import { registerAs } from "@nestjs/config";
import { TypeOrmModuleOptions } from "@nestjs/typeorm";
import { DataSource, DataSourceOptions } from "typeorm";
import { addTransactionalDataSource } from "typeorm-transactional";

export default registerAs("database", () => ({
  host: process.env.DB_HOST ?? "localhost",
  port: parseInt(process.env.DB_PORT ?? "3306", 10),
  username: process.env.DB_USER ?? "root",
  password: process.env.DB_PASSWORD ?? "root",
  database: process.env.DB_NAME ?? "app",
}));

export const databaseConnectionFactory = async (): Promise<TypeOrmModuleOptions> => {
  const config = defaultDatabaseConfig();
  return {
    type: "mysql",
    host: config.host,
    port: config.port,
    username: config.username,
    password: config.password,
    database: config.database,
    entities: [__dirname + "/../**/*.entity{.ts,.js}"],
    synchronize: false,
    logging: true,
    autoLoadEntities: true,
    timezone: 'Z', // UTC 시간대 강제
  };
};

export const dataSourceFactory = async (options?: DataSourceOptions) => {
  if (!options) {
    throw new Error('Invalid options passed');
  }
  return addTransactionalDataSource(new DataSource(options));
};

const defaultDatabaseConfig = () => ({
  host: process.env.DB_HOST ?? "localhost",
  port: parseInt(process.env.DB_PORT ?? "3306", 10),
  username: process.env.DB_USER ?? "root",
  password: process.env.DB_PASSWORD ?? "root",
  database: process.env.DB_NAME ?? "app",
});
