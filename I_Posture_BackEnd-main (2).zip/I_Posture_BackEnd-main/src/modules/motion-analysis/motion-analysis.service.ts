import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { FindMotionAnalysisDto } from './dto/find-motion-analysis.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { MotionAnalysisResponseDto, MotionAnalysisDetailResponseDto } from './dto/motion-analysis-response.dto';
import { CreateMotionAnalysisDto } from './dto/create-motion-analysis.dto';
import { UpdateMotionAnalysisDto } from './dto/update-motion-analysis.dto';
import { DeleteMotionAnalysesDto } from './dto/delete-motion-analyses.dto';
import { SaveTrainerCommentDto } from './dto/save-trainer-comment.dto';
import { S3Service } from '../../s3/s3.service';
import { CapacityService } from '../capacity/capacity.service';
import { FileEntity, FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { StoredFileReleaseService } from '../capacity/stored-file-release.service';
import { Transactional } from 'typeorm-transactional';

@Injectable()
export class MotionAnalysisService {
  constructor(
    @InjectRepository(MotionAnalysisEntity)
    private readonly motionAnalysisRepo: Repository<MotionAnalysisEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    private readonly storedFileReleaseService: StoredFileReleaseService,
  ) {}

  /**
   * 회원의 모션 분석 목록을 조회합니다.
   */
  async findAllByMemberId(trainerId: string, memberId: string, dto: FindMotionAnalysisDto): Promise<IPageData<MotionAnalysisResponseDto>> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const { page = 1, limit = 10, startDate, endDate, sort } = dto;
    const query = this.motionAnalysisRepo.createQueryBuilder('analysis')
      .where('analysis.userId = :userId', { userId: memberId });

    if (startDate) query.andWhere('analysis.createdAt >= :startDate', { startDate });
    if (endDate) query.andWhere('analysis.createdAt <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('analysis.createdAt', sortDirection);

    const total = await query.getCount();
    const analyses = await query.offset((page - 1) * limit).limit(limit).getMany();

    return {
      items: analyses.map(a => ({
        id: a.id,
        createdAt: a.createdAt,
        title: a.title,
        memo: a.memo,
        trainerComment: a.trainerComment,
      })),
      paging: buildPaging(total, limit, page),
    };
  }

  /**
   * 모션 분석 상세 정보를 조회합니다.
   */
  async findOne(trainerId: string, memberId: string, id: string): Promise<MotionAnalysisDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const analysis = await this.motionAnalysisRepo.findOne({ where: { id, userId: memberId } });
    if (!analysis) throw new NotFoundException('모션 분석 데이터를 찾을 수 없습니다.');

    const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.MOTION, relatedId: id } });

    return {
      id: analysis.id,
      createdAt: analysis.createdAt,
      title: analysis.title,
      memo: analysis.memo,
      trainerComment: analysis.trainerComment,
      files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, size: f.size, s3Key: f.s3Key })),
    };
  }

  async findOnePublic(id: string, memberId?: string): Promise<MotionAnalysisDetailResponseDto> {
    const analysis = await this.motionAnalysisRepo.findOne({
      where: memberId ? { id, userId: memberId } : { id },
    });
    if (!analysis) throw new NotFoundException('모션 분석 데이터를 찾을 수 없습니다.');

    const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.MOTION, relatedId: id } });

    return {
      id: analysis.id,
      createdAt: analysis.createdAt,
      title: analysis.title,
      memo: analysis.memo,
      trainerComment: analysis.trainerComment,
      files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, size: f.size, s3Key: f.s3Key })),
    };
  }

  /**
   * 모션 분석 데이터를 생성합니다. (동영상 업로드 포함)
   */
  async create(trainer: UserEntity, memberId: string, dto: CreateMotionAnalysisDto, file: Express.Multer.File): Promise<MotionAnalysisEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId: trainer.id, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원에게 모션 분석을 등록할 권한이 없습니다.');

    // 1. 모션 분석 데이터 먼저 생성 (relatedId를 얻기 위해)
    const motionAnalysis = this.motionAnalysisRepo.create({
      ...dto,
      trainerId: trainer.id,
      userId: memberId,
    });
    const savedAnalysis = await this.motionAnalysisRepo.save(motionAnalysis);

    // 2. 파일 업로드
    const uploadedFile = await this.s3Service.uploadFile(file, {
      memberId: memberId,
      uploaderId: trainer.id,
      ownerType: FileOwnerType.TRAINER,
      ownerId: trainer.id,
      relatedType: FileRelatedType.MOTION,
      relatedId: savedAnalysis.id, // 생성된 분석 데이터의 ID를 연결
    });

    // 3. 트레이너 용량 차감
    await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);

    return savedAnalysis;
  }

  /**
   * 모션 분석 데이터를 수정합니다.
   */
  async update(trainerId: string, memberId: string, id: string, dto: UpdateMotionAnalysisDto): Promise<MotionAnalysisEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 수정할 권한이 없습니다.');

    const analysis = await this.motionAnalysisRepo.findOne({ where: { id, userId: memberId } });
    if (!analysis) throw new NotFoundException('모션 분석 데이터를 찾을 수 없습니다.');

    if (analysis.trainerId !== trainerId) {
      throw new ForbiddenException('본인이 등록한 데이터만 수정할 수 있습니다.');
    }

    Object.assign(analysis, dto);
    return this.motionAnalysisRepo.save(analysis);
  }

  /**
   * 트레이너 코멘트를 저장합니다.
   */
  async saveTrainerComment(trainerId: string, memberId: string, id: string, dto: SaveTrainerCommentDto): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 수정할 권한이 없습니다.');

    const analysis = await this.motionAnalysisRepo.findOne({ where: { id, userId: memberId } });
    if (!analysis) throw new NotFoundException('모션 분석 데이터를 찾을 수 없습니다.');

    if (analysis.trainerId !== trainerId) {
      throw new ForbiddenException('본인이 등록한 데이터만 수정할 수 있습니다.');
    }

    await this.motionAnalysisRepo.update(id, { trainerComment: dto.comment });
    return { success: true };
  }

  /**
   * 모션 분석 데이터를 일괄 삭제합니다. (논리적 삭제)
   */
  @Transactional()
  async delete(trainerId: string, memberId: string, dto: DeleteMotionAnalysesDto): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 삭제할 권한이 없습니다.');

    const analyses = await this.motionAnalysisRepo.find({ where: { id: In(dto.ids), userId: memberId } });
    if (analyses.length !== dto.ids.length) {
      throw new NotFoundException('일부 모션 분석 데이터를 찾을 수 없습니다.');
    }

    for (const analysis of analyses) {
      if (analysis.trainerId !== trainerId) {
        throw new ForbiddenException(`데이터 ${analysis.id}를 삭제할 권한이 없습니다.`);
      }
    }

    await this.storedFileReleaseService.releaseForTrainer(trainerId, dto.ids);
    await this.motionAnalysisRepo.softDelete(dto.ids);
    return { success: true };
  }
}
