import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query, Req, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { MotionAnalysisService } from './motion-analysis.service';
import { FindMotionAnalysisDto } from './dto/find-motion-analysis.dto';
import { MotionAnalysisResponseDto, MotionAnalysisDetailResponseDto } from './dto/motion-analysis-response.dto';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { CreateMotionAnalysisDto } from './dto/create-motion-analysis.dto';
import { UpdateMotionAnalysisDto } from './dto/update-motion-analysis.dto';
import { DeleteMotionAnalysesDto } from './dto/delete-motion-analyses.dto';
import { SaveTrainerCommentDto } from './dto/save-trainer-comment.dto';

@ApiTags('Motion Analysis')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('motion-analyses')
export class MotionAnalysisController {
  constructor(private readonly motionAnalysisService: MotionAnalysisService) {}

  /**
   * @summary 회원의 모션 분석 목록 조회
   */
  @ApiOperation({ summary: 'Get Member Motion Analysis List' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() findDto: FindMotionAnalysisDto,
  ): Promise<IPageResponse<MotionAnalysisResponseDto>> {
    const pageData = await this.motionAnalysisService.findAllByMemberId(req.user.id, memberId, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 모션 분석 상세 조회
   */
  @ApiOperation({ summary: 'Get Motion Analysis Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/:id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<MotionAnalysisDetailResponseDto>> {
    const data = await this.motionAnalysisService.findOne(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 모션 분석 등록 (동영상 업로드)
   */
  @ApiOperation({ summary: 'Create Motion Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        memo: { type: 'string' },
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  async create(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() createDto: CreateMotionAnalysisDto,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<ISuccessResponse<MotionAnalysisEntity>> {
    const data = await this.motionAnalysisService.create(req.user, memberId, createDto, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 모션 분석 수정
   */
  @ApiOperation({ summary: 'Update Motion Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put('member/:memberId/:id')
  async update(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() updateDto: UpdateMotionAnalysisDto,
  ): Promise<ISuccessResponse<MotionAnalysisEntity>> {
    const data = await this.motionAnalysisService.update(req.user.id, memberId, id, updateDto);
    return SuccessResponse(data);
  }

  /**
   * @summary 트레이너 코멘트 저장
   */
  @ApiOperation({ summary: 'Save Trainer Comment' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put('member/:memberId/:id/comment')
  async saveTrainerComment(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() commentDto: SaveTrainerCommentDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.motionAnalysisService.saveTrainerComment(req.user.id, memberId, id, commentDto);
    return SuccessResponse(result);
  }

  /**
   * @summary 모션 분석 일괄 삭제
   */
  @ApiOperation({ summary: 'Delete Motion Analyses' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() deleteDto: DeleteMotionAnalysesDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.motionAnalysisService.delete(req.user.id, memberId, deleteDto);
    return SuccessResponse(result);
  }
}

/**
 * 모션 분석 퍼블릭 API (인증 불필요)
 */
@ApiTags('Motion Analysis')
@Controller('motion-analyses')
export class PublicMotionAnalysisController {
  constructor(private readonly motionAnalysisService: MotionAnalysisService) {}

  /**
   * @summary 모션 분석 상세 조회 (공유 링크 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Motion Analysis Detail (Public Share)' })
  @Get(':id/public')
  async findOnePublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<MotionAnalysisDetailResponseDto>> {
    const data = await this.motionAnalysisService.findOnePublic(id);
    return SuccessResponse(data);
  }
}

/**
 * 센터용 모션 분석 퍼블릭 API (인증 불필요, 공유 링크)
 */
@ApiTags('Center Motion Analysis Public')
@Controller('center/motion-analyses/public')
export class CenterMotionAnalysisPublicController {
  constructor(private readonly motionAnalysisService: MotionAnalysisService) {}

  @ApiOperation({ summary: 'Get Motion Analysis Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/:id')
  async findOnePublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<MotionAnalysisDetailResponseDto>> {
    const data = await this.motionAnalysisService.findOnePublic(id, memberId);
    return SuccessResponse(data);
  }
}
