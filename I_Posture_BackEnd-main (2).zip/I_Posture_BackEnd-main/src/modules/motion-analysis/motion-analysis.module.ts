import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import {
  MotionAnalysisController,
  PublicMotionAnalysisController,
  CenterMotionAnalysisPublicController,
} from './motion-analysis.controller';
import { MotionAnalysisService } from './motion-analysis.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { S3Module } from '../../s3/s3.module';
import { CapacityModule } from '../capacity/capacity.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      MotionAnalysisEntity, 
      UserEntity, 
      TrainerUserEntity,
      FileEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
    ]),
    S3Module,
    CapacityModule,
  ],
  controllers: [
    MotionAnalysisController,
    PublicMotionAnalysisController,
    CenterMotionAnalysisPublicController,
  ],
  providers: [MotionAnalysisService, SubscriptionGuard],
  exports: [MotionAnalysisService],
})
export class MotionAnalysisModule {}
