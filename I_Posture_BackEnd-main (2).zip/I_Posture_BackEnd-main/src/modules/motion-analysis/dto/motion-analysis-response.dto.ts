import { ApiProperty } from '@nestjs/swagger';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '파일 크기' })
  size!: string;

  @ApiProperty({ description: '원본 파일명 (S3 Key 등)' })
  s3Key!: string;
}

// 목록용 DTO
export class MotionAnalysisResponseDto {
  @ApiProperty({ description: '분석 ID' })
  id!: string;

  @ApiProperty({ description: '측정 날짜 (생성일시)' })
  createdAt!: Date;

  @ApiProperty({ description: '영상 제목 또는 수기 코멘트', nullable: true })
  title?: string;

  @ApiProperty({ description: '간단 메모', nullable: true })
  memo?: string;

  @ApiProperty({ description: '트레이너 코멘트', nullable: true })
  trainerComment?: string;
}

// 상세용 DTO
export class MotionAnalysisDetailResponseDto extends MotionAnalysisResponseDto {
  @ApiProperty({ description: '첨부 파일 목록 (동영상)', type: [FileDto] })
  files!: FileDto[];
}
