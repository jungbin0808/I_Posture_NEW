import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString } from 'class-validator';

export class CreateMotionAnalysisDto {
  @ApiProperty({ description: '영상 제목 또는 수기 코멘트', required: false })
  @IsString()
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '간단 메모', required: false })
  @IsString()
  @IsOptional()
  memo?: string;
}
