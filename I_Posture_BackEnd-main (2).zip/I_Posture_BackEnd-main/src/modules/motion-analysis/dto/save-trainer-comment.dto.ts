import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class SaveTrainerCommentDto {
  @ApiProperty({ description: '트레이너 코멘트', example: '전반적으로 자세가 좋습니다. 다만 왼쪽 어깨가 약간 올라가는 경향이 있으니 주의하세요.' })
  @IsString()
  comment!: string;
}
