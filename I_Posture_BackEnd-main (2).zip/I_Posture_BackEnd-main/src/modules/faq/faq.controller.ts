import { Controller, Get, Param, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { FaqService } from './faq.service';
import { FindFaqDto } from './dto/find-faq.dto';
import { IPageData, IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { FaqEntity } from '../../database/entities/faq.entity';
import { FaqCategoryEntity } from '../../database/entities/faq-category.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { SuccessResponse } from '../../common/response/response.helper';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';

@ApiTags('Faq')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('faqs')
export class FaqController {
  constructor(private readonly faqService: FaqService) {}

  @ApiOperation({ summary: 'Get FAQ Categories' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('categories')
  async getCategories(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<FaqCategoryEntity[]>> {
    const categories = await this.faqService.findAllCategories(req.user);
    return SuccessResponse(categories);
  }

  @ApiOperation({ summary: 'Get FAQ List' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer)
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() findFaqDto: FindFaqDto,
  ): Promise<IPageResponse<FaqEntity>> {
    const pageData: IPageData<FaqEntity> = await this.faqService.findAll(req.user, findFaqDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Get FAQ Detail' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer)
  @Get(':id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FaqEntity>> {
    const faq = await this.faqService.findOne(req.user, id);
    return SuccessResponse(faq);
  }
}
