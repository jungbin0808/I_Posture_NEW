import { IsOptional, IsString, IsIn } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export class FindFaqDto extends PaginationDto {
  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsIn(['ALL', 'MEMBER', 'TRAINER', 'CENTER'])
  targetRole?: 'ALL' | 'MEMBER' | 'TRAINER' | 'CENTER';

  @IsOptional()
  @IsString()
  faqCategory?: string;
}
