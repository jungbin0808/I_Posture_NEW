// 이 파일은 src/modules/admin/faq/dto/update-faq.dto.ts 로 이동되었습니다.
// 직접 삭제해주세요.
export {};
