import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FaqCategoryEntity } from '../../database/entities/faq-category.entity';
import { FaqEntity } from '../../database/entities/faq.entity';
import { FaqController } from './faq.controller';
import { FaqService } from './faq.service';
import { AuthModule } from '../auth/auth.module';

@Module({
  imports: [TypeOrmModule.forFeature([FaqCategoryEntity, FaqEntity]), forwardRef(() => AuthModule)],
  controllers: [FaqController], // FaqAdminController 제거
  providers: [FaqService],
  exports: [FaqService], // FaqService를 다른 모듈에서 사용할 수 있도록 export
})
export class FaqModule {}
