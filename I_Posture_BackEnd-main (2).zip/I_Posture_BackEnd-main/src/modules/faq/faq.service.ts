import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { FaqCategoryEntity } from '../../database/entities/faq-category.entity';
import { FaqEntity, FaqTargetRole } from '../../database/entities/faq.entity';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { FindFaqDto } from './dto/find-faq.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';

@Injectable()
export class FaqService {
  constructor(
    @InjectRepository(FaqCategoryEntity)
    private readonly faqCategoryRepo: Repository<FaqCategoryEntity>,
    @InjectRepository(FaqEntity)
    private readonly faqRepo: Repository<FaqEntity>,
  ) {}

  async findAllCategories(user: UserEntity): Promise<FaqCategoryEntity[]> {
    const userFaqRole = this.resolveFaqTargetRole(user.userType);
    const queryBuilder = this.faqCategoryRepo
      .createQueryBuilder('category')
      .where('category.isActive = :isActive', { isActive: true })
      .orderBy('category.sortOrder', 'ASC');

    this.applyTargetRoleFilter(queryBuilder, 'category', userFaqRole);

    return queryBuilder.getMany();
  }

  async findAll(user: UserEntity, findFaqDto: FindFaqDto): Promise<IPageData<FaqEntity>> {
    const { page = 1, limit = 10, search, faqCategory } = findFaqDto;
    const userFaqRole = this.resolveFaqTargetRole(user.userType);
    const queryBuilder: SelectQueryBuilder<FaqEntity> = this.faqRepo.createQueryBuilder('faq');

    queryBuilder
      .leftJoinAndSelect('faq.category', 'category')
      .where('faq.isVisible = :isVisible', { isVisible: true })
      .orderBy('faq.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    // USER APP(MEMBER)은 사용자앱 전용 FAQ 콘텐츠가 별도 전달될 예정이라, 기존 센터/트레이너 공용(ALL) FAQ는
    // 노출하지 않고 targetRole=MEMBER로 등록된 것만 보여준다. 센터/트레이너는 기존대로 ALL + 자기 role 노출 유지.
    this.applyTargetRoleFilter(queryBuilder, 'faq', userFaqRole);

    if (search) {
      queryBuilder.andWhere('faq.title LIKE :search', { search: `%${search}%` });
    }
    if (faqCategory) {
      queryBuilder.andWhere('category.id = :faqCategory', { faqCategory: faqCategory });
    }

    const [faqs, total] = await queryBuilder.getManyAndCount();
    return { items: faqs, paging: buildPaging(total, limit, page) };
  }

  async findOne(user: UserEntity, id: string): Promise<FaqEntity> {
    const faq = await this.faqRepo.findOne({ where: { id }, relations: ['category'] });
    if (!faq || !faq.isVisible || !this.canAccessFaq(faq, user.userType)) {
      throw new NotFoundException(`FAQ with ID "${id}" not found`);
    }

    await this.faqRepo.increment({ id }, 'viewCount', 1);
    return faq;
  }

  /**
   * MEMBER는 ALL(센터/트레이너 공용) 제외하고 자기 role만, 센터/트레이너는 기존대로 ALL + 자기 role 노출.
   * FAQ/카테고리 조회 공용 - alias는 호출부에서 넘긴 쿼리빌더의 테이블 별칭.
   */
  private applyTargetRoleFilter<T extends FaqEntity | FaqCategoryEntity>(
    queryBuilder: SelectQueryBuilder<T>,
    alias: string,
    userFaqRole: FaqTargetRole,
  ): void {
    if (userFaqRole === FaqTargetRole.MEMBER) {
      queryBuilder.andWhere(`${alias}.targetRole = :userFaqRole`, { userFaqRole });
    } else {
      queryBuilder.andWhere(`(${alias}.targetRole = :allRole OR ${alias}.targetRole = :userFaqRole)`, {
        allRole: FaqTargetRole.ALL,
        userFaqRole,
      });
    }
  }

  private resolveFaqTargetRole(userType: UserType): FaqTargetRole {
    switch (userType) {
      case UserType.MEMBER:
        return FaqTargetRole.MEMBER;
      case UserType.C_TRAINER:
      case UserType.F_TRAINER:
        return FaqTargetRole.TRAINER;
      case UserType.CENTER:
        return FaqTargetRole.CENTER;
      default:
        return FaqTargetRole.ALL;
    }
  }

  private canAccessFaq(faq: FaqEntity, userType: UserType): boolean {
    const userFaqRole = this.resolveFaqTargetRole(userType);
    // USER APP(MEMBER)은 센터/트레이너 공용(ALL) FAQ 상세도 직접 접근 불가 - 목록 노출 정책과 동일하게 맞춤
    if (faq.targetRole === FaqTargetRole.ALL) {
      return userFaqRole !== FaqTargetRole.MEMBER;
    }
    return faq.targetRole === userFaqRole;
  }
}
