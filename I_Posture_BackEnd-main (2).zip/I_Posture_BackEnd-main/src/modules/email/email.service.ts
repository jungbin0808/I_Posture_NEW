import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as nodemailer from 'nodemailer';
import { randomUUID } from 'crypto';

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);
  private readonly transporter: nodemailer.Transporter;
  private readonly fromAddress: string;
  private readonly gmailUser: string;

  constructor(private readonly configService: ConfigService) {
    this.gmailUser = this.configService.get<string>('GMAIL_USER') ?? '';
    const gmailPass = this.configService.get<string>('GMAIL_APP_PASSWORD') ?? '';

    this.fromAddress = `iPosture <${this.gmailUser}>`;

    this.transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      auth: {
        user: this.gmailUser,
        pass: gmailPass,
      },
    });
  }

  async sendVerificationCode(to: string, code: string, purpose: 'REGISTER' | 'FIND_ID' | 'FIND_PASSWORD'): Promise<void> {
    const subjectMap: Record<string, string> = {
      REGISTER: 'iPosture 회원가입 인증 번호',
      FIND_ID: 'iPosture 아이디 찾기 인증 번호',
      FIND_PASSWORD: 'iPosture 비밀번호 재설정 인증 번호',
    };

    const bodyMap: Record<string, string> = {
      REGISTER: '회원가입',
      FIND_ID: '아이디 찾기',
      FIND_PASSWORD: '비밀번호 재설정',
    };

    const subject = subjectMap[purpose];
    const purposeLabel = bodyMap[purpose];
    const domain = this.gmailUser.split('@')[1] ?? 'gmail.com';
    const messageId = `<${randomUUID()}@${domain}>`;

    const htmlBody = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background-color:#f9fafb;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f9fafb;padding:40px 0;">
    <tr>
      <td align="center">
        <table role="presentation" width="480" cellpadding="0" cellspacing="0" style="max-width:480px;width:100%;background-color:#ffffff;border:1px solid #e5e7eb;border-radius:8px;padding:40px;">
          <tr>
            <td>
              <p style="margin:0 0 4px 0;font-family:Arial,sans-serif;font-size:22px;font-weight:bold;color:#111827;">이메일 인증</p>
              <p style="margin:0 0 28px 0;font-family:Arial,sans-serif;font-size:15px;color:#6b7280;">${purposeLabel}을 위한 인증 번호입니다.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f3f4f6;border-radius:8px;margin-bottom:28px;">
                <tr>
                  <td align="center" style="padding:28px;">
                    <span style="font-family:Arial,sans-serif;font-size:38px;font-weight:bold;color:#111827;display:block;">${code}</span>
                  </td>
                </tr>
              </table>
              <p style="margin:0 0 8px 0;font-family:Arial,sans-serif;font-size:14px;color:#6b7280;">인증 번호는 <strong>5분</strong> 동안 유효합니다.</p>
              <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#9ca3af;">본인이 요청하지 않은 경우 이 메일을 무시하세요.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

    const textBody = `iPosture ${purposeLabel} 인증 번호

인증 번호: ${code}

이 번호는 5분 동안 유효합니다.
본인이 요청하지 않은 경우 이 메일을 무시하세요.`;

    await this.transporter.sendMail({
      from: this.fromAddress,
      to,
      subject,
      html: htmlBody,
      text: textBody,
      messageId,
      headers: {
        'X-Entity-Ref-ID': randomUUID(),
      },
    });

    this.logger.log(`Verification email sent to ${to} for purpose: ${purpose}`);
  }

  async sendTrainerInviteEmail(params: {
    to: string;
    trainerName: string;
    centerName: string;
    userId: string;
    tempPassword: string;
  }): Promise<void> {
    const { to, trainerName, centerName, userId, tempPassword } = params;
    const subject = `iPosture ${centerName} 트레이너 계정 안내`;
    const domain = this.gmailUser.split('@')[1] ?? 'gmail.com';
    const messageId = `<${randomUUID()}@${domain}>`;

    const htmlBody = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background-color:#f9fafb;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f9fafb;padding:40px 0;">
    <tr>
      <td align="center">
        <table role="presentation" width="480" cellpadding="0" cellspacing="0" style="max-width:480px;width:100%;background-color:#ffffff;border:1px solid #e5e7eb;border-radius:8px;padding:40px;">
          <tr>
            <td>
              <p style="margin:0 0 4px 0;font-family:Arial,sans-serif;font-size:22px;font-weight:bold;color:#111827;">트레이너 계정 안내</p>
              <p style="margin:0 0 28px 0;font-family:Arial,sans-serif;font-size:15px;color:#6b7280;">${centerName}에서 ${trainerName}님의 트레이너 계정이 발급되었습니다.</p>
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color:#f3f4f6;border-radius:8px;margin-bottom:28px;">
                <tr>
                  <td style="padding:20px 24px;font-family:Arial,sans-serif;font-size:14px;color:#374151;line-height:1.8;">
                    <div><strong>아이디</strong> ${userId}</div>
                    <div><strong>임시 비밀번호</strong> ${tempPassword}</div>
                  </td>
                </tr>
              </table>
              <p style="margin:0 0 8px 0;font-family:Arial,sans-serif;font-size:14px;color:#6b7280;">iPosture 트레이너 앱/웹에서 로그인 후 비밀번호를 변경해 주세요.</p>
              <p style="margin:0;font-family:Arial,sans-serif;font-size:12px;color:#9ca3af;">본인이 요청하지 않은 경우 센터 관리자에게 문의해 주세요.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

    const textBody = `iPosture ${centerName} 트레이너 계정 안내

${trainerName}님, 트레이너 계정이 발급되었습니다.

아이디: ${userId}
임시 비밀번호: ${tempPassword}

iPosture 트레이너 앱/웹에서 로그인 후 비밀번호를 변경해 주세요.`;

    await this.transporter.sendMail({
      from: this.fromAddress,
      to,
      subject,
      html: htmlBody,
      text: textBody,
      messageId,
      headers: {
        'X-Entity-Ref-ID': randomUUID(),
      },
    });

    this.logger.log(`Trainer invite email sent to ${to} (center: ${centerName})`);
  }
}
