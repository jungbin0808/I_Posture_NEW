import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { TermEntity } from "../../database/entities/term.entity";
import { TermController } from "./term.controller";
import { TermService } from "./term.service";
import { UserAgreementEntity } from "../../database/entities/user-agreement.entity";

@Module({
  imports: [TypeOrmModule.forFeature([TermEntity, UserAgreementEntity])],
  controllers: [TermController],
  providers: [TermService],
})
export class TermModule {}
