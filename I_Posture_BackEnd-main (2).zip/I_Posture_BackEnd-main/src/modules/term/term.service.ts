import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { TermEntity, TermType } from "../../database/entities/term.entity";

@Injectable()
export class TermService {
  constructor(
    @InjectRepository(TermEntity)
    private readonly termRepo: Repository<TermEntity>,
  ) {}

  async findByType(type: TermType): Promise<TermEntity> {
    const term = await this.termRepo.findOne({
      where: { type, isActive: true },
      order: { createdAt: 'DESC' },
    });
    if (!term) throw new NotFoundException(`'${type}' 약관을 찾을 수 없습니다.`);
    return term;
  }

  /** 가입/약관 동의 화면용 - 현재 활성화된 약관 전체 목록(타입별 최신 1건씩) */
  async findAllActive(): Promise<TermEntity[]> {
    return this.termRepo.find({
      where: { isActive: true },
      order: { type: 'ASC' },
    });
  }
}
