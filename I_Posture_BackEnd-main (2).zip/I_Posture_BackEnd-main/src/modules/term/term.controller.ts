import { Controller, Get, Param } from "@nestjs/common";
import { ApiOperation, ApiParam, ApiTags } from "@nestjs/swagger";
import { TermService } from "./term.service";
import { TermType } from "../../database/entities/term.entity";

@ApiTags('약관')
@Controller("terms")
export class TermController {
  constructor(private readonly termService: TermService) {}

  @Get()
  @ApiOperation({ summary: '약관 목록 조회 (현재 활성화된 약관 전체, 타입별 최신 1건씩)' })
  findAllActive() {
    return this.termService.findAllActive();
  }

  @Get(':type')
  @ApiOperation({ summary: '약관 단건 조회 (type: SERVICE | PRIVACY | MARKETING | THIRD_PARTY | LOCATION)' })
  @ApiParam({ name: 'type', enum: TermType })
  findByType(@Param('type') type: TermType) {
    return this.termService.findByType(type);
  }
}
