import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { PointHistoryEntity, PointHistoryType } from '../../../database/entities/point-history.entity';
import { BannerService } from '../../banner/banner.service';
import { BannerPosition } from '../../../database/entities/banner.entity';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { PointSummaryResponseDto } from './dto/point-summary-response.dto';
import { FindPointHistoryDto } from './dto/find-point-history.dto';
import { PointHistoryItemDto } from './dto/point-history-item.dto';

@Injectable()
export class AppPointService {
  constructor(
    @InjectRepository(PointHistoryEntity)
    private readonly pointHistoryRepo: Repository<PointHistoryEntity>,
    private readonly bannerService: BannerService,
  ) {}

  async getSummary(user: UserEntity): Promise<PointSummaryResponseDto> {
    const [earnCount, banners] = await Promise.all([
      this.pointHistoryRepo.count({ where: { userId: user.id, type: PointHistoryType.EARN } }),
      this.bannerService.findActiveByPosition(BannerPosition.POINT),
    ]);

    return {
      totalPoints: user.totalPoints,
      earnCount,
      banners: banners.map((b) => ({ id: b.id, imageUrl: b.imageUrl, linkUrl: b.linkUrl })),
    };
  }

  async getHistory(user: UserEntity, dto: FindPointHistoryDto): Promise<IPageData<PointHistoryItemDto>> {
    const { page = 1, limit = 10 } = dto;

    const [rows, total] = await this.pointHistoryRepo.findAndCount({
      where: { userId: user.id },
      order: { createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });

    const items: PointHistoryItemDto[] = rows.map((r) => ({
      id: r.id,
      type: r.type,
      source: r.source,
      amount: r.amount,
      description: r.description,
      createdAt: r.createdAt,
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }
}
