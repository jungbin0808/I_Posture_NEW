import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse, IPageResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AppPointService } from './app-point.service';
import { PointSummaryResponseDto } from './dto/point-summary-response.dto';
import { FindPointHistoryDto } from './dto/find-point-history.dto';
import { PointHistoryItemDto } from './dto/point-history-item.dto';

@ApiTags('App - Point')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/point')
export class AppPointController {
  constructor(private readonly appPointService: AppPointService) {}

  @ApiOperation({ summary: '포인트 메인 - 누적 리워드(보유 포인트 총액), 총 지급 횟수' })
  @Get('summary')
  async getSummary(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<PointSummaryResponseDto>> {
    const data = await this.appPointService.getSummary(req.user);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '포인트 지급/변동 이력 목록 (관리자가 admin/points/adjust로 입력한 내역)' })
  @Get('history')
  async getHistory(
    @Req() req: { user: UserEntity },
    @Query() dto: FindPointHistoryDto,
  ): Promise<IPageResponse<PointHistoryItemDto>> {
    const pageData = await this.appPointService.getHistory(req.user, dto);
    return SuccessResponse(pageData);
  }
}
