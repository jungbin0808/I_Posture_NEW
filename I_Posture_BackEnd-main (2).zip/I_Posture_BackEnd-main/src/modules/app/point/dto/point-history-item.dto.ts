import { ApiProperty } from '@nestjs/swagger';
import { PointHistoryType, PointSource } from '../../../../database/entities/point-history.entity';

export class PointHistoryItemDto {
  @ApiProperty({ description: '포인트 이력 ID' })
  id!: string;

  @ApiProperty({ enum: PointHistoryType, description: '변동 유형 (EARN: 지급, USE: 차감, EXPIRE: 소멸)' })
  type!: PointHistoryType;

  @ApiProperty({ enum: PointSource, description: '발생 원천' })
  source!: PointSource;

  @ApiProperty({ description: '변동 포인트 (항상 양수, 부호는 type으로 판단)' })
  amount!: number;

  @ApiProperty({ description: '적요 (ex. "챌린지 성공 리워드 (스토어)")', required: false, nullable: true })
  description?: string;

  @ApiProperty({ description: '지급/변동 일시' })
  createdAt!: Date;
}
