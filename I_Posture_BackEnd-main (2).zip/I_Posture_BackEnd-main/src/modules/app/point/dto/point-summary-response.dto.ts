import { ApiProperty } from '@nestjs/swagger';

class PointBannerItemDto {
  @ApiProperty({ description: '배너 ID' })
  id!: string;

  @ApiProperty({ description: '배너 이미지 URL' })
  imageUrl!: string;

  @ApiProperty({ description: '탭 시 이동할 링크 URL', required: false, nullable: true })
  linkUrl?: string;
}

export class PointSummaryResponseDto {
  @ApiProperty({ description: '누적 리워드 (현재 보유 포인트 총액, user.totalPoints)' })
  totalPoints!: number;

  @ApiProperty({ description: '총 지급 횟수 (point_history의 EARN 이력 건수)' })
  earnCount!: number;

  @ApiProperty({ description: '스토어 홍보 배너 (SAC에서 관리)', type: [PointBannerItemDto] })
  banners!: PointBannerItemDto[];
}
