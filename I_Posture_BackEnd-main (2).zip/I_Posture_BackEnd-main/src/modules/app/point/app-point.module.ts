import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PointHistoryEntity } from '../../../database/entities/point-history.entity';
import { BannerModule } from '../../banner/banner.module';
import { AppPointController } from './app-point.controller';
import { AppPointService } from './app-point.service';

@Module({
  imports: [TypeOrmModule.forFeature([PointHistoryEntity]), BannerModule],
  controllers: [AppPointController],
  providers: [AppPointService],
})
export class AppPointModule {}
