import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { IsNull, Not, Repository } from 'typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { BodyReportEntity } from '../../../database/entities/body-report.entity';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../../database/entities/member-identity-link.entity';
import { CustomExerciseEntity } from '../../../database/entities/custom-exercise.entity';
import { CustomExerciseService, ExerciseCategory } from '../../custom-exercise/custom-exercise.service';
import {
  ExerciseRecommendationResponseDto,
  RecommendedExerciseItemDto,
  RecommendationSource,
} from './dto/exercise-recommendation-response.dto';
import { FindExerciseRecommendationDto } from './dto/find-exercise-recommendation.dto';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';

interface RecommendationContext {
  bodySource: RecommendationSource;
  bodyMeasuredAt: Date | null;
  inbodySource: RecommendationSource;
  inbodyMeasuredAt: Date | null;
  exercises: CustomExerciseEntity[];
}

@Injectable()
export class AppExerciseRecommendationService {
  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly customExerciseService: CustomExerciseService,
  ) {}

  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.managedMemberId ?? null;
  }

  /**
   * STEP A: 체형측정값 결정 - 트레이너 측정 > 회원 셀프측정 > (없음)
   */
  private async pickPriorityBodyReport(appMemberId: string, managedMemberId: string | null): Promise<BodyReportEntity | null> {
    if (managedMemberId) {
      const trainerReport = await this.bodyReportRepo.findOne({
        where: { userId: managedMemberId, trainerId: Not(IsNull()) },
        order: { createdAt: 'DESC' },
      });
      if (trainerReport) return trainerReport;
    }
    return this.bodyReportRepo.findOne({
      where: { userId: appMemberId, trainerId: IsNull() },
      order: { createdAt: 'DESC' },
    });
  }

  /**
   * STEP B: 인바디값 결정 - 트레이너 측정 > 회원 셀프측정 > (없음)
   */
  private async pickPriorityInbody(appMemberId: string, managedMemberId: string | null): Promise<InbodyDataEntity | null> {
    if (managedMemberId) {
      const trainerInbody = await this.inbodyDataRepo.findOne({
        where: { userId: managedMemberId, trainerId: Not(IsNull()) },
        order: { measuredAt: 'DESC' },
      });
      if (trainerInbody) return trainerInbody;
    }
    return this.inbodyDataRepo.findOne({
      where: { userId: appMemberId, trainerId: IsNull() },
      order: { measuredAt: 'DESC' },
    });
  }

  private toItemDto(e: CustomExerciseEntity): RecommendedExerciseItemDto {
    return {
      id: e.id,
      category: e.category,
      mainCat: e.mainCat,
      subCat: e.subCat,
      detailCat: e.detailCat,
      level: e.level,
      youtubeUrl: e.youtubeUrl,
      title: e.title ?? null,
      thumbnailUrl: e.thumbnailUrl ?? null,
      durationSeconds: e.durationSeconds ?? null,
      isNew: e.isNew,
      createdAt: e.createdAt,
    };
  }

  /**
   * STEP A~D: 체형/인바디 우선순위 결정 → 각각 맞춤운동 조회 → 믹스 → 최신 등록순 정렬.
   * getRecommendation(메인)과 getRecommendationAll(전체보기)이 공유하는 개인화 로직.
   */
  private async buildRecommendationContext(user: UserEntity): Promise<RecommendationContext> {
    const managedMemberId = await this.resolveManagedMemberId(user.id);

    // STEP A
    const bodyReport = await this.pickPriorityBodyReport(user.id, managedMemberId);
    let bodyExercises: CustomExerciseEntity[];
    let bodySource: RecommendationSource;
    let bodyMeasuredAt: Date | null;

    if (bodyReport) {
      bodySource = bodyReport.trainerId ? RecommendationSource.TRAINER : RecommendationSource.SELF;
      bodyMeasuredAt = bodyReport.createdAt;
      const grouped = await this.customExerciseService.findByBodyReportId(bodyReport.id);
      bodyExercises = Object.values(grouped).flat();
    } else {
      bodySource = RecommendationSource.RANDOM;
      bodyMeasuredAt = null;
      bodyExercises = await this.customExerciseService.findRandomBodyExercises();
    }

    // STEP B
    const inbody = await this.pickPriorityInbody(user.id, managedMemberId);
    let inbodyExercises: CustomExerciseEntity[];
    let inbodySource: RecommendationSource;
    let inbodyMeasuredAt: Date | null;

    if (inbody) {
      inbodySource = inbody.trainerId ? RecommendationSource.TRAINER : RecommendationSource.SELF;
      inbodyMeasuredAt = inbody.measuredAt;
      const grouped = await this.customExerciseService.findByInbodyId(inbody.id);
      inbodyExercises = Object.values(grouped).flat();
    } else {
      inbodySource = RecommendationSource.RANDOM;
      inbodyMeasuredAt = null;
      inbodyExercises = await this.customExerciseService.findInbodyDiet();
    }

    // STEP C: 믹스 (항상 무조건 적용)
    const mergedById = new Map<string, CustomExerciseEntity>();
    for (const e of [...bodyExercises, ...inbodyExercises]) {
      mergedById.set(e.id, e);
    }

    // STEP D: 최신 등록순 정렬
    const exercises = Array.from(mergedById.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());

    return { bodySource, bodyMeasuredAt, inbodySource, inbodyMeasuredAt, exercises };
  }

  async getRecommendation(user: UserEntity): Promise<ExerciseRecommendationResponseDto> {
    const { bodySource, bodyMeasuredAt, inbodySource, inbodyMeasuredAt, exercises } =
      await this.buildRecommendationContext(user);

    return {
      bodySource,
      bodyMeasuredAt,
      inbodySource,
      inbodyMeasuredAt,
      items: exercises.map((e) => this.toItemDto(e)),
    };
  }

  /**
   * "나의 맞춤추천" 카테고리별 전체보기 - getRecommendation과 동일한 개인화 결과를 해당 카테고리만 페이지네이션으로 제공.
   * 운동 라이브러리 전체보기(GET /custom-exercises/library/:category)와 동일한 라우트 컨벤션.
   */
  async getRecommendationAllByCategory(
    user: UserEntity,
    category: ExerciseCategory,
    dto: FindExerciseRecommendationDto,
  ): Promise<IPageData<RecommendedExerciseItemDto>> {
    const { page = 1, limit = 10 } = dto;
    const { exercises } = await this.buildRecommendationContext(user);

    const filtered = exercises.filter((e) => e.category === category);
    const total = filtered.length;
    const paged = filtered.slice((page - 1) * limit, (page - 1) * limit + limit);

    return { items: paged.map((e) => this.toItemDto(e)), paging: buildPaging(total, limit, page) };
  }
}
