import { ApiProperty } from '@nestjs/swagger';

export enum RecommendationSource {
  /** 트레이너가 측정한 값 기준 */
  TRAINER = 'TRAINER',
  /** 트레이너 측정이 없어 회원 셀프측정 값 기준 */
  SELF = 'SELF',
  /** 트레이너/셀프측정 둘 다 없어 비개인화 랜덤 노출 */
  RANDOM = 'RANDOM',
}

export class RecommendedExerciseItemDto {
  @ApiProperty({ description: '운동 ID' })
  id!: string;

  @ApiProperty({ description: 'BODY_BALANCE | INBODY_DIET | LINE_DIET | FACE_CARE' })
  category!: string;

  @ApiProperty()
  mainCat!: string;

  @ApiProperty({ nullable: true })
  subCat!: string | null;

  @ApiProperty()
  detailCat!: string;

  @ApiProperty({ nullable: true })
  level!: string | null;

  @ApiProperty({ nullable: true })
  youtubeUrl!: string | null;

  @ApiProperty({ nullable: true, description: '영상 제목 (관리자 미보완 시 null)' })
  title!: string | null;

  @ApiProperty({ nullable: true, description: '썸네일 이미지 URL (관리자 미보완 시 null)' })
  thumbnailUrl!: string | null;

  @ApiProperty({ nullable: true, description: '영상 길이(초) (관리자 미보완 시 null)' })
  durationSeconds!: number | null;

  @ApiProperty({ description: 'NEW 뱃지 노출 여부' })
  isNew!: boolean;

  @ApiProperty()
  createdAt!: Date;
}

export class ExerciseRecommendationResponseDto {
  @ApiProperty({ enum: RecommendationSource, description: '체형측정값 결정 출처 (STEP A)' })
  bodySource!: RecommendationSource;

  @ApiProperty({ nullable: true, description: '체형측정값으로 채택된 측정 일시 (RANDOM이면 null)' })
  bodyMeasuredAt!: Date | null;

  @ApiProperty({ enum: RecommendationSource, description: '인바디값 결정 출처 (STEP B)' })
  inbodySource!: RecommendationSource;

  @ApiProperty({ nullable: true, description: '인바디값으로 채택된 측정 일시 (RANDOM이면 null)' })
  inbodyMeasuredAt!: Date | null;

  @ApiProperty({ description: '체형+인바디 믹스 후 최신 등록순 정렬된 추천 영상 (STEP C+D)', type: [RecommendedExerciseItemDto] })
  items!: RecommendedExerciseItemDto[];
}
