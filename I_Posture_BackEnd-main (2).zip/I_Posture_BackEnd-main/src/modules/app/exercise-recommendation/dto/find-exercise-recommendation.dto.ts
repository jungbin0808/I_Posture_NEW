import { PaginationDto } from '../../../../common/dto/pagination.dto';

export class FindExerciseRecommendationDto extends PaginationDto {}
