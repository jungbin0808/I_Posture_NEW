import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BodyReportEntity } from '../../../database/entities/body-report.entity';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { MemberIdentityLinkEntity } from '../../../database/entities/member-identity-link.entity';
import { CustomExerciseModule } from '../../custom-exercise/custom-exercise.module';
import { AppExerciseRecommendationController } from './app-exercise-recommendation.controller';
import { AppExerciseRecommendationService } from './app-exercise-recommendation.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BodyReportEntity,
      InbodyDataEntity,
      MemberIdentityLinkEntity,
    ]),
    CustomExerciseModule,
  ],
  controllers: [AppExerciseRecommendationController],
  providers: [AppExerciseRecommendationService],
  exports: [AppExerciseRecommendationService],
})
export class AppExerciseRecommendationModule {}
