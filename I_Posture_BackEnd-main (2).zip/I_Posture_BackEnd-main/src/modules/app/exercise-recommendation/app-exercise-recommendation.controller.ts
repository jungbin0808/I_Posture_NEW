import { BadRequestException, Controller, Get, Param, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AppExerciseRecommendationService } from './app-exercise-recommendation.service';
import { ExerciseRecommendationResponseDto, RecommendedExerciseItemDto } from './dto/exercise-recommendation-response.dto';
import { FindExerciseRecommendationDto } from './dto/find-exercise-recommendation.dto';
import { ExerciseCategory } from '../../custom-exercise/custom-exercise.service';

const EXERCISE_CATEGORIES: ExerciseCategory[] = ['BODY_BALANCE', 'INBODY_DIET', 'LINE_DIET', 'FACE_CARE'];

@ApiTags('App - Exercise Recommendation')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/exercise-recommendation')
export class AppExerciseRecommendationController {
  constructor(private readonly appExerciseRecommendationService: AppExerciseRecommendationService) {}

  @ApiOperation({ summary: '나의 맞춤 추천 운동영상 (체형측정+인바디 STEP A~D 로직)' })
  @Get('me')
  async getMine(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<ExerciseRecommendationResponseDto>> {
    const data = await this.appExerciseRecommendationService.getRecommendation(req.user);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '나의 맞춤 추천 운동영상 카테고리별 전체보기 (me와 동일 개인화 로직 + 페이지네이션)' })
  @Get('me/all/:category')
  async getMineAllByCategory(
    @Req() req: { user: UserEntity },
    @Param('category') category: string,
    @Query() findDto: FindExerciseRecommendationDto,
  ): Promise<IPageResponse<RecommendedExerciseItemDto>> {
    if (!EXERCISE_CATEGORIES.includes(category as ExerciseCategory)) {
      throw new BadRequestException(`category는 ${EXERCISE_CATEGORIES.join(' | ')} 중 하나여야 합니다.`);
    }
    const data = await this.appExerciseRecommendationService.getRecommendationAllByCategory(
      req.user,
      category as ExerciseCategory,
      findDto,
    );
    return SuccessResponse(data);
  }
}
