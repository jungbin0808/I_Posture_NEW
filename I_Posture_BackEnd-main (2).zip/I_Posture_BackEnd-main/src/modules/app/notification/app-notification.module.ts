import { Module } from '@nestjs/common';
import { AppNotificationController } from './app-notification.controller';

@Module({
  controllers: [AppNotificationController],
})
export class AppNotificationModule {}
