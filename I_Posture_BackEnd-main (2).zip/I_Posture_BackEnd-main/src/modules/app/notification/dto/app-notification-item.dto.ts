import { ApiProperty } from '@nestjs/swagger';
import { UserNotificationType } from '../../../../database/entities/user-notification.entity';

export class AppNotificationItemDto {
  @ApiProperty({ description: '알림 ID' })
  id!: string;

  @ApiProperty({ description: '알림 유형', enum: UserNotificationType })
  type!: UserNotificationType;

  @ApiProperty({ description: '알림 제목' })
  title!: string;

  @ApiProperty({ description: '알림 본문' })
  body!: string;

  @ApiProperty({ description: '읽음 여부' })
  isRead!: boolean;

  @ApiProperty({ description: '생성일시 (ISO8601)' })
  createdAt!: string;

  @ApiProperty({
    description: '딥링크용 추가 데이터 (알림 종류별 스키마는 docs/notification-push-data-spec.md 참고)',
    nullable: true,
    required: false,
  })
  data?: Record<string, string>;
}
