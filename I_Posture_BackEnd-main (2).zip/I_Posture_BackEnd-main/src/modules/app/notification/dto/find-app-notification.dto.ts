import { PaginationDto } from '../../../../common/dto/pagination.dto';

export class FindAppNotificationDto extends PaginationDto {}
