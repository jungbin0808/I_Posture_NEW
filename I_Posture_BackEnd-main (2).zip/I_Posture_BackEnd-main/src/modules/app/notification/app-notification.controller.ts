import { Controller, Get, Param, Patch, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse, IPageResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { UserNotificationService } from '../../notification/user-notification.service';
import { FindAppNotificationDto } from './dto/find-app-notification.dto';
import { AppNotificationItemDto } from './dto/app-notification-item.dto';

@ApiTags('App - Notification')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/notifications')
export class AppNotificationController {
  constructor(private readonly userNotificationService: UserNotificationService) {}

  @ApiOperation({ summary: '알림 목록 조회 (공지/이벤트/앱 알림 전체, 최신순)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() dto: FindAppNotificationDto,
  ): Promise<IPageResponse<AppNotificationItemDto>> {
    const pageData = await this.userNotificationService.findAllForUser(req.user.id, dto);
    return SuccessResponse({
      items: pageData.items.map((n) => this.userNotificationService.toListItem(n)),
      paging: pageData.paging,
    });
  }

  @ApiOperation({ summary: '안 읽은 알림 존재 여부 (알림 뱃지 표시용)' })
  @Get('has-unread')
  async hasUnread(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<{ hasUnread: boolean }>> {
    const hasUnread = await this.userNotificationService.hasUnread(req.user.id);
    return SuccessResponse({ hasUnread });
  }

  @ApiOperation({ summary: '알림 읽음 처리' })
  @Patch(':id/read')
  async markAsRead(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<AppNotificationItemDto>> {
    const notification = await this.userNotificationService.markAsRead(req.user.id, id);
    return SuccessResponse(this.userNotificationService.toListItem(notification));
  }
}
