import { Controller, Get, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse, IPageResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AppMeasurementService } from './app-measurement.service';
import { MeasurementSummaryResponseDto } from './dto/measurement-summary-response.dto';
import { MeasurementHistoryItemDto } from './dto/measurement-history-item.dto';
import { FindMeasurementHistoryDto } from './dto/find-measurement-history.dto';

@ApiTags('App - Measurement')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/measurement')
export class AppMeasurementController {
  constructor(private readonly appMeasurementService: AppMeasurementService) {}

  @ApiOperation({ summary: '측정 메인 - 최근 측정 요약 (종합체형점수 등, 트레이너/셀프 측정 통틀어 최신 1건)' })
  @Get('summary')
  async getSummary(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<MeasurementSummaryResponseDto>> {
    const data = await this.appMeasurementService.getSummary(req.user);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '측정 기록 목록 - 트레이너 측정 + 회원 셀프측정 통합, 최신/오래된순, 유형 필터' })
  @Get('history')
  async getHistory(
    @Req() req: { user: UserEntity },
    @Query() dto: FindMeasurementHistoryDto,
  ): Promise<IPageResponse<MeasurementHistoryItemDto>> {
    const pageData = await this.appMeasurementService.getHistory(req.user, dto);
    return SuccessResponse(pageData);
  }
}
