import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BodyReportEntity } from '../../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../../database/entities/precision-report.entity';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { MemberIdentityLinkEntity } from '../../../database/entities/member-identity-link.entity';
import { AppMeasurementController } from './app-measurement.controller';
import { AppMeasurementService } from './app-measurement.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BodyReportEntity,
      PrecisionReportEntity,
      InbodyDataEntity,
      MemberIdentityLinkEntity,
    ]),
  ],
  controllers: [AppMeasurementController],
  providers: [AppMeasurementService],
  exports: [AppMeasurementService],
})
export class AppMeasurementModule {}
