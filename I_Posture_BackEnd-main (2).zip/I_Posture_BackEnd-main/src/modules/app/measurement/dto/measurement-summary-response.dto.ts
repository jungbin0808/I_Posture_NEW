import { ApiProperty } from '@nestjs/swagger';

export class MeasurementSummaryResponseDto {
  @ApiProperty({ description: '측정 기록 존재 여부' })
  hasData!: boolean;

  @ApiProperty({ description: '종합체형점수', nullable: true })
  totalScore?: number;

  @ApiProperty({ description: '측정일시', nullable: true })
  measuredAt?: Date;

  @ApiProperty({ description: '거북목 각도(°)', nullable: true })
  neckScore?: number;

  @ApiProperty({ description: '어깨 비대칭 각도(°)', nullable: true })
  shoulderAsymmetryScore?: number;

  @ApiProperty({ description: '골반 비대칭 각도(°)', nullable: true })
  pelvisAsymmetryScore?: number;

  @ApiProperty({ description: '트레이너 측정 여부 (false면 회원 셀프측정)', nullable: true })
  isTrainerMeasured?: boolean;
}
