import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';

export enum MeasurementHistoryType {
  ALL = 'ALL',
  BODY = 'BODY',
  PRECISION = 'PRECISION',
  INBODY = 'INBODY',
}

export enum MeasurementHistorySort {
  LATEST = 'LATEST',
  OLDEST = 'OLDEST',
}

export class FindMeasurementHistoryDto extends PaginationDto {
  @ApiProperty({ enum: MeasurementHistoryType, required: false, description: '전체/체형측정/정밀 리포트/인바디' })
  @IsEnum(MeasurementHistoryType)
  @IsOptional()
  type: MeasurementHistoryType = MeasurementHistoryType.ALL;

  @ApiProperty({ enum: MeasurementHistorySort, required: false })
  @IsEnum(MeasurementHistorySort)
  @IsOptional()
  sort: MeasurementHistorySort = MeasurementHistorySort.LATEST;
}
