import { ApiProperty } from '@nestjs/swagger';
import { MEASUREMENT_TYPE } from '../../../../common/enums/measurement-type.enum';
import { MeasurementHistoryType } from './find-measurement-history.dto';

export class MeasurementHistoryItemDto {
  @ApiProperty({ description: '레코드 ID (body_reports/precision_reports/inbody_data 중 하나의 PK)' })
  id!: string;

  @ApiProperty({ enum: MeasurementHistoryType, description: 'BODY | PRECISION | INBODY' })
  type!: MeasurementHistoryType.BODY | MeasurementHistoryType.PRECISION | MeasurementHistoryType.INBODY;

  @ApiProperty({ description: '측정일시' })
  measuredAt!: Date;

  @ApiProperty({ description: '트레이너 측정 여부 (false면 회원 셀프측정)' })
  isTrainerMeasured!: boolean;

  @ApiProperty({ description: '종합체형점수 (type=BODY일 때만)', nullable: true })
  totalScore?: number;

  @ApiProperty({ description: '거북목 각도 (type=BODY일 때만)', nullable: true })
  neckScore?: number;

  @ApiProperty({ description: '어깨 비대칭 각도 (type=BODY일 때만)', nullable: true })
  shoulderAsymmetryScore?: number;

  @ApiProperty({ description: '골반 비대칭 각도 (type=BODY일 때만)', nullable: true })
  pelvisAsymmetryScore?: number;

  @ApiProperty({ enum: MEASUREMENT_TYPE, description: '정밀측정 부위 대분류 (예: NECK) - 여러 세부 동작이 이 값을 공유하므로 화면 표시는 precisionName 사용 (type=PRECISION일 때만)', nullable: true })
  precisionType?: MEASUREMENT_TYPE;

  @ApiProperty({ description: '정밀측정 세부 동작명 한글 (예: "목 오른쪽 가쪽굽힘", "왼쪽 엉덩관절 벌림") - OVERHEAD_SQUAT_TEST/BALANCE_TEST 등 동작 단위가 아닌 종합 검사류는 null (type=PRECISION일 때만)', nullable: true })
  precisionName?: string;

  @ApiProperty({ description: '가동범위 도달률 % (type=PRECISION일 때만)', nullable: true })
  precisionScore?: number;

  @ApiProperty({ description: 'BMI (type=INBODY일 때만)', nullable: true })
  bmi?: number;

  @ApiProperty({ description: '체지방률 % (type=INBODY일 때만)', nullable: true })
  percentBodyFat?: number;
}
