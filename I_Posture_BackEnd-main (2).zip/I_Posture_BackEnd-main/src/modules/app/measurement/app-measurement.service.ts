import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, Repository } from 'typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { BodyReportEntity } from '../../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../../database/entities/precision-report.entity';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../../database/entities/member-identity-link.entity';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { MeasurementSummaryResponseDto } from './dto/measurement-summary-response.dto';
import { MeasurementHistoryItemDto } from './dto/measurement-history-item.dto';
import { FindMeasurementHistoryDto, MeasurementHistoryType, MeasurementHistorySort } from './dto/find-measurement-history.dto';

interface OwnedRow {
  userId: string;
  trainerId?: string;
  deletedAt?: Date;
}

@Injectable()
export class AppMeasurementService {
  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
  ) {}

  /**
   * 앱 회원(A) ID → 트레이너가 관리하는 관리회원(C) ID. 트레이너 측정 기록은 전부 관리회원 기준으로 저장되므로
   * 본인 측정 기록(트레이너분 + 셀프분)을 함께 조회하려면 이 매핑을 먼저 거쳐야 함.
   */
  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.managedMemberId ?? null;
  }

  /**
   * 본인 소유 레코드 전부 조회 - 셀프측정(userId=앱회원 ID, trainerId 없음) + 트레이너 측정(userId=관리회원 ID, trainerId 있음)
   */
  private fetchOwnedRows<T extends OwnedRow>(
    repo: Repository<T>,
    appMemberId: string,
    managedMemberId: string | null,
  ): Promise<T[]> {
    // createQueryBuilder는 소프트 삭제 필터를 자동 적용하지 않으므로 명시적으로 걸어줘야 함
    // (find()/findOne()과 달리 QueryBuilder는 deletedAt을 자동으로 안 걸러줌 - 삭제한 기록이 다시 보이는 버그의 원인이었음)
    const query = repo.createQueryBuilder('r')
      .where('r.deletedAt IS NULL')
      .andWhere(
        new Brackets((qb) => {
          qb.where('r.userId = :appMemberId AND r.trainerId IS NULL', { appMemberId });
          if (managedMemberId) {
            qb.orWhere('r.userId = :managedMemberId AND r.trainerId IS NOT NULL', { managedMemberId });
          }
        }),
      );
    return query.getMany();
  }

  async getSummary(user: UserEntity): Promise<MeasurementSummaryResponseDto> {
    const managedMemberId = await this.resolveManagedMemberId(user.id);
    const rows = await this.fetchOwnedRows(this.bodyReportRepo, user.id, managedMemberId);

    if (rows.length === 0) {
      return { hasData: false };
    }

    const latest = rows.reduce((a, b) => (a.createdAt > b.createdAt ? a : b));

    return {
      hasData: true,
      totalScore: latest.totalScore,
      measuredAt: latest.createdAt,
      neckScore: latest.neckScore,
      shoulderAsymmetryScore: latest.shoulderAsymmetryScore,
      pelvisAsymmetryScore: latest.pelvisAsymmetryScore,
      isTrainerMeasured: !!latest.trainerId,
    };
  }

  async getHistory(user: UserEntity, dto: FindMeasurementHistoryDto): Promise<IPageData<MeasurementHistoryItemDto>> {
    const { type = MeasurementHistoryType.ALL, sort = MeasurementHistorySort.LATEST, page = 1, limit = 10 } = dto;
    const managedMemberId = await this.resolveManagedMemberId(user.id);

    const items: MeasurementHistoryItemDto[] = [];

    if (type === MeasurementHistoryType.ALL || type === MeasurementHistoryType.BODY) {
      const rows = await this.fetchOwnedRows(this.bodyReportRepo, user.id, managedMemberId);
      items.push(...rows.map((r) => ({
        id: r.id,
        type: MeasurementHistoryType.BODY as const,
        measuredAt: r.createdAt,
        isTrainerMeasured: !!r.trainerId,
        totalScore: r.totalScore,
        neckScore: r.neckScore,
        shoulderAsymmetryScore: r.shoulderAsymmetryScore,
        pelvisAsymmetryScore: r.pelvisAsymmetryScore,
      })));
    }

    if (type === MeasurementHistoryType.ALL || type === MeasurementHistoryType.PRECISION) {
      const rows = await this.fetchOwnedRows(this.precisionReportRepo, user.id, managedMemberId);
      items.push(...rows.map((r) => ({
        id: r.id,
        type: MeasurementHistoryType.PRECISION as const,
        measuredAt: r.createdAt,
        isTrainerMeasured: !!r.trainerId,
        precisionType: r.type,
        precisionName: r.name,
        precisionScore: r.score,
      })));
    }

    if (type === MeasurementHistoryType.ALL || type === MeasurementHistoryType.INBODY) {
      const rows = await this.fetchOwnedRows(this.inbodyDataRepo, user.id, managedMemberId);
      items.push(...rows.map((r) => ({
        id: r.id,
        type: MeasurementHistoryType.INBODY as const,
        measuredAt: r.measuredAt,
        isTrainerMeasured: !!r.trainerId,
        bmi: r.keyStats?.bmi,
        percentBodyFat: r.keyStats?.percentBodyFat,
      })));
    }

    items.sort((a, b) => (sort === MeasurementHistorySort.OLDEST
      ? a.measuredAt.getTime() - b.measuredAt.getTime()
      : b.measuredAt.getTime() - a.measuredAt.getTime()));

    const total = items.length;
    const paged = items.slice((page - 1) * limit, (page - 1) * limit + limit);

    return { items: paged, paging: buildPaging(total, limit, page) };
  }

  /**
   * 홈 화면 "체형측정 변화 그래프" - 종합체형점수(totalScore) 추이, 오래된순 최근 6건
   */
  async getBodyMeasurementTrend(user: UserEntity): Promise<{ hasData: boolean; points: Array<{ date: string; score: number }> }> {
    const managedMemberId = await this.resolveManagedMemberId(user.id);
    const rows = await this.fetchOwnedRows(this.bodyReportRepo, user.id, managedMemberId);

    if (rows.length === 0) return { hasData: false, points: [] };

    const points = rows
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime())
      .slice(-6)
      .map((r) => ({ date: r.createdAt.toISOString().slice(0, 10), score: r.totalScore }));

    return { hasData: true, points };
  }

  /**
   * 홈 화면 "인바디 체지방률 변화 그래프" - keyStats.percentBodyFat 추이, 오래된순 최근 6건
   */
  async getInbodyTrend(user: UserEntity): Promise<{ hasData: boolean; points: Array<{ date: string; score: number }> }> {
    const managedMemberId = await this.resolveManagedMemberId(user.id);
    const rows = await this.fetchOwnedRows(this.inbodyDataRepo, user.id, managedMemberId);
    const withFatData = rows.filter((r) => r.keyStats?.percentBodyFat != null);

    if (withFatData.length === 0) return { hasData: false, points: [] };

    const points = withFatData
      .sort((a, b) => a.measuredAt.getTime() - b.measuredAt.getTime())
      .slice(-6)
      .map((r) => ({ date: r.measuredAt.toISOString().slice(0, 10), score: r.keyStats!.percentBodyFat as number }));

    return { hasData: true, points };
  }

  /**
   * 홈 화면 "최근 리포트 보기" 버튼 활성화 여부 - 체형측정/정밀측정/인바디 중 하나라도 있으면 true
   */
  async hasAnyMeasurement(user: UserEntity): Promise<boolean> {
    const managedMemberId = await this.resolveManagedMemberId(user.id);
    const [bodyRows, precisionRows, inbodyRows] = await Promise.all([
      this.fetchOwnedRows(this.bodyReportRepo, user.id, managedMemberId),
      this.fetchOwnedRows(this.precisionReportRepo, user.id, managedMemberId),
      this.fetchOwnedRows(this.inbodyDataRepo, user.id, managedMemberId),
    ]);
    return bodyRows.length > 0 || precisionRows.length > 0 || inbodyRows.length > 0;
  }

  /**
   * 앱회원 기준 가장 최근 측정일(체형측정 or 인바디, 트레이너분+셀프분 통합). 측정 주기 알림 배치용 - 이 값이
   * "정확히 1개월 전"이면 그 이후 재측정이 없었다는 뜻이라 리마인더를 보냄
   */
  async getLatestMeasurementDate(appMemberId: string): Promise<Date | null> {
    const managedMemberId = await this.resolveManagedMemberId(appMemberId);
    const [bodyRows, inbodyRows] = await Promise.all([
      this.fetchOwnedRows(this.bodyReportRepo, appMemberId, managedMemberId),
      this.fetchOwnedRows(this.inbodyDataRepo, appMemberId, managedMemberId),
    ]);
    const dates = [...bodyRows.map((r) => r.createdAt), ...inbodyRows.map((r) => r.measuredAt)];
    if (dates.length === 0) return null;
    return dates.reduce((a, b) => (a > b ? a : b));
  }
}
