import { Injectable } from '@nestjs/common';
import { UserEntity } from '../../../database/entities/user.entity';
import { UserNotificationService } from '../../notification/user-notification.service';
import { QnaService } from '../../qna/qna.service';
import { QnaListSort } from '../../qna/dto/find-qna-list.dto';
import { AppMeasurementService } from '../measurement/app-measurement.service';
import { AppMypageService } from '../mypage/app-mypage.service';
import { AppExerciseRecommendationService } from '../exercise-recommendation/app-exercise-recommendation.service';
import { BannerService } from '../../banner/banner.service';
import { BannerPosition } from '../../../database/entities/banner.entity';
import { AppHomeResponseDto } from './dto/app-home-response.dto';

const QNA_PREVIEW_COUNT = 3;
const EXERCISE_PREVIEW_COUNT = 5;

@Injectable()
export class AppHomeService {
  constructor(
    private readonly userNotificationService: UserNotificationService,
    private readonly qnaService: QnaService,
    private readonly appMeasurementService: AppMeasurementService,
    private readonly appMypageService: AppMypageService,
    private readonly appExerciseRecommendationService: AppExerciseRecommendationService,
    private readonly bannerService: BannerService,
  ) {}

  async getHome(user: UserEntity): Promise<AppHomeResponseDto> {
    const [
      hasUnreadNotification,
      qnaPage,
      bodyMeasurementTrend,
      inbodyTrend,
      hasAnyMeasurement,
      trainerInfo,
      exerciseRecommendation,
      banners,
    ] = await Promise.all([
      this.userNotificationService.hasUnread(user.id),
      this.qnaService.findAll(
        { id: user.id } as UserEntity,
        { page: 1, limit: QNA_PREVIEW_COUNT, sort: QnaListSort.LATEST },
      ),
      this.appMeasurementService.getBodyMeasurementTrend(user),
      this.appMeasurementService.getInbodyTrend(user),
      this.appMeasurementService.hasAnyMeasurement(user),
      this.appMypageService.getTrainerInfo(user),
      this.appExerciseRecommendationService.getRecommendation(user),
      this.bannerService.findActiveByPosition(BannerPosition.HOME),
    ]);

    return {
      hasUnreadNotification,
      banners: banners.map((b) => ({ id: b.id, imageUrl: b.imageUrl, linkUrl: b.linkUrl })),
      bodyMeasurementTrend,
      inbodyTrend,
      trainerRecommendation: { isLinkedToTrainer: trainerInfo.isLinked, recommendedTrainers: [] },
      recentReportLinks: { hasAny: hasAnyMeasurement },
      qnaPreview: qnaPage.items.map((item) => ({
        id: item.id,
        title: item.title,
        authorName: item.authorName,
        answerCount: item.answerCount,
        viewCount: item.viewCount,
        createdAt: item.createdAt,
      })),
      exercisePreview: exerciseRecommendation.items.slice(0, EXERCISE_PREVIEW_COUNT),
    };
  }
}
