import { ApiProperty } from '@nestjs/swagger';

export class AppHomeQnaPreviewItemDto {
  @ApiProperty({ description: '질문 ID' })
  id!: string;

  @ApiProperty({ description: '질문 제목' })
  title!: string;

  @ApiProperty({ description: '작성자 이름' })
  authorName!: string;

  @ApiProperty({ description: '답변 수' })
  answerCount!: number;

  @ApiProperty({ description: '조회수' })
  viewCount!: number;

  @ApiProperty({ description: '작성일시' })
  createdAt!: Date;
}

class AppHomeBannerItemDto {
  @ApiProperty({ description: '배너 ID' })
  id!: string;

  @ApiProperty({ description: '배너 이미지 URL' })
  imageUrl!: string;

  @ApiProperty({ description: '탭 시 이동할 링크 URL', required: false, nullable: true })
  linkUrl?: string;
}

class MeasurementTrendDto {
  @ApiProperty({ description: '기록 존재 여부' })
  hasData!: boolean;

  @ApiProperty({ description: '날짜별 점수 추이 (오래된순, 최근 10건, 기록 없으면 빈 배열) — 체형측정은 totalScore, 인바디는 keyStats.percentBodyFat(체지방률)', type: [Object] })
  points!: Array<{ date: string; score: number }>;
}

class TrainerRecommendationDto {
  @ApiProperty({ description: '트레이너 연동 여부 (실 데이터, `GET /app/mypage/trainer`의 isLinked와 동일)' })
  isLinkedToTrainer!: boolean;

  @ApiProperty({ description: '이 달의 추천 센터/트레이너 — 추천 알고리즘·디렉토리 자체가 없는 완전 신규 기능이라 항상 빈 배열', type: [Object] })
  recommendedTrainers!: unknown[];
}

class RecentReportLinksDto {
  @ApiProperty({ description: '리포트 보유 여부 (실 데이터) — 체형측정/정밀측정/인바디 중 하나라도 있으면 true' })
  hasAny!: boolean;
}

export class AppHomeResponseDto {
  @ApiProperty({ description: '안 읽은 알림 존재 여부' })
  hasUnreadNotification!: boolean;

  @ApiProperty({ description: '배너 캐러셀 (실 데이터, SAC 배너 관리에서 등록)', type: [AppHomeBannerItemDto] })
  banners!: AppHomeBannerItemDto[];

  @ApiProperty({ description: '체형측정 변화 그래프' })
  bodyMeasurementTrend!: MeasurementTrendDto;

  @ApiProperty({ description: '인바디 체지방률 변화 그래프' })
  inbodyTrend!: MeasurementTrendDto;

  @ApiProperty({ description: '트레이너 연동/추천' })
  trainerRecommendation!: TrainerRecommendationDto;

  @ApiProperty({ description: '최근 리포트 보기 (버튼 3개 활성화 여부용)' })
  recentReportLinks!: RecentReportLinksDto;

  @ApiProperty({ description: '질의응답 미리보기 (최신 3건)', type: [AppHomeQnaPreviewItemDto] })
  qnaPreview!: AppHomeQnaPreviewItemDto[];

  @ApiProperty({ description: '추천 운동영상 미리보기 (실 데이터, 5그룹 "나의 맞춤 추천" 결과 최대 5건)', type: [Object] })
  exercisePreview!: unknown[];
}
