import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AppHomeService } from './app-home.service';
import { AppHomeResponseDto } from './dto/app-home-response.dto';

@ApiTags('App - Home')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/home')
export class AppHomeController {
  constructor(private readonly appHomeService: AppHomeService) {}

  @ApiOperation({ summary: '홈 화면 데이터 조회' })
  @Get()
  async getHome(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<AppHomeResponseDto>> {
    const data = await this.appHomeService.getHome(req.user);
    return SuccessResponse(data);
  }
}
