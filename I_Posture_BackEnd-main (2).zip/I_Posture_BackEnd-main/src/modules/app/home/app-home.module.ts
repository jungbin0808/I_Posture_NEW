import { Module } from '@nestjs/common';
import { QnaModule } from '../../qna/qna.module';
import { AppMeasurementModule } from '../measurement/app-measurement.module';
import { AppMypageModule } from '../mypage/app-mypage.module';
import { AppExerciseRecommendationModule } from '../exercise-recommendation/app-exercise-recommendation.module';
import { BannerModule } from '../../banner/banner.module';
import { AppHomeController } from './app-home.controller';
import { AppHomeService } from './app-home.service';

@Module({
  imports: [QnaModule, AppMeasurementModule, AppMypageModule, AppExerciseRecommendationModule, BannerModule],
  controllers: [AppHomeController],
  providers: [AppHomeService],
})
export class AppHomeModule {}
