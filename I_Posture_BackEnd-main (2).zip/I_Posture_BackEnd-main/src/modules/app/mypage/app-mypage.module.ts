import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { TrainerUserEntity } from '../../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity } from '../../../database/entities/member-identity-link.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../../database/entities/center.entity';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { CapacityModule } from '../../capacity/capacity.module';
import { AppMypageController } from './app-mypage.controller';
import { AppMypageService } from './app-mypage.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserEntity,
      TrainerUserEntity,
      MemberIdentityLinkEntity,
      CenterTrainerEntity,
      CenterEntity,
      SubscriptionEntity,
    ]),
    CapacityModule,
  ],
  controllers: [AppMypageController],
  providers: [AppMypageService],
  exports: [AppMypageService],
})
export class AppMypageModule {}
