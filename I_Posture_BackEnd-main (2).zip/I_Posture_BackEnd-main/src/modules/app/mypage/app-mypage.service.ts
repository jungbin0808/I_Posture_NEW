import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { UserEntity, UserType } from '../../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../../database/entities/member-identity-link.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../../database/entities/center.entity';
import { SubscriptionEntity, SubscriptionStatus } from '../../../database/entities/subscription.entity';
import { CapacityService } from '../../capacity/capacity.service';
import { MypageTrainerResponseDto } from './dto/mypage-trainer-response.dto';

const MS_PER_DAY = 24 * 60 * 60 * 1000;

@Injectable()
export class AppMypageService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    private readonly capacityService: CapacityService,
  ) {}

  async getTrainerInfo(user: UserEntity): Promise<MypageTrainerResponseDto> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId: user.id, status: IdentityLinkStatus.LINKED } });
    if (!link) {
      return { isLinked: false, history: [] };
    }
    const managedMemberId = link.managedMemberId;

    const relations = await this.trainerUserRepo.find({
      where: { memberId: managedMemberId },
      withDeleted: true,
      order: { createdAt: 'DESC' },
    });

    const trainerIds = [...new Set(relations.map((r) => r.trainerId))];
    const trainers = trainerIds.length > 0 ? await this.userRepo.find({ where: { id: In(trainerIds) } }) : [];
    const trainerMap = new Map(trainers.map((t) => [t.id, t]));

    const history = relations.map((relation) => ({
      trainerId: relation.trainerId,
      trainerName: trainerMap.get(relation.trainerId)?.name ?? '알 수 없음',
      linkedAt: relation.linkedAt ?? relation.createdAt,
      endedAt: relation.deletedAt,
      isCurrent: relation.status === TrainerUserStatus.ACTIVE && !relation.deletedAt,
    }));

    const activeRelation = relations.find((r) => r.status === TrainerUserStatus.ACTIVE && !r.deletedAt);
    if (!activeRelation) {
      return { isLinked: false, history };
    }

    const trainer = trainerMap.get(activeRelation.trainerId);
    const isCenterTrainer = trainer?.userType === UserType.C_TRAINER;

    let center: MypageTrainerResponseDto['center'];
    if (isCenterTrainer) {
      const centerTrainer = await this.centerTrainerRepo.findOne({
        where: { trainerId: activeRelation.trainerId, status: CenterTrainerStatus.WORKING },
      });
      if (centerTrainer) {
        const centerEntity = await this.centerRepo.findOne({ where: { id: centerTrainer.centerId } });
        if (centerEntity) {
          center = {
            name: centerEntity.name,
            logoUrl: centerEntity.logoUrl ?? undefined,
            description: centerEntity.description,
            address: centerEntity.address,
            phone: centerEntity.phone,
          };
        }
      }
    }

    const activeSubscription = await this.subscriptionRepo.findOne({
      where: { userId: managedMemberId, status: SubscriptionStatus.ACTIVE },
      relations: ['plan'],
    });

    let membership: MypageTrainerResponseDto['membership'];
    if (activeSubscription) {
      const capacity = await this.capacityService.getMemberCapacity(user);
      const dDay = activeSubscription.nextBillingDate
        ? Math.ceil((new Date(activeSubscription.nextBillingDate).getTime() - Date.now()) / MS_PER_DAY)
        : undefined;

      membership = {
        planName: activeSubscription.plan?.name ?? '',
        startDate: activeSubscription.createdAt.toISOString().split('T')[0],
        endDate: activeSubscription.nextBillingDate,
        dDay,
        isExpired: dDay != null && dDay < 0,
        totalCapacity: capacity.totalCapacity,
        usedCapacity: capacity.usedCapacity,
        usagePercentage: capacity.usagePercentage,
      };
    }

    // 앱 계정과 실제로 연동(본인 인증)된 시점 기준 - trainer_users(회원 등록/배정 시점)과는 다른 이벤트라 혼동 주의
    const linkedAt = link.createdAt;
    const daysSinceLinked = Math.floor((Date.now() - linkedAt.getTime()) / MS_PER_DAY);

    return {
      isLinked: true,
      trainerId: activeRelation.trainerId,
      trainerName: trainer?.name,
      isCenterTrainer,
      linkedAt,
      daysSinceLinked,
      center,
      membership,
      history,
    };
  }
}
