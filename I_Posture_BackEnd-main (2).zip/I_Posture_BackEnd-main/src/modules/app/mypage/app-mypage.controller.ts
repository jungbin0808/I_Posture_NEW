import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AppMypageService } from './app-mypage.service';
import { MypageTrainerResponseDto } from './dto/mypage-trainer-response.dto';

@ApiTags('App - Mypage')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Member)
@Controller('app/mypage')
export class AppMypageController {
  constructor(private readonly appMypageService: AppMypageService) {}

  @ApiOperation({ summary: '연동 트레이너 정보 조회 (마이페이지 메인 카드 + 연동 트레이너 상세 공용)' })
  @Get('trainer')
  async getTrainerInfo(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<MypageTrainerResponseDto>> {
    const data = await this.appMypageService.getTrainerInfo(req.user);
    return SuccessResponse(data);
  }
}
