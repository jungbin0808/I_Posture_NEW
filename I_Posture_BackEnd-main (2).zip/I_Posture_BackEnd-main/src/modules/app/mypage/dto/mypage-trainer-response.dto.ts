import { ApiProperty } from '@nestjs/swagger';

export class MypageCenterInfoDto {
  @ApiProperty({ description: '센터명' })
  name!: string;

  @ApiProperty({ description: '센터 로고/사진 URL', nullable: true })
  logoUrl?: string;

  @ApiProperty({ description: '센터 소개', nullable: true })
  description?: string;

  @ApiProperty({ description: '주소', nullable: true })
  address?: string;

  @ApiProperty({ description: '대표 연락처', nullable: true })
  phone?: string;
}

export class MypageMembershipDto {
  @ApiProperty({ description: '이용권(멤버십) 이름' })
  planName!: string;

  @ApiProperty({ description: '이용 시작일 (YYYY-MM-DD)' })
  startDate!: string;

  @ApiProperty({ description: '이용 종료일 (다음 결제일, YYYY-MM-DD)', nullable: true })
  endDate?: string;

  @ApiProperty({ description: '만료까지 남은 일수 (음수면 이미 만료)', nullable: true })
  dDay?: number;

  @ApiProperty({ description: '만료 여부' })
  isExpired!: boolean;

  @ApiProperty({ description: '총 용량 (Byte)' })
  totalCapacity!: string;

  @ApiProperty({ description: '사용 용량 (Byte)' })
  usedCapacity!: string;

  @ApiProperty({ description: '용량 사용률 (%)' })
  usagePercentage!: number;
}

export class MypageTrainerHistoryItemDto {
  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너 이름' })
  trainerName!: string;

  @ApiProperty({ description: '연동 시작일시' })
  linkedAt!: Date;

  @ApiProperty({ description: '연동 종료일시 (진행 중이면 null)', nullable: true })
  endedAt?: Date;

  @ApiProperty({ description: '현재 연동 중인 건인지 여부' })
  isCurrent!: boolean;
}

export class MypageTrainerResponseDto {
  @ApiProperty({ description: '현재 연동 중인 트레이너가 있는지 여부 (= 연동회원 여부)' })
  isLinked!: boolean;

  @ApiProperty({ description: '트레이너 ID', nullable: true })
  trainerId?: string;

  @ApiProperty({ description: '트레이너 이름', nullable: true })
  trainerName?: string;

  @ApiProperty({ description: '센터소속 트레이너 여부 (false면 개인 트레이너)', nullable: true })
  isCenterTrainer?: boolean;

  @ApiProperty({ description: '연동 시작일시', nullable: true })
  linkedAt?: Date;

  @ApiProperty({ description: '연동 시작 후 경과일수', nullable: true })
  daysSinceLinked?: number;

  @ApiProperty({ description: '센터소속 트레이너인 경우의 센터 정보', type: MypageCenterInfoDto, nullable: true })
  center?: MypageCenterInfoDto;

  @ApiProperty({ description: '현재 이용 중인 멤버십 정보 (활성 이용권이 없으면 null)', type: MypageMembershipDto, nullable: true })
  membership?: MypageMembershipDto;

  @ApiProperty({ description: '트레이너 연동 이력 (과거 + 현재, 최신순)', type: [MypageTrainerHistoryItemDto] })
  history!: MypageTrainerHistoryItemDto[];
}
