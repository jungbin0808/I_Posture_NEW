import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ExerciseCategoryEntity } from '../../database/entities/exercise-category.entity';
import { ExerciseEntity } from '../../database/entities/exercise.entity';

@Injectable()
export class ExerciseService {
  constructor(
    @InjectRepository(ExerciseCategoryEntity)
    private readonly categoryRepo: Repository<ExerciseCategoryEntity>,
    @InjectRepository(ExerciseEntity)
    private readonly exerciseRepo: Repository<ExerciseEntity>,
  ) {}

  /**
   * 모든 운동 카테고리를 조회합니다.
   */
  async findAllCategories(): Promise<ExerciseCategoryEntity[]> {
    return this.categoryRepo.find({
      order: {
        name: 'ASC',
      },
    });
  }

  /**
   * 특정 카테고리에 속한 모든 운동을 조회합니다.
   */
  async findExercisesByCategory(categoryId: string): Promise<ExerciseEntity[]> {
    const categoryExists = await this.categoryRepo.exist({ where: { id: categoryId } });
    if (!categoryExists) {
      throw new NotFoundException('해당 카테고리를 찾을 수 없습니다.');
    }

    return this.exerciseRepo.find({
      where: { categoryId },
      order: {
        name: 'ASC',
      },
    });
  }

  /**
   * 단일 운동의 상세 정보를 조회합니다.
   */
  async findOneExercise(id: string): Promise<ExerciseEntity> {
    const exercise = await this.exerciseRepo.findOne({ where: { id } });
    if (!exercise) {
      throw new NotFoundException('해당 운동을 찾을 수 없습니다.');
    }
    return exercise;
  }
}
