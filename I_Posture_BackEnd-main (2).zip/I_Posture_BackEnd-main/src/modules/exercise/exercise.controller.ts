import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ExerciseService } from './exercise.service';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { SuccessResponse } from '../../common/response/response.helper';
import { ApiOperation, ApiTags, ApiQuery } from '@nestjs/swagger';

@ApiTags('Exercises')
@Controller('exercises')
@UseGuards(AccessTokenGuard)
export class ExerciseController {
  constructor(private readonly exerciseService: ExerciseService) {}

  @ApiOperation({
    summary: '운동 카테고리 또는 운동 목록 조회',
    description: '`categoryId`가 없으면 카테고리 목록을, 있으면 해당 카테고리의 운동 목록을 반환합니다.',
  })
  @ApiQuery({ name: 'categoryId', required: false, description: '운동 목록을 조회할 카테고리 ID' })
  @Get()
  async find(@Query('categoryId') categoryId?: string) {
    if (categoryId) {
      const data = await this.exerciseService.findExercisesByCategory(categoryId);
      return SuccessResponse(data);
    } else {
      const data = await this.exerciseService.findAllCategories();
      return SuccessResponse(data);
    }
  }

  @ApiOperation({ summary: '단일 운동 상세 조회' })
  @Get(':id')
  async findOneExercise(@Param('id') id: string) {
    const data = await this.exerciseService.findOneExercise(id);
    return SuccessResponse(data);
  }
}
