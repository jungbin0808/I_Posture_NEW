import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, In } from 'typeorm';
import { ReportComparisonEntity, ComparisonReportType } from '../../database/entities/report-comparison.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { FileEntity, FileRelatedType } from '../../database/entities/file.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';
import { SPINAL_ALIGNMENT } from '../analysis/analysis.constants';
import { resolvePelvicReaction } from '../analysis/helpers/pelvic-reaction.helper';
import {
  estimateHorizontalPxPerCm,
  formatCenterShiftDistanceCm,
  formatCenterShiftMetricLabel,
} from '../analysis/helpers/spinal-alignment-display.helper';
import { MeasurementReportService } from '../measurement-report/measurement-report.service';
import { resolveCenterLogoUrl } from '../measurement-report/helpers/resolve-center-logo-url.helper';
import { rankBodyDiseases } from '../consultation-log/action-plan.helper';
import { BodyReportService } from '../body-report/body-report.service';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CreateReportComparisonDto } from './dto/create-report-comparison.dto';
import { FindReportComparisonDto } from './dto/find-report-comparison.dto';
import { ReportComparisonResponseDto, ReportComparisonDetailResponseDto } from './dto/report-comparison-response.dto';
import { RomComparisonDetailResponseDto } from './dto/rom-comparison-response.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';

@Injectable()
export class ReportComparisonService {
  constructor(
    @InjectRepository(ReportComparisonEntity)
    private readonly comparisonRepo: Repository<ReportComparisonEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(RomStandardEntity)
    private readonly romStandardRepo: Repository<RomStandardEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(MotionAnalysisEntity)
    private readonly motionAnalysisRepo: Repository<MotionAnalysisEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    private readonly measurementReportService: MeasurementReportService,
  ) {}

  private async resolveCenterLogoUrl(trainerId?: string | null): Promise<string | null> {
    return resolveCenterLogoUrl(trainerId, {
      centerRepo: this.centerRepo,
      centerTrainerRepo: this.centerTrainerRepo,
    });
  }

  private async resolvePrecisionComparisonTrainerId(comparison: ReportComparisonEntity): Promise<string | null> {
    const afterReport = await this.precisionReportRepo.findOne({
      where: { id: comparison.afterReportId },
      select: ['trainerId'],
    });
    if (afterReport?.trainerId) return afterReport.trainerId;

    const beforeReport = await this.precisionReportRepo.findOne({
      where: { id: comparison.beforeReportId },
      select: ['trainerId'],
    });
    return beforeReport?.trainerId ?? null;
  }

  /**
   * 비교 리포트 생성
   */
  async create(trainerId: string, memberId: string, dto: CreateReportComparisonDto): Promise<ReportComparisonEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 생성할 권한이 없습니다.');

    const { reportType, beforeReportId, afterReportId } = dto;
    let beforeScore = 0;
    let afterScore = 0;
    let summaryData: any = {};

    if (reportType === ComparisonReportType.BODY) {
      const beforeReport = await this.bodyReportRepo.findOne({ where: { id: beforeReportId, userId: memberId } });
      const afterReport = await this.bodyReportRepo.findOne({ where: { id: afterReportId, userId: memberId } });

      if (!beforeReport || !afterReport) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

      beforeScore = beforeReport.totalScore;
      afterScore = afterReport.totalScore;
      
      const diseases = afterReport.analysisData?.disease || [];
      const majorDiseases = rankBodyDiseases(diseases)
        .slice(0, 3)
        .map((d) => ({
          key: d.key,
          label: d.label,
        }));

      summaryData = {
        beforeDate: beforeReport.createdAt,
        afterDate: afterReport.createdAt,
        majorDiseases,
        centerOfWeight: {
          before: beforeReport.analysisData?.scoreDetail?.balanceIndex ?? null,
          after: afterReport.analysisData?.scoreDetail?.balanceIndex ?? null,
        },
      };

    } else if (reportType === ComparisonReportType.ROM) {
      const beforeReport = await this.precisionReportRepo.findOne({ where: { id: beforeReportId, userId: memberId } });
      const afterReport = await this.precisionReportRepo.findOne({ where: { id: afterReportId, userId: memberId } });

      if (!beforeReport || !afterReport) throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
      
      if (beforeReport.type !== afterReport.type || beforeReport.key !== afterReport.key) {
        throw new BadRequestException('같은 동작의 리포트만 비교할 수 있습니다.');
      }

      beforeScore = beforeReport.score;
      afterScore = afterReport.score;
      summaryData = {
        beforeDate: beforeReport.createdAt,
        afterDate: afterReport.createdAt,
        key: beforeReport.key,
        name: beforeReport.name,
        beforeLevel: beforeReport.level,
        afterLevel: afterReport.level,
        beforeComment: beforeReport.comment,
        afterComment: afterReport.comment,
      };
    } else if (reportType === ComparisonReportType.INBODY) {
      const beforeReport = await this.inbodyDataRepo.findOne({ where: { id: beforeReportId, userId: memberId } });
      const afterReport = await this.inbodyDataRepo.findOne({ where: { id: afterReportId, userId: memberId } });

      if (!beforeReport || !afterReport) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

      summaryData = {
        beforeDate: beforeReport.measuredAt,
        afterDate: afterReport.measuredAt,
        beforeWeight: beforeReport.keyStats?.weight,
        afterWeight: afterReport.keyStats?.weight,
        beforeBodyFatMass: beforeReport.keyStats?.bodyFatMass,
        afterBodyFatMass: afterReport.keyStats?.bodyFatMass,
        beforeSkeletalMuscleMass: beforeReport.keyStats?.skeletalMuscleMass,
        afterSkeletalMuscleMass: afterReport.keyStats?.skeletalMuscleMass,
      };
    } else if (reportType === ComparisonReportType.MOTION) {
      const beforeReport = await this.motionAnalysisRepo.findOne({ where: { id: beforeReportId, userId: memberId } });
      const afterReport = await this.motionAnalysisRepo.findOne({ where: { id: afterReportId, userId: memberId } });

      if (!beforeReport || !afterReport) throw new NotFoundException('모션 분석 데이터를 찾을 수 없습니다.');

      summaryData = {
        beforeDate: beforeReport.createdAt,
        afterDate: afterReport.createdAt,
        beforeTitle: beforeReport.title,
        afterTitle: afterReport.title,
        beforeComment: beforeReport.trainerComment ?? null,
        afterComment: afterReport.trainerComment ?? null,
      };
    } else if (
      reportType === ComparisonReportType.SPINE ||
      reportType === ComparisonReportType.BALANCE ||
      reportType === ComparisonReportType.FULL_BODY
    ) {
      const measurementTypeMap: Record<string, MEASUREMENT_TYPE> = {
        [ComparisonReportType.SPINE]: MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST,
        [ComparisonReportType.BALANCE]: MEASUREMENT_TYPE.BALANCE_TEST,
        [ComparisonReportType.FULL_BODY]: MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST,
      };
      const measurementType = measurementTypeMap[reportType];

      const beforeReport = await this.precisionReportRepo.findOne({ where: { id: beforeReportId, userId: memberId, type: measurementType } });
      const afterReport = await this.precisionReportRepo.findOne({ where: { id: afterReportId, userId: memberId, type: measurementType } });

      if (!beforeReport || !afterReport) throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');

      beforeScore = beforeReport.score;
      afterScore = afterReport.score;
      summaryData = {
        beforeDate: beforeReport.createdAt,
        afterDate: afterReport.createdAt,
        beforeLevel: beforeReport.level,
        afterLevel: afterReport.level,
        beforeComment: beforeReport.comment,
        afterComment: afterReport.comment,
      };
    }

    const afterMeasuredAt = summaryData?.afterDate ? new Date(summaryData.afterDate) : undefined;

    const comparison = this.comparisonRepo.create({
      userId: memberId,
      reportType,
      beforeReportId,
      afterReportId,
      beforeScore,
      afterScore,
      summaryData,
      afterMeasuredAt,
    });

    return this.comparisonRepo.save(comparison);
  }

  /**
   * 회원의 비교 리포트 목록 조회
   */
  async findAllByMemberId(trainerId: string, memberId: string, dto: FindReportComparisonDto): Promise<IPageData<ReportComparisonResponseDto>> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const { page = 1, limit = 10, startDate, endDate, reportType, sort } = dto;

    const where: any = { userId: memberId };
    if (reportType) where.reportType = reportType;

    const query = this.comparisonRepo.createQueryBuilder('comp')
      .where('comp.userId = :userId', { userId: memberId });

    if (reportType) query.andWhere('comp.reportType = :reportType', { reportType });
    if (startDate) query.andWhere('comp.createdAt >= :startDate', { startDate });
    if (endDate) query.andWhere('comp.createdAt <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('COALESCE(comp.afterMeasuredAt, comp.createdAt)', sortDirection);

    const total = await query.getCount();
    const items = await query.offset((page - 1) * limit).limit(limit).getMany();

    const dtos = items.map(item => ({
      id: item.id,
      reportType: item.reportType,
      beforeReportId: item.beforeReportId,
      afterReportId: item.afterReportId,
      beforeScore: item.beforeScore,
      afterScore: item.afterScore,
      beforeDate: item.summaryData?.beforeDate,
      afterDate: item.summaryData?.afterDate,
      summaryData: item.summaryData,
      trainerComment: item.trainerComment,
      createdAt: item.createdAt,
    }));

    return { items: dtos, paging: buildPaging(total, limit, page) };
  }

  /**
   * 일반(BODY) 비교 리포트 상세 조회
   */
  async findOneBody(trainerId: string, memberId: string, id: string): Promise<ReportComparisonDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.BODY } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const dto = new ReportComparisonDetailResponseDto();
    Object.assign(dto, comparison);
    dto.beforeDate = comparison.summaryData?.beforeDate;
    dto.afterDate = comparison.summaryData?.afterDate;

    const beforeReport = await this.bodyReportRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.bodyReportRepo.findOne({ where: { id: comparison.afterReportId } });
    
    if (beforeReport && afterReport) {
      const beforeFiles = await this.fileRepo.find({ where: { relatedId: beforeReport.id } });
      const afterFiles = await this.fileRepo.find({ where: { relatedId: afterReport.id } });

      const extractSummary = (report: BodyReportEntity, files: FileEntity[]) => {
        const diseases = report.analysisData?.disease || [];
        const majorDiseases = rankBodyDiseases(diseases)
          .slice(0, 3)
          .map((d) => ({ key: d.key, label: d.label }));

        const bodyPartScores = BodyReportService.calculateBodyPartScores(report.analysisData);

        return {
          totalScore: report.totalScore,
          balance: report.analysisData?.scoreDetail?.balanceIndex,
          majorDiseases,
          bodyPartScores,
          files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, division: f.division })),
          landmarks: report.analysisData?.landmarks,
          previewSize: { width: report.analysisData?.previewWidth, height: report.analysisData?.previewHeight },
        };
      };

      dto.bodyComparison = {
        before: extractSummary(beforeReport, beforeFiles),
        after: extractSummary(afterReport, afterFiles),
      };
    }

    return dto;
  }

  /**
   * 정밀(ROM) 비교 리포트 상세 조회
   */
  async findOneRom(trainerId: string, memberId: string, id: string): Promise<RomComparisonDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.ROM } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const dto = new RomComparisonDetailResponseDto();
    Object.assign(dto, comparison);
    dto.beforeDate = comparison.summaryData?.beforeDate;
    dto.afterDate = comparison.summaryData?.afterDate;

    const beforeReport = await this.precisionReportRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.precisionReportRepo.findOne({ where: { id: comparison.afterReportId } });

    if (beforeReport && afterReport) {
      if (!dto.summaryData) dto.summaryData = {};
      if (!dto.summaryData.beforeComment) dto.summaryData.beforeComment = beforeReport.comment;
      if (!dto.summaryData.afterComment) dto.summaryData.afterComment = afterReport.comment;

      const beforeFiles = await this.fileRepo.find({ where: { relatedId: beforeReport.id } });
      const afterFiles = await this.fileRepo.find({ where: { relatedId: afterReport.id } });

      let romStandard: RomStandardEntity | null = null;
      if (beforeReport.key) {
          const allStandards = await this.romStandardRepo.find({
              relations: ['sensations', 'movementPatterns', 'habits']
          });
          romStandard = allStandards.find(s => s.reportNameEn.replace(/\s/g, '') === beforeReport.key) || null;
      }

      const extractAngle = (report: PrecisionReportEntity) => {
        let angle = '';
        const resultValues = Object.values(report.analysisData?.result || {}) as any[];
        const targetResult = resultValues.find(r => r && r.result);
        if (targetResult && targetResult.result) {
            let angleStr = targetResult.result;
            try {
                const jsonResult = JSON.parse(angleStr);
                if (jsonResult.angle) angleStr = jsonResult.angle;
                else if (jsonResult.distance) angleStr = jsonResult.distance;
            } catch (e) {}
            angle = String(angleStr);
        }
        return angle;
      };

      const extractLandmarks = (report: PrecisionReportEntity) => {
          if (!report.analysisData) return null;
          if (report.key && report.analysisData[report.key]) {
              return report.analysisData[report.key].steps || report.analysisData[report.key];
          }
          if (report.analysisData.landmarks) {
              return report.analysisData.landmarks;
          }
          if (report.analysisData.steps) {
              return report.analysisData.steps;
          }
          const keys = Object.keys(report.analysisData);
          for (const k of keys) {
              if (report.analysisData[k]?.steps) {
                  return report.analysisData[k].steps;
              }
          }
          return null;
      };

      const extractSummary = (report: PrecisionReportEntity, files: FileEntity[]) => ({
        score: report.score,
        level: report.level || 'NORMAL',
        angle: extractAngle(report),
        files: files.map(f => ({
          id: f.id,
          fileUrl: f.fileUrl,
          division: f.division,
        })),
        landmarks: extractLandmarks(report),
        previewSize: {
            width: report.analysisData?.previewWidth,
            height: report.analysisData?.previewHeight,
        },
      });

      dto.romComparison = {
        key: beforeReport.key || '',
        name: beforeReport.name || '',
        normalDeg: romStandard?.normalDeg || 0,
        before: extractSummary(beforeReport, beforeFiles),
        after: extractSummary(afterReport, afterFiles),
        detailInfo: {
          sensations: romStandard?.sensations.map(s => ({
              content: s.sensationContent
          })) || [],
          movementPatterns: romStandard?.movementPatterns.map(p => ({
              content: p.patternContent,
              imageNo: p.imageNo,
              dailyExample: p.dailyExample
          })) || [],
          habits: romStandard?.habits.map(h => ({
              content: h.habitContent,
              imageNo: h.imageNo
          })) || [],
        },
      };
    }

    return dto;
  }

  /**
   * 모션 비교 리포트 상세 조회
   */
  async findOneMotion(trainerId: string, memberId: string, id: string) {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.MOTION } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const beforeAnalysis = await this.motionAnalysisRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterAnalysis = await this.motionAnalysisRepo.findOne({ where: { id: comparison.afterReportId } });

    const flattenMotion = async (analysis: MotionAnalysisEntity | null) => {
      if (!analysis) return null;
      const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.MOTION, relatedId: analysis.id } });
      return {
        motionId: analysis.id,
        createdAt: analysis.createdAt,
        title: analysis.title,
        memo: analysis.memo,
        trainerComment: analysis.trainerComment ?? null,
        files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl })),
      };
    };

    return {
      id: comparison.id,
      trainerComment: comparison.trainerComment,
      createdAt: comparison.createdAt,
      before: await flattenMotion(beforeAnalysis),
      after: await flattenMotion(afterAnalysis),
    };
  }

  /**
   * 인바디 비교 리포트 상세 조회
   */
  async findOneInbody(trainerId: string, memberId: string, id: string) {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.INBODY } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const beforeReport = await this.inbodyDataRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.inbodyDataRepo.findOne({ where: { id: comparison.afterReportId } });

    const flattenInbody = (report: InbodyDataEntity | null) => {
      if (!report) return null;
      return {
        inbodyId: report.id,
        measuredAt: report.measuredAt,
        weight: report.keyStats?.weight,
        skeletalMuscleMass: report.keyStats?.skeletalMuscleMass,
        bodyFatMass: report.keyStats?.bodyFatMass,
        bmi: report.keyStats?.bmi,
        percentBodyFat: report.keyStats?.percentBodyFat,
        abdominalFatRatio: report.keyStats?.abdominalFatRatio,
        visceralFatLevel: report.keyStats?.visceralFatLevel,
        basalMetabolicRate: report.keyStats?.basalMetabolicRate,
        bodyWater: report.detailData?.bodyWater,
        protein: report.detailData?.protein,
        minerals: report.detailData?.minerals,
        idealWeight: report.detailData?.idealWeight,
        weightControl: report.detailData?.weightControl,
        fatControl: report.detailData?.fatControl,
        muscleControl: report.detailData?.muscleControl,
        bmiEvaluation: report.detailData?.bmiEvaluation,
        bodyFatEvaluation: report.detailData?.bodyFatEvaluation,
        inbodyImageUrl: report.detailData?.inbodyImageUrl,
      };
    };

    return {
      id: comparison.id,
      trainerComment: comparison.trainerComment,
      createdAt: comparison.createdAt,
      before: flattenInbody(beforeReport),
      after: flattenInbody(afterReport),
    };
  }

  // ─── 척추/균형/전신 공통 precision 비교 헬퍼 ────────────────────────────

  private buildSpineObservationSummary(report: PrecisionReportEntity, files: FileEntity[]) {
    const SPINAL_IMG_BASE = 'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/spinal-alignment';
    const scoreDetail = report.analysisData?.scoreDetail || {};

    const spinalTilt = (() => {
      if (scoreDetail.centerShoulderHip) {
        const raw = scoreDetail.centerShoulderHip;
        const disease = Math.abs(raw.result) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX ? 'NORMAL'
          : raw.result > 0 ? 'SPINE_TILTED_RIGHT' : 'SPINE_TILTED_LEFT';
        return { ...raw, disease };
      }
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftShoulder || !back?.RightShoulder || !back?.LeftHip || !back?.RightHip) return undefined;
      const centerShoulderX = (back.LeftShoulder.x + back.RightShoulder.x) / 2;
      const centerHipX = (back.LeftHip.x + back.RightHip.x) / 2;
      const result = centerShoulderX - centerHipX;
      const disease = Math.abs(result) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX ? 'NORMAL'
        : result > 0 ? 'SPINE_TILTED_RIGHT' : 'SPINE_TILTED_LEFT';
      return { result, score: 0, disease };
    })();

    const shoulderAlignment = (() => {
      if (scoreDetail.higherShoulder) return scoreDetail.higherShoulder;
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftShoulder || !back?.RightShoulder) return undefined;
      const result = back.LeftShoulder.y - back.RightShoulder.y;
      const disease = Math.abs(result) <= 10 ? 'NORMAL'
        : back.RightShoulder.y < back.LeftShoulder.y ? 'SPINE_CURVED_RIGHT' : 'SPINE_CURVED_LEFT';
      return { result, score: 0, disease };
    })();

    const pelvicReaction = resolvePelvicReaction(
      scoreDetail.pelvicReaction,
      report.analysisData?.landmarks?.back,
    );

    // illustration URL
    const tilt = spinalTilt?.disease ?? 'NORMAL';
    const shoulder = shoulderAlignment?.disease ?? 'NORMAL';
    const FILE_MAP: Record<string, string> = {
      'NORMAL|NORMAL': 'spine_normal.png',
      
      // 1. 중심축만 이동한 경우 (Tilted)
      'SPINE_TILTED_LEFT|NORMAL': 'spine_straight_tilted_left.png',
      'SPINE_TILTED_RIGHT|NORMAL': 'spine_straight_but_tilted_right.png',
      
      // 2. 등 높이(척추 라인)만 차이 나는 경우 (Curved)
      'NORMAL|SPINE_CURVED_LEFT': 'spine_curved_left.png',
      'NORMAL|SPINE_CURVED_RIGHT': 'spine_curved_right.png',
      
      // 3. 복합적인 경우
      'SPINE_TILTED_LEFT|SPINE_CURVED_LEFT': 'spine_curved_left_tilted_left.png',
      'SPINE_TILTED_RIGHT|SPINE_CURVED_RIGHT': 'spine_curved_right_tilted_right.png',
      'SPINE_TILTED_LEFT|SPINE_CURVED_RIGHT': 'spine_curved_right_tilted_left.png',
      'SPINE_TILTED_RIGHT|SPINE_CURVED_LEFT': 'spine_curved_left_tilted_right.png',
    };
    const illustrationUrl = `${SPINAL_IMG_BASE}/${FILE_MAP[`${tilt}|${shoulder}`] ?? 'spine_normal.png'}`;

    // photo URL (BACK division)
    const photoFile = files.find(f => f.division === 'BACK');
    const photoUrl = photoFile?.fileUrl ?? null;

    const backLandmarks = report.analysisData?.landmarks?.back;
    const centerShiftPxPerCm = estimateHorizontalPxPerCm(backLandmarks, {
      heightCm: report.user?.height != null ? Number(report.user.height) : undefined,
      previewHeight: report.analysisData?.previewHeight,
    });

    // metrics
    const metrics = [
      {
        label: '상체 중심 이동 경향',
        value: formatCenterShiftMetricLabel(spinalTilt, centerShiftPxPerCm),
      },
      {
        label: '숙일 때\n골반 반응 유형',
        value: !pelvicReaction ? '데이터 없음'
          : pelvicReaction.isNormal ? '좌우 평행'
          : pelvicReaction.higherSide === '왼쪽'
            ? `왼쪽 ${Math.round(Math.abs(pelvicReaction.result ?? 0))}° ↑ (오른쪽 대비)`
            : `오른쪽 ${Math.round(Math.abs(pelvicReaction.result ?? 0))}° ↑ (왼쪽 대비)`,
      },
      {
        label: '척추 라인방향',
        value: !shoulderAlignment ? '데이터 없음'
          : shoulderAlignment.disease === 'NORMAL' ? '중앙 정렬 유지'
          : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽 경향' : '왼쪽 경향',
      },
      {
        label: '숙일 때 등 높이 차이',
        value: !shoulderAlignment ? '데이터 없음'
          : shoulderAlignment.disease === 'NORMAL' ? '대칭 유지'
          : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT'
            ? `오른쪽 ↑ (왼쪽 대비)`
            : `왼쪽 ↑ (오른쪽 대비)`,
      },
    ];

    // analysis text
    const centerNormal = !spinalTilt || Math.abs(spinalTilt?.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX;
    const centerDir = centerNormal ? '수직' : spinalTilt.disease === 'SPINE_TILTED_RIGHT' ? '오른쪽' : '왼쪽';
    const centerDist = formatCenterShiftDistanceCm(spinalTilt?.result ?? 0, centerShiftPxPerCm);
    const line1 = centerNormal
      ? `골반 중심선 대비 몸통이 <b>수직으로 정렬된</b> 상태를 보이며 상체 무게중심의 <b>안정성</b>이 있을 가능성이 높으며`
      : `골반 중심선 대비 몸통이 <b>${centerDist}</b>cm만큼 <b>${centerDir}으로 이동한</b> 상태를 보이며 상체 무게중심의 <b>치우침</b>이 있을 가능성이 높으며`;
    const pelvicNormal = !pelvicReaction || pelvicReaction.isNormal;
    const pelvicAngle = Math.abs(pelvicReaction?.result ?? 0).toFixed(0);
    const line2 = pelvicNormal
      ? `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>좌우</b> 골반이 <b>평행한</b> 경향이 관찰되었습니다.`
      : `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>${pelvicReaction.higherSide}</b> 골반이 반대측보다 <b>높아진</b> 경향이 관찰되었습니다.`;
    const shoulderNormal = !shoulderAlignment || shoulderAlignment.disease === 'NORMAL';
    const spineDir = shoulderNormal ? '수직' : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';
    const spineStress = spineDir === '수직' ? '균형적인 부하 전달' : '비대칭적인 자극';
    const line3 = `동시에 척추 배열이 <b>${spineDir}</b> 방향의 흐름을 보여, 움직임 시 <b>${spineStress}</b>이 전달될 수 있고,`;
    const backSide = shoulderNormal ? '양쪽 대칭' : spineDir;
    const backAngle = Math.abs(shoulderAlignment?.result ?? 0).toFixed(0);
    const backState1 = shoulderNormal ? '균형을 유지하는 양상이' : '더 높게 솟아오르는 양상이';
    const backState2 = shoulderNormal ? '안정적인 중립 정렬이' : '척추의 입체적인 정렬 변화가';
    const line4 = shoulderNormal
      ? `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`
      : `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`;
    const analysis = [line1, line2, line3, line4].join('\n');

    // result text
    const hasTorso    = !!(spinalTilt && spinalTilt.disease !== 'NORMAL');
    const hasPelvic   = !!(pelvicReaction && !pelvicReaction.isNormal);
    const hasShoulder = !!(shoulderAlignment && shoulderAlignment.disease !== 'NORMAL');
    const count = [hasTorso, hasPelvic, hasShoulder].filter(Boolean).length;

    let result: string;
    if (count === 0) {
      result = '현재 외형적으로는 전반적인 신체 축이 수직으로 견고하게 정렬된 양상을 보이며, 하중 분산 능력이 매우 안정적일 가능성이 높게 분석됩니다.'
        + '다만, 이러한 정적 정렬이 실제 움직임이나 생활 습관 속에서도 유지되고 있는지 확인이 필요합니다.'
        + ' 이어지는 리포트를 통해, 보이지 않는 곳에서 정렬을 위협하는 미세한 습관이 있는지 점검하여 현재의 완벽한 균형을 유지하시길 권장합니다.';
    } else if (count === 1) {
      if (hasTorso) {
        result = '골반 중심축을 기준으로 상체가 한쪽으로 밀려 있는 양상을 보이며, 이는 서 있거나 움직일 때 체중이 특정 측면에만 과하게 실리고 있을 가능성을 시사합니다.'
          + '척추의 직접적인 회전은 적으나 중심축 자체가 쏠려 있어, 특정 관절에만 누적 스트레스가 쌓이기 쉬운 경향을 보입니다.';
      } else if (hasPelvic) {
        result = '상체를 숙였을 때 양쪽 골반의 수평 정렬이 어긋나는 양상이 확인되며, 이는 골반을 지지하는 하체 근육의 길이가 서로 다르거나 기능적 비대칭이 있을 가능성이 분석됩니다.'
          + '골반의 수평이 맞지 않으면 척추의 뿌리가 흔들리는 것과 같아 추후 허리 주변의 불편함으로 전이될 경향이 있습니다.';
      } else {
        result = '숙인 자세에서 한쪽 등이 반대측보다 솟아오르는 양상을 보이며, 이는 단순히 어깨가 높은 것이 아니라 척추가 입체적으로 회전하며 구조적인 정렬 변화를 동반했을 가능성을 보여줍니다.'
          + '척추의 회전은 호흡 효율을 떨어뜨리고 한쪽 근육만 쉽게 뭉치게 만드는 경향이 있어 주의가 필요합니다.';
      }
    } else if (count === 2) {
      if (hasTorso && hasPelvic) {
        result = '골반의 수평이 어긋나면서 그 위의 상체 중심축까지 한쪽으로 밀려 있는 양상이 확인되며, 이는 신체 하부의 불안정이 상체의 위치 변화를 유도했을 가능성이 높게 분석됩니다.'
          + '무게중심이 한쪽으로 쏠린 상태가 지속되면 엉덩관절과 허리 관절에 비대칭적인 하중이 가해질 경향이 있습니다.';
      } else if (hasPelvic && hasShoulder) {
        result = '숙인 자세에서 골반의 수평이 맞지 않음과 동시에 등의 높낮이 차이가 관찰되는 것은, 골반의 기울기가 척추의 입체적인 회전 변화로까지 이어졌을 가능성을 시사합니다.'
          + ' 척추의 뿌리인 골반부터 상부 흐름까지 전반적인 정렬 양상이 변해 있을 경향이 있어 주의가 필요합니다.';
      } else {
        result = '척추가 입체적으로 회전하며 등이 솟아오른 양상과 함께 상체 무게중심이 정중선을 벗어난 흐름이 확인되어, 상부의 정렬 변화가 전체적인 체중 분포에 영향을 주고 있을 가능성이 분석됩니다.'
          + '이러한 경향은 일상 움직임 시 특정 방향의 근육과 관절에만 과도한 긴장을 유발할 수 있습니다.';
      }
    } else {
      result = '골반 수평과 상체 중심축, 등 높이 모두에서 정렬 변화가 포착되어 신체 하부의 불안정이 상부로 전이되었을 가능성이 높게 분석됩니다.'
        + ' 이러한 전신 비대칭 양상은 관절 스트레스를 누적시킬 경향이 있으므로, 전문 트레이너를 통해 정확한 원인을 파악하고 개인별 정렬 최적화 트레이닝을 시작할 것을 강력히 권장합니다.';
    }

    return {
      images: {
        photo: { assetKey: 'SPINE_FRONT_PHOTO', url: photoUrl },
        illustration: { assetKey: 'SPINE_FRONT_ILLUSTRATION', url: illustrationUrl },
      },
      metrics,
      tooltips: {
        guide: '숙일 때 골반 반응 유형 (좌우 비교)',
        points: [
          {
            part: '엉덩이',
            left:  !pelvicReaction || pelvicReaction.isNormal ? 0
              : pelvicReaction.higherSide === '왼쪽'  ? +Math.round(Math.abs(pelvicReaction.result ?? 0))
              : -Math.round(Math.abs(pelvicReaction.result ?? 0)),
            right: !pelvicReaction || pelvicReaction.isNormal ? 0
              : pelvicReaction.higherSide === '오른쪽' ? +Math.round(Math.abs(pelvicReaction.result ?? 0))
              : -Math.round(Math.abs(pelvicReaction.result ?? 0)),
          },
        ],
      },
      analysis,
      result,
    };
  }

  private buildBalanceTotalScore(score: number) {
    const s = Math.max(0, Math.min(10, Math.round(score / 10)));
    let stage: string, summaryTitle: string, meaning: string, balanceControlFeature: string, dailyLifeConnection: string, bottomMessage: string;
    if (s >= 10) {
      stage = '안정'; summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>안정</b> 단계에 해당합니다.';
      meaning = '신경계·근육·관절이 매우 효율적으로 협응되는 상태';
      balanceControlFeature = '한 다리 지지 상황에서도 전신이 하나의 단위처럼 안정적으로 작동하며, 균형 유지를 위해 과도한 노력이나 보상이 거의 필요하지 않은 상태입니다.';
      dailyLifeConnection = '다양한 일상 동작에서도 안정감이 높고, 움직임이 부드러우며 여유가 느껴지는 상태입니다.';
      bottomMessage = '전반적인 균형 조절 능력이 매우 우수하며, 고난도 운동이나 복합 동작으로 확장하기에 적합한 단계입니다.';
    } else if (s >= 8) {
      stage = '기능적 안정'; summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>기능적 안정</b> 단계에 해당합니다.';
      meaning = '일상 및 운동 수행에 충분한 균형 조절 능력 보유';
      balanceControlFeature = '균형 유지는 가능하지만, 상황이나 피로도에 따라 균형을 유지하기 위한 추가적인 조절이 요구되는 경우가 있는 상태입니다.';
      dailyLifeConnection = '일상생활에서는 큰 불편이 없으나, 빠른 움직임이나 불안정한 환경에서는 흔들림이 나타날 수 있는 상태입니다.';
      bottomMessage = '기본적인 균형 능력은 확보되어 있으며, 안정성을 유지한 상태에서 움직임을 강화하는 훈련이 필요한 단계입니다.';
    } else if (s >= 6) {
      stage = '보상적 안정'; summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>보상적 안정</b> 단계에 해당합니다.';
      meaning = '균형을 유지하지만 다른 부위의 보상으로 버티는 상태';
      balanceControlFeature = '균형 자체는 유지되지만, 몸의 일부를 더 많이 사용해 버티는 경향이 나타나며 전신 협응 효율이 떨어지는 상태입니다.';
      dailyLifeConnection = '오래 서 있거나 한쪽 다리를 사용하는 상황에서 피로가 빨리 쌓이고 불편감이 생기기 쉬운 상태입니다.';
      bottomMessage = '현재는 효율적인 균형 전략이 부족하므로, 불필요한 보상을 줄이고 균형 조절 능력을 개선하는 훈련이 필요한 단계입니다.';
    } else if (s >= 4) {
      stage = '불안정'; summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>불안정</b> 단계에 해당합니다.';
      meaning = '신경-근육 조절 능력이 충분히 작동하지 않는 상태';
      balanceControlFeature = '한 다리 지지 상황에서 균형을 유지하기 위한 조절이 지속적으로 필요하며, 안정적인 패턴을 유지하기 어려운 상태입니다.';
      dailyLifeConnection = '일상 동작에서도 불안정함을 느끼기 쉽고, 특정 상황에서는 넘어질 위험이 커질 수 있는 상태입니다.';
      bottomMessage = '현재는 근력보다 기초적인 균형 조절 능력을 우선적으로 향상시키는 접근이 필요한 단계입니다.';
    } else {
      stage = '조절상실'; summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>조절상실</b> 단계에 해당합니다.';
      meaning = '균형을 능동적으로 조절하지 못하는 상태';
      balanceControlFeature = '균형 조절 전략이 충분히 형성되지 않아 한 다리 지지 상태를 유지하는 것 자체가 어려운 상태입니다.';
      dailyLifeConnection = '일상생활에서도 불안정성이 높아 안전에 대한 관리가 특히 중요한 상태입니다.';
      bottomMessage = '안전을 최우선으로 고려하여 매우 기초적인 균형 조절 능력부터 단계적으로 접근해야 하는 단계입니다.';
    }
    return {
      scoreText: `BALANCE SCORE : ${s}/10 (${stage})`,
      score: s,
      scoreMax: 10,
      stage,
      levelGuide: [
        { label: '조절상실', color: 'red' },
        { label: '불안정', color: 'orange' },
        { label: '보상적 안정', color: 'yellow' },
        { label: '기능적 안정', color: 'green' },
        { label: '안정', color: 'blue' },
      ],
      summaryTitle,
      meaning,
      balanceControlFeature,
      dailyLifeConnection,
      bottomMessage,
    };
  }

  private async buildPrecisionComparison(comparison: ReportComparisonEntity, measurementType: MEASUREMENT_TYPE) {
    const beforeReport = await this.precisionReportRepo.findOne({
      where: { id: comparison.beforeReportId },
      relations: ['user'],
    });
    const afterReport = await this.precisionReportRepo.findOne({
      where: { id: comparison.afterReportId },
      relations: ['user'],
    });

    const extractSummary = async (report: PrecisionReportEntity | null) => {
      if (!report) return null;
      const files = await this.fileRepo.find({ where: { relatedId: report.id } });
      const base: any = {
        score: report.score,
        level: report.level || 'NORMAL',
        analysisData: report.analysisData,
        files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, division: f.division })),
        createdAt: report.createdAt,
      };
      if (measurementType === MEASUREMENT_TYPE.BALANCE_TEST) {
        const sideLegPassed = report.analysisData?.scoreDetail?.sideLeg?.disease === 'NORMAL';
        const effectiveScore = sideLegPassed ? (report.score ?? 0) : Math.min(report.score ?? 0, 50);
        base.totalScore = this.buildBalanceTotalScore(effectiveScore);
      }
      if (measurementType === MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST) {
        base.observationSummary = this.buildSpineObservationSummary(report, files);
      }
      if (measurementType === MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST) {
        const filesByDiv = Object.fromEntries(files.map(f => [f.division, f.fileUrl]));
        const sd = report.analysisData?.scoreDetail ?? {};
        const performanceIndex = this.measurementReportService.buildOHTPerformanceIndex(sd);
        base.exercisePerformanceIndex = performanceIndex;
        base.sidePatternAnalysis = this.measurementReportService.buildSidePatternAnalysis(sd, filesByDiv);
        base.rearPatternAnalysis = this.measurementReportService.buildRearPatternAnalysis(sd, filesByDiv);
        base.frontPatternAnalysis = this.measurementReportService.buildFrontPatternAnalysis(sd, filesByDiv);
      }
      return base;
    };

    return {
      type: measurementType,
      before: await extractSummary(beforeReport),
      after: await extractSummary(afterReport),
    };
  }

  /**
   * 척추 비교 리포트 상세 조회
   */
  async findOneSpine(trainerId: string, memberId: string, id: string) {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.SPINE } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
    };
  }

  /**
   * 균형 비교 리포트 상세 조회
   */
  async findOneBalance(trainerId: string, memberId: string, id: string) {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.BALANCE } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.BALANCE_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
    };
  }

  /**
   * 전신기능 비교 리포트 상세 조회
   */
  async findOneFullBody(trainerId: string, memberId: string, id: string) {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId, reportType: ComparisonReportType.FULL_BODY } });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
    };
  }

  /**
   * 비교 리포트 삭제
   */
  // ─── Public (공유 링크용, 인증 불필요) ───────────────────────────────────

  async findOneBodyPublic(id: string, memberId?: string): Promise<ReportComparisonDetailResponseDto> {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.BODY, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const dto = new ReportComparisonDetailResponseDto();
    Object.assign(dto, comparison);
    dto.beforeDate = comparison.summaryData?.beforeDate;
    dto.afterDate = comparison.summaryData?.afterDate;

    const beforeReport = await this.bodyReportRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.bodyReportRepo.findOne({ where: { id: comparison.afterReportId } });

    if (beforeReport && afterReport) {
      const beforeFiles = await this.fileRepo.find({ where: { relatedId: beforeReport.id } });
      const afterFiles = await this.fileRepo.find({ where: { relatedId: afterReport.id } });

      const extractSummary = (report: BodyReportEntity, files: FileEntity[]) => {
        const diseases = report.analysisData?.disease || [];
        const majorDiseases = rankBodyDiseases(diseases)
          .slice(0, 3)
          .map((d) => ({ key: d.key, label: d.label }));

        const bodyPartScores = BodyReportService.calculateBodyPartScores(report.analysisData);

        return {
          totalScore: report.totalScore,
          balance: report.analysisData?.scoreDetail?.balanceIndex,
          majorDiseases,
          bodyPartScores,
          files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, division: f.division })),
          landmarks: report.analysisData?.landmarks,
          previewSize: { width: report.analysisData?.previewWidth, height: report.analysisData?.previewHeight },
        };
      };

      dto.bodyComparison = {
        before: extractSummary(beforeReport, beforeFiles),
        after: extractSummary(afterReport, afterFiles),
      };
      dto.centerLogoUrl = await this.resolveCenterLogoUrl(afterReport.trainerId);
    }
    return dto;
  }

  async findOneRomPublic(id: string, memberId?: string): Promise<RomComparisonDetailResponseDto> {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.ROM, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const dto = new RomComparisonDetailResponseDto();
    Object.assign(dto, comparison);
    dto.beforeDate = comparison.summaryData?.beforeDate;
    dto.afterDate = comparison.summaryData?.afterDate;

    const beforeReport = await this.precisionReportRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.precisionReportRepo.findOne({ where: { id: comparison.afterReportId } });

    if (beforeReport && afterReport) {
      if (!dto.summaryData) dto.summaryData = {};
      if (!dto.summaryData.beforeComment) dto.summaryData.beforeComment = beforeReport.comment;
      if (!dto.summaryData.afterComment) dto.summaryData.afterComment = afterReport.comment;

      const beforeFiles = await this.fileRepo.find({ where: { relatedId: beforeReport.id } });
      const afterFiles = await this.fileRepo.find({ where: { relatedId: afterReport.id } });

      let romStandard: RomStandardEntity | null = null;
      if (beforeReport.key) {
        const allStandards = await this.romStandardRepo.find({ relations: ['sensations', 'movementPatterns', 'habits'] });
        romStandard = allStandards.find(s => s.reportNameEn.replace(/\s/g, '') === beforeReport.key) || null;
      }

      const extractAngle = (report: PrecisionReportEntity) => {
        const resultValues = Object.values(report.analysisData?.result || {}) as any[];
        const targetResult = resultValues.find(r => r && r.result);
        if (!targetResult) return '';
        let angleStr = targetResult.result;
        try {
          const j = JSON.parse(angleStr);
          if (j.angle) angleStr = j.angle;
          else if (j.distance) angleStr = j.distance;
        } catch {}
        return String(angleStr);
      };

      const extractLandmarks = (report: PrecisionReportEntity) => {
        if (!report.analysisData) return null;
        if (report.key && report.analysisData[report.key]) return report.analysisData[report.key].steps || report.analysisData[report.key];
        if (report.analysisData.landmarks) return report.analysisData.landmarks;
        if (report.analysisData.steps) return report.analysisData.steps;
        for (const k of Object.keys(report.analysisData)) {
          if (report.analysisData[k]?.steps) return report.analysisData[k].steps;
        }
        return null;
      };

      const extractSummary = (report: PrecisionReportEntity, files: FileEntity[]) => ({
        score: report.score,
        level: report.level || 'NORMAL',
        angle: extractAngle(report),
        files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, division: f.division })),
        landmarks: extractLandmarks(report),
        previewSize: { width: report.analysisData?.previewWidth, height: report.analysisData?.previewHeight },
      });

      dto.romComparison = {
        key: beforeReport.key || '',
        name: beforeReport.name || '',
        normalDeg: romStandard?.normalDeg || 0,
        before: extractSummary(beforeReport, beforeFiles),
        after: extractSummary(afterReport, afterFiles),
        detailInfo: {
          sensations: romStandard?.sensations.map(s => ({ content: s.sensationContent })) || [],
          movementPatterns: romStandard?.movementPatterns.map(p => ({ content: p.patternContent, imageNo: p.imageNo, dailyExample: p.dailyExample })) || [],
          habits: romStandard?.habits.map(h => ({ content: h.habitContent, imageNo: h.imageNo })) || [],
        },
      };
      dto.centerLogoUrl = await this.resolveCenterLogoUrl(afterReport.trainerId);
    }
    return dto;
  }

  async findOneMotionPublic(id: string, memberId?: string) {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.MOTION, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const beforeAnalysis = await this.motionAnalysisRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterAnalysis = await this.motionAnalysisRepo.findOne({ where: { id: comparison.afterReportId } });

    const flattenMotion = async (analysis: MotionAnalysisEntity | null) => {
      if (!analysis) return null;
      const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.MOTION, relatedId: analysis.id } });
      return {
        motionId: analysis.id,
        createdAt: analysis.createdAt,
        title: analysis.title,
        memo: analysis.memo,
        trainerComment: analysis.trainerComment ?? null,
        files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl })),
      };
    };

    return {
      id: comparison.id,
      trainerComment: comparison.trainerComment,
      createdAt: comparison.createdAt,
      before: await flattenMotion(beforeAnalysis),
      after: await flattenMotion(afterAnalysis),
      centerLogoUrl: await this.resolveCenterLogoUrl(afterAnalysis?.trainerId ?? beforeAnalysis?.trainerId),
    };
  }

  async findOneInbodyPublic(id: string, memberId?: string) {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.INBODY, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');

    const beforeReport = await this.inbodyDataRepo.findOne({ where: { id: comparison.beforeReportId } });
    const afterReport = await this.inbodyDataRepo.findOne({ where: { id: comparison.afterReportId } });

    const flattenInbody = (report: InbodyDataEntity | null) => {
      if (!report) return null;
      return {
        inbodyId: report.id,
        measuredAt: report.measuredAt,
        weight: report.keyStats?.weight,
        skeletalMuscleMass: report.keyStats?.skeletalMuscleMass,
        bodyFatMass: report.keyStats?.bodyFatMass,
        bmi: report.keyStats?.bmi,
        percentBodyFat: report.keyStats?.percentBodyFat,
        abdominalFatRatio: report.keyStats?.abdominalFatRatio,
        visceralFatLevel: report.keyStats?.visceralFatLevel,
        basalMetabolicRate: report.keyStats?.basalMetabolicRate,
        bodyWater: report.detailData?.bodyWater,
        protein: report.detailData?.protein,
        minerals: report.detailData?.minerals,
        idealWeight: report.detailData?.idealWeight,
        weightControl: report.detailData?.weightControl,
        fatControl: report.detailData?.fatControl,
        muscleControl: report.detailData?.muscleControl,
        bmiEvaluation: report.detailData?.bmiEvaluation,
        bodyFatEvaluation: report.detailData?.bodyFatEvaluation,
        inbodyImageUrl: report.detailData?.inbodyImageUrl,
      };
    };

    return {
      id: comparison.id,
      trainerComment: comparison.trainerComment,
      createdAt: comparison.createdAt,
      before: flattenInbody(beforeReport),
      after: flattenInbody(afterReport),
      centerLogoUrl: await this.resolveCenterLogoUrl(afterReport?.trainerId ?? beforeReport?.trainerId),
    };
  }

  async findOneSpinePublic(id: string, memberId?: string) {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.SPINE, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');
    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
      centerLogoUrl: await this.resolveCenterLogoUrl(await this.resolvePrecisionComparisonTrainerId(comparison)),
    };
  }

  async findOneBalancePublic(id: string, memberId?: string) {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.BALANCE, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');
    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.BALANCE_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
      centerLogoUrl: await this.resolveCenterLogoUrl(await this.resolvePrecisionComparisonTrainerId(comparison)),
    };
  }

  async findOneFullBodyPublic(id: string, memberId?: string) {
    const comparison = await this.comparisonRepo.findOne({
      where: { id, reportType: ComparisonReportType.FULL_BODY, ...(memberId ? { userId: memberId } : {}) },
    });
    if (!comparison) throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');
    const precisionComparison = await this.buildPrecisionComparison(comparison, MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST);
    return {
      id: comparison.id, reportType: comparison.reportType,
      beforeDate: comparison.summaryData?.beforeDate, afterDate: comparison.summaryData?.afterDate,
      summaryData: comparison.summaryData, trainerComment: comparison.trainerComment, createdAt: comparison.createdAt,
      precisionComparison,
      centerLogoUrl: await this.resolveCenterLogoUrl(await this.resolvePrecisionComparisonTrainerId(comparison)),
    };
  }

  /**
   * 비교 리포트 상세 (reportType에 따라 타입별 상세 반환)
   */
  async findOneForMember(trainerId: string, memberId: string, id: string): Promise<unknown> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const comparison = await this.comparisonRepo.findOne({ where: { id, userId: memberId } });
    if (!comparison) {
      throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');
    }

    switch (comparison.reportType) {
      case ComparisonReportType.BODY:
        return this.findOneBody(trainerId, memberId, id);
      case ComparisonReportType.ROM:
        return this.findOneRom(trainerId, memberId, id);
      case ComparisonReportType.MOTION:
        return this.findOneMotion(trainerId, memberId, id);
      case ComparisonReportType.INBODY:
        return this.findOneInbody(trainerId, memberId, id);
      case ComparisonReportType.SPINE:
        return this.findOneSpine(trainerId, memberId, id);
      case ComparisonReportType.BALANCE:
        return this.findOneBalance(trainerId, memberId, id);
      case ComparisonReportType.FULL_BODY:
        return this.findOneFullBody(trainerId, memberId, id);
      default:
        throw new BadRequestException('지원하지 않는 비교 리포트 유형입니다.');
    }
  }

  /**
   * 비교 리포트 삭제
   */
  async delete(trainerId: string, memberId: string, id: string): Promise<void> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 삭제할 권한이 없습니다.');

    const result = await this.comparisonRepo.delete({ id, userId: memberId });
    if (result.affected === 0) {
      throw new NotFoundException('비교 리포트를 찾을 수 없습니다.');
    }
  }
}
