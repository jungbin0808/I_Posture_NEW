import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportComparisonEntity } from '../../database/entities/report-comparison.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import {
  ReportComparisonController,
  ReportComparisonPublicController,
  CenterReportComparisonPublicController,
} from './report-comparison.controller';
import { ReportComparisonService } from './report-comparison.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { CapacityModule } from '../capacity/capacity.module';
import { MeasurementReportModule } from '../measurement-report/measurement-report.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ReportComparisonEntity,
      UserEntity,
      TrainerUserEntity,
      BodyReportEntity,
      PrecisionReportEntity,
      FileEntity,
      RomStandardEntity,
      InbodyDataEntity,
      MotionAnalysisEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
    ]),
    CapacityModule,
    MeasurementReportModule,
  ],
  controllers: [
    ReportComparisonController,
    ReportComparisonPublicController,
    CenterReportComparisonPublicController,
  ],
  providers: [ReportComparisonService, SubscriptionGuard],
  exports: [ReportComparisonService],
})
export class ReportComparisonModule {}
