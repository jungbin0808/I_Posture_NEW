import { Body, Controller, Delete, Get, Param, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { ReportComparisonService } from './report-comparison.service';
import { CreateReportComparisonDto } from './dto/create-report-comparison.dto';
import { FindReportComparisonDto } from './dto/find-report-comparison.dto';
import { ReportComparisonResponseDto, ReportComparisonDetailResponseDto } from './dto/report-comparison-response.dto';
import { RomComparisonDetailResponseDto } from './dto/rom-comparison-response.dto';

@ApiTags('Report Comparison')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('report-comparisons')
export class ReportComparisonController {
  constructor(private readonly comparisonService: ReportComparisonService) {}

  @ApiOperation({ summary: 'Create Report Comparison' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId')
  async create(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() createDto: CreateReportComparisonDto,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.create(req.user.id, memberId, createDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Member Comparison List' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() dto: FindReportComparisonDto,
  ): Promise<IPageResponse<ReportComparisonResponseDto>> {
    const pageData = await this.comparisonService.findAllByMemberId(req.user.id, memberId, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Get Body Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('body/member/:memberId/:id')
  async findOneBody(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<ReportComparisonDetailResponseDto>> {
    const data = await this.comparisonService.findOneBody(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get ROM Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('rom/member/:memberId/:id')
  async findOneRom(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<RomComparisonDetailResponseDto>> {
    const data = await this.comparisonService.findOneRom(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Motion Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('motion/member/:memberId/:id')
  async findOneMotion(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.comparisonService.findOneMotion(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Inbody Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('inbody/member/:memberId/:id')
  async findOneInbody(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.comparisonService.findOneInbody(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Spine Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('spinal-alignment/member/:memberId/:id')
  async findOneSpine(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.comparisonService.findOneSpine(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Balance Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('balance-test/member/:memberId/:id')
  async findOneBalance(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.comparisonService.findOneBalance(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Full Body Function Comparison Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('overhead-squat/member/:memberId/:id')
  async findOneFullBody(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.comparisonService.findOneFullBody(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Delete Comparison' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId/:id')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    await this.comparisonService.delete(req.user.id, memberId, id);
    return SuccessResponse({ success: true });
  }
}

@ApiTags('Report Comparison Public')
@Controller('report-comparisons/public')
export class ReportComparisonPublicController {
  constructor(private readonly comparisonService: ReportComparisonService) {}

  @ApiOperation({ summary: 'Get Body Comparison Detail (Public / Share Link)' })
  @Get('body/:id')
  async findOneBodyPublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<ReportComparisonDetailResponseDto>> {
    const result = await this.comparisonService.findOneBodyPublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get ROM Comparison Detail (Public / Share Link)' })
  @Get('rom/:id')
  async findOneRomPublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<RomComparisonDetailResponseDto>> {
    const result = await this.comparisonService.findOneRomPublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Motion Comparison Detail (Public / Share Link)' })
  @Get('motion/:id')
  async findOneMotionPublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneMotionPublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Inbody Comparison Detail (Public / Share Link)' })
  @Get('inbody/:id')
  async findOneInbodyPublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneInbodyPublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Spine Comparison Detail (Public / Share Link)' })
  @Get('spinal-alignment/:id')
  async findOneSpinePublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneSpinePublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Balance Comparison Detail (Public / Share Link)' })
  @Get('balance-test/:id')
  async findOneBalancePublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneBalancePublic(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Full Body Function Comparison Detail (Public / Share Link)' })
  @Get('overhead-squat/:id')
  async findOneFullBodyPublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneFullBodyPublic(id);
    return SuccessResponse(result);
  }
}

/**
 * 센터용 공개 비교 리포트 — 인증 불필요 (공유 링크)
 * 트레이너용 ReportComparisonPublicController와 동일한 서비스 로직을 재사용하되,
 * member/:memberId/{종류}/:id 패턴(측정 리포트와 동일한 URL 형태)으로 통일하고
 * memberId로 소유 회원 검증까지 함께 수행.
 */
@ApiTags('Center Report Comparison Public')
@Controller('center/report-comparisons/public')
export class CenterReportComparisonPublicController {
  constructor(private readonly comparisonService: ReportComparisonService) {}

  @ApiOperation({ summary: 'Get Body Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/body/:id')
  async findOneBodyPublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<ReportComparisonDetailResponseDto>> {
    const result = await this.comparisonService.findOneBodyPublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get ROM Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/rom/:id')
  async findOneRomPublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<RomComparisonDetailResponseDto>> {
    const result = await this.comparisonService.findOneRomPublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Motion Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/motion/:id')
  async findOneMotionPublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneMotionPublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Inbody Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/inbody/:id')
  async findOneInbodyPublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneInbodyPublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Spine Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/spinal-alignment/:id')
  async findOneSpinePublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneSpinePublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Balance Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/balance-test/:id')
  async findOneBalancePublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneBalancePublic(id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Get Full Body Function Comparison Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/overhead-squat/:id')
  async findOneFullBodyPublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.comparisonService.findOneFullBodyPublic(id, memberId);
    return SuccessResponse(result);
  }
}
