import { ApiProperty } from '@nestjs/swagger';
import { ReportComparisonResponseDto } from './report-comparison-response.dto';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '구분 (Key_stepN)' })
  division?: string;
}

class PreviewSizeDto {
  @ApiProperty({ description: '프리뷰 너비' })
  width!: number;

  @ApiProperty({ description: '프리뷰 높이' })
  height!: number;
}

class RomReportSummaryDto {
  @ApiProperty({ description: '점수 (도달률)' })
  score!: number;

  @ApiProperty({ description: '단계' })
  level!: string;

  @ApiProperty({ description: '측정 각도 (문자열)', nullable: true })
  angle?: string;

  @ApiProperty({ description: '사진 목록', type: [FileDto] })
  files!: FileDto[];

  @ApiProperty({ description: '랜드마크 데이터 (JSON)', nullable: true })
  landmarks?: any;

  @ApiProperty({ description: '프리뷰 사이즈', type: PreviewSizeDto, nullable: true })
  previewSize?: PreviewSizeDto;
}

class RomSensationDto {
  @ApiProperty({ description: '체감 변화 내용' })
  content!: string;
}

class RomMovementPatternDto {
  @ApiProperty({ description: '움직임 패턴 내용' })
  content!: string;

  @ApiProperty({ description: '이미지 번호' })
  imageNo!: number;

  @ApiProperty({ description: '일상 예시' })
  dailyExample!: string;
}

class RomHabitDto {
  @ApiProperty({ description: '습관/자세 내용' })
  content!: string;

  @ApiProperty({ description: '이미지 번호' })
  imageNo!: number;
}

class RomDetailInfoDto {
  @ApiProperty({ description: '질환 및 통증 (체감 변화)', type: [RomSensationDto] })
  sensations!: RomSensationDto[];

  @ApiProperty({ description: '움직임 패턴', type: [RomMovementPatternDto] })
  movementPatterns!: RomMovementPatternDto[];

  @ApiProperty({ description: '습관 및 자세', type: [RomHabitDto] })
  habits!: RomHabitDto[];
}

class RomComparisonDto {
  @ApiProperty({ description: '동작 키' })
  key!: string;

  @ApiProperty({ description: '동작명' })
  name!: string;

  @ApiProperty({ description: '정상 각도' })
  normalDeg!: number;

  @ApiProperty({ description: 'Before 리포트 요약' })
  before!: RomReportSummaryDto;

  @ApiProperty({ description: 'After 리포트 요약' })
  after!: RomReportSummaryDto;

  @ApiProperty({ description: '상세 정보 (공통)', type: RomDetailInfoDto })
  detailInfo!: RomDetailInfoDto;
}

export class RomComparisonDetailResponseDto extends ReportComparisonResponseDto {
  @ApiProperty({ description: '정밀 비교 상세 데이터', type: RomComparisonDto })
  romComparison!: RomComparisonDto;
}
