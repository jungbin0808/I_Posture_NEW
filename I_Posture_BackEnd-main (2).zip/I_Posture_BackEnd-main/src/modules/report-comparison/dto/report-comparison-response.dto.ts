import { ApiProperty } from '@nestjs/swagger';
import { ComparisonReportType } from '../../../database/entities/report-comparison.entity';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '구분 (FRONT, SIDE, BACK)' })
  division?: string;
}

class PreviewSizeDto {
  @ApiProperty({ description: '프리뷰 너비' })
  width!: number;

  @ApiProperty({ description: '프리뷰 높이' })
  height!: number;
}

class BodyReportSummaryDto {
  @ApiProperty({ description: '종합 점수' })
  totalScore!: number;

  @ApiProperty({ description: '신체 균형 상태 (JSON)' })
  balance!: any;

  @ApiProperty({ description: '주요 체형 유형 (JSON)' })
  majorDiseases!: any;

  @ApiProperty({ description: '부위별 점수 (average + items)' })
  bodyPartScores!: any;

  @ApiProperty({ description: '사진 목록', type: [FileDto] })
  files!: FileDto[];

  @ApiProperty({ description: '랜드마크 데이터 (JSON)', nullable: true })
  landmarks?: any;

  @ApiProperty({ description: '프리뷰 사이즈', type: PreviewSizeDto, nullable: true })
  previewSize?: PreviewSizeDto;
}

class BodyComparisonDto {
  @ApiProperty({ description: 'Before 리포트 요약' })
  before!: BodyReportSummaryDto;

  @ApiProperty({ description: 'After 리포트 요약' })
  after!: BodyReportSummaryDto;
}

export class ReportComparisonResponseDto {
  @ApiProperty({ description: '비교 리포트 ID' })
  id!: string;

  @ApiProperty({ description: '리포트 종류', enum: ComparisonReportType })
  reportType!: ComparisonReportType;

  @ApiProperty({ description: 'Before 리포트 ID' })
  beforeReportId!: string;

  @ApiProperty({ description: 'After 리포트 ID' })
  afterReportId!: string;

  @ApiProperty({ description: 'Before 점수', nullable: true })
  beforeScore?: number;

  @ApiProperty({ description: 'After 점수', nullable: true })
  afterScore?: number;

  @ApiProperty({ description: 'Before 측정일', nullable: true })
  beforeDate?: Date;

  @ApiProperty({ description: 'After 측정일', nullable: true })
  afterDate?: Date;

  @ApiProperty({ description: '요약 데이터 (JSON)', nullable: true })
  summaryData?: any;

  @ApiProperty({ description: '트레이너 코멘트', nullable: true })
  trainerComment?: string;

  @ApiProperty({ description: '생성일시' })
  createdAt!: Date;

  @ApiProperty({ description: '센터 로고 URL (센터 소속 트레이너인 경우만)', nullable: true })
  centerLogoUrl?: string | null;
}

export class ReportComparisonDetailResponseDto extends ReportComparisonResponseDto {
  // 원본 리포트 데이터 (선택적 포함)
  @ApiProperty({ description: 'Before 리포트 데이터', nullable: true })
  beforeReport?: any;

  @ApiProperty({ description: 'After 리포트 데이터', nullable: true })
  afterReport?: any;

  @ApiProperty({ description: '체형 비교 상세 데이터', type: BodyComparisonDto, nullable: true })
  bodyComparison?: BodyComparisonDto;
}
