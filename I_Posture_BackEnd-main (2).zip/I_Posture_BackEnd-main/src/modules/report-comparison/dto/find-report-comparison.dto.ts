import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';
import { Min } from 'class-validator';
import { ComparisonReportType } from '../../../database/entities/report-comparison.entity';

export enum ReportComparisonSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindReportComparisonDto {
  @ApiProperty({ description: '페이지 번호', required: false, default: 1 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page?: number = 1;

  @ApiProperty({ description: '페이지당 항목 수', required: false, default: 10 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit?: number = 10;

  @ApiProperty({ description: '조회 시작 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '조회 종료 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({
    description: '구분 필터 (BODY: 체형, ROM: 정밀, INBODY: 인바디, MOTION: 모션)',
    enum: ComparisonReportType,
    required: false,
  })
  @IsEnum(ComparisonReportType)
  @IsOptional()
  reportType?: ComparisonReportType;

  @ApiProperty({ description: '정렬 순서', enum: ReportComparisonSortOrder, required: false, default: ReportComparisonSortOrder.DATE_DESC })
  @IsEnum(ReportComparisonSortOrder)
  @IsOptional()
  sort?: ReportComparisonSortOrder = ReportComparisonSortOrder.DATE_DESC;
}
