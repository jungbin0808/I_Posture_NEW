import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsString } from 'class-validator';
import { ComparisonReportType } from '../../../database/entities/report-comparison.entity';

export class CreateReportComparisonDto {
  @ApiProperty({ description: '리포트 종류 (BODY, ROM, MOTION, INBODY)', enum: ComparisonReportType })
  @IsEnum(ComparisonReportType)
  @IsNotEmpty()
  reportType!: ComparisonReportType;

  @ApiProperty({ description: 'Before 리포트 ID' })
  @IsString()
  @IsNotEmpty()
  beforeReportId!: string;

  @ApiProperty({ description: 'After 리포트 ID' })
  @IsString()
  @IsNotEmpty()
  afterReportId!: string;
}
