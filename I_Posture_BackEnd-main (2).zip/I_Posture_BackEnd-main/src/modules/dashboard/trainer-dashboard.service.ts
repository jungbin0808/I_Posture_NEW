import { Injectable } from '@nestjs/common';
import { InjectDataSource } from '@nestjs/typeorm';
import { DataSource } from 'typeorm';
import {
  calcTrialConversionRatePercent,
  fetchTrialConversionMetrics,
} from '../consultation-log/helpers/trial-conversion-metrics.helper';
import {
  fetchTrainerConsultationStats,
  fetchTrainerConsultationStatsTrend,
} from '../consultation-log/helpers/trainer-transfer-attribution.helper';

@Injectable()
export class TrainerDashboardService {
  constructor(
    @InjectDataSource() private readonly dataSource: DataSource,
  ) {}

  // ────────────────────────────────────────────────────────────────
  // Screen 1: 회원 운영 관리
  // ────────────────────────────────────────────────────────────────
  async getMemberManagement(trainerId: string) {
    const now = new Date();
    const startOfMonth   = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth      = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
    const thirtyDaysAgo  = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const startOfToday   = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const threeDaysLater = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 3);

    // 1. 이번 달 레슨 출석/결석 통계 (workout_logs 기준)
    const [lessonStat] = await this.dataSource.query(`
      SELECT
        COUNT(*)                                                                      AS total,
        SUM(CASE WHEN wl.attendance IN ('PRESENT','LATE') THEN 1 ELSE 0 END)        AS attended,
        SUM(CASE WHEN wl.attendance = 'ABSENT'            THEN 1 ELSE 0 END)        AS absent
      FROM workout_logs wl
      WHERE wl.trainer_id  = ?
        AND wl.workout_date >= ?
        AND wl.workout_date  < ?
        AND wl.deleted_at   IS NULL
    `, [trainerId, startOfMonth, nextMonth]);

    const total    = Number(lessonStat.total)    || 0;
    const attended = Number(lessonStat.attended) || 0;
    const absent   = Number(lessonStat.absent)   || 0;

    // 2. 수업 빈도 낮은 TOP 5 (이번 달 기준: 운동일지 작성 수 + 예약 건수)
    const lowLessonMembers = await this.dataSource.query(`
      SELECT
        u.id                                    AS memberId,
        u.name                                  AS memberName,
        COALESCE(wl.cnt, 0) + COALESCE(sb.cnt, 0) AS lessonCount
      FROM trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      LEFT JOIN (
        SELECT wl2.user_id AS uid, COUNT(*) AS cnt
        FROM   workout_logs wl2
        WHERE  wl2.trainer_id    = ?
          AND  wl2.workout_date >= ?
          AND  wl2.workout_date  < ?
          AND  wl2.deleted_at   IS NULL
        GROUP BY wl2.user_id
      ) wl ON wl.uid = u.id
      LEFT JOIN (
        SELECT sb2.user_id AS uid, COUNT(*) AS cnt
        FROM   schedule_bookings sb2
        INNER JOIN schedules s2
          ON  s2.id          = sb2.schedule_id
          AND s2.trainer_id  = ?
          AND s2.start_time >= ?
          AND s2.start_time  < ?
          AND s2.deleted_at  IS NULL
        WHERE sb2.deleted_at IS NULL
          AND sb2.status    != 'CANCELED'
        GROUP BY sb2.user_id
      ) sb ON sb.uid = u.id
      WHERE tu.trainer_id  = ?
        AND tu.status      = 'ACTIVE'
        AND tu.deleted_at  IS NULL
      ORDER BY lessonCount ASC
      LIMIT 5
    `, [trainerId, startOfMonth, nextMonth, trainerId, startOfMonth, nextMonth, trainerId]);

    // 3. 측정 빈도 낮은 TOP 5 (3개월간: 체형분석 + 정밀분석 + 인바디 + 모션분석)
    const lowMeasurementMembers = await this.dataSource.query(`
      SELECT
        u.id                          AS memberId,
        u.name                        AS memberName,
        COALESCE(mc.cnt, 0)           AS measurementCount
      FROM trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      LEFT JOIN (
        SELECT uid, COUNT(*) AS cnt
        FROM (
          SELECT user_id AS uid
          FROM   body_reports
          WHERE  trainer_id    = ?
            AND  created_at   >= ?
            AND  deleted_at   IS NULL
          UNION ALL
          SELECT user_id AS uid
          FROM   precision_reports
          WHERE  trainer_id    = ?
            AND  created_at   >= ?
            AND  deleted_at   IS NULL
          UNION ALL
          SELECT user_id AS uid
          FROM   inbody_data
          WHERE  trainer_id    = ?
            AND  created_at   >= ?
            AND  deleted_at   IS NULL
          UNION ALL
          SELECT user_id AS uid
          FROM   motion_analyses
          WHERE  trainer_id    = ?
            AND  created_at   >= ?
            AND  deleted_at   IS NULL
        ) all_records
        GROUP BY uid
      ) mc ON mc.uid = u.id
      WHERE tu.trainer_id  = ?
        AND tu.status      = 'ACTIVE'
        AND tu.deleted_at  IS NULL
      ORDER BY measurementCount ASC
      LIMIT 5
    `, [
      trainerId, threeMonthsAgo,
      trainerId, threeMonthsAgo,
      trainerId, threeMonthsAgo,
      trainerId, threeMonthsAgo,
      trainerId,
    ]);

    // 4. 휴면 회원 목록 (30일 기준 — 수업 참석 & 측정 없음)
    const dormantMembers = await this.dataSource.query(`
      SELECT tu.member_id AS memberId, u.name AS memberName
      FROM   trainer_users tu
      INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
      WHERE  tu.trainer_id  = ?
        AND  tu.status      = 'ACTIVE'
        AND  tu.deleted_at  IS NULL
        AND  tu.member_id NOT IN (
          SELECT DISTINCT br.user_id
          FROM   body_reports br
          WHERE  br.trainer_id  = ?
            AND  br.created_at >= ?
            AND  br.deleted_at  IS NULL
          UNION
          SELECT DISTINCT sb.user_id
          FROM   schedule_bookings sb
          INNER JOIN schedules s
            ON  s.id           = sb.schedule_id
            AND s.trainer_id   = ?
            AND s.start_time  >= ?
            AND s.deleted_at   IS NULL
          WHERE  sb.status     = 'APPLIED'
            AND  sb.deleted_at IS NULL
        )
      ORDER BY u.name ASC
    `, [trainerId, trainerId, thirtyDaysAgo, trainerId, thirtyDaysAgo]);

    // 5. 수업 예약 현황 (오늘 ~ 3일치)
    const rawSchedules = await this.dataSource.query(`
      SELECT
        s.start_time  AS startTime,
        s.end_time    AS endTime,
        u.id          AS memberId,
        u.name        AS memberName
      FROM schedules s
      INNER JOIN schedule_bookings sb
        ON  sb.schedule_id = s.id
        AND sb.deleted_at  IS NULL
        AND sb.status     != 'CANCELED'
      INNER JOIN users u ON u.id = sb.user_id
      WHERE s.trainer_id  = ?
        AND s.start_time  >= ?
        AND s.start_time   < ?
        AND s.deleted_at  IS NULL
      ORDER BY s.start_time ASC
    `, [trainerId, startOfToday, threeDaysLater]);

    // 날짜·시간 기준으로 그룹핑
    const scheduleMap = new Map<string, Map<string, { id: string; name: string }[]>>();
    for (const row of rawSchedules) {
      const dt   = new Date(row.startTime);
      // KST(+09:00) 기준으로 date/time 추출
      const kstOffset = 9 * 60 * 60 * 1000;
      const kstDt = new Date(dt.getTime() + kstOffset);
      const date = kstDt.toISOString().substring(0, 10);
      const time = kstDt.toISOString().substring(11, 16);
      if (!scheduleMap.has(date)) scheduleMap.set(date, new Map());
      const timeMap = scheduleMap.get(date)!;
      if (!timeMap.has(time)) timeMap.set(time, []);
      timeMap.get(time)!.push({ id: row.memberId, name: row.memberName });
    }
    const upcomingSchedules = Array.from(scheduleMap.entries()).map(([date, timeMap]) => ({
      date,
      slots: Array.from(timeMap.entries()).map(([time, members]) => ({ time, members })),
    }));

    return {
      lesson: {
        attendanceRate:  total > 0 ? Math.round((attended / total) * 100) : 0,
        attendanceCount: attended,
        absenceRate:     total > 0 ? 100 - Math.round((attended / total) * 100) : 0,
        absenceCount:    absent,
      },
      retentionRisk: {
        lowLessonFrequency: lowLessonMembers.map((r: any) => ({
          memberId:   r.memberId,
          memberName: r.memberName,
          count:      Number(r.lessonCount),
        })),
        lowMeasurementFrequency: lowMeasurementMembers.map((r: any) => ({
          memberId:   r.memberId,
          memberName: r.memberName,
          count:      Number(r.measurementCount),
        })),
        dormantCount:   dormantMembers.length,
        dormantMembers: dormantMembers.map((r: any) => ({ memberId: r.memberId, memberName: r.memberName })),
      },
      upcomingSchedules,
    };
  }

  // ────────────────────────────────────────────────────────────────
  // Screen 2: 성과 증명 (Before/After & Outcomes)
  // ────────────────────────────────────────────────────────────────
  async getPerformance(trainerId: string) {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    // 이번 달 body_report 중 회원별 역대 최고(가장 낮은) 값 조회
    const bodyData = await this.dataSource.query(`
      SELECT
        u.id                          AS memberId,
        u.name                        AS memberName,
        MIN(br.neck_score)            AS neckScore,
        MIN(br.pelvis_asymmetry_score)   AS pelvisScore,
        MIN(br.shoulder_asymmetry_score) AS shoulderScore
      FROM trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      INNER JOIN body_reports br
        ON  br.user_id     = tu.member_id
        AND br.trainer_id  = ?
        AND br.created_at >= ?
        AND br.created_at  < ?
        AND br.deleted_at  IS NULL
      WHERE tu.trainer_id  = ?
        AND tu.status      = 'ACTIVE'
        AND tu.deleted_at  IS NULL
      GROUP BY u.id, u.name
    `, [trainerId, startOfMonth, nextMonth, trainerId]);

    // 이번 달 ROM: 회원별 도달률(score) 최저값 → 낮은 순 하위 3명
    const romRows = await this.dataSource.query(`
      SELECT
        u.id              AS memberId,
        u.name            AS memberName,
        MIN(pr.score)     AS minScore
      FROM trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      INNER JOIN precision_reports pr
        ON  pr.user_id    = tu.member_id
        AND pr.trainer_id = ?
        AND pr.created_at >= ?
        AND pr.created_at  < ?
        AND pr.deleted_at IS NULL
        AND pr.type NOT IN ('BODY','SPINAL_ALIGNMENT_TEST','OVERHEAD_SQUAT_TEST','BALANCE_TEST')
      WHERE tu.trainer_id  = ?
        AND tu.status      = 'ACTIVE'
        AND tu.deleted_at  IS NULL
      GROUP BY u.id, u.name
      ORDER BY minScore ASC
    `, [trainerId, startOfMonth, nextMonth, trainerId]);

    // 이번 달 역대 최고(최저) 값 기준 정렬: top3 = 각도 작을수록(ASC), bottom3 = 각도 클수록(DESC)
    const sortBody = (key: string, asc: boolean) => {
      const sorted = [...bodyData]
        .sort((a: any, b: any) => asc
          ? Number(a[key]) - Number(b[key])
          : Number(b[key]) - Number(a[key]));
      return sorted.slice(0, 3).map((r: any) => ({
        memberId:   r.memberId,
        memberName: r.memberName,
        value:      Number(r[key]) || 0,
      }));
    };

    // ROM bottom3: 이번 달 도달률(score) 최저 회원 3명
    const fmtRom = (rows: any[]) =>
      rows.slice(0, 3).map((r: any) => ({
        memberId:   r.memberId,
        memberName: r.memberName,
        value:      Math.round(Number(r.minScore)) || 0,
      }));

    return {
      turtleNeck: {
        top3:    sortBody('neckScore', true),   // 각도 낮을수록(0에 가까울수록) 상위
        bottom3: sortBody('neckScore', false),  // 각도 클수록 하위
      },
      pelvisAsymmetry: {
        top3:    sortBody('pelvisScore', true),   // 상위: 각도 작을수록 1위 (ASC)
        bottom3: sortBody('pelvisScore', false),  // 하위: 각도 클수록 1위 (DESC)
      },
      shoulderAsymmetry: {
        top3:    sortBody('shoulderScore', true),   // 상위: 각도 작을수록 1위 (ASC)
        bottom3: sortBody('shoulderScore', false),  // 하위: 각도 클수록 1위 (DESC)
      },
      rom: {
        bottom3: fmtRom(romRows),  // ROM 도달률 낮을수록 하위
      },
    };
  }

  // ────────────────────────────────────────────────────────────────
  // Screen 2: 우리 센터 남은 데이터 (스토리지)
  // ────────────────────────────────────────────────────────────────
  async getStorage(trainerId: string) {
    // 센터 소속 여부 확인
    const [centerTrainer] = await this.dataSource.query(`
      SELECT ct.center_id AS centerId
      FROM   center_trainers ct
      WHERE  ct.trainer_id  = ?
        AND  ct.status      = 'WORKING'
        AND  ct.deleted_at  IS NULL
      LIMIT 1
    `, [trainerId]);

    let pool: any = null;
    if (centerTrainer) {
      [pool] = await this.dataSource.query(`
        SELECT total_capacity AS totalCapacity, used_capacity AS usedCapacity,
               allocated_capacity AS allocatedCapacity
        FROM   center_capacity_pool
        WHERE  center_id = ?
      `, [centerTrainer.centerId]);
    } else {
      [pool] = await this.dataSource.query(`
        SELECT total_capacity AS totalCapacity, used_capacity AS usedCapacity,
               allocated_capacity AS allocatedCapacity
        FROM   trainer_capacity_pool
        WHERE  trainer_id = ?
      `, [trainerId]);
    }

    // 트레이너 본인 사용량
    const [trainerPool] = centerTrainer
      ? await this.dataSource.query(`
          SELECT COALESCE(used_capacity, 0) AS usedCapacity
          FROM   center_trainer_capacity_pools
          WHERE  center_id = ?
            AND  trainer_id = ?
        `, [centerTrainer.centerId, trainerId])
      : await this.dataSource.query(`
          SELECT COALESCE(SUM(size), 0) AS usedCapacity
          FROM   files
          WHERE  uploader_id = ?
        `, [trainerId]);

    // 발급 중인 회원 수 & 할당 용량
    // C_TRAINER는 센터 pool 기준이므로 center_id로 조회, 아니면 trainer_id로 조회
    const [allocation] = centerTrainer
      ? await this.dataSource.query(`
          SELECT COUNT(*)                  AS memberCount,
                 SUM(allocated_capacity)   AS totalAllocated
          FROM   storage_allocations
          WHERE  owner_id = ?
            AND  status   = 'ACTIVE'
        `, [centerTrainer.centerId])
      : await this.dataSource.query(`
          SELECT COUNT(*)                  AS memberCount,
                 SUM(allocated_capacity)   AS totalAllocated
          FROM   storage_allocations
          WHERE  owner_id = ?
            AND  status   = 'ACTIVE'
        `, [trainerId]);

    const toBytes = (val: string | null | undefined): number => {
      if (!val) return 0;
      return Number(val) || 0;
    };

    const total     = pool?.totalCapacity     ?? '0';
    const used      = pool?.usedCapacity      ?? '0';
    const allocated = pool?.allocatedCapacity ?? '0';
    const remaining = Math.max(0, Number(total) - Number(used) - Number(allocated));

    return {
      totalCapacity:          toBytes(total),
      usedCapacity:           toBytes(used),
      allocatedCapacity:      toBytes(allocated),
      remainingCapacity:      remaining,
      myUsage:                toBytes(trainerPool?.usedCapacity ?? '0'),
      allocatedMemberCount:   Number(allocation?.memberCount)   || 0,
      memberAllocatedCapacity: toBytes(allocation?.totalAllocated ?? '0'),
    };
  }

  // ────────────────────────────────────────────────────────────────
  // Screen 3: 등록/매출 퍼널 (트래킹 노트 기반)
  // ────────────────────────────────────────────────────────────────
  async getSalesFunnel(trainerId: string) {
    const now           = new Date();
    const startOfMonth  = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth     = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const sixMonthsAgo  = new Date(now.getFullYear(), now.getMonth() - 5, 1);

    // 월별 등록 미등록 추이 (최근 6개월) — 이관 시 담당이 바뀐 상담일지도 있어, 실제 상담을 진행한 트레이너 기준으로 보정
    const monthlyTrends = await fetchTrainerConsultationStatsTrend(
      this.dataSource,
      trainerId,
      sixMonthsAgo,
    );

    // 이번 달 상담 통계 (이관 실적 보정 적용)
    const currentMonth = await fetchTrainerConsultationStats(
      this.dataSource,
      trainerId,
      startOfMonth,
      nextMonth,
    );

    // 총 등록 회원 수 (ACTIVE 상태인 내 회원)
    const [registeredCount] = await this.dataSource.query(`
      SELECT COUNT(*) AS cnt
      FROM   trainer_users tu
      WHERE  tu.trainer_id = ?
        AND  tu.status     = 'ACTIVE'
        AND  tu.deleted_at IS NULL
    `, [trainerId]);

    // 월간 신규 앱 가입 추이 (최근 6개월, 내 회원 기준)
    const monthlyAppSignups = await this.dataSource.query(`
      SELECT
        DATE_FORMAT(tu.created_at, '%Y-%m') AS month,
        COUNT(*)                            AS count
      FROM   trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      WHERE  tu.trainer_id = ?
        AND  tu.created_at >= ?
        AND  tu.deleted_at  IS NULL
        AND  tu.status      = 'ACTIVE'
      GROUP BY DATE_FORMAT(tu.created_at, '%Y-%m')
      ORDER BY month ASC
    `, [trainerId, sixMonthsAgo]);

    const [currentMonthSignup] = await this.dataSource.query(`
      SELECT COUNT(*) AS cnt
      FROM   trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      WHERE  tu.trainer_id = ?
        AND  tu.created_at >= ?
        AND  tu.created_at  < ?
        AND  tu.deleted_at  IS NULL
        AND  tu.status      = 'ACTIVE'
    `, [trainerId, startOfMonth, nextMonth]);

    const totalConsult = Number(currentMonth.total)    || 0;
    const trialCount   = Number(currentMonth.trial)    || 0;
    const regNew       = Number(currentMonth.regNew)   || 0;
    const regRenew     = Number(currentMonth.regRenew) || 0;
    const noSale       = Number(currentMonth.noSale)   || 0;

    const { trialMemberCount, trialConversionCount } = await fetchTrialConversionMetrics(
      this.dataSource,
      [trainerId],
      startOfMonth,
      nextMonth,
    );

    return {
      monthlyTrends: monthlyTrends.map((r: any) => {
        const tot    = Number(r.total)    || 0;
        const tr     = Number(r.trial)    || 0;
        const rn     = Number(r.regNew)   || 0;
        const rr     = Number(r.regRenew) || 0;
        const ns     = Number(r.noSale)   || 0;
        const pd     = rn + rr;
        return {
          month:              r.month,
          total:              tot,
          trial:              tr,
          regNew:             rn,
          regRenew:           rr,
          noSale:             ns,
          trialRate:          tot > 0 ? Math.round((tr / tot) * 100) : 0,
          regNewRate:         tot > 0 ? Math.round((rn / tot) * 100) : 0,
          regRenewRate:       tot > 0 ? Math.round((rr / tot) * 100) : 0,
          noSaleRate:         tot > 0 ? Math.round((ns / tot) * 100) : 0,
          conversionRate:     tot > 0 ? Math.round(((tot - ns) / tot) * 100) : 0,
        };
      }),
      currentMonth: {
        totalConsultations: totalConsult,
        conversionRate: totalConsult > 0 ? Math.round(((totalConsult - noSale) / totalConsult) * 100) : 0,
        trial:    trialCount,
        regNew,
        regRenew,
        noSale,
        trialRate:    totalConsult > 0 ? Math.round((trialCount / totalConsult) * 100) : 0,
        regNewRate:   totalConsult > 0 ? Math.round((regNew    / totalConsult) * 100) : 0,
        regRenewRate: totalConsult > 0 ? Math.round((regRenew  / totalConsult) * 100) : 0,
        noSaleRate:   totalConsult > 0 ? Math.round((noSale    / totalConsult) * 100) : 0,
      },
      monthlyAppSignups: monthlyAppSignups.map((r: any) => ({
        month: r.month,
        count: Number(r.count) || 0,
      })),
      currentMonthAppSignups: Number(currentMonthSignup?.cnt) || 0,
      totalRegisteredMembers:    Number(registeredCount.cnt) || 0,
      trialMemberCount,
      trialConversionCount,
      trialConversionRate: calcTrialConversionRatePercent(
        trialConversionCount,
        trialMemberCount,
      ),
      afterConsultNoPayRate:     totalConsult > 0 ? Math.round((noSale / totalConsult) * 100) : 0,
      afterConsultNoRegCount:    noSale,
    };
  }

  // ────────────────────────────────────────────────────────────────
  // Screen 2: 성과증명 — 회원별 최고/최저 기록 (ROM: 이번 달, 나머지: 최근 3개월)
  // type:      'neck' | 'pelvis' | 'shoulder' | 'rom'
  // direction: 'top' (상위, 편차 가장 작은) | 'bottom' (하위, 편차 가장 큰)
  // ────────────────────────────────────────────────────────────────
  async getPerformanceRecordsByMember(
    trainerId: string,
    memberId: string,
    type: 'neck' | 'pelvis' | 'shoulder' | 'rom',
    direction: 'top' | 'bottom',
  ) {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    // 트레이너 소속 회원인지 확인
    const [memberRow] = await this.dataSource.query(`
      SELECT u.name AS memberName
      FROM   trainer_users tu
      INNER JOIN users u
        ON  u.id         = tu.member_id
        AND u.deleted_at IS NULL
      WHERE tu.trainer_id = ?
        AND tu.member_id  = ?
        AND tu.status     = 'ACTIVE'
        AND tu.deleted_at IS NULL
      LIMIT 1
    `, [trainerId, memberId]);

    if (!memberRow) {
      return { memberName: null, record: null };
    }

    if (type === 'rom') {
      // ROM: 이번 달 측정 전체 — score 높은(top) / 낮은(bottom) 순
      const orderDir = direction === 'top' ? 'DESC' : 'ASC';
      const rows = await this.dataSource.query(`
        SELECT
          pr.id                                                      AS reportId,
          'PRECISION'                                                AS reportType,
          pr.name                                                    AS itemName,
          pr.created_at                                              AS measuredAt,
          ROUND(pr.analysis_data->>'$.romInfo.measuredAngle', 1)    AS measuredAngle,
          pr.score                                                   AS score,
          pr.level                                                   AS level
        FROM precision_reports pr
        WHERE pr.trainer_id  = ?
          AND pr.user_id     = ?
          AND pr.created_at >= ?
          AND pr.created_at  < ?
          AND pr.deleted_at  IS NULL
          AND pr.type NOT IN ('BODY','SPINAL_ALIGNMENT_TEST','OVERHEAD_SQUAT_TEST','BALANCE_TEST')
        ORDER BY pr.score ${orderDir}
      `, [trainerId, memberId, startOfMonth, nextMonth]);

      return {
        memberName: memberRow.memberName,
        records: rows.map((r: any) => ({
          reportId:   r.reportId,
          reportType: r.reportType,
          itemName:   r.itemName || '',
          measuredAt: r.measuredAt,
          value:      Number(r.score) || 0,
          measuredAngle: r.measuredAngle !== null ? Number(r.measuredAngle) : null,
          score:      Number(r.score) || 0,
          level:      r.level || '',
        })),
      };
    }

    // 거북목 / 골반 비대칭 / 어깨 비대칭 — body_reports
    // top(상위): 편차 가장 작은(0에 가까운) → ASC
    // bottom(하위): 편차 가장 큰 → DESC
    const scoreColMap: Record<string, string> = {
      neck:     'br.neck_score',
      pelvis:   'br.pelvis_asymmetry_score',
      shoulder: 'br.shoulder_asymmetry_score',
    };
    const labelMap: Record<string, string> = {
      neck:     '거북목',
      pelvis:   '골반 비대칭',
      shoulder: '어깨 비대칭',
    };
    const scoreCol = scoreColMap[type];
    const orderDir = direction === 'top' ? 'ASC' : 'DESC';

    const rows = await this.dataSource.query(`
      SELECT
        br.id               AS reportId,
        'BODY'              AS reportType,
        '${labelMap[type]}' AS itemName,
        br.created_at       AS measuredAt,
        ${scoreCol}         AS value
      FROM body_reports br
      WHERE br.trainer_id  = ?
        AND br.user_id     = ?
        AND br.created_at >= ?
        AND br.created_at  < ?
        AND br.deleted_at  IS NULL
      ORDER BY ${scoreCol} ${orderDir}
    `, [trainerId, memberId, startOfMonth, nextMonth]);

    return {
      memberName: memberRow.memberName,
      records: rows.map((r: any) => ({
        reportId:   r.reportId,
        reportType: r.reportType,
        itemName:   r.itemName,
        measuredAt: r.measuredAt,
        value:      r.value !== null ? Number(r.value) : null,
      })),
    };
  }
}
