import { Module } from '@nestjs/common';
import { TrainerDashboardController } from './trainer-dashboard.controller';
import { TrainerDashboardService } from './trainer-dashboard.service';

@Module({
  controllers: [TrainerDashboardController],
  providers:   [TrainerDashboardService],
  exports:       [TrainerDashboardService],
})
export class DashboardModule {}
