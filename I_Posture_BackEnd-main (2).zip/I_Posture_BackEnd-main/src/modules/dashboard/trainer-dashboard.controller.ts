import { Controller, Get, Param, Req, UseGuards } from '@nestjs/common';
import { Request } from 'express';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { TrainerDashboardService } from './trainer-dashboard.service';

@Controller('dashboard/trainer')
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
export class TrainerDashboardController {
  constructor(private readonly trainerDashboardService: TrainerDashboardService) {}

  /**
   * Screen 1 — 회원 운영 관리
   * GET /api/v1/dashboard/trainer/member-management
   *
   * Returns:
   * - lesson: 이번 달 출석률/결석률
   * - retentionRisk: 수업/측정 빈도 낮은 TOP5, 휴면 회원 수
   * - upcomingSchedules: 오늘 ~ 3일치 예약 현황
   */
  @Get('member-management')
  async getMemberManagement(@Req() req: Request) {
    const trainerId = (req.user as any).id as string;
    return this.trainerDashboardService.getMemberManagement(trainerId);
  }

  /**
   * Screen 2 — 성과 증명 (Before/After & Outcomes)
   * GET /api/v1/dashboard/trainer/performance
   *
   * Returns:
   * - totalComparison: 전후비교 총합점수 개선도 TOP5 / 하위5
   * - bodyComparison: 체형종합 점수 개선도 TOP5 / 하위5
   * - turtleNeck: 거북목 각도 개선 TOP3
   * - pelvisAsymmetry: 골반 비대칭 개선 TOP3
   * - shoulderAsymmetry: 어깨 비대칭 개선 TOP3
   * - rom: ROM(가동범위) 하위 TOP3 (이번 달 score 최저 3명)
   */
  @Get('performance')
  async getPerformance(@Req() req: Request) {
    const trainerId = (req.user as any).id as string;
    return this.trainerDashboardService.getPerformance(trainerId);
  }

  /**
   * Screen 2 — 우리 센터 남은 데이터
   * GET /api/v1/dashboard/trainer/storage
   *
   * Returns:
   * - totalCapacity / usedCapacity / allocatedCapacity / remainingCapacity (bytes)
   * - myUsage: 트레이너 본인 사용량 (bytes)
   * - allocatedMemberCount / memberAllocatedCapacity: 이용권 발급 중 회원 정보 (bytes)
   */
  @Get('storage')
  async getStorage(@Req() req: Request) {
    const trainerId = (req.user as any).id as string;
    return this.trainerDashboardService.getStorage(trainerId);
  }

  /**
   * Screen 3 — 등록/매출 퍼널 (트래킹 노트 기반)
   * GET /api/v1/dashboard/trainer/sales-funnel
   *
   * Returns:
   * - monthlyTrends: 최근 6개월 월별 등록·미등록 추이
   * - currentMonth: 이번 달 결제율 / 전환율 / 상담 통계
   * - totalRegisteredMembers: 총 등록 회원 수
   * - trialMemberCount: 당월 체험 명수 ∪ 당월 전환 명수 (전환율 분모)
   * - trialConversionCount: 당월 신규·재등록 전환 명수, 체험은 이전 달이어도 됨 (전환율 분자)
   * - trialConversionRate: 체험수업 등록 전환율 (분자÷분모×100, 전환 월 기준)
   * - afterConsultNoPayRate: 상담 후 미결제율
   * - afterConsultNoRegCount: 상담 후 미등록 수
   */
  @Get('sales-funnel')
  async getSalesFunnel(@Req() req: Request) {
    const trainerId = (req.user as any).id as string;
    return this.trainerDashboardService.getSalesFunnel(trainerId);
  }

  /**
   * Screen 2 — 성과증명 최고/최저 기록 네비게이션 (ROM: 이번 달, 나머지: 최근 3개월)
   * GET /api/v1/dashboard/trainer/performance/records/:memberId/:type/:direction
   * type:      neck | pelvis | shoulder | rom
   * direction: top (상위, 편차 가장 작은) | bottom (하위, 편차 가장 큰)
   *
   * Returns:
   * - memberName
   * - records: [{ reportId, reportType, itemName, measuredAt, value(ROM=도달률%), measuredAngle?, score?, level? }, ...]
   */
  @Get('performance/records/:memberId/:type/:direction')
  async getPerformanceRecordsByMember(
    @Req() req: Request,
    @Param('memberId') memberId: string,
    @Param('type') type: string,
    @Param('direction') direction: string,
  ) {
    const trainerId = (req.user as any).id as string;
    const validTypes = ['neck', 'pelvis', 'shoulder', 'rom'] as const;
    const validDirs  = ['top', 'bottom'] as const;
    const resolvedType = validTypes.includes(type as any)
      ? (type as typeof validTypes[number]) : 'rom';
    const resolvedDir = validDirs.includes(direction as any)
      ? (direction as typeof validDirs[number]) : 'bottom';
    return this.trainerDashboardService.getPerformanceRecordsByMember(
      trainerId, memberId, resolvedType, resolvedDir,
    );
  }
}
