import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { LessonStatus, ScheduleEntity } from '../../database/entities/schedule.entity';
import { SequenceEntity } from '../../database/entities/sequence.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { BookingStatus, ScheduleBookingEntity } from '../../database/entities/schedule-booking.entity';
import { IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { CreateScheduleDto, FindSchedulesDto, ScheduleListItemDto, ScheduleSortOrder, UpdateScheduleDto, BulkNoshowDto, BulkCompleteDto } from './schedule.dto';
import { buildPaging } from '../../common/response/response.helper';
import { IPageData } from '../../common/response/response.interface';

@Injectable()
export class ScheduleService {
  constructor(
    @InjectRepository(ScheduleEntity)
    private readonly scheduleRepo: Repository<ScheduleEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(ScheduleBookingEntity)
    private readonly bookingRepo: Repository<ScheduleBookingEntity>,
  ) {}

  /**
   * 나의 전체 일정 목록 조회 (트레이너 본인)
   */
  async findAll(trainerId: string, dto: FindSchedulesDto): Promise<IPageData<ScheduleListItemDto>> {
    const { page = 1, limit = 10, startDate, endDate, groupId, search, sort = ScheduleSortOrder.DATE_ASC } = dto;
    
    const qb = this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('user.managedIdentityLinks', 'identityLink')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.trainerId = :trainerId', { trainerId });

    if (startDate) qb.andWhere('schedule.startTime >= :startDate', { startDate });
    if (endDate) qb.andWhere('schedule.endTime <= :endDate', { endDate });
    if (groupId) qb.andWhere('schedule.groupId = :groupId', { groupId });
    if (search) qb.andWhere('user.name LIKE :search', { search: `%${search}%` });

    const sortDirection = sort === ScheduleSortOrder.DATE_DESC ? 'DESC' : 'ASC';
    qb.orderBy('schedule.startTime', sortDirection)
      .skip((page - 1) * limit)
      .take(limit);

    const [schedules, total] = await qb.getManyAndCount();

    const items = schedules.map(s => this.mapToDto(s));
    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 시퀀스 등록용 일정 목록 조회 (KST 기준 당일 이후, 페이징 없음)
   */
  async findForSequenceRegistration(trainerId: string): Promise<ScheduleListItemDto[]> {
    // KST 기준 오늘 00:00:00을 UTC로 변환
    const nowUtc = new Date();
    const kstOffset = 9 * 60 * 60 * 1000;
    const nowKst = new Date(nowUtc.getTime() + kstOffset);
    const todayKstStr = nowKst.toISOString().slice(0, 10); // YYYY-MM-DD
    const todayKstStart = new Date(`${todayKstStr}T00:00:00+09:00`);

    const qb = this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('user.managedIdentityLinks', 'identityLink')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.trainerId = :trainerId', { trainerId })
      .andWhere('schedule.startTime >= :todayKstStart', { todayKstStart: todayKstStart.toISOString() })
      .orderBy('schedule.startTime', 'ASC');

    const schedules = await qb.getMany();
    return schedules.map(s => this.mapToDto(s));
  }

  /**
   * 특정 회원의 일정 목록 조회 (트레이너용)
   */
  async findAllByMember(trainerId: string, memberId: string, dto: FindSchedulesDto): Promise<IPageData<ScheduleListItemDto>> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);
    
    const { page = 1, limit = 10, startDate, endDate, search, sort = ScheduleSortOrder.DATE_ASC } = dto;

    const qb = this.scheduleRepo.createQueryBuilder('schedule')
      .innerJoin('schedule.bookings', 'booking', 'booking.userId = :memberId', { memberId })
      .leftJoinAndSelect('schedule.bookings', 'all_bookings') // 전체 예약자 정보 로드
      .leftJoinAndSelect('all_bookings.user', 'user')
      .leftJoinAndSelect('user.managedIdentityLinks', 'identityLink')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.trainerId = :trainerId', { trainerId });

    if (startDate) qb.andWhere('schedule.startTime >= :startDate', { startDate });
    if (endDate) qb.andWhere('schedule.endTime <= :endDate', { endDate });
    if (search) qb.andWhere('user.name LIKE :search', { search: `%${search}%` });

    const sortDirection = sort === ScheduleSortOrder.DATE_DESC ? 'DESC' : 'ASC';
    qb.orderBy('schedule.startTime', sortDirection)
      .skip((page - 1) * limit)
      .take(limit);

    const [schedules, total] = await qb.getManyAndCount();
    
    const items = schedules.map(s => this.mapToDto(s));
    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 일정 상세 조회 (트레이너 본인)
   */
  async findOne(trainerId: string, scheduleId: string): Promise<ScheduleEntity> {
    const schedule = await this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.id = :scheduleId', { scheduleId })
      .andWhere('schedule.trainerId = :trainerId', { trainerId })
      .getOne();

    if (!schedule) {
      throw new NotFoundException('일정을 찾을 수 없거나 권한이 없습니다.');
    }

    return schedule;
  }

  /**
   * 특정 회원의 일정 상세 조회 (트레이너용)
   */
  async findOneByMember(trainerId: string, memberId: string, scheduleId: string): Promise<ScheduleEntity> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);

    const qb = this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.id = :scheduleId', { scheduleId })
      .andWhere('schedule.trainerId = :trainerId', { trainerId });

    const schedule = await qb.getOne();

    if (!schedule) {
      throw new NotFoundException('일정을 찾을 수 없습니다.');
    }
    // 해당 회원이 이 일정에 예약되어 있는지 확인
    if (!schedule.bookings.some(b => b.userId === memberId)) {
      throw new ForbiddenException('해당 회원은 이 일정에 포함되어 있지 않습니다.');
    }
    return schedule;
  }

  /**
   * 일정 등록
   */
  @Transactional()
  async create(trainerId: string, dto: CreateScheduleDto): Promise<ScheduleEntity> {
    await this.checkTrainerMemberRelationship(trainerId, dto.userId);
    if (dto.sequenceId) {
      await this.assertSequenceBelongsToTrainer(trainerId, dto.sequenceId);
    }

    const { userId, ...scheduleData } = dto;

    // 일정 생성
    const schedule = this.scheduleRepo.create({ ...scheduleData, trainerId });
    const savedSchedule = await this.scheduleRepo.save(schedule);

    // 예약 정보 생성
    const booking = this.bookingRepo.create({ scheduleId: savedSchedule.id, userId });
    await this.bookingRepo.save(booking);

    // 전체 정보 조회 후 반환 (QueryBuilder 사용)
    const result = await this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.id = :id', { id: savedSchedule.id })
      .getOne();

    if (!result) {
      throw new NotFoundException('생성된 일정을 찾을 수 없습니다.');
    }

    return result;
  }

  /**
   * 특정 회원에게 일정 등록 (트레이너용)
   */
  @Transactional()
  async createForMember(trainerId: string, memberId: string, dto: CreateScheduleDto): Promise<ScheduleEntity> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);

    const { userId, ...scheduleData } = dto;
    if (userId !== memberId) {
      throw new BadRequestException('URL의 회원 ID와 요청 데이터의 회원 ID가 일치하지 않습니다.');
    }
    if (dto.sequenceId) {
      await this.assertSequenceBelongsToTrainer(trainerId, dto.sequenceId);
    }

    const schedule = this.scheduleRepo.create({ ...scheduleData, trainerId });
    const savedSchedule = await this.scheduleRepo.save(schedule);

    // 예약 정보 생성
    const booking = this.bookingRepo.create({ scheduleId: savedSchedule.id, userId: memberId });
    await this.bookingRepo.save(booking);

    const result = await this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .where('schedule.id = :id', { id: savedSchedule.id })
      .getOne();

    if (!result) {
      throw new NotFoundException('생성된 일정을 다시 조회하는 데 실패했습니다.');
    }
    return result;
  }

  /**
   * 특정 회원의 일정 수정 (트레이너용)
   */
  async updateForMember(trainerId: string, memberId: string, scheduleId: string, dto: UpdateScheduleDto): Promise<ScheduleEntity> {
    const schedule = await this.findOneByMember(trainerId, memberId, scheduleId);

    // userId는 수정하지 않음 (회원 변경 불가)
    const { userId, ...updateData } = dto as any;

    // 시퀀스를 변경하는 경우 해당 트레이너의 시퀀스인지 검증 (isActive 무관)
    if (updateData.sequenceId && updateData.sequenceId !== null && updateData.sequenceId !== schedule.sequenceId) {
      await this.assertSequenceBelongsToTrainer(trainerId, updateData.sequenceId);
    }

    const updatePayload: Partial<ScheduleEntity> = {};
    if (updateData.startTime !== undefined) updatePayload.startTime = updateData.startTime;
    if (updateData.endTime !== undefined) updatePayload.endTime = updateData.endTime;
    if (updateData.sequenceId !== undefined) updatePayload.sequenceId = updateData.sequenceId;
    if (updateData.memo !== undefined) updatePayload.memo = updateData.memo;
    await this.scheduleRepo.update({ id: schedule.id }, updatePayload);
    return this.scheduleRepo.findOne({ where: { id: schedule.id } }) as Promise<ScheduleEntity>;
  }

  /**
   * 특정 회원의 일정 삭제 (트레이너용)
   */
  @Transactional()
  async deleteForMember(trainerId: string, memberId: string, scheduleId: string): Promise<{ success: boolean }> {
    const schedule = await this.findOneByMember(trainerId, memberId, scheduleId);
    await this.softDeleteScheduleWithBookings(schedule.id);
    return { success: true };
  }

  /**
   * 일정 수정 (트레이너 본인)
   */
  async update(trainerId: string, scheduleId: string, dto: UpdateScheduleDto): Promise<ScheduleEntity> {
    const schedule = await this.scheduleRepo.createQueryBuilder('schedule')
      .leftJoinAndSelect('schedule.bookings', 'booking')
      .leftJoinAndSelect('booking.user', 'user')
      .leftJoinAndSelect('schedule.group', 'group')
      .leftJoinAndSelect('schedule.sequence', 'sequence')
      .where('schedule.id = :scheduleId', { scheduleId })
      .andWhere('schedule.trainerId = :trainerId', { trainerId })
      .getOne();

    if (!schedule) {
      throw new NotFoundException('일정을 찾을 수 없거나 권한이 없습니다.');
    }

    // userId는 수정하지 않음 (회원 변경 불가)
    const { userId, ...updateData } = dto as any;

    // 시퀀스를 변경하는 경우 해당 트레이너의 시퀀스인지 검증 (isActive 무관)
    if (updateData.sequenceId && updateData.sequenceId !== null && updateData.sequenceId !== schedule.sequenceId) {
      await this.assertSequenceBelongsToTrainer(trainerId, updateData.sequenceId);
    }

    const updatePayload: Partial<ScheduleEntity> = {};
    if (updateData.startTime !== undefined) updatePayload.startTime = updateData.startTime;
    if (updateData.endTime !== undefined) updatePayload.endTime = updateData.endTime;
    if (updateData.sequenceId !== undefined) updatePayload.sequenceId = updateData.sequenceId;
    if (updateData.memo !== undefined) updatePayload.memo = updateData.memo;
    await this.scheduleRepo.update({ id: scheduleId, trainerId }, updatePayload);
    return this.scheduleRepo.findOne({ where: { id: scheduleId, trainerId } }) as Promise<ScheduleEntity>;
  }

  /**
   * 일정 삭제 (트레이너 본인)
   */
  @Transactional()
  async delete(trainerId: string, scheduleId: string): Promise<{ success: boolean }> {
    const schedule = await this.scheduleRepo.findOne({
      where: { id: scheduleId, trainerId },
    });

    if (!schedule) {
      throw new NotFoundException('일정을 찾을 수 없거나 권한이 없습니다.');
    }

    await this.softDeleteScheduleWithBookings(schedule.id);
    return { success: true };
  }



  // --- Helper Methods ---
  private async checkTrainerMemberRelationship(trainerId: string, memberId: string): Promise<void> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원에 대한 권한이 없습니다.');
    }
  }

  private async assertSequenceBelongsToTrainer(trainerId: string, sequenceId: string): Promise<void> {
    const sequenceRepo = this.scheduleRepo.manager.getRepository(SequenceEntity);
    const sequence = await sequenceRepo.findOne({
      where: { id: sequenceId, trainerId },
    });
    if (!sequence) {
      throw new NotFoundException('시퀀스를 찾을 수 없거나 권한이 없습니다.');
    }
  }

  private async softDeleteScheduleWithBookings(scheduleId: string): Promise<void> {
    await this.bookingRepo.softDelete({ scheduleId });
    await this.scheduleRepo.softDelete(scheduleId);
  }

  private mapToDto(schedule: ScheduleEntity): ScheduleListItemDto {
    const booking = schedule.bookings?.[0]; // 1:1 수업의 경우 첫번째 예약자
    const member = booking?.user;

    const toKst = (utcDate: Date | string) => {
      const d = new Date(utcDate);
      // KST = UTC+9
      d.setMinutes(d.getMinutes() + d.getTimezoneOffset() + 540);
      return d;
    };

    const kstStart = toKst(schedule.startTime);
    const kstEnd   = toKst(schedule.endTime);

    const pad = (n: number) => String(n).padStart(2, '0');
    const dateStr     = `${kstStart.getFullYear()}-${pad(kstStart.getMonth() + 1)}-${pad(kstStart.getDate())}`;
    const startTimeStr = `${pad(kstStart.getHours())}:${pad(kstStart.getMinutes())}`;
    const endTimeStr   = `${pad(kstEnd.getHours())}:${pad(kstEnd.getMinutes())}`;
    const dayOfWeek   = kstStart.toLocaleDateString('ko-KR', { weekday: 'long' });

    return {
      id: schedule.id,
      date: dateStr,
      dayOfWeek,
      startTime: startTimeStr,
      endTime: endTimeStr,
      memberId: member?.id,
      memberName: member?.name ?? '회원 없음',
      memberStatus: this.resolveMemberStatus(member),
      groupId: schedule.groupId,
      groupName: schedule.group?.name,
      sequenceId: schedule.sequenceId,
      sequenceTitle: schedule.sequence?.title,
      status: schedule.lessonStatus,
      memo: schedule.memo,
    };
  }

  private resolveMemberStatus(member: any): string {
    if (!member || !member.offlinePaymentStatus) return '미결제';
    const isLinked = member.managedIdentityLinks?.some(
      (l: any) => l.status === IdentityLinkStatus.LINKED,
    );
    return isLinked ? '결제/앱 연동' : '결제/앱 미연동';
  }

  /**
   * 취소/차감 처리 - 어떤 상태든 NOSHOW로 변경 (다건)
   */
  async bulkNoshow(trainerId: string, dto: BulkNoshowDto): Promise<{ success: boolean; affected: number }> {
    const schedules = await this.scheduleRepo.find({
      where: { id: In(dto.scheduleIds), trainerId },
    });
    if (schedules.length !== dto.scheduleIds.length) {
      throw new ForbiddenException('일부 일정을 찾을 수 없거나 권한이 없습니다.');
    }

    await this.bookingRepo.createQueryBuilder()
      .update()
      .set({ status: BookingStatus.NOSHOW })
      .where('schedule_id IN (:...scheduleIds)', { scheduleIds: dto.scheduleIds })
      .execute();
    const result = await this.scheduleRepo.update(
      { id: In(dto.scheduleIds), trainerId },
      { lessonStatus: LessonStatus.NOSHOW },
    );

    return { success: true, affected: result.affected ?? 0 };
  }

  /**
   * 완료 처리 - NOSHOW 상태인 일정만 COMPLETED로 복구 (다건)
   */
  async bulkComplete(trainerId: string, dto: BulkCompleteDto): Promise<{ success: boolean; affected: number }> {
    const schedules = await this.scheduleRepo.find({
      where: { id: In(dto.scheduleIds), trainerId },
    });
    if (schedules.length !== dto.scheduleIds.length) {
      throw new ForbiddenException('일부 일정을 찾을 수 없거나 권한이 없습니다.');
    }

    const nonNoshow = schedules.filter(s => s.lessonStatus !== LessonStatus.NOSHOW);
    if (nonNoshow.length > 0) {
      throw new BadRequestException('취소/차감 상태인 일정만 완료 처리할 수 있습니다.');
    }

    await this.bookingRepo.createQueryBuilder()
      .update()
      .set({ status: BookingStatus.APPLIED })
      .where('schedule_id IN (:...scheduleIds)', { scheduleIds: dto.scheduleIds })
      .execute();
    const result = await this.scheduleRepo.update(
      { id: In(dto.scheduleIds), trainerId },
      { lessonStatus: LessonStatus.COMPLETED },
    );

    return { success: true, affected: result.affected ?? 0 };
  }
}
