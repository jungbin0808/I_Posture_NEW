import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ScheduleService } from './schedule.service';
import { ScheduleController } from './schedule.controller';
import { ScheduleTaskService } from './schedule.task';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { ScheduleBookingEntity } from '../../database/entities/schedule-booking.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ScheduleEntity,
      TrainerUserEntity,
      ScheduleBookingEntity,
    ]),
  ],
  controllers: [ScheduleController],
  providers: [ScheduleService, ScheduleTaskService],
  exports: [ScheduleService],
})
export class ScheduleModule {}
