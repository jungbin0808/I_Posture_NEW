import { IsArray, IsDateString, IsEnum, IsNotEmpty, IsOptional, IsString, IsUUID, Min } from "class-validator";
import { Type } from "class-transformer";

export enum ScheduleSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindSchedulesDto {
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page: number = 1;

  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit: number = 10;

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsString()
  groupId?: string;

  @IsOptional()
  @IsDateString()
  startDate?: string;

  @IsOptional()
  @IsDateString()
  endDate?: string;

  @IsOptional()
  @IsEnum(ScheduleSortOrder)
  sort: ScheduleSortOrder = ScheduleSortOrder.DATE_ASC;
}

export class ScheduleListItemDto {
  id!: string;
  date!: string; // YYYY-MM-DD
  dayOfWeek!: string; // 요일
  startTime!: string; // HH:mm
  endTime!: string; // HH:mm
  memberId?: string; // 회원 ID (추가)
  memberName!: string; // 회원명
  memberStatus?: string; // 회원 상태
  groupId?: string; // 그룹 ID
  groupName?: string; // 그룹명
  sequenceId?: string; // 시퀀스 ID
  sequenceTitle?: string; // 시퀀스명
  status!: string; // 수업 상태 (예정, 완료, 취소)
  memo?: string; // 비고
}

export class CreateScheduleDto {
  @IsString()
  @IsNotEmpty()
  userId!: string;

  @IsDateString()
  @IsNotEmpty()
  startTime!: string;

  @IsDateString()
  @IsNotEmpty()
  endTime!: string;

  @IsOptional()
  @IsString()
  sequenceId?: string;

  @IsOptional()
  @IsString()
  memo?: string;
}

export class UpdateScheduleDto {
  // userId는 수정 시 무시됨 (회원 변경 불가)
  @IsOptional()
  @IsString()
  userId?: string; // 클라이언트에서 보내더라도 무시됨

  @IsOptional()
  @IsDateString()
  startTime?: string;

  @IsOptional()
  @IsDateString()
  endTime?: string;

  @IsOptional()
  @IsString()
  sequenceId?: string | null; // null 허용

  @IsOptional()
  @IsString()
  memo?: string;
}

export class BulkNoshowDto {
  @IsArray()
  @IsUUID('all', { each: true })
  @IsNotEmpty()
  scheduleIds!: string[];
}

export class BulkCompleteDto {
  @IsArray()
  @IsUUID('all', { each: true })
  @IsNotEmpty()
  scheduleIds!: string[];
}

export class AddSchedulesToGroupDto {
  @IsNotEmpty()
  @IsString({ each: true })
  scheduleIds!: string[];
}

export class RemoveSchedulesFromGroupDto {
  @IsNotEmpty()
  @IsString({ each: true })
  scheduleIds!: string[];
}

export class UpdateScheduleSequenceDto {
  @IsString()
  @IsNotEmpty()
  sequenceId!: string;
}

