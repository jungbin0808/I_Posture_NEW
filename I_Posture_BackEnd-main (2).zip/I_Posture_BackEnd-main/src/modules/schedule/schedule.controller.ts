import { Controller, Get, Post, Put, Delete, Body, Param, Query, Request, UseGuards } from '@nestjs/common';
import { ApiOperation, ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { ScheduleService } from './schedule.service';
import { BulkCompleteDto, BulkNoshowDto, CreateScheduleDto, FindSchedulesDto, ScheduleListItemDto, UpdateScheduleDto } from './schedule.dto';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { SuccessResponse } from '../../common/response/response.helper';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { UserEntity } from '../../database/entities/user.entity';

@ApiTags('Schedules')
@ApiBearerAuth()
@Controller('schedules')
@UseGuards(AccessTokenGuard, RolesGuard)
export class ScheduleController {
  constructor(private readonly scheduleService: ScheduleService) {}

  @ApiOperation({ summary: '나의 전체 일정 목록 조회 (트레이너 본인)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get()
  async findMySchedules(@Request() req: any, @Query() dto: FindSchedulesDto): Promise<IPageResponse<ScheduleListItemDto>> {
    const pageData = await this.scheduleService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '시퀀스 등록용 일정 목록 조회 (KST 기준 당일 이후, 페이징 없음)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('for-sequence')
  async findForSequenceRegistration(
    @Request() req: { user: UserEntity },
  ): Promise<ISuccessResponse<ScheduleListItemDto[]>> {
    const data = await this.scheduleService.findForSequenceRegistration(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 상세 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get(':scheduleId')
  async findOne(
    @Request() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.findOne(req.user.id, scheduleId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 등록' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Post()
  async create(
    @Request() req: { user: UserEntity },
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 노쇼 처리 (취소/차감) - 어떤 상태든 가능, 다건' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Put('noshow')
  async bulkNoshow(
    @Request() req: { user: UserEntity },
    @Body() dto: BulkNoshowDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.bulkNoshow(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 완료 처리 - 취소/차감 상태일 때만 가능, 다건' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Put('complete')
  async bulkComplete(
    @Request() req: { user: UserEntity },
    @Body() dto: BulkCompleteDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.bulkComplete(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 수정' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Put(':scheduleId')
  async update(
    @Request() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.update(req.user.id, scheduleId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 삭제' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Delete(':scheduleId')
  async delete(
    @Request() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.delete(req.user.id, scheduleId);
    return SuccessResponse(data);
  }

  // --- 특정 회원 일정 관리 (트레이너용) ---

  @ApiOperation({ summary: '특정 회원의 일정 목록 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId')
  async findAllByMember(
    @Request() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() dto: FindSchedulesDto,
  ): Promise<IPageResponse<ScheduleListItemDto>> {
    const pageData = await this.scheduleService.findAllByMember(req.user.id, memberId, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '특정 회원의 일정 상세 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId/:scheduleId')
  async findOneByMember(
    @Request() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.findOneByMember(req.user.id, memberId, scheduleId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원에게 일정 등록' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Post('member/:memberId')
  async createForMember(
    @Request() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.createForMember(req.user.id, memberId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원의 일정 수정' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Put('member/:memberId/:scheduleId')
  async updateForMember(
    @Request() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.updateForMember(req.user.id, memberId, scheduleId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원의 일정 삭제' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Delete('member/:memberId/:scheduleId')
  async deleteForMember(
    @Request() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<any>> {
    const data = await this.scheduleService.deleteForMember(req.user.id, memberId, scheduleId);
    return SuccessResponse(data);
  }
}
