import { Injectable } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { LessonStatus, ScheduleEntity } from '../../database/entities/schedule.entity';
import { BookingStatus, ScheduleBookingEntity } from '../../database/entities/schedule-booking.entity';

@Injectable()
export class ScheduleTaskService {
  constructor(
    @InjectRepository(ScheduleEntity)
    private readonly scheduleRepo: Repository<ScheduleEntity>,
    @InjectRepository(ScheduleBookingEntity)
    private readonly bookingRepo: Repository<ScheduleBookingEntity>,
  ) {}

  /**
   * 매 10분마다 종료 시간이 지난 RESERVED 일정을 COMPLETED로 자동 변경
   */
  @Cron('*/10 * * * *')
  @Transactional()
  async autoCompleteSchedules(): Promise<void> {
    const now = new Date();

    const targets = await this.scheduleRepo.createQueryBuilder('schedule')
      .select('schedule.id', 'id')
      .where('schedule.lesson_status = :status', { status: LessonStatus.RESERVED })
      .andWhere('schedule.end_time < :now', { now })
      .andWhere('schedule.deleted_at IS NULL')
      .getRawMany<{ id: string }>();

    const scheduleIds = targets.map((row) => row.id);
    if (scheduleIds.length === 0) return;

    await this.bookingRepo.update(
      { scheduleId: In(scheduleIds) },
      { status: BookingStatus.APPLIED },
    );
    await this.scheduleRepo.update(
      { id: In(scheduleIds) },
      { lessonStatus: LessonStatus.COMPLETED },
    );
  }
}
