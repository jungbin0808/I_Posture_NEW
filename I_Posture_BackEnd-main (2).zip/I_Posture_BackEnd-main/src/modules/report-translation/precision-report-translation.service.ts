import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { GoogleTranslateService } from './google-translate.service';
import { translateReportPayload } from './helpers/report-payload-translate.helper';

@Injectable()
export class PrecisionReportTranslationService {
  constructor(
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    private readonly googleTranslateService: GoogleTranslateService,
  ) {}

  async translatePayloadToEnglish(payload: Record<string, unknown>): Promise<Record<string, unknown>> {
    return translateReportPayload(payload, (texts) => this.googleTranslateService.translateTexts(texts));
  }

  async persistDisplayPayloadEn(reportId: string, payload: any): Promise<void> {
    await this.precisionReportRepo.update(reportId, {
      displayPayloadEn: payload,
    });
  }

  async getDisplayPayloadEn(reportId: string, memberId: string): Promise<any | null> {
    const report = await this.precisionReportRepo.findOne({
      where: { id: reportId, userId: memberId },
      select: ['id', 'displayPayloadEn'],
    });
    if (!report) {
      throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
    }
    return report.displayPayloadEn ?? null;
  }
}
