import {
  GOOGLE_TRANSLATE_BATCH_SIZE,
  GOOGLE_TRANSLATE_MAX_CHARS_PER_BATCH,
  REPORT_PAYLOAD_SKIP_SUBTREE_KEYS,
  REPORT_PAYLOAD_SKIP_VALUE_KEYS,
  REPORT_PAYLOAD_SKIP_VALUE_PATHS,
  REPORT_PAYLOAD_TRANSLATION_GLOSSARY,
} from '../constants/report-payload-translate.constants';

export interface TranslatableStringEntry {
  path: string;
  text: string;
}

function isProbablyNonTranslatable(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed) {
    return true;
  }
  if (/^https?:\/\//i.test(trimmed)) {
    return true;
  }
  if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(trimmed)) {
    return true;
  }
  if (!/[가-힣]/.test(trimmed) && /^[A-Z0-9_]+$/.test(trimmed)) {
    return true;
  }
  // 한글 없이 숫자·단위·기호만 있는 표시값 (예: "45° / 90°", "80%")
  if (!/[가-힣]/.test(trimmed) && /^[\d\s.,%°/+\-←→↑↓▼▲():a-zA-Z]+$/.test(trimmed)) {
    return true;
  }
  return false;
}

function shouldSkipTranslatableString(path: string, bareKey: string): boolean {
  if (REPORT_PAYLOAD_SKIP_VALUE_PATHS.some((pattern) => pattern.test(path))) {
    return true;
  }
  return REPORT_PAYLOAD_SKIP_VALUE_KEYS.has(bareKey);
}

function parsePath(path: string): Array<string | number> {
  const result: Array<string | number> = [];
  for (const part of path.split('.')) {
    const match = part.match(/^([^\[]+)(?:\[(\d+)\])?$/);
    if (!match?.[1]) {
      continue;
    }
    result.push(match[1]);
    if (match[2] !== undefined) {
      result.push(Number(match[2]));
    }
  }
  return result;
}

function setValueAtPath(root: unknown, path: string, newValue: string): void {
  const segments = parsePath(path);
  if (segments.length === 0) {
    return;
  }

  let current: unknown = root;
  for (let i = 0; i < segments.length - 1; i++) {
    current = (current as Record<string | number, unknown>)[segments[i]];
  }

  const last = segments[segments.length - 1];
  (current as Record<string | number, unknown>)[last] = newValue;
}

function walkTranslatableStrings(
  node: unknown,
  path: string,
  entries: TranslatableStringEntry[],
): void {
  if (node === null || node === undefined) {
    return;
  }

  if (typeof node === 'string') {
    const key = path.includes('.') ? path.split('.').pop() ?? '' : path;
    const bareKey = key.replace(/\[\d+\]$/, '');
    if (shouldSkipTranslatableString(path, bareKey)) {
      return;
    }
    if (isProbablyNonTranslatable(node)) {
      return;
    }
    entries.push({ path, text: node });
    return;
  }

  if (Array.isArray(node)) {
    node.forEach((item, index) => {
      const childPath = path ? `${path}[${index}]` : `[${index}]`;
      walkTranslatableStrings(item, childPath, entries);
    });
    return;
  }

  if (typeof node === 'object') {
    for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
      if (REPORT_PAYLOAD_SKIP_SUBTREE_KEYS.has(key)) {
        continue;
      }
      const childPath = path ? `${path}.${key}` : key;
      walkTranslatableStrings(value, childPath, entries);
    }
  }
}

/** 체형 리포트 payload 에서 번역 대상 string 만 추출 */
export function extractTranslatableStrings(root: unknown): TranslatableStringEntry[] {
  const entries: TranslatableStringEntry[] = [];
  walkTranslatableStrings(root, '', entries);
  return entries;
}

/** 번역 결과를 원본 payload 구조에 다시 merge */
export function applyTranslations(
  root: unknown,
  entries: TranslatableStringEntry[],
  translations: string[],
): unknown {
  const clone = structuredClone(root);
  entries.forEach((entry, index) => {
    setValueAtPath(clone, entry.path, translations[index]);
  });
  return clone;
}

/**
 * 체형/정밀 리포트 payload 를 영문으로 변환.
 * 용어집(REPORT_PAYLOAD_TRANSLATION_GLOSSARY)에 매칭되는 문자열은 구글 번역 API를 거치지 않고
 * 고정값으로 치환하고, 나머지만 번역 API 결과로 채운다.
 */
export async function translateReportPayload(
  payload: Record<string, unknown>,
  translateTexts: (texts: string[]) => Promise<string[]>,
): Promise<Record<string, unknown>> {
  const entries = extractTranslatableStrings(payload);
  if (entries.length === 0) {
    return structuredClone(payload) as Record<string, unknown>;
  }

  const translatedTexts: string[] = new Array(entries.length);
  const pendingEntries: TranslatableStringEntry[] = [];
  const pendingIndexes: number[] = [];

  entries.forEach((entry, index) => {
    const glossaryHit = REPORT_PAYLOAD_TRANSLATION_GLOSSARY[entry.text.trim()];
    if (glossaryHit !== undefined) {
      translatedTexts[index] = glossaryHit;
    } else {
      pendingEntries.push(entry);
      pendingIndexes.push(index);
    }
  });

  if (pendingEntries.length > 0) {
    const batches = chunkTranslatableEntries(pendingEntries);
    const batchTranslatedTexts: string[] = [];
    for (const batch of batches) {
      const batchResult = await translateTexts(batch.map((entry) => entry.text));
      batchTranslatedTexts.push(...batchResult);
    }
    batchTranslatedTexts.forEach((text, i) => {
      translatedTexts[pendingIndexes[i]] = text;
    });
  }

  return applyTranslations(payload, entries, translatedTexts) as Record<string, unknown>;
}

/** Google API batch 호출 단위로 문자열 분할 */
export function chunkTranslatableEntries(
  entries: TranslatableStringEntry[],
): TranslatableStringEntry[][] {
  const batches: TranslatableStringEntry[][] = [];
  let current: TranslatableStringEntry[] = [];
  let charCount = 0;

  for (const entry of entries) {
    const nextChars = entry.text.length;
    const exceedsBatch =
      current.length >= GOOGLE_TRANSLATE_BATCH_SIZE
      || charCount + nextChars > GOOGLE_TRANSLATE_MAX_CHARS_PER_BATCH;

    if (exceedsBatch && current.length > 0) {
      batches.push(current);
      current = [];
      charCount = 0;
    }

    current.push(entry);
    charCount += nextChars;
  }

  if (current.length > 0) {
    batches.push(current);
  }

  return batches;
}
