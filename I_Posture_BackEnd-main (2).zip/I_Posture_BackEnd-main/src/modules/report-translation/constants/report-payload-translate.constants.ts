/** 하위 트리 전체를 번역 walk 에서 제외 */
export const REPORT_PAYLOAD_SKIP_SUBTREE_KEYS = new Set([
  'landmarks',
  'scoreDetail',
  'combinedContent',
]);

/** 해당 키의 string value 는 번역하지 않음 */
export const REPORT_PAYLOAD_SKIP_VALUE_KEYS = new Set([
  'id',
  'fileUrl',
  'url',
  'assetKey',
  'key',
  'division',
  'relatedType',
  'statusColor',
  'view',
  'part',
  'unit',
  'score',
  'imageNumber',
  'previewWidth',
  'previewHeight',
  'birthDate',
  'shootingDate',
  'issuedAt',
  'createdAt',
  'reportType',
  'min',
  'max',
  'referenceScore',
  'leftRight',
  'frontBack',
]);

/**
 * 구글 번역 API로 보내지 않고 고정 치환하는 용어집.
 * '경미'는 흔한 한국어 인명이기도 해서 구글 번역이 의미 번역(Mild) 대신
 * 음역(Kyungmi)으로 반환하는 문제가 있어 고정 매핑으로 처리한다.
 */
export const REPORT_PAYLOAD_TRANSLATION_GLOSSARY: Record<string, string> = {
  '경미': 'Mild',
};

export const GOOGLE_TRANSLATE_BATCH_SIZE = 100;

/** 특정 경로의 string value 만 번역 제외 (키 기반 skip 보다 우선) */
export const REPORT_PAYLOAD_SKIP_VALUE_PATHS: RegExp[] = [
  /^member\.name$/,
];

export const GOOGLE_TRANSLATE_MAX_CHARS_PER_BATCH = 28000;
