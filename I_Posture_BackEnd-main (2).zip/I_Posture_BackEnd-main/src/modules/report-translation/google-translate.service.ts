import { BadGatewayException, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

interface GoogleTranslateV2Response {
  data?: {
    translations?: Array<{ translatedText: string }>;
  };
  error?: {
    message?: string;
    code?: number;
  };
}

@Injectable()
export class GoogleTranslateService {
  private readonly logger = new Logger(GoogleTranslateService.name);

  constructor(private readonly configService: ConfigService) {}

  /**
   * Google Cloud Translation API v2 — 문자열 배열을 target 언어로 번역.
   * q 파라미터는 POST JSON body 로 전송 (URL 길이 제한 회피).
   */
  async translateTexts(
    texts: string[],
    sourceLanguage = 'ko',
    targetLanguage = 'en',
  ): Promise<string[]> {
    if (texts.length === 0) {
      return [];
    }

    const apiKey = this.configService.get<string>('GOOGLE_TRANSLATE_API_KEY');
    if (!apiKey) {
      throw new Error('GOOGLE_TRANSLATE_API_KEY is not configured');
    }

    const url = `https://translation.googleapis.com/language/translate/v2?key=${encodeURIComponent(apiKey)}`;

    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        q: texts,
        source: sourceLanguage,
        target: targetLanguage,
        format: 'text',
      }),
    });

    const raw = await response.text();
    let body: GoogleTranslateV2Response;

    try {
      body = JSON.parse(raw) as GoogleTranslateV2Response;
    } catch {
      this.logger.error(
        `Google Translate non-JSON response (HTTP ${response.status}): ${raw.slice(0, 300)}`,
      );
      throw new BadGatewayException(
        'Google Translate API 응답을 처리할 수 없습니다. API 키·Cloud Translation API 활성화 여부를 확인해 주세요.',
      );
    }

    if (!response.ok || body.error) {
      const message = body.error?.message ?? `Google Translate HTTP ${response.status}`;
      this.logger.error(message);
      throw new BadGatewayException(message);
    }

    const translations = body.data?.translations ?? [];
    if (translations.length !== texts.length) {
      throw new BadGatewayException(
        `Google Translate returned ${translations.length} items for ${texts.length} inputs`,
      );
    }

    return translations.map((item) => item.translatedText);
  }
}
