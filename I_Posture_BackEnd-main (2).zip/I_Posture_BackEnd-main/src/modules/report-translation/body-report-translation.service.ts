import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { GoogleTranslateService } from './google-translate.service';
import { translateReportPayload } from './helpers/report-payload-translate.helper';

@Injectable()
export class BodyReportTranslationService {
  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    private readonly googleTranslateService: GoogleTranslateService,
  ) {}

  /**
   * 한글 리포트 payload 를 영문으로 번역 (풀 데이터, 트레이너 코멘트 블록은 입력 전 제외 권장).
   */
  async translatePayloadToEnglish(payload: Record<string, unknown>): Promise<Record<string, unknown>> {
    return translateReportPayload(payload, (texts) => this.googleTranslateService.translateTexts(texts));
  }

  /**
   * 영문 payload 를 body_reports.display_payload_en 에 저장.
   */
  async persistDisplayPayloadEn(reportId: string, payload: any): Promise<void> {
    await this.bodyReportRepo.update(reportId, {
      displayPayloadEn: payload,
    });
  }

  async getDisplayPayloadEn(reportId: string): Promise<any | null> {
    const report = await this.bodyReportRepo.findOne({
      where: { id: reportId },
      select: ['id', 'displayPayloadEn'],
    });
    if (!report) {
      throw new NotFoundException('체형측정 리포트를 찾을 수 없습니다.');
    }
    return report.displayPayloadEn ?? null;
  }
}
