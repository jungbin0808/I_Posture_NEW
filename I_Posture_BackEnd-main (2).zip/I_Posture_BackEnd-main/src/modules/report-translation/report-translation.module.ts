import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { BodyReportTranslationService } from './body-report-translation.service';
import { PrecisionReportTranslationService } from './precision-report-translation.service';
import { GoogleTranslateService } from './google-translate.service';

@Module({
  imports: [TypeOrmModule.forFeature([BodyReportEntity, PrecisionReportEntity])],
  providers: [GoogleTranslateService, BodyReportTranslationService, PrecisionReportTranslationService],
  exports: [GoogleTranslateService, BodyReportTranslationService, PrecisionReportTranslationService],
})
export class ReportTranslationModule {}
