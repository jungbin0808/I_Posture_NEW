import {
  BadRequestException,
  Controller,
  Get,
  Param,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { SuccessResponse, buildPaging } from '../../common/response/response.helper';
import { IPageResponse } from '../../common/response/response.interface';
import { CustomExerciseEntity } from '../../database/entities/custom-exercise.entity';
import {
  CustomExerciseService,
  ExerciseCategory,
} from './custom-exercise.service';

@ApiTags('Custom Exercise')
@Controller('custom-exercises')
@UseGuards(AccessTokenGuard)
export class CustomExerciseController {
  constructor(private readonly service: CustomExerciseService) {}

  /**
   * "운동 라이브러리" 탭 진입용 - 개인화 없이 4개 카테고리 각각 전체 개수 + 미리보기 목록 반환
   */
  @ApiOperation({
    summary: '운동 라이브러리 진입/검색 (카테고리별로 묶어서 반환)',
    description:
      'BODY_BALANCE/INBODY_DIET/LINE_DIET/FACE_CARE 4개 카테고리를 개인화 없이 그대로 반환. ' +
      'search 미전달 시 진입 화면용(카테고리당 previewLimit개, 기본 10). ' +
      'search 전달 시 검색 화면용(mainCat/subCat/detailCat/title LIKE 검색, previewLimit 무시하고 카테고리별 전체 결과 반환).',
  })
  @ApiQuery({ name: 'previewLimit', required: false, description: '카테고리당 미리보기 개수 (기본 10, search 지정 시 무시)' })
  @ApiQuery({ name: 'search', required: false, description: '검색어 (미전달 시 진입 화면 모드)' })
  @Get('library')
  async getLibraryPreview(
    @Query('previewLimit') previewLimit?: string,
    @Query('search') search?: string,
  ) {
    const limit = previewLimit ? parseInt(previewLimit, 10) : 10;
    if (Number.isNaN(limit) || limit < 1) {
      throw new BadRequestException('previewLimit은 1 이상의 숫자여야 합니다.');
    }
    const data = await this.service.findLibraryPreview(limit, search);
    return SuccessResponse(data);
  }

  /**
   * "운동 라이브러리" 탭 전체보기용 - 특정 카테고리 전체를 개인화 없이 페이징 조회
   */
  @ApiOperation({
    summary: '운동 라이브러리 카테고리 전체보기',
    description: 'INBODY_DIET는 mainCat(WHOLE_BODY|LOWER_BODY|ABDOMEN|UPPER_BODY)으로 추가 필터 가능.',
  })
  @ApiQuery({ name: 'mainCat', required: false })
  @Get('library/:category')
  async getLibraryByCategory(
    @Param('category') category: string,
    @Query('mainCat') mainCat: string | undefined,
    @Query('page') page = '1',
    @Query('limit') limit = '20',
  ): Promise<IPageResponse<CustomExerciseEntity>> {
    const allowed: ExerciseCategory[] = ['BODY_BALANCE', 'INBODY_DIET', 'LINE_DIET', 'FACE_CARE'];
    if (!allowed.includes(category as ExerciseCategory)) {
      throw new BadRequestException(`category는 ${allowed.join(' | ')} 중 하나여야 합니다.`);
    }
    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 20;

    const { items, total } = await this.service.findLibraryByCategory(
      category as ExerciseCategory,
      mainCat,
      pageNum,
      limitNum,
    );
    return SuccessResponse({ items, paging: buildPaging(total, limitNum, pageNum) });
  }

  /**
   * BODY_BALANCE / LINE_DIET / FACE_CARE — 체형유형명으로 운동 목록 조회
   */
  @ApiOperation({
    summary: '체형유형 기반 맞춤운동 조회',
    description:
      'bodyTypeName 필수. category 미전달 시 전체 카테고리 반환. ' +
      'INBODY_DIET는 /inbody-diet 엔드포인트 사용.',
  })
  @ApiQuery({ name: 'bodyTypeName', required: true, description: '체형유형 영문 키 (ex. TURTLE_NECK, ROUNDED_SHOULDER)' })
  @ApiQuery({ name: 'category', required: false, enum: ['BODY_BALANCE', 'LINE_DIET', 'FACE_CARE'], description: '미전달 시 전체 카테고리 반환' })
  @Get()
  async findByBodyType(
    @Query('bodyTypeName') bodyTypeName: string,
    @Query('category') category?: string,
  ) {
    if (!bodyTypeName) {
      throw new BadRequestException('bodyTypeName은 필수입니다.');
    }
    const allowed: ExerciseCategory[] = ['BODY_BALANCE', 'LINE_DIET', 'FACE_CARE'];
    if (category && !allowed.includes(category as ExerciseCategory)) {
      throw new BadRequestException(
        `category는 ${allowed.join(' | ')} 중 하나여야 합니다.`,
      );
    }

    const data = await this.service.findByBodyTypeName(
      bodyTypeName,
      category as Exclude<ExerciseCategory, 'INBODY_DIET'> | undefined,
    );
    return SuccessResponse(data);
  }

  /**
   * 체형리포트 UUID 기반 맞춤운동 조회 (1순위 체형 기준)
   */
  @ApiOperation({
    summary: '체형리포트 기반 맞춤운동 조회',
    description:
      '체형리포트 UUID를 받아 측정된 모든 체형(disease)에 해당하는 맞춤운동을 반환합니다. ' +
      '체형별 disease.score에 따라 Lv1(심각·위험)/Lv2(주의·경계)/Lv3(양호) 중 하나만 매칭됩니다. ' +
      'youtube_url이 있는 운동만 포함됩니다.',
  })
  @Get('body-report/:reportId')
  async findByBodyReport(@Param('reportId') reportId: string) {
    const data = await this.service.findByBodyReportId(reportId);
    return SuccessResponse(data);
  }

  /**
   * 정밀리포트 UUID 기반 맞춤운동 조회
   */
  @ApiOperation({
    summary: '정밀리포트 기반 맞춤운동 조회',
    description:
      '정밀리포트 UUID로 해당 회원의 최신 체형분석 결과를 조회하여 ' +
      '체형별 disease.score 기준 Lv1/Lv2/Lv3 맞춤운동을 카테고리별로 반환합니다.',
  })
  @Get('precision-report/:reportId')
  async findByPrecisionReport(@Param('reportId') reportId: string) {
    const data = await this.service.findByPrecisionReportId(reportId);
    return SuccessResponse(data);
  }

  /**
   * 인바디 UUID 기반 INBODY_DIET 맞춤운동 조회
   */
  @ApiOperation({
    summary: '인바디 기반 맞춤운동 조회',
    description: '인바디 UUID로 INBODY_DIET 운동을 mainCat별로 그룹핑하여 반환합니다.',
  })
  @Get('inbody/:inbodyId')
  async findByInbody(@Param('inbodyId') inbodyId: string) {
    const data = await this.service.findByInbodyId(inbodyId);
    return SuccessResponse(data);
  }
}

/**
 * 공개 맞춤운동 - 인증 불필요 (공유 링크)
 */
@ApiTags('Custom Exercise')
@Controller('custom-exercises')
export class PublicCustomExerciseController {
  constructor(private readonly service: CustomExerciseService) {}

  @ApiOperation({ summary: 'Get Body Report Exercises (Public)' })
  @Get('body-report/:reportId/public')
  async findByBodyReportPublic(@Param('reportId') reportId: string) {
    const data = await this.service.findByBodyReportId(reportId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Precision Report Exercises (Public)' })
  @Get('precision-report/:reportId/public')
  async findByPrecisionReportPublic(@Param('reportId') reportId: string) {
    const data = await this.service.findByPrecisionReportId(reportId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Inbody Exercises (Public)' })
  @Get('inbody/:inbodyId/public')
  async findByInbodyPublic(@Param('inbodyId') inbodyId: string) {
    const data = await this.service.findByInbodyId(inbodyId);
    return SuccessResponse(data);
  }
}

/**
 * 센터용 공개 맞춤운동 - 인증 불필요 (공유 링크)
 * PublicCustomExerciseController와 완전히 동일한 서비스 로직을 재사용하는 /center/* 라우트.
 */
@ApiTags('Center Custom Exercise Public')
@Controller('center/custom-exercises/public')
export class CenterCustomExercisePublicController {
  constructor(private readonly service: CustomExerciseService) {}

  @ApiOperation({ summary: 'Get Body Report Exercises (Center / Public)' })
  @Get('body-report/:reportId')
  async findByBodyReportPublic(@Param('reportId') reportId: string) {
    const data = await this.service.findByBodyReportId(reportId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Precision Report Exercises (Center / Public)' })
  @Get('precision-report/:reportId')
  async findByPrecisionReportPublic(@Param('reportId') reportId: string) {
    const data = await this.service.findByPrecisionReportId(reportId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Inbody Exercises (Center / Public)' })
  @Get('inbody/:inbodyId')
  async findByInbodyPublic(@Param('inbodyId') inbodyId: string) {
    const data = await this.service.findByInbodyId(inbodyId);
    return SuccessResponse(data);
  }
}
