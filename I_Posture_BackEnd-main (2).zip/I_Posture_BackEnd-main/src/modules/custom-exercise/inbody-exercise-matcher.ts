/**
 * 인바디 데이터 기반 INBODY_DIET 맞춤운동 매칭 로직.
 * 문서: docs/맞춤운동_파싱.md 섹션 3 조건표
 *
 * 표준범위 판단 불가 항목 처리:
 *  - 골격근량 표준 이하/범위/이상  → muscleControl(근육조절) 수치로 근사
 *  - 체지방량 표준 이상/범위       → fatControl(지방조절) 수치로 근사
 *  - 기초대사량 표준 이하          → muscleControl로 근사 (저근육 = 저대사율)
 *  - 체수분/단백질/무기질 표준 이하 → 표준범위 미저장 → false (조건 미충족으로 처리)
 */

/** DB에서 꺼낸 keyStats / detailData JSON 필드 인터페이스 */
export interface InbodyStats {
  // keyStats
  bmi?: number;
  percentBodyFat?: number;     // 체지방률(%)
  visceralFatLevel?: number;   // 내장지방레벨
  basalMetabolicRate?: number; // 기초대사량
  skeletalMuscleMass?: number; // 골격근량
  bodyFatMass?: number;        // 체지방량
  abdominalFatRatio?: number;  // 복부지방률
  // detailData
  weightControl?: number | string; // 체중조절 (e.g. "-5.5")
  fatControl?: number | string;    // 지방조절 (e.g. "-7.0")
  muscleControl?: number | string; // 근육조절 (e.g. "+1.5")
}

/** "+1.5" / "-7.0" 등 문자열 또는 숫자를 number로 파싱 */
function parseControl(val: number | string | undefined | null): number | undefined {
  if (val == null) return undefined;
  if (typeof val === 'number') return val;
  const n = parseFloat(val.replace(/[^\d.\-+]/g, ''));
  return isNaN(n) ? undefined : n;
}

// ── 표준범위 근사 헬퍼 ─────────────────────────────────────────
// muscleControl(근육조절): 이상 체성분까지 더 필요한 근육량(+면 부족, -면 과다)
function isSkelMuscleMassBelow(mc: number | undefined): boolean {
  return mc !== undefined && mc >= 2;
}
function isSkelMuscleMassNormal(mc: number | undefined): boolean {
  return mc !== undefined && mc >= 0 && mc < 2;
}
function isSkelMuscleMassAbove(mc: number | undefined): boolean {
  return mc !== undefined && mc < 0;
}

// fatControl(지방조절): 이상 체성분까지 줄여야 할 지방량(-면 과다)
function isBodyFatMassAbove(fc: number | undefined): boolean {
  return fc !== undefined && fc <= -2;
}
function isBodyFatMassNormal(fc: number | undefined): boolean {
  return fc !== undefined && fc > -2 && fc <= 0;
}

// 기초대사량 표준 이하 ≈ 골격근량 부족
function isBasalMetabolicRateBelow(mc: number | undefined): boolean {
  return isSkelMuscleMassBelow(mc);
}
// ─────────────────────────────────────────────────────────────

/**
 * 인바디 keyStats / detailData JSON으로부터 조건을 만족하는
 * 운동 키(mainCat|subCat|detailCat|level) 집합을 반환합니다.
 *
 * 키 형식: `"WHOLE_BODY|유산소 루틴|기초체력용|"` (level이 null이면 빈 문자열)
 */
export function matchInbodyExercises(
  rawKeyStats: Record<string, unknown> | null | undefined,
  rawDetailData: Record<string, unknown> | null | undefined,
): Set<string> {
  const s = (rawKeyStats ?? {}) as Record<string, unknown>;
  const d = (rawDetailData ?? {}) as Record<string, unknown>;

  const bmi = s.bmi as number | undefined;
  const pbf = s.percentBodyFat as number | undefined;    // 체지방률
  const vfl = s.visceralFatLevel as number | undefined;  // 내장지방레벨
  const abr = s.abdominalFatRatio as number | undefined; // 복부지방률

  const wc = parseControl(d.weightControl as string | number | undefined); // 체중조절
  const fc = parseControl(d.fatControl as string | number | undefined);    // 지방조절
  const mc = parseControl(d.muscleControl as string | number | undefined); // 근육조절

  const matched = new Set<string>();

  const add = (
    mainCat: string,
    subCat: string,
    detailCat: string,
    level: string | null,
    cond: boolean,
  ) => {
    if (cond) matched.add(`${mainCat}|${subCat}|${detailCat}|${level ?? ''}`);
  };

  // ── WHOLE_BODY (전신 다이어트) ──────────────────────────────

  // 유산소 루틴 / 기초체력용 / NULL
  // BMI 28~29 OR 체지방률 31~32 OR 내장지방레벨 12~13 OR 골격근량 표준 이하
  add('WHOLE_BODY', '유산소 루틴', '기초체력용', null,
    (bmi !== undefined && bmi >= 28 && bmi <= 29) ||
    (pbf !== undefined && pbf >= 31 && pbf <= 32) ||
    (vfl !== undefined && vfl >= 12 && vfl <= 13) ||
    isSkelMuscleMassBelow(mc),
  );

  // 유산소 루틴 / 고강도 / NULL
  // BMI 25~27 OR 체지방률 28~30 OR 내장지방레벨 10~11
  add('WHOLE_BODY', '유산소 루틴', '고강도', null,
    (bmi !== undefined && bmi >= 25 && bmi <= 27) ||
    (pbf !== undefined && pbf >= 28 && pbf <= 30) ||
    (vfl !== undefined && vfl >= 10 && vfl <= 11),
  );

  // 유산소 루틴 / 인터벌 / Lv1
  // BMI 27~29 OR 체지방률 30~32
  add('WHOLE_BODY', '유산소 루틴', '인터벌', 'Lv1',
    (bmi !== undefined && bmi >= 27 && bmi <= 29) ||
    (pbf !== undefined && pbf >= 30 && pbf <= 32),
  );

  // 유산소 루틴 / 인터벌 / Lv2
  // BMI 23~26 OR 체지방률 25~29
  add('WHOLE_BODY', '유산소 루틴', '인터벌', 'Lv2',
    (bmi !== undefined && bmi >= 23 && bmi <= 26) ||
    (pbf !== undefined && pbf >= 25 && pbf <= 29),
  );

  // 유산소 루틴 / 인터벌 / Lv3
  // BMI 18.5~22 OR 체지방률 18~24
  add('WHOLE_BODY', '유산소 루틴', '인터벌', 'Lv3',
    (bmi !== undefined && bmi >= 18.5 && bmi <= 22) ||
    (pbf !== undefined && pbf >= 18 && pbf <= 24),
  );

  // 근력&톤업 / 전신근육 활성 / NULL
  // 골격근량 표준 이하 OR 근육조절 ≥2kg
  add('WHOLE_BODY', '근력&톤업', '전신근육 활성', null,
    isSkelMuscleMassBelow(mc) ||
    (mc !== undefined && mc >= 2),
  );

  // 근력&톤업 / 근육대사 향상 / NULL
  // 골격근량 표준 범위 OR 근육조절 0~1.9kg
  add('WHOLE_BODY', '근력&톤업', '근육대사 향상', null,
    isSkelMuscleMassNormal(mc) ||
    (mc !== undefined && mc >= 0 && mc <= 1.9),
  );

  // 챌린지형 루틴 (급찐급빠) / 7일 체지방 다운 챌린지 / NULL
  // 체지방률 ≥25 OR 지방조절 ≤-3kg OR BMI ≥23
  add('WHOLE_BODY', '챌린지형 루틴 (급찐급빠)', '7일 체지방 다운 챌린지', null,
    (pbf !== undefined && pbf >= 25) ||
    (fc !== undefined && fc <= -3) ||
    (bmi !== undefined && bmi >= 23),
  );

  // 전신 붓기 제거 / 아침용 붓기제거 / NULL
  // 체수분 표준 이하 OR 단백질 표준 이하
  // ※ 표준범위 데이터 미저장 → 조건 평가 불가
  add('WHOLE_BODY', '전신 붓기 제거', '아침용 붓기제거', null, false);

  // 전신 붓기 제거 / 퇴근 후 붓기 / NULL
  // 체수분 표준 이하 OR 무기질 표준 이하
  // ※ 표준범위 데이터 미저장 → 조건 평가 불가
  add('WHOLE_BODY', '전신 붓기 제거', '퇴근 후 붓기', null, false);

  // 심폐지구력향상 / 체력증진 / NULL
  // 기초대사량 표준 이하 OR 골격근량 표준 이하
  add('WHOLE_BODY', '심폐지구력향상', '체력증진', null,
    isBasalMetabolicRateBelow(mc) ||
    isSkelMuscleMassBelow(mc),
  );

  // ── LOWER_BODY (하체 다이어트) ──────────────────────────────

  // 허벅지 지방 / 안벅지 / Lv1
  // 체지방률 ≥33 OR 체지방량 표준 이상 OR 내장지방레벨 ≥12
  add('LOWER_BODY', '허벅지 지방', '안벅지', 'Lv1',
    (pbf !== undefined && pbf >= 33) ||
    isBodyFatMassAbove(fc) ||
    (vfl !== undefined && vfl >= 12),
  );

  // 허벅지 지방 / 안벅지 / Lv2
  // 체지방률 28~32 OR 체지방량 표준 범위
  add('LOWER_BODY', '허벅지 지방', '안벅지', 'Lv2',
    (pbf !== undefined && pbf >= 28 && pbf <= 32) ||
    isBodyFatMassNormal(fc),
  );

  // 허벅지 지방 / 안벅지 / Lv3
  // 체지방률 20~27
  add('LOWER_BODY', '허벅지 지방', '안벅지', 'Lv3',
    pbf !== undefined && pbf >= 20 && pbf <= 27,
  );

  // 전체 다리라인 / 하체 순환 루틴 / Lv1
  // BMI ≥30 OR 체지방률 ≥33 OR 체중조절 ≤-10kg
  add('LOWER_BODY', '전체 다리라인', '하체 순환 루틴', 'Lv1',
    (bmi !== undefined && bmi >= 30) ||
    (pbf !== undefined && pbf >= 33) ||
    (wc !== undefined && wc <= -10),
  );

  // 전체 다리라인 / 하체 순환 루틴 / Lv2
  // BMI 25~29 OR 체지방률 28~32 OR 체중조절 -5~-9kg
  add('LOWER_BODY', '전체 다리라인', '하체 순환 루틴', 'Lv2',
    (bmi !== undefined && bmi >= 25 && bmi <= 29) ||
    (pbf !== undefined && pbf >= 28 && pbf <= 32) ||
    (wc !== undefined && wc >= -9 && wc <= -5),
  );

  // 전체 다리라인 / 하체 순환 루틴 / Lv3
  // BMI 18.5~24 OR 체지방률 20~27
  add('LOWER_BODY', '전체 다리라인', '하체 순환 루틴', 'Lv3',
    (bmi !== undefined && bmi >= 18.5 && bmi <= 24) ||
    (pbf !== undefined && pbf >= 20 && pbf <= 27),
  );

  // ── ABDOMEN (복부 다이어트) ─────────────────────────────────

  // 하복부 / 아랫배 지방정리 / Lv1
  // 체지방률 ≥33 OR 복부지방률 ≥1.0 OR 내장지방레벨 ≥12
  add('ABDOMEN', '하복부', '아랫배 지방정리', 'Lv1',
    (pbf !== undefined && pbf >= 33) ||
    (abr !== undefined && abr >= 1.0) ||
    (vfl !== undefined && vfl >= 12),
  );

  // 하복부 / 아랫배 지방정리 / Lv2
  // 체지방률 28~32 OR 복부지방률 0.9~0.99 OR 내장지방레벨 8~11
  add('ABDOMEN', '하복부', '아랫배 지방정리', 'Lv2',
    (pbf !== undefined && pbf >= 28 && pbf <= 32) ||
    (abr !== undefined && abr >= 0.9 && abr <= 0.99) ||
    (vfl !== undefined && vfl >= 8 && vfl <= 11),
  );

  // 하복부 / 아랫배 지방정리 / Lv3
  // 체지방률 20~27 OR 복부지방률 0.85~0.89
  add('ABDOMEN', '하복부', '아랫배 지방정리', 'Lv3',
    (pbf !== undefined && pbf >= 20 && pbf <= 27) ||
    (abr !== undefined && abr >= 0.85 && abr <= 0.89),
  );

  // 하복부 / 아랫배 탄력 코어 / Lv1
  // 골격근량 표준 이하 OR 근육조절 ≥2kg OR 기초대사량 표준 이하
  add('ABDOMEN', '하복부', '아랫배 탄력 코어', 'Lv1',
    isSkelMuscleMassBelow(mc) ||
    (mc !== undefined && mc >= 2) ||
    isBasalMetabolicRateBelow(mc),
  );

  // 하복부 / 아랫배 탄력 코어 / Lv2
  // 골격근량 표준 범위 OR 근육조절 1~1.9kg
  add('ABDOMEN', '하복부', '아랫배 탄력 코어', 'Lv2',
    isSkelMuscleMassNormal(mc) ||
    (mc !== undefined && mc >= 1 && mc <= 1.9),
  );

  // 하복부 / 아랫배 탄력 코어 / Lv3
  // 골격근량 표준 이상 OR 근육조절 <1kg
  add('ABDOMEN', '하복부', '아랫배 탄력 코어', 'Lv3',
    isSkelMuscleMassAbove(mc) ||
    (mc !== undefined && mc < 1),
  );

  // 옆구리&러브핸들 / 옆구리 지방제거 / Lv1
  // 체지방률 ≥33 OR 복부지방률 ≥1.0 OR 내장지방레벨 ≥12
  add('ABDOMEN', '옆구리&러브핸들', '옆구리 지방제거', 'Lv1',
    (pbf !== undefined && pbf >= 33) ||
    (abr !== undefined && abr >= 1.0) ||
    (vfl !== undefined && vfl >= 12),
  );

  // 옆구리&러브핸들 / 옆구리 지방제거 / Lv2
  // 체지방률 28~32 OR 복부지방률 0.9~0.99 OR 내장지방레벨 8~11
  add('ABDOMEN', '옆구리&러브핸들', '옆구리 지방제거', 'Lv2',
    (pbf !== undefined && pbf >= 28 && pbf <= 32) ||
    (abr !== undefined && abr >= 0.9 && abr <= 0.99) ||
    (vfl !== undefined && vfl >= 8 && vfl <= 11),
  );

  // 옆구리&러브핸들 / 옆구리 지방제거 / Lv3
  // 체지방률 20~27 OR 복부지방률 0.85~0.89
  add('ABDOMEN', '옆구리&러브핸들', '옆구리 지방제거', 'Lv3',
    (pbf !== undefined && pbf >= 20 && pbf <= 27) ||
    (abr !== undefined && abr >= 0.85 && abr <= 0.89),
  );

  // 옆구리&러브핸들 / 11자 복근 / Lv1
  // 체지방률 25~32 OR 체지방량 표준 이상
  add('ABDOMEN', '옆구리&러브핸들', '11자 복근', 'Lv1',
    (pbf !== undefined && pbf >= 25 && pbf <= 32) ||
    isBodyFatMassAbove(fc),
  );

  // 옆구리&러브핸들 / 11자 복근 / Lv2
  // 체지방률 20~24
  add('ABDOMEN', '옆구리&러브핸들', '11자 복근', 'Lv2',
    pbf !== undefined && pbf >= 20 && pbf <= 24,
  );

  // 옆구리&러브핸들 / 11자 복근 / Lv3
  // 체지방률 15~19 AND 내장지방레벨 ≤5
  add('ABDOMEN', '옆구리&러브핸들', '11자 복근', 'Lv3',
    (pbf !== undefined && pbf >= 15 && pbf <= 19) &&
    (vfl !== undefined && vfl <= 5),
  );

  // ── UPPER_BODY (상체 다이어트) ──────────────────────────────

  // 전체적인 상체 라인 / 상체 순환 루틴 / Lv1
  // 체지방률 ≥28 OR 체지방량 표준 이상 OR 지방조절 ≤-5kg
  add('UPPER_BODY', '전체적인 상체 라인', '상체 순환 루틴', 'Lv1',
    (pbf !== undefined && pbf >= 28) ||
    isBodyFatMassAbove(fc) ||
    (fc !== undefined && fc <= -5),
  );

  // 전체적인 상체 라인 / 상체 순환 루틴 / Lv2
  // 체지방률 23~27 OR 체지방량 표준 범위 OR 지방조절 -3~-4kg
  add('UPPER_BODY', '전체적인 상체 라인', '상체 순환 루틴', 'Lv2',
    (pbf !== undefined && pbf >= 23 && pbf <= 27) ||
    isBodyFatMassNormal(fc) ||
    (fc !== undefined && fc >= -4 && fc <= -3),
  );

  // 전체적인 상체 라인 / 상체 순환 루틴 / Lv3
  // 체지방률 18~22 OR 지방조절 -1~-2kg
  add('UPPER_BODY', '전체적인 상체 라인', '상체 순환 루틴', 'Lv3',
    (pbf !== undefined && pbf >= 18 && pbf <= 22) ||
    (fc !== undefined && fc >= -2 && fc <= -1),
  );

  return matched;
}
