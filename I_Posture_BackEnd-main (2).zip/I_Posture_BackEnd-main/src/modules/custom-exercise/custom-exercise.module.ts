import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomExerciseEntity } from '../../database/entities/custom-exercise.entity';
import { CustomExerciseBodyTypeEntity } from '../../database/entities/custom-exercise-body-type.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import {
  CustomExerciseController,
  PublicCustomExerciseController,
  CenterCustomExercisePublicController,
} from './custom-exercise.controller';
import { CustomExerciseService } from './custom-exercise.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      CustomExerciseEntity,
      CustomExerciseBodyTypeEntity,
      BodyReportEntity,
      PrecisionReportEntity,
      InbodyDataEntity,
    ]),
  ],
  controllers: [
    CustomExerciseController,
    PublicCustomExerciseController,
    CenterCustomExercisePublicController,
  ],
  providers: [CustomExerciseService],
  exports: [CustomExerciseService],
})
export class CustomExerciseModule {}
