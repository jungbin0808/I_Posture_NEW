import { DISEASE_KEY_NORMALIZATION } from '../consultation-log/action-plan.helper';

/**
 * 체형 분석 disease.score → 맞춤운동 level 매핑
 *
 * | 틀어짐단계 | 체형유형 단계 | 운동 level |
 * |-----------|--------------|-----------|
 * | 1단계     | 정상         | (없음)    |
 * | 2단계     | 양호         | Lv3       |
 * | 3단계     | 주의         | Lv2       |
 * | 4단계     | 경계         | Lv2       |
 * | 5단계     | 심각         | Lv1       |
 * | 6단계     | 위험         | Lv1       |
 *
 * score는 analysis 엔진 referenceScore(5/15/25/40/55/62)와 동일합니다.
 */
const DISEASE_SCORE_TO_EXERCISE_LEVEL: Readonly<Record<number, string>> = {
  15: 'Lv3',
  25: 'Lv2',
  40: 'Lv2',
  55: 'Lv1',
  62: 'Lv1',
};

export interface BodyTypeLevelPair {
  bodyTypeName: string;
  level: string;
}

/** disease.score → Lv1|Lv2|Lv3. 매칭 없으면 null(운동 미노출). */
export function resolveExerciseLevelFromDiseaseScore(
  score: number | null | undefined,
): string | null {
  if (score == null) return null;
  return DISEASE_SCORE_TO_EXERCISE_LEVEL[score] ?? null;
}

/**
 * 측정 disease 목록 → (body_type_name, level) 쌍 목록.
 * NORMAL·레벨 없는 score(정상/경계/위험)는 제외합니다.
 */
export function buildBodyTypeLevelPairs(
  diseases: Array<{ key: string; score?: number }>,
): BodyTypeLevelPair[] {
  const seen = new Set<string>();
  const pairs: BodyTypeLevelPair[] = [];

  for (const disease of diseases ?? []) {
    if (!disease?.key || disease.key === 'NORMAL') continue;

    const bodyTypeName = DISEASE_KEY_NORMALIZATION[disease.key] ?? disease.key;
    const level = resolveExerciseLevelFromDiseaseScore(disease.score);
    if (!level) continue;

    const dedupeKey = `${bodyTypeName}|${level}`;
    if (seen.has(dedupeKey)) continue;

    seen.add(dedupeKey);
    pairs.push({ bodyTypeName, level });
  }

  return pairs;
}

/** Lv1이 Lv2·Lv3보다 심각(숫자가 작을수록 심각). */
const EXERCISE_LEVEL_SEVERITY: Readonly<Record<string, number>> = {
  Lv1: 1,
  Lv2: 2,
  Lv3: 3,
};

export function buildExercisePathKey(exercise: {
  category: string;
  mainCat: string;
  subCat: string | null;
  detailCat: string;
}): string {
  return `${exercise.category}|${exercise.mainCat}|${exercise.subCat ?? ''}|${exercise.detailCat}`;
}

function compareExerciseLevelSeverity(a: string | null, b: string | null): number {
  const severityA = EXERCISE_LEVEL_SEVERITY[a ?? ''] ?? Number.MAX_SAFE_INTEGER;
  const severityB = EXERCISE_LEVEL_SEVERITY[b ?? ''] ?? Number.MAX_SAFE_INTEGER;
  return severityA - severityB;
}

/**
 * 동일 운동 경로(category/main/sub/detail)에 여러 level이 매칭되면
 * 가장 심한 level(Lv1 > Lv2 > Lv3) 운동만 남깁니다.
 */
export function dedupeExercisesByPathKeepingSeverestLevel<
  T extends {
    category: string;
    mainCat: string;
    subCat: string | null;
    detailCat: string;
    level: string | null;
  },
>(exercises: T[]): T[] {
  const byPath = new Map<string, T>();

  for (const exercise of exercises) {
    const pathKey = buildExercisePathKey(exercise);
    const existing = byPath.get(pathKey);
    if (!existing || compareExerciseLevelSeverity(exercise.level, existing.level) < 0) {
      byPath.set(pathKey, exercise);
    }
  }

  return Array.from(byPath.values());
}
