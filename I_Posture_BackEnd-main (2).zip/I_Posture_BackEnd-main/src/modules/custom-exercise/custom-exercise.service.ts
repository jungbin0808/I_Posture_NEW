import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { CustomExerciseEntity } from '../../database/entities/custom-exercise.entity';
import { CustomExerciseBodyTypeEntity } from '../../database/entities/custom-exercise-body-type.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { buildBodyTypeLevelPairs, dedupeExercisesByPathKeepingSeverestLevel } from './body-exercise-level.helper';
import { matchInbodyExercises } from './inbody-exercise-matcher';

export type ExerciseCategory = 'BODY_BALANCE' | 'INBODY_DIET' | 'LINE_DIET' | 'FACE_CARE';
export type InbodyDietMainCat = 'WHOLE_BODY' | 'LOWER_BODY' | 'ABDOMEN' | 'UPPER_BODY';

@Injectable()
export class CustomExerciseService {
  constructor(
    @InjectRepository(CustomExerciseEntity)
    private readonly exerciseRepo: Repository<CustomExerciseEntity>,
    @InjectRepository(CustomExerciseBodyTypeEntity)
    private readonly bodyTypeRepo: Repository<CustomExerciseBodyTypeEntity>,
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    private readonly dataSource: DataSource,
  ) {}

  /**
   * BODY_BALANCE / LINE_DIET / FACE_CARE
   * 특정 체형유형(body_type_name)에 매핑된 운동 목록을 반환합니다.
   * category 미전달 시 전체 카테고리 반환. sub_cat NULL-safe 조인 적용.
   */
  async findByBodyTypeName(
    bodyTypeName: string,
    category?: Exclude<ExerciseCategory, 'INBODY_DIET'>,
    level?: string,
  ): Promise<CustomExerciseEntity[]> {
    const qb = this.dataSource
      .createQueryBuilder(CustomExerciseEntity, 'e')
      .innerJoin(
        CustomExerciseBodyTypeEntity,
        'bt',
        'bt.category = e.category ' +
          'AND bt.main_cat = e.main_cat ' +
          'AND bt.sub_cat <=> e.sub_cat ' +
          'AND bt.detail_cat = e.detail_cat',
      )
      .where('bt.body_type_name = :bodyTypeName', { bodyTypeName })
      .andWhere('e.youtube_url IS NOT NULL')
      .distinct(true)
      .orderBy('e.sort_order', 'ASC');

    if (category) {
      qb.andWhere('e.category = :category', { category });
    }

    if (level) {
      qb.andWhere('e.level = :level', { level });
    }

    return qb.getMany();
  }

  /**
   * 측정 disease 목록 기준 맞춤운동 조회.
   * 체형별 disease.score → Lv1|Lv2|Lv3 매핑 후 해당 level 운동을 조회하고,
   * 동일 운동 경로는 가장 심한 level(Lv1)만 남깁니다.
   */
  private async findByDiseases(
    diseases: Array<{ key: string; score?: number }>,
    category?: Exclude<ExerciseCategory, 'INBODY_DIET'>,
  ): Promise<CustomExerciseEntity[]> {
    const pairs = buildBodyTypeLevelPairs(diseases);
    if (pairs.length === 0) return [];

    const seenIds = new Set<string>();
    const exercises: CustomExerciseEntity[] = [];

    for (const { bodyTypeName, level } of pairs) {
      const rows = await this.findByBodyTypeName(bodyTypeName, category, level);
      for (const row of rows) {
        if (seenIds.has(row.id)) continue;
        seenIds.add(row.id);
        exercises.push(row);
      }
    }

    return dedupeExercisesByPathKeepingSeverestLevel(exercises).sort((a, b) => {
      const categoryOrder = a.category.localeCompare(b.category);
      if (categoryOrder !== 0) return categoryOrder;
      return a.sortOrder - b.sortOrder;
    });
  }

  private groupExercisesByCategory(
    exercises: CustomExerciseEntity[],
  ): Record<string, CustomExerciseEntity[]> {
    return exercises.reduce<Record<string, CustomExerciseEntity[]>>((acc, e) => {
      (acc[e.category] ??= []).push(e);
      return acc;
    }, {});
  }

  /**
   * INBODY_DIET
   * main_cat 기준으로 운동 목록을 반환합니다.
   * (WHOLE_BODY | LOWER_BODY | ABDOMEN | UPPER_BODY)
   * mainCat 미전달 시 전체 반환.
   */
  async findInbodyDiet(mainCat?: InbodyDietMainCat): Promise<CustomExerciseEntity[]> {
    const qb = this.exerciseRepo
      .createQueryBuilder('e')
      .where('e.category = :category', { category: 'INBODY_DIET' })
      .andWhere('e.youtube_url IS NOT NULL')
      .orderBy('e.sort_order', 'ASC');

    if (mainCat) {
      qb.andWhere('e.main_cat = :mainCat', { mainCat });
    }

    return qb.getMany();
  }

  /**
   * 인바디 UUID 기반 INBODY_DIET 맞춤운동 조회.
   * docs/맞춤운동_파싱.md 섹션 3의 인바디 조건표에 따라 매칭된 운동을
   * mainCat별로 그룹핑하여 반환합니다.
   */
  async findByInbodyId(inbodyId: string): Promise<Record<string, CustomExerciseEntity[]>> {
    const inbody = await this.inbodyDataRepo.findOne({ where: { id: inbodyId } });
    if (!inbody) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

    const matchedKeys = matchInbodyExercises(inbody.keyStats, inbody.detailData);

    const exercises = await this.exerciseRepo
      .createQueryBuilder('e')
      .where('e.category = :category', { category: 'INBODY_DIET' })
      .andWhere('e.youtube_url IS NOT NULL')
      .orderBy('e.sort_order', 'ASC')
      .getMany();

    const filtered = exercises.filter((e) =>
      matchedKeys.has(`${e.mainCat}|${e.subCat}|${e.detailCat}|${e.level ?? ''}`),
    );

    return filtered.reduce<Record<string, CustomExerciseEntity[]>>((acc, e) => {
      (acc[e.mainCat] ??= []).push(e);
      return acc;
    }, {});
  }

  /**
   * 체형리포트 UUID 기반 맞춤운동 조회.
   * 측정된 모든 체형에 대해 disease.score 기준 Lv1|Lv2|Lv3 운동만 반환합니다.
   */
  async findByBodyReportId(reportId: string): Promise<Record<string, CustomExerciseEntity[]>> {
    const report = await this.bodyReportRepo.findOne({ where: { id: reportId } });
    if (!report) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

    const diseases: Array<{ key: string; score?: number }> = report.analysisData?.disease ?? [];
    const exercises = await this.findByDiseases(diseases);
    return this.groupExercisesByCategory(exercises);
  }

  /**
   * 정밀리포트 UUID → 해당 회원의 최신 체형분석 disease 기반 맞춤운동 조회.
   * 체형별 disease.score 기준 Lv1|Lv2|Lv3 운동만 반환합니다.
   */
  async findByPrecisionReportId(reportId: string): Promise<Record<string, CustomExerciseEntity[]>> {
    const precisionReport = await this.precisionReportRepo.findOne({ where: { id: reportId } });
    if (!precisionReport) throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');

    const bodyReport = await this.bodyReportRepo.findOne({
      where: { userId: precisionReport.userId },
      order: { createdAt: 'DESC' },
    });
    if (!bodyReport) return {};

    const diseases: Array<{ key: string; score?: number }> = bodyReport.analysisData?.disease ?? [];
    const exercises = await this.findByDiseases(diseases);
    return this.groupExercisesByCategory(exercises);
  }

  /**
   * 회원의 최신 체형분석(body_report) 결과를 기반으로
   * 체형별 disease.score 기준 Lv1|Lv2|Lv3 맞춤운동을 반환합니다.
   */
  async findByLatestBodyReport(memberId: string): Promise<CustomExerciseEntity[]> {
    const report = await this.bodyReportRepo.findOne({
      where: { userId: memberId },
      order: { createdAt: 'DESC' },
    });
    if (!report) return [];

    const diseases: Array<{ key: string; score?: number }> = report.analysisData?.disease ?? [];
    return this.findByDiseases(diseases);
  }

  /**
   * 체형측정/인바디 둘 다 없는 회원을 위한 랜덤(비개인화) 체형 계열 운동 풀.
   * BODY_BALANCE/LINE_DIET/FACE_CARE 전체 - 특정 체형유형 매칭 없이 폭넓게 반환.
   */
  async findRandomBodyExercises(): Promise<CustomExerciseEntity[]> {
    return this.exerciseRepo
      .createQueryBuilder('e')
      .where('e.category IN (:...categories)', { categories: ['BODY_BALANCE', 'LINE_DIET', 'FACE_CARE'] })
      .andWhere('e.youtube_url IS NOT NULL')
      .orderBy('e.sort_order', 'ASC')
      .getMany();
  }

  /**
   * "운동 라이브러리" 탭 진입/검색용 - 4개 카테고리(BODY_BALANCE/INBODY_DIET/LINE_DIET/FACE_CARE)를
   * 개인화(체형/인바디 매칭) 없이 카테고리별로 묶어서 반환.
   * - search 미지정: 카테고리별 전체 개수 + 미리보기 목록(previewLimit개) - 탭 진입 화면용
   * - search 지정: previewLimit 무시하고 카테고리별 검색 결과 전체 반환 - 검색 화면용
   */
  async findLibraryPreview(previewLimit = 10, search?: string): Promise<
    Array<{ category: ExerciseCategory; totalCount: number; items: CustomExerciseEntity[] }>
  > {
    const categories: ExerciseCategory[] = ['BODY_BALANCE', 'INBODY_DIET', 'LINE_DIET', 'FACE_CARE'];

    return Promise.all(
      categories.map(async (category) => {
        const baseQuery = this.exerciseRepo
          .createQueryBuilder('e')
          .where('e.category = :category', { category })
          .andWhere('e.youtube_url IS NOT NULL');

        if (search) {
          baseQuery.andWhere(
            '(e.mainCat LIKE :search OR e.subCat LIKE :search OR e.detailCat LIKE :search OR e.title LIKE :search)',
            { search: `%${search}%` },
          );
        }

        const totalCount = await baseQuery.clone().getCount();
        const itemsQuery = baseQuery.clone().orderBy('e.sort_order', 'ASC');
        if (!search) {
          itemsQuery.take(previewLimit);
        }
        const items = await itemsQuery.getMany();

        return { category, totalCount, items };
      }),
    );
  }

  /**
   * "운동 라이브러리" 탭 전체보기용 - 특정 카테고리 전체를 개인화 없이 페이징 조회.
   * INBODY_DIET는 mainCat(WHOLE_BODY|LOWER_BODY|ABDOMEN|UPPER_BODY)으로 추가 필터 가능.
   */
  async findLibraryByCategory(
    category: ExerciseCategory,
    mainCat: string | undefined,
    page: number,
    limit: number,
  ): Promise<{ items: CustomExerciseEntity[]; total: number }> {
    const qb = this.exerciseRepo
      .createQueryBuilder('e')
      .where('e.category = :category', { category })
      .andWhere('e.youtube_url IS NOT NULL')
      .orderBy('e.sort_order', 'ASC')
      .skip((page - 1) * limit)
      .take(limit);

    if (mainCat) {
      qb.andWhere('e.main_cat = :mainCat', { mainCat });
    }

    const [items, total] = await qb.getManyAndCount();
    return { items, total };
  }

  /**
   * 특정 category의 고유 body_type_name 목록 조회 (관리/테스트용)
   */
  async findBodyTypeNames(category: ExerciseCategory): Promise<string[]> {
    const rows = await this.bodyTypeRepo
      .createQueryBuilder('bt')
      .select('DISTINCT bt.body_type_name', 'bodyTypeName')
      .where('bt.category = :category', { category })
      .orderBy('bt.body_type_name', 'ASC')
      .getRawMany<{ bodyTypeName: string }>();

    return rows.map((r) => r.bodyTypeName);
  }
}
