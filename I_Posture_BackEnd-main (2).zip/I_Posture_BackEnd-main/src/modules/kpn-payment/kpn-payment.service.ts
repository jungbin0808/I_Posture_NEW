import { BadRequestException, Injectable, Logger, NotFoundException, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, LessThan, Repository } from 'typeorm';
import { createHash } from 'crypto';
import { BillKeyEntity } from '../../database/entities/bill-key.entity';
import { BillKeyRegistrationEntity } from '../../database/entities/bill-key-registration.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { BillKeyCallbackDto, BillKeyRegistrationStatusDto, BillKeyResponseDto, BillRegisterUrlResponseDto, GetBillRegisterUrlDto } from './dto/kpn-payment.dto';

// ── KPN API 응답 타입 ────────────────────────────────────────────
interface KpnServiceApiResponse<T = unknown> {
  code: string;       // '0000' = 성공
  message: string;
  status: string;
  requestId: string;
  requestAt: string;
  responseAt: string;
  data: T | null;
}

interface KpnBillUrlData {
  forwardUrl: string;
  forwardMUrl: string;
}

// ── KPN 발급사 코드 → 이름 매핑 ────────────────────────────────
const ISS_NAME_MAP: Record<string, string> = {
  '01': '비씨', '02': '신한', '03': '삼성', '04': '현대', '05': '롯데',
  '07': 'KB국민', '08': '외환', '10': '우리', '12': '농협', '27': '하나',
  'W2': '페이코', 'KM': '카카오페이', 'X7': '네이버페이', 'X8': '토스페이',
};

// ── 서비스 ───────────────────────────────────────────────────────
@Injectable()
export class KpnPaymentService {
  private readonly logger = new Logger(KpnPaymentService.name);
  private readonly baseUrl: string;
  private readonly mxId: string;
  private readonly passKey: string;
  private readonly defaultReturnUrl: string;

  constructor(
    private readonly configService: ConfigService,
    private readonly dataSource: DataSource,
    @InjectRepository(BillKeyEntity)
    private readonly billKeyRepo: Repository<BillKeyEntity>,
    @InjectRepository(BillKeyRegistrationEntity)
    private readonly registrationRepo: Repository<BillKeyRegistrationEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
  ) {
    this.mxId = this.configService.getOrThrow<string>('KPN_MX_ID');
    this.passKey = this.configService.getOrThrow<string>('KPN_PASS_KEY');
    this.baseUrl = this.configService.get<string>('KPN_BASE_URL') ?? 'https://dev.firstpay.co.kr';
    this.defaultReturnUrl = this.configService.getOrThrow<string>('KPN_BILL_RETURN_URL');
  }

  // ── callHash 생성 ────────────────────────────────────────────────

  /** SHA256(mxId + custNo + passKey) — 빌키 등록 URL 발급용 */
  private hashForBillRegister(custNo: string): string {
    return createHash('sha256').update(`${this.mxId}${custNo}${this.passKey}`).digest('hex');
  }

  /** SHA256(custNo + billKey + passKey) — returnUrl 콜백 검증용 */
  private hashForBillCallback(custNo: string, billKey: string): string {
    return createHash('sha256').update(`${custNo}${billKey}${this.passKey}`).digest('hex');
  }

  /** SHA256(mxId + billKey + passKey) — 빌키 삭제 요청용 */
  private hashForBillDelete(billKey: string): string {
    return createHash('sha256').update(`${this.mxId}${billKey}${this.passKey}`).digest('hex');
  }

  /** SHA256(mxId + mxIssueNo + amount + passKey) — 빌키 결제 승인용 */
  private hashForBillApproval(mxIssueNo: string, amount: number): string {
    return createHash('sha256').update(`${this.mxId}${mxIssueNo}${amount}${this.passKey}`).digest('hex');
  }

  // ── KPN API 호출 헬퍼 ────────────────────────────────────────────

  private async callKpnApi<T>(path: string, body: object): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    this.logger.log(`KPN API 호출: POST ${url}`);

    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    const json = (await res.json()) as KpnServiceApiResponse<T>;
    this.logger.log(`KPN API 응답 code=${json.code} message=${json.message}`);

    const SUCCESS_CODES = ['0000', '200'];
    if (!SUCCESS_CODES.includes(String(json.code))) {
      throw new BadRequestException(`KPN 오류 [${json.code}]: ${json.message}`);
    }
    if (!json.data) {
      throw new BadRequestException('KPN 응답 data가 비어있습니다.');
    }
    return json.data;
  }

  // ── 빌키 조회 ──────────────────────────────────────────────────

  /** KPN 주문자명 — 명시값 없으면 회원명(user.name) 사용 */
  private async resolveRegisterCustName(userId: string, dto: GetBillRegisterUrlDto): Promise<string> {
    const explicit = (dto.cardHolderName ?? dto.custName)?.trim();
    if (explicit) {
      return explicit;
    }

    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'name'],
    });
    const memberName = user?.name?.trim();
    if (!memberName) {
      throw new BadRequestException('회원명이 없어 카드 등록을 진행할 수 없습니다.');
    }
    return memberName;
  }

  private async resolveMemberName(userId: string): Promise<string | undefined> {
    const user = await this.userRepo.findOne({
      where: { id: userId },
      select: ['id', 'name'],
    });
    return user?.name?.trim() || undefined;
  }

  /** KPN 콜백에서 카드 소유주명 추출 (PG 필드명 다양성 대응) */
  private extractCallbackCustName(raw: Record<string, unknown>): string | undefined {
    const candidates = ['custName', 'cust_name', 'buyerName', 'buyer_name', 'cardHolderName'];
    for (const key of candidates) {
      const value = raw[key];
      if (typeof value === 'string' && value.trim()) {
        return value.trim();
      }
    }
    return undefined;
  }

  async getActiveBillKey(userId: string): Promise<BillKeyEntity | null> {
    return this.billKeyRepo.findOne({ where: { userId, isActive: true } });
  }

  // ── 빌키 등록 URL 발급 ────────────────────────────────────────────

  async getBillRegisterUrl(userId: string, dto: GetBillRegisterUrlDto): Promise<BillRegisterUrlResponseDto> {
    // 카드 1개 제한: 이미 등록된 활성 빌키가 있으면 차단
    const existing = await this.billKeyRepo.findOne({ where: { userId, isActive: true } });
    if (existing) {
      throw new BadRequestException('이미 등록된 카드가 있습니다. 기존 카드를 교체하려면 교체 API를 사용하세요.');
    }

    // 만료되지 않은 기존 PENDING 등록 세션 재사용
    const existingReg = await this.registrationRepo.findOne({
      where: { userId, replacingBillKeyId: undefined },
    });
    if (existingReg) {
      await this.registrationRepo.delete({ id: existingReg.id });
    }

    const custNo = userId.replace(/-/g, '');
    const returnUrl = dto.returnUrl ?? this.defaultReturnUrl;
    const custName = await this.resolveRegisterCustName(userId, dto);

    const data = await this.callKpnApi<KpnBillUrlData>('/payments_bill_url', {
      mxId: this.mxId,
      custNo,
      custName,
      phoneNo: dto.phoneNo,
      returnUrl,
      callHash: this.hashForBillRegister(custNo),
      lang: 'ko',
    });

    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
    const registration = await this.registrationRepo.save(
      this.registrationRepo.create({
        userId,
        custNo,
        custName,
        replacingBillKeyId: null,
        expiresAt,
      }),
    );

    return { forwardUrl: data.forwardUrl, forwardMUrl: data.forwardMUrl, registrationId: registration.id };
  }

  // ── 빌키 등록 콜백 처리 (KPN returnUrl) ─────────────────────────

  async handleBillKeyCallback(payload: Record<string, unknown>): Promise<BillKeyEntity> {
    this.logger.log(`[콜백] 수신 payload: ${JSON.stringify(payload)}`);

    const dto = payload as unknown as BillKeyCallbackDto;

    if (dto.code !== '0000') {
      this.logger.warn(`[콜백] 등록 실패 code=${dto.code} message=${dto.message}`);
      throw new BadRequestException(`카드 등록 실패: ${dto.message}`);
    }

    if (!dto.billKey) {
      this.logger.warn(`[콜백] billKey 없음`);
      throw new BadRequestException('billKey가 전달되지 않았습니다.');
    }

    // hashData 검증: SHA256(custNo + billKey + passKey) — 원본 dto.custNo 그대로 사용
    const expectedHash = this.hashForBillCallback(dto.custNo, dto.billKey);
    this.logger.log(`[콜백] hashData 검증 — 수신: ${dto.hashData} / 기대값: ${expectedHash}`);
    if (dto.hashData?.toLowerCase() !== expectedHash.toLowerCase()) {
      this.logger.error(`[콜백] hashData 불일치 — 위변조 의심. custNo=${dto.custNo}`);
      throw new UnauthorizedException('hashData 검증에 실패했습니다.');
    }
    this.logger.log(`[콜백] hashData 검증 통과`);

    // KPN이 하이픈 포함·미포함 어떤 형식으로 custNo를 돌려보내도 일관되게 처리
    const custNoNormalized = dto.custNo.replace(/-/g, '');
    this.logger.log(`[콜백] custNo 정규화 — 원본: "${dto.custNo}" → 정규화: "${custNoNormalized}" (길이: ${custNoNormalized.length})`);

    // userId 복원: 하이픈 없는 32자 → UUID 형식 (세션이 있으면 거기서 가져옴)
    const raw = custNoNormalized;
    const uuidFromCustNo = `${raw.slice(0,8)}-${raw.slice(8,12)}-${raw.slice(12,16)}-${raw.slice(16,20)}-${raw.slice(20)}`;

    // bill_key_registrations에서 custNo로 세션 조회 (정규화된 값으로 매칭)
    // ※ duplicate 체크보다 먼저 수행 — 교체 케이스 판단에 필요
    this.logger.log(`[콜백] bill_key_registrations 조회 — custNo: "${custNoNormalized}"`);
    const registration = await this.registrationRepo.findOne({
      where: { custNo: custNoNormalized },
      order: { createdAt: 'DESC' },
    });
    this.logger.log(`[콜백] registration 조회 결과: ${registration ? `id=${registration.id}, replacingBillKeyId=${registration.replacingBillKeyId ?? 'null'}` : 'null (세션 없음)'}`);

    const userId = registration?.userId ?? uuidFromCustNo;
    this.logger.log(`[콜백] userId 결정: ${userId} (출처: ${registration ? 'registration' : 'custNo 역산'})`);

    // 동일 billKey 중복 등록 방지
    // 단, 교체 케이스에서 교체 대상 카드의 billKey와 동일한 경우(테스트환경 등)는 replace 로직 진행
    const existingBillKey = await this.billKeyRepo.findOne({ where: { billKey: dto.billKey } });
    if (existingBillKey) {
      const isReplacingThisCard = registration?.replacingBillKeyId != null && existingBillKey.id === registration.replacingBillKeyId;
      if (!isReplacingThisCard) {
        this.logger.warn(`[콜백] 이미 등록된 billKey: ${dto.billKey} — 기존 레코드 반환`);
        return existingBillKey;
      }
      this.logger.warn(`[콜백] 교체 대상 카드와 동일한 billKey 수신 (테스트환경?) — 교체 로직 계속 진행`);
    }

    return await this.dataSource.transaction(async (manager) => {
      // 교체 케이스: replacingBillKeyId가 있으면 기존 카드 삭제
      if (registration?.replacingBillKeyId) {
        this.logger.log(`[콜백] 교체 케이스 — 기존 billKeyId: ${registration.replacingBillKeyId}`);
        const oldKey = await manager.findOne(BillKeyEntity, {
          where: { id: registration.replacingBillKeyId },
        });
        if (oldKey) {
          try {
            await this.callKpnApi('/bill/delete', {
              mxId: this.mxId,
              billKey: oldKey.billKey,
              callHash: this.hashForBillDelete(oldKey.billKey),
            });
            this.logger.log(`[콜백] KPN 기존 빌키 삭제 완료: ${oldKey.billKey}`);
          } catch (err) {
            this.logger.warn(`[콜백] KPN 기존 빌키 삭제 오류 (계속 진행): ${err}`);
          }
          await manager.delete(BillKeyEntity, { id: oldKey.id });
          this.logger.log(`[콜백] 기존 bill_keys 레코드 삭제 완료: ${oldKey.id}`);
        } else {
          this.logger.warn(`[콜백] replacingBillKeyId=${registration.replacingBillKeyId} 레코드를 bill_keys에서 찾지 못함`);
        }
      }

      // 새 카드 INSERT
      const newBillKey = manager.create(BillKeyEntity, {
        userId,
        billKey: dto.billKey,
        viewCardNo: dto.viewCardNo,
        custName: this.extractCallbackCustName(payload) || registration?.custName,
        cardExp: dto.cardExp || undefined,
        issCd: dto.issCd,
        issName: dto.issCd ? (ISS_NAME_MAP[dto.issCd] ?? dto.issCd) : undefined,
        checkYn: dto.checkYn,
        billKeyType: dto.billKeyType,
        isActive: true,
      });
      const saved = await manager.save(BillKeyEntity, newBillKey);
      this.logger.log(`[콜백] 새 bill_keys INSERT 완료: id=${saved.id}`);

      // PENDING 등록 세션 완료 처리 (삭제 대신 completedAt 기록)
      if (registration) {
        await manager.update(BillKeyRegistrationEntity, { id: registration.id }, { completedAt: new Date() });
        this.logger.log(`[콜백] registration completedAt UPDATE 완료: id=${registration.id}`);
      } else {
        this.logger.warn(`[콜백] registration이 null — completedAt 업데이트 스킵`);
      }

      return saved;
    });
  }

  // ── 빌키 목록 조회 ────────────────────────────────────────────────

  async getBillKeys(userId: string): Promise<BillKeyResponseDto[]> {
    const keys = await this.billKeyRepo.find({
      where: { userId, isActive: true },
      order: { createdAt: 'DESC' },
    });

    const fallbackCustName = keys.some((key) => !key.custName)
      ? await this.resolveMemberName(userId)
      : undefined;

    return keys.map((k) => ({
      id: k.id,
      custName: k.custName ?? fallbackCustName,
      viewCardNo: k.viewCardNo,
      cardExp: k.cardExp,
      issCd: k.issCd,
      issName: k.issName,
      checkYn: k.checkYn,
      billKeyType: k.billKeyType,
      isActive: k.isActive,
      createdAt: k.createdAt,
    }));
  }

  // ── 빌키 교체 (기존 삭제 후 새 등록 URL 발급) ──────────────────────

  async replaceBillKey(userId: string, dto: GetBillRegisterUrlDto): Promise<BillRegisterUrlResponseDto> {
    const existing = await this.billKeyRepo.findOne({ where: { userId, isActive: true } });
    if (!existing) {
      throw new BadRequestException('교체할 등록 카드가 없습니다. 신규 등록 API를 사용하세요.');
    }

    // 기존 PENDING 교체 세션이 있으면 제거 후 재발급
    await this.registrationRepo.delete({ userId });

    const custNo = userId.replace(/-/g, '');
    const returnUrl = dto.returnUrl ?? this.defaultReturnUrl;
    const custName = await this.resolveRegisterCustName(userId, dto);
    const data = await this.callKpnApi<KpnBillUrlData>('/payments_bill_url', {
      mxId: this.mxId,
      custNo,
      custName,
      phoneNo: dto.phoneNo,
      returnUrl,
      callHash: this.hashForBillRegister(custNo),
      lang: 'ko',
    });

    const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
    const registration = await this.registrationRepo.save(
      this.registrationRepo.create({
        userId,
        custNo,
        custName,
        replacingBillKeyId: existing.id,
        expiresAt,
      }),
    );

    // 기존 카드는 콜백 성공 시까지 그대로 유지
    return { forwardUrl: data.forwardUrl, forwardMUrl: data.forwardMUrl, registrationId: registration.id };
  }

  // ── 빌키 삭제 ────────────────────────────────────────────────────

  async deleteBillKey(userId: string, billKeyId: string): Promise<void> {
    const record = await this.billKeyRepo.findOne({ where: { id: billKeyId, userId } });
    if (!record) {
      throw new NotFoundException('등록된 카드를 찾을 수 없습니다.');
    }

    // KPN에 삭제 요청
    try {
      await this.callKpnApi('/bill/delete', {
        mxId: this.mxId,
        billKey: record.billKey,
        callHash: this.hashForBillDelete(record.billKey),
      });
    } catch (err) {
      // KPN에서 이미 삭제된 경우 등 오류가 나도 로컬 비활성화는 진행
      this.logger.warn(`KPN 빌키 삭제 오류 (로컬 비활성화는 계속 진행): ${err}`);
    }

    // 로컬 비활성화 (hard delete 대신 soft 처리)
    await this.billKeyRepo.update({ id: billKeyId }, { isActive: false });
  }

  // ── 등록 세션 상태 조회 (폴링용) ─────────────────────────────────

  async getRegistrationStatus(registrationId: string, userId: string): Promise<BillKeyRegistrationStatusDto> {
    const registration = await this.registrationRepo.findOne({
      where: { id: registrationId, userId },
    });
    if (!registration) {
      throw new NotFoundException('등록 세션을 찾을 수 없습니다.');
    }
    return { completed: registration.completedAt != null };
  }

  // ── 만료된 등록 세션 정리 (스케줄러에서 호출) ──────────────────────

  async cleanupExpiredRegistrations(): Promise<void> {
    // 만료된 미완료 세션 삭제
    const expired = await this.registrationRepo.delete({
      expiresAt: LessThan(new Date()),
      completedAt: undefined,
    });
    // 완료 후 1시간 이상 지난 세션 삭제
    const completedBefore = new Date(Date.now() - 60 * 60 * 1000);
    const completed = await this.registrationRepo.delete({
      completedAt: LessThan(completedBefore),
    });
    const total = (expired.affected ?? 0) + (completed.affected ?? 0);
    if (total > 0) {
      this.logger.log(`등록 세션 정리 완료 (만료: ${expired.affected}건, 완료후정리: ${completed.affected}건)`);
    }
  }

  // ── 빌키 결제 승인 ────────────────────────────────────────────────

  async approveBillPayment(params: {
    userId: string;
    billKeyId: string;
    mxIssueNo: string;
    mxIssueDate: string;
    amount: number;
    goodsName: string;
  }): Promise<{ tid: string; authNo: string; payMethod: string; mxIssueNo: string; mxIssueDate: string }> {
    const { userId, billKeyId, mxIssueNo, mxIssueDate, amount, goodsName } = params;

    // 빌키 소유권 검증
    const billKeyRecord = await this.billKeyRepo.findOne({ where: { id: billKeyId, userId, isActive: true } });
    if (!billKeyRecord) {
      throw new NotFoundException('등록된 카드를 찾을 수 없습니다.');
    }

    const custNo = userId.replace(/-/g, '');

    const data = await this.callKpnApi<{ tid: string; authNo: string; payMethod: string; mxIssueNo: string; mxIssueDate: string }>(
      '/bill/approval',
      {
        mxId: this.mxId,
        custNo,
        billKey: billKeyRecord.billKey,
        mxIssueNo,
        mxIssueDate,
        amount,
        goodsName,
        callHash: this.hashForBillApproval(mxIssueNo, amount),
      },
    );

    const tid = data.tid?.trim();
    const authNo = data.authNo?.trim();
    if (!tid || !authNo) {
      this.logger.error(
        `KPN 빌키 결제 승인 응답 불완전: tid=${tid ?? ''} authNo=${authNo ?? ''} mxIssueNo=${mxIssueNo} amount=${amount} payMethod=${data.payMethod ?? ''}`,
      );
      throw new BadRequestException('카드 결제 승인에 실패했습니다. 카드를 다시 등록한 후 시도해 주세요.');
    }

    return {
      ...data,
      tid,
      authNo,
    };
  }
}
