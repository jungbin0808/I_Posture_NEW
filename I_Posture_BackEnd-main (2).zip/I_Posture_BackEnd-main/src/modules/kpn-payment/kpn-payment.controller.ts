import { Body, Controller, Delete, Get, Param, Post, Req, Res, UseGuards } from '@nestjs/common';
import { Response } from 'express';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { KpnPaymentService } from './kpn-payment.service';
import {
  BillKeyCallbackDto,
  BillKeyResponseDto,
  BillKeyRegistrationStatusDto,
  BillRegisterUrlResponseDto,
  GetBillRegisterUrlDto,
} from './dto/kpn-payment.dto';

@ApiTags('KPN Payment')
@Controller('payment')
export class KpnPaymentController {
  constructor(private readonly kpnPaymentService: KpnPaymentService) {}

  /**
   * 카드 등록 URL 발급
   * - 클라이언트가 이 URL로 이동하면 KPN 카드 등록 UI가 열림
   * - 등록 완료 후 KPN이 returnUrl로 billKey를 전달
   */
  @ApiOperation({ summary: '빌키 등록 URL 발급 (KPN 카드 등록 화면 URL 반환)' })
  @ApiBearerAuth()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Member, Role.FreelancerTrainer, Role.Center, Role.CenterTrainer)
  @Post('bill-key/register-url')
  async getBillRegisterUrl(
    @Req() req: { user: UserEntity },
    @Body() dto: GetBillRegisterUrlDto,
  ): Promise<ISuccessResponse<BillRegisterUrlResponseDto>> {
    const result = await this.kpnPaymentService.getBillRegisterUrl(req.user.id, dto);
    return SuccessResponse(result);
  }

  /**
   * 빌키 등록 콜백 (KPN returnUrl)
   * - KPN이 카드 등록 완료 후 Form Submit 방식으로 호출
   * - 인증 없이 수신 (KPN 서버 → 우리 서버), hashData로 위변조 검증
   */
  @ApiOperation({ summary: '빌키 등록 콜백 수신 (KPN → 서버, 내부용)' })
  @Post('bill-key/callback')
  async billKeyCallback(
    @Body() body: Record<string, unknown>,
    @Res() res: Response,
  ): Promise<void> {
    await this.kpnPaymentService.handleBillKeyCallback(body);
    res.send(`
      <html><body><script>
        alert('카드 등록이 완료되었습니다. 우측 상단의 닫기 버튼을 눌러 창을 닫아주세요.');
        window.close();
      </script></body></html>
    `);
  }

  /**
   * 빌키 등록 세션 상태 조회 (폴링용)
   * - registrationId로 등록 완료 여부 확인
   * - completed: true → 팝업 닫기
   */
  @ApiOperation({ summary: '카드 등록 완료 여부 폴링' })
  @ApiBearerAuth()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Member, Role.FreelancerTrainer, Role.Center, Role.CenterTrainer)
  @Get('bill-key/registration/:registrationId/status')
  async getRegistrationStatus(
    @Req() req: { user: UserEntity },
    @Param('registrationId') registrationId: string,
  ): Promise<ISuccessResponse<BillKeyRegistrationStatusDto>> {
    const result = await this.kpnPaymentService.getRegistrationStatus(registrationId, req.user.id);
    return SuccessResponse(result);
  }

  /**
   * 등록된 카드(빌키) 목록 조회
   */
  @ApiOperation({ summary: '등록된 카드 목록 조회' })
  @ApiBearerAuth()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Member, Role.FreelancerTrainer, Role.Center, Role.CenterTrainer)
  @Get('bill-keys')
  async getBillKeys(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<BillKeyResponseDto[]>> {
    const result = await this.kpnPaymentService.getBillKeys(req.user.id);
    return SuccessResponse(result);
  }

  /**
   * 카드(빌키) 삭제
   * - KPN에 삭제 요청 후 로컬 비활성화 처리
   */
  @ApiOperation({ summary: '등록된 카드 삭제' })
  @ApiBearerAuth()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Member, Role.FreelancerTrainer, Role.Center, Role.CenterTrainer)
  @Delete(['bill-keys/:id', 'bill-key/:id'])
  async deleteBillKey(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    await this.kpnPaymentService.deleteBillKey(req.user.id, id);
    return SuccessResponse({ success: true });
  }

  /**
   * 카드 교체 (기존 카드 삭제 + 새 등록 URL 발급)
   */
  @ApiOperation({ summary: '카드 교체 (기존 카드 삭제 후 새 등록 URL 발급)' })
  @ApiBearerAuth()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Member, Role.FreelancerTrainer, Role.Center, Role.CenterTrainer)
  @Post('bill-key/replace-url')
  async replaceBillKey(
    @Req() req: { user: UserEntity },
    @Body() dto: GetBillRegisterUrlDto,
  ): Promise<ISuccessResponse<BillRegisterUrlResponseDto>> {
    const result = await this.kpnPaymentService.replaceBillKey(req.user.id, dto);
    return SuccessResponse(result);
  }
}
