import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConfigModule } from '@nestjs/config';
import { BillKeyEntity } from '../../database/entities/bill-key.entity';
import { BillKeyRegistrationEntity } from '../../database/entities/bill-key-registration.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { KpnPaymentService } from './kpn-payment.service';
import { KpnPaymentController } from './kpn-payment.controller';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([BillKeyEntity, BillKeyRegistrationEntity, UserEntity]),
  ],
  controllers: [KpnPaymentController],
  providers: [KpnPaymentService],
  exports: [KpnPaymentService],
})
export class KpnPaymentModule {}
