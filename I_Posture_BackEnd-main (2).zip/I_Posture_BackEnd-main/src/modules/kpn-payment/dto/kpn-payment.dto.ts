import { IsOptional, IsString } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

/** POST /payment/bill-key/register-url 요청 */
export class GetBillRegisterUrlDto {
  @ApiPropertyOptional({
    description: '주문자명 (미입력 시 회원명 user.name 사용)',
  })
  @IsOptional()
  @IsString()
  cardHolderName?: string;

  @ApiPropertyOptional({
    description: 'cardHolderName과 동일 (하위 호환)',
    deprecated: true,
  })
  @IsOptional()
  @IsString()
  custName?: string;

  @ApiPropertyOptional({ description: '주문자 휴대폰번호 (- 제거)' })
  @IsOptional()
  @IsString()
  phoneNo?: string;

  @ApiPropertyOptional({ description: '빌키 등록 완료 후 리다이렉트 URL (기본값: 환경변수 KPN_BILL_RETURN_URL)' })
  @IsOptional()
  @IsString()
  returnUrl?: string;
}

/** POST /payment/bill-key/register-url 응답 */
export class BillRegisterUrlResponseDto {
  /** PC용 KPN 카드 등록 화면 URL */
  forwardUrl!: string;
  /** 모바일용 KPN 카드 등록 화면 URL */
  forwardMUrl!: string;
  /** 폴링에 사용할 등록 세션 ID */
  registrationId!: string;
}

/** GET /payment/bill-key/registration/:id/status 응답 */
export class BillKeyRegistrationStatusDto {
  /** 카드 등록 완료 여부 */
  completed!: boolean;
}

/** KPN returnUrl 콜백 바디 (Form Submit) */
export class BillKeyCallbackDto {
  @IsString()
  code!: string;

  @IsOptional()
  @IsString()
  message?: string;

  @IsString()
  mxId!: string;

  @IsOptional()
  @IsString()
  billKey?: string;

  @IsString()
  custNo!: string;

  @IsOptional()
  @IsString()
  custName?: string;

  @IsOptional()
  @IsString()
  issCd?: string;

  @IsOptional()
  @IsString()
  cardNo?: string;

  @IsOptional()
  @IsString()
  cardExp?: string;

  @IsOptional()
  @IsString()
  hashData?: string;

  @IsOptional()
  @IsString()
  checkYn?: string;

  @IsOptional()
  @IsString()
  billKeyType?: string;

  @IsOptional()
  @IsString()
  viewCardNo?: string;

  @IsOptional()
  @IsString()
  appFlag?: string;
}

/** 등록된 빌키 목록 응답 */
export class BillKeyResponseDto {
  id!: string;
  @ApiPropertyOptional({ description: '카드 소유주명 (회원명, KPN 주문자명)' })
  custName?: string;
  viewCardNo?: string;
  cardExp?: string;
  issCd?: string;
  issName?: string;
  checkYn?: string;
  billKeyType?: string;
  isActive!: boolean;
  createdAt!: Date;
}
