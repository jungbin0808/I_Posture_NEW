import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BannerEntity, BannerPosition } from '../../database/entities/banner.entity';

@Injectable()
export class BannerService {
  constructor(
    @InjectRepository(BannerEntity)
    private readonly bannerRepo: Repository<BannerEntity>,
  ) {}

  async findActiveByPosition(position: BannerPosition): Promise<BannerEntity[]> {
    return this.bannerRepo.find({
      where: { position, isActive: true },
      order: { sortOrder: 'ASC' },
    });
  }
}
