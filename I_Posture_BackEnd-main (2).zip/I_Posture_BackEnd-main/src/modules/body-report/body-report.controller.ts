import { Controller, Get, Post, Body, Put, Param, Delete, UseGuards, Req, Query, Headers, ForbiddenException } from '@nestjs/common';
import { BodyReportService } from './body-report.service';
import { ApiBearerAuth, ApiOperation, ApiTags, ApiHeader } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse, IPageData } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { BodyReportResponseDto, BodyReportDetailResponseDto } from './dto/body-report-response.dto';
import { BodyMeasurementReportResponseDto } from '../measurement-report/dto/measurement-report-response.dto';
import { resolveReportDisplayLanguage } from '../../common/helpers/resolve-report-display-language.helper';
import { FindBodyReportDto } from './dto/find-body-report.dto';
import { DeleteBodyReportsDto } from './dto/delete-body-reports.dto';
import { UpdateBodyReportDto } from './dto/update-body-report.dto';
import { UpdateBodyReportCommentDto } from './dto/update-body-report-comment.dto';

@ApiTags('BodyReport')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('body-reports')
export class BodyReportController {
  constructor(private readonly bodyReportService: BodyReportService) {}

  @ApiOperation({ summary: '내 체형 리포트 상세 조회 (회원 본인, 셀프측정/트레이너측정 모두 포함) - 트레이너 앱과 동일한 풀 리포트' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @Roles(Role.Member)
  @Get('me/:id')
  async findOneForOwnMember(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<BodyMeasurementReportResponseDto>> {
    const data = await this.bodyReportService.findOneForOwnMember(
      req.user.id,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '회원의 체형 리포트 목록 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() dto: FindBodyReportDto,
  ): Promise<IPageData<BodyReportResponseDto>> {
    const data = await this.bodyReportService.findAllByMemberId(req.user.id, memberId, dto);
    return data;
  }

  @ApiOperation({ summary: '체형 리포트 상세 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/:id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<BodyReportDetailResponseDto>> {
    const data = await this.bodyReportService.findOne(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '체형 리포트 코멘트 저장/수정' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put('member/:memberId/:id/comment')
  async updateComment(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() dto: UpdateBodyReportCommentDto,
  ): Promise<ISuccessResponse<BodyReportDetailResponseDto>> {
    const data = await this.bodyReportService.updateComment(req.user.id, memberId, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '체형 리포트 일괄 삭제' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() deleteDto: DeleteBodyReportsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.bodyReportService.delete(req.user.id, memberId, deleteDto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '내 체형 리포트 일괄 삭제 (회원 본인, 셀프측정분만 가능)' })
  @Roles(Role.Member)
  @Delete('me')
  async deleteSelf(
    @Req() req: { user: UserEntity },
    @Body() deleteDto: DeleteBodyReportsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.bodyReportService.deleteSelf(req.user.id, deleteDto);
    return SuccessResponse(data);
  }
}
