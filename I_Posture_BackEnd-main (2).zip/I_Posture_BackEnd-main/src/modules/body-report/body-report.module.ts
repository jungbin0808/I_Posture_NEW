import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { BodyReportController } from './body-report.controller';
import { BodyReportService } from './body-report.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { CapacityModule } from '../capacity/capacity.module';
import { MeasurementReportModule } from '../measurement-report/measurement-report.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BodyReportEntity,
      UserEntity,
      TrainerUserEntity,
      FileEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
      MemberIdentityLinkEntity,
    ]),
    CapacityModule,
    MeasurementReportModule,
  ],
  controllers: [BodyReportController],
  providers: [BodyReportService, SubscriptionGuard],
  exports: [BodyReportService],
})
export class BodyReportModule {}
