import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export enum BodyReportSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindBodyReportDto extends PaginationDto {
  @ApiProperty({ description: '조회 시작 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '조회 종료 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({ description: '정렬 순서', enum: BodyReportSortOrder, required: false, default: BodyReportSortOrder.DATE_DESC })
  @IsEnum(BodyReportSortOrder)
  @IsOptional()
  sort?: BodyReportSortOrder = BodyReportSortOrder.DATE_DESC;
}
