import { ApiProperty } from '@nestjs/swagger';
import { BodyMeasurementDetailDto } from './body-measurement-detail.dto';

class BodyPartScoreItemDto {
  @ApiProperty({ description: '부위 키 (NECK, SHOULDER, PELVIS_WAIST, LEG_ALIGNMENT, KNEE, ANKLE)' })
  key!: string;

  @ApiProperty({ description: '부위명' })
  label!: string;

  @ApiProperty({ description: '점수 (0~100, 높을수록 좋음)' })
  score!: number;
}

class BodyPartScoresDto {
  @ApiProperty({ description: '평균 점수 (6개 부위)' })
  average!: number;

  @ApiProperty({ description: '6개 부위 점수 항목', type: [BodyPartScoreItemDto] })
  items!: BodyPartScoreItemDto[];
}

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '관련 타입 (BODY)' })
  relatedType?: string;

  @ApiProperty({ description: '구분 (FRONT, SIDE, BACK)', nullable: true })
  division?: string;
}

class MajorDiseaseDto {
  @ApiProperty({ description: '질환 키' })
  key!: string;

  @ApiProperty({ description: '질환 한글명' })
  label!: string;
}

export class BodyReportResponseDto {
  @ApiProperty({ description: '리포트 ID' })
  id!: string;

  @ApiProperty({ description: '측정일시' })
  createdAt!: Date;

  @ApiProperty({ description: '종합 점수' })
  totalScore!: number;

  @ApiProperty({ description: '코멘트', nullable: true })
  comment?: string;

  @ApiProperty({ description: '주요 체형 유형', type: [MajorDiseaseDto] })
  majorDiseases!: MajorDiseaseDto[];
}

export class BodyReportDetailResponseDto extends BodyReportResponseDto {
  @ApiProperty({ description: '분석 데이터 (JSON)' })
  analysisData!: any;

  @ApiProperty({ description: '부위별 체형 점수 (6개 항목, scoreUsage 기반)', type: BodyPartScoresDto })
  bodyPartScores!: BodyPartScoresDto;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto] })
  files!: FileDto[];
}

// 체형측정 리포트 전체 구조 응답 (새로 추가)
export class BodyReportFullResponseDto {
  @ApiProperty({ description: '리포트 ID' })
  id!: string;

  @ApiProperty({ description: '측정일시' })
  createdAt!: Date;

  @ApiProperty({ description: '체형측정 리포트 상세 데이터', type: BodyMeasurementDetailDto })
  reportData!: BodyMeasurementDetailDto;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto] })
  files!: FileDto[];
}

