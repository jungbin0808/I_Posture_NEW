import { ApiProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class UpdateBodyReportCommentDto {
  @ApiProperty({ description: '트레이너 총평 코멘트' })
  @IsString()
  comment!: string;
}
