import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString } from 'class-validator';

export class UpdateBodyReportDto {
  @ApiProperty({ description: '종합 점수', required: false })
  @IsInt()
  @IsOptional()
  totalScore?: number;

  @ApiProperty({ description: '상세 분석 데이터 (JSON)', required: false })
  @IsOptional()
  analysisData?: any;

  @ApiProperty({ description: '트레이너 총평', required: false })
  @IsString()
  @IsOptional()
  comment?: string;
}
