import { ApiProperty } from '@nestjs/swagger';

// 공통 Asset 타입
class AssetDto {
  @ApiProperty({ description: 'Asset Key (이미지 식별자)', required: false })
  assetKey?: string;

  @ApiProperty({ description: '이미지 URL', required: false })
  url?: string | null;
}

// 회원 정보
class MemberInfoDto {
  @ApiProperty({ description: '회원명' })
  name!: string;

  @ApiProperty({ description: '생년월일' })
  birthDate!: string;

  @ApiProperty({ description: '성별' })
  gender!: string;

  @ApiProperty({ description: '촬영일' })
  shootingDate!: string;
}

// 종합 체형 점수 - 분포
class ScoreRangeDto {
  @ApiProperty({ description: '단계 레이블' })
  label!: string;

  @ApiProperty({ description: '최소 점수' })
  min!: number;

  @ApiProperty({ description: '최대 점수' })
  max!: number;
}

class CurrentScoreDto {
  @ApiProperty({ description: '현재 단계 레이블' })
  label!: string;

  @ApiProperty({ description: '현재 점수' })
  score!: number;
}

class ScoreDistributionDto {
  @ApiProperty({ description: '점수 범위 목록', type: [ScoreRangeDto] })
  ranges!: ScoreRangeDto[];

  @ApiProperty({ description: '현재 점수 정보', type: CurrentScoreDto })
  current!: CurrentScoreDto;
}

// 종합 체형 점수 - 추이
class TrendPointDto {
  @ApiProperty({ description: '날짜 레이블' })
  label!: string;

  @ApiProperty({ description: '점수', required: false })
  score?: number | null;
}

class ScoreTrendDto {
  @ApiProperty({ description: 'X축 레이블 목록', type: [String] })
  xAxisLabels!: string[];

  @ApiProperty({ description: '점수 포인트 목록', type: [TrendPointDto] })
  points!: TrendPointDto[];

  @ApiProperty({ description: '참고사항', required: false })
  note?: string;
}

// 종합 체형 점수
class TotalScoreDto {
  @ApiProperty({ description: '종합 점수' })
  score!: number;

  @ApiProperty({ description: '헤드라인 문구' })
  headline!: string;

  @ApiProperty({ description: '단계 설명 문구' })
  stageText!: string;

  @ApiProperty({ description: '점수 분포', type: ScoreDistributionDto })
  distribution!: ScoreDistributionDto;

  @ApiProperty({ description: '점수 추이', type: ScoreTrendDto })
  trend!: ScoreTrendDto;
}

// 주요 체형
class PostureCardDto {
  @ApiProperty({ description: '체형 유형명' })
  label!: string;

  @ApiProperty({ description: 'Asset Key' })
  assetKey!: string;

  @ApiProperty({ description: '테두리 스타일' })
  borderStyle!: string;
}

class MajorPosturesDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '체형 카드 목록', type: [PostureCardDto] })
  cards!: PostureCardDto[];

  @ApiProperty({ description: '참고사항', required: false })
  note?: string;
}

// 사진 분석 - 후면
class BackAnalysisDto {
  @ApiProperty({ description: '이미지', type: AssetDto })
  image!: AssetDto;

  @ApiProperty({ description: '패널 제목' })
  panelTitle!: string;

  @ApiProperty({ description: '분석 내용', type: [String] })
  bullets!: string[];
}

// 사진 분석 - 정면/측면 섹션
class PhotoAnalysisSectionDto {
  @ApiProperty({ description: '부위 제목' })
  title!: string;

  @ApiProperty({ description: '레벨 컬러' })
  levelColor!: string;

  @ApiProperty({ description: '분석 내용', type: [String] })
  bullets!: string[];
}

class FrontSideAnalysisDto {
  @ApiProperty({ description: '이미지', type: AssetDto })
  image!: AssetDto;

  @ApiProperty({ description: '패널 제목' })
  panelTitle!: string;

  @ApiProperty({ description: '분석 섹션 목록', type: [PhotoAnalysisSectionDto] })
  sections!: PhotoAnalysisSectionDto[];
}

class PhotoAnalysisDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '후면 분석', type: BackAnalysisDto })
  back!: BackAnalysisDto;

  @ApiProperty({ description: '정면 분석', type: FrontSideAnalysisDto })
  front!: FrontSideAnalysisDto;

  @ApiProperty({ description: '측면 분석', type: FrontSideAnalysisDto })
  side!: FrontSideAnalysisDto;
}

// 체형 상세 - 근사용 불균형
class MuscleImbalanceDto {
  @ApiProperty({ description: '과긴장 근육 목록', type: [String] })
  tight!: string[];

  @ApiProperty({ description: '저활성화 근육 목록', type: [String] })
  weak!: string[];
}

class PostureDetailAnalysisDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '체형 키' })
  postureKey!: string;

  @ApiProperty({ description: '근육도 이미지', type: AssetDto })
  figure!: AssetDto;

  @ApiProperty({ description: '근사용 불균형', type: MuscleImbalanceDto })
  muscleImbalance!: MuscleImbalanceDto;

  @ApiProperty({ description: '신체적 불편감', type: [String] })
  discomfort!: string[];

  @ApiProperty({ description: '외형 인상', type: [String] })
  impression!: string[];
}

// 체형 상세 - 주의 습관
class HabitAssetDto {
  @ApiProperty({ description: '습관명' })
  label!: string;

  @ApiProperty({ description: 'Asset Key' })
  assetKey!: string;

  @ApiProperty({ description: '이미지 URL', required: false })
  url?: string | null;
}

class PostureDetailHabitDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '체형 키' })
  postureKey!: string;

  @ApiProperty({ description: '주의 습관 목록', type: [HabitAssetDto] })
  cautionHabits!: HabitAssetDto[];

  @ApiProperty({ description: '참고사항', required: false })
  note?: string;
}

// 권장 생활 습관
class RecommendedSectionDto {
  @ApiProperty({ description: '섹션 제목' })
  title!: string;

  @ApiProperty({ description: 'Asset 목록', type: [AssetDto] })
  assets!: AssetDto[];

  @ApiProperty({ description: '권장사항', type: [String] })
  bullets!: string[];
}

class RecommendedHabitsDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '섹션 목록', type: [RecommendedSectionDto] })
  sections!: RecommendedSectionDto[];
}

// 종합 요약 - 골격 이미지
class SkeletonRowDto {
  @ApiProperty({ description: '뷰 타입 (back/front/side)' })
  view!: string;

  @ApiProperty({ description: '현재 골격', type: AssetDto })
  current!: AssetDto;

  @ApiProperty({ description: '미래 골격', type: AssetDto })
  future!: AssetDto;

  @ApiProperty({ description: '정상 골격', type: AssetDto })
  normal!: AssetDto;
}

class SkeletonDto {
  @ApiProperty({ description: '골격 이미지 행 목록', type: [SkeletonRowDto] })
  rows!: SkeletonRowDto[];
}

// 종합 요약 - 수치 정보
class HeightLossDto {
  @ApiProperty({ description: '레이블' })
  label!: string;

  @ApiProperty({ description: '값' })
  value!: number;

  @ApiProperty({ description: '단위' })
  unit!: string;
}

class NeckLoadDto {
  @ApiProperty({ description: '레이블' })
  label!: string;

  @ApiProperty({ description: '값' })
  value!: number;

  @ApiProperty({ description: '단위' })
  unit!: string;

  @ApiProperty({ description: '설명' })
  description!: string;
}

// 종합 요약 - 신체 균형
class BalanceStateDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '설명' })
  description!: string;
}

// 종합 요약 - 부위별 점수
class BodyFunctionScoreItemDto {
  @ApiProperty({ description: '부위 키' })
  key!: string;

  @ApiProperty({ description: '부위명' })
  label!: string;

  @ApiProperty({ description: '점수' })
  score!: number;

  @ApiProperty({ description: '상태 컬러' })
  statusColor!: string;
}

class BodyFunctionScoresDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '부위별 점수 항목', type: [BodyFunctionScoreItemDto] })
  items!: BodyFunctionScoreItemDto[];

  @ApiProperty({ description: '범례', type: [String] })
  legend!: string[];
}

// 종합 요약 - 전체 단계
class OverallStageDto {
  @ApiProperty({ description: '단계 레이블' })
  label!: string;

  @ApiProperty({ description: '점수' })
  score!: number;
}

// 종합 요약 - 종합 콘텐츠
class CombinedContentDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: 'Placeholder' })
  placeholder!: string;
}

// 종합 요약
class SummaryDto {
  @ApiProperty({ description: '제목' })
  title!: string;

  @ApiProperty({ description: '골격 이미지', type: SkeletonDto })
  skeleton!: SkeletonDto;

  @ApiProperty({ description: '키손실', type: HeightLossDto })
  heightLoss!: HeightLossDto;

  @ApiProperty({ description: '목 부담', type: NeckLoadDto })
  neckLoad!: NeckLoadDto;

  @ApiProperty({ description: '신체 균형 상태', type: BalanceStateDto })
  balanceState!: BalanceStateDto;

  @ApiProperty({ description: '신체 부위별 기능 점수', type: BodyFunctionScoresDto })
  bodyFunctionScores!: BodyFunctionScoresDto;

  @ApiProperty({ description: '종합 단계', type: OverallStageDto })
  overallStage!: OverallStageDto;

  @ApiProperty({ description: '종합 조언' })
  overallAdvice!: string;

  @ApiProperty({ description: '종합 콘텐츠', type: CombinedContentDto })
  combinedContent!: CombinedContentDto;

  @ApiProperty({ description: '면책 조항', type: [String] })
  disclaimer!: string[];
}

// 체형측정 리포트 상세 데이터
export class BodyMeasurementDetailDto {
  @ApiProperty({ description: '리포트 제목' })
  reportTitle!: string;

  @ApiProperty({ description: '발행일' })
  issuedAt!: string;

  @ApiProperty({ description: '회원 정보', type: MemberInfoDto })
  member!: MemberInfoDto;

  @ApiProperty({ description: '종합 체형 점수', type: TotalScoreDto })
  totalScore!: TotalScoreDto;

  @ApiProperty({ description: '주요 체형', type: MajorPosturesDto })
  majorPostures!: MajorPosturesDto;

  @ApiProperty({ description: '사진 분석', type: PhotoAnalysisDto })
  photoAnalysis!: PhotoAnalysisDto;

  @ApiProperty({ description: '체형 상세 분석', type: [Object] })
  postureDetails!: Array<PostureDetailAnalysisDto | PostureDetailHabitDto>;

  @ApiProperty({ description: '권장 생활 습관', type: RecommendedHabitsDto })
  recommendedHabits!: RecommendedHabitsDto;

  @ApiProperty({ description: '종합 요약', type: SummaryDto })
  summary!: SummaryDto;
}

