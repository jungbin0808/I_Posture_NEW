import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { FindBodyReportDto } from './dto/find-body-report.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { BodyReportResponseDto, BodyReportDetailResponseDto } from './dto/body-report-response.dto';
import { DeleteBodyReportsDto } from './dto/delete-body-reports.dto';
import { UpdateBodyReportCommentDto } from './dto/update-body-report-comment.dto';
import {
  BODY_PART_SCORE_KEYS,
  calculateBodyPartScoreFromDetail,
} from '../analysis/helpers/body-score-usage.helper';
import { rankBodyDiseases } from '../consultation-log/action-plan.helper';
import { StoredFileReleaseService } from '../capacity/stored-file-release.service';
import { Transactional } from 'typeorm-transactional';
import { MeasurementReportService } from '../measurement-report/measurement-report.service';
import { BodyMeasurementReportResponseDto } from '../measurement-report/dto/measurement-report-response.dto';
import { ReportDisplayLanguage } from '../../common/helpers/resolve-report-display-language.helper';

const DISEASE_KEY_TO_LABEL: Record<string, string> = {
    NECK_TILT: "목 가쪽굽힘",
    NECK_ROTATION: "목 회전",
    TURTLE_NECK: "거북목",
    RAISED_NECK: "들임목",
    STRAIGHT_NECK: "일자목",
    RAISED_SHOULDER: "올라간 어깨",
    DROPPED_SHOULDER: "처진 어깨",
    SHOULDER_HEIGHT_ASYMMETRY: "어깨높이 비대칭",
    ROUNDED_SHOULDER: "라운드숄더",
    STRAIGHT_SHOULDER: "과도하게 펴진 어깨",
    PELVIS_ASYMMETRY: "골반 비대칭",
    PELVIS_ROTATION_LEFT: "골반 왼쪽 회전",
    PELVIS_ROTATION_RIGHT: "골반 오른쪽 회전",
    PELVIS_MOVE_RIGHT: "오른쪽으로 이동된 골반",
    PELVIS_MOVE_LEFT: "왼쪽으로 이동된 골반",
    PELVIS_TILTS_FORWARD: "허리 과전만 & 골반 전방경사",
    PELVIS_TILTS_BACKWARD: "일자허리 & 골반 후방경사",
    SWAY_BACK: "스웨이백",
    BOW_LEGS: "오다리",
    KNOCK_LEGS: "엑스다리",
    BENT_KNEES: "굽혀진 무릎",
    BACK_KNEES: "과하게 펴진 무릎",
    ARCHED_FEET: "오목발",
    FLAT_FEET: "평발",
    ANKLE_MOVE_OUTWARD: "발목 바깥쪽",
    ANKLE_MOVE_INWARD: "발목 안쪽",
    HUNCHED_BACK: "굽은등",
    FLAT_BACK: "펴진등",
    ARMS_TURNED_IN: "위팔 안쪽돌림",
    ARMS_TURNED_OUT: "위팔 가쪽돌림",
    BENT_ELBOW: "굽혀진 팔꿈치",
    EXTENDED_ELBOW: "과하게 펴진팔꿈치",
    TORSO_TILTED_RIGHT: "몸통 오른쪽 가쪽굽힘",
    TORSO_TILTED_LEFT: "몸통 왼쪽 가쪽굽힘",
    TORSO_ROTATION_LEFT: "회전된 몸통(왼쪽)",
    TORSO_ROTATION_RIGHT: "회전된 몸통(오른쪽)",
    LEGS_TURNED_OUTWARD: "넙다리 가쪽돌림",
    LEGS_TURNED_INWARD: "넙다리 안쪽돌림",
    SPINAL_ALIGNMENT_TEST: "척추측만증",
    NORMAL: "정상",
};

@Injectable()
export class BodyReportService {
  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly storedFileReleaseService: StoredFileReleaseService,
    private readonly measurementReportService: MeasurementReportService,
  ) {}

  /**
   * 회원의 체형 리포트 목록을 조회합니다.
   */
  async findAllByMemberId(trainerId: string, memberId: string, dto: FindBodyReportDto): Promise<IPageData<BodyReportResponseDto>> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const { page = 1, limit = 10, startDate, endDate, sort } = dto;
    const query = this.bodyReportRepo.createQueryBuilder('report')
      .where('report.userId = :userId', { userId: memberId });

    if (startDate) query.andWhere('report.createdAt >= :startDate', { startDate });
    if (endDate) query.andWhere('report.createdAt <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('report.createdAt', sortDirection);

    const total = await query.getCount();
    const reports = await query.offset((page - 1) * limit).limit(limit).getMany();

    const items: BodyReportResponseDto[] = reports.map(report => {
      const diseases = report.analysisData?.disease || [];
      const majorDiseases = rankBodyDiseases(diseases)
        .slice(0, 3)
        .map((d) => ({
          key: d.key,
          label: DISEASE_KEY_TO_LABEL[d.key] || d.label,
        }));

      return {
        id: report.id,
        createdAt: report.createdAt,
        totalScore: report.totalScore,
        comment: report.comment,
        majorDiseases,
      };
    });

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 체형 리포트 상세 정보를 조회합니다.
   */
  async findOne(trainerId: string, memberId: string, id: string): Promise<BodyReportDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const report = await this.bodyReportRepo.findOne({ where: { id, userId: memberId } });
    if (!report) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

    return this.buildDetail(report);
  }

  /**
   * 내 체형 리포트 상세 조회 (회원 본인용) - 셀프측정 본인 소유이거나, 연동된 트레이너가 측정한 것만 허용
   */
  /**
   * 회원 본인 상세 조회 - 트레이너 앱과 동일한 풀 리포트(MeasurementReportService)를 그대로 반환한다.
   * 프론트가 필요한 필드만 골라 쓰면 되므로, 트레이너용과 다른 축약 응답을 따로 만들지 않는다.
   */
  async findOneForOwnMember(appMemberId: string, id: string, lang: ReportDisplayLanguage = 'ko'): Promise<BodyMeasurementReportResponseDto> {
    const report = await this.bodyReportRepo.findOne({ where: { id } });
    if (!report) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

    const isSelfOwned = report.userId === appMemberId && !report.trainerId;
    let isOwnedByLinkedTrainer = false;
    if (!isSelfOwned && report.trainerId) {
      const managedMemberId = await this.resolveManagedMemberId(appMemberId);
      isOwnedByLinkedTrainer = !!managedMemberId && report.userId === managedMemberId;
    }

    if (!isSelfOwned && !isOwnedByLinkedTrainer) {
      throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');
    }

    return this.measurementReportService.getBodyMeasurementReport(report.userId, id, lang);
  }

  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.managedMemberId ?? null;
  }

  private async buildDetail(report: BodyReportEntity): Promise<BodyReportDetailResponseDto> {
    const files = await this.fileRepo.find({ where: { relatedId: report.id } });

    const diseases = report.analysisData?.disease || [];
    const majorDiseases = rankBodyDiseases(diseases)
      .slice(0, 3)
      .map((d) => ({
        key: d.key,
        label: DISEASE_KEY_TO_LABEL[d.key] || d.label,
      }));

    const bodyPartScores = BodyReportService.calculateBodyPartScores(report.analysisData);

    return {
      id: report.id,
      createdAt: report.createdAt,
      totalScore: report.totalScore,
      comment: report.comment,
      analysisData: report.analysisData,
      majorDiseases,
      bodyPartScores,
      files: files.map(f => ({
        id: f.id,
        fileUrl: f.fileUrl,
        division: f.division,
      })),
    };
  }

  /**
   * 체형 리포트 코멘트를 저장/수정합니다.
   */
  async updateComment(trainerId: string, memberId: string, id: string, dto: UpdateBodyReportCommentDto): Promise<BodyReportDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 수정할 권한이 없습니다.');

    const report = await this.bodyReportRepo.findOne({ where: { id, userId: memberId } });
    if (!report) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

    if (report.trainerId !== trainerId) throw new ForbiddenException('이 리포트를 수정할 권한이 없습니다.');

    await this.bodyReportRepo.update(id, { comment: dto.comment });

    return this.findOne(trainerId, memberId, id);
  }

  /**
   * 체형 리포트를 일괄 삭제합니다. (논리적 삭제)
   */
  @Transactional()
  async delete(trainerId: string, memberId: string, dto: DeleteBodyReportsDto): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 삭제할 권한이 없습니다.');

    const reports = await this.bodyReportRepo.find({ where: { id: In(dto.ids), userId: memberId } });
    if (reports.length !== dto.ids.length) {
      throw new NotFoundException('일부 체형 리포트를 찾을 수 없습니다.');
    }

    for (const report of reports) {
      if (report.trainerId !== trainerId) {
        throw new ForbiddenException(`리포트 ${report.id}를 삭제할 권한이 없습니다.`);
      }
    }

    await this.storedFileReleaseService.releaseForTrainer(trainerId, dto.ids);
    await this.bodyReportRepo.softDelete(dto.ids);
    return { success: true };
  }

  /**
   * 내 체형 리포트 삭제 (회원 본인용) - 셀프측정분만 삭제 가능. 트레이너가 측정한 기록은
   * 회원이 임의로 지울 수 없게 막는다(트레이너 업무 기록 보호).
   */
  @Transactional()
  async deleteSelf(appMemberId: string, dto: DeleteBodyReportsDto): Promise<{ success: boolean }> {
    const reports = await this.bodyReportRepo.find({ where: { id: In(dto.ids), userId: appMemberId } });
    if (reports.length !== dto.ids.length) {
      throw new NotFoundException('일부 체형 리포트를 찾을 수 없습니다.');
    }
    if (reports.some((report) => report.trainerId)) {
      throw new ForbiddenException('트레이너가 측정한 체형 리포트는 직접 삭제할 수 없습니다.');
    }

    await this.bodyReportRepo.softDelete(dto.ids);
    return { success: true };
  }

  /**
   * 체형리포트와 동일한 로직으로 부위별 점수를 계산합니다.
   * scoreUsage (품질 점수, 높을수록 좋음) 기준으로 각 부위 내 최솟값을 사용합니다.
   * 표시 6개 항목: 목/어깨/골반·허리/하지정렬/무릎/발목
   */
  public static getScoreLevel(average: number): { key: string; label: string } {
    if (average >= 90) return { key: 'EXCELLENT', label: '매우 좋음' };
    if (average >= 75) return { key: 'GOOD',      label: '좋음' };
    if (average >= 60) return { key: 'AVERAGE',   label: '보통' };
    if (average >= 40) return { key: 'POOR',      label: '나쁨' };
    return                     { key: 'VERY_POOR', label: '매우 나쁨' };
  }

  public static calculateBodyPartScores(analysisData: any) {
    try {
      const sd = analysisData?.scoreDetail || {};

      const neck = calculateBodyPartScoreFromDetail(sd.neck, BODY_PART_SCORE_KEYS.neck);
      const shoulder = calculateBodyPartScoreFromDetail(sd.shoulder, BODY_PART_SCORE_KEYS.shoulder, sd);
      const pelvisWaist = calculateBodyPartScoreFromDetail(sd.pelvis, BODY_PART_SCORE_KEYS.pelvis);
      const legAlignment = calculateBodyPartScoreFromDetail(sd.lowerLimbAlignment, BODY_PART_SCORE_KEYS.lowerLimbAlignment);
      const knee = calculateBodyPartScoreFromDetail(sd.knee, BODY_PART_SCORE_KEYS.knee);
      const ankle = calculateBodyPartScoreFromDetail(sd.ankle, BODY_PART_SCORE_KEYS.ankle);
      const average     = Math.round((neck + shoulder + pelvisWaist + legAlignment + knee + ankle) / 6);

      return {
        average,
        level: BodyReportService.getScoreLevel(average),
        items: [
          { key: 'NECK',          label: '목',       score: neck },
          { key: 'SHOULDER',      label: '어깨',     score: shoulder },
          { key: 'PELVIS_WAIST',  label: '골반/허리', score: pelvisWaist },
          { key: 'LEG_ALIGNMENT', label: '하지정렬',  score: legAlignment },
          { key: 'KNEE',          label: '무릎',     score: knee },
          { key: 'ANKLE',         label: '발목',     score: ankle },
        ],
      };
    } catch {
      const items = [
        { key: 'NECK',          label: '목',       score: 100 },
        { key: 'SHOULDER',      label: '어깨',     score: 100 },
        { key: 'PELVIS_WAIST',  label: '골반/허리', score: 100 },
        { key: 'LEG_ALIGNMENT', label: '하지정렬',  score: 100 },
        { key: 'KNEE',          label: '무릎',     score: 100 },
        { key: 'ANKLE',         label: '발목',     score: 100 },
      ];
      return { average: 100, level: BodyReportService.getScoreLevel(100), items };
    }
  }
}
