import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateMealDto {
  @ApiProperty({ required: false, description: '시간' })
  @IsString()
  @IsOptional()
  time?: string;

  @ApiProperty({ required: false, description: '음식명 (최대 30자)' })
  @IsString()
  @MaxLength(30)
  @IsOptional()
  menuName?: string;
}
