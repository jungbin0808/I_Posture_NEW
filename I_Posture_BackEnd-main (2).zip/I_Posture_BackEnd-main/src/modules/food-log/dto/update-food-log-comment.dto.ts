import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { Evaluation } from '../../../database/entities/food-log.entity';

export class UpdateFoodLogCommentDto {
  @ApiProperty({ description: '영양소 균형 피드백 (JSON)', required: false })
  @IsOptional()
  nutritionFeedback?: any;

  @ApiProperty({ description: '식사 패턴 피드백 (JSON)', required: false })
  @IsOptional()
  patternFeedback?: any;

  @ApiProperty({ description: '수분 및 음료 섭취 피드백 (JSON)', required: false })
  @IsOptional()
  hydrationFeedback?: any;

  @ApiProperty({ description: '종합 분석 및 코칭 피드백 (JSON)', required: false })
  @IsOptional()
  coachingFeedback?: any;

  @ApiProperty({ description: '체중 목표 달성도 종합 평가 (5단계)', enum: Evaluation, required: false })
  @IsEnum(Evaluation)
  @IsOptional()
  evaluation?: Evaluation;

  @ApiProperty({ description: '트레이너 한줄 코멘트', required: false })
  @IsString()
  @IsOptional()
  trainerComment?: string;
}
