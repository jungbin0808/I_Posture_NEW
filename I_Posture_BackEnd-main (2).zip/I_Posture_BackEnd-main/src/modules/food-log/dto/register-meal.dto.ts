import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { MealType } from '../enums/meal-type.enum';
import { FoodLogVisibility } from '../../../database/entities/food-log.entity';

export class RegisterMealDto {
  @ApiProperty({ description: '식단 날짜' })
  @IsDateString()
  @IsNotEmpty()
  logDate!: string;

  @ApiProperty({ enum: MealType, description: '끼니 (아침/점심/저녁/야식/간식)' })
  @IsEnum(MealType)
  type!: MealType;

  @ApiProperty({
    enum: FoodLogVisibility,
    required: false,
    description:
      '그 날짜 일지의 공개 범위 - PRIVATE: 나의 식단으로 등록(트레이너 비공개) / SHARED_WITH_TRAINER: 담당 트레이너 식단 연결(연동 해제 시 회원도 열람 불가). ' +
      '일자(로우) 단위 값이라 그 날짜에 이미 등록된 끼니가 있으면 무시되고 기존 값을 따름 - 그 날짜의 첫 끼니를 등록할 때만 필수',
  })
  @IsEnum(FoodLogVisibility)
  @IsOptional()
  visibility?: FoodLogVisibility;

  @ApiProperty({ description: '시간' })
  @IsString()
  @IsNotEmpty()
  time!: string;

  @ApiProperty({ description: '음식명 (최대 30자)' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(30)
  menuName!: string;
}
