import { ApiProperty } from '@nestjs/swagger';
import { FoodLogResponseDto } from './food-log-response.dto';

export class FoodLogDetailResponseDto extends FoodLogResponseDto {
  @ApiProperty({ description: '수정일시' })
  updatedAt!: Date;
}
