import { ApiProperty } from '@nestjs/swagger';
import { Evaluation, FoodLogVisibility } from '../../../database/entities/food-log.entity';

export class FoodLogResponseDto {
    @ApiProperty({ description: '일지 ID' })
    id!: string;

    @ApiProperty({ description: '식단 날짜' })
    logDate!: string;

    @ApiProperty({ enum: FoodLogVisibility, description: '공개 범위 - PRIVATE(나의 식단) / SHARED_WITH_TRAINER(담당 트레이너 식단 연결)' })
    visibility!: FoodLogVisibility;

    @ApiProperty({ description: '끼니 타입(BREAKFAST/LUNCH/DINNER/NIGHT_SNACK/SNACK)을 key로 하는 객체. 값: { time, menuName, fileId, imageUrl }' })
    meals?: any;

    @ApiProperty({ description: '회원 메모 (종합)' })
    userMemo?: string;

    @ApiProperty({ description: '오늘의 식단 만족도 별점 (1~5)', nullable: true })
    mealSatisfactionScore?: number;

    @ApiProperty({ description: '영양소 균형 피드백 (JSON)', nullable: true })
    nutritionFeedback?: any;

    @ApiProperty({ description: '식사 패턴 피드백 (JSON)', nullable: true })
    patternFeedback?: any;

    @ApiProperty({ description: '수분 및 음료 섭취 피드백 (JSON)', nullable: true })
    hydrationFeedback?: any;

    @ApiProperty({ description: '종합 분석 및 코칭 피드백 (JSON)', nullable: true })
    coachingFeedback?: any;

    @ApiProperty({ description: '체중 목표 달성도 종합 평가 (5단계)' })
    evaluation!: Evaluation;

    @ApiProperty({ description: '트레이너 한줄 코멘트' })
    trainerComment?: string;

    @ApiProperty({ description: '작성일시' })
    createdAt!: Date;
}
