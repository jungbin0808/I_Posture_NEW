import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsDateString, IsEnum, IsOptional } from 'class-validator';
import { Transform } from 'class-transformer';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export enum FoodLogSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindFoodLogDto extends PaginationDto {
  @ApiProperty({ description: '조회 시작 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '조회 종료 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({ description: '트레이너 코멘트가 있는 일지만 조회', required: false })
  @IsBoolean()
  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  onlyCommented?: boolean;

  @ApiProperty({ description: '정렬 순서', enum: FoodLogSortOrder, required: false, default: FoodLogSortOrder.DATE_DESC })
  @IsEnum(FoodLogSortOrder)
  @IsOptional()
  sort?: FoodLogSortOrder = FoodLogSortOrder.DATE_DESC;
}
