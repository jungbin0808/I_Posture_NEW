import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, Max, MaxLength, Min } from 'class-validator';

export class UpsertSatisfactionDto {
  @ApiProperty({ description: '식단 날짜' })
  @IsDateString()
  @IsNotEmpty()
  logDate!: string;

  @ApiProperty({ description: '오늘의 식단 만족도 별점 (1~5)', required: false })
  @IsInt()
  @Min(1)
  @Max(5)
  @IsOptional()
  mealSatisfactionScore?: number;

  @ApiProperty({ description: '회원 메모 (종합, 최대 1000자)', required: false })
  @IsString()
  @MaxLength(1000)
  @IsOptional()
  userMemo?: string;
}
