import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FoodLogEntity } from '../../database/entities/food-log.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import {
  FoodLogController,
  PublicFoodLogController,
  CenterFoodLogPublicController,
} from './food-log.controller';
import { FoodLogService } from './food-log.service';
import { S3Module } from '../../s3/s3.module';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { CapacityModule } from '../capacity/capacity.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      FoodLogEntity,
      MemberIdentityLinkEntity,
      UserEntity,
      FileEntity,
      TrainerUserEntity,
    ]),
    S3Module,
    CapacityModule,
  ],
  controllers: [FoodLogController, PublicFoodLogController, CenterFoodLogPublicController],
  providers: [FoodLogService],
  exports: [FoodLogService],
})
export class FoodLogModule {}
