import { Controller, Get, Post, Body, Put, Param, Delete, UseGuards, UseInterceptors, UploadedFile, Req, Query, ForbiddenException, ParseEnumPipe } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { FoodLogService } from './food-log.service';
import { RegisterMealDto } from './dto/register-meal.dto';
import { UpdateMealDto } from './dto/update-meal.dto';
import { UpsertSatisfactionDto } from './dto/upsert-satisfaction.dto';
import { MealType } from './enums/meal-type.enum';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { ISuccessResponse, IPageData } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { FoodLogResponseDto } from './dto/food-log-response.dto';
import { FindFoodLogDto } from './dto/find-food-log.dto';
import { FoodLogDetailResponseDto } from './dto/food-log-detail-response.dto';
import { UpdateFoodLogCommentDto } from './dto/update-food-log-comment.dto';

@ApiTags('FoodLog')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('food-logs')
export class FoodLogController {
  constructor(private readonly foodLogService: FoodLogService) {}

  @ApiOperation({ summary: '식단일지 목록 조회 (회원/트레이너 공용)' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() dto: FindFoodLogDto,
  ): Promise<IPageData<FoodLogResponseDto>> {
    const isTrainer = req.user.userType === UserType.C_TRAINER || req.user.userType === UserType.F_TRAINER;
    if (req.user.id !== memberId && !isTrainer) {
      throw new ForbiddenException('자신의 식단일지만 조회할 수 있습니다.');
    }

    if (isTrainer) {
      return this.foodLogService.findAllByTrainer(req.user.id, memberId, dto);
    } else {
      return this.foodLogService.findAllByMember(req.user.id, dto);
    }
  }

  @ApiOperation({ summary: '식단일지 상세 조회' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId/:id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FoodLogDetailResponseDto>> {
    const result = await this.foodLogService.findOne(req.user, memberId, id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '끼니 등록 (회원용) - 같은 날짜/같은 끼니가 이미 있으면 409, 사진 필수' })
  @Roles(Role.Member)
  @Post('member/:memberId/meals')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      required: ['logDate', 'type', 'time', 'menuName', 'file'],
      properties: {
        logDate: { type: 'string' },
        type: { type: 'string', enum: ['BREAKFAST', 'LUNCH', 'DINNER', 'NIGHT_SNACK', 'SNACK'] },
        visibility: { type: 'string', enum: ['PRIVATE', 'SHARED_WITH_TRAINER'] },
        time: { type: 'string' },
        menuName: { type: 'string' },
        file: { type: 'string', format: 'binary', description: '끼니 사진 (필수)' },
      },
    },
  })
  async registerMeal(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() registerMealDto: RegisterMealDto,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<ISuccessResponse<any>> {
    if (req.user.id !== memberId) {
      throw new ForbiddenException('자신의 식단일지만 등록할 수 있습니다.');
    }
    const result = await this.foodLogService.registerMeal(req.user.id, registerMealDto, file);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '끼니 수정 (회원용) - 사진은 교체할 때만 함께 전송(생략 시 기존 사진 유지)' })
  @Roles(Role.Member)
  @Put('member/:memberId/:id/meals/:type')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        time: { type: 'string' },
        menuName: { type: 'string' },
        file: { type: 'string', format: 'binary', description: '교체할 사진 (선택)' },
      },
    },
  })
  async updateMeal(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Param('type', new ParseEnumPipe(MealType)) type: MealType,
    @Body() updateMealDto: UpdateMealDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<any>> {
    if (req.user.id !== memberId) {
      throw new ForbiddenException('자신의 식단일지만 수정할 수 있습니다.');
    }
    const result = await this.foodLogService.updateMeal(req.user.id, id, type, updateMealDto, file);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '끼니 삭제 (회원용)' })
  @Roles(Role.Member)
  @Delete('member/:memberId/:id/meals/:type')
  async deleteMeal(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Param('type', new ParseEnumPipe(MealType)) type: MealType,
  ): Promise<ISuccessResponse<any>> {
    if (req.user.id !== memberId) {
      throw new ForbiddenException('자신의 식단일지만 수정할 수 있습니다.');
    }
    const result = await this.foodLogService.deleteMeal(req.user.id, id, type);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '오늘의 식단 만족도(별점+메모) 저장 (회원용) - 해당 날짜 일지가 없으면 새로 생성' })
  @Roles(Role.Member)
  @Put('member/:memberId/satisfaction')
  async upsertSatisfaction(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() upsertSatisfactionDto: UpsertSatisfactionDto,
  ): Promise<ISuccessResponse<any>> {
    if (req.user.id !== memberId) {
      throw new ForbiddenException('자신의 식단일지만 저장할 수 있습니다.');
    }
    const result = await this.foodLogService.upsertSatisfaction(req.user.id, upsertSatisfactionDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '식단일지 피드백 수정 (트레이너용)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Put('member/:memberId/:id/feedback')
  async updateFeedback(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() updateFoodLogCommentDto: UpdateFoodLogCommentDto,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.foodLogService.updateFeedback(req.user.id, memberId, id, updateFoodLogCommentDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '식단일지 피드백 삭제 (트레이너용)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Delete('member/:memberId/:id/feedback')
  async deleteFeedback(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    const result = await this.foodLogService.deleteFeedback(req.user.id, memberId, id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '식단일지 삭제 (회원용)' })
  @Roles(Role.Member)
  @Delete('member/:memberId/:id')
  async remove(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<any>> {
    if (req.user.id !== memberId) {
      throw new ForbiddenException('자신의 식단일지만 삭제할 수 있습니다.');
    }
    await this.foodLogService.delete(req.user.id, id);
    return SuccessResponse({ success: true });
  }
}

/**
 * 식단일지 퍼블릭 API (인증 불필요)
 */
@ApiTags('FoodLog')
@Controller('food-logs')
export class PublicFoodLogController {
  constructor(private readonly foodLogService: FoodLogService) {}

  /**
   * @summary 식단일지 상세 조회 (공유 링크 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Food Log Detail (Public Share)' })
  @Get(':id/public')
  async findOnePublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FoodLogDetailResponseDto>> {
    const result = await this.foodLogService.findOnePublic(id);
    return SuccessResponse(result);
  }
}

/**
 * 센터용 식단일지 퍼블릭 API (인증 불필요, 공유 링크)
 */
@ApiTags('Center Food Log Public')
@Controller('center/food-logs/public')
export class CenterFoodLogPublicController {
  constructor(private readonly foodLogService: FoodLogService) {}

  @ApiOperation({ summary: 'Get Food Log Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/:id')
  async findOnePublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FoodLogDetailResponseDto>> {
    const result = await this.foodLogService.findOnePublic(id, memberId);
    return SuccessResponse(result);
  }
}
