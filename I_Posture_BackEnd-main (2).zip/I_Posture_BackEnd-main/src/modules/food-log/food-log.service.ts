import { Injectable, NotFoundException, ForbiddenException, ConflictException, BadRequestException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { FoodLogEntity, Evaluation, FoodLogVisibility } from '../../database/entities/food-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { FileEntity, FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { S3Service } from '../../s3/s3.service';
import { MealType } from './enums/meal-type.enum';
import { RegisterMealDto } from './dto/register-meal.dto';
import { UpdateMealDto } from './dto/update-meal.dto';
import { UpsertSatisfactionDto } from './dto/upsert-satisfaction.dto';
import { FindFoodLogDto } from './dto/find-food-log.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { FoodLogResponseDto } from './dto/food-log-response.dto';
import { FoodLogDetailResponseDto } from './dto/food-log-detail-response.dto';
import { UpdateFoodLogCommentDto } from './dto/update-food-log-comment.dto';
import { MemberNotificationService } from '../notification/member-notification.service';

@Injectable()
export class FoodLogService {
  private readonly logger = new Logger(FoodLogService.name);

  constructor(
    @InjectRepository(FoodLogEntity)
    private readonly foodLogRepo: Repository<FoodLogEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    private readonly memberNotificationService: MemberNotificationService,
    private readonly s3Service: S3Service,
  ) {}

  /**
   * 앱 회원(A) ID → 트레이너가 관리하는 관리회원(C) ID. trainer_users는 전부 관리회원(C) 기준으로 저장되므로
   * 앱 회원 본인 기준 트레이너 연동 여부를 확인하려면 반드시 이 매핑을 먼저 거쳐야 함.
   */
  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.managedMemberId ?? null;
  }

  /**
   * 관리회원(C) ID → 앱 회원(A) ID (역방향). food_logs.userId는 앱회원 ID 기준이라,
   * 트레이너가 관리회원 ID로 회원을 조회할 때(:memberId 경로 파라미터) 이 변환을 거쳐야 함.
   * 반드시 "지금 LINKED인" 연동만 봐야 한다 — 같은 managedMemberId가 과거에 다른 앱회원과
   * 연동됐던 이력까지 보면 전혀 다른 사람의 로그가 섞여 나올 수 있다(2026-10-08, 실데이터로 확인된
   * 버그: 연동 끊긴 managedMemberId로 조회 시 그 managedMemberId와 "한때 연동됐던 다른 앱회원"의
   * 로그가 잘못 노출됨). 연동 해제 시 트레이너는 피드백도 일지도 전부 못 봐야 한다는 정책과도 일치.
   */
  private async resolveAppMemberId(managedMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { managedMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.appMemberId ?? null;
  }

  /**
   * URL 경로의 :memberId가 이 로그의 실제 소유자(appMemberId)와 일치하는지 확인.
   * 회원 본인이 호출하면 memberId=앱회원 ID 그대로 오고, 트레이너가 호출하면 memberId=관리회원 ID로
   * 온다(다른 트레이너용 API들과 동일한 컨벤션) - 두 경우 다 커버해야 한다.
   * 지금 LINKED 상태인 연동만 인정한다 — 연동 해제되면 트레이너는 식단일지/피드백 전부 접근 불가 (2026-10-08).
   */
  private async matchesMemberId(appMemberId: string, memberId: string): Promise<boolean> {
    if (appMemberId === memberId) return true;
    const managedMemberId = await this.resolveManagedMemberId(appMemberId);
    return managedMemberId === memberId;
  }

  /**
   * 회원(앱 계정 기준)의 현재 활성 트레이너 ID (없으면 null). 회원당 활성 트레이너는 최대 1명이라는 기존 전제를 그대로 따름.
   */
  private async getActiveTrainerId(appMemberId: string): Promise<string | null> {
    const managedMemberId = await this.resolveManagedMemberId(appMemberId);
    if (!managedMemberId) return null;

    const relation = await this.trainerUserRepo.findOne({ where: { memberId: managedMemberId, status: TrainerUserStatus.ACTIVE } });
    return relation?.trainerId ?? null;
  }

  /**
   * 식단일지 본문(끼니/메모 등)은 회원 소유라 연동 여부와 무관하게 항상 보인다. 다만 트레이너가
   * 작성한 피드백(nutritionFeedback/patternFeedback/hydrationFeedback/coachingFeedback/evaluation/
   * trainerComment)은 그 트레이너와 지금도 연동 중일 때만 노출하고, 연동 해제되면 숨긴다 (2026-10-08).
   */
  private maskTrainerFeedbackIfUnlinked<T extends Pick<FoodLogEntity, 'visibility' | 'trainerId'>>(
    log: T,
    activeTrainerId: string | null,
  ): T {
    const isLinkedShare = log.visibility === FoodLogVisibility.SHARED_WITH_TRAINER && log.trainerId === activeTrainerId;
    if (isLinkedShare) return log;

    return {
      ...log,
      nutritionFeedback: undefined,
      patternFeedback: undefined,
      hydrationFeedback: undefined,
      coachingFeedback: undefined,
      evaluation: undefined,
      trainerComment: undefined,
    };
  }

  /**
   * 트레이너 기준 - 이 트레이너가 그 앱 회원을 지금도 실제로 관리 중인지 (관리회원 매핑을 거쳐 확인).
   * 연동 해제되면 트레이너도 이 회원에게 남긴 피드백/일지를 전혀 볼 수 없다 (2026-10-08 정책).
   */
  private async isTrainerLinkedToMember(trainerId: string, appMemberId: string): Promise<boolean> {
    const managedMemberId = await this.resolveManagedMemberId(appMemberId);
    if (!managedMemberId) return false;

    const relation = await this.trainerUserRepo.findOne({ where: { trainerId, memberId: managedMemberId, status: TrainerUserStatus.ACTIVE } });
    return !!relation;
  }

  /**
   * 트레이너 관점 - 자신과 공유된(SHARED_WITH_TRAINER + trainerId 일치) 로우만 보임
   */
  private isLogVisibleToTrainer(log: FoodLogEntity, trainerId: string): boolean {
    return log.visibility === FoodLogVisibility.SHARED_WITH_TRAINER && log.trainerId === trainerId;
  }

  /**
   * 공유 링크(퍼블릭, 인증 불필요) 관점 - PRIVATE는 항상 제외, 연동 해제된 공유도 제외
   */
  private isLogVisibleToPublic(log: FoodLogEntity, activeTrainerId: string | null): boolean {
    return log.visibility === FoodLogVisibility.SHARED_WITH_TRAINER && log.trainerId === activeTrainerId;
  }

  /**
   * @param activeTrainerId 회원 본인 관점 조회일 때만 전달 — 전달되면 연동 끊긴 공유 로그의 피드백을 마스킹한다.
   * 트레이너 본인이 자신이 쓴 피드백을 조회/수정하는 경로는 생략(undefined)해서 그대로 보여준다.
   */
  private async toDetailResponse(log: FoodLogEntity, activeTrainerId?: string | null): Promise<FoodLogDetailResponseDto> {
    const masked = activeTrainerId === undefined ? log : this.maskTrainerFeedbackIfUnlinked(log, activeTrainerId);
    const [populatedLog] = await this.populateMealsWithFileUrls([masked]);
    return {
      id: populatedLog.id,
      logDate: populatedLog.logDate,
      visibility: populatedLog.visibility,
      meals: populatedLog.meals,
      userMemo: populatedLog.userMemo,
      mealSatisfactionScore: populatedLog.mealSatisfactionScore,
      nutritionFeedback: populatedLog.nutritionFeedback,
      patternFeedback: populatedLog.patternFeedback,
      hydrationFeedback: populatedLog.hydrationFeedback,
      coachingFeedback: populatedLog.coachingFeedback,
      evaluation: populatedLog.evaluation,
      trainerComment: populatedLog.trainerComment,
      createdAt: populatedLog.createdAt,
      updatedAt: populatedLog.updatedAt,
    };
  }

  private async populateMealsWithFileUrls(logs: FoodLogEntity[]): Promise<any[]> {
    const fileIds = logs.flatMap(log => {
      if (!log.meals || typeof log.meals !== 'object') return [];
      return Object.values(log.meals).map((meal: any) => meal.fileId).filter(Boolean);
    });

    if (fileIds.length === 0) {
      return logs.map(log => {
        const newMeals: any = {};
        if (log.meals && typeof log.meals === 'object') {
          for (const key in log.meals) {
            newMeals[key] = { ...log.meals[key], imageUrl: null };
          }
        }
        return { ...log, meals: newMeals };
      });
    }

    const files = await this.fileRepo.find({ where: { id: In(fileIds) } });
    const fileUrlMap = new Map(files.map(file => [file.id, file.fileUrl]));

    return logs.map(log => {
      const newMeals: any = {};
      if (log.meals && typeof log.meals === 'object') {
        for (const key in log.meals) {
          const meal = log.meals[key];
          newMeals[key] = {
            ...meal,
            imageUrl: fileUrlMap.get(meal.fileId) || null,
          };
        }
      }
      return { ...log, meals: newMeals };
    });
  }

  /**
   * 끼니 등록 (회원용) - 같은 날짜에 같은 끼니가 이미 있으면 거부, 그 날짜의 일지가 없으면 새로 생성.
   * visibility는 그 날짜 일지를 새로 만들 때만 사용(일자 단위 값) - 이미 있는 날짜면 기존 값을 따르고 dto.visibility는 무시.
   * 식단 사진의 저장 소유권은 항상 회원 본인이고(PRIVATE/SHARED_WITH_TRAINER 무관), 회원 용량은
   * 별도 제한이 없어 용량 체크를 하지 않는다(2026-10-08).
   * 사진은 요청과 함께(multipart) 직접 받는다 - 다른 모든 API(analysis/inbody/QnA 등)와 동일한 패턴,
   * 사전 업로드 후 fileId만 참조하는 방식은 이 프로젝트에서 쓰지 않음(2026-09-18 재설계).
   */
  @Transactional()
  async registerMeal(userId: string, dto: RegisterMealDto, file: Express.Multer.File): Promise<FoodLogDetailResponseDto> {
    if (!file) {
      throw new BadRequestException('사진(file)을 첨부해주세요.');
    }

    let log = await this.foodLogRepo.findOne({ where: { userId, logDate: dto.logDate } });

    if (log && log.meals?.[dto.type]) {
      throw new ConflictException('이미 등록한 식단이에요. 변경하려면 기존 식단을 수정해주세요.');
    }

    const activeTrainerId = await this.getActiveTrainerId(userId);
    let trainerId: string | undefined = log?.trainerId;

    if (!log) {
      if (!dto.visibility) {
        throw new BadRequestException('식단 등록 시 공개 범위(visibility)를 선택해야 합니다.');
      }
      if (dto.visibility === FoodLogVisibility.SHARED_WITH_TRAINER) {
        if (!activeTrainerId) {
          throw new BadRequestException('연동된 트레이너가 없어 트레이너 피드백 받기를 선택할 수 없습니다.');
        }
        trainerId = activeTrainerId;
      }
    }

    const uploadedFile = await this.s3Service.uploadFile(file, {
      memberId: userId,
      uploaderId: userId,
      ownerType: FileOwnerType.MEMBER,
      ownerId: userId,
      relatedType: FileRelatedType.DIET_LOG,
      division: dto.type,
    });
    const meal = { time: dto.time, menuName: dto.menuName, fileId: uploadedFile.id };

    if (!log) {
      log = this.foodLogRepo.create({
        userId,
        logDate: dto.logDate,
        visibility: dto.visibility,
        trainerId,
        meals: { [dto.type]: meal },
      });
    } else {
      log.meals = { ...log.meals, [dto.type]: meal };
    }

    const saved = await this.foodLogRepo.save(log);
    return this.toDetailResponse(saved, activeTrainerId);
  }

  /**
   * 끼니 수정 (회원용) - 사진은 교체할 때만 multipart로 함께 보내면 됨(생략하면 기존 사진 유지 - 사진 삭제는 지원 안 함).
   */
  @Transactional()
  async updateMeal(userId: string, id: string, type: MealType, dto: UpdateMealDto, file?: Express.Multer.File): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({ where: { id, userId } });
    if (!log || !log.meals?.[type]) throw new NotFoundException('등록된 끼니를 찾을 수 없습니다.');

    const activeTrainerId = await this.getActiveTrainerId(userId);

    let fileId = log.meals[type].fileId;

    if (file) {
      const uploadedFile = await this.s3Service.uploadFile(file, {
        memberId: userId,
        uploaderId: userId,
        ownerType: FileOwnerType.MEMBER,
        ownerId: userId,
        relatedType: FileRelatedType.DIET_LOG,
        division: type,
      });
      fileId = uploadedFile.id;
    }

    log.meals = { ...log.meals, [type]: { ...log.meals[type], ...dto, fileId } };
    const saved = await this.foodLogRepo.save(log);
    return this.toDetailResponse(saved, activeTrainerId);
  }

  /**
   * 끼니 삭제 (회원용)
   */
  @Transactional()
  async deleteMeal(userId: string, id: string, type: MealType): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({ where: { id, userId } });
    if (!log || !log.meals?.[type]) throw new NotFoundException('등록된 끼니를 찾을 수 없습니다.');

    const meals = { ...log.meals };
    delete meals[type];
    log.meals = meals;
    const saved = await this.foodLogRepo.save(log);
    return this.toDetailResponse(saved, await this.getActiveTrainerId(userId));
  }

  /**
   * 오늘의 식단 만족도(별점+메모) 저장 (회원용) - 그 날짜의 일지가 없으면 PRIVATE로 새로 생성
   */
  async upsertSatisfaction(userId: string, dto: UpsertSatisfactionDto): Promise<FoodLogDetailResponseDto> {
    let log = await this.foodLogRepo.findOne({ where: { userId, logDate: dto.logDate } });

    if (!log) {
      log = this.foodLogRepo.create({ userId, logDate: dto.logDate, visibility: FoodLogVisibility.PRIVATE });
    }

    log.mealSatisfactionScore = dto.mealSatisfactionScore;
    log.userMemo = dto.userMemo;
    const saved = await this.foodLogRepo.save(log);
    return this.toDetailResponse(saved, await this.getActiveTrainerId(userId));
  }

  /**
   * 식단일지 목록 조회 (회원용) - 본인이 작성한 전체 일지를 조회(연동 여부 무관). 연동 끊긴
   * SHARED_WITH_TRAINER 로우는 일지 자체는 그대로 보이고 트레이너 피드백만 마스킹된다.
   */
  async findAllByMember(userId: string, dto: FindFoodLogDto): Promise<IPageData<FoodLogResponseDto>> {
    const activeTrainerId = await this.getActiveTrainerId(userId);
    const { page = 1, limit = 10, startDate, endDate, sort } = dto;
    const query = this.foodLogRepo.createQueryBuilder('log')
      .where('log.userId = :userId', { userId });

    if (startDate) query.andWhere('log.logDate >= :startDate', { startDate });
    if (endDate) query.andWhere('log.logDate <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('log.logDate', sortDirection);

    const total = await query.getCount();
    const logs = await query.offset((page - 1) * limit).limit(limit).getMany();

    const populatedLogs = await this.populateMealsWithFileUrls(
      logs.map(log => this.maskTrainerFeedbackIfUnlinked(log, activeTrainerId)),
    );

    const items: FoodLogResponseDto[] = populatedLogs.map(log => ({
      id: log.id,
      logDate: log.logDate,
      visibility: log.visibility,
      meals: log.meals,
      userMemo: log.userMemo,
      mealSatisfactionScore: log.mealSatisfactionScore,
      nutritionFeedback: log.nutritionFeedback,
      patternFeedback: log.patternFeedback,
      hydrationFeedback: log.hydrationFeedback,
      coachingFeedback: log.coachingFeedback,
      evaluation: log.evaluation,
      trainerComment: log.trainerComment,
      createdAt: log.createdAt,
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 식단일지 목록 조회 (트레이너용) - 자신과 공유된(SHARED_WITH_TRAINER) 로우만 조회.
   * 컨트롤러의 :memberId는 트레이너가 넘기는 관리회원(C) ID - food_logs.userId(앱회원 A ID 기준)와
   * 바로 비교하면 안 되고, member_identity_links로 앱회원 ID로 변환한 뒤 조회해야 한다.
   */
  async findAllByTrainer(trainerId: string, managedMemberId: string, dto: FindFoodLogDto): Promise<IPageData<FoodLogResponseDto>> {
    const relation = await this.trainerUserRepo.findOne({ where: { trainerId, memberId: managedMemberId, status: TrainerUserStatus.ACTIVE } });
    if (!relation) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const appMemberId = await this.resolveAppMemberId(managedMemberId);
    if (!appMemberId) {
      const { page = 1, limit = 10 } = dto;
      return { items: [], paging: buildPaging(0, limit, page) };
    }

    const { page = 1, limit = 10, startDate, endDate } = dto;
    const query = this.foodLogRepo.createQueryBuilder('log')
      .where('log.userId = :userId', { userId: appMemberId })
      .andWhere('log.visibility = :shared', { shared: FoodLogVisibility.SHARED_WITH_TRAINER })
      .andWhere('log.trainerId = :trainerId', { trainerId });

    if (startDate) query.andWhere('log.logDate >= :startDate', { startDate });
    if (endDate) query.andWhere('log.logDate <= :endDate', { endDate });

    query.orderBy('log.logDate', 'DESC');

    const total = await query.getCount();
    const logs = await query.offset((page - 1) * limit).limit(limit).getMany();

    const populatedLogs = await this.populateMealsWithFileUrls(logs);

    const items: FoodLogResponseDto[] = populatedLogs.map(log => ({
      id: log.id,
      logDate: log.logDate,
      visibility: log.visibility,
      meals: log.meals,
      userMemo: log.userMemo,
      mealSatisfactionScore: log.mealSatisfactionScore,
      nutritionFeedback: log.nutritionFeedback,
      patternFeedback: log.patternFeedback,
      hydrationFeedback: log.hydrationFeedback,
      coachingFeedback: log.coachingFeedback,
      evaluation: log.evaluation,
      trainerComment: log.trainerComment,
      createdAt: log.createdAt,
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 식단일지 상세 조회 (퍼블릭 - 인증 불필요) - PRIVATE, 연동 해제된 공유는 404
   */
  async findOnePublic(id: string, memberId?: string): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({
      where: memberId ? { id, userId: memberId } : { id },
    });
    if (!log) throw new NotFoundException('식단일지를 찾을 수 없습니다.');

    const activeTrainerId = await this.getActiveTrainerId(log.userId);
    if (!this.isLogVisibleToPublic(log, activeTrainerId)) {
      throw new NotFoundException('식단일지를 찾을 수 없습니다.');
    }

    return this.toDetailResponse(log);
  }

  /**
   * 식단일지 상세 조회
   */
  async findOne(user: UserEntity, memberId: string, id: string): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({ where: { id } });
    if (!log || !(await this.matchesMemberId(log.userId, memberId))) {
      throw new NotFoundException('식단일지를 찾을 수 없습니다.');
    }

    // 본인 또는 담당 트레이너만 조회 가능
    if (log.userId === user.id) {
      const activeTrainerId = await this.getActiveTrainerId(user.id);
      return this.toDetailResponse(log, activeTrainerId);
    }

    const isLinked = await this.isTrainerLinkedToMember(user.id, log.userId);
    if (!isLinked || !this.isLogVisibleToTrainer(log, user.id)) {
      throw new ForbiddenException('해당 식단일지를 조회할 권한이 없습니다.');
    }

    return this.toDetailResponse(log);
  }

  /**
   * 식단일지 피드백 수정 (트레이너용) - 자신과 공유된 로우에만 가능
   */
  async updateFeedback(trainerId: string, memberId: string, id: string, dto: UpdateFoodLogCommentDto): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({ where: { id } });
    if (!log || !(await this.matchesMemberId(log.userId, memberId))) {
      throw new NotFoundException('식단일지를 찾을 수 없습니다.');
    }

    const isLinked = await this.isTrainerLinkedToMember(trainerId, log.userId);
    if (!isLinked || !this.isLogVisibleToTrainer(log, trainerId)) {
      throw new ForbiddenException('해당 회원의 식단일지를 수정할 권한이 없습니다.');
    }

    Object.assign(log, dto);
    const saved = await this.foodLogRepo.save(log);
    this.memberNotificationService.notifyDietFeedback(log.userId, log.id);
    return this.toDetailResponse(saved);
  }

  /**
   * 식단일지 피드백 삭제 (트레이너용) - 자신과 공유된 로우에만 가능
   */
  async deleteFeedback(trainerId: string, memberId: string, id: string): Promise<FoodLogDetailResponseDto> {
    const log = await this.foodLogRepo.findOne({ where: { id } });
    if (!log || !(await this.matchesMemberId(log.userId, memberId))) {
      throw new NotFoundException('식단일지를 찾을 수 없습니다.');
    }

    const isLinked = await this.isTrainerLinkedToMember(trainerId, log.userId);
    if (!isLinked || !this.isLogVisibleToTrainer(log, trainerId)) {
      throw new ForbiddenException('해당 회원의 식단일지를 수정할 권한이 없습니다.');
    }

    log.nutritionFeedback = undefined;
    log.patternFeedback = undefined;
    log.hydrationFeedback = undefined;
    log.coachingFeedback = undefined;
    log.evaluation = Evaluation.NORMAL;
    log.trainerComment = undefined;

    const saved = await this.foodLogRepo.save(log);
    return this.toDetailResponse(saved);
  }

  /**
   * 식단일지 삭제 (회원용)
   */
  @Transactional()
  async delete(userId: string, id: string): Promise<void> {
    const log = await this.foodLogRepo.findOne({ where: { id, userId } });
    if (!log) {
      throw new NotFoundException('식단일지를 찾을 수 없습니다.');
    }

    await this.foodLogRepo.softDelete({ id, userId });
  }

  /**
   * 탈퇴 등: 회원의 식단일지 전체 소프트딜리트
   */
  async deleteAllDataForUser(userId: string): Promise<void> {
    await this.foodLogRepo.softDelete({ userId });
  }
}
