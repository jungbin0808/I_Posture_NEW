import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty } from 'class-validator';

export class LinkMemberDto {
  @ApiProperty({ description: '연동할 앱 회원 이메일', example: 'new_user1@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;
}


