import { ApiProperty } from '@nestjs/swagger';
import { IsString, MaxLength, MinLength } from 'class-validator';

export class RegisterFcmTokenDto {
  @ApiProperty({ description: 'Firebase FCM 디바이스 토큰', example: 'dGhpcyBpcyBhIHNhbXBsZSB0b2tlbg==' })
  @IsString()
  @MinLength(10)
  @MaxLength(512)
  fcmToken!: string;
}
