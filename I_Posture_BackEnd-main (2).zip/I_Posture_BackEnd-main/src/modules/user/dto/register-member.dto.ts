import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString, Length } from 'class-validator';
import { Gender } from '../../../database/entities/user.entity';

export class RegisterMemberDto {
  @ApiProperty({ description: '이메일', example: 'managed01@example.com' })
  @IsEmail()
  @IsNotEmpty()
  email!: string;

  @ApiProperty({ description: '이름', example: '박관리' })
  @IsString()
  @IsNotEmpty()
  @Length(1, 50)
  name!: string;

  @ApiProperty({ description: '전화번호', example: '010-9876-5432' })
  @IsString()
  @IsNotEmpty()
  @Length(1, 65)
  phone!: string;

  @ApiProperty({ description: '키(cm)', required: false, example: 185.0 })
  @IsOptional()
  @IsNumber()
  height?: number;

  @ApiProperty({ description: '몸무게(kg)', required: false, example: 70.0 })
  @IsOptional()
  @IsNumber()
  weight?: number;

  @ApiProperty({ description: '생년월일 (YYYY-MM-DD)', required: false, example: '1990-01-01' })
  @IsOptional()
  @IsString()
  birthDate?: string;

  @ApiProperty({ description: '성별', required: false, enum: Gender })
  @IsOptional()
  @IsEnum(Gender)
  gender?: Gender;
}

