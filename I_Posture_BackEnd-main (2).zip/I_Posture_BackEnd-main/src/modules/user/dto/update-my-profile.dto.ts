import { ApiProperty } from '@nestjs/swagger';
import { Transform, Type } from 'class-transformer';
import { IsBoolean, IsEnum, IsNumber, IsOptional, IsString, MinLength, ValidateNested } from 'class-validator';
import { Gender } from '../../../database/entities/user.entity';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

export class NotificationSettingsDto {
  @ApiProperty({ description: '이벤트/프로모션 마케팅 푸시알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  eventMarketing?: boolean;

  @ApiProperty({ description: '내가 올린 질문 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  myQuestion?: boolean;

  @ApiProperty({ description: '챌린지 신청 결과 알림', required: false, example: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  challengeResult?: boolean;

  @ApiProperty({ description: '이용권 사용량 완료 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  subscriptionUsage?: boolean;

  @ApiProperty({ description: '내가 올린 답변 채택 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  myAnswerAccepted?: boolean;

  @ApiProperty({ description: '적립금 정산알림', required: false, example: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  pointSettlement?: boolean;

  @ApiProperty({ description: '(USER APP) 전체 알림 받기 마스터 토글', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  all?: boolean;

  @ApiProperty({ description: '(USER APP) 체형·인바디 측정 주기 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  bodyMeasurementCycle?: boolean;

  @ApiProperty({ description: '(USER APP) 운동 루틴 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  workoutRoutine?: boolean;

  @ApiProperty({ description: '(USER APP) 챌린지 참여 및 마감 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  challengeParticipation?: boolean;

  @ApiProperty({ description: '(USER APP) 식단 피드백 및 작성 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  dietFeedback?: boolean;

  @ApiProperty({ description: '(USER APP) 트레이너 분석 리포트 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  trainerReport?: boolean;

  @ApiProperty({ description: '(USER APP) 공지사항 알림', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  notice?: boolean;
}

export class UpdateMyProfileDto {
  @ApiProperty({ description: '이름', required: false, example: '홍길동' })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiProperty({ description: '휴대폰 번호', required: false, example: '010-1234-5678' })
  @IsString()
  @IsOptional()
  phone?: string;

  @ApiProperty({ description: '생년월일 (YYYY-MM-DD)', required: false, example: '2002-03-19' })
  @IsString()
  @IsOptional()
  birthDate?: string;

  @ApiProperty({ description: '성별', enum: Gender, required: false })
  @IsEnum(Gender)
  @IsOptional()
  gender?: Gender;

  @ApiProperty({ description: '키 (cm)', required: false, example: 164 })
  @IsNumber()
  @IsOptional()
  height?: number;

  @ApiProperty({ description: '몸무게 (kg)', required: false, example: 52 })
  @IsNumber()
  @IsOptional()
  weight?: number;

  @ApiProperty({ description: '새 비밀번호 (변경 시에만, 최소 8자)', required: false, example: 'newPass123!' })
  @IsString()
  @MinLength(8)
  @IsOptional()
  newPassword?: string;

  @ApiProperty({ description: '소속명 (프리랜서 트레이너 전용)', required: false, example: '홍길동 퍼스널트레이닝' })
  @IsString()
  @IsOptional()
  affiliationName?: string;

  @ApiProperty({
    description: '알림 설정 (변경할 항목만 포함)',
    required: false,
    type: NotificationSettingsDto,
    example: { eventMarketing: true, myQuestion: true, challengeResult: false, subscriptionUsage: true, myAnswerAccepted: true, pointSettlement: false },
  })
  @ValidateNested()
  @Type(() => NotificationSettingsDto)
  @IsOptional()
  notifications?: NotificationSettingsDto;
}
