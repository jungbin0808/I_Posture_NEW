import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { MemberFilterType, MemberSortOrder } from '../enums/member-filter.enum';

export class FindMyMembersDto extends PaginationDto {
  @ApiProperty({ description: '검색어 (이름, 전화번호)', required: false })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiProperty({ description: '필터 타입', enum: MemberFilterType, required: false, default: MemberFilterType.ALL })
  @IsEnum(MemberFilterType)
  @IsOptional()
  filterType?: MemberFilterType = MemberFilterType.ALL;

  @ApiProperty({ description: '이용권 보유 회원만 보기', required: false, default: false })
  @IsOptional()
  @Transform(({ value }) => value === 'true' || value === true)
  @IsBoolean()
  isActiveSubscription?: boolean = false;

  @ApiProperty({
    description: '정렬 기준 (가입일 = 트레이너 보유 등록일)',
    enum: MemberSortOrder,
    required: false,
    default: MemberSortOrder.JOIN_DATE_DESC,
  })
  @IsEnum(MemberSortOrder)
  @IsOptional()
  sort?: MemberSortOrder = MemberSortOrder.JOIN_DATE_DESC;
}
