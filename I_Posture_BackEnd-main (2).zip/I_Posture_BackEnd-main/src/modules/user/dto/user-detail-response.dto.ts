import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from './user-response.dto';
import { UserEntity } from '../../../database/entities/user.entity';

export class UserDetailResponseDto extends UserResponseDto {
  @ApiProperty({ description: '생년월일', nullable: true })
  birthDate?: string;

  @ApiProperty({ description: '성별', nullable: true })
  gender?: string;

  @ApiProperty({ description: '키', nullable: true })
  height?: number;

  @ApiProperty({ description: '몸무게', nullable: true })
  weight?: number;

  @ApiProperty({ description: '주소', nullable: true })
  address?: string;

  @ApiProperty({ description: '메모 (트레이너용)', nullable: true })
  memo?: string;

  @ApiProperty({ description: '최초 결제일', nullable: true })
  firstPaymentDate?: Date | null;

  // subscriptionEndDate는 UserResponseDto에 이미 정의되어 있을 수 있으나, Detail에서 확실히 포함
  @ApiProperty({ description: '이용권 만료일', nullable: true })
  subscriptionEndDate?: Date | null;

  constructor(user: UserEntity) {
    super(user);
    this.birthDate = user.birthDate;
    this.gender = user.gender;
    this.height = user.height;
    this.weight = user.weight;
    this.address = user.address;
    // this.memo = user.memo; 
    
    // Service에서 값을 채워넣어야 함
    this.firstPaymentDate = null;
    this.subscriptionEndDate = null;
  }
}
