import { ApiProperty } from '@nestjs/swagger';
import { UserResponseDto } from './user-response.dto';

export class MemberCountsDto {
  @ApiProperty({ description: '전체 회원 수' })
  total!: number;

  @ApiProperty({ description: '미결제 회원 수' })
  unpaid!: number;

  @ApiProperty({ description: '결제/앱 미연동 회원 수' })
  paidUnlinked!: number;

  @ApiProperty({ description: '결제/앱 연동 회원 수' })
  paidLinked!: number;
}

export class PagingDto {
  @ApiProperty()
  total!: number;

  @ApiProperty()
  limit!: number;

  @ApiProperty()
  totalPage!: number;

  @ApiProperty()
  page!: number;
}

export class MyMembersResponseDto {
  @ApiProperty({ description: '회원 목록', type: [UserResponseDto] })
  items!: UserResponseDto[];

  @ApiProperty({ description: '페이징 정보' })
  paging!: PagingDto;

  @ApiProperty({ description: '상태별 회원 수' })
  counts!: MemberCountsDto;
}
