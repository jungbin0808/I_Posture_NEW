import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNumber, IsOptional, IsString } from 'class-validator';

export class UpdateUserDto {
  @ApiProperty({ description: '이름', required: false })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiProperty({ description: '전화번호', required: false })
  @IsString()
  @IsOptional()
  phone?: string;

  @ApiProperty({ description: '이메일', required: false })
  @IsEmail()
  @IsOptional()
  email?: string;

  @ApiProperty({ description: '생년월일', required: false })
  @IsString()
  @IsOptional()
  birthDate?: string;

  @ApiProperty({ description: '성별', required: false })
  @IsString()
  @IsOptional()
  gender?: string;

  @ApiProperty({ description: '키', required: false })
  @IsNumber()
  @IsOptional()
  height?: number;

  @ApiProperty({ description: '몸무게', required: false })
  @IsNumber()
  @IsOptional()
  weight?: number;

  @ApiProperty({ description: '주소', required: false })
  @IsString()
  @IsOptional()
  address?: string;

  @ApiProperty({ description: '메모 (트레이너용)', required: false })
  @IsString()
  @IsOptional()
  memo?: string;
}
