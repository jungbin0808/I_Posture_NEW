import { ApiProperty } from '@nestjs/swagger';
import { Gender } from '../../../database/entities/user.entity';

class CenterInfo {
  @ApiProperty({ description: '소속 센터 ID', nullable: true })
  id?: string;

  @ApiProperty({ description: '소속 센터 이름', nullable: true })
  name?: string;
}

class NotificationSettings {
  @ApiProperty({ description: '이벤트/프로모션 마케팅 푸시알림' })
  eventMarketing!: boolean;

  @ApiProperty({ description: '내가 올린 질문 알림' })
  myQuestion!: boolean;

  @ApiProperty({ description: '챌린지 신청 결과 알림' })
  challengeResult!: boolean;

  @ApiProperty({ description: '이용권 사용량 완료 알림' })
  subscriptionUsage!: boolean;

  @ApiProperty({ description: '내가 올린 답변 채택 알림' })
  myAnswerAccepted!: boolean;

  @ApiProperty({ description: '적립금 정산알림' })
  pointSettlement!: boolean;

  @ApiProperty({ description: '(USER APP) 전체 알림 받기 마스터 토글' })
  all!: boolean;

  @ApiProperty({ description: '(USER APP) 체형·인바디 측정 주기 알림' })
  bodyMeasurementCycle!: boolean;

  @ApiProperty({ description: '(USER APP) 운동 루틴 알림' })
  workoutRoutine!: boolean;

  @ApiProperty({ description: '(USER APP) 챌린지 참여 및 마감 알림' })
  challengeParticipation!: boolean;

  @ApiProperty({ description: '(USER APP) 식단 피드백 및 작성 알림' })
  dietFeedback!: boolean;

  @ApiProperty({ description: '(USER APP) 트레이너 분석 리포트 알림' })
  trainerReport!: boolean;

  @ApiProperty({ description: '(USER APP) 공지사항 알림' })
  notice!: boolean;
}

export class MyProfileResponseDto {
  // 상단 정보
  @ApiProperty({ description: '유저 ID (UUID)' })
  id!: string;

  @ApiProperty({ description: '로그인 아이디 (이메일)' })
  userId!: string;

  @ApiProperty({ description: '이용권 사용 여부' })
  hasSubscription!: boolean;

  @ApiProperty({ description: '나의 회원 수 (트레이너/센터)' })
  myMemberCount!: number;

  @ApiProperty({ description: '나의 별점 지수' })
  myStarRating!: number;

  @ApiProperty({ description: '나의 질문 수' })
  myQuestionCount!: number;

  @ApiProperty({ description: '나의 답변 수' })
  myAnswerCount!: number;

  @ApiProperty({ description: '나의 챌린지 적립금' })
  myChallengePoints!: number;

  // 중간 정보
  @ApiProperty({ description: '이름' })
  name!: string;

  @ApiProperty({ description: '아이디 (이메일)' })
  email!: string;

  @ApiProperty({ description: '휴대폰 번호 (APP 회원은 미입력 가능)', required: false, nullable: true })
  phone?: string;

  @ApiProperty({ description: '생년월일 (YYYY-MM-DD)', required: false, nullable: true })
  birthDate?: string;

  @ApiProperty({ description: '성별', enum: Gender, required: false, nullable: true })
  gender?: Gender;

  @ApiProperty({ description: '키 (cm)', required: false, nullable: true })
  height?: number;

  @ApiProperty({ description: '몸무게 (kg)', required: false, nullable: true })
  weight?: number;

  @ApiProperty({ description: '소속명 (프리랜서 트레이너 전용)', required: false, nullable: true })
  affiliationName?: string;

  @ApiProperty({ description: '소속 센터 정보 (센터/센터소속 트레이너 전용)', required: false, nullable: true })
  center?: CenterInfo;

  // 하단 정보
  @ApiProperty({ description: '알림 설정' })
  notifications!: NotificationSettings;
}
