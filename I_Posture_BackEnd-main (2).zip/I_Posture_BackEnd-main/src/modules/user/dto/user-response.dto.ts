import { ApiProperty } from '@nestjs/swagger';
import { UserEntity } from '../../../database/entities/user.entity';
import { IdentityLinkStatus } from '../../../database/entities/member-identity-link.entity';

class UserStatusDto {
  @ApiProperty()
  isLinked!: boolean;

  @ApiProperty({ description: '오프라인 결제 여부' })
  offlinePaid!: boolean;
}

export class UserResponseDto {
  @ApiProperty({ description: '회원 ID' })
  id: string;

  @ApiProperty({ description: '이름' })
  name: string;

  @ApiProperty({ description: '전화번호', nullable: true })
  phone?: string;

  @ApiProperty({ description: '이메일' })
  email: string;

  @ApiProperty({ description: '마지막 상담일', nullable: true })
  lastConsultationDate?: Date | null;

  @ApiProperty({ description: '마지막 체형 리포트 날짜', nullable: true })
  lastBodyReportDate?: Date | null;

  @ApiProperty({ description: '마지막 정밀 리포트 날짜', nullable: true })
  lastPrecisionReportDate?: Date | null;

  @ApiProperty({ description: '연동 일시', nullable: true })
  linkedAt?: Date | null;

  @ApiProperty({ description: '이용권 종료일', nullable: true })
  subscriptionEndDate?: Date | null;

  @ApiProperty({ description: '회원 상태' })
  status: UserStatusDto;

  constructor(user: UserEntity) {
    this.id = user.id;
    this.name = user.name;
    this.phone = user.phone;
    this.email = user.email;
    
    // 아래 필드들은 UserService에서 별도로 채워줘야 함 (일단 null/기본값 처리)
    this.lastConsultationDate = null;
    this.lastBodyReportDate = null;
    this.lastPrecisionReportDate = null;

    // 재연동 시마다 새 row가 쌓이므로(2026-10-08, 이력 보존을 위해 재사용 대신 새로 생성하는 방식으로
    // 변경됨) 배열 순서([0])에 의존하면 안 되고, 반드시 LINKED 상태인 row를 직접 찾아야 한다.
    const linkedLink = user.managedIdentityLinks?.find((link) => link.status === IdentityLinkStatus.LINKED);
    this.linkedAt = linkedLink?.createdAt || null;
    this.subscriptionEndDate = null;

    this.status = {
      isLinked: !!linkedLink,
      offlinePaid: user.offlinePaymentStatus,
    };
  }
}
