import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsIn, IsOptional } from 'class-validator';

export type MemberStatusUpdateType = 'UNPAID' | 'PAID_UNLINKED' | 'PAID_LINKED';

export class UpdateMemberStatusDto {
  @ApiProperty({
    description: '변경할 회원 상태',
    enum: ['UNPAID', 'PAID_UNLINKED', 'PAID_LINKED'],
    example: 'PAID_LINKED',
  })
  @IsIn(['UNPAID', 'PAID_UNLINKED', 'PAID_LINKED'])
  status!: MemberStatusUpdateType;

  @ApiProperty({
    description: '앱 회원 이메일 (PAID_LINKED 선택 시 필수)',
    required: false,
    example: 'app_user@example.com',
  })
  @IsEmail()
  @IsOptional()
  email?: string;
}
