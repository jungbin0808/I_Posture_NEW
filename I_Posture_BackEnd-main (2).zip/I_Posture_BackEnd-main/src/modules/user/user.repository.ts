import { Injectable, Optional } from "@nestjs/common";
import { EntityManager, EntityTarget, QueryRunner, Repository } from "typeorm";
import { InjectEntityManager } from "@nestjs/typeorm";

import { UserEntity } from "../../database/entities/user.entity";

@Injectable()
export class UserRepository extends Repository<UserEntity> {
  constructor(
    @Optional() target: EntityTarget<UserEntity> = UserEntity,
    @InjectEntityManager() manager: EntityManager,
    @Optional() queryRunner?: QueryRunner,
  ) {
    super(target, manager, queryRunner);
  }
}
