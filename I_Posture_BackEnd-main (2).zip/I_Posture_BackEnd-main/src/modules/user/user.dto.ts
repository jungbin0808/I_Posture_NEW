import { IsEmail, IsEnum, IsNumber, IsOptional, IsString, Length, MinLength, IsBoolean, Min } from "class-validator";
import { Type } from "class-transformer";
import { Gender, PaymentStatus } from "../../database/entities/user.entity";

export class CreateUserDto {
  @IsEmail()
  email!: string;

  @IsString()
  @Length(1, 100)
  name!: string;

  @IsString()
  @Length(4, 100)
  password!: string;
}

export class UpdateUserDto {
  @IsOptional()
  @IsEmail()
  email?: string;

  @IsOptional()
  @IsString()
  @Length(1, 100)
  name?: string;

  @IsOptional()
  @IsString()
  @Length(4, 100)
  password?: string;
}


export enum MemberStatusFilter {
  PAID = 'PAID',
  UNPAID = 'UNPAID',
  LINKED = 'LINKED',
  UNLINKED = 'UNLINKED',
}

export enum SortOrder {
  ASC = 'ASC',
  DESC = 'DESC',
}

export class GetMyMembersDto {
  @IsOptional()
  @IsBoolean()
  @Type(() => Boolean)
  hasSubscription?: boolean;

  @IsOptional()
  @IsEnum(MemberStatusFilter)
  statusFilter?: MemberStatusFilter;

  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page: number = 1;

  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit: number = 10;

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsEnum(SortOrder)
  sort: SortOrder = SortOrder.DESC;
}

export class MyMemberResponseDto {
  id!: string;
  name!: string;
  phone!: string;
  email!: string;
  lastConsultationDate?: Date;
  lastBodyReportDate?: Date;
  lastPrecisionReportDate?: Date;
  linkedAt?: Date;
  subscriptionEndDate?: Date;
  status!: {
    isLinked: boolean;
    paymentStatus: PaymentStatus;
  };
}

export class UpdateManagedMemberDto {
  @IsOptional()
  @IsEmail()
  email?: string;

  @IsOptional()
  @IsString()
  @Length(1, 50)
  name?: string;

  @IsOptional()
  @IsString()
  @Length(1, 65)
  phone?: string;

  @IsOptional()
  @IsString()
  birthDate?: string;

  @IsOptional()
  @IsEnum(Gender)
  gender?: Gender;

  @IsOptional()
  @IsNumber()
  height?: number;

  @IsOptional()
  @IsNumber()
  weight?: number;

  @IsOptional()
  @IsString()
  address?: string;
}
