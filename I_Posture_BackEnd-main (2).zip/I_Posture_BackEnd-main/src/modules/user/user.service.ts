import { Injectable, NotFoundException, BadRequestException, ConflictException } from '@nestjs/common';
import { InjectRepository, InjectDataSource } from '@nestjs/typeorm';
import { DataSource, Repository, Brackets, In, QueryFailedError } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import * as bcrypt from 'bcrypt';
import { UserEntity, UserType, PaymentStatus, MemberType, AccountStatus } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { FindMyMembersDto } from './dto/find-my-members.dto';
import { MyMembersResponseDto, MemberCountsDto, PagingDto } from './dto/my-members-response.dto';
import { MemberFilterType, MemberSortOrder } from './enums/member-filter.enum';
import { UserResponseDto } from './dto/user-response.dto';
import { UserDetailResponseDto } from './dto/user-detail-response.dto';
import { MyProfileResponseDto } from './dto/my-profile-response.dto';
import { UpdateMyProfileDto } from './dto/update-my-profile.dto';
import { RegisterMemberDto } from './dto/register-member.dto';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { SubscriptionEntity, SubscriptionStatus } from '../../database/entities/subscription.entity';
import { CapacityService } from '../capacity/capacity.service';
import { RefreshTokenEntity } from '../../database/entities/refresh-token.entity';
import { QnaQuestionEntity } from '../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../database/entities/qna-answer.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { WorkoutLogEntity } from '../../database/entities/workout-log.entity';
import { ConsultationLogEntity } from '../../database/entities/consultation-log.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { ReportComparisonEntity } from '../../database/entities/report-comparison.entity';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { ScheduleBookingEntity } from '../../database/entities/schedule-booking.entity';
import { QnaService } from '../qna/qna.service';
import { FoodLogService } from '../food-log/food-log.service';
import { resolveEmailAvailability } from '../auth/helpers/email-availability.helper';
import { ACCOUNT_DELETION_GRACE_DAYS } from '../center/trainer/helpers/center-trainer-account-status.helper';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    @InjectRepository(RefreshTokenEntity)
    private readonly refreshTokenRepo: Repository<RefreshTokenEntity>,
    private readonly capacityService: CapacityService,
    @InjectRepository(QnaQuestionEntity)
    private readonly qnaQuestionRepo: Repository<QnaQuestionEntity>,
    @InjectRepository(QnaAnswerEntity)
    private readonly qnaAnswerRepo: Repository<QnaAnswerEntity>,
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(MotionAnalysisEntity)
    private readonly motionAnalysisRepo: Repository<MotionAnalysisEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(WorkoutLogEntity)
    private readonly workoutLogRepo: Repository<WorkoutLogEntity>,
    @InjectRepository(ConsultationLogEntity)
    private readonly consultationLogRepo: Repository<ConsultationLogEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(ReportComparisonEntity)
    private readonly reportComparisonRepo: Repository<ReportComparisonEntity>,
    @InjectRepository(ScheduleEntity)
    private readonly scheduleRepo: Repository<ScheduleEntity>,
    @InjectRepository(ScheduleBookingEntity)
    private readonly scheduleBookingRepo: Repository<ScheduleBookingEntity>,
    private readonly qnaService: QnaService,
    @InjectDataSource()
    private readonly dataSource: DataSource,
    private readonly foodLogService: FoodLogService,
  ) {}

  private buildManagedMemberUserId(email: string): string {
    return `MANAGED_${email}`;
  }

  private async assertRegisterMemberEmailAvailable(email: string): Promise<void> {
    const managedUserId = this.buildManagedMemberUserId(email);
    const existingUser = await this.userRepo.findOne({
      where: [
        { email },
        { userId: email },
        { userId: managedUserId },
      ],
      withDeleted: true,
    });

    if (existingUser) {
      throw new ConflictException('이미 존재하는 이메일입니다.');
    }
  }

  private async saveManagedMemberUser(user: UserEntity): Promise<UserEntity> {
    try {
      return await this.userRepo.save(user);
    } catch (error) {
      if (error instanceof QueryFailedError && (error.driverError as { code?: string })?.code === 'ER_DUP_ENTRY') {
        throw new ConflictException('이미 존재하는 이메일입니다.');
      }
      throw error;
    }
  }

  @Transactional()
  async createManagedMember(trainerId: string, dto: CreateUserDto): Promise<UserEntity> {
    await this.assertRegisterMemberEmailAvailable(dto.email);

    const user = this.userRepo.create({
      ...dto,
      userId: this.buildManagedMemberUserId(dto.email),
      memberType: MemberType.MANAGED,
      userType: UserType.MEMBER,
    });
    const savedUser = await this.saveManagedMemberUser(user);

    const trainerUser = this.trainerUserRepo.create({
      trainerId,
      memberId: savedUser.id,
      status: TrainerUserStatus.ACTIVE,
    });
    await this.trainerUserRepo.save(trainerUser);

    return savedUser;
  }

  async getMyMembers(trainerId: string, dto: FindMyMembersDto): Promise<MyMembersResponseDto> {
    const { page = 1, limit = 10, search, filterType, isActiveSubscription, sort = MemberSortOrder.JOIN_DATE_DESC } = dto;

    // 1. 기본 쿼리 빌더 (서브쿼리로 최신 날짜만 SELECT)
    const queryBuilder = this.userRepo.createQueryBuilder('user')
      .innerJoin('user.trainerMemberships', 'tu')
      .leftJoinAndSelect('user.managedIdentityLinks', 'link')
      .leftJoin('user.subscriptions', 'sub', 'sub.status = :subStatus', { subStatus: 'ACTIVE' })
      .where('tu.trainerId = :trainerId', { trainerId })
      .andWhere('tu.status = :status', { status: TrainerUserStatus.ACTIVE });

    // 최신 상담일지 날짜 서브쿼리
    queryBuilder.addSelect(subQuery =>
      subQuery
        .select('MAX(cl.consult_at)')
        .from('consultation_logs', 'cl')
        .where('cl.user_id = user.id')
        .andWhere('cl.deleted_at IS NULL'),
      'lastConsultationDate'
    );

    // 최신 체형리포트 날짜 서브쿼리
    queryBuilder.addSelect(subQuery =>
      subQuery
        .select('MAX(br.created_at)')
        .from('body_reports', 'br')
        .where('br.user_id = user.id')
        .andWhere('br.deleted_at IS NULL'),
      'lastBodyReportDate'
    );

    // 최신 정밀리포트 날짜 서브쿼리
    queryBuilder.addSelect(subQuery =>
      subQuery
        .select('MAX(pr.created_at)')
        .from('precision_reports', 'pr')
        .where('pr.user_id = user.id')
        .andWhere('pr.deleted_at IS NULL'),
      'lastPrecisionReportDate'
    );

    // 최신 구독 종료일 서브쿼리
    queryBuilder.addSelect(subQuery =>
      subQuery
        .select('s.next_billing_date')
        .from('subscriptions', 's')
        .where('s.user_id = user.id')
        .andWhere('s.status = :subStatus')
        .orderBy('s.next_billing_date', 'DESC')
        .limit(1),
      'subscriptionEndDate'
    );

    if (search) {
      queryBuilder.andWhere(new Brackets(qb => {
        qb.where('user.name LIKE :search', { search: `%${search}%` })
          .orWhere('user.phone LIKE :search', { search: `%${search}%` })
          .orWhere('user.email LIKE :search', { search: `%${search}%` });
      }));
    }

    // 2. 카운트 계산 (한 번의 쿼리로 집계)
    const countsQuery = this.userRepo.createQueryBuilder('user')
      .innerJoin('user.trainerMemberships', 'tu')
      .leftJoin('user.managedIdentityLinks', 'link')
      .select('COUNT(DISTINCT user.id)', 'total')
      .addSelect('SUM(CASE WHEN user.offline_payment_status = 0 THEN 1 ELSE 0 END)', 'unpaid')
      .addSelect('SUM(CASE WHEN user.offline_payment_status = 1 AND (link.status IS NULL OR link.status != :linked) THEN 1 ELSE 0 END)', 'paidUnlinked')
      .addSelect('SUM(CASE WHEN user.offline_payment_status = 1 AND link.status = :linked THEN 1 ELSE 0 END)', 'paidLinked')
      .where('tu.trainerId = :trainerId', { trainerId })
      .andWhere('tu.status = :status', { status: TrainerUserStatus.ACTIVE })
      .setParameters({
        linked: IdentityLinkStatus.LINKED,
      });

    if (search) {
      countsQuery.andWhere(new Brackets(qb => {
        qb.where('user.name LIKE :search', { search: `%${search}%` })
          .orWhere('user.phone LIKE :search', { search: `%${search}%` })
          .orWhere('user.email LIKE :search', { search: `%${search}%` });
      }));
    }

    const countsRaw = await countsQuery.getRawOne();
    const counts: MemberCountsDto = {
      total: parseInt(countsRaw?.total || '0', 10),
      unpaid: parseInt(countsRaw?.unpaid || '0', 10),
      paidUnlinked: parseInt(countsRaw?.paidUnlinked || '0', 10),
      paidLinked: parseInt(countsRaw?.paidLinked || '0', 10),
    };

    // 3. 필터링
    if (filterType === MemberFilterType.UNPAID) {
      queryBuilder.andWhere('user.offlinePaymentStatus = :offlinePaid', { offlinePaid: false });
    } else if (filterType === MemberFilterType.PAID_UNLINKED) {
      queryBuilder.andWhere('user.offlinePaymentStatus = :offlinePaid', { offlinePaid: true })
        .andWhere(new Brackets(qb => {
          qb.where('link.status IS NULL')
            .orWhere('link.status != :linkStatus', { linkStatus: IdentityLinkStatus.LINKED });
        }));
    } else if (filterType === MemberFilterType.PAID_LINKED) {
      queryBuilder.andWhere('user.offlinePaymentStatus = :offlinePaid', { offlinePaid: true })
        .andWhere('link.status = :linkStatus', { linkStatus: IdentityLinkStatus.LINKED });
    }

    // 이용권 보유 회원만 보기 (AND 조건)
    if (isActiveSubscription) {
      queryBuilder.andWhere('sub.id IS NOT NULL');
    }

    const isAsc = sort === MemberSortOrder.JOIN_DATE_ASC || sort === MemberSortOrder.NAME_ASC;
    const direction = isAsc ? 'ASC' : 'DESC';
    const sortByJoinDate =
      sort === MemberSortOrder.JOIN_DATE_ASC || sort === MemberSortOrder.JOIN_DATE_DESC;

    if (sortByJoinDate) {
      queryBuilder.addSelect('tu.createdAt');
    }

    const sortColumn = sort === MemberSortOrder.NAME_ASC || sort === MemberSortOrder.NAME_DESC
      ? 'user.name'
      : 'tu.createdAt';

    queryBuilder
      .orderBy(sortColumn, direction)
      .addOrderBy('user.id', direction)
      .skip((page - 1) * limit)
      .take(limit);

    const rawResults = await queryBuilder.getRawAndEntities();
    const total = filterType ? await queryBuilder.getCount() : counts.total;

    const userDtos = rawResults.entities.map((user, index) => {
      const dto = new UserResponseDto(user);
      const raw = rawResults.raw[index];

      dto.lastConsultationDate = raw.lastConsultationDate ? new Date(raw.lastConsultationDate) : undefined;
      dto.lastBodyReportDate = raw.lastBodyReportDate ? new Date(raw.lastBodyReportDate) : undefined;
      dto.lastPrecisionReportDate = raw.lastPrecisionReportDate ? new Date(raw.lastPrecisionReportDate) : undefined;
      dto.subscriptionEndDate = raw.subscriptionEndDate ? new Date(raw.subscriptionEndDate) : undefined;

      return dto;
    });

    const paging: PagingDto = {
      total,
      limit,
      page,
      totalPage: Math.ceil(total / limit),
    };

    return {
      items: userDtos,
      paging,
      counts,
    };
  }

  async findOne(id: string): Promise<UserDetailResponseDto> {
    const user = await this.userRepo.findOne({
      where: { id },
      relations: ['managedIdentityLinks', 'payments', 'subscriptions'],
    });
    if (!user) {
      throw new NotFoundException('User not found');
    }

    const dto = new UserDetailResponseDto(user);

    // 최초 결제일
    if (user.payments?.length > 0) {
      user.payments.sort((a, b) => a.paidAt.getTime() - b.paidAt.getTime());
      dto.firstPaymentDate = user.payments[0].paidAt;
    }

    // 이용권 만료일 (가장 늦게 끝나는 활성 구독 기준)
    if (user.subscriptions?.length > 0) {
      const activeSubscriptions = user.subscriptions.filter(sub => sub.status === 'ACTIVE');
      if (activeSubscriptions.length > 0) {
        activeSubscriptions.sort((a, b) => {
          const dateA = a.nextBillingDate ? new Date(a.nextBillingDate).getTime() : 0;
          const dateB = b.nextBillingDate ? new Date(b.nextBillingDate).getTime() : 0;
          return dateB - dateA;
        });
        dto.subscriptionEndDate = activeSubscriptions[0].nextBillingDate ? new Date(activeSubscriptions[0].nextBillingDate) : null;
      }
    }

    return dto;
  }

  async update(id: string, dto: UpdateUserDto): Promise<UserEntity> {
    const user = await this.userRepo.findOne({ where: { id } });
    if (!user) {
      throw new NotFoundException('User not found');
    }

    if (dto.email && dto.email !== user.email) {
      const usersWithEmail = await this.userRepo.find({
        where: { email: dto.email },
        withDeleted: true,
      });
      const availability = resolveEmailAvailability(usersWithEmail, user.userType, { excludeUserId: id });
      if (!availability.available) {
        throw new ConflictException(availability.message ?? '이미 사용 중인 이메일입니다.');
      }
    }

    Object.assign(user, dto);
    return this.userRepo.save(user);
  }

  async getMyProfile(userId: string): Promise<MyProfileResponseDto> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    const response = new MyProfileResponseDto();
    response.id = user.id;
    // MEMBER는 소셜로그인 전용이라 로그인 아이디 개념이 없고, user_id 컬럼은 unique 제약 충족용 내부 식별값일 뿐이라 화면에 노출하면 안 됨
    response.userId = user.userType === UserType.MEMBER ? user.email : user.userId;
    response.name = user.name;
    response.email = user.email;
    response.phone = user.phone;
    response.birthDate = user.birthDate;
    response.gender = user.gender;
    response.height = user.height;
    response.weight = user.weight;

    // 알림 설정
    response.notifications = {
      eventMarketing: user.notificationEventMarketing,
      myQuestion: user.notificationMyQuestion,
      challengeResult: user.notificationChallengeResult,
      subscriptionUsage: user.notificationSubscriptionUsage,
      myAnswerAccepted: user.notificationMyAnswerAccepted,
      pointSettlement: user.notificationPointSettlement,
      all: user.notificationAll,
      bodyMeasurementCycle: user.notificationBodyMeasurementCycle,
      workoutRoutine: user.notificationWorkoutRoutine,
      challengeParticipation: user.notificationChallengeParticipation,
      dietFeedback: user.notificationDietFeedback,
      trainerReport: user.notificationTrainerReport,
      notice: user.notificationNotice,
    };

    // 트레이너/센터 관련 정보
    if (user.userType === UserType.C_TRAINER || user.userType === UserType.F_TRAINER || user.userType === UserType.CENTER) {
      // 회원 수
      const memberCount = await this.trainerUserRepo.count({
        where: { trainerId: userId, status: TrainerUserStatus.ACTIVE },
      });
      response.myMemberCount = memberCount;

      // 소속 센터 정보 + 이용권 여부
      if (user.userType === UserType.CENTER) {
        const center = await this.centerRepo.findOne({ where: { ownerId: userId } });
        if (center) {
          response.center = { id: center.id, name: center.name };
        }
        // CENTER: 본인의 활성 구독 여부
        const sub = await this.subscriptionRepo.findOne({ where: { userId, status: SubscriptionStatus.ACTIVE } });
        response.hasSubscription = !!sub;
      } else if (user.userType === UserType.C_TRAINER) {
        const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: userId }, relations: ['center'] });
        if (affiliation && affiliation.center) {
          response.center = { id: affiliation.center.id, name: affiliation.center.name };
          // C_TRAINER: 소속 센터 오너의 활성 구독 여부
          const sub = await this.subscriptionRepo.findOne({
            where: { userId: affiliation.center.ownerId, status: SubscriptionStatus.ACTIVE },
          });
          response.hasSubscription = !!sub;
        } else {
          response.hasSubscription = false;
        }
      } else if (user.userType === UserType.F_TRAINER) {
        response.affiliationName = user.affiliationName;
        const sub = await this.subscriptionRepo.findOne({ where: { userId, status: SubscriptionStatus.ACTIVE } });
        response.hasSubscription = !!sub;
      }
    } else {
      response.myMemberCount = 0;
      response.hasSubscription = false;
    }

    const [questionCount, answerCount, ratingResult] = await Promise.all([
      this.qnaQuestionRepo.count({ where: { authorId: userId } }),
      this.qnaAnswerRepo.count({ where: { authorId: userId } }),
      this.qnaAnswerRepo
        .createQueryBuilder('a')
        .select('AVG(a.rating)', 'avg')
        .where('a.authorId = :userId AND a.isAccepted = true AND a.rating IS NOT NULL', { userId })
        .getRawOne(),
    ]);

    response.myQuestionCount = questionCount;
    response.myAnswerCount = answerCount;
    const starRating = ratingResult?.avg != null ? parseFloat(parseFloat(ratingResult.avg).toFixed(1)) : 0;
    response.myStarRating = starRating;
    response.myChallengePoints = user.totalPoints;

    return response;
  }

  async updateMyProfile(userId: string, dto: UpdateMyProfileDto): Promise<void> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    if (dto.name !== undefined) user.name = dto.name;
    if (dto.phone !== undefined) user.phone = dto.phone;
    if (dto.birthDate !== undefined) user.birthDate = dto.birthDate;
    if (dto.gender !== undefined) user.gender = dto.gender;
    if (dto.height !== undefined) user.height = dto.height;
    if (dto.weight !== undefined) user.weight = dto.weight;

    if (dto.newPassword !== undefined) {
      user.password = await bcrypt.hash(dto.newPassword.toLowerCase(), 10);
    }

    // 소속명: F_TRAINER(프리랜서 트레이너) 전용
    if (dto.affiliationName !== undefined) {
      if (user.userType !== UserType.F_TRAINER) {
        throw new BadRequestException('소속명은 프리랜서 트레이너만 수정할 수 있습니다.');
      }
      user.affiliationName = dto.affiliationName;
    }

    // 알림 설정
    if (dto.notifications) {
      const n = dto.notifications;
      if (n.eventMarketing !== undefined) user.notificationEventMarketing = n.eventMarketing;
      if (n.myQuestion !== undefined) user.notificationMyQuestion = n.myQuestion;
      if (n.challengeResult !== undefined) user.notificationChallengeResult = n.challengeResult;
      if (n.subscriptionUsage !== undefined) user.notificationSubscriptionUsage = n.subscriptionUsage;
      if (n.myAnswerAccepted !== undefined) user.notificationMyAnswerAccepted = n.myAnswerAccepted;
      if (n.pointSettlement !== undefined) user.notificationPointSettlement = n.pointSettlement;
      if (n.all !== undefined) user.notificationAll = n.all;
      if (n.bodyMeasurementCycle !== undefined) user.notificationBodyMeasurementCycle = n.bodyMeasurementCycle;
      if (n.workoutRoutine !== undefined) user.notificationWorkoutRoutine = n.workoutRoutine;
      if (n.challengeParticipation !== undefined) user.notificationChallengeParticipation = n.challengeParticipation;
      if (n.dietFeedback !== undefined) user.notificationDietFeedback = n.dietFeedback;
      if (n.trainerReport !== undefined) user.notificationTrainerReport = n.trainerReport;
      if (n.notice !== undefined) user.notificationNotice = n.notice;
    }

    await this.userRepo.save(user);
  }

  async registerFcmToken(userId: string, fcmToken: string): Promise<void> {
    await this.userRepo.update({ id: userId }, { fcmToken });
  }

  /**
   * 일반 회원 가입 (트레이너가 관리하는 회원 등록)
   */
  @Transactional()
  async registerMember(trainerId: string, dto: RegisterMemberDto): Promise<UserEntity> {
    await this.assertRegisterMemberEmailAvailable(dto.email);

    const user = this.userRepo.create({
      userId: this.buildManagedMemberUserId(dto.email),
      email: dto.email,
      name: dto.name,
      phone: dto.phone,
      height: dto.height,
      weight: dto.weight,
      birthDate: dto.birthDate,
      gender: dto.gender,
      memberType: MemberType.MANAGED,
      userType: UserType.MEMBER,
      accountStatus: AccountStatus.ACTIVE,
      paymentStatus: PaymentStatus.UNPAID,
    });
    const savedUser = await this.saveManagedMemberUser(user);

    // 트레이너-회원 관계 생성
    const trainerUser = this.trainerUserRepo.create({
      trainerId,
      memberId: savedUser.id,
      status: TrainerUserStatus.ACTIVE,
    });
    await this.trainerUserRepo.save(trainerUser);

    return savedUser;
  }

  /**
   * 회원 연동 (앱 회원 ↔ 관리 회원 연결)
   */
  @Transactional()
  async linkMember(trainerId: string, managedMemberId: string, email: string): Promise<{ success: boolean; message: string }> {
    // 1. 관리 회원이 트레이너의 회원인지 확인
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId: managedMemberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new BadRequestException('해당 회원에 대한 권한이 없습니다.');
    }

    // 2. 관리 회원 확인
    const managedMember = await this.userRepo.findOne({
      where: { id: managedMemberId, memberType: MemberType.MANAGED },
    });
    if (!managedMember) {
      throw new NotFoundException('관리 회원을 찾을 수 없습니다.');
    }

    // 3. 앱 회원 확인 (이메일로)
    const appMember = await this.userRepo.findOne({
      where: { email, memberType: MemberType.APP },
    });
    if (!appMember) {
      throw new NotFoundException('해당 이메일의 앱 회원을 찾을 수 없습니다.');
    }

    // 4. 해당 앱 회원이 다른 관리 회원과 이미 연동되어 있는지 확인
    const alreadyLinkedElsewhere = await this.identityLinkRepo.findOne({
      where: { appMemberId: appMember.id, status: IdentityLinkStatus.LINKED },
    });
    if (alreadyLinkedElsewhere && alreadyLinkedElsewhere.managedMemberId !== managedMemberId) {
      throw new ConflictException('해당 앱 회원은 이미 다른 관리 회원과 연동되어 있습니다.');
    }

    // 5. 해당 관리 회원이 다른 앱 회원과 이미 연동되어 있는지 확인
    const managedAlreadyLinked = await this.identityLinkRepo.findOne({
      where: { managedMemberId, status: IdentityLinkStatus.LINKED },
    });
    if (managedAlreadyLinked && managedAlreadyLinked.appMemberId !== appMember.id) {
      throw new ConflictException('이 관리 회원은 이미 다른 앱 회원과 연동되어 있습니다. 먼저 연동을 해제해주세요.');
    }

    // 6. 이미 LINKED 상태로 연동되어 있는지 확인 (같은 조합)
    const existingActiveLink = await this.identityLinkRepo.findOne({
      where: { managedMemberId, appMemberId: appMember.id, status: IdentityLinkStatus.LINKED },
    });
    if (existingActiveLink) {
      throw new ConflictException('이미 연동된 회원입니다.');
    }

    // 7. 새로운 연동 생성 — 과거 UNLINKED 이력(기존 row)은 그대로 보존하고 항상 새 row로 만든다.
    // 재사용 방식은 unlinkedAt 초기화가 TypeORM에서 undefined로는 반영되지 않는 문제가 있었고,
    // created_at도 최초 연동일에 고정돼 재연동 시점이 마이페이지에 반영되지 않는 문제가 있었다 (2026-10-08 수정).
    const link = this.identityLinkRepo.create({
      appMemberId: appMember.id,
      managedMemberId,
      status: IdentityLinkStatus.LINKED,
    });
    await this.identityLinkRepo.save(link);

    return { success: true, message: '회원 연동이 완료되었습니다.' };
  }

  /**
   * 회원 연동 해제
   */
  @Transactional()
  async unlinkMember(trainerId: string, managedMemberId: string): Promise<{ success: boolean; message: string }> {
    // 1. 관리 회원이 트레이너의 회원인지 확인
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId: managedMemberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new BadRequestException('해당 회원에 대한 권한이 없습니다.');
    }

    // 2. 연동 정보 찾기
    const link = await this.identityLinkRepo.findOne({
      where: { managedMemberId, status: IdentityLinkStatus.LINKED },
    });
    if (!link) {
      throw new NotFoundException('연동된 회원 정보를 찾을 수 없습니다.');
    }

    // 3. 연동 해제
    link.status = IdentityLinkStatus.UNLINKED;
    link.unlinkedAt = new Date();
    await this.identityLinkRepo.save(link);

    // 4. 회원을 종료 회원으로 전환
    await this.userRepo.update(managedMemberId, { paymentStatus: PaymentStatus.UNPAID });

    // 회원별 이용권 지급 개념이 삭제돼 트레이너가 회원에게 용량을 별도로 지급하지 않으므로
    // 회수할 용량도 없다 (2026-10-08). 연동 해제해도 트레이너가 만든 체형/정밀/인바디 등 데이터는
    // 삭제하지 않는다 — 재연동 시 기존 데이터를 그대로 볼 수 있어야 한다는 정책(2026-10-08 확정)에
    // 따라 소프트딜리트 로직도 제거함.

    return { success: true, message: '회원 연동이 해제되었습니다.' };
  }

  /**
   * 회원 상태 일괄 변경 (미결제 / 결제+앱미연동 / 결제+앱연동)
   */
  @Transactional()
  async updateMemberStatus(
    trainerId: string,
    memberId: string,
    status: 'UNPAID' | 'PAID_UNLINKED' | 'PAID_LINKED',
    email?: string,
  ): Promise<{ success: boolean }> {
    if (status === 'PAID_LINKED' && !email) {
      throw new BadRequestException('PAID_LINKED 선택 시 앱 회원 이메일이 필요합니다.');
    }

    const member = await this.userRepo.findOne({ where: { id: memberId } });
    if (!member) {
      throw new NotFoundException('회원을 찾을 수 없습니다.');
    }

    if (status === 'PAID_LINKED') {
      // 오프라인 결제 처리 후 linkMember 로직 재사용
      member.offlinePaymentStatus = true;
      await this.userRepo.save(member);
      await this.linkMember(trainerId, memberId, email!);
    } else {
      // UNPAID 또는 PAID_UNLINKED
      member.offlinePaymentStatus = status === 'PAID_UNLINKED';
      await this.userRepo.save(member);

      // 기존 연동 해제
      const link = await this.identityLinkRepo.findOne({
        where: { managedMemberId: memberId, status: IdentityLinkStatus.LINKED },
      });
      if (link) {
        link.status = IdentityLinkStatus.UNLINKED;
        await this.identityLinkRepo.save(link);
      }
    }

    return { success: true };
  }

  /**
   * 트레이너가 관리 회원 계정 완전 삭제
   * - 트레이너-회원 관계 확인 후 이용권 만료, 용량 회수
   * - 관련 데이터 소프트딜리트 + 회원 계정 소프트딜리트
   */
  @Transactional()
  async deleteMember(trainerId: string, memberId: string): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId },
    });
    if (!trainerUser) {
      throw new BadRequestException('해당 회원에 대한 권한이 없습니다.');
    }

    // 1. 활성 이용권 만료 처리 + 용량 회수
    const activeSubscription = await this.subscriptionRepo.findOne({
      where: { userId: memberId, status: SubscriptionStatus.ACTIVE },
      relations: ['plan'],
    });
    if (activeSubscription) {
      activeSubscription.status = SubscriptionStatus.EXPIRED;
      await this.subscriptionRepo.save(activeSubscription);
      await this.userRepo.update(memberId, { paymentStatus: PaymentStatus.UNPAID });
      await this.capacityService.deallocateCapacity(trainerId, memberId, activeSubscription.plan?.storageLimit);
    }

    // 2. 연동 정보 해제
    const link = await this.identityLinkRepo.findOne({
      where: { managedMemberId: memberId, status: IdentityLinkStatus.LINKED },
    });
    if (link) {
      link.status = IdentityLinkStatus.UNLINKED;
      await this.identityLinkRepo.save(link);
    }

    // 3. 트레이너-회원 관계 비활성화
    trainerUser.status = TrainerUserStatus.HOLD;
    await this.trainerUserRepo.save(trainerUser);

    // 4. 관련 데이터 소프트딜리트
    await this.recallDistributedMemberData(trainerId, memberId);

    // 5. 리프레시 토큰 폐기 + 회원 계정 소프트딜리트
    await this.refreshTokenRepo.delete({ userId: memberId });
    await this.userRepo.softDelete(memberId);

    return { success: true };
  }

  /**
   * 트레이너/센터 회원탈퇴
   * - 센터 탈퇴: 소속 트레이너가 회원에게 지급한 이용권·용량만 회수 (회원 데이터는 유지, HOLD로 접근 차단)
   * - 트레이너 탈퇴: 담당 회원 이용권·용량 회수 + 트레이너 생성 콘텐츠 소프트딜리트
   * - SAC 관리자 계정 복구는 restoreAccountByAdmin 사용
   */
  @Transactional()
  async withdrawAccount(userId: string): Promise<{ success: boolean }> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    if (user.userType === UserType.MEMBER) {
      return this.withdrawMemberAccount(userId, user);
    }

    if (
      user.userType !== UserType.C_TRAINER
      && user.userType !== UserType.F_TRAINER
      && user.userType !== UserType.CENTER
    ) {
      throw new BadRequestException('탈퇴할 수 없는 계정 유형입니다.');
    }

    if (user.userType === UserType.CENTER) {
      return this.withdrawCenterAccount(userId, user);
    }

    return this.withdrawTrainerAccount(userId, user);
  }

  /**
   * 앱 회원(Role.Member) 탈퇴
   * - 연동된 트레이너가 있으면: 지급된 이용권·용량 회수 + 트레이너가 생성한 콘텐츠(체형/인바디 등) 소프트딜리트 + 연동 해제
   * - 회원 본인 콘텐츠(식단일지, 작성한 질문/답변) 소프트딜리트, 보유 포인트 초기화
   * - 챌린지 내역은 아직 챌린지 기능 자체가 없어 처리 대상 없음
   */
  private async withdrawMemberAccount(userId: string, user: UserEntity): Promise<{ success: boolean }> {
    const link = await this.identityLinkRepo.findOne({
      where: { appMemberId: userId, status: IdentityLinkStatus.LINKED },
    });

    if (link) {
      const managedMemberId = link.managedMemberId;
      const activeTrainerUser = await this.trainerUserRepo.findOne({
        where: { memberId: managedMemberId, status: TrainerUserStatus.ACTIVE },
      });

      if (activeTrainerUser) {
        await this.recallGrantedSubscriptionAndCapacity(activeTrainerUser.trainerId, managedMemberId);
        await this.recallDistributedMemberData(activeTrainerUser.trainerId, managedMemberId);
        activeTrainerUser.status = TrainerUserStatus.HOLD;
        await this.trainerUserRepo.save(activeTrainerUser);
      }

      link.status = IdentityLinkStatus.UNLINKED;
      link.unlinkedAt = new Date();
      await this.identityLinkRepo.save(link);
    }

    await this.foodLogService.deleteAllDataForUser(userId);
    await this.qnaService.deleteAllDataForAuthor(userId);

    user.totalPoints = 0;
    user.accountStatus = AccountStatus.WITHDRAWAL;
    await this.userRepo.save(user);

    await this.refreshTokenRepo.delete({ userId });
    await this.userRepo.softDelete(userId);

    return { success: true };
  }

  /**
   * SAC 관리자가 탈퇴 계정을 복구합니다.
   * - 계정 soft-delete 해제 및 accountStatus → ACTIVE
   * - 센터/트레이너 관계, 회원 데이터, 식단일지는 별도 복구하지 않음
   * - 동일 아이디 재가입 대신 관리자 복구 또는 다른 아이디 가입 안내
   */
  @Transactional()
  async restoreAccountByAdmin(targetUserId: string): Promise<{ success: boolean }> {
    const user = await this.userRepo.findOne({
      where: { id: targetUserId },
      withDeleted: true,
    });
    if (!user) throw new NotFoundException('User not found');

    if (user.accountStatus !== AccountStatus.WITHDRAWAL || !user.deletedAt) {
      throw new BadRequestException('탈퇴 상태의 계정만 복구할 수 있습니다.');
    }

    await this.userRepo.recover(user);
    user.accountStatus = AccountStatus.ACTIVE;
    await this.userRepo.save(user);

    return { success: true };
  }

  private async withdrawTrainerAccount(userId: string, user: UserEntity): Promise<{ success: boolean }> {
    await this.withdrawTrainerMembers(userId, { recallMemberContent: true });

    const ownActiveSubscription = await this.subscriptionRepo.findOne({
      where: { userId, status: SubscriptionStatus.ACTIVE },
    });
    if (ownActiveSubscription) {
      ownActiveSubscription.status = SubscriptionStatus.EXPIRED;
      await this.subscriptionRepo.save(ownActiveSubscription);
      if (user.userType === UserType.F_TRAINER) {
        await this.userRepo.update(userId, { paymentStatus: PaymentStatus.UNPAID });
      }
    }

    if (user.userType === UserType.C_TRAINER) {
      const centerTrainer = await this.centerTrainerRepo.findOne({
        where: { trainerId: userId, status: CenterTrainerStatus.WORKING },
      });
      if (centerTrainer) {
        centerTrainer.status = CenterTrainerStatus.RESIGNED;
        await this.centerTrainerRepo.save(centerTrainer);
      }
    }

    await this.withdrawTrainerOwnResourceData(userId);
    await this.refreshTokenRepo.delete({ userId });

    user.accountStatus = AccountStatus.WITHDRAWAL;
    await this.userRepo.save(user);
    await this.userRepo.softDelete(userId);

    return { success: true };
  }

  private async withdrawCenterAccount(userId: string, user: UserEntity): Promise<{ success: boolean }> {
    const center = await this.centerRepo.findOne({ where: { ownerId: userId } });
    if (!center) throw new NotFoundException('센터 정보를 찾을 수 없습니다.');

    const centerTrainers = await this.centerTrainerRepo.find({
      where: { centerId: center.id, status: CenterTrainerStatus.WORKING },
    });
    const trainerIds = [...new Set([userId, ...centerTrainers.map((ct) => ct.trainerId)])];

    for (const trainerId of trainerIds) {
      await this.withdrawTrainerMembers(trainerId, { recallMemberContent: false });

      if (trainerId !== userId) {
        const trainerSubscription = await this.subscriptionRepo.findOne({
          where: { userId: trainerId, status: SubscriptionStatus.ACTIVE },
        });
        if (trainerSubscription) {
          trainerSubscription.status = SubscriptionStatus.EXPIRED;
          await this.subscriptionRepo.save(trainerSubscription);
        }
        await this.refreshTokenRepo.delete({ userId: trainerId });
      }
    }

    // 센터장 본인 탈퇴 시에만 스케줄·QnA 등 트레이너 운영 데이터 정리
    await this.withdrawTrainerOwnResourceData(userId);

    for (const centerTrainer of centerTrainers) {
      centerTrainer.status = CenterTrainerStatus.RESIGNED;
      await this.centerTrainerRepo.save(centerTrainer);
    }

    const ownActiveSubscription = await this.subscriptionRepo.findOne({
      where: { userId, status: SubscriptionStatus.ACTIVE },
    });
    if (ownActiveSubscription) {
      ownActiveSubscription.status = SubscriptionStatus.EXPIRED;
      await this.subscriptionRepo.save(ownActiveSubscription);
      await this.userRepo.update(userId, { paymentStatus: PaymentStatus.UNPAID });
    }

    await this.refreshTokenRepo.delete({ userId });
    await this.centerRepo.softDelete(center.id);

    user.accountStatus = AccountStatus.WITHDRAWAL;
    await this.userRepo.save(user);
    await this.userRepo.softDelete(userId);

    return { success: true };
  }

  private async withdrawTrainerMembers(
    trainerId: string,
    options: { recallMemberContent: boolean },
  ): Promise<string[]> {
    const affectedMemberIds: string[] = [];
    const activeTrainerUsers = await this.trainerUserRepo.find({
      where: { trainerId, status: TrainerUserStatus.ACTIVE },
    });

    for (const trainerUser of activeTrainerUsers) {
      await this.recallGrantedSubscriptionAndCapacity(trainerId, trainerUser.memberId);

      if (options.recallMemberContent) {
        await this.recallDistributedMemberData(trainerId, trainerUser.memberId);
      }

      trainerUser.status = TrainerUserStatus.HOLD;
      await this.trainerUserRepo.save(trainerUser);
      affectedMemberIds.push(trainerUser.memberId);
    }

    return affectedMemberIds;
  }

  /**
   * 트레이너가 회원에게 지급한 이용권·용량 회수
   */
  private async recallGrantedSubscriptionAndCapacity(trainerId: string, memberId: string): Promise<void> {
    const activeSubscription = await this.subscriptionRepo.findOne({
      where: { userId: memberId, status: SubscriptionStatus.ACTIVE },
      relations: ['plan'],
    });
    if (activeSubscription) {
      activeSubscription.status = SubscriptionStatus.EXPIRED;
      await this.subscriptionRepo.save(activeSubscription);
      await this.userRepo.update(memberId, { paymentStatus: PaymentStatus.UNPAID });
    }

    await this.capacityService.deallocateCapacity(trainerId, memberId, activeSubscription?.plan?.storageLimit);
  }

  /**
   * 트레이너가 회원에게 생성한 콘텐츠 소프트딜리트 (트레이너 본인 탈퇴 시)
   */
  private async recallDistributedMemberData(trainerId: string, memberId: string): Promise<void> {
    await Promise.all([
      this.bodyReportRepo.softDelete({ userId: memberId, trainerId }),
      this.motionAnalysisRepo.softDelete({ userId: memberId, trainerId }),
      this.precisionReportRepo.softDelete({ userId: memberId, trainerId }),
      this.workoutLogRepo.softDelete({ userId: memberId, trainerId }),
      this.consultationLogRepo.softDelete({ userId: memberId, trainerId }),
      this.inbodyDataRepo.softDelete({ userId: memberId, trainerId }),
      this.reportComparisonRepo.softDelete({ userId: memberId }),
    ]);
  }

  /**
   * 탈퇴하는 트레이너 본인의 운영 데이터 정리 (스케줄, QnA)
   */
  private async withdrawTrainerOwnResourceData(trainerId: string): Promise<void> {
    const schedules = await this.scheduleRepo.find({
      where: { trainerId },
      select: ['id'],
    });
    const scheduleIds = schedules.map((schedule) => schedule.id);
    if (scheduleIds.length > 0) {
      await this.scheduleBookingRepo.softDelete({ scheduleId: In(scheduleIds) });
      await this.scheduleRepo.softDelete({ trainerId });
    }

    await this.qnaService.deleteAllDataForAuthor(trainerId);
  }

  /**
   * 탈퇴 후 유예기간(90일)이 지난 계정을 물리적으로 완전 삭제합니다.
   * - 배치에서 호출할 함수만 구현한 상태이며, 실제 스케줄(cron) 등록은 별도 작업입니다.
   * - DB의 FK 제약(ON DELETE NO ACTION)이 걸린 테이블은 참조 관계상 하위 레벨부터
   *   순서대로 지워야 하므로, 아래 순서를 임의로 바꾸면 안 됩니다.
   * - 센터 오너(centers) 탈퇴는 연쇄 범위가 더 커서 이번 범위에서 제외했습니다.
   * - S3 등 외부 스토리지의 실파일 삭제는 포함하지 않습니다 (DB row만 정리).
   */
  @Transactional()
  async permanentlyDeleteWithdrawnUser(userId: string): Promise<void> {
    const user = await this.userRepo.findOne({ where: { id: userId }, withDeleted: true });
    if (!user) return;

    if (user.accountStatus !== AccountStatus.WITHDRAWAL || !user.deletedAt) {
      throw new BadRequestException('탈퇴 처리된 계정만 완전 삭제할 수 있습니다.');
    }

    const daysSinceWithdrawal = Math.floor(
      (Date.now() - user.deletedAt.getTime()) / (24 * 60 * 60 * 1000),
    );
    if (daysSinceWithdrawal < ACCOUNT_DELETION_GRACE_DAYS) {
      throw new BadRequestException(
        `탈퇴 후 ${ACCOUNT_DELETION_GRACE_DAYS}일이 지나야 완전 삭제할 수 있습니다. (경과: ${daysSinceWithdrawal}일)`,
      );
    }

    const del = (table: string, where: string, params: unknown[]): Promise<unknown> =>
      this.dataSource.query(`DELETE FROM ${table} WHERE ${where}`, params);

    // 레벨 3: 하위 레벨 테이블(motion_analyses/schedules/point_history/sequences)을 FK로 참조
    await del('workout_logs', 'user_id = ? OR trainer_id = ?', [userId, userId]);
    await del('schedule_bookings', 'user_id = ?', [userId]);
    await del('admin_point_logs', 'admin_id = ? OR target_user_id = ?', [userId, userId]);
    await del(
      'sequence_details',
      'sequence_id IN (SELECT id FROM sequences WHERE trainer_id = ?)',
      [userId],
    );

    // 레벨 2: sequences를 FK로 참조
    await del('motion_analyses', 'user_id = ? OR trainer_id = ?', [userId, userId]);
    await del('schedules', 'trainer_id = ?', [userId]);
    await del('point_history', 'user_id = ?', [userId]);

    // 레벨 1: users를 직접 FK로 참조 (DB 제약 있음, 위 레벨들이 먼저 지워져야 안전)
    await del('sequences', 'trainer_id = ?', [userId]);
    await del('body_reports', 'trainer_id = ? OR user_id = ?', [userId, userId]);
    await del('center_notices', 'author_id = ?', [userId]);
    await del('center_trainers', 'trainer_id = ?', [userId]);
    await del('inbody_data', 'user_id = ? OR trainer_id = ?', [userId, userId]);
    await del('member_identity_links', 'app_member_id = ? OR managed_member_id = ?', [userId, userId]);
    await del('member_storage', 'member_id = ?', [userId]);
    await del('precision_reports', 'user_id = ? OR trainer_id = ?', [userId, userId]);
    await del('storage_allocations', 'member_id = ?', [userId]);
    await del('storage_usages', 'uploader_id = ? OR member_id = ?', [userId, userId]);
    await del('subscriptions', 'user_id = ?', [userId]);
    await del('trainer_capacity_pool', 'trainer_id = ?', [userId]);
    await del('trainer_link_requests', 'member_id = ? OR trainer_id = ?', [userId, userId]);
    await del('trainer_users', 'trainer_id = ? OR member_id = ?', [userId, userId]);
    await del('user_agreements', 'user_id = ?', [userId]);
    await del('reports', 'reporter_user_id = ?', [userId]); // 레거시 테이블 (실사용은 qna_reports)

    // FK 제약은 없지만 코드상 user를 참조 — 데이터 정합성을 위해 함께 삭제
    await del('qna_answers', 'author_id = ?', [userId]);
    await del('qna_questions', 'author_id = ?', [userId]);
    await del('qna_reports', 'reporter_id = ?', [userId]);
    await del('food_logs', 'user_id = ? OR trainer_id = ?', [userId, userId]);
    await del('consultation_logs', 'trainer_id = ? OR user_id = ?', [userId, userId]);
    await del('files', 'owner_id = ? OR uploader_id = ? OR member_id = ?', [userId, userId, userId]);
    await del('payments', 'user_id = ?', [userId]);
    await del('bill_key_registrations', 'user_id = ?', [userId]);
    await del('bill_keys', 'user_id = ?', [userId]);
    await del('report_comparisons', 'user_id = ?', [userId]);
    await del('center_trainer_capacity_pools', 'trainer_id = ?', [userId]);
    await del('schedule_group_members', 'user_id = ?', [userId]);
    await del('schedule_groups', 'trainer_id = ?', [userId]);
    await del('sequence_groups', 'trainer_id = ?', [userId]);
    await del('center_trainer_invitations', 'trainer_id = ?', [userId]);
    await del(
      'member_transfer_histories',
      'member_id = ? OR from_trainer_id = ? OR to_trainer_id = ?',
      [userId, userId, userId],
    );

    // CASCADE 대상: users 삭제 시 DB가 자동 처리하지만, refresh_tokens는 레거시 컬럼
    // (user_id/userId)이 공존해 명시적으로 지워야 누락이 없음
    await del('refresh_tokens', 'user_id = ? OR userId = ?', [userId, userId]);
    await del('sns_accounts', 'user_id = ?', [userId]);

    // 마지막: users row 자체 물리 삭제
    await this.dataSource.query('DELETE FROM users WHERE id = ?', [userId]);
  }
}
