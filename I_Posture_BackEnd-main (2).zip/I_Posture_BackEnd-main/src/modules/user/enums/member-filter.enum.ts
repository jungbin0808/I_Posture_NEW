export enum MemberFilterType {
  ALL = 'ALL',
  UNPAID = 'UNPAID',
  PAID_UNLINKED = 'PAID_UNLINKED',
  PAID_LINKED = 'PAID_LINKED',
}

export enum MemberSortOrder {
  JOIN_DATE_ASC = 'JOIN_DATE_ASC',
  JOIN_DATE_DESC = 'JOIN_DATE_DESC',
  NAME_ASC = 'NAME_ASC',
  NAME_DESC = 'NAME_DESC',
}
