import { Body, Controller, Delete, Get, Param, Patch, Post, Put, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { UserService } from './user.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { FindMyMembersDto } from './dto/find-my-members.dto';
import { MyMembersResponseDto } from './dto/my-members-response.dto';
import { UserResponseDto } from './dto/user-response.dto';
import { UserDetailResponseDto } from './dto/user-detail-response.dto';
import { MyProfileResponseDto } from './dto/my-profile-response.dto';
import { RegisterMemberDto } from './dto/register-member.dto';
import { LinkMemberDto } from './dto/link-member.dto';
import { UpdateMemberStatusDto } from './dto/update-offline-payment.dto';
import { UpdateMyProfileDto } from './dto/update-my-profile.dto';
import { RegisterFcmTokenDto } from './dto/register-fcm-token.dto';
import { SubscriptionService } from '../subscription/subscription.service';
import { GrantSubscriptionDto } from '../subscription/dto/grant-subscription.dto';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';

@ApiTags('User')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('user')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly subscriptionService: SubscriptionService,
  ) {}

  @ApiOperation({ summary: 'Create Managed Member (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Post('managed')
  async createManagedMember(
    @Req() req: { user: UserEntity },
    @Body() createDto: CreateUserDto,
  ): Promise<ISuccessResponse<UserEntity>> {
    const user = await this.userService.createManagedMember(req.user.id, createDto);
    return SuccessResponse(user);
  }

  @ApiOperation({ summary: '회원 가입 (트레이너용 - 관리 회원 등록)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Post('register-member')
  async registerMember(
    @Req() req: { user: UserEntity },
    @Body() registerDto: RegisterMemberDto,
  ): Promise<ISuccessResponse<UserEntity>> {
    const user = await this.userService.registerMember(req.user.id, registerDto);
    return SuccessResponse(user);
  }

  @ApiOperation({ summary: 'Get My Members (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('my-members')
  async getMyMembers(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindMyMembersDto,
  ): Promise<ISuccessResponse<MyMembersResponseDto>> {
    const result = await this.userService.getMyMembers(req.user.id, findDto);
    return SuccessResponse<MyMembersResponseDto>(result);
  }

  @ApiOperation({ summary: 'Get My Profile' })
  @Get('me')
  async getMe(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<MyProfileResponseDto>> {
    const result = await this.userService.getMyProfile(req.user.id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'FCM 디바이스 토큰 등록/갱신' })
  @Patch('me/fcm-token')
  async registerFcmToken(
    @Req() req: { user: UserEntity },
    @Body() dto: RegisterFcmTokenDto,
  ): Promise<ISuccessResponse<null>> {
    await this.userService.registerFcmToken(req.user.id, dto.fcmToken);
    return SuccessResponse(null);
  }

  @ApiOperation({ summary: '내 정보 수정 (이름/휴대폰/비밀번호/소속센터명/알림설정)' })
  @Put('me')
  async updateMe(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateMyProfileDto,
  ): Promise<ISuccessResponse<null>> {
    await this.userService.updateMyProfile(req.user.id, dto);
    return SuccessResponse(null);
  }

  @ApiOperation({ summary: 'Get User Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center, Role.Admin)
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<UserDetailResponseDto>> {
    const result = await this.userService.findOne(id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Update User' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center, Role.Admin)
  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateDto: UpdateUserDto,
  ): Promise<ISuccessResponse<UserEntity>> {
    const user = await this.userService.update(id, updateDto);
    return SuccessResponse(user);
  }

  @ApiOperation({ summary: '회원 연동 (관리 회원 ↔ 앱 회원)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Post('my-members/:memberId/link')
  async linkMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() linkDto: LinkMemberDto,
  ): Promise<ISuccessResponse<{ success: boolean; message: string }>> {
    const result = await this.userService.linkMember(req.user.id, memberId, linkDto.email);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '회원 상태 변경 (미결제 / 결제+앱미연동 / 결제+앱연동)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Put('my-members/:memberId/status')
  async updateMemberStatus(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() dto: UpdateMemberStatusDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.userService.updateMemberStatus(req.user.id, memberId, dto.status, dto.email);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '특정 회원에게 이용권 지급 (등록)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Post(':memberId/subscription')
  async grantSubscription(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() grantDto: GrantSubscriptionDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const subscription = await this.subscriptionService.grantSubscription(req.user.id, memberId, grantDto);
    return SuccessResponse(subscription);
  }

  @ApiOperation({ summary: '회원 연동 해제 (관리 회원)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Delete('my-members/:memberId')
  async unlinkMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
  ): Promise<ISuccessResponse<{ success: boolean; message: string }>> {
    const result = await this.userService.unlinkMember(req.user.id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '관리 회원 계정 삭제 (트레이너/센터 전용)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Delete('my-members/:memberId/account')
  async deleteMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.userService.deleteMember(req.user.id, memberId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '회원 탈퇴 (일반회원/트레이너/센터 공용)' })
  @Roles(Role.Member, Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Delete('me/withdraw')
  async withdrawAccount(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.userService.withdrawAccount(req.user.id);
    return SuccessResponse(result);
  }
}
