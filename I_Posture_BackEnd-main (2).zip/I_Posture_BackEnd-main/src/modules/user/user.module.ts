import { Module, forwardRef } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../../database/entities/user.entity';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { MemberStorageEntity } from '../../database/entities/member-storage.entity';
import { StorageAllocationEntity } from '../../database/entities/storage-allocation.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { StorageUsageEntity } from '../../database/entities/storage-usage.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { TrainerLinkRequestEntity } from '../../database/entities/trainer-link-request.entity';
import { AuthModule } from '../auth/auth.module';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { PointHistoryEntity } from '../../database/entities/point-history.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { RefreshTokenEntity } from '../../database/entities/refresh-token.entity';
import { QnaQuestionEntity } from '../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../database/entities/qna-answer.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { WorkoutLogEntity } from '../../database/entities/workout-log.entity';
import { ConsultationLogEntity } from '../../database/entities/consultation-log.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { ReportComparisonEntity } from '../../database/entities/report-comparison.entity';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { ScheduleBookingEntity } from '../../database/entities/schedule-booking.entity';
import { QnaModule } from '../qna/qna.module';
import { SubscriptionModule } from '../subscription/subscription.module';
import { CapacityModule } from '../capacity/capacity.module';
import { FoodLogModule } from '../food-log/food-log.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserEntity,
      TrainerUserEntity,
      TrainerCapacityPoolEntity,
      MemberStorageEntity,
      StorageAllocationEntity,
      FileEntity,
      StorageUsageEntity,
      MemberIdentityLinkEntity,
      TrainerLinkRequestEntity,
      SubscriptionEntity,
      PointHistoryEntity,
      CenterTrainerEntity,
      CenterEntity,
      RefreshTokenEntity,
      QnaQuestionEntity,
      QnaAnswerEntity,
      BodyReportEntity,
      MotionAnalysisEntity,
      PrecisionReportEntity,
      WorkoutLogEntity,
      ConsultationLogEntity,
      InbodyDataEntity,
      ReportComparisonEntity,
      ScheduleEntity,
      ScheduleBookingEntity,
    ]),
    forwardRef(() => AuthModule),
    QnaModule,
    SubscriptionModule,
    CapacityModule,
    FoodLogModule,
  ],
  controllers: [UserController],
  providers: [UserService],
  exports: [UserService],
})
export class UserModule {}
