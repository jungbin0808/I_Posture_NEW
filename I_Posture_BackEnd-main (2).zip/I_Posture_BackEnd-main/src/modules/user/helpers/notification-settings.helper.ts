import { UserEntity } from '../../../database/entities/user.entity';

type NotificationSettingFields = Pick<
  UserEntity,
  | 'notificationEventMarketing'
  | 'notificationMyQuestion'
  | 'notificationChallengeResult'
  | 'notificationSubscriptionUsage'
  | 'notificationMyAnswerAccepted'
  | 'notificationPointSettlement'
  | 'notificationAll'
  | 'notificationBodyMeasurementCycle'
  | 'notificationWorkoutRoutine'
  | 'notificationChallengeParticipation'
  | 'notificationDietFeedback'
  | 'notificationTrainerReport'
  | 'notificationNotice'
>;

/** 회원가입 시 알림 설정 전체 ON */
export const ALL_NOTIFICATIONS_ON: NotificationSettingFields = {
  notificationEventMarketing: true,
  notificationMyQuestion: true,
  notificationChallengeResult: true,
  notificationSubscriptionUsage: true,
  notificationMyAnswerAccepted: true,
  notificationPointSettlement: true,
  notificationAll: true,
  notificationBodyMeasurementCycle: true,
  notificationWorkoutRoutine: true,
  notificationChallengeParticipation: true,
  notificationDietFeedback: true,
  notificationTrainerReport: true,
  notificationNotice: true,
};
