import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SequenceGroupEntity } from '../../database/entities/sequence-group.entity';
import { SequenceGroupController } from './sequence-group.controller';
import { SequenceGroupService } from './sequence-group.service';
import { SequenceEntity } from '../../database/entities/sequence.entity';
import { SequenceGroupMappingEntity } from '../../database/entities/sequence-group-mapping.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SequenceGroupEntity,
      SequenceEntity,
      SequenceGroupMappingEntity,
    ])
  ],
  controllers: [SequenceGroupController],
  providers: [SequenceGroupService],
  exports: [SequenceGroupService],
})
export class SequenceGroupModule {}
