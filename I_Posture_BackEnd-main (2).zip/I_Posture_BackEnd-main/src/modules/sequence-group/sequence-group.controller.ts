import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { SequenceGroupService } from './sequence-group.service';
import { AddSequencesToGroupDto, CreateSequenceGroupDto, DeleteSequenceGroupsDto, FindSequenceGroupsDto, RemoveSequencesFromGroupDto, UpdateSequenceGroupDto } from './sequence-group.dto';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { SuccessResponse } from '../../common/response/response.helper';

@Controller('sequence-groups')
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
export class SequenceGroupController {
  constructor(private readonly sequenceGroupService: SequenceGroupService) {}

  /**
   * @summary 시퀀스 그룹 생성
   */
  @Post()
  async create(@Request() req: any, @Body() dto: CreateSequenceGroupDto) {
    const data = await this.sequenceGroupService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 그룹 목록 조회
   */
  @Get()
  async findAll(@Request() req: any, @Query() dto: FindSequenceGroupsDto) {
    const pageData = await this.sequenceGroupService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 시퀀스 그룹 상세 조회
   */
  @Get(':id')
  async findOne(@Request() req: any, @Param('id') id: string) {
    const data = await this.sequenceGroupService.findOne(req.user.id, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 그룹 수정
   */
  @Put(':id')
  async update(@Request() req: any, @Param('id') id: string, @Body() dto: UpdateSequenceGroupDto) {
    const data = await this.sequenceGroupService.update(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 그룹에 시퀀스 추가 (다중 처리)
   */
  @Post(':id/sequences')
  async addSequencesToGroup(@Request() req: any, @Param('id') id: string, @Body() dto: AddSequencesToGroupDto) {
    const data = await this.sequenceGroupService.addSequencesToGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 그룹에서 시퀀스 삭제 (다중 처리)
   */
  @Delete(':id/sequences')
  async removeSequencesFromGroup(@Request() req: any, @Param('id') id: string, @Body() dto: RemoveSequencesFromGroupDto) {
    const data = await this.sequenceGroupService.removeSequencesFromGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 그룹 삭제 (다중 처리)
   */
  @Delete()
  async delete(@Request() req: any, @Body() dto: DeleteSequenceGroupsDto) {
    const data = await this.sequenceGroupService.delete(req.user.id, dto);
    return SuccessResponse(data);
  }
}
