import { IsArray, IsNotEmpty, IsOptional, IsString, Min } from "class-validator";
import { Type } from "class-transformer";

export class FindSequenceGroupsDto {
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page: number = 1;

  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit: number = 10;

  @IsOptional()
  @IsString()
  search?: string;
}

export class CreateSequenceGroupDto {
  @IsString()
  @IsNotEmpty()
  name!: string;
}

export class UpdateSequenceGroupDto {
  @IsString()
  @IsNotEmpty()
  name!: string;
}

export class DeleteSequenceGroupsDto {
  @IsArray()
  @IsString({ each: true })
  @IsNotEmpty({ each: true })
  ids!: string[];
}

export class AddSequencesToGroupDto {
  @IsArray()
  @IsString({ each: true })
  @IsNotEmpty({ each: true })
  sequenceIds!: string[];
}

export class RemoveSequencesFromGroupDto {
  @IsArray()
  @IsString({ each: true })
  @IsNotEmpty({ each: true })
  sequenceIds!: string[];
}

