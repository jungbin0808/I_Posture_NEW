import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource, In } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { SequenceGroupEntity } from '../../database/entities/sequence-group.entity';
import { AddSequencesToGroupDto, CreateSequenceGroupDto, DeleteSequenceGroupsDto, FindSequenceGroupsDto, RemoveSequencesFromGroupDto, UpdateSequenceGroupDto } from './sequence-group.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { SequenceEntity } from '../../database/entities/sequence.entity';
import { SequenceGroupMappingEntity } from '../../database/entities/sequence-group-mapping.entity';

@Injectable()
export class SequenceGroupService {
  constructor(
    @InjectRepository(SequenceGroupEntity)
    private readonly groupRepo: Repository<SequenceGroupEntity>,
    @InjectRepository(SequenceEntity)
    private readonly sequenceRepo: Repository<SequenceEntity>,
    @InjectRepository(SequenceGroupMappingEntity)
    private readonly mappingRepo: Repository<SequenceGroupMappingEntity>,
    private readonly dataSource: DataSource,
  ) {}

  @Transactional()
  async create(trainerId: string, dto: CreateSequenceGroupDto) {
    const group = this.groupRepo.create({
      trainerId,
      name: dto.name,
    });
    return this.groupRepo.save(group);
  }

  async findAll(trainerId: string, dto: FindSequenceGroupsDto): Promise<IPageData<SequenceGroupEntity>> {
    const query = this.groupRepo.createQueryBuilder('group')
      .where('group.trainerId = :trainerId', { trainerId });

    if (dto.search) {
      query.andWhere('group.name LIKE :search', { search: `%${dto.search}%` });
    }

    query.orderBy('group.createdAt', 'DESC');

    const page = dto.page || 1;
    const limit = dto.limit || 10;
    const skip = (page - 1) * limit;

    const [items, total] = await query.skip(skip).take(limit).getManyAndCount();

    return {
      items,
      paging: buildPaging(total, limit, page),
    };
  }

  async findOne(trainerId: string, id: string) {
    const group = await this.groupRepo.findOne({ where: { id } });

    if (!group) throw new NotFoundException('Sequence Group not found');
    if (group.trainerId !== trainerId) throw new ForbiddenException('Access denied');

    return group;
  }

  @Transactional()
  async update(trainerId: string, id: string, dto: UpdateSequenceGroupDto) {
    const group = await this.groupRepo.findOne({ where: { id } });
    if (!group) throw new NotFoundException('Sequence Group not found');
    if (group.trainerId !== trainerId) throw new ForbiddenException('Access denied');

    group.name = dto.name;
    return this.groupRepo.save(group);
  }

  @Transactional()
  async delete(trainerId: string, dto: DeleteSequenceGroupsDto) {
    // 권한 확인 및 존재 여부 확인
    const groups = await this.groupRepo.find({
      where: { id: In(dto.ids), trainerId },
    });

    if (groups.length !== dto.ids.length) {
      throw new ForbiddenException('Some groups not found or access denied');
    }

    // 1. 매핑 테이블에서 관련 레코드 삭제 (Hard Delete)
    await this.mappingRepo.delete({ sequenceGroupId: In(dto.ids) });

    // 2. 그룹 삭제 (Soft Delete)
    const result = await this.groupRepo.softDelete(dto.ids);
    return { success: true, affected: result.affected };
  }

  @Transactional()
  async addSequencesToGroup(trainerId: string, groupId: string, dto: AddSequencesToGroupDto) {
    // 1. 그룹 존재 및 권한 확인
    const group = await this.groupRepo.findOne({ where: { id: groupId } });
    if (!group) throw new NotFoundException('Sequence Group not found');
    if (group.trainerId !== trainerId) throw new ForbiddenException('Access denied');

    // 2. 시퀀스 존재 및 권한 확인
    const sequences = await this.sequenceRepo.find({
      where: { id: In(dto.sequenceIds), trainerId },
    });
    if (sequences.length !== dto.sequenceIds.length) {
      throw new ForbiddenException('Some sequences not found or access denied');
    }

    // 3. 이미 그룹에 포함된 시퀀스 확인 (중복 방지)
    const existingMappings = await this.mappingRepo.find({
      where: {
        sequenceGroupId: groupId,
        sequenceId: In(dto.sequenceIds),
      },
    });
    const existingSequenceIds = new Set(existingMappings.map(m => m.sequenceId));

    // 4. 새로운 매핑 생성
    const newMappings = dto.sequenceIds
      .filter(seqId => !existingSequenceIds.has(seqId))
      .map(seqId => 
        this.mappingRepo.create({
          sequenceGroupId: groupId,
          sequenceId: seqId,
        })
      );

    if (newMappings.length > 0) {
      await this.mappingRepo.save(newMappings);
    }

    return { success: true, addedCount: newMappings.length };
  }

  @Transactional()
  async removeSequencesFromGroup(trainerId: string, groupId: string, dto: RemoveSequencesFromGroupDto) {
    // 1. 그룹 존재 및 권한 확인
    const group = await this.groupRepo.findOne({ where: { id: groupId } });
    if (!group) throw new NotFoundException('Sequence Group not found');
    if (group.trainerId !== trainerId) throw new ForbiddenException('Access denied');

    // 2. 해당 그룹에 속한 매핑만 삭제 (권한 체크 포함)
    const result = await this.mappingRepo.delete({
      sequenceGroupId: groupId,
      sequenceId: In(dto.sequenceIds),
    });

    return { success: true, removedCount: result.affected || 0 };
  }
}
