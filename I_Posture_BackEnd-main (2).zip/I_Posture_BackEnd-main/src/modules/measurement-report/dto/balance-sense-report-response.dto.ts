import { ApiProperty } from '@nestjs/swagger';
import { ReportCenterBrandingDto } from './report-center-branding.dto';

class BalanceMemberDto {
  @ApiProperty() name!: string;
  @ApiProperty() gender!: string;
  @ApiProperty() birthDate!: string;
  @ApiProperty() age!: number;
  @ApiProperty() measurementDate!: string;
}

class BalanceLevelGuideItemDto {
  @ApiProperty() label!: string;
  @ApiProperty() color!: string;
}

class BalanceTotalScoreDto {
  @ApiProperty() scoreText!: string;
  @ApiProperty() score!: number;
  @ApiProperty() scoreMax!: number;
  @ApiProperty() stage!: string;
  @ApiProperty({ type: [BalanceLevelGuideItemDto] }) levelGuide!: BalanceLevelGuideItemDto[];
  @ApiProperty() summaryTitle!: string;
  @ApiProperty() meaning!: string;
  @ApiProperty() balanceControlFeature!: string;
  @ApiProperty() dailyLifeConnection!: string;
  @ApiProperty() bottomMessage!: string;
}

class BalanceChartDatasetDto {
  @ApiProperty() label!: string;
  @ApiProperty({ type: [Number] }) values!: number[];
  @ApiProperty() color!: string;
}

class BalancePatternChartDto {
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
  @ApiProperty({ type: [String] }) labels!: string[];
  @ApiProperty({ type: [BalanceChartDatasetDto] }) datasets!: BalanceChartDatasetDto[];
}

class BalancePatternTypeAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty() chart!: BalancePatternChartDto;
  @ApiProperty() typeName!: string;
  @ApiProperty({ required: false }) subTypes?: string;
  @ApiProperty() typeDescription!: string;
  @ApiProperty() causeTitle!: string;
  @ApiProperty() causeDescription!: string;
}

class BalanceImageDto {
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
}

class BalanceFrontPanelDto {
  @ApiProperty() title!: string;
  @ApiProperty() normalImage!: BalanceImageDto;
  @ApiProperty() currentImage!: BalanceImageDto;
}

class BalanceObservationPointsDto {
  @ApiProperty() rightLegRaise!: string;
  @ApiProperty() leftLegRaise!: string;
}

class BalancePatternAnalysisDto {
  @ApiProperty() rightLegRaise!: string;
  @ApiProperty() leftLegRaise!: string;
}

class BalanceAnalysisCardDto {
  @ApiProperty() title!: string;
  @ApiProperty() observationPoints!: BalanceObservationPointsDto;
  @ApiProperty() patternAnalysis!: BalancePatternAnalysisDto;
}

class BalanceFrontViewAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [BalanceFrontPanelDto] }) panels!: BalanceFrontPanelDto[];
  @ApiProperty({ type: [BalanceAnalysisCardDto] }) analysisCards!: BalanceAnalysisCardDto[];
}

class BalanceSideCardDto {
  @ApiProperty() title!: string;
  @ApiProperty() observationPoint!: string;
  @ApiProperty() patternAnalysis!: string;
}

class BalanceSideImagesDto {
  @ApiProperty() normalImage!: BalanceImageDto;
  @ApiProperty() currentImage!: BalanceImageDto;
}

class BalanceSideAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty() target!: string;
  @ApiProperty() images!: BalanceSideImagesDto;
  @ApiProperty({ type: [BalanceSideCardDto] }) cards!: BalanceSideCardDto[];
}

class BalanceDailyActivityDto {
  @ApiProperty() activity!: string;
  @ApiProperty() image!: BalanceImageDto;
  @ApiProperty() currentPattern!: string;
  @ApiProperty() correctionGuide!: string;
}

class BalanceDailyItemDto {
  @ApiProperty() title!: string;
  @ApiProperty() observationPoint!: string;
  @ApiProperty() image!: BalanceImageDto;
  @ApiProperty({ type: [BalanceDailyActivityDto] }) currentPattern!: BalanceDailyActivityDto[];
}

class BalanceDailyPatternsDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [BalanceDailyItemDto] }) items!: BalanceDailyItemDto[];
}

class BalanceExerciseDto {
  @ApiProperty() name!: string;
  @ApiProperty() assetKey!: string;
}

class BalanceTrainingLevelDto {
  @ApiProperty() level!: number;
  @ApiProperty({ required: false }) recommended?: boolean;
  @ApiProperty({ required: false }) challenge?: boolean;
  @ApiProperty() levelDescription!: string;
  @ApiProperty({ type: [BalanceExerciseDto] }) exercises!: BalanceExerciseDto[];
}

class BalanceFunctionalTrainingGoalsDto {
  @ApiProperty() title!: string;
  @ApiProperty() currentLevel!: number;
  @ApiProperty() currentLevelLabel!: string;
  @ApiProperty() challengeLevelLabel!: string;
  @ApiProperty({ type: [BalanceTrainingLevelDto] }) levels!: BalanceTrainingLevelDto[];
}

class BalanceDetailedExerciseDto {
  @ApiProperty() name!: string;
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
}

class BalanceTrainingDetailDto {
  @ApiProperty() title!: string;
  @ApiProperty() level!: number;
  @ApiProperty() levelText!: string;
  @ApiProperty() levelDescription!: string;
  @ApiProperty() overview!: string;
  @ApiProperty() exercise!: BalanceDetailedExerciseDto;
  @ApiProperty() goal!: string;
  @ApiProperty({ type: [String] }) method!: string[];
  @ApiProperty({ type: [String] }) checkPoints!: string[];
  @ApiProperty() stimulus!: string;
}

export class BalanceSenseReportResponseDto extends ReportCenterBrandingDto {
  @ApiProperty() reportType!: string;
  @ApiProperty() reportTitle!: string;
  @ApiProperty() reportSubTitle!: string;
  @ApiProperty() issuedAt!: string;
  @ApiProperty({ description: '측정일시 (YYYY-MM-DD HH:mm:ss.SSS)' }) createdAt!: string;
  @ApiProperty() member!: BalanceMemberDto;
  @ApiProperty() introNotice!: string;
  @ApiProperty() totalScore!: BalanceTotalScoreDto;
  @ApiProperty() patternTypeAnalysis!: BalancePatternTypeAnalysisDto;
  @ApiProperty() frontViewAnalysis!: BalanceFrontViewAnalysisDto;
  @ApiProperty() rightSideAnalysis!: BalanceSideAnalysisDto;
  @ApiProperty() leftSideAnalysis!: BalanceSideAnalysisDto;
  @ApiProperty() dailyBalancePatterns!: BalanceDailyPatternsDto;
  @ApiProperty() functionalBalanceTrainingGoals!: BalanceFunctionalTrainingGoalsDto;
  @ApiProperty() recommendedTrainingDetail!: BalanceTrainingDetailDto;
  @ApiProperty() challengeTrainingDetail!: BalanceTrainingDetailDto;
  @ApiProperty({ type: [String] }) disclaimer!: string[];
  @ApiProperty({ description: '첨부 파일 목록', required: false }) files?: any[];
  @ApiProperty({ description: '랜드마크 데이터 (JSON)', required: false }) landmarks?: any;
  @ApiProperty({ description: '미리보기 이미지 너비', required: false }) previewWidth?: number | null;
  @ApiProperty({ description: '미리보기 이미지 높이', required: false }) previewHeight?: number | null;
}
