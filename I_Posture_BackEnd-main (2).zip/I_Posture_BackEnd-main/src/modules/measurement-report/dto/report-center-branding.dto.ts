import { ApiProperty } from '@nestjs/swagger';

export class ReportCenterBrandingDto {
  @ApiProperty({ description: '센터 로고 URL', nullable: true, required: false })
  centerLogoUrl?: string | null;
}
