import { ApiProperty } from '@nestjs/swagger';
import { ReportCenterBrandingDto } from './report-center-branding.dto';

class FbfMemberDto {
  @ApiProperty() name!: string;
  @ApiProperty() gender!: string;
  @ApiProperty() birthDate!: string;
  @ApiProperty() measurementDate!: string;
}

class FbfScaleItemDto {
  @ApiProperty() label!: string;
  @ApiProperty() color!: string;
}

class FbfSummaryBoxDto {
  @ApiProperty() title!: string;
  @ApiProperty() content!: string;
}

class FbfExercisePerformanceIndexDto {
  @ApiProperty() title!: string;
  @ApiProperty() stage!: string;
  @ApiProperty() scoreRangeLabel!: string;
  @ApiProperty({ type: [FbfScaleItemDto] }) scale!: FbfScaleItemDto[];
  @ApiProperty() summary!: FbfSummaryBoxDto;
  @ApiProperty() strategy!: FbfSummaryBoxDto;
}

class FbfMovementBiomechanicsSummaryDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [String] }) paragraphs!: string[];
  @ApiProperty() bottomBox!: string;
}

class FbfLinkedScenarioStepDto {
  @ApiProperty() order!: number;
  @ApiProperty() title!: string;
  @ApiProperty() themeColor!: string;
  @ApiProperty() content!: string;
}

class FbfLinkedScenarioDto {
  @ApiProperty() title!: string;
  @ApiProperty() description!: string;
  @ApiProperty({ type: [FbfLinkedScenarioStepDto] }) steps!: FbfLinkedScenarioStepDto[];
}

class FbfMuscleViewDto {
  @ApiProperty() view!: string;
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
}

class FbfMuscleGroupDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [String] }) items!: string[];
}

class FbfMuscleBalanceDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [FbfMuscleViewDto] }) views!: FbfMuscleViewDto[];
  @ApiProperty() overactiveMuscles!: FbfMuscleGroupDto;
  @ApiProperty() underactiveMuscles!: FbfMuscleGroupDto;
}

class FbfExerciseCaseStrategyDto {
  @ApiProperty({ type: [String] }) movementAnalysis!: string[];
  @ApiProperty({ type: [String] }) recommendedMethod!: string[];
}

class FbfExerciseCaseItemDto {
  @ApiProperty() exerciseName!: string;
  @ApiProperty() assetKey!: string;
  @ApiProperty() strategy!: FbfExerciseCaseStrategyDto;
}

class FbfExerciseCasesDto {
  @ApiProperty() title!: string;
  @ApiProperty() description!: string;
  @ApiProperty({ type: [FbfExerciseCaseItemDto] }) items!: FbfExerciseCaseItemDto[];
}

class FbfSideTopImageDto {
  @ApiProperty() label!: string;
  @ApiProperty() photoAssetKey!: string;
  @ApiProperty() skeletonAssetKey!: string;
}

class FbfSideTopImagesDto {
  @ApiProperty() left!: FbfSideTopImageDto;
  @ApiProperty() right!: FbfSideTopImageDto;
}

class FbfPatternSectionDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [String] }) stateAnalysis!: string[];
  @ApiProperty({ type: [String] }) movementPatternAnalysis!: string[];
  @ApiProperty({ type: [String], required: false }) optimizationStrategy?: string[];
}

class FbfSidePatternAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty() topImages!: FbfSideTopImagesDto;
  @ApiProperty({ type: [FbfPatternSectionDto] }) sections!: FbfPatternSectionDto[];
}

class FbfImageDto {
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
}

class FbfRearFrontImagesDto {
  @ApiProperty() photo!: FbfImageDto;
  @ApiProperty() analysisImage!: FbfImageDto;
}

class FbfKeyMetricDto {
  @ApiProperty() label!: string;
  @ApiProperty() value!: string;
}

class FbfRearPatternAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty() images!: FbfRearFrontImagesDto;
  @ApiProperty({ type: [FbfKeyMetricDto] }) keyMetrics!: FbfKeyMetricDto[];
  @ApiProperty({ type: [String] }) analysis!: string[];
}

class FbfCenterLineDto {
  @ApiProperty() bodyCenterLineLabel!: string;
  @ApiProperty() observation!: string;
}

class FbfFrontPatternSectionDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [String] }) stateAnalysis!: string[];
  @ApiProperty({ type: [String] }) movementPatternAnalysis!: string[];
}

class FbfFrontPatternAnalysisDto {
  @ApiProperty() title!: string;
  @ApiProperty() images!: FbfRearFrontImagesDto;
  @ApiProperty() centerLine!: FbfCenterLineDto;
  @ApiProperty({ type: [FbfFrontPatternSectionDto] }) sections!: FbfFrontPatternSectionDto[];
}

export class FullBodyFunctionReportResponseDto extends ReportCenterBrandingDto {
  @ApiProperty() reportType!: string;
  @ApiProperty() reportTitle!: string;
  @ApiProperty() issuedAt!: string;
  @ApiProperty({ description: '측정일시 (YYYY-MM-DD HH:mm:ss.SSS)' }) createdAt!: string;
  @ApiProperty() member!: FbfMemberDto;
  @ApiProperty() exercisePerformanceIndex!: FbfExercisePerformanceIndexDto;
  @ApiProperty() movementBiomechanicsSummary!: FbfMovementBiomechanicsSummaryDto;
  @ApiProperty() linkedScenario!: FbfLinkedScenarioDto;
  @ApiProperty() muscleBalance!: FbfMuscleBalanceDto;
  @ApiProperty() exerciseCases!: FbfExerciseCasesDto;
  @ApiProperty() sidePatternAnalysis!: FbfSidePatternAnalysisDto;
  @ApiProperty() rearPatternAnalysis!: FbfRearPatternAnalysisDto;
  @ApiProperty() frontPatternAnalysis!: FbfFrontPatternAnalysisDto;
  @ApiProperty({ type: [String] }) disclaimer!: string[];
  @ApiProperty({ description: '첨부 파일 목록', required: false }) files?: any[];
  @ApiProperty({ description: '랜드마크 데이터 (JSON)', required: false }) landmarks?: any;
  @ApiProperty({ description: '미리보기 이미지 너비', required: false }) previewWidth?: number | null;
  @ApiProperty({ description: '미리보기 이미지 높이', required: false }) previewHeight?: number | null;
}
