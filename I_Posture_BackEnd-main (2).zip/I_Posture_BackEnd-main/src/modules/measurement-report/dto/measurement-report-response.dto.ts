import { ApiProperty } from '@nestjs/swagger';
import { ReportCenterBrandingDto } from './report-center-branding.dto';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '관련 타입' })
  relatedType?: string;

  @ApiProperty({ description: '구분', nullable: true })
  division?: string;
}

// 체형측정 리포트 전체 구조 응답 (제공하신 JSON 구조 그대로)
export class BodyMeasurementReportResponseDto extends ReportCenterBrandingDto {
  @ApiProperty({ description: '리포트 제목' })
  reportTitle!: string;

  @ApiProperty({ description: '발행일' })
  issuedAt!: string;

  @ApiProperty({ description: '측정일시 (YYYY-MM-DD HH:mm:ss.SSS)' })
  createdAt!: string;

  @ApiProperty({ description: '회원 정보' })
  member!: any;

  @ApiProperty({ description: '종합 체형 점수' })
  totalScore!: any;

  @ApiProperty({ description: '주요 체형' })
  majorPostures!: any;

  @ApiProperty({ description: '사진 분석' })
  photoAnalysis!: any;

  @ApiProperty({ description: '체형 상세 분석' })
  postureDetails!: any[];

  @ApiProperty({ description: '권장 생활 습관' })
  recommendedHabits!: any;

  @ApiProperty({ description: '종합 요약' })
  summary!: any;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto], required: false })
  files?: FileDto[];

  @ApiProperty({ description: '랜드마크 데이터 (JSON)', required: false })
  landmarks?: any;

  @ApiProperty({ description: '촬영 미리보기 너비', nullable: true })
  previewWidth?: number | null;

  @ApiProperty({ description: '촬영 미리보기 높이', nullable: true })
  previewHeight?: number | null;

  @ApiProperty({ description: '분석 상세 점수 데이터 (scoreDetail)', required: false })
  scoreDetail?: any;
}

