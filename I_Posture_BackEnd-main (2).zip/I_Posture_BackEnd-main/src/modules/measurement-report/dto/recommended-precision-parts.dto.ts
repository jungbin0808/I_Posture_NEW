import { ApiProperty } from '@nestjs/swagger';

class RecommendedPartDto {
  @ApiProperty({ description: '부위 유형 (NECK, SHOULDER, HIP 등)' })
  type!: string;

  @ApiProperty({ description: '부위명 (목, 어깨, 골반/허리 등)' })
  label!: string;

  @ApiProperty({ description: '점수 (낮을수록 안 좋음)' })
  score!: number;

  @ApiProperty({ description: '순위 (1위가 가장 안 좋음)' })
  rank!: number;

  @ApiProperty({ description: '추천 사유' })
  reason!: string;

  @ApiProperty({ description: '연결된 정밀측정 타입 목록', type: [String], example: ['TORSO', 'HIP'] })
  measurementTypes!: string[];
}

export class RecommendedPrecisionPartsResponseDto {
  @ApiProperty({ description: '추천 부위 목록 (2개, 점수 낮은 순)', type: [RecommendedPartDto] })
  recommendedParts!: RecommendedPartDto[];

  @ApiProperty({ description: '추천 정밀측정 타입 flat 배열 (중복 제거, 최대 3개)', type: [String], example: ['NECK', 'TORSO', 'HIP'] })
  recommendedMeasurementTypes!: string[];

  @ApiProperty({ description: '기준이 된 체형리포트 ID' })
  baseReportId!: string;

  @ApiProperty({ description: '기준이 된 체형리포트 측정일' })
  baseReportDate!: string;
}

