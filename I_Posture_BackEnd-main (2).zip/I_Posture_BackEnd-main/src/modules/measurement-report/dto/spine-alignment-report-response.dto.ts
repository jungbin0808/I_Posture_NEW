import { ApiProperty } from '@nestjs/swagger';
import { ReportCenterBrandingDto } from './report-center-branding.dto';

class SpineAlignmentMemberDto {
  @ApiProperty({ description: '이름' })
  name!: string;

  @ApiProperty({ description: '성별' })
  gender!: string;

  @ApiProperty({ description: '생년월일' })
  birthDate!: string;

  @ApiProperty({ description: '측정일' })
  measurementDate!: string;
}

class SpineAlignmentImageDto {
  @ApiProperty({ description: '에셋 키' })
  assetKey!: string;

  @ApiProperty({ description: '이미지 URL', nullable: true })
  url!: string | null;
}

class SpineAlignmentImagesDto {
  @ApiProperty()
  photo!: SpineAlignmentImageDto;

  @ApiProperty()
  illustration!: SpineAlignmentImageDto;
}

class SpineAlignmentMetricDto {
  @ApiProperty({ description: '항목 라벨' })
  label!: string;

  @ApiProperty({ description: '측정값' })
  value!: string;
}

class SpineAlignmentTooltipPointDto {
  @ApiProperty({ description: '부위명' })
  part!: string;

  @ApiProperty({ description: '좌측 값' })
  left!: number;

  @ApiProperty({ description: '우측 값' })
  right!: number;
}

class SpineAlignmentTooltipsDto {
  @ApiProperty({ description: '가이드 텍스트' })
  guide!: string;

  @ApiProperty({ type: [SpineAlignmentTooltipPointDto] })
  points!: SpineAlignmentTooltipPointDto[];
}

class SpineAlignmentObservationSummaryDto {
  @ApiProperty()
  images!: SpineAlignmentImagesDto;

  @ApiProperty({ type: [SpineAlignmentMetricDto] })
  metrics!: SpineAlignmentMetricDto[];

  @ApiProperty({ type: SpineAlignmentTooltipsDto })
  tooltips!: SpineAlignmentTooltipsDto;

  @ApiProperty({ description: '분석 내용' })
  analysis!: string;

  @ApiProperty({ description: '결과 요약' })
  result!: string;
}

class SpineAlignmentFlowSummaryDto {
  @ApiProperty({ description: '패턴 요약' })
  patternSummary!: string;

  @ApiProperty({ description: '패턴 설명' })
  pattern!: string;

  @ApiProperty({ description: '일상 움직임 영향' })
  dailyMovementImpact!: string;

  @ApiProperty({ description: '트레이닝 방향' })
  trainingDirection!: string;

  @ApiProperty({ description: '향후 계획' })
  futurePlan!: string;

  @ApiProperty({ description: '결과' })
  result!: string;

  @ApiProperty({ description: '솔루션 버튼 텍스트' })
  solutionButton!: string;
}

class SpineTrainingGuideDto {
  @ApiProperty({ description: '카테고리' })
  category!: string;

  @ApiProperty({ description: '테마 색상' })
  themeColor!: string;

  @ApiProperty({ description: '방향성' })
  direction!: string;

  @ApiProperty({ description: '접근 방법 목록', type: [String] })
  approaches!: string[];
}

class SpineTrainingGuidesDto {
  @ApiProperty({ type: [SpineTrainingGuideDto] })
  guides!: SpineTrainingGuideDto[];

  @ApiProperty({ description: '하단 안내 문구' })
  footerNote!: string;
}

class SpineCoreStructureBlockDto {
  @ApiProperty()
  title!: string;

  @ApiProperty()
  description!: string;

  @ApiProperty()
  assetKey!: string;

  @ApiProperty({ nullable: true })
  url!: string | null;
}

class SpineCoreStructureDto {
  @ApiProperty({ description: '핵심 구조 설명' })
  description!: string;

  @ApiProperty({ type: [SpineCoreStructureBlockDto] })
  blocks!: SpineCoreStructureBlockDto[];

  @ApiProperty({ description: '하단 안내 문구' })
  footer!: string;

  @ApiProperty({ description: '관찰 코멘트 (전굴 측정 결과 문장)', required: false })
  comment?: string;

  @ApiProperty({ description: '관찰 이미지 변형 코드 1-9 (전굴 이미지 선택)', required: false })
  observationVariant?: number;
}

class SpineBodyChangeSectionDto {
  @ApiProperty()
  order!: number;

  @ApiProperty()
  title!: string;

  @ApiProperty()
  image!: { assetKey: string };

  @ApiProperty()
  summary!: string;

  @ApiProperty({ type: [String] })
  dailyPatterns!: string[];

  @ApiProperty({ type: [String] })
  bodyStress!: string[];

  @ApiProperty({ type: [String] })
  appearanceImpact!: string[];
}

class SpineBodyChangeInsightsDto {
  @ApiProperty()
  intro!: string;

  @ApiProperty({ type: [SpineBodyChangeSectionDto] })
  sections!: SpineBodyChangeSectionDto[];
}

export class SpineAlignmentReportResponseDto extends ReportCenterBrandingDto {
  @ApiProperty()
  member!: SpineAlignmentMemberDto;

  @ApiProperty({ description: 'KST 측정날짜 (YYYY-MM-DD)' })
  createdAt!: string;

  @ApiProperty({ description: '주의사항 안내문' })
  notice!: string;

  @ApiProperty()
  observationSummary!: SpineAlignmentObservationSummaryDto;

  @ApiProperty()
  alignmentFlowSummary!: SpineAlignmentFlowSummaryDto;

  @ApiProperty()
  trainingGuides!: SpineTrainingGuidesDto;

  @ApiProperty()
  coreStructure!: SpineCoreStructureDto;

  @ApiProperty()
  bodyChangeInsights!: SpineBodyChangeInsightsDto;

  @ApiProperty({ type: [String] })
  disclaimer!: string[];

  @ApiProperty({ description: '첨부 파일 목록', required: false })
  files?: any[];

  @ApiProperty({ description: '랜드마크 데이터 (JSON)', required: false })
  landmarks?: any;

  @ApiProperty({ description: '미리보기 이미지 가로 픽셀', nullable: true })
  previewWidth?: number | null;

  @ApiProperty({ description: '미리보기 이미지 세로 픽셀', nullable: true })
  previewHeight?: number | null;
}
