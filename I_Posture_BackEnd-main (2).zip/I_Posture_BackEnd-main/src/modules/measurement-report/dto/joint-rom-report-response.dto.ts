import { ApiProperty } from '@nestjs/swagger';
import { ReportCenterBrandingDto } from './report-center-branding.dto';

class RomMemberDto {
  @ApiProperty() name!: string;
  @ApiProperty() gender!: string;
  @ApiProperty() birthDate!: string;
  @ApiProperty() measurementDate!: string;
}

class RomImageDto {
  @ApiProperty() assetKey!: string;
  @ApiProperty({ nullable: true }) url!: string | null;
}

class RomMetricDto {
  @ApiProperty() label!: string;
  @ApiProperty() value!: string;
}

class RomRiskStageDto {
  @ApiProperty() label!: string;
  @ApiProperty() color!: string;
}

class RomRiskBarDto {
  @ApiProperty() currentStage!: string;
  @ApiProperty({ type: [RomRiskStageDto] }) stages!: RomRiskStageDto[];
}

class RomSummaryImagesDto {
  @ApiProperty() measurementPhoto!: RomImageDto;
  @ApiProperty() skeletonGuide!: RomImageDto;
}

class RomSummaryDto {
  @ApiProperty() title!: string;
  @ApiProperty() partTitle!: string;
  @ApiProperty() inspectionPart!: string;
  @ApiProperty() images!: RomSummaryImagesDto;
  @ApiProperty({ type: [RomMetricDto] }) metrics!: RomMetricDto[];
  @ApiProperty() riskBar!: RomRiskBarDto;
  @ApiProperty() analysis!: string;
}

class RomCompensationItemDto {
  @ApiProperty() title!: string;
  @ApiProperty() themeColor!: string;
  @ApiProperty() image!: RomImageDto;
}

class RomCompensationMotionDto {
  @ApiProperty() title!: string;
  @ApiProperty() description!: string;
  @ApiProperty({ type: [RomCompensationItemDto] }) items!: RomCompensationItemDto[];
}

class RomDailyUseItemDto {
  @ApiProperty() title!: string;
  @ApiProperty() themeColor!: string;
}

class RomDailyUseExamplesDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [RomDailyUseItemDto] }) items!: RomDailyUseItemDto[];
}

class RomRelatedConditionItemDto {
  @ApiProperty() title!: string;
  @ApiProperty() themeColor!: string;
  @ApiProperty() iconKey!: string;
}

class RomRelatedConditionDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [RomRelatedConditionItemDto] }) items!: RomRelatedConditionItemDto[];
}

class RomMovementDetailDto {
  @ApiProperty() title!: string;
  @ApiProperty() compensationMotionWhenRestricted!: RomCompensationMotionDto;
  @ApiProperty() dailyUseExamples!: RomDailyUseExamplesDto;
  @ApiProperty() relatedCondition!: RomRelatedConditionDto;
}

class RomCauseItemDto {
  @ApiProperty() title!: string;
  @ApiProperty() image!: RomImageDto;
}

class RomMainCausesDto {
  @ApiProperty() title!: string;
  @ApiProperty() subTitle!: string;
  @ApiProperty() rightCaption!: string;
  @ApiProperty({ type: [RomCauseItemDto] }) items!: RomCauseItemDto[];
}

class RomFutureProgramDirectionDto {
  @ApiProperty() title!: string;
  @ApiProperty() content!: string;
}

class RomImprovementGoalDto {
  @ApiProperty() title!: string;
  @ApiProperty() content!: string;
}

class RomCommentSectionDto {
  @ApiProperty() title!: string;
  @ApiProperty() comment!: string;
  @ApiProperty() futureProgramDirection!: RomFutureProgramDirectionDto;
  @ApiProperty() improvementGoal!: RomImprovementGoalDto;
}

class RomRoutineItemDto {
  @ApiProperty() order!: number;
  @ApiProperty() name!: string;
  @ApiProperty() image!: RomImageDto;
}

class RomRecommendedDailyRoutineDto {
  @ApiProperty() title!: string;
  @ApiProperty({ type: [RomRoutineItemDto] }) items!: RomRoutineItemDto[];
}

class RomExpectedEffectDto {
  @ApiProperty() title!: string;
  @ApiProperty() content!: string;
}

class RomActionButtonDto {
  @ApiProperty() label!: string;
}

export class JointRomReportResponseDto extends ReportCenterBrandingDto {
  @ApiProperty() reportType!: string;
  @ApiProperty() reportTitle!: string;
  @ApiProperty() issuedAt!: string;
  @ApiProperty({ description: '측정일시 (YYYY-MM-DD HH:mm:ss.SSS)' }) createdAt!: string;
  @ApiProperty() member!: RomMemberDto;
  @ApiProperty() summary!: RomSummaryDto;
  @ApiProperty() movementDetail!: RomMovementDetailDto;
  @ApiProperty() mainCauses!: RomMainCausesDto;
  @ApiProperty() commentSection!: RomCommentSectionDto;
  @ApiProperty() recommendedDailyRoutine!: RomRecommendedDailyRoutineDto;
  @ApiProperty() expectedEffect!: RomExpectedEffectDto;
  @ApiProperty() actionButton!: RomActionButtonDto;
  @ApiProperty({ type: [String] }) disclaimer!: string[];
  @ApiProperty({ description: '첨부 파일 목록', required: false }) files?: any[];
  @ApiProperty({ description: '랜드마크 데이터 (JSON)', required: false }) landmarks?: any;
  @ApiProperty({ description: '촬영 미리보기 너비', required: false }) previewWidth?: number | null;
  @ApiProperty({ description: '촬영 미리보기 높이', required: false }) previewHeight?: number | null;
}
