import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import {
  MeasurementReportController,
  PublicMeasurementReportController,
  CenterMeasurementReportPublicController,
} from './measurement-report.controller';
import { MeasurementReportService } from './measurement-report.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { CapacityModule } from '../capacity/capacity.module';
import { ReportTranslationModule } from '../report-translation/report-translation.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BodyReportEntity,
      PrecisionReportEntity,
      UserEntity,
      TrainerUserEntity,
      FileEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
      MemberIdentityLinkEntity,
    ]),
    CapacityModule,
    ReportTranslationModule,
  ],
  controllers: [
    PublicMeasurementReportController,
    CenterMeasurementReportPublicController,
    MeasurementReportController,
  ],
  providers: [MeasurementReportService, SubscriptionGuard],
  exports: [MeasurementReportService],
})
export class MeasurementReportModule {}

