// Static report data extracted from measurement-report.service.ts

export const SPINAL_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/spinal-alignment';

export const BALANCE_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/balance-test';

export const OVERHEAD_SQUAT_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/overhead-squat';

export const JOINT_ROM_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/joint-rom';

export const JOINT_ROM_ICON_BASE =
    'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/joint-rom/icon';

export const MUSCLE_MAP_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/body/muscle-maps';

export const SKELETON_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/body/skeleton';

export const RECOMMENDED_HABITS_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/body/habits/recommended-habits';

export const HEIGHT_LOSS_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/body/height-loss';

export const BODY_BALANCE_IMG_BASE =
    'https://s3.ap-northeast-2.amazonaws.com/iposture-s3-bucket/body/balance';

export const BODY_POSTURE_ICON_IMG_BASE =
    'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/body/posture-types';

export const ROM_CAUSE_IMAGE_NUMBER_BY_TITLE: Record<string, number> = {
    '옆으로눕는수면자세오른쪽이아래': 1,
    '옆으로눕는수면자세왼쪽이아래': 2,
    '오른쪽으로고개를돌린수면자세': 3,
    '왼쪽으로고개를돌린수면자세': 4,
    '과도하게높은베개사용': 5,
    '오른쪽팔꿈치로턱괴기': 6,
    '왼쪽팔꿈치로턱괴기': 7,
    '머리카락오른쪽으로넘기는습관': 8,
    '머리카락왼쪽으로넘기는습관': 9,
    '오른쪽으로기대어앉는습관': 10,
    '왼쪽으로기대어앉는습관': 11,
    '의자끝에걸터앉기': 12,
    '지나치게높은의자사용': 13,
    '지나치게낮은의자사용': 14,
    '골반을뒤로빼고허리를꺾어앉기': 15,
    '골반을앞으로빼고등받이에기대앉기': 16,
    '골반을앞으로밀고서있기': 17,
    '구부정한앉은자세': 18,
    '오른쪽방향가방착용습관': 19,
    '왼쪽방향가방착용습관': 20,
    '무거운가방착용': 21,
    '손으로무거운물건반복운반': 22,
    '듀얼모니터오른쪽편중배치': 23,
    '듀얼모니터왼쪽편중배치': 24,
    '키보드과도하게가까운배치': 27,
    '낮은모니터위치노트북사용환경': 28,
    '책상높이가너무높음': 29,
    '고개숙임중심의업무환경': 30,
    '고개숙인상태의장시간휴대폰사용': 31,
    '장시간책상업무자세유지': 32,
    '테이블에팔꿈치를대고몸을기댄자세': 33,
    '체중을팔꿈치로지탱하는습관': 34,
    '팔지지운동시팔꿈치잠금고정푸쉬업등': 35,
    '전화기오른쪽어깨로끼우기': 36,
    '전화기왼쪽어깨로끼우기': 37,
    '다리꼬기오른쪽다리가위': 38,
    '다리꼬기왼쪽다리가위': 39,
    '짝다리지지오른쪽': 40,
    '짝다리지지왼쪽': 41,
    '장시간양반다리': 42,
    '장시간쪼그려앉기': 43,
    '의자에다리간격을넓게두고앉는자세': 44,
    '무릎을붙이고종아리를바깥으로두는앉은자세': 45,
    '안짱걸음': 46,
    '팔자걸음': 47,
    '회전의자사용': 48,
    '몸통만사용하는회전습관오른쪽회전': 49,
    '몸통만사용하는회전습관왼쪽회전': 50,
    '회전운동편중골프테니스등': 51,
    '만세자세로자는수면습관': 52,
    '과도한바른자세강박과도한등허리펴기': 53,
    '과도한등펴기': 54,
    '과도한등근력운동': 55,
    '과도한턱당김습관': 56,
    '오른쪽목어깨스트레칭과다': 57,
    '왼쪽목어깨스트레칭과다': 58,
    '장시간운전': 59,
    '운전시헤드레스트미사용': 60,
    '잦은하이힐착용': 61,
    '장시간서있는자세': 62,
    '발안쪽체중지지': 63,
    '발바깥쪽체중지지': 64,
    '운동부족': 65,
    '팔꿈치가몸에서벌어진상태의업무자세': 67,
  };

/** 키손실 단계 임계값 (cm, 상한 미만) */
export const HEIGHT_LOSS_THRESHOLDS = [
    { max: 0.2,       stage: 1, label: '정상' },
    { max: 0.6,       stage: 2, label: '경미' },
    { max: 1.2,       stage: 3, label: '주의' },
    { max: 2.5,       stage: 4, label: '경계' },
    { max: 4,         stage: 5, label: '심각' },
    { max: Infinity,  stage: 6, label: '위험' },
  ];

export const CAUTION_HABITS_BY_POSTURE_KO: Record<string, Array<{ label: string; imageNumber: number }>> = {
    "목 가쪽굽힘(오른쪽)": [
      { label: "옆으로 눕는 수면자세 (오른쪽이 아래)", imageNumber: 1 },
      { label: "오른손으로 턱 괴는 습관", imageNumber: 6 },
      { label: "머리카락 오른쪽으로 넘기는 습관", imageNumber: 8 },
      { label: "오른쪽으로 기대어 앉는 습관", imageNumber: 10 },
      { label: "오른쪽 방향 가방 착용 습관", imageNumber: 19 },
    ],
    "목 가쪽굽힘(왼쪽)": [
      { label: "옆으로 눕는 수면자세 (왼쪽이 아래)", imageNumber: 2 },
      { label: "왼손으로 턱 괴는 습관", imageNumber: 7 },
      { label: "머리카락 왼쪽으로 넘기는 습관", imageNumber: 9 },
      { label: "왼쪽으로 기대어 앉는 습관", imageNumber: 11 },
      { label: "왼쪽 방향 가방 착용 습관", imageNumber: 20 },
    ],
    "목 회전(오른쪽)": [
      { label: "듀얼 모니터 오른쪽 편중 배치", imageNumber: 23 },
      { label: "옆으로 눕는 수면자세 (오른쪽이 아래)", imageNumber: 1 },
      { label: "오른쪽으로 고개를 돌린 수면자세", imageNumber: 3 },
    ],
    "목 회전(왼쪽)": [
      { label: "듀얼 모니터 왼쪽 편중 배치", imageNumber: 24 },
      { label: "옆으로 눕는 수면자세 (왼쪽이 아래)", imageNumber: 2 },
      { label: "왼쪽으로 고개를 돌린 수면자세", imageNumber: 4 },
    ],
    "거북목": [
      { label: "테이블에 팔꿈치를 대고 몸을 기댄 자세", imageNumber: 33 },
      { label: "낮은 모니터 위치(노트북 사용 환경)", imageNumber: 28 },
      { label: "고개 숙임 중심의 업무 환경", imageNumber: 30 },
      { label: "고개 숙인 상태의 장시간 휴대폰 사용", imageNumber: 31 },
      { label: "과도하게 높은 베개 사용", imageNumber: 5 },
      { label: "운전 시 헤드레스트 미사용", imageNumber: 60 },
    ],
    "들임목": [
      { label: "골반을 앞으로 밀고 서 있기", imageNumber: 17 },
      { label: "골반을 앞으로 빼고 등받이에 기대앉기", imageNumber: 16 },
      { label: "과도한 턱 당김 습관", imageNumber: 56 },
      { label: "과도하게 낮은 베개 사용", imageNumber: 59 },
    ],
    "일자목": [
      { label: "과도한 등 펴기", imageNumber: 54 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
      { label: "과도한 턱 당김 습관", imageNumber: 56 },
    ],

    "어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)": [
      { label: "오른쪽 방향 가방 착용 습관", imageNumber: 19 },
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
      { label: "전화기 오른쪽 어깨로 끼우기", imageNumber: 36 },
    ],
    "어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)": [
      { label: "왼쪽 방향 가방 착용 습관", imageNumber: 20 },
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "짝다리 지지", imageNumber: 41 },
      { label: "전화기 왼쪽 어깨로 끼우기", imageNumber: 37 },
    ],

    "올라간 어깨(오른쪽)": [
      { label: "테이블에 팔꿈치를 대고 몸을 기댄 자세", imageNumber: 33 },
      { label: "만세 자세로 자는 수면 습관", imageNumber: 52 },
      { label: "책상 높이가 너무 높음", imageNumber: 29 },
    ],
    "올라간 어깨(왼쪽)": [
      { label: "테이블에 팔꿈치를 대고 몸을 기댄 자세", imageNumber: 33 },
      { label: "만세 자세로 자는 수면 습관", imageNumber: 52 },
      { label: "책상 높이가 너무 높음", imageNumber: 29 },
    ],
    "올라간 어깨": [
      { label: "테이블에 팔꿈치를 대고 몸을 기댄 자세", imageNumber: 33 },
      { label: "만세 자세로 자는 수면 습관", imageNumber: 52 },
      { label: "책상 높이가 너무 높음", imageNumber: 29 },
    ],

    "처진 어깨(오른쪽)": [
      { label: "무거운 가방 착용", imageNumber: 21 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
      { label: "오른쪽 목·어깨 스트레칭 과다", imageNumber: 57 },
    ],
    "처진 어깨(왼쪽)": [
      { label: "무거운 가방 착용", imageNumber: 21 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
      { label: "왼쪽 목·어깨 스트레칭 과다", imageNumber: 58 },
    ],
    "처진 어깨": [
      { label: "무거운 가방 착용", imageNumber: 21 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
      { label: "목·어깨 스트레칭 과다", imageNumber: 57 },
    ],

    "라운드숄더": [
      { label: "구부정한 앉은 자세", imageNumber: 18 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
      { label: "고개 숙인 상태의 장시간 휴대폰 사용", imageNumber: 31 },
      { label: "고개 숙임 중심의 업무 환경", imageNumber: 30 },
    ],
    "과도하게 펴진 어깨": [
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
    ],

    "위팔 안쪽돌림(오른쪽)": [
      { label: "장시간 책상 업무 자세 유지", imageNumber: 32 },
      { label: "팔꿈치가 몸에서 벌어진 상태의 업무 자세", imageNumber: 67 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],
    "위팔 안쪽돌림(왼쪽)": [
      { label: "장시간 책상 업무 자세 유지", imageNumber: 32 },
      { label: "팔꿈치가 몸에서 벌어진 상태의 업무 자세", imageNumber: 67 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],
    "위팔 안쪽돌림": [
      { label: "장시간 책상 업무 자세 유지", imageNumber: 32 },
      { label: "팔꿈치가 몸에서 벌어진 상태의 업무 자세", imageNumber: 67 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],

    "위팔 가쪽돌림(오른쪽)": [
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
    ],
    "위팔 가쪽돌림(왼쪽)": [
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
    ],
    "위팔 가쪽돌림": [
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
    ],

    "굽혀진 팔꿈치(오른쪽)": [
      { label: "손으로 무거운 물건 반복 운반", imageNumber: 22 },
      { label: "키보드 과도하게 가까운 배치", imageNumber: 27 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],
    "굽혀진 팔꿈치(왼쪽)": [
      { label: "손으로 무거운 물건 반복 운반", imageNumber: 22 },
      { label: "키보드 과도하게 가까운 배치", imageNumber: 27 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],
    "굽혀진 팔꿈치": [
      { label: "손으로 무거운 물건 반복 운반", imageNumber: 22 },
      { label: "키보드 과도하게 가까운 배치", imageNumber: 27 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
    ],

    "과하게 펴진팔꿈치(오른쪽)": [
      { label: "체중을 팔꿈치로 지탱하는 습관", imageNumber: 34 },
      { label: "팔 지지 운동 시 팔꿈치 잠금 고정(ex) 푸쉬업)", imageNumber: 35 },
    ],
    "과하게 펴진팔꿈치(왼쪽)": [
      { label: "체중을 팔꿈치로 지탱하는 습관", imageNumber: 34 },
      { label: "팔 지지 운동 시 팔꿈치 잠금 고정(ex) 푸쉬업)", imageNumber: 35 },
    ],
    "과하게 펴진팔꿈치": [
      { label: "체중을 팔꿈치로 지탱하는 습관", imageNumber: 34 },
      { label: "팔 지지 운동 시 팔꿈치 잠금 고정(ex) 푸쉬업)", imageNumber: 35 },
    ],

    "굽은등": [
      { label: "고개 숙임 중심의 업무 환경", imageNumber: 30 },
      { label: "구부정한 앉은 자세", imageNumber: 18 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
    ],
    "펴진등": [
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
      { label: "과도한 등 근력운동", imageNumber: 55 },
      { label: "잦은 하이힐 착용", imageNumber: 61 },
    ],

    "허리 과전만 & 골반 전방경사": [
      { label: "의자 끝에 걸터앉기", imageNumber: 12 },
      { label: "지나치게 높은 의자 사용", imageNumber: 13 },
      { label: "골반을 뒤로 빼고 허리를 꺾어 앉기", imageNumber: 15 },
      { label: "잦은 하이힐 착용", imageNumber: 61 },
    ],
    "일자허리 & 골반 후방경사": [
      { label: "지나치게 낮은 의자 사용", imageNumber: 14 },
      { label: "골반을 앞으로 빼고 등받이에 기대앉기", imageNumber: 16 },
      { label: "장시간 쪼그려 앉기", imageNumber: 43 },
      { label: "장시간 운전", imageNumber: 60 },
    ],

    "몸통 오른쪽 가쪽굽힘": [
      { label: "왼쪽 방향 가방 착용 습관", imageNumber: 20 },
      { label: "다리꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
      { label: "오른쪽으로 기대어 앉는 습관", imageNumber: 10 },
    ],
    "몸통 왼쪽 가쪽굽힘": [
      { label: "오른쪽 방향 가방 착용 습관", imageNumber: 19 },
      { label: "다리꼬기", imageNumber: 39 },
      { label: "짝다리 지지", imageNumber: 41 },
      { label: "왼쪽으로 기대어 앉는 습관", imageNumber: 11 },
    ],

    "회전된 몸통(오른쪽)": [
      { label: "몸통만 사용하는 회전 습관(오른쪽 회전)", imageNumber: 49 },
      { label: "듀얼 모니터 오른쪽 편중 배치", imageNumber: 23 },
      { label: "회전 운동 편중(골프·테니스 등)", imageNumber: 51 },
      { label: "옆으로 눕는 수면자세", imageNumber: 1 },
    ],
    "회전된 몸통(왼쪽)": [
      { label: "몸통만 사용하는 회전 습관(왼쪽 회전)", imageNumber: 50 },
      { label: "듀얼 모니터 왼쪽 편중 배치", imageNumber: 24 },
      { label: "회전 운동 편중(골프·테니스 등)", imageNumber: 51 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
    ],

    "스웨이백": [
      { label: "골반을 앞으로 빼고 등받이에 기대앉기", imageNumber: 16 },
      { label: "장시간 운전", imageNumber: 60 },
      { label: "골반을 앞으로 밀고 서 있기", imageNumber: 17 },
    ],

    "골반 비대칭(오른쪽↑, 왼쪽↓)": [
      { label: "다리 꼬기(오른쪽 다리가 위)", imageNumber: 38 },
      { label: "짝다리 지지 (오른쪽)", imageNumber: 40 },
      { label: "옆으로 눕는 수면자세", imageNumber: 1 },
    ],
    "골반 비대칭(왼쪽↑, 오른쪽↓)": [
      { label: "다리 꼬기(왼쪽 다리가 위)", imageNumber: 39 },
      { label: "짝다리 지지 (왼쪽)", imageNumber: 41 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
    ],
    "골반 비대칭(오른쪽 ↑)": [
      { label: "다리 꼬기(오른쪽 다리가 위)", imageNumber: 38 },
      { label: "짝다리 지지 (오른쪽)", imageNumber: 40 },
      { label: "옆으로 눕는 수면자세", imageNumber: 1 },
    ],
    "골반 비대칭(왼쪽 ↑)": [
      { label: "다리 꼬기(왼쪽 다리가 위)", imageNumber: 39 },
      { label: "짝다리 지지 (왼쪽)", imageNumber: 41 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
    ],

    "골반 오른쪽 회전": [
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "회전의자 사용", imageNumber: 48 },
      { label: "회전 운동 편중(골프·테니스 등)", imageNumber: 51 },
    ],
    "골반 왼쪽 회전": [
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "회전의자 사용", imageNumber: 48 },
      { label: "회전 운동 편중(골프·테니스 등)", imageNumber: 51 },
    ],
    "골반 회전": [
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "회전의자 사용", imageNumber: 48 },
      { label: "회전 운동 편중(골프·테니스 등)", imageNumber: 51 },
    ],

    "오른쪽으로 이동된 골반": [
      { label: "짝다리 지지 (오른쪽)", imageNumber: 40 },
      { label: "옆으로 눕는 수면자세", imageNumber: 1 },
      { label: "한쪽으로 기대어 앉는 습관", imageNumber: 10 },
    ],
    "왼쪽으로 이동된 골반": [
      { label: "짝다리 지지 (왼쪽)", imageNumber: 41 },
      { label: "옆으로 눕는 수면자세", imageNumber: 2 },
      { label: "한쪽으로 기대어 앉는 습관", imageNumber: 11 },
    ],

    "넙다리 가쪽돌림(오른쪽)": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "팔자걸음", imageNumber: 47 },
      { label: "의자에 다리 간격을 넓게 두고 앉는 자세", imageNumber: 44 },
    ],
    "넙다리 가쪽돌림(왼쪽)": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "팔자걸음", imageNumber: 47 },
      { label: "의자에 다리 간격을 넓게 두고 앉는 자세", imageNumber: 44 },
    ],
    "넙다리 가쪽돌림": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "팔자걸음", imageNumber: 47 },
      { label: "의자에 다리 간격을 넓게 두고 앉는 자세", imageNumber: 44 },
    ],

    "넙다리 안쪽돌림(오른쪽)": [
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "안짱걸음", imageNumber: 46 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],
    "넙다리 안쪽돌림(왼쪽)": [
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "안짱걸음", imageNumber: 46 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],
    "넙다리 안쪽돌림": [
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "안짱걸음", imageNumber: 46 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],

    "오다리(오른쪽)": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "팔자걸음", imageNumber: 47 },
      { label: "의자에 다리 간격을 넓게 두고 앉는 자세", imageNumber: 44 },
    ],
    "오다리(왼쪽)": [
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "안짱걸음", imageNumber: 46 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],
    "오다리": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "팔자걸음", imageNumber: 47 },
      { label: "의자에 다리 간격을 넓게 두고 앉는 자세", imageNumber: 44 },
    ],

    "엑스다리(오른쪽)": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "운동 부족", imageNumber: 55 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],
    "엑스다리(왼쪽)": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "운동 부족", imageNumber: 55 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],
    "엑스다리": [
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "운동 부족", imageNumber: 55 },
      { label: "무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세", imageNumber: 45 },
    ],

    "과하게 펴진 무릎": [
      { label: "잦은 하이힐 착용", imageNumber: 61 },
      { label: "장시간 서 있는 자세", imageNumber: 62 },
      { label: "과도한 바른자세 강박(과도한 등.허리펴기)", imageNumber: 53 },
    ],
    "굽혀진 무릎": [
      { label: "지나치게 낮은 의자 사용", imageNumber: 14 },
      { label: "장시간 양반다리", imageNumber: 42 },
      { label: "장시간 쪼그려 앉기", imageNumber: 43 },
    ],

    "평발(오른쪽)": [
      { label: "발 안쪽 체중 지지", imageNumber: 63 },
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
    ],
    "평발(왼쪽)": [
      { label: "발 안쪽 체중 지지", imageNumber: 63 },
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "짝다리 지지", imageNumber: 41 },
    ],
    "평발": [
      { label: "발 안쪽 체중 지지", imageNumber: 63 },
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
    ],

    "오목발(오른쪽)": [
      { label: "발 바깥쪽 체중 지지", imageNumber: 64 },
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
    ],
    "오목발(왼쪽)": [
      { label: "발 바깥쪽 체중 지지", imageNumber: 64 },
      { label: "다리 꼬기", imageNumber: 39 },
      { label: "짝다리 지지", imageNumber: 41 },
    ],
    "오목발": [
      { label: "발 바깥쪽 체중 지지", imageNumber: 64 },
      { label: "다리 꼬기", imageNumber: 38 },
      { label: "짝다리 지지", imageNumber: 40 },
    ],
  };

export const DISEASE_KEY_TO_POSTURE_KO: Record<string, string> = {
    NECK_TILT: '목 가쪽굽힘',
    NECK_ROTATION: '목 회전',
    TURTLE_NECK: '거북목',
    STRAIGHT_NECK: '일자목',
    RAISED_NECK: '들임목',
    SHOULDER_HEIGHT_ASYMMETRY: '어깨높이 비대칭',
    RAISED_SHOULDER: '올라간 어깨',
    DROPPED_SHOULDER: '처진 어깨',
    ROUNDED_SHOULDER: '라운드숄더',
    STRAIGHT_SHOULDER: '과도하게 펴진 어깨',
    ARMS_TURNED_IN: '위팔 안쪽돌림',
    ARMS_TURNED_OUT: '위팔 가쪽돌림',
    BENT_ELBOW: '굽혀진 팔꿈치',
    EXTENDED_ELBOW: '과하게 펴진팔꿈치',
    HUNCHED_BACK: '굽은등',
    FLAT_BACK: '펴진등',
    PELVIS_TILTS_FORWARD: '허리 과전만 & 골반 전방경사',
    PELVIS_TILTS_BACKWARD: '일자허리 & 골반 후방경사',
    TORSO_TILTED_RIGHT: '몸통 오른쪽 가쪽굽힘',
    TORSO_TILTED_LEFT: '몸통 왼쪽 가쪽굽힘',
    TORSO_ROTATION_LEFT: '회전된 몸통',
    TORSO_ROTATION_RIGHT: '회전된 몸통',
    SWAY_BACK: '스웨이백',
    PELVIS_ASYMMETRY: '골반 비대칭',
    PELVIS_ROTATION_LEFT: '골반 회전',
    PELVIS_ROTATION_RIGHT: '골반 회전',
    PELVIS_MOVE_RIGHT: '오른쪽으로 이동된 골반',
    PELVIS_MOVE_LEFT: '왼쪽으로 이동된 골반',
    LEGS_TURNED_OUTWARD: '넙다리 가쪽돌림',
    LEGS_TURNED_INWARD: '넙다리 안쪽돌림',
    BOW_LEGS: '오다리',
    KNOCK_LEGS: '엑스다리',
    BACK_KNEES: '과하게 펴진 무릎',
    BENT_KNEES: '굽혀진 무릎',
    FLAT_FEET: '평발',
    ARCHED_FEET: '오목발',
    ANKLE_MOVE_OUTWARD: '발목 가쪽번짐',
    ANKLE_MOVE_INWARD: '발목 안쪽번짐',
  };

export const POSTURE_IMAGE_NUMBER_MAP: Record<string, number> = {
    // 목
    'NECK_TILT_RIGHT': 1,
    'NECK_TILT_LEFT': 2,
    'NECK_ROTATION_RIGHT': 3,
    'NECK_ROTATION_LEFT': 4,
    'TURTLE_NECK': 5,
    'RAISED_NECK': 6,
    'STRAIGHT_NECK': 7,

    // 어깨
    'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP': 8,
    'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP': 9,
    'RAISED_SHOULDER_RIGHT': 10,
    'RAISED_SHOULDER_LEFT': 11,
    'DROPPED_SHOULDER_RIGHT': 12,
    'DROPPED_SHOULDER_LEFT': 13,
    'ROUNDED_SHOULDER': 14,
    'STRAIGHT_SHOULDER': 15,

    // 팔
    'ARMS_TURNED_IN_RIGHT': 16,
    'ARMS_TURNED_IN_LEFT': 17,
    'ARMS_TURNED_OUT_RIGHT': 18,
    'ARMS_TURNED_OUT_LEFT': 19,
    'BENT_ELBOW_RIGHT': 20,
    'BENT_ELBOW_LEFT': 21,
    'EXTENDED_ELBOW_RIGHT': 22,
    'EXTENDED_ELBOW_LEFT': 23,

    // 등
    'HUNCHED_BACK': 24,
    'FLAT_BACK': 25,

    // 골반/허리
    'PELVIS_TILTS_FORWARD': 26,
    'PELVIS_TILTS_BACKWARD': 27,
    'TORSO_TILTED_RIGHT': 28,
    'TORSO_TILTED_LEFT': 29,
    'TORSO_ROTATION_RIGHT': 30,
    'TORSO_ROTATION_LEFT': 31,
    'SWAY_BACK': 32,
    'PELVIS_ASYMMETRY_RIGHT_UP': 33,
    'PELVIS_ASYMMETRY_LEFT_UP': 34,
    'PELVIS_ROTATION_RIGHT': 35,
    'PELVIS_ROTATION_LEFT': 36,
    'PELVIS_MOVE_RIGHT': 37,
    'PELVIS_MOVE_LEFT': 38,

    // 다리
    'LEGS_TURNED_OUTWARD_RIGHT': 39,
    'LEGS_TURNED_OUTWARD_LEFT': 40,
    'LEGS_TURNED_INWARD_RIGHT': 41,
    'LEGS_TURNED_INWARD_LEFT': 42,
    'BOW_LEGS_EXTERNAL_RIGHT': 43,  // 바깥으로 돌아간 다리 + 오다리
    'BOW_LEGS_EXTERNAL_LEFT': 44,
    'BOW_LEGS_INTERNAL_RIGHT': 45,  // 안으로 돌아간 다리 + 오다리
    'BOW_LEGS_INTERNAL_LEFT': 46,
    'KNOCK_LEGS_RIGHT': 47,
    'KNOCK_LEGS_LEFT': 48,

    // 무릎
    'BACK_KNEES': 49,
    'BENT_KNEES': 50,

    // 발
    'FLAT_FEET_RIGHT': 51,
    'FLAT_FEET_LEFT': 52,
    'ARCHED_FEET_RIGHT': 53,
    'ARCHED_FEET_LEFT': 54,
  };

export const POSTURE_CARD_LABEL_MAP: Record<string, string> = {
    // 목
    'NECK_TILT_RIGHT': '목 가쪽굽힘(오른쪽)',
    'NECK_TILT_LEFT': '목 가쪽굽힘(왼쪽)',
    'NECK_TILT': '목 가쪽굽힘',
    'NECK_ROTATION_RIGHT': '목 회전(오른쪽)',
    'NECK_ROTATION_LEFT': '목 회전(왼쪽)',
    'NECK_ROTATION': '목 회전',
    'TURTLE_NECK': '거북목',
    'RAISED_NECK': '들임목',
    'STRAIGHT_NECK': '일자목',

    // 어깨
    'SHOULDER_HEIGHT_ASYMMETRY_RIGHT': '어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)',
    'SHOULDER_HEIGHT_ASYMMETRY_LEFT': '어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)',
    'SHOULDER_HEIGHT_ASYMMETRY': '어깨높이 비대칭',
    'RAISED_SHOULDER': '올라간 어깨',
    'DROPPED_SHOULDER': '처진 어깨',
    'ROUNDED_SHOULDER': '라운드숄더',
    'STRAIGHT_SHOULDER': '과도하게 펴진 어깨',

    // 팔
    'ARMS_TURNED_IN_RIGHT': '위팔 안쪽돌림(오른쪽)',
    'ARMS_TURNED_IN_LEFT': '위팔 안쪽돌림(왼쪽)',
    'ARMS_TURNED_IN': '위팔 안쪽돌림',
    'ARMS_TURNED_OUT_RIGHT': '위팔 가쪽돌림(오른쪽)',
    'ARMS_TURNED_OUT_LEFT': '위팔 가쪽돌림(왼쪽)',
    'ARMS_TURNED_OUT': '위팔 가쪽돌림',
    'BENT_ELBOW_RIGHT': '굽혀진 팔꿈치(오른쪽)',
    'BENT_ELBOW_LEFT': '굽혀진 팔꿈치(왼쪽)',
    'BENT_ELBOW': '굽혀진 팔꿈치',
    'EXTENDED_ELBOW_RIGHT': '과하게 펴진팔꿈치(오른쪽)',
    'EXTENDED_ELBOW_LEFT': '과하게 펴진팔꿈치(왼쪽)',
    'EXTENDED_ELBOW': '과하게 펴진팔꿈치',

    // 등
    'HUNCHED_BACK': '굽은등',
    'FLAT_BACK': '펴진등',

    // 골반 / 허리
    'PELVIS_TILTS_FORWARD': '허리 과전만 & 골반 전방경사',
    'PELVIS_TILTS_BACKWARD': '일자허리 & 골반 후방경사',
    'TORSO_TILTED_RIGHT': '몸통 오른쪽 가쪽굽힘',
    'TORSO_TILTED_LEFT': '몸통 왼쪽 가쪽굽힘',
    'TORSO_ROTATION_RIGHT': '회전된 몸통(오른쪽)',
    'TORSO_ROTATION_LEFT': '회전된 몸통(왼쪽)',
    'SWAY_BACK': '스웨이백',
    'PELVIS_ASYMMETRY_RIGHT': '골반 비대칭(오른쪽 ↑, 왼쪽 ↓)',
    'PELVIS_ASYMMETRY_LEFT': '골반 비대칭(왼쪽 ↑, 오른쪽 ↓)',
    'PELVIS_ASYMMETRY': '골반 비대칭',
    'PELVIS_ROTATION_RIGHT': '골반 오른쪽 회전',
    'PELVIS_ROTATION_LEFT': '골반 왼쪽 회전',
    'PELVIS_MOVE_RIGHT': '오른쪽으로 이동된 골반',
    'PELVIS_MOVE_LEFT': '왼쪽으로 이동된 골반',

    // 다리
    'LEGS_TURNED_OUTWARD_RIGHT': '넙다리 가쪽돌림(오른쪽)',
    'LEGS_TURNED_OUTWARD_LEFT': '넙다리 가쪽돌림(왼쪽)',
    'LEGS_TURNED_OUTWARD': '넙다리 가쪽돌림',
    'LEGS_TURNED_INWARD_RIGHT': '넙다리 안쪽돌림(오른쪽)',
    'LEGS_TURNED_INWARD_LEFT': '넙다리 안쪽돌림(왼쪽)',
    'LEGS_TURNED_INWARD': '넙다리 안쪽돌림',
    'BOW_LEGS_RIGHT': '오다리(오른쪽)',
    'BOW_LEGS_LEFT': '오다리(왼쪽)',
    'BOW_LEGS': '오다리',
    'KNOCK_LEGS_RIGHT': '엑스다리(오른쪽)',
    'KNOCK_LEGS_LEFT': '엑스다리(왼쪽)',
    'KNOCK_LEGS': '엑스다리',

    // 무릎
    'BACK_KNEES': '과하게 펴진 무릎',
    'BENT_KNEES': '굽혀진 무릎',

    // 발
    'FLAT_FEET_RIGHT': '평발(오른쪽)',
    'FLAT_FEET_LEFT': '평발(왼쪽)',
    'FLAT_FEET': '평발',
    'ARCHED_FEET_RIGHT': '오목발(오른쪽)',
    'ARCHED_FEET_LEFT': '오목발(왼쪽)',
    'ARCHED_FEET': '오목발',

    // 발목
    'ANKLE_MOVE_OUTWARD': '발목 가쪽번짐',
    'ANKLE_MOVE_INWARD': '발목 안쪽번짐',
  };

export { NECK_LOAD_BACKWARD_MAP, NECK_LOAD_FORWARD_MAP } from '../analysis/helpers/neck-load.helper';

export const POSTURE_IMPRESSION_MAP: Record<string, string[]> = {
    // 목 가쪽굽힘
    'NECK_TILT_RIGHT': [
      '얼굴 기울어짐으로 한쪽이 더 커 보이는 인상',
      '한쪽 볼만 유독 잘 붓는 얼굴',
      '한쪽 어깨(승모근)만 더 튀어나와 보임',
      '목선이 한쪽만 짧아 답답해 보이는 인상',
    ],
    'NECK_TILT_LEFT': [
      '얼굴 기울어짐으로 한쪽이 더 커 보이는 인상',
      '한쪽 볼만 유독 잘 붓는 얼굴',
      '한쪽 어깨(승모근)만 더 튀어나와 보임',
      '목선이 한쪽만 짧아 답답해 보이는 인상',
    ],

    // 목 회전
    'NECK_ROTATION_RIGHT': [
      '얼굴 중심이 한쪽으로 치우쳐 보이는 인상',
      '턱선이 한쪽만 유독 두꺼워 보임',
      '목 라인이 좌우로 균형이 맞지 않아 보임',
      '어깨 폭이 한쪽만 더 넓어 보이는 체형',
    ],
    'NECK_ROTATION_LEFT': [
      '얼굴 중심이 한쪽으로 치우쳐 보이는 인상',
      '턱선이 한쪽만 유독 두꺼워 보임',
      '목 라인이 좌우로 균형이 맞지 않아 보임',
      '어깨 폭이 한쪽만 더 넓어 보이는 체형',
    ],

    // 거북목
    'TURTLE_NECK': [
      '얼굴이 전체적으로 커 보이는 인상',
      '목이 짧고 굵어 보이는 체형',
      '어깨 위 근육(승모근)이 부풀어 보임',
      '목 뒤가 튀어나와 보이는 인상',
    ],

    // 들임목
    'RAISED_NECK': [
      '이중턱이 도드라져 보이는 인상',
      '얼굴과 목의 경계가 흐려 보임',
      '얼굴이 평면적이고 납작해 보이는 인상',
      '상체 대비 배가 더 나와 보이는 체형',
    ],

    // 일자목 (거북목과 동일)
    'STRAIGHT_NECK': [
      '얼굴이 전체적으로 커 보이는 인상',
      '목이 짧고 굵어 보이는 체형',
      '어깨 위 근육(승모근)이 부풀어 보임',
      '목 뒤가 튀어나와 보이는 인상',
    ],

    // 어깨높이 비대칭
    'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP': [
      '한쪽 어깨(승모근)만 더 튀어나와 보임',
      '목선이 한쪽만 짧아 답답해 보이는 인상',
      '얼굴 기울어짐으로 한쪽이 더 커 보이는 인상',
      '한쪽 옆구리 지방 축적',
    ],
    'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP': [
      '한쪽 어깨(승모근)만 더 튀어나와 보임',
      '목선이 한쪽만 짧아 답답해 보이는 인상',
      '얼굴 기울어짐으로 한쪽이 더 커 보이는 인상',
      '한쪽 옆구리 지방 축적',
    ],

    // 올라간 어깨
    'RAISED_SHOULDER_RIGHT': [
      '목이 짧고 굵어 보이는 체형',
      '얼굴이 전체적으로 커 보이는 인상',
      '어깨 위 근육(승모근)이 부풀어 보임',
      '항상 긴장되어 보이는 인상',
    ],
    'RAISED_SHOULDER_LEFT': [
      '목이 짧고 굵어 보이는 체형',
      '얼굴이 전체적으로 커 보이는 인상',
      '어깨 위 근육(승모근)이 부풀어 보임',
      '항상 긴장되어 보이는 인상',
    ],
    'RAISED_SHOULDER_BOTH': [
      '목이 짧고 굵어 보이는 체형',
      '얼굴이 전체적으로 커 보이는 인상',
      '어깨 위 근육(승모근)이 부풀어 보임',
      '항상 긴장되어 보이는 인상',
    ],

    // 처진 어깨
    'DROPPED_SHOULDER_RIGHT': [
      '어깨선이 무너져 전체적으로 나이 들어 보이는 인상',
      '목이 짧고 굵어 보이는 체형',
      '가슴 위치가 아래로 내려가 보이는 인상',
      '전신에 탄력이 없어 늘어진 느낌',
    ],
    'DROPPED_SHOULDER_LEFT': [
      '어깨선이 무너져 전체적으로 나이 들어 보이는 인상',
      '목이 짧고 굵어 보이는 체형',
      '가슴 위치가 아래로 내려가 보이는 인상',
      '전신에 탄력이 없어 늘어진 느낌',
    ],
    'DROPPED_SHOULDER_BOTH': [
      '어깨선이 무너져 전체적으로 나이 들어 보이는 인상',
      '목이 짧고 굵어 보이는 체형',
      '가슴 위치가 아래로 내려가 보이는 인상',
      '전신에 탄력이 없어 늘어진 느낌',
    ],

    // 라운드숄더
    'ROUNDED_SHOULDER': [
      '얼굴 라인이 처져 보이는 인상',
      '목이 굵고 짧아 보이는 인상',
      '상체 옆모습이 둔해 보이는 인상',
      '어깨선이 둥글어 전체적으로 둔해 보임',
    ],

    // 과도하게 펴진 어깨
    'STRAIGHT_SHOULDER': [
      '갈비뼈가 도드라져 몸통이 커 보임',
      '상복부가 앞으로 돌출됨',
      '전체 체형이 경직돼 보임',
    ],

    // 안으로 돌아간 팔
    'ARMS_TURNED_IN_RIGHT': [
      '겨드랑이 앞라인이 접혀 보임',
      '위팔 안쪽 체지방 정체',
      '어깨선이 둥글어 전체적으로 둔해 보임',
    ],
    'ARMS_TURNED_IN_LEFT': [
      '겨드랑이 앞라인이 접혀 보임',
      '위팔 안쪽 체지방 정체',
      '어깨선이 둥글어 전체적으로 둔해 보임',
    ],
    'ARMS_TURNED_IN_BOTH': [
      '겨드랑이 앞라인이 접혀 보임',
      '위팔 안쪽 체지방 정체',
      '어깨선이 둥글어 전체적으로 둔해 보임',
    ],

    // 바깥으로 돌아간 팔
    'ARMS_TURNED_OUT_RIGHT': [
      '겨드랑이·옆선이 정리되지 않아 보임',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
      '상체 긴장도 증가',
    ],
    'ARMS_TURNED_OUT_LEFT': [
      '겨드랑이·옆선이 정리되지 않아 보임',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
      '상체 긴장도 증가',
    ],
    'ARMS_TURNED_OUT_BOTH': [
      '겨드랑이·옆선이 정리되지 않아 보임',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
      '상체 긴장도 증가',
    ],

    // 굽혀진 팔꿈치
    'BENT_ELBOW_RIGHT': [
      '팔 길이 비율이 왜곡돼 보임',
      '팔 체지방 정체',
      '상체 전체 라인 무너짐의 시작',
    ],
    'BENT_ELBOW_LEFT': [
      '팔 길이 비율이 왜곡돼 보임',
      '팔 체지방 정체',
      '상체 전체 라인 무너짐의 시작',
    ],
    'BENT_ELBOW_BOTH': [
      '팔 길이 비율이 왜곡돼 보임',
      '팔 체지방 정체',
      '상체 전체 라인 무너짐의 시작',
    ],

    // 과하게 펴진 팔꿈치
    'EXTENDED_ELBOW_RIGHT': [
      '상체 긴장도 증가',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
    ],
    'EXTENDED_ELBOW_LEFT': [
      '상체 긴장도 증가',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
    ],
    'EXTENDED_ELBOW_BOTH': [
      '상체 긴장도 증가',
      '팔 라인 미관 손상(직선·역각 형태의 팔 인상)',
    ],

    // 굽은등
    'HUNCHED_BACK': [
      '등이 넓고 두꺼워 보임',
      '전키가 작아 보이는 착시',
      '얼굴이 크게 보임',
      '목·턱선 지지 약화',
    ],

    // 펴진 등
    'FLAT_BACK': [
      '갈비뼈가 드러나 몸통이 커 보임',
      '상복부 돌출',
      '전체 체형이 경직돼 보임',
    ],

    // 스웨이백
    'SWAY_BACK': [
      '아랫배가 항상 나와보임',
      '힙 라인이 아래로 내려가 보임',
      '체형 전반의 이완으로 노화된 이미지가 형성',
    ],

    // 골반 전방경사
    'PELVIS_TILTS_FORWARD': [
      '아랫배가 항상 나와보임',
      '복부 체지방 정체',
      '허벅지 앞쪽 두께 증가',
      '둔부 볼륨이 커져 하체 실루엣이 둔해짐',
    ],

    // 골반 후방경사
    'PELVIS_TILTS_BACKWARD': [
      '둔부가 납작해 보임',
      '힙 라인이 아래로 내려가 보임',
      '하체 길이가 짧아 보임',
      '전신 체형이 평면적으로 보임',
    ],

    // 기울어진 몸통
    'TORSO_TILTED_RIGHT': [
      '한쪽 옆구리에 지방이 집중됨',
      '하지 굵기·형태 비대칭',
      '힙 크기가 한쪽만 더 크게 보임',
    ],
    'TORSO_TILTED_LEFT': [
      '한쪽 옆구리에 지방이 집중됨',
      '하지 굵기·형태 비대칭',
      '힙 크기가 한쪽만 더 크게 보임',
    ],

    // 회전된 몸통
    'TORSO_ROTATION_RIGHT': [
      '한쪽 옆구리에 지방이 집중됨',
      '갈비뼈 좌우 비대칭 돌출',
      '체중 감량 대비 복부 실루엣 개선 저조',
    ],
    'TORSO_ROTATION_LEFT': [
      '한쪽 옆구리에 지방이 집중됨',
      '갈비뼈 좌우 비대칭 돌출',
      '체중 감량 대비 복부 실루엣 개선 저조',
    ],

    // 골반 비대칭
    'PELVIS_ASYMMETRY_RIGHT_UP': [
      '힙 크기가 한쪽만 더 크게 보임',
      '한쪽 옆구리 지방 축적',
      '한쪽 순환 저하에 따른 셀룰라이트 고착',
      '양측 하지 굵기 비대칭',
    ],
    'PELVIS_ASYMMETRY_LEFT_UP': [
      '힙 크기가 한쪽만 더 크게 보임',
      '한쪽 옆구리 지방 축적',
      '한쪽 순환 저하에 따른 셀룰라이트 고착',
      '양측 하지 굵기 비대칭',
    ],

    // 골반 회전
    'PELVIS_ROTATION_RIGHT': [
      '치마·바지가 한쪽으로 비틀려 맞지 않음',
      '복부가 한쪽만 더 도드라져 보임',
      '한쪽 순환 저하에 따른 셀룰라이트 고착',
      '하지 부종',
    ],
    'PELVIS_ROTATION_LEFT': [
      '치마·바지가 한쪽으로 비틀려 맞지 않음',
      '복부가 한쪽만 더 도드라져 보임',
      '한쪽 순환 저하에 따른 셀룰라이트 고착',
      '하지 부종',
    ],

    // 이동된 골반
    'PELVIS_MOVE_RIGHT': [
      '양측 하지 굵기 비대칭',
      '한쪽 엉덩이 볼륨 감소(힙딥)',
      '한쪽 옆구리 지방 축적',
    ],
    'PELVIS_MOVE_LEFT': [
      '양측 하지 굵기 비대칭',
      '한쪽 엉덩이 볼륨 감소(힙딥)',
      '한쪽 옆구리 지방 축적',
    ],

    // 바깥으로 돌아간 다리
    'LEGS_TURNED_OUTWARD_RIGHT': [
      '다리 정렬 이탈로 라인이 벌어짐',
      '하체 폭이 넓어 보이는 실루엣',
      '다리 길이 짧아 보이는 착시',
    ],
    'LEGS_TURNED_OUTWARD_LEFT': [
      '다리 정렬 이탈로 라인이 벌어짐',
      '하체 폭이 넓어 보이는 실루엣',
      '다리 길이 짧아 보이는 착시',
    ],
    'LEGS_TURNED_OUTWARD_BOTH': [
      '다리 정렬 이탈로 라인이 벌어짐',
      '하체 폭이 넓어 보이는 실루엣',
      '다리 길이 짧아 보이는 착시',
    ],

    // 안으로 돌아간 다리
    'LEGS_TURNED_INWARD_RIGHT': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],
    'LEGS_TURNED_INWARD_LEFT': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],
    'LEGS_TURNED_INWARD_BOTH': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],

    // 오다리 (바깥)
    'BOW_LEGS_EXTERNAL_RIGHT': [
      '다리 사이 공간이 과도하게 벌어짐',
      '다리 비율 짧아 보임',
      '하체가 실제보다 크고 넓어 보임',
    ],
    'BOW_LEGS_EXTERNAL_LEFT': [
      '다리 사이 공간이 과도하게 벌어짐',
      '다리 비율 짧아 보임',
      '하체가 실제보다 크고 넓어 보임',
    ],
    'BOW_LEGS_EXTERNAL_BOTH': [
      '다리 사이 공간이 과도하게 벌어짐',
      '다리 비율 짧아 보임',
      '하체가 실제보다 크고 넓어 보임',
    ],

    // 오다리 (안)
    'BOW_LEGS_INTERNAL_RIGHT': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],
    'BOW_LEGS_INTERNAL_LEFT': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],
    'BOW_LEGS_INTERNAL_BOTH': [
      '엉덩이 볼륨 감소(힙딥)',
      '허벅지 앞쪽 두께 증가',
      '종아리 라인이 휘어 보임',
    ],

    // 엑스다리
    'KNOCK_LEGS_RIGHT': [
      '허벅지 바깥쪽 살이 더 도드라져 보임',
      '다리 비율이 짧아 보임',
      '하체 정렬이 불안정해 보임',
    ],
    'KNOCK_LEGS_LEFT': [
      '허벅지 바깥쪽 살이 더 도드라져 보임',
      '다리 비율이 짧아 보임',
      '하체 정렬이 불안정해 보임',
    ],
    'KNOCK_LEGS_BOTH': [
      '허벅지 바깥쪽 살이 더 도드라져 보임',
      '다리 비율이 짧아 보임',
      '하체 정렬이 불안정해 보임',
    ],

    // 무릎
    'BACK_KNEES': [
      '허벅지 앞쪽 두께 증가',
      '종아리 두께 증가',
      '하체 전반이 경직돼 보임',
    ],
    'BENT_KNEES': [
      '다리 비율이 짧아 보임',
      '힙 라인이 아래로 내려가 보임',
      '하체 라인 처짐',
    ],

    // 평발
    'FLAT_FEET_RIGHT': [
      '발목이 굵어 보임',
      '하지 부종 증가',
      '종아리 안쪽 살이 도드라져 보임',
    ],
    'FLAT_FEET_LEFT': [
      '발목이 굵어 보임',
      '하지 부종 증가',
      '종아리 안쪽 살이 도드라져 보임',
    ],
    'FLAT_FEET_BOTH': [
      '발목이 굵어 보임',
      '하지 부종 증가',
      '종아리 안쪽 살이 도드라져 보임',
    ],

    // 오목발
    'ARCHED_FEET_RIGHT': [
      '발목 바깥쪽 라인이 돌출돼 보임',
      '하지 부종 증가',
      '발 두께가 강조돼 둔해 보임',
    ],
    'ARCHED_FEET_LEFT': [
      '발목 바깥쪽 라인이 돌출돼 보임',
      '하지 부종 증가',
      '발 두께가 강조돼 둔해 보임',
    ],
    'ARCHED_FEET_BOTH': [
      '발목 바깥쪽 라인이 돌출돼 보임',
      '하지 부종 증가',
      '발 두께가 강조돼 둔해 보임',
    ],
  };

export const IMPRESSION_TO_IMPROVEMENT: Record<string, string> = {
    // 얼굴·목
    '얼굴 기울어짐으로 한쪽이 더 커 보이는 인상': '얼굴 좌우 대칭 개선',
    '한쪽 볼만 유독 잘 붓는 얼굴': '볼 붓기 개선',
    '한쪽 어깨(승모근)만 더 튀어나와 보임': '승모근 부풀어오름 완화',
    '목선이 한쪽만 짧아 답답해 보이는 인상': '목선 길이감 회복',
    '얼굴 중심이 한쪽으로 치우쳐 보이는 인상': '얼굴 좌우 대칭 개선',
    '턱선이 한쪽만 유독 두꺼워 보임': '턱선 또렷해짐',
    '목 라인이 좌우로 균형이 맞지 않아 보임': '넥 라인 정돈',
    '어깨 폭이 한쪽만 더 넓어 보이는 체형': '어깨 폭 좌우 균형 개선',
    '얼굴이 전체적으로 커 보이는 인상': '얼굴 윤곽이 작아 보이는 인상',
    '목이 짧고 굵어 보이는 체형': '넥 라인 슬림화',
    '목이 굵고 짧아 보이는 인상': '넥 라인 슬림화',
    '어깨 위 근육(승모근)이 부풀어 보임': '승모근 부풀어오름 완화',
    '목 뒤가 튀어나와 보이는 인상': '목 뒤 돌출 완화',
    '이중턱이 도드라져 보이는 인상': '이중턱 완화',
    '얼굴과 목의 경계가 흐려 보임': '얼굴–목 경계 또렷해짐',
    '얼굴이 평면적이고 납작해 보이는 인상': '얼굴 입체감 회복',
    '상체 대비 배가 더 나와 보이는 체형': '복부 돌출 인상 완화',
    '얼굴이 크게 보임': '얼굴 윤곽이 작아 보이는 인상',
    '목·턱선 지지 약화': '목·턱선 지지 회복',
    // 어깨·상체
    '항상 긴장되어 보이는 인상': '상체 긴장 완화',
    '어깨선이 무너져 전체적으로 나이 들어 보이는 인상': '어깨선 개선',
    '가슴 위치가 아래로 내려가 보이는 인상': '가슴 라인 리프팅 효과',
    '전신에 탄력이 없어 늘어진 느낌': '전신 탄력 개선',
    '얼굴 라인이 처져 보이는 인상': '페이스 라인 리프트',
    '상체 옆모습이 둔해 보이는 인상': '상체 옆모습이 얇아짐',
    '어깨선이 둥글어 전체적으로 둔해 보임': '어깨선이 직각으로 정리됨',
    '갈비뼈가 도드라져 몸통이 커 보임': '갈비뼈 돌출 완화',
    '갈비뼈가 드러나 몸통이 커 보임': '갈비뼈 돌출 완화',
    '상복부가 앞으로 돌출됨': '상복부 돌출 완화',
    '상복부 돌출': '상복부 돌출 완화',
    '전체 체형이 경직돼 보임': '체형 이완 및 정렬 개선',
    '등이 넓고 두꺼워 보임': '등 두께 및 폭 감소',
    '전키가 작아 보이는 착시': '키 비율 개선 효과',
    '상체 전체 라인 무너짐의 시작': '상체 라인 회복',
    // 팔
    '겨드랑이 앞라인이 접혀 보임': '겨드랑이 라인 정리',
    '위팔 안쪽 체지방 정체': '위팔 안쪽 지방 감소',
    '팔 라인 미관 손상': '팔 라인 정돈',
    '팔 라인 미관 손상(직선·역각 형태의 팔 인상)': '팔 라인 정돈',
    '겨드랑이·옆선이 정리되지 않아 보임': '겨드랑이·옆라인 정리',
    '상체 긴장도 증가': '상체 긴장 완화',
    '팔 길이 비율이 왜곡돼 보임': '팔 비율 회복',
    '팔 체지방 정체': '팔 라인 슬림화',
    // 복부·골반·힙
    '아랫배가 항상 나와보임': '아랫배 정리',
    '복부 체지방 정체': '복부 라인 개선',
    '허벅지 앞쪽 두께 증가': '허벅지 전면 두께 감소',
    '둔부 볼륨이 커져 하체 실루엣이 둔해짐': '하체 실루엣 정리',
    '둔부가 납작해 보임': '힙 볼륨 회복',
    '힙 라인이 아래로 내려가 보임': '힙 라인 리프트',
    '하체 길이가 짧아 보임': '하체 비율 개선',
    '전신 체형이 평면적으로 보임': '체형 입체감 회복',
    '복부가 한쪽만 더 도드라져 보임': '복부 좌우 균형 개선',
    // 하체·다리
    '한쪽 옆구리에 지방이 집중됨': '옆구리 지방 집중 완화',
    '한쪽 옆구리 지방 축적': '옆구리 지방 집중 완화',
    '하지 굵기·형태 비대칭': '하지 좌우 균형 개선',
    '양측 하지 굵기 비대칭': '하지 좌우 균형 개선',
    '힙 크기가 한쪽만 더 크게 보임': '힙 볼륨 좌우 균형 개선',
    '갈비뼈 좌우 비대칭 돌출': '갈비뼈 좌우 균형 개선',
    '체중 감량 대비 복부 실루엣 개선 저조': '복부 실루엣 개선 체감 증가',
    '체형 전반의 이완으로 노화된 이미지가 형성': '전신 탄력 회복',
    '체형 전반의 이완으로 노화된 이미지 형성': '전신 탄력 회복',
    '한쪽 순환 저하에 따른 셀룰라이트 고착': '셀룰라이트 완화',
    '치마·바지가 한쪽으로 비틀려 맞지 않음': '하의 착용 시 틀어짐 완화',
    '하지 부종': '하지 부종 완화',
    '하지 부종 증가': '하지 부종 완화',
    '한쪽 엉덩이 볼륨 감소(힙딥)': '힙 외측 라인 정돈',
    '엉덩이 볼륨 감소(힙딥)': '힙 외측 라인 정돈',
    '다리 정렬 이탈로 라인이 벌어짐': '다리 정렬 개선',
    '하체 폭이 넓어 보이는 실루엣': '하체 좌우 폭 축소',
    '다리 길이 짧아 보이는 착시': '다리 비율 개선 효과',
    '다리 비율 짧아 보임': '다리 비율 개선 효과',
    '다리 비율이 짧아 보임': '다리 비율 개선 효과',
    '다리 사이 공간이 과도하게 벌어짐': '다리 간격 완화',
    '하체가 실제보다 크고 넓어 보임': '하체 실루엣 축소',
    '하체 정렬이 불안정해 보임': '하체 정렬 안정',
    '종아리 라인이 휘어 보임': '종아리 실루엣이 길고 가늘게 보임',
    '종아리 두께 증가': '종아리 두께 감소',
    '하체 라인 처짐': '하체 라인 탄력 개선',
    '하체 전반이 경직돼 보임': '하체 경직 완화',
    '허벅지 바깥쪽 살이 더 도드라져 보임': '허벅지 외측 라인 정리',
    // 발·발목
    '발목이 굵어 보임': '발목 라인 슬림화',
    '종아리 안쪽 살이 도드라져 보임': '종아리 안쪽 라인 정리',
    '발목 바깥쪽 라인이 돌출돼 보임': '발목 바깥 라인 정리',
    '발 두께가 강조돼 둔해 보임': '발목 두께 감소',
  };

export const POSTURE_DISCOMFORT_MAP: Record<string, string[]> = {
    // 목 가쪽굽힘
    'NECK_TILT_RIGHT': [
      '목 옆 뻐근함',
      '뒷목 압박',
      '관자 조임',
      '귀 옆 묵직함',
    ],
    'NECK_TILT_LEFT': [
      '목 옆 뻐근함',
      '뒷목 압박',
      '관자 조임',
      '귀 옆 묵직함',
    ],

    // 목 회전
    'NECK_ROTATION_RIGHT': [
      '회전 시 걸림',
      '팔로 퍼지는 묵직함',
      '상체 긴장',
      '한쪽 머리 욱신',
    ],
    'NECK_ROTATION_LEFT': [
      '회전 시 걸림',
      '팔로 퍼지는 묵직함',
      '상체 긴장',
      '한쪽 머리 욱신',
    ],

    // 거북목
    'TURTLE_NECK': [
      '뒷목 당김',
      '머리 무거움',
      '젖힐 때 압박',
    ],

    // 들임목
    'RAISED_NECK': [
      '목 뒤 중심부 답답함',
      '목 뻣뻣함',
      '뒷머리 욱신',
    ],

    // 일자목
    'STRAIGHT_NECK': [
      '뒷목 당김',
      '머리 무거움',
      '젖힐 때 압박',
    ],

    // 어깨높이 비대칭: BODY_TYPE_DISCOMFORT_LIST fallback 사용

    // 올라간 어깨
    'RAISED_SHOULDER_RIGHT': [
      '어깨 앞쪽 관절 걸림',
      '어깨 앞쪽 근육 당김',
      '어깨 관절 깊은 피로',
    ],
    'RAISED_SHOULDER_LEFT': [
      '팔 들 때 어깨 전체 무거움',
      '팔꿈치 뒤쪽→어깨 뒤 당김',
      '어깨 관절 깊은 피로',
    ],
    'RAISED_SHOULDER_BOTH': [
      '어깨 앞쪽 관절 걸림',
      '팔 들 때 어깨 전체 무거움',
      '어깨 관절 깊은 피로',
    ],

    // 처진 어깨
    'DROPPED_SHOULDER_RIGHT': [
      '어깨 관절 깊은 둔함',
      '등 중앙·견갑 사이 압박',
      '어깨 뒤 근육 뻐근함',
    ],
    'DROPPED_SHOULDER_LEFT': [
      '어깨 뒤 근육 뻐근함',
      '어깨 깊은 조임·둔함',
      '어깨 앞·위 찌르는 불편',
    ],
    'DROPPED_SHOULDER_BOTH': [
      '어깨 관절 깊은 둔함',
      '등 중앙·견갑 사이 압박',
      '어깨 깊은 조임·둔함',
    ],

    // 라운드숄더
    'ROUNDED_SHOULDER': [
      '어깨 깊은 둔한 불편',
      '어깨 앞쪽 압박',
      '어깨 바깥 깊은 무거움',
    ],

    // 과도하게 펴진 어깨
    'STRAIGHT_SHOULDER': [
      '어깨 바깥 걸림',
      '목-어깨 경계 묵직함',
      '상체 전반 경직감',
    ],

    // 안으로 돌아간 팔
    'ARMS_TURNED_IN_RIGHT': [
      '팔꿈치 안쪽 당김',
      '팔꿈치 안쪽 저림',
      '손바닥 저림',
    ],
    'ARMS_TURNED_IN_LEFT': [
      '팔꿈치 뻣뻣함',
      '팔꿈치 바깥 당김',
      '팔꿈치 뒤쪽 당김',
    ],
    'ARMS_TURNED_IN_BOTH': [
      '팔꿈치 안쪽 당김',
      '팔꿈치 바깥 당김',
      '손바닥 저림',
    ],

    // 바깥으로 돌아간 팔
    'ARMS_TURNED_OUT_RIGHT': [
      '끝까지 펼 때 뻣뻣함',
      '손 저림·피로',
      '팔 전체 긴장감',
    ],
    'ARMS_TURNED_OUT_LEFT': [
      '끝까지 펼 때 뻣뻣함',
      '손 저림·피로',
      '팔 전체 긴장감',
    ],
    'ARMS_TURNED_OUT_BOTH': [
      '끝까지 펼 때 뻣뻣함',
      '손 저림·피로',
      '팔 전체 긴장감',
    ],

    // 굽혀진 팔꿈치
    'BENT_ELBOW_RIGHT': [
      '골반 한쪽 묵직함',
      '허리 옆쪽 뻐근함',
      '회전 마지막 구간에서 허리 부담감',
    ],
    'BENT_ELBOW_LEFT': [
      '허리 불안정 묵직함',
      '엉덩이→다리 묵직함',
      '허리 동반 불편',
    ],
    'BENT_ELBOW_BOTH': [
      '허리 옆쪽 뻐근함',
      '허리 불안정 묵직함',
      '엉덩이→다리 묵직함',
    ],

    // 과하게 펴진 팔꿈치
    'EXTENDED_ELBOW_RIGHT': [
      '허리 근육 피로',
      '허리 깊은 압박',
      '앞으로 숙일 때 허리 눌리는 느낌',
    ],
    'EXTENDED_ELBOW_LEFT': [
      '허리 뒤쪽 뻐근함',
      '허리 뒤 근육 당김',
      '굽힘/폄 시 허리 불편',
    ],
    'EXTENDED_ELBOW_BOTH': [
      '허리 근육 피로',
      '허리 뒤쪽 뻐근함',
      '허리 뒤 근육 당김',
    ],

    // 굽은등
    'HUNCHED_BACK': [
      '허리 젖힐 때 답답한 느낌',
      '뒤로 젖힐 때 압박',
      '허리 전반 경직',
    ],

    // 펴진 등
    'FLAT_BACK': [
      '뒤로 젖힐 때 균형 불편',
      '허리 전반 경직',
      '허리 동작 제한',
    ],

    // 골반 전방경사
    'PELVIS_TILTS_FORWARD': [
      '엉덩관절이 딱딱 걸림',
      '엉덩이 바깥쪽 당김',
      '엉덩관절 깊은 압박',
    ],

    // 골반 후방경사
    'PELVIS_TILTS_BACKWARD': [
      '골반 옆 묵직함',
      '골반 뒤 가운데가 눌리는 느낌',
      '골반 뒤쪽 불편',
    ],

    // 기울어진 몸통
    'TORSO_TILTED_RIGHT': [
      '엉덩관절 안쪽 걸림 느낌',
      '허리 동반 불편',
      '엉덩관절 깊은 둔함',
    ],
    'TORSO_TILTED_LEFT': [
      '바깥 회전 시 깊은 걸림',
      '엉덩관절 회전 중 딸깍 느낌',
      '허리 동반 불편',
    ],

    // 회전된 몸통
    'TORSO_ROTATION_RIGHT': [
      '엉덩회전 시 둔한 불편',
      '허벅지 옆 당김',
      '안쪽 회전 시 압박감',
    ],
    'TORSO_ROTATION_LEFT': [
      '회전 범위 감소',
      '골반 안쪽 불편',
      '허리-다리 묵직함',
    ],

    // 스웨이백
    'SWAY_BACK': [
      '엉덩이→다리 묵직함',
      '발 안쪽 저림',
      '다리 들 때 깊은 압박',
      '발목 안쪽 불안',
      '허리 옆쪽 뻐근함',
      '허리 좌우 비대칭 뻐근함',
      '회전 마지막 구간에서 허리 부담감',
      '골반 한쪽 묵직함',
      '허리 불안정 묵직함',
    ],

    // 골반 비대칭: BODY_TYPE_DISCOMFORT_LIST fallback 사용

    // 골반 회전
    'PELVIS_ROTATION_RIGHT': [
      '무릎 안쪽 걸림',
      '무릎 앞 둔함',
      '무릎 전반 경직',
    ],
    'PELVIS_ROTATION_LEFT': [
      '무릎 굽힘 경직',
      '무릎 아래 당김',
      '무릎 앞 당김',
    ],

    // 이동된 골반
    'PELVIS_MOVE_RIGHT': [
      '무릎 안쪽 불안정',
      '무릎 펴는 중 걸림',
      '발목 안쪽 불안',
    ],
    'PELVIS_MOVE_LEFT': [
      '발목 안쪽 불안',
      '발 안쪽 저림',
      '무릎 안쪽 불안정',
    ],

    // 바깥으로 돌아간 다리
    'LEGS_TURNED_OUTWARD_RIGHT': [
      '엄지 안쪽 압박',
      '발바닥 중앙 피로',
      '발목 바깥 불안',
    ],
    'LEGS_TURNED_OUTWARD_LEFT': [
      '발가락 사이 찌릿',
      '발목이 뻑뻑한 느낌',
      '보행 시 발바닥 피로',
    ],
    'LEGS_TURNED_OUTWARD_BOTH': [
      '엄지 안쪽 압박',
      '발가락 사이 찌릿',
      '발목이 뻑뻑한 느낌',
    ],

    // 안으로 돌아간 다리
    'LEGS_TURNED_INWARD_RIGHT': [
      '발목 앞 압박',
      '종아리 아래 당김',
      '발목 전반 경직',
    ],
    'LEGS_TURNED_INWARD_LEFT': [
      '발목 전반 경직',
      '발 저림',
      '발바닥 중앙 뻐근함',
    ],
    'LEGS_TURNED_INWARD_BOTH': [
      '발목 앞 압박',
      '발 저림',
      '발바닥 중앙 뻐근함',
    ],

    // 오다리 (바깥)
    'BOW_LEGS_EXTERNAL_RIGHT': [
      '뒤꿈치 당김',
      '발가락 저림',
      '발목 깊은 곳의 둔한 불편감',
    ],
    'BOW_LEGS_EXTERNAL_LEFT': [
      '눈이 흐릿함',
      '머리가 어지러움',
      '잠들기 어렵거나 자주 깸',
      '눈 주변 뻐근함',
    ],
    'BOW_LEGS_EXTERNAL_BOTH': [
      '뒤꿈치 당김',
      '발가락 저림',
      '발목 깊은 곳의 둔한 불편감',
    ],

    // 오다리 (안)
    'BOW_LEGS_INTERNAL_RIGHT': [
      '아래턱 통증',
      '턱에서 소리 남',
      '턱이 잘 안 벌어짐',
      '얼굴 좌우 비대칭',
      '어깨 주변 저릿함',
    ],
    'BOW_LEGS_INTERNAL_LEFT': [
      '등 라인 통증',
      '등이 저릿함',
      '어깨 저릿함',
      '어깨 움직일 때 소리',
      '어깨 힘줄 부기',
    ],
    'BOW_LEGS_INTERNAL_BOTH': [
      '아래턱 통증',
      '턱에서 소리 남',
      '턱이 잘 안 벌어짐',
      '등 라인 통증',
      '어깨 저릿함',
    ],

    // 엑스다리
    'KNOCK_LEGS_RIGHT': [
      '전신 피로감 큼',
      '숨이 깊게 안 쉬어짐',
      '숨쉬기 답답함',
      '속이 울렁거림',
      '다리가 차갑게 느낌',
    ],
    'KNOCK_LEGS_LEFT': [
      '걸을 때 절뚝거림',
      '무릎에 물 참',
      '무릎에 힘 빠짐',
      '발목이 뜨거운 느낌',
      '손·발 피부색 변화',
    ],
    'KNOCK_LEGS_BOTH': [
      '전신 피로감 큼',
      '숨쉬기 답답함',
      '걸을 때 절뚝거림',
      '무릎에 힘 빠짐',
      '손·발 피부색 변화',
    ],

    // 무릎
    'BACK_KNEES': [
      '무릎 아래 당김',
      '무릎 안쪽 걸림',
      '무릎 굽힘 경직',
      '무릎에 부종',
      '무릎 앞 둔함',
      '계단 이용 불편',
      '무릎 펴는 중 걸림',
      '걸을 때 절뚝거림',
      '무릎에 물 참',
    ],
    'BENT_KNEES': [
      '무릎 앞 둔함',
      '걸을 때 절뚝거림',
      '무릎 굽힘 경직',
      '무릎에 물 참',
      '계단 이용 불편',
      '무릎 펴는 중 걸림',
      '무릎에 부종',
    ],

    // 평발
    'FLAT_FEET_RIGHT': [
      '뒤꿈치 당김',
      '발바닥 중앙 피로',
      '종아리 아래 당김',
      '발목 안쪽 불안',
      '발 안쪽 저림',
      '발가락 사이 찌릿',
      '엄지 안쪽 압박',
      '발목 앞 압박',
    ],
    'FLAT_FEET_LEFT': [
      '뒤꿈치 당김',
      '발바닥 중앙 피로',
      '종아리 아래 당김',
      '발목 안쪽 불안',
      '발 안쪽 저림',
      '발가락 사이 찌릿',
      '엄지 안쪽 압박',
      '발목 앞 압박',
    ],
    'FLAT_FEET_BOTH': [
      '뒤꿈치 당김',
      '발바닥 중앙 피로',
      '종아리 아래 당김',
      '발목 안쪽 불안',
      '발 안쪽 저림',
      '발가락 사이 찌릿',
      '엄지 안쪽 압박',
      '발목 앞 압박',
    ],

    // 오목발
    'ARCHED_FEET_RIGHT': [
      '발목 바깥 불안',
      '발목이 뻑뻑한 느낌',
      '발목이 뜨거운 느낌',
      '보행 시 발바닥 피로',
      '발가락 사이 찌릿',
      '발바닥 중앙 피로',
      '뒤꿈치 당김',
    ],
    'ARCHED_FEET_LEFT': [
      '발목 바깥 불안',
      '발목이 뻑뻑한 느낌',
      '발목이 뜨거운 느낌',
      '보행 시 발바닥 피로',
      '발가락 사이 찌릿',
      '발바닥 중앙 피로',
      '뒤꿈치 당김',
    ],
    'ARCHED_FEET_BOTH': [
      '발목 바깥 불안',
      '발목이 뻑뻑한 느낌',
      '발목이 뜨거운 느낌',
      '보행 시 발바닥 피로',
      '발가락 사이 찌릿',
      '발바닥 중앙 피로',
      '뒤꿈치 당김',
    ],
  };

export const POSTURE_SYMPTOM_IMPROVEMENTS: Record<string, string[]> = {
    NECK_TILT: ['목 압통 완화', '목 가동범위 회복', '목 근육 이완', '두통 완화'],
    NECK_ROTATION: ['목 가동범위 회복', '목 경직 완화', '두통 완화', '어지럼 증상 완화'],
    TURTLE_NECK: ['목 압통 완화', '목 가동범위 회복', '목 근육 이완', '두통 완화', '어지럼 증상 완화'],
    STRAIGHT_NECK: ['목 경직 완화', '목 신전 시 통증 완화', '목 가동범위 회복', '두통 완화'],
    RAISED_NECK: ['목 압통 완화', '목 근육 이완', '두통 완화', '호흡 기능 개선'],
    SHOULDER_HEIGHT_ASYMMETRY: ['어깨 통증 완화', '어깨 압통 완화', '상체 긴장 완화'],
    RAISED_SHOULDER: ['어깨 통증 완화', '어깨 압통 완화', '상체 긴장 완화', '두통 완화'],
    DROPPED_SHOULDER: ['어깨 통증 완화', '어깨 안정성 회복', '팔 신경 증상 완화'],
    ROUNDED_SHOULDER: ['어깨 통증 완화', '어깨 저림 완화', '팔 신경 증상 완화', '등 통증 완화', '호흡 기능 개선'],
    STRAIGHT_SHOULDER: ['등 통증 완화', '호흡 기능 개선', '상체 긴장 완화'],
    ARMS_TURNED_IN: ['어깨 통증 완화', '팔 가동범위 회복', '상체 긴장 완화'],
    ARMS_TURNED_OUT: ['어깨 통증 완화', '팔 가동범위 회복', '상체 긴장 완화'],
    BENT_ELBOW: ['팔꿈치 통증 완화', '팔 가동범위 회복', '상체 긴장 완화'],
    EXTENDED_ELBOW: ['팔꿈치 통증 완화', '팔 가동범위 회복', '상체 긴장 완화'],
    HUNCHED_BACK: ['등 통증 완화', '호흡 기능 개선', '목 압통 완화', '전신 피로도 감소'],
    FLAT_BACK: ['등 통증 완화', '호흡 기능 개선', '상체 긴장 완화'],
    PELVIS_TILTS_FORWARD: ['허리 통증 완화', '허리 경직 완화', '골반 통증 완화'],
    PELVIS_TILTS_BACKWARD: ['허리 통증 완화', '허리 가동성 회복', '골반 통증 완화'],
    TORSO_TILTED_RIGHT: ['허리 통증 완화', '골반 통증 완화', '하지 가동성 회복'],
    TORSO_TILTED_LEFT: ['허리 통증 완화', '골반 통증 완화', '하지 가동성 회복'],
    TORSO_ROTATION_LEFT: ['허리 통증 완화', '골반 통증 완화', '호흡 기능 개선'],
    TORSO_ROTATION_RIGHT: ['허리 통증 완화', '골반 통증 완화', '호흡 기능 개선'],
    SWAY_BACK: ['허리 통증 완화', '허리 가동성 회복', '전신 피로도 감소'],
    PELVIS_ASYMMETRY: ['허리 통증 완화', '골반 통증 완화', '보행 안정성 회복', '하지 부종 완화'],
    PELVIS_ROTATION_LEFT: ['골반 통증 완화', '허리 통증 완화', '하지 부종 완화'],
    PELVIS_ROTATION_RIGHT: ['골반 통증 완화', '허리 통증 완화', '하지 부종 완화'],
    PELVIS_MOVE_RIGHT: ['골반 통증 완화', '허리 통증 완화', '보행 안정성 회복'],
    PELVIS_MOVE_LEFT: ['골반 통증 완화', '허리 통증 완화', '보행 안정성 회복'],
    LEGS_TURNED_OUTWARD: ['무릎 통증 완화', '하지 가동성 회복', '보행 안정성 회복'],
    LEGS_TURNED_INWARD: ['무릎 통증 완화', '하지 가동성 회복', '보행 안정성 회복'],
    BOW_LEGS: ['무릎 통증 완화', '무릎 안정성 회복', '하지 가동성 회복', '발목 통증 완화'],
    KNOCK_LEGS: ['무릎 통증 완화', '무릎 압통 완화', '무릎 안정성 회복'],
    BACK_KNEES: ['무릎 통증 완화', '하지 경직 완화', '무릎 안정성 회복'],
    BENT_KNEES: ['무릎 통증 완화', '무릎 가동범위 회복', '하지 가동성 회복'],
    FLAT_FEET: ['발목 통증 완화', '발바닥 통증 완화', '발목 안정성 회복', '발 신경 증상 완화'],
    ARCHED_FEET: ['발목 통증 완화', '발바닥 통증 완화', '발목 안정성 회복', '발 신경 증상 완화'],
  };

export const MANAGEMENT_RECOMMENDATION_BY_SCORE: Array<{
    min: number;
    max: number;
    text: string;
  }> = [
    { min: 81, max: 100, text: '현재 컨디션 유지를 위해 주 2회 이상 규칙적인 운동을 권장드립니다.' },
    { min: 71, max: 80, text: '현재 상태 개선을 위해 주 2회 이상 체계적인 운동이 필요합니다.' },
    { min: 61, max: 70, text: '신체 회복을 위해 주 2회 이상 지속적인 관리가 요구됩니다.' },
    { min: 51, max: 60, text: '현재 상태에서는 주 3회 이상 관리가 필수적입니다.' },
    { min: 31, max: 50, text: '신체 기능 회복을 위해 주 3회 이상 집중 관리가 권장됩니다.' },
    { min: 0, max: 30, text: '상태 개선을 위해 주 3회 이상 전문적인 관리가 필요합니다.' },
  ];

export const BALANCE_STATE_RULES: Array<{
    min: number;
    max: number;
    stage: number;
    label: string;
    description: string;
  }> = [
    {
      min: 81,
      max: 100,
      stage: 1,
      label: '양호',
      description: '체중심이 중앙에 안정적으로 위치해 있으며, 정적인 자세와 동적인 움직임 모두에서 중앙 정렬이 잘 유지되는 상태입니다. 이 단계에서는 체중심 붕괴 없이 운동을 수행할 수 있어, 퍼포먼스 중심의 트레이닝도 안정적으로 진행 가능합니다.',
    },
    {
      min: 71,
      max: 80,
      stage: 2,
      label: '경미',
      description: '체중심이 중앙에 비교적 안정적으로 유지되고 있습니다. 서 있거나 움직일 때도 체중이 한쪽으로 크게 쏠리지 않으며, 기본적인 정렬이 잘 유지되는 단계입니다. 다만 일상 습관이나 피로 누적에 따라 미세한 이탈이 생길 수 있으므로, 중앙 정렬을 유지하는 기본 운동을 지속하는 것이 좋습니다.',
    },
    {
      min: 61,
      max: 70,
      stage: 3,
      label: '주의',
      description: '체중심이 중앙에서 아주 미세하게 어긋나 있는 상태입니다. 겉보기에는 큰 문제 없이 움직일 수 있으나, 자세를 유지할수록 중앙에서 벗어난 방향으로 체중이 쌓이는 경향이 나타날 수 있습니다. 이 단계에서는 체중심을 중앙에 두는 감각을 정확히 인지하는 것이 중요합니다.',
    },
    {
      min: 51,
      max: 60,
      stage: 4,
      label: '경계',
      description: '체중심이 중앙에서 벗어나 있긴 하나, 앞·뒤·좌·우 이탈 폭은 아직 관리 가능한 범위에 해당합니다. 다만 현재 패턴이 반복될 경우, 체중심이 점점 한 방향으로 굳어질 가능성이 있습니다. 이 단계에서는 중앙 정렬을 유지한 상태에서의 동작 학습이 핵심입니다.',
    },
    {
      min: 31,
      max: 50,
      stage: 5,
      label: '심각',
      description: '체중심이 중앙에 머무르지 못하고, 앞·뒤 또는 좌·우 중 한 방향으로 고정된 패턴으로 어긋나 있는 단계입니다. 서 있거나 움직일 때도 체중심이 자연스럽게 중앙으로 돌아오지 않아, 정렬 유지 없이 동작이 진행되는 경향이 나타납니다. 이 단계에서는 체중심을 다시 중앙에 세우는 기준부터 재설정하는 접근이 필요합니다.',
    },
    {
      min: 0,
      max: 30,
      stage: 6,
      label: '위험',
      description: '현재 체중심이 중앙에서 크게 벗어나 있으며, 앞·뒤 또는 좌·우 한 방향으로 뚜렷하게 치우친 상태가 확인됩니다. 이 상태에서는 체중을 중앙에 유지한 채 움직이기 어려워, 운동 수행 시 정렬 유지가 가장 먼저 무너지는 단계입니다. 트레이닝 적용 전, 체중심을 중앙으로 인식하고 유지하는 능력부터 점검하는 것이 필요합니다.',
    },
  ];

export const BODY_PART_SCORE_STAGE_RULES = [
    { min: 81, max: 100, stage: 1, label: '정상',  referenceScore: 5  },
    { min: 71, max: 80,  stage: 2, label: '양호',  referenceScore: 15 },
    { min: 61, max: 70,  stage: 3, label: '주의',  referenceScore: 25 },
    { min: 51, max: 60,  stage: 4, label: '경계',  referenceScore: 40 },
    { min: 31, max: 50,  stage: 5, label: '심각',  referenceScore: 55 },
    { min: 0,  max: 30,  stage: 6, label: '위험',  referenceScore: 62 },
  ];

export const MUSCLE_BALANCE_DB: Record<number, {
    type1Label: string;
    type2Label: string | null;
    overactiveItems: string[];
    underactiveItems: string[];
  }> = {
    // ── 유형1: 골반 오른쪽 이동 ────────────────────────────────
    1: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      overactiveItems: [
        '오른쪽 긴모음근', '오른쪽 짧은모음근', '오른쪽 큰모음근', '오른쪽 넙다리근막긴장근',
        '오른쪽 넙다리두갈래근-단두', '오른쪽 장딴지근-가쪽갈래', '오른쪽 긴종아리근',
        '왼쪽 궁둥구멍근', '왼쪽 넙다리두갈래근-장두', '왼쪽 허리네모근',
        '왼쪽 중간볼기근-후면섬유', '왼쪽 넙다리근막긴장근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근', '오른쪽 큰볼기근', '오른쪽 안쪽넓은근', '오른쪽 뒤정강근',
        '왼쪽 긴모음근', '왼쪽 큰모음근', '왼쪽 짧은모음근',
      ],
    },
    2: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '양쪽 발 벌림',
      overactiveItems: [
        '오른쪽 가자미근', '오른쪽 장딴지근-가쪽갈래', '오른쪽 넙다리두갈래근-단두',
        '오른쪽 긴모음근', '오른쪽 큰모음근', '오른쪽 긴종아리근', '오른쪽 넙다리근막긴장근',
        '왼쪽 가자미근', '왼쪽 장딴지근-가쪽갈래', '왼쪽 넙다리두갈래근-장두',
        '왼쪽 궁둥구멍근', '왼쪽 허리네모근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근', '오른쪽 큰볼기근', '오른쪽 안쪽넓은근',
        '오른쪽 장딴지근-안쪽갈래', '오른쪽 뒤정강근',
        '왼쪽 중간볼기근', '왼쪽 안쪽넓은근', '왼쪽 장딴지근-안쪽갈래', '왼쪽 큰모음근',
      ],
    },
    3: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      overactiveItems: [
        '오른쪽 앞정강근', '오른쪽 뒤정강근', '오른쪽 궁둥구멍근', '오른쪽 큰볼기근', '오른쪽 넙다리두갈래근',
        '왼쪽 긴종아리근', '왼쪽 짧은종아리근', '왼쪽 장딴지근-가쪽갈래',
        '왼쪽 넙다리근막긴장근', '왼쪽 작은볼기근', '왼쪽 긴모음근',
      ],
      underactiveItems: [
        '오른쪽 긴종아리근', '오른쪽 짧은종아리근', '오른쪽 작은볼기근', '오른쪽 큰모음근', '오른쪽 넙다리근막긴장근',
        '왼쪽 뒤정강근 (아치 지지 실패)', '왼쪽 앞정강근',
        '왼쪽 중간볼기근 (특히 후면 섬유)', '왼쪽 큰볼기근', '왼쪽 궁둥구멍근',
      ],
    },
    4: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '오른쪽 장딴지근', '오른쪽 가자미근', '오른쪽 긴모음근', '오른쪽 큰모음근',
        '오른쪽 넙다리근막긴장근', '오른쪽 엉덩허리근', '오른쪽 배곧은근',
        '왼쪽 장딴지근', '왼쪽 가자미근', '왼쪽 궁둥구멍근', '왼쪽 넙다리두갈래근', '왼쪽 허리네모근',
      ],
      underactiveItems: [
        '오른쪽 앞정강근', '오른쪽 큰볼기근', '오른쪽 중간볼기근', '오른쪽 척추세움근',
        '왼쪽 긴모음근', '왼쪽 큰모음근', '왼쪽 앞정강근',
      ],
    },
    5: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '오른쪽 골반 높이 상승',
      overactiveItems: [
        '오른쪽 허리네모근', '오른쪽 모음근', '오른쪽 넙다리근막긴장근', '오른쪽 척추세움근',
        '왼쪽 중간볼기근', '왼쪽 넙다리근막긴장근', '왼쪽 엉덩허리근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근', '오른쪽 큰볼기근',
        '왼쪽 허리네모근', '왼쪽 모음근',
      ],
    },
    6: {
      type1Label: '골반 오른쪽 이동',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '오른쪽 모음근', '오른쪽 넙다리네갈래근', '오른쪽 중간볼기근',
        '왼쪽 중간볼기근', '왼쪽 큰볼기근',
      ],
      underactiveItems: [
        '왼쪽 넙다리두갈래근', '왼쪽 장딴지근', '왼쪽 가자미근',
      ],
    },
    7: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      overactiveItems: [
        '왼쪽 긴모음근', '왼쪽 짧은모음근', '왼쪽 큰모음근', '왼쪽 넙다리근막긴장근',
        '왼쪽 넙다리두갈래근-단두', '왼쪽 장딴지근-가쪽갈래', '왼쪽 긴종아리근',
        '오른쪽 궁둥구멍근', '오른쪽 넙다리두갈래근-장두', '오른쪽 허리네모근',
        '오른쪽 중간볼기근-후면섬유', '오른쪽 넙다리근막긴장근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근', '왼쪽 큰볼기근', '왼쪽 안쪽넓은근', '왼쪽 뒤정강근',
        '오른쪽 긴모음근', '오른쪽 큰모음근', '오른쪽 짧은모음근',
      ],
    },
    8: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '양쪽 발 벌림',
      overactiveItems: [
        '왼쪽 가자미근', '왼쪽 장딴지근-가쪽갈래', '왼쪽 넙다리두갈래근-단두',
        '왼쪽 긴모음근', '왼쪽 큰모음근', '왼쪽 긴종아리근', '왼쪽 넙다리근막긴장근',
        '오른쪽 가자미근', '오른쪽 장딴지근-가쪽갈래', '오른쪽 넙다리두갈래근-장두',
        '오른쪽 궁둥구멍근', '오른쪽 허리네모근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근', '왼쪽 큰볼기근', '왼쪽 안쪽넓은근',
        '왼쪽 장딴지근-안쪽갈래', '왼쪽 뒤정강근',
        '오른쪽 중간볼기근', '오른쪽 안쪽넓은근', '오른쪽 장딴지근-안쪽갈래', '오른쪽 큰모음근',
      ],
    },
    9: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      overactiveItems: [
        '왼쪽 앞정강근', '왼쪽 뒤정강근', '왼쪽 궁둥구멍근', '왼쪽 큰볼기근', '왼쪽 넙다리두갈래근',
        '오른쪽 긴종아리근', '오른쪽 짧은종아리근', '오른쪽 장딴지근-가쪽갈래',
        '오른쪽 넙다리근막긴장근', '오른쪽 작은볼기근', '오른쪽 긴모음근',
      ],
      underactiveItems: [
        '왼쪽 긴종아리근', '왼쪽 짧은종아리근', '왼쪽 작은볼기근', '왼쪽 큰모음근', '왼쪽 넙다리근막긴장근',
        '오른쪽 뒤정강근 (아치 지지 실패)', '오른쪽 앞정강근',
        '오른쪽 중간볼기근 (특히 후면 섬유)', '오른쪽 큰볼기근', '오른쪽 궁둥구멍근',
      ],
    },
    10: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '왼쪽 장딴지근', '왼쪽 가자미근', '왼쪽 긴모음근', '왼쪽 큰모음근',
        '왼쪽 넙다리근막긴장근', '왼쪽 엉덩허리근', '왼쪽 배곧은근',
        '오른쪽 장딴지근', '오른쪽 가자미근', '오른쪽 궁둥구멍근', '오른쪽 넙다리두갈래근', '오른쪽 허리네모근',
      ],
      underactiveItems: [
        '왼쪽 앞정강근', '왼쪽 큰볼기근', '왼쪽 중간볼기근', '왼쪽 척추세움근',
        '오른쪽 긴모음근', '오른쪽 큰모음근', '오른쪽 앞정강근',
      ],
    },
    11: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '왼쪽 골반 높이 상승',
      overactiveItems: [
        '왼쪽 허리네모근', '왼쪽 모음근', '왼쪽 넙다리근막긴장근', '왼쪽 척추세움근',
        '오른쪽 중간볼기근', '오른쪽 넙다리근막긴장근', '오른쪽 엉덩허리근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근', '왼쪽 큰볼기근',
        '오른쪽 허리네모근', '오른쪽 모음근',
      ],
    },
    12: {
      type1Label: '골반 왼쪽 이동',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '왼쪽 모음근', '왼쪽 넙다리네갈래근', '왼쪽 중간볼기근',
        '오른쪽 중간볼기근', '오른쪽 큰볼기근',
      ],
      underactiveItems: [
        '오른쪽 넙다리두갈래근', '오른쪽 장딴지근', '오른쪽 가자미근',
      ],
    },
    // ── 유형1: 오른쪽 무릎 안굽이(varus) / 왼쪽 무릎 밖굽이(valgus) ──
    13: {
      type1Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      type2Label: '오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      overactiveItems: [
        '왼쪽 모음근', '왼쪽 종아리근', '왼쪽 넙다리근막긴장근', '왼쪽 장딴지근-가쪽갈래',
        '오른쪽 넙다리근막긴장근 & 넙다리두갈래근', '오른쪽 궁둥구멍근', '오른쪽 뒤정강근 & 앞정강근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근 & 큰볼기근', '왼쪽 뒤정강근', '왼쪽 안쪽넓은근',
        '오른쪽 모음근', '오른쪽 종아리근',
      ],
    },
    14: {
      type1Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      type2Label: '왼쪽 골반 높이 상승',
      overactiveItems: [
        '왼쪽 허리네모근', '왼쪽 모음근', '왼쪽 넙다리근막긴장근', '왼쪽 종아리근',
        '오른쪽 넙다리근막긴장근 & 넙다리두갈래근', '오른쪽 궁둥구멍근', '오른쪽 뒤정강근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근 & 큰볼기근', '왼쪽 안쪽넓은근',
        '오른쪽 모음근', '오른쪽 중간볼기근', '오른쪽 허리네모근',
      ],
    },
    15: {
      type1Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 장딴지근 & 가자미근', '양쪽 엉덩허리근 & 배곧은근',
        '왼쪽 모음근', '왼쪽 넙다리근막긴장근', '왼쪽 종아리근',
        '오른쪽 넙다리근막긴장근 & 넙다리두갈래근', '오른쪽 궁둥구멍근',
      ],
      underactiveItems: [
        '양쪽 앞정강근', '양쪽 척추세움근',
        '왼쪽 중간볼기근 & 큰볼기근', '왼쪽 안쪽넓은근',
        '오른쪽 모음근',
      ],
    },
    16: {
      type1Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      type2Label: '왼쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '왼쪽 장딴지근 & 가자미근', '왼쪽 모음근', '왼쪽 넙다리근막긴장근',
        '오른쪽 넙다리근막긴장근 & 넙다리두갈래근', '오른쪽 궁둥구멍근',
      ],
      underactiveItems: [
        '왼쪽 앞정강근', '왼쪽 중간볼기근 & 큰볼기근',
        '오른쪽 모음근',
      ],
    },
    17: {
      type1Label: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '왼쪽 모음근', '왼쪽 넙다리근막긴장근', '왼쪽 넙다리두갈래근-짧은머리',
        '오른쪽 궁둥구멍근 & 깊은 엉덩관절 바깥돌림근', '오른쪽 넙다리근막긴장근 & 중간볼기근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근 & 큰볼기근',
        '오른쪽 모음근',
      ],
    },
    // ── 유형1: 양쪽 무릎 밖굽이(valgus) ─────────────────────────
    18: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '양쪽 발목 가쪽번짐',
      overactiveItems: [
        '양쪽 긴모음근', '양쪽 짧은모음근', '양쪽 큰모음근', '양쪽 넙다리근막긴장근',
        '양쪽 넙다리두갈래근-단두', '양쪽 장딴지근-가쪽갈래', '양쪽 긴종아리근',
      ],
      underactiveItems: [
        '양쪽 중간볼기근', '양쪽 큰볼기근', '양쪽 안쪽넓은근', '양쪽 뒤정강근',
      ],
    },
    19: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '양쪽 발 벌림',
      overactiveItems: [
        '양쪽 장딴지근-가쪽갈래', '양쪽 가자미근', '양쪽 긴종아리근', '양쪽 짧은종아리근',
        '양쪽 넙다리두갈래근-단두', '양쪽 넙다리근막긴장근', '양쪽 긴모음근', '양쪽 큰모음근',
      ],
      underactiveItems: [
        '양쪽 중간볼기근', '양쪽 큰볼기근', '양쪽 장딴지근-안쪽갈래',
        '양쪽 안쪽넓은근', '양쪽 뒤정강근', '양쪽 앞정강근',
      ],
    },
    20: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '오른쪽 골반 높이 상승',
      overactiveItems: [
        '오른쪽 허리네모근', '오른쪽 척추세움근', '오른쪽 긴모음근', '오른쪽 큰모음근',
        '오른쪽 넙다리근막긴장근', '오른쪽 넓은등근',
        '왼쪽 긴모음근', '왼쪽 큰모음근', '왼쪽 넙다리근막긴장근', '왼쪽 넙다리두갈래근-단두',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근', '오른쪽 큰볼기근', '오른쪽 배속빗근',
        '왼쪽 허리네모근', '왼쪽 중간볼기근', '왼쪽 큰볼기근',
      ],
    },
    21: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '왼쪽 골반 높이 상승',
      overactiveItems: [
        '오른쪽 긴모음근', '오른쪽 큰모음근', '오른쪽 짧은모음근',
        '오른쪽 넙다리근막긴장근', '오른쪽 넙다리두갈래근-단두',
        '왼쪽 허리네모근', '왼쪽 척추세움근', '왼쪽 긴모음근', '왼쪽 큰모음근',
        '왼쪽 넙다리근막긴장근', '왼쪽 넓은등근',
      ],
      underactiveItems: [
        '오른쪽 허리네모근', '오른쪽 중간볼기근', '오른쪽 큰볼기근', '오른쪽 안쪽넓은근',
        '왼쪽 중간볼기근', '왼쪽 큰볼기근', '왼쪽 배속빗근',
      ],
    },
    22: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 장딴지근 & 가자미근', '양쪽 긴모음근 & 큰모음근', '양쪽 넙다리근막긴장근',
        '양쪽 엉덩허리근 & 넙다리곧은근', '양쪽 배곧은근',
      ],
      underactiveItems: [
        '양쪽 앞정강근', '양쪽 중간볼기근', '양쪽 큰볼기근', '양쪽 척추세움근',
      ],
    },
    23: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '상체 과도한 뒤로 젖힘',
      overactiveItems: [
        '양쪽 척추세움근', '양쪽 엉덩허리근', '양쪽 긴모음근 & 큰모음근',
        '양쪽 넙다리근막긴장근', '양쪽 장딴지근 & 가자미근',
      ],
      underactiveItems: [
        '양쪽 배곧은근', '양쪽 배가로근 & 배속빗근', '양쪽 중간볼기근', '양쪽 큰볼기근',
      ],
    },
    24: {
      type1Label: '양쪽 무릎 밖굽이',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '양쪽 모음근 그룹', '양쪽 넙다리근막긴장근', '양쪽 넙다리두갈래근-단두', '양쪽 장딴지근-가쪽갈래',
      ],
      underactiveItems: [
        '양쪽 중간볼기근', '양쪽 큰볼기근',
      ],
    },
    // ── 유형1: 오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 ─────────────
    25: {
      type1Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      type2Label: '오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      overactiveItems: [
        '오른쪽 모음근', '오른쪽 종아리근', '오른쪽 넙다리근막긴장근', '오른쪽 장딴지근-가쪽갈래',
        '왼쪽 넙다리근막긴장근 & 넙다리두갈래근', '왼쪽 궁둥구멍근', '왼쪽 뒤정강근 & 앞정강근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근 & 큰볼기근', '오른쪽 뒤정강근', '오른쪽 안쪽넓은근',
        '왼쪽 모음근', '왼쪽 종아리근',
      ],
    },
    26: {
      type1Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      type2Label: '오른쪽 골반 높이 상승',
      overactiveItems: [
        '오른쪽 허리네모근', '오른쪽 모음근', '오른쪽 넙다리근막긴장근', '오른쪽 종아리근',
        '왼쪽 넙다리근막긴장근 & 넙다리두갈래근', '왼쪽 궁둥구멍근', '왼쪽 뒤정강근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근 & 큰볼기근', '오른쪽 안쪽넓은근',
        '왼쪽 모음근', '왼쪽 중간볼기근', '왼쪽 허리네모근',
      ],
    },
    27: {
      type1Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 장딴지근 & 가자미근', '양쪽 엉덩허리근 & 배곧은근',
        '오른쪽 모음근', '오른쪽 넙다리근막긴장근', '오른쪽 종아리근',
        '왼쪽 넙다리근막긴장근 & 넙다리두갈래근', '왼쪽 궁둥구멍근',
      ],
      underactiveItems: [
        '양쪽 앞정강근', '양쪽 척추세움근',
        '오른쪽 중간볼기근 & 큰볼기근', '오른쪽 안쪽넓은근',
        '왼쪽 모음근',
      ],
    },
    28: {
      type1Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      type2Label: '오른쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '오른쪽 장딴지근 & 가자미근', '오른쪽 모음근', '오른쪽 넙다리근막긴장근',
        '왼쪽 넙다리근막긴장근 & 넙다리두갈래근', '왼쪽 궁둥구멍근',
      ],
      underactiveItems: [
        '오른쪽 앞정강근', '오른쪽 중간볼기근 & 큰볼기근',
        '왼쪽 모음근',
      ],
    },
    29: {
      type1Label: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '오른쪽 모음근', '오른쪽 넙다리근막긴장근', '오른쪽 넙다리두갈래근-짧은머리',
        '왼쪽 궁둥구멍근 & 깊은 엉덩관절 바깥돌림근', '왼쪽 넙다리근막긴장근 & 중간볼기근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근 & 큰볼기근',
        '왼쪽 모음근',
      ],
    },
    // ── 유형1: 양쪽 어깨관절 굽힘 가동범위 제한 ──────────────────
    30: {
      type1Label: '양쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '상체 과도한 뒤로 젖힘',
      overactiveItems: [
        '양쪽 넓은등근', '양쪽 척추세움근', '양쪽 엉덩허리근 & 넙다리곧은근',
      ],
      underactiveItems: [
        '양쪽 앞쪽 코어 근육', '양쪽 등세모근 하부 & 앞톱니근',
      ],
    },
    31: {
      type1Label: '양쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '양쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '양쪽 넓은등근 & 큰원근', '양쪽 장딴지근 & 가자미근', '양쪽 엉덩허리근 & 넙다리곧은근',
      ],
      underactiveItems: [
        '양쪽 등세모근 하부 & 능형근', '양쪽 앞정강근', '양쪽 코어 근육 & 큰볼기근',
      ],
    },
    32: {
      type1Label: '양쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '왼쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '양쪽 넓은등근 & 큰가슴근', '오른쪽 모음근 & 넙다리네갈래근', '왼쪽 장딴지근 & 가자미근',
      ],
      underactiveItems: [
        '양쪽 등세모근 하부 & 앞톱니근', '왼쪽 앞정강근', '왼쪽 큰볼기근',
      ],
    },
    // ── 유형1: 오른쪽 어깨관절 굽힘 가동범위 제한 ────────────────
    33: {
      type1Label: '오른쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '상체 과도한 뒤로 젖힘',
      overactiveItems: [
        '오른쪽 넓은등근', '오른쪽 큰가슴근 & 작은가슴근', '오른쪽 어깨밑근', '오른쪽 큰원근',
        '양쪽 척추세움근', '양쪽 엉덩허리근',
      ],
      underactiveItems: [
        '오른쪽 등세모근-하부섬유', '오른쪽 앞톱니근', '오른쪽 가시위근',
        '양쪽 배곧은근', '양쪽 배속빗근 & 배바깥빗근',
      ],
    },
    34: {
      type1Label: '오른쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '골반 오른쪽 이동',
      overactiveItems: [
        '오른쪽 넓은등근', '오른쪽 큰가슴근 & 작은가슴근', '오른쪽 넙다리네갈래근', '오른쪽 모음근',
        '왼쪽 가자미근 & 장딴지근', '왼쪽 엉덩허리근 & 넙다리곧은근',
      ],
      underactiveItems: [
        '오른쪽 등세모근-하부섬유', '오른쪽 앞톱니근', '오른쪽 중간볼기근',
        '왼쪽 큰볼기근', '왼쪽 앞정강근',
      ],
    },
    35: {
      type1Label: '오른쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '오른쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '오른쪽 가자미근 & 장딴지근', '오른쪽 넓은등근',
        '오른쪽 큰가슴근 & 작은가슴근', '오른쪽 넙다리곧은근 & 엉덩허리근',
      ],
      underactiveItems: [
        '오른쪽 앞정강근', '오른쪽 등세모근-하부섬유', '오른쪽 앞톱니근',
      ],
    },
    36: {
      type1Label: '오른쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '오른쪽 넓은등근', '오른쪽 작은가슴근', '오른쪽 큰가슴근', '오른쪽 어깨밑근 & 큰원근',
      ],
      underactiveItems: [
        '오른쪽 등세모근-하부섬유', '오른쪽 앞톱니근', '오른쪽 가시위근 및 뒤쪽 회전근개',
      ],
    },
    // ── 유형1: 왼쪽 어깨관절 굽힘 가동범위 제한 ─────────────────
    37: {
      type1Label: '왼쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '상체 과도한 뒤로 젖힘',
      overactiveItems: [
        '왼쪽 넓은등근', '왼쪽 큰가슴근 & 작은가슴근', '왼쪽 어깨밑근', '왼쪽 큰원근',
        '양쪽 척추세움근', '양쪽 엉덩허리근',
      ],
      underactiveItems: [
        '왼쪽 등세모근-하부섬유', '왼쪽 앞톱니근', '왼쪽 가시위근',
        '양쪽 배곧은근', '양쪽 배속빗근 & 배바깥빗근',
      ],
    },
    38: {
      type1Label: '왼쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '골반 왼쪽 이동',
      overactiveItems: [
        '왼쪽 넓은등근', '왼쪽 큰가슴근 & 작은가슴근', '왼쪽 넙다리네갈래근', '왼쪽 모음근',
        '오른쪽 가자미근 & 장딴지근', '오른쪽 엉덩허리근 & 넙다리곧은근',
      ],
      underactiveItems: [
        '왼쪽 등세모근-하부섬유', '왼쪽 앞톱니근', '왼쪽 중간볼기근',
        '오른쪽 큰볼기근', '오른쪽 앞정강근',
      ],
    },
    39: {
      type1Label: '왼쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '왼쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '왼쪽 가자미근 & 장딴지근', '왼쪽 넓은등근',
        '왼쪽 큰가슴근 & 작은가슴근', '왼쪽 넙다리곧은근 & 엉덩허리근',
      ],
      underactiveItems: [
        '왼쪽 앞정강근', '왼쪽 등세모근-하부섬유', '왼쪽 앞톱니근',
      ],
    },
    40: {
      type1Label: '왼쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '왼쪽 넓은등근', '왼쪽 작은가슴근', '왼쪽 큰가슴근', '왼쪽 어깨밑근 & 큰원근',
      ],
      underactiveItems: [
        '왼쪽 등세모근-하부섬유', '왼쪽 앞톱니근', '왼쪽 가시위근 및 뒤쪽 회전근개',
      ],
    },
    // ── 유형1: 오른쪽 골반 높이 상승 ─────────────────────────────
    41: {
      type1Label: '오른쪽 골반 높이 상승',
      type2Label: '오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      overactiveItems: [
        '오른쪽 허리네모근', '오른쪽 종아리근', '오른쪽 장딴지근 & 가자미근',
        '오른쪽 넙다리근막긴장근', '오른쪽 모음근',
        '왼쪽 뒤정강근 & 앞정강근', '왼쪽 모음근',
      ],
      underactiveItems: [
        '오른쪽 뒤정강근', '오른쪽 앞정강근', '오른쪽 중간볼기근',
        '왼쪽 종아리근', '왼쪽 허리네모근', '왼쪽 중간볼기근',
      ],
    },
    42: {
      type1Label: '오른쪽 골반 높이 상승',
      type2Label: '오른쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '오른쪽 장딴지근 & 가자미근', '오른쪽 허리네모근',
        '오른쪽 넙다리근막긴장근', '오른쪽 넙다리곧은근',
        '왼쪽 모음근',
      ],
      underactiveItems: [
        '오른쪽 앞정강근', '오른쪽 큰볼기근',
        '왼쪽 중간볼기근', '왼쪽 허리네모근',
      ],
    },
    43: {
      type1Label: '오른쪽 골반 높이 상승',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 배곧은근 & 배속/바깥빗근', '양쪽 넓은등근',
        '오른쪽 장딴지근 & 가자미근', '오른쪽 허리네모근', '오른쪽 넙다리근막긴장근 & 엉덩허리근',
      ],
      underactiveItems: [
        '양쪽 척추세움근', '양쪽 등세모근-하부섬유 & 능형근',
        '오른쪽 앞정강근', '오른쪽 큰볼기근',
      ],
    },
    44: {
      type1Label: '오른쪽 골반 높이 상승',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '오른쪽 허리네모근', '오른쪽 모음근', '오른쪽 넙다리근막긴장근', '오른쪽 엉덩허리근',
      ],
      underactiveItems: [
        '왼쪽 중간볼기근', '왼쪽 큰볼기근',
      ],
    },
    // ── 유형1: 왼쪽 골반 높이 상승 ─────────────────────────────────
    45: {
      type1Label: '왼쪽 골반 높이 상승',
      type2Label: '오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      overactiveItems: [
        '왼쪽 허리네모근', '왼쪽 종아리근', '왼쪽 장딴지근 & 가자미근',
        '왼쪽 넙다리근막긴장근', '왼쪽 모음근',
        '오른쪽 뒤정강근 & 앞정강근', '오른쪽 모음근',
      ],
      underactiveItems: [
        '왼쪽 뒤정강근', '왼쪽 앞정강근', '왼쪽 중간볼기근',
        '오른쪽 종아리근', '오른쪽 허리네모근', '오른쪽 중간볼기근',
      ],
    },
    46: {
      type1Label: '왼쪽 골반 높이 상승',
      type2Label: '왼쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '왼쪽 장딴지근 & 가자미근', '왼쪽 허리네모근',
        '왼쪽 넙다리근막긴장근', '왼쪽 넙다리곧은근',
        '오른쪽 모음근',
      ],
      underactiveItems: [
        '왼쪽 앞정강근', '왼쪽 큰볼기근',
        '오른쪽 중간볼기근', '오른쪽 허리네모근',
      ],
    },
    47: {
      type1Label: '왼쪽 골반 높이 상승',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 배곧은근 & 배속/바깥빗근', '양쪽 넓은등근',
        '왼쪽 장딴지근 & 가자미근', '왼쪽 허리네모근', '왼쪽 넙다리근막긴장근 & 엉덩허리근',
      ],
      underactiveItems: [
        '양쪽 척추세움근', '양쪽 등세모근-하부섬유 & 능형근',
        '왼쪽 앞정강근', '왼쪽 큰볼기근',
      ],
    },
    48: {
      type1Label: '왼쪽 골반 높이 상승',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '왼쪽 허리네모근', '왼쪽 모음근', '왼쪽 넙다리근막긴장근', '왼쪽 엉덩허리근',
      ],
      underactiveItems: [
        '오른쪽 중간볼기근', '오른쪽 큰볼기근',
      ],
    },
    49: {
      type1Label: '양쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '오른쪽 발등굽힘 가동범위 제한',
      overactiveItems: [
        '양쪽 넓은등근 & 큰가슴근', '오른쪽 장딴지근 & 가자미근', '왼쪽 모음근 & 넙다리네갈래근',
      ],
      underactiveItems: [
        '양쪽 등세모근 하부 & 앞톱니근', '오른쪽 앞정강근', '오른쪽 큰볼기근',
      ],
    },
    50: {
      type1Label: '양쪽 어깨관절 굽힘 가동범위 제한',
      type2Label: '나머지 케이스',
      overactiveItems: [
        '양쪽 넓은등근', '양쪽 큰가슴근 & 작은가슴근', '양쪽 큰원근', '양쪽 배곧은근',
      ],
      underactiveItems: [
        '양쪽 등세모근 하부', '양쪽 앞톱니근', '양쪽 회전근개',
      ],
    },
    // ── 유형1: 양쪽 무릎 안굽이(varus) ──────────────────────────
    54: {
      type1Label: '양쪽 무릎 안굽이(varus)',
      type2Label: '양쪽 발목 안쪽번짐',
      overactiveItems: [
        '양쪽 장딴지근', '양쪽 긴종아리근', '양쪽 뒤정강근', '양쪽 넙다리근막긴장근',
      ],
      underactiveItems: [
        '양쪽 중간볼기근', '양쪽 큰볼기근', '양쪽 모음근',
      ],
    },
    // ── 유형1: 골반 중심 안정 ─────────────────────────────────────
    51: {
      type1Label: '골반 중심 안정',
      type2Label: '상체 과도한 앞으로 숙임',
      overactiveItems: [
        '양쪽 장딴지근', '양쪽 넙다리곧은근', '양쪽 넓은등근', '양쪽 긴모음근', '양쪽 넙다리근막긴장근',
      ],
      underactiveItems: [
        '양쪽 중간볼기근', '양쪽 큰볼기근', '양쪽 복부 심부 안정 근육군',
      ],
    },
    // ── 기타 케이스 (전체 fallback) ───────────────────────────────
    52: {
      type1Label: '기타 패턴',
      type2Label: null,
      overactiveItems: [
        '양쪽 장딴지근', '양쪽 가자미근', '양쪽 뒤정강근',
        '양쪽 모음근', '양쪽 넙다리근막긴장근', '양쪽 넙다리곧은근',
      ],
      underactiveItems: [
        '양쪽 복부 심부 안정 근육군', '양쪽 중간볼기근', '양쪽 큰볼기근',
      ],
    },
    // ── 전부 정상 ─────────────────────────────────────────────────
    53: {
      type1Label: '안정적 통합패턴',
      type2Label: null,
      overactiveItems: ['불필요하게 과하게 사용되는 근육 없음'],
      underactiveItems: ['필요한 근육들이 동작 전반에서 적절히 작용함'],
    },
  };

export const SCENARIO_DB: Record<string, {
    title: string;
    priority: number; // 1=보라 2=파랑 3=초록 4=하얀 5=오렌지(fallback)
    content: string;
  }> = {
    // ── 골반 오른쪽 이동 계열 ────────────────────────────────────
    'HIP_NOT_CENTER_RIGHT|KNEE_RIGHT': {
      title: '골반 오른쪽 이동 + 오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      priority: 1,
      content: '스쿼트 하강 시 왼쪽 발목의 발등굽힘 제한이나 엉덩관절의 뻣뻣함으로 무게중심이 오른쪽으로 이동합니다.\n오른쪽 엉덩이 근육이 부하를 견디지 못해 넙다리뼈가 안쪽으로 회전하며 무릎이 안으로 무너지는 밖굽이(valgus) 현상이 나타납니다.\n결과적으로 골반이 오른쪽으로 빠지며 왼쪽 다리는 벌어지고 바깥으로 돌아가는 안굽이(varus) 자세의 움직임 패턴을 형성합니다.',
    },
    'FOOT_OUTWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 양쪽 발 벌림',
      priority: 1,
      content: '스쿼트 하강 시 왼쪽 하체의 움직임 활용이 제한되면서 무게중심이 오른쪽으로 이동합니다.\n이 과정에서 오른쪽 발목은 가동 범위를 쉽게 사용하기 위해 발끝을 바깥으로 돌리는 정렬이 나타나며,\n무게중심 이동에 따라 왼쪽 하체 역시 균형 보조를 위해 지면을 넓게 사용하는 방향으로 발 정렬을 조정합니다.\n그 결과 양발 모두 toe-out 정렬이 형성되고, 스쿼트 동작 중 무릎과 발목 안쪽 사용 비중이 높아지는 움직임 특성을 보입니다.',
    },
    'ANKLE_RIGHT|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'BODY_LEARN_FORWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 상체 과도한 앞으로 숙임',
      priority: 1,
      content: '스쿼트 하강 시 왼쪽 하체의 움직임 범위 제한으로 무게중심이 오른쪽으로 이동합니다.\n오른쪽 발목의 발등굽힘 제한으로 무릎이 충분히 나가지 못해 엉덩이가 뒤로 과도하게 빠지는 현상이 발생합니다.\n결과적으로 뒤로 쏠린 무게중심을 맞추기 위해 상체를 앞으로 급격히 숙이는 보상 패턴이 나타납니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_HIP_HIGHER': {
      title: '골반 오른쪽 이동 + 오른쪽 골반 높이 상승',
      priority: 1,
      content: '스쿼트 하강 시 왼쪽 하체의 움직임 범위 제한으로 무게중심이 오른쪽으로 이동합니다.\n오른쪽 하체는 엉덩관절의 안정성 대신 허리네모근을 과하게 수축하여 골반을 위로 끌어당기는 방식으로 버티게 됩니다.\n이로 인해 오른쪽 골반이 높아지고 왼쪽은 낮아지는 불균형이 발생하며, 척추가 오른쪽으로 휘어지는 옆굽음 형태의 스트레스가 유발되는 움직임 패턴이 나타납니다.',
    },
    'HIP_NOT_CENTER_RIGHT|KNEE_INWARD': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    // 골반 오른쪽 이동 나머지 케이스
    'ANKLE_LEFT|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 1,
      content: '스쿼트 하강 시 왼쪽 발바닥 아치가 무너지며 다리가 안쪽으로 회전해 지지력이 약화됩니다.\n신체는 이를 보상하기 위해 골반을 오른쪽으로 이동시키며 무게중심을 재배치합니다.\n체중이 실린 오른쪽 다리는 넙다리뼈가 바깥으로 회전하고 발날로 지지하는(inversion) 형태를 취합니다.\n이로 인해 하체 정렬이 오른쪽으로 기울어진 비대칭 구조의 움직임 패턴이 형성됩니다.',
    },
    'ANKLE_INWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'ANKLE_OUTWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'BODY_LEARN_BACKWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_INWARD|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'ARM_UNNORMAL|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_LEFT|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 왼쪽 발 벌림 / 오른쪽 발 정면',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_RIGHT|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 오른쪽 발 벌림 / 왼쪽 발 정면',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HEEL_UNNORMAL|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 양쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|KNEE_LEFT': {
      title: '골반 오른쪽 이동 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|KNEE_OUTWARD': {
      title: '골반 오른쪽 이동 + 양쪽 무릎 안굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_ANKLE_INWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 발목 안쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_ANKLE_OUTWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 발목 가쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_FOOT_INWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 발 모음',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_FOOT_OUTWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 발 벌림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_HEEL_UNNORMAL': {
      title: '골반 오른쪽 이동 + 왼쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_HIP_HIGHER': {
      title: '골반 오른쪽 이동 + 왼쪽 골반 높이 상승',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_KNEE_INWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 무릎 밖굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|LEFT_KNEE_OUTWARD': {
      title: '골반 오른쪽 이동 + 왼쪽 무릎 안굽이(varus)',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_ANKLE_INWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 발목 안쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_ANKLE_OUTWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 발목 가쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_FOOT_INWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 발 모음',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_FOOT_OUTWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 발 벌림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_HEEL_UNNORMAL': {
      title: '골반 오른쪽 이동 + 오른쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_KNEE_OUTWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 무릎 안굽이(varus)',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_CENTER_STABLE|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 골반 중심 안정',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|HIP_NOT_CENTER_RIGHT': {
      title: '골반 오른쪽 이동 + 골반 왼쪽 이동',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_KNEE_INWARD': {
      title: '골반 오른쪽 이동 + 오른쪽 무릎 밖굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 오른쪽으로 이동하며\n골반이 양발 사이 중심선의 오른쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 오른쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    // ── 골반 왼쪽 이동 계열 ────────────────────────────────────
    'HIP_NOT_CENTER_LEFT|KNEE_LEFT': {
      title: '골반 왼쪽 이동 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 1,
      content: '스쿼트 하강 시 오른쪽 발목의 발등굽힘 제한이나 엉덩관절의 뻣뻣함으로 무게중심이 왼쪽으로 이동합니다.\n왼쪽 엉덩이 근육이 부하를 견디지 못해 넙다리뼈가 안쪽으로 회전하며 무릎이 안으로 무너지는 밖굽이(valgus) 현상이 나타납니다.\n결과적으로 골반이 왼쪽으로 빠지며 오른쪽 다리는 벌어지고 바깥으로 돌아가는 안굽이(varus) 자세의 움직임 패턴을 형성합니다.',
    },
    'FOOT_OUTWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 양쪽 발 벌림',
      priority: 1,
      content: '스쿼트 하강 시 오른쪽 하체의 움직임 활용이 제한되면서 무게중심이 왼쪽으로 이동합니다.\n이 과정에서 왼쪽 발목은 가동 범위를 쉽게 사용하기 위해 발끝을 바깥으로 돌리는 정렬이 나타나며,\n무게중심 이동에 따라 오른쪽 하체 역시 균형 보조를 위해 지면을 넓게 사용하는 방향으로 발 정렬을 조정합니다.\n그 결과 양발 모두 toe-out 정렬이 형성되고, 스쿼트 동작 중 무릎과 발목 안쪽 사용 비중이 높아지는 움직임 특성을 보입니다.',
    },
    'ANKLE_LEFT|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'BODY_LEARN_FORWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 상체 과도한 앞으로 숙임',
      priority: 1,
      content: '스쿼트 하강 시 오른쪽 하체의 움직임 범위 제한으로 무게중심이 왼쪽으로 이동합니다.\n왼쪽 발목의 발등굽힘 제한으로 무릎이 충분히 나가지 못해 엉덩이가 뒤로 과도하게 빠지는 현상이 발생합니다.\n결과적으로 뒤로 쏠린 무게중심을 맞추기 위해 상체를 앞으로 급격히 숙이는 보상 패턴이 나타납니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_HIP_HIGHER': {
      title: '골반 왼쪽 이동 + 왼쪽 골반 높이 상승',
      priority: 1,
      content: '스쿼트 하강 시 오른쪽 하체의 움직임 범위 제한으로 무게중심이 왼쪽으로 이동합니다.\n왼쪽 하체는 엉덩관절의 안정성 대신 허리네모근을 과하게 수축하여 골반을 위로 끌어당기는 방식으로 버티게 됩니다.\n이로 인해 왼쪽 골반이 높아지고 오른쪽은 낮아지는 불균형이 발생하며, 척추가 왼쪽으로 휘어지는 옆굽음 형태의 스트레스가 유발되는 움직임 패턴이 나타납니다.',
    },
    'HIP_NOT_CENTER_LEFT|KNEE_INWARD': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    // 골반 왼쪽 이동 나머지 케이스
    'ANKLE_INWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'ANKLE_OUTWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'ANKLE_RIGHT|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 1,
      content: '스쿼트 하강 시 오른쪽 발바닥 아치가 무너지며 다리가 안쪽으로 회전해 지지력이 약화됩니다.\n신체는 이를 보상하기 위해 골반을 왼쪽으로 이동 및 회전시키며 무게중심을 옮깁니다.\n체중이 실린 왼쪽 다리는 넙다리뼈가 바깥으로 돌아가고 발날로 서는(inversion) 형태를 취하게 됩니다.\n최종적으로 하체 정렬이 왼쪽으로 기울어지는 평행사변형 모양의 비대칭 움직임 패턴이 형성됩니다.',
    },
    'BODY_LEARN_BACKWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_INWARD|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 ',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    // 골반 왼쪽 이동 추가 나머지 케이스
    'HIP_CENTER_STABLE|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 골반 중심 안정',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_RIGHT|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 오른쪽 발 벌림 / 왼쪽 발 정면',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_FOOT_INWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 발 모음',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_FOOT_OUTWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 발 벌림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_FOOT_INWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 발 모음',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'FOOT_LEFT|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 왼쪽 발 벌림 / 오른쪽 발 정면',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_FOOT_OUTWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 발 벌림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|KNEE_OUTWARD': {
      title: '골반 왼쪽 이동 + 양쪽 무릎 안굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|KNEE_RIGHT': {
      title: '골반 왼쪽 이동 + 오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_KNEE_INWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 무릎 밖굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_KNEE_OUTWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 무릎 안굽이(varus)',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_KNEE_INWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 무릎 밖굽이',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_KNEE_OUTWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 무릎 안굽이(varus)',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_ANKLE_INWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 발목 안쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_ANKLE_OUTWARD': {
      title: '골반 왼쪽 이동 + 오른쪽 발목 가쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_ANKLE_INWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 발목 안쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_ANKLE_OUTWARD': {
      title: '골반 왼쪽 이동 + 왼쪽 발목 가쪽번짐',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'ARM_UNNORMAL|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HEEL_UNNORMAL|HIP_NOT_CENTER_LEFT': {
      title: '골반 왼쪽 이동 + 양쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_HEEL_UNNORMAL': {
      title: '골반 왼쪽 이동 + 왼쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_HEEL_UNNORMAL': {
      title: '골반 왼쪽 이동 + 오른쪽 발뒤꿈치 들림',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    'HIP_NOT_CENTER_LEFT|HIP_CENTER_STABLE': {
      title: '골반 왼쪽 이동 + 골반 중심 안정',
      priority: 1,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때, 하강 말기 구간에서 무게중심이 왼쪽으로 이동하며\n골반이 양발 사이 중심선의 왼쪽에 위치하는 패턴이 관찰됩니다.\n이는 동작 수행 과정에서 신체가 왼쪽 하체를 기준으로 하중을 지지하고 분배하는 전략이 반영된 결과로,\n골반의 위치 변화가 뚜렷하게 나타나는 움직임 패턴입니다.',
    },
    // ── 양쪽 무릎 밖굽이(KNEE_INWARD) 계열 ──────────────────────
    'ANKLE_INWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 양쪽 발목 안쪽번짐',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 발목의 안정성이 떨어지면서 발바닥 아치가 내려앉고,\n그 영향이 위로 전달되어 정강이와 허벅지가 함께 안쪽으로 말리는 움직임이 나타납니다.\n이로 인해 무릎이 서로 가까워지는 정렬이 형성되며,\n엉덩이 근육이 하체의 안쪽 쏠림을 충분히 제어하지 못할 때 나타나는 보상 패턴입니다.',
    },
    'FOOT_OUTWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 양쪽 발 벌림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 발목의 발등굽힘 제한으로 무릎이 충분히 전진하지 못합니다.\n신체는 가동 범위를 확보하기 위해 발바닥 아치를 무너뜨리고 발끝을 바깥으로 벌리는 보상 작용을 사용합니다.\n이로 인해 무릎과 발끝의 정렬이 어긋나며, 엉덩관절 근육의 조절 능력 부족으로 무릎이 안으로 모이는 밖굽이(Valgus) 현상이 발생합니다.\n결과적으로 엉덩이 근육의 활용도가 낮아지고 허벅지 앞쪽과 무릎 관절에 부하가 집중되는 움직임 패턴이 형성됩니다.',
    },
    'KNEE_INWARD|RIGHT_HIP_HIGHER': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 엉덩관절과 발목의 움직임 활용이 원활하지 않아,\n무릎 정렬을 유지하기 어려워지며 양쪽 무릎이 안쪽으로 모이는 밖굽이(Valgus) 움직임이 관찰됩니다.\n\n이 과정에서 좌우 지지 활용에 차이가 생겨 하중이 오른쪽으로 치우치며,\n자세 유지를 위해 오른쪽 골반을 위로 끌어올리는 정렬 변화가 함께 나타나\n골반의 높낮이 차이가 동반된 비대칭 패턴으로 이어질 수 있습니다.',
    },
    'KNEE_INWARD|LEFT_HIP_HIGHER': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 엉덩관절과 발목의 움직임 활용이 원활하지 않아,\n무릎 정렬을 유지하기 어려워지며 양쪽 무릎이 안쪽으로 모이는 밖굽이(Valgus) 움직임이 관찰됩니다.\n\n이 과정에서 좌우 지지 활용에 차이가 생겨 하중이 왼쪽으로 치우치며,\n자세 유지를 위해 왼쪽 골반을 위로 끌어올리는 정렬 변화가 함께 나타나\n골반의 높낮이 차이가 동반된 비대칭 패턴으로 이어질 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 상체 과도한 앞으로 숙임',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 발목의 발등굽힘 활용이 제한되어 무릎 전진이 줄어들며,\n엉덩이가 뒤로 빠지고 상체가 앞으로 기울어지는 정렬 변화가 나타납니다.\n\n이러한 자세에서는 발–무릎–골반의 지지 연결이 약해지며,\n그 결과 스쿼트 동작 중 양쪽 무릎이 바깥 정렬을 유지하지 못하고 안쪽으로 모이는 움직임이 관찰될 수 있습니다.',
    },
    'BODY_LEARN_BACKWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 상체 과도한 뒤로 젖힘',
      priority: 4,
      content: '스쿼트 동작 시 몸통 전면의 조절이 원활하지 않아 복압 유지가 어려워지며,\n이를 보완하는 과정에서 허리뼈 폄과 상체 뒤젖힘 정렬이 함께 나타납니다.\n\n이러한 자세에서는 하체가 지지와 균형을 더 담당하게 되어,\n무릎 정렬을 유지하기 어려워지며 하체가 안쪽으로 모이는 움직임이 동반될 수 있습니다.',
    },
    // 양쪽 무릎 밖굽이 나머지 케이스
    'ANKLE_OUTWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'ANKLE_RIGHT|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'ANKLE_LEFT|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'FOOT_INWARD|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'ARM_UNNORMAL|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'FOOT_LEFT|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발 벌림 / 오른쪽 발 정면',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'FOOT_RIGHT|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발 벌림 / 왼쪽 발 정면',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'HEEL_UNNORMAL|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 양쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'HIP_CENTER_STABLE|KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 골반 중심 안정',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|KNEE_LEFT': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 양쪽 무릎 안굽이',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|KNEE_RIGHT': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_ANKLE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_ANKLE_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_ARM_UNNORMAL': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_FOOT_INWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_FOOT_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_HEEL_UNNORMAL': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|LEFT_KNEE_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 왼쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_ANKLE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_ANKLE_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_FOOT_INWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_FOOT_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_HEEL_UNNORMAL': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_KNEE_INWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    'KNEE_INWARD|RIGHT_KNEE_OUTWARD': {
      title: '양쪽 무릎 밖굽이 + 오른쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트에서 최대 깊이로 내려앉았을 때,\n동작을 유지하는 과정에서 양쪽 무릎이 중심선 쪽으로 모이는 정렬이 관찰됩니다.\n하강 말기에서는 발목·엉덩이·상체의 사용 방식이 동시에 조절되어야 하는데,\n이 과정에서 하체가 안정적으로 지지를 확보하기 위해\n무릎 정렬을 기준으로 하중을 받아내는 선택이 이루어지며 이러한 움직임이 나타납니다.',
    },
    // ── 오른쪽 무릎 밖굽이/왼쪽 무릎 안굽이 (KNEE_RIGHT) 계열 ──
    'ANKLE_LEFT|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 오른쪽 골반이 지지 기준으로 높게 유지되면,\n몸은 균형을 유지하기 위해 오른쪽 다리를 몸 안쪽으로, 왼쪽 다리를 바깥쪽으로 이동시키는 정렬 선택을 보입니다.\n\n이 과정에서 오른쪽 무릎은 안쪽으로, 왼쪽 무릎은 바깥쪽으로 이동하는 모습이 함께 관찰되며,\n골반 높이 차이를 기준으로 한 좌우 비대칭 움직임 패턴으로 해석할 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 상체 과도한 앞으로 숙임',
      priority: 4,
      content: '스쿼트 하강 말기에서 오른쪽 무릎이 중심선 방향으로 모이고,\n동시에 체중이 왼쪽 하체에 더 많이 실리는 정렬 변화가 관찰됩니다.\n이 과정에서 발목과 엉덩관절이 충분한 범위로 사용되지 않으면서\n무게중심이 뒤쪽으로 이동하는 경향이 나타날 수 있고,\n이를 조절하기 위해 상체가 앞으로 기울어지는 사용 양상이 동반됩니다.\n그 결과 하체는 좌우로 다른 방식으로 지지를 담당하고,\n상체는 균형을 맞추기 위해 각도가 변하는 전신 비대칭 움직임 패턴으로 이어집니다.',
    },
    'KNEE_RIGHT|RIGHT_HEEL_UNNORMAL': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발등굽힘 가동범위 제한',
      priority: 4,
      content: '스쿼트 하강 말기에서 오른쪽 발목의 발등굽힘이 충분히 활용되지 않으며,\n정강뼈의 전진이 제한되는 양상이 관찰됩니다.\n이로 인해 하강 과정에서 오른쪽 하체로 체중을 싣는 데 제약이 생기고,\n동작을 유지하기 위해 하중이 상대적으로 왼쪽 하체로 더 이동하는 흐름이 나타납니다.\n그 결과 오른쪽은 무릎이 중심선 쪽으로 모이는 정렬을 보이고,\n왼쪽은 증가한 하중을 지지하기 위해 무릎이 바깥으로 벌어지는 형태가 함께 나타나는,\n좌우 지지 역할이 분리된 하체 비대칭 움직임 패턴으로 이어집니다.',
    },
    // 나머지 KNEE_RIGHT 케이스
    'ANKLE_INWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ANKLE_OUTWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ANKLE_RIGHT|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 4,
      content: '스쿼트 하강 말기에서 오른쪽 무릎이 중심선 쪽으로 모이고,\n이와 함께 오른쪽 발목의 아치가 낮아지는 사용 양상이 관찰됩니다.\n동작 중 하중이 좌우에서 동일하게 분배되지 않으면서\n체중이 상대적으로 왼쪽 하체로 더 실리는 흐름이 나타나고,\n그 결과 왼쪽 무릎은 바깥으로 지지하는 정렬과\n발바닥의 가쪽 날을 활용하는 형태가 동반되는 좌우 비대칭 움직임 패턴으로 이어집니다.',
    },
    // 나머지 KNEE_RIGHT 추가 케이스
    'HIP_CENTER_STABLE|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 골반 중심 안정',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'FOOT_OUTWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 양쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'FOOT_INWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 양쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_FOOT_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_FOOT_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_FOOT_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_FOOT_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_OUTWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 양쪽 무릎 안굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_KNEE_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_KNEE_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_KNEE_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_KNEE_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_ANKLE_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|RIGHT_ANKLE_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 오른쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_ANKLE_INWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_ANKLE_OUTWARD': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_HIP_HIGHER': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 골반 높이 상승',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ARM_UNNORMAL|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_ARM_UNNORMAL': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'BODY_LEARN_BACKWARD|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 상체 과도한 뒤로 젖힘',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'HEEL_UNNORMAL|KNEE_RIGHT': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 양쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_RIGHT|LEFT_HEEL_UNNORMAL': {
      title: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이 + 왼쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n오른쪽 무릎은 중심선 쪽으로 모이고, 왼쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    // ── 오른쪽 무릎 안굽이/왼쪽 무릎 밖굽이 (KNEE_LEFT) 계열 ──
    'ANKLE_LEFT|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 4,
      content: '스쿼트 하강 말기에서 왼쪽 무릎이 중심선 쪽으로 모이고,\n이와 함께 왼쪽 발목의 아치가 낮아지는 사용 양상이 관찰됩니다.\n동작 중 하중이 좌우에서 동일하게 분배되지 않으면서\n체중이 상대적으로 오른쪽 하체로 더 실리는 흐름이 나타나고,\n그 결과 오른쪽 무릎은 바깥으로 지지하는 정렬과\n발바닥의 가쪽 날을 활용하는 형태가 동반되는 좌우 비대칭 움직임 패턴으로 이어집니다.',
    },
    'KNEE_LEFT|LEFT_HIP_HIGHER': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 왼쪽 골반이 지지 기준으로 높게 유지되면,\n몸은 균형을 유지하기 위해 왼쪽 다리를 몸 안쪽으로, 오른쪽 다리를 바깥쪽으로 이동시키는 정렬 선택을 보입니다.\n\n이 과정에서 왼쪽 무릎은 안쪽으로, 오른쪽 무릎은 바깥쪽으로 이동하는 모습이 함께 관찰되며,\n골반 높이 차이를 기준으로 한 좌우 비대칭 움직임 패턴으로 해석할 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 상체 과도한 앞으로 숙임',
      priority: 4,
      content: '스쿼트 하강 말기에서 왼쪽 무릎이 중심선 방향으로 모이고,\n동시에 체중이 오른쪽 하체에 더 많이 실리는 정렬 변화가 관찰됩니다.\n이 과정에서 발목과 엉덩관절이 충분한 범위로 사용되지 않으면서\n무게중심이 뒤쪽으로 이동하는 경향이 나타날 수 있고,\n이를 조절하기 위해 상체가 앞으로 기울어지는 사용 양상이 동반됩니다.\n그 결과 하체는 좌우로 다른 방식으로 지지를 담당하고,\n상체는 균형을 맞추기 위해 각도가 변하는 전신 비대칭 움직임 패턴으로 이어집니다.',
    },
    'KNEE_LEFT|LEFT_HEEL_UNNORMAL': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 발등굽힘 가동범위 제한',
      priority: 4,
      content: '스쿼트 하강 말기에서 왼쪽 발목의 발등굽힘이 충분히 활용되지 않으며,\n정강뼈의 전진이 제한되는 양상이 관찰됩니다.\n이로 인해 하강 과정에서 왼쪽 하체로 체중을 싣는 데 제약이 생기고,\n동작을 유지하기 위해 하중이 상대적으로 오른쪽 하체로 더 이동하는 흐름이 나타납니다.\n그 결과 왼쪽은 무릎이 중심선 쪽으로 모이는 정렬을 보이고,\n오른쪽은 증가한 하중을 지지하기 위해 무릎이 바깥으로 벌어지는 형태가 함께 나타나는,\n좌우 지지 역할이 분리된 하체 비대칭 움직임 패턴으로 이어집니다.',
    },
    // 나머지 KNEE_LEFT
    'ANKLE_INWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ANKLE_OUTWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'FOOT_OUTWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ANKLE_RIGHT|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 ',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    // 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 추가 나머지 케이스
    'HIP_CENTER_STABLE|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 골반 중심 안정',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'FOOT_INWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 양쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_FOOT_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_FOOT_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_FOOT_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 발 모음',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_FOOT_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 발 벌림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|KNEE_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 양쪽 무릎 안굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_KNEE_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_KNEE_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_KNEE_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_KNEE_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_ANKLE_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_ANKLE_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_ANKLE_INWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 발목 안쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|LEFT_ANKLE_OUTWARD': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 왼쪽 발목 가쪽번짐',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'ARM_UNNORMAL|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'BODY_LEARN_BACKWARD|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 상체 과도한 뒤로 젖힘',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'HEEL_UNNORMAL|KNEE_LEFT': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 양쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    'KNEE_LEFT|RIGHT_HEEL_UNNORMAL': {
      title: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이 + 오른쪽 발뒤꿈치 들림',
      priority: 4,
      content: '오버헤드 스쿼트 하강 말기에서\n왼쪽 무릎은 중심선 쪽으로 모이고, 오른쪽 무릎은 상대적으로 바깥으로 벌어지는 좌우 비대칭 정렬이 관찰됩니다.\n이 정렬 차이는 동작 중 하중이 좌우에서 동일하게 분배되지 않고\n한쪽을 기준으로 더 많이 지지되는 사용 방식이 반영된 결과로,\n무릎 정렬의 차이를 통해 하체의 비대칭적인 하중 분배 패턴이 드러납니다.',
    },
    // ── 양쪽 무릎 안굽이(KNEE_OUTWARD) + 관련 계열 ──────────────
    'ANKLE_OUTWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 양쪽 발목 가쪽번짐',
      priority: 4,
      content: '양발로 지면을 지지하는 과정에서 발바닥의 바깥쪽 사용 비중이 높아지며,\n그에 따라 무릎이 중심선보다 바깥으로 벌어진 정렬이 함께 관찰됩니다.\n이 패턴에서는 하체를 넓게 사용해 버티는 안정감은 나타나지만,\n동작이 깊어질수록 하중을 세밀하게 조절하기보다는\n힘을 분산시켜 지지를 유지하려는 사용 전략이 드러납니다.',
    },
    'FOOT_OUTWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 양쪽 발 벌림',
      priority: 4,
      content: '발을 바깥쪽으로 벌린 상태에서 지면을 지지하려는 사용 방식이 나타나며,\n이에 따라 무릎도 중심선보다 바깥으로 벌어진 정렬이 함께 유지됩니다.\n하체는 넓은 기반을 만들어 안정성을 확보하려는 선택을 하게 되고,\n깊이가 깊어질수록 무릎을 모아 내려가기보다\n벌린 상태로 버티는 지지 패턴이 두드러지게 나타납니다.',
    },
    'BODY_LEARN_BACKWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 상체 과도한 뒤로 젖힘',
      priority: 4,
      content: '스쿼트 하강 시 하체가 바깥쪽으로 지지를 선택하면,\n지면을 미는 힘의 방향이 좌우로 분산되어 몸의 중심을 위아래로 곧게 유지하기가 어려워집니다.\n\n이를 보완하기 위해 상체 각도를 뒤쪽으로 조절해 중심을 맞추는 선택이 나타나며,\n그 결과 하체는 바깥으로, 상체는 뒤로 사용되는 분리된 균형 패턴이 함께 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '양쪽 무릎 안굽이 + 오른쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하면,\n하체는 지지를 넓게 분산해 처리하게 되어 좌우 하중 전달에 차이가 생기기 쉽습니다.\n\n이 과정에서 하중을 더 많이 담당한 쪽 골반이 기준점 역할을 하며 높이 차이가 나타나고,\n무릎 바깥 정렬과 함께 골반 비대칭이 동반되는 전신 균형 조절 패턴으로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_HIP_HIGHER': {
      title: '양쪽 무릎 안굽이 + 왼쪽 골반 높이 상승',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하면,\n하체는 지지를 넓게 분산해 처리하게 되어 좌우 하중 전달에 차이가 생기기 쉽습니다.\n\n이 과정에서 하중을 더 많이 담당한 쪽 골반이 기준점 역할을 하며 높이 차이가 나타나고,\n무릎 바깥 정렬과 함께 골반 비대칭이 동반되는 전신 균형 조절 패턴으로 관찰될 수 있습니다.',
    },
    // 나머지 KNEE_OUTWARD
    'ANKLE_INWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 ',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'ANKLE_LEFT|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 ',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'ANKLE_RIGHT|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 ',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 상체 과도한 앞으로 숙임',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'FOOT_INWARD|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 양쪽 발 모음',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'HEEL_UNNORMAL|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 양쪽 발뒤꿈치 들림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'HIP_CENTER_STABLE|KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 골반 중심 안정',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_ANKLE_INWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 발목 안쪽번짐',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_ANKLE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 발목 가쪽번짐',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_FOOT_INWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 발 모음',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_FOOT_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 발 벌림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_HEEL_UNNORMAL': {
      title: '양쪽 무릎 안굽이 + 왼쪽 발뒤꿈치 들림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_KNEE_INWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 무릎 밖굽이',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 왼쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_ANKLE_INWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 발목 안쪽번짐',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_ANKLE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 발목 가쪽번짐',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_FOOT_INWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 발 모음',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_FOOT_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 발 벌림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_HEEL_UNNORMAL': {
      title: '양쪽 무릎 안굽이 + 오른쪽 발뒤꿈치 들림',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_KNEE_INWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 무릎 밖굽이',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_KNEE_OUTWARD': {
      title: '양쪽 무릎 안굽이 + 오른쪽 무릎 안굽이(varus)',
      priority: 4,
      content: '스쿼트 하강 시 양쪽 무릎이 바깥으로 벌어진 정렬을 유지하는 경우,\n하체는 하중을 넓게 분산해 처리하며 지면 반력을 좌우로 사용하는 지지 전략을 선택할 수 있습니다.\n\n이러한 전략에서는 중심을 세로로 정밀하게 모아 조절하기보다,\n동작 조건에 따라 각 분절이 안정적인 방향으로 역할을 분담하는 전신 조절 양상이 나타나며,\n그 결과 골반·상체·발목 정렬 변화가 동반되거나, 비교적 유지되는 형태로 관찰될 수 있습니다.',
    },
    // ── 오른쪽 어깨관절 굽힘 가동범위 제한 (RIGHT_ARM_UNNORMAL) 계열
    'BODY_LEARN_BACKWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 뒤로 젖힘',
      priority: 3,
      content: '스쿼트나 팔을 머리 위로 드는 동작 시 오른쪽 어깨의 굽힘 범위 활용이 충분하지 않아,\n팔을 더 올리기 위해 몸통을 뒤로 젖혀 가동 범위를 보완하는 정렬 변화가 나타납니다.\n\n이러한 보상으로 상체 전체가 뒤로 기울어진 상태에서 동작이 수행되며,\n좌우 팔의 움직임 차이가 동반된 상체 정렬 불균형 패턴이 관찰될 수 있습니다.',
    },
    'HIP_NOT_CENTER_RIGHT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 골반 오른쪽 이동',
      priority: 3,
      content: '오버헤드 스쿼트 하강 시 몸의 중심이 오른쪽으로 치우치며,\n균형 유지를 위해 오른쪽 몸통이 지지 기준점으로 고정되는 움직임 선택이 나타납니다.\n\n이 과정에서 오른쪽 몸통은 움직일 수 있음에도 불구하고 안정 유지를 우선해 여유를 제한하게 되며,\n그 결과 오른쪽 골반의 치우침과 함께 같은 쪽 팔의 머리 위 움직임이 덜 사용되는 패턴이 관찰될 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_HEEL_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발등굽힘 가동범위 제한',
      priority: 3,
      content: '스쿼트 하강 시 오른쪽 발목이 충분히 접히지 않아,\n몸이 오른쪽 다리를 기준으로 지지하는 자세 변화가 나타납니다.\n\n이러한 오른쪽 중심 사용 속에서 균형을 유지하기 위해,\n상체와 팔도 같은 쪽을 기준으로 덜 움직이게 되며\n오른쪽 어깨와 하체가 함께 제한되는 패턴이 관찰될 수 있습니다.',
    },
    // 나머지 RIGHT_ARM_UNNORMAL
    'HIP_NOT_CENTER_LEFT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 ',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 ',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_LEFT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_RIGHT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 앞으로 숙임',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_LEFT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 벌림 / 오른쪽 발 정면',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_RIGHT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림 / 왼쪽 발 정면',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'HEEL_UNNORMAL|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발뒤꿈치 들림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'KNEE_LEFT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'KNEE_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 무릎 안굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'KNEE_RIGHT|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ANKLE_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ANKLE_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 어깨관절 굽힘 가동범위 제한',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_FOOT_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_FOOT_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_HEEL_UNNORMAL|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발뒤꿈치 들림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 골반 높이 상승',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_KNEE_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_KNEE_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ANKLE_INWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ANKLE_OUTWARD|RIGHT_ARM_UNNORMAL': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_FOOT_INWARD': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_FOOT_OUTWARD': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 골반 높이 상승',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_KNEE_INWARD': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    'RIGHT_ARM_UNNORMAL|RIGHT_KNEE_OUTWARD': {
      title: '오른쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도 오른쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n등이 충분히 펴진 자세에서도 동일한 움직임 제한이 관찰된다면,\n이는 팔을 들어 올리는 과정에서 오른쪽 어깨와 어깨뼈 주변의 움직임 조절이나\n연부조직의 긴장으로 인해 가동 범위가 제한된 사용 양상이 반영된 결과로 볼 수 있습니다.\n이 경우 다른 부위의 뚜렷한 보상 없이 어깨 주변의 사용 방식 차이로 팔 위치 제한이 나타나는 국소적인 움직임 패턴으로 해석할 수 있습니다.',
    },
    // ── 왼쪽 어깨관절 굽힘 가동범위 제한 (LEFT_ARM_UNNORMAL) 계열
    'BODY_LEARN_BACKWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 뒤로 젖힘',
      priority: 3,
      content: '오버헤드 스쿼트에서 팔을 머리 위로 유지한 채 하강할 때,\n왼쪽 팔의 굽힘 범위가 오른쪽에 비해 충분히 확보되지 않는 모습이 관찰됩니다.\n하강 말기에서는 팔의 굽힘과 함께 등뼈의 폄과 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 왼쪽 팔이 위로 따라오지 못하면서\n팔 위치를 유지하기 위한 조절로 상체가 뒤쪽으로 젖혀지는 사용 양상이 동반될 수 있습니다.\n그 결과 팔 위치의 좌우 차이와 상체 각도 변화가 함께 나타나는,\n상체 중심의 비대칭 움직임 패턴으로 이어집니다.',
    },
    'HIP_NOT_CENTER_LEFT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 골반 왼쪽 이동',
      priority: 3,
      content: '오버헤드 스쿼트 하강 시 몸의 중심이 왼쪽으로 치우치며,\n균형 유지를 위해 왼쪽 몸통이 지지 기준점으로 고정되는 움직임 선택이 나타납니다.\n\n이 과정에서 왼쪽 몸통은 움직일 수 있음에도 불구하고 안정 유지를 우선해 여유를 제한하게 되며,\n그 결과 왼쪽 골반의 치우침과 함께 같은 쪽 팔의 머리 위 움직임이 덜 사용되는 패턴이 관찰될 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_HEEL_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발등굽힘 가동범위 제한',
      priority: 3,
      content: '스쿼트 하강 시 왼쪽 발목이 충분히 접히지 않아 발의 지지 폭이 줄어들지만,\n하강 중에는 이동보다 즉각적으로 지면을 누를 수 있는 쪽에 중심을 남기는 선택이 나타날 수 있습니다.\n\n이 과정에서 왼쪽 하체와 몸통이 지지 기준으로 고정되며,\n그 결과 같은 쪽 팔과 하체의 움직임 사용이 함께 줄어드는 전신 조절 패턴이 관찰될 수 있습니다.',
    },
    // 나머지 LEFT_ARM_UNNORMAL
    'HIP_NOT_CENTER_RIGHT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 ',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_INWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 ',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    // 왼쪽 어깨관절 굽힘 가동범위 제한 추가 나머지 케이스
    'FOOT_OUTWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_INWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_RIGHT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림 / 왼쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_LEFT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 모음 / 왼쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_FOOT_INWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_FOOT_OUTWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_FOOT_INWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 모음',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_FOOT_OUTWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 벌림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'KNEE_OUTWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 무릎 안굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'KNEE_LEFT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_KNEE_INWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_KNEE_OUTWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_KNEE_INWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 밖굽이',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_KNEE_OUTWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_OUTWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_LEFT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'ANKLE_RIGHT|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_ANKLE_INWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_ANKLE_OUTWARD': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ANKLE_INWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ANKLE_OUTWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|LEFT_HIP_HIGHER': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 골반 높이 상승',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'BODY_LEARN_FORWARD|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 앞으로 숙임',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'HEEL_UNNORMAL|LEFT_ARM_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발뒤꿈치 들림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_HEEL_UNNORMAL': {
      title: '왼쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발뒤꿈치 들림',
      priority: 3,
      content: '허리와 골반 정렬이 비교적 유지된 상태에서도\n왼쪽 팔이 귀 옆까지 충분히 올라가지 않는 모습이 관찰됩니다.\n\n등을 편 자세에서도 동일한 제한이 나타난다면,\n이는 팔을 들어 올리는 과정에서 왼쪽 어깨와 어깨뼈 주변의 움직임 사용 방식 차이가 반영된 결과로 볼 수 있습니다.\n\n이 경우 다른 부위의 뚜렷한 보상 없이,\n어깨 주변의 국소적인 움직임 특성으로 팔 위치 제한이 나타나는 패턴으로 해석할 수 있습니다.',
    },
    // ── 양쪽 어깨관절 굽힘 가동범위 제한 (ARM_UNNORMAL) 계열 ────
    'ARM_UNNORMAL|BODY_LEARN_FORWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 앞으로 숙임',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|BODY_LEARN_BACKWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 상체 과도한 뒤로 젖힘',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서 양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 않으며\n180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n팔 위치를 유지하는 데 필요한 가동 범위나 사용 방식이 충분히 확보되지 않을 경우\n상체 각도를 조절하는 선택으로 뒤쪽으로 젖혀지는 사용 양상이 동반될 수 있습니다.\n그 결과 팔 위치 제한과 상체 각도 변화가 함께 나타나는\n상체 중심의 움직임 패턴으로 해석할 수 있습니다.',
    },
    'ARM_UNNORMAL|HEEL_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발등굽힘 가동범위 제한',
      priority: 3,
      content: '스쿼트 하강 시 양쪽 발목이 충분히 접히지 않으면,\n무릎 전진과 하강 깊이를 만들기 위해 엉덩이를 더 뒤로 쓰고 상체를 더 크게 움직이는 전략이 나타납니다.\n\n이처럼 하체에서 깊이를 만들기 어려운 상황에서는 상체가 안정 기준 역할을 하게 되며,\n그 결과 팔을 머리 위로 충분히 들어 올리기 위한 여유가 줄어들어 양쪽 팔의 움직임 제한과 발뒤꿈치 들림이 함께 관찰될 수 있습니다.',
    },
    // 나머지 ARM_UNNORMAL
    'ARM_UNNORMAL|RIGHT_HEEL_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발등굽힘 가동범위 제한',
      priority: 3,
      content: '스쿼트 하강 시 오른쪽 발목이 충분히 접히지 않으면,\n무릎 전진이 줄어들어 몸통 중심을 안정적으로 유지하려는 선택이 나타납니다.\n\n이 과정에서 상체의 움직임 여유가 줄어들며,\n그 결과 좌우 팔 모두 머리 위로 충분히 사용되지 않고,\n오른쪽에서는 발뒤꿈치 들림이 함께 관찰될 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_HEEL_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발등굽힘 가동범위 제한',
      priority: 3,
      content: '스쿼트 하강 시 왼쪽 발목이 충분히 접히지 않으면,\n무릎 전진이 줄어들어 몸통 중심을 안정적으로 유지하려는 선택이 나타납니다.\n\n이 과정에서 상체의 움직임 여유가 줄어들며,\n그 결과 좌우 팔 모두 머리 위로 충분히 사용되지 않고,\n왼쪽에서는 발뒤꿈치 들림이 함께 관찰될 수 있습니다.',
    },
    // 양쪽 어깨관절 굽힘 가동범위 제한 추가 나머지 케이스
    'ARM_UNNORMAL|FOOT_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 벌림',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|FOOT_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발 모음',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|FOOT_RIGHT': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림 / 왼쪽 발 모음',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|FOOT_LEFT': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 모음 / 왼쪽 발 벌림',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_FOOT_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 모음',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_FOOT_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발 벌림',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_FOOT_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 모음',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_FOOT_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발 벌림',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|KNEE_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 무릎 안굽이',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_KNEE_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 밖굽이',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_KNEE_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_KNEE_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 밖굽이',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_KNEE_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 무릎 안굽이(varus)',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ANKLE_INWARD|ARM_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발목 안쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ANKLE_OUTWARD|ARM_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 양쪽 발목 가쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ANKLE_LEFT|ARM_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ANKLE_RIGHT|ARM_UNNORMAL': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_ANKLE_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 안쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_ANKLE_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 오른쪽 발목 가쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_ANKLE_INWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 안쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_ANKLE_OUTWARD': {
      title: '양쪽 어깨관절 굽힘 가동범위 제한 + 왼쪽 발목 가쪽번짐',
      priority: 3,
      content: '오버헤드 스쿼트 하강 말기에서\n양쪽 팔 모두 머리 위 위치까지 충분히 올라가지 못하며 180도에 도달하지 않는 모습이 관찰됩니다.\n이 구간에서는 팔의 굽힘과 함께 등뼈의 폄, 어깨뼈의 위쪽 회전이 동시에 요구되는데,\n이 과정에서 상체가 팔을 위로 유지하는 데 필요한 가동 범위나 사용 방식을 충분히 확보하지 못하면\n하체 정렬과 관계없이 팔 위치 제한이 드러나는 움직임 패턴으로 나타날 수 있습니다.',
    },
    // ── 오른쪽 골반 높이 상승 (RIGHT_HIP_HIGHER) 계열 ────────────
    'ANKLE_LEFT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_HEEL_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발등굽힘 가동범위 제한',
      priority: 2,
      content: '스쿼트 하강 시 오른쪽 발목의 발등굽힘 제한으로 무릎이 충분히 전진하지 못해 발뒤꿈치가 들리는 보상이 나타납니다.\n이와 함께 오른쪽 엉덩관절의 굽힘 가동성 부족으로 인해 오른쪽 골반이 충분히 내려가지 못하고 위로 치솟는 골반 끌어당김(Hike) 현상이 발생합니다.\n결과적으로 체중을 안정적으로 지지하며 내려가는 왼쪽 골반은 낮아지고, 오른쪽은 높게 유지되는 비대칭적인 하체 정렬과 움직임 패턴이 형성됩니다.',
    },
    'BODY_LEARN_FORWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 상체 과도한 앞으로 숙임',
      priority: 2,
      content: '스쿼트 하강 시 오른쪽 발목이 충분히 접히지 않아 무릎 전진이 줄어들고,\n이를 보완하기 위해 엉덩이를 뒤로 보내며 상체를 앞으로 기울여 균형을 유지하는 움직임이 나타납니다.\n\n이 과정에서 몸은 오른쪽 하체를 기준으로 지지를 처리하려는 경향을 보이며,\n그 결과 상체가 앞으로 기울어진 상태와 함께 오른쪽 골반이 상대적으로 높아 보이는 정렬 변화가 동시에 관찰될 수 있습니다.',
    },
    // 나머지 RIGHT_HIP_HIGHER
    'ANKLE_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ANKLE_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ANKLE_RIGHT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      priority: 2,
      content: '스쿼트 하강 시 왼쪽 하체의 활용이 줄어들며,\n몸은 오른쪽 다리를 중심으로 지지를 처리하는 움직임 경향을 보입니다.\n\n이 과정에서 오른쪽 발은 늘어난 지지를 처리하기 위해 발바닥을 넓게 쓰는 방향으로 움직여 가동이 제한된 것처럼 보이며,\n반대로 지지에서 멀어진 왼쪽 하체는 균형을 맞추는 과정에서 바깥쪽 정렬이 함께 나타나,\n오른쪽 골반이 상대적으로 높아 보이는 좌우 비대칭 패턴이 관찰될 수 있습니다.',
    },
    'BODY_LEARN_BACKWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ARM_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 양쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_LEFT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발 벌림 / 오른쪽 발 정면',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 양쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_RIGHT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발 벌림 / 왼쪽 발 정면',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'HEEL_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 양쪽 발뒤꿈치 들림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'HIP_CENTER_STABLE|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 골반 중심 안정',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'HIP_NOT_CENTER_LEFT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 골반 왼쪽 이동',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'KNEE_LEFT|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_ANKLE_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발목 안쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_ANKLE_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발목 가쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_ARM_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 어깨관절 굽힘 가동범위 제한',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_FOOT_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_FOOT_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HEEL_UNNORMAL|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 발뒤꿈치 들림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_KNEE_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 무릎 밖굽이',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_KNEE_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 왼쪽 무릎 안굽이(varus)',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_ANKLE_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발목 안쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_ANKLE_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발목 가쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_FOOT_INWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_FOOT_OUTWARD|RIGHT_HIP_HIGHER': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_HIP_HIGHER|RIGHT_KNEE_INWARD': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 무릎 밖굽이',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'RIGHT_HIP_HIGHER|RIGHT_KNEE_OUTWARD': {
      title: '오른쪽 골반 높이 상승 + 오른쪽 무릎 안굽이(varus)',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 오른쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 왼쪽 골반은 더 내려가고(Drop),\n오른쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    // ── 왼쪽 골반 높이 상승 (LEFT_HIP_HIGHER) 계열 ─────────────
    'ANKLE_LEFT|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      priority: 2,
      content: '스쿼트 하강 시 오른쪽 하체의 가동성 저하로 왼쪽으로 무게중심을 이동시킵니다.\n과부하가 걸린 왼쪽 발목은 부족한 가동 범위를 확보하기 위해 아치를 무너뜨립니다.\n동시에 왼쪽 엉덩관절이 체중을 충분히 지지하지 못하면서, 허리네모근이 과활성화되어 골반을 위로 끌어당깁니다(Hike).\n반대로 체중 지지에서 멀어진 오른쪽은 넙다리뼈가 벌어지며 발날로 지탱하는 패턴이 형성되어 전신적인 비대칭 움직임을 유발합니다.',
    },
    'LEFT_HEEL_UNNORMAL|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 발등굽힘 가동범위 제한',
      priority: 2,
      content: '스쿼트 하강 시 왼쪽 발목의 발등굽힘 제한으로 무릎이 충분히 전진하지 못해 발뒤꿈치가 들리는 보상이 나타납니다.\n\n이와 함께 왼쪽 엉덩관절의 굽힘 가동성 부족으로 인해 왼쪽 골반이 충분히 내려가지 못하고 위로 치솟는 골반 끌어당김(Hike) 현상이 발생합니다.\n\n결과적으로 체중을 안정적으로 지지하며 내려가는 오른쪽 골반은 낮아지고, 왼쪽은 높게 유지되는 비대칭적인 하체 정렬과 움직임 패턴이 형성됩니다.',
    },
    'BODY_LEARN_FORWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 상체 과도한 앞으로 숙임',
      priority: 2,
      content: '스쿼트 하강 시 왼쪽 발목이 충분히 접히지 않아 무릎 전진이 줄어들고,\n이를 보완하기 위해 엉덩이를 뒤로 보내며 상체를 앞으로 기울여 균형을 유지하는 움직임이 나타납니다.\n\n이 과정에서 몸은 왼쪽 하체를 기준으로 지지를 처리하려는 경향을 보이며,\n그 결과 상체가 앞으로 기울어진 상태와 함께 왼쪽 골반이 상대적으로 높아 보이는 정렬 변화가 동시에 관찰될 수 있습니다.',
    },
    // 나머지 LEFT_HIP_HIGHER
    'ANKLE_INWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ANKLE_OUTWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'BODY_LEARN_BACKWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ANKLE_RIGHT|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 ',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    // 왼쪽 골반 높이 상승 추가 나머지 케이스
    'HIP_CENTER_STABLE|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 골반 중심 안정',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_OUTWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 양쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_INWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 양쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_RIGHT|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발 벌림 / 왼쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'FOOT_LEFT|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발 모음 / 왼쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_FOOT_INWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_FOOT_OUTWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_FOOT_INWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 발 모음',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_FOOT_OUTWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 발 벌림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_KNEE_INWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 무릎 밖굽이',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_KNEE_OUTWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 무릎 안굽이(varus)',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|LEFT_KNEE_INWARD': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 무릎 밖굽이',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|LEFT_KNEE_OUTWARD': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 무릎 안굽이(varus)',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_ANKLE_INWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발목 안쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_ANKLE_OUTWARD': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발목 가쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_ANKLE_INWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 발목 안쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_ANKLE_OUTWARD|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 왼쪽 발목 가쪽번짐',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 골반 높이 상승',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'ARM_UNNORMAL|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 양쪽 어깨관절 굽힘 가동범위 제한',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'HEEL_UNNORMAL|LEFT_HIP_HIGHER': {
      title: '왼쪽 골반 높이 상승 + 양쪽 발뒤꿈치 들림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    'LEFT_HIP_HIGHER|RIGHT_HEEL_UNNORMAL': {
      title: '왼쪽 골반 높이 상승 + 오른쪽 발뒤꿈치 들림',
      priority: 2,
      content: '오버헤드 스쿼트 하강 말기에서\n무게중심이 한쪽으로 이동하며 왼쪽 골반이 상대적으로 높게 유지되는 정렬이 관찰됩니다.\n이 과정에서 오른쪽 골반은 더 내려가고(Drop),\n왼쪽은 위쪽에 머무르는(Hike) 비대칭적인 골반 높이 차이가 형성됩니다.\n이 패턴은 특정 부위의 단일 보상으로 한정되기보다는,\n동작 중 하중을 지지하고 분배하는 과정에서 골반 위치를 중심으로 나타난 전신적인 정렬 선택의 결과로 이해할 수 있습니다.',
    },
    // ── 발 방향 비대칭 + 무릎 정렬 조합 ─────────────────────────
    'FOOT_RIGHT|KNEE_RIGHT': {
      title: '오른쪽 발 벌림 / 왼쪽 발 모음 + 오른쪽 무릎 밖굽이 / 왼쪽 무릎 중립',
      priority: 4,
      content: '발의 방향이 오른쪽으로 치우친 상태에서 지면을 지지하려는 과정에서\n체중이 상대적으로 오른쪽 하체에 더 실리는 흐름이 나타납니다.\n이로 인해 오른쪽 무릎은 중심선 쪽으로 모이며 정렬 변화가 나타나고,\n왼쪽 하체는 비교적 안정적인 지지 역할을 유지합니다.\n결과적으로 발 방향의 비대칭과 무릎 정렬 차이가 함께 나타나는\n오른쪽 하체 중심의 사용 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_LEFT|KNEE_LEFT': {
      title: '오른쪽 발 모음 / 왼쪽 발 벌림 + 왼쪽 무릎 밖굽이 / 오른쪽 무릎 중립',
      priority: 4,
      content: '발의 방향이 왼쪽으로 치우친 상태에서 지면을 지지하려는 과정에서\n체중이 상대적으로 왼쪽 하체에 더 실리는 흐름이 나타납니다.\n이로 인해 왼쪽 무릎은 중심선 쪽으로 모이며 정렬 변화가 나타나고,\n오른쪽 하체는 비교적 안정적인 지지 역할을 유지합니다.\n결과적으로 발 방향의 비대칭과 무릎 정렬 차이가 함께 나타나는\n왼쪽 하체 중심의 사용 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_RIGHT|KNEE_OUTWARD': {
      title: '왼발 정면 정렬 / 오른쪽 발 벌림 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 중립',
      priority: 4,
      content: '오른발이 바깥쪽을 향한 상태에서 지면을 지지하면서\n오른쪽 하체는 넓은 기반으로 버티는 사용 방식을 선택하게 됩니다.\n이 과정에서 오른쪽 무릎 역시 바깥으로 벌어진 정렬을 유지하고,\n왼쪽 하체는 비교적 중립적인 정렬로 내려가는 역할을 맡게 됩니다.\n결과적으로 오른쪽은 지지 중심, 왼쪽은 움직임 중심으로 역할이 나뉘는\n비대칭적인 하체 사용 패턴이 형성됩니다.',
    },
    'FOOT_RIGHT|KNEE_LEFT': {
      title: '왼발 정면 정렬 / 오른쪽 발 벌림 + 왼쪽 무릎 안굽이 / 오른쪽 무릎 중립',
      priority: 4,
      content: '발의 방향은 오른쪽에 치우쳐 있지만,\n하중 분배 과정에서 왼쪽 하체가 상대적으로 더 많은 지지 역할을 맡게 되며\n왼쪽 무릎이 바깥으로 벌어진 정렬이 함께 나타납니다.\n이로 인해 발 방향과 무릎 정렬이 서로 다른 쪽에서 드러나며,\n좌우 하체가 각기 다른 방식으로 균형을 맞추는\n교차형 비대칭 하체 사용 패턴으로 해석할 수 있습니다.',
    },
    'FOOT_LEFT|KNEE_OUTWARD': {
      title: '오른쪽 발 정면 정렬 / 왼쪽 발 벌림 + 오른쪽 무릎 안굽이 / 왼쪽 무릎 중립',
      priority: 4,
      content: '왼발이 바깥쪽을 향한 상태에서 지면을 지지하면서\n왼쪽 하체는 넓은 기반으로 버티는 사용 방식을 선택하게 됩니다.\n이 과정에서 왼쪽 무릎 역시 바깥으로 벌어진 정렬을 유지하고,\n오른쪽 하체는 비교적 중립적인 정렬로 내려가는 역할을 맡게 됩니다.\n결과적으로 왼쪽은 지지 중심, 오른쪽은 움직임 중심으로 역할이 나뉘는\n비대칭적인 하체 사용 패턴이 형성됩니다.',
    },
    'FOOT_LEFT|KNEE_RIGHT': {
      title: '오른쪽 발 정면 정렬 / 왼쪽 발 벌림 + 왼쪽 무릎 안굽이 / 오른쪽 무릎 중립',
      priority: 4,
      content: '발의 방향은 왼쪽에 치우쳐 있지만,\n하중 분배 과정에서 오른쪽 하체가 상대적으로 더 많은 지지 역할을 맡게 되며\n오른쪽 무릎이 바깥으로 벌어진 정렬이 함께 나타납니다.\n이로 인해 발 방향과 무릎 정렬이 서로 다른 쪽에서 드러나며,\n좌우 하체가 각기 다른 방식으로 균형을 맞추는\n교차형 비대칭 하체 사용 패턴으로 해석할 수 있습니다.',
    },
    // ── 골반 중심 안정 (정상 골반) 계열 ─────────────────────────
    'BODY_LEARN_FORWARD|HIP_CENTER_STABLE': {
      title: '골반 중심 안정 + 상체 과도한 앞으로 숙임',
      priority: 4,
      content: '오버헤드 스쿼트 하강 시 골반 중심은 양발 사이에 유지되지만,\n동작 깊이를 계속 확보하기 위해 상체, 팔, 발목 중 움직임이 덜 되는 부위를 대신해 다른 부위가 더 사용되는 조절 변화가 나타납니다.\n\n그 결과 하체 중심은 유지된 상태에서,\n전신의 움직임 사용 비율이 달라지는 패턴이 함께 관찰될 수 있습니다.',
    },
    // 기타 나머지 케이스 (정상 골반 + 비정상 다른 항목)
    'BODY_LEARN_BACKWARD|HIP_CENTER_STABLE': {
      title: '골반 중심 안정 + 상체 과도한 뒤로 젖힘',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'FOOT_OUTWARD|HIP_CENTER_STABLE': {
      title: '기타 패턴 ',
      priority: 5,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'ANKLE_INWARD|HIP_CENTER_STABLE': {
      title: '기타 패턴 ',
      priority: 5,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'ANKLE_OUTWARD|HIP_CENTER_STABLE': {
      title: '기타 패턴 ',
      priority: 5,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'ARM_UNNORMAL|HIP_CENTER_STABLE': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'HIP_CENTER_STABLE|LEFT_ARM_UNNORMAL': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'HIP_CENTER_STABLE|RIGHT_ARM_UNNORMAL': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'HEEL_UNNORMAL|HIP_CENTER_STABLE': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'HIP_CENTER_STABLE|LEFT_HEEL_UNNORMAL': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
    'HIP_CENTER_STABLE|RIGHT_HEEL_UNNORMAL': {
      title: '기타 패턴 ',
      priority: 4,
      content: '골반의 중심과 좌우 높이는 전반적으로 안정적으로 유지되지만,\n동작을 진행하는 과정에서 발의 방향이나 발목 각도를 활용해\n하부에서 균형을 세밀하게 조절하는 움직임이 함께 관찰됩니다.\n\n이로 인해 전체적인 정렬은 유지되는 것처럼 보이지만,\n동작 깊이나 반복 상황에 따라 관절별 사용 비중에는 차이가 나타날 수 있습니다.',
    },
  };

export const EXERCISE_CASE_DB: Record<string, {
    squat: { isNormal: boolean; items: string[]; methods: string[] };
    lunge: { isNormal: boolean; items: string[]; methods: string[] };
    plank: { isNormal: boolean; items: string[]; methods: string[] };
    curlUp: { isNormal: boolean; items: string[]; methods: string[] };
    clam: { isNormal: boolean; items: string[]; methods: string[] };
    hamstring: { isNormal: boolean; items: string[]; methods: string[] };
  }> = {
    // ── 팔 위치 (arm) ─────────────────────────────────────────
    'arm:NORMAL': {
      squat: { isNormal: true, items: [
        '양 팔을 180도 위로 든 오버헤드 포지션에서도 팔이 앞으로 떨어지지 않고 수직 라인을 유지하여, 척추를 바르게 세우는 데 기여합니다.',
        '상지의 우수한 가동성 덕분에 하강 시 시선과 가슴이 정면을 향하며, 하체와 상체의 역학적 연결이 매우 안정적입니다.',
        '양측 견관절의 대칭적인 유연성을 바탕으로 동작 중 상체의 좌우 흔들림 없이 중심을 견고하게 유지합니다.',
      ], methods: [
        '하단 구간에서 멈춘 채 양 팔을 귀 뒤로 미세하게 더 보내는 \'숄더 프레스 펌핑\'을 추가하여, 최대 가동 범위에서의 견갑골 통제력을 챌린지합니다.',
        '한 팔만 180도로 들고 스쿼트를 수행하며, 비대칭 부하 속에서도 몸통이 회전하지 않도록 코어의 저항 능력을 강화합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '팔을 180도로 올린 상태에서 런지 수행 시, 상체의 수직 정렬이 유도되어 체중이 하체 관절의 중앙으로 정확히 전달됩니다.',
        '견관절의 충분한 가동성이 확보되어 하강 시 골반과 척추가 뒤로 젖혀지는 보상 작용 없이 바른 정렬을 유지합니다.',
        '좌우 런지 교체 시에도 상지의 180도 정렬이 변함없이 견고하게 유지되는 우수한 제어 능력이 확인됩니다.',
      ], methods: [
        '양 팔을 180도로 유지한 채 워킹 런지를 실시하여, 동적인 이동 중에도 상체의 수직 축과 팔의 각도를 사수하는 능력을 챌린지합니다.',
        '런지 하단 자세에서 팔을 180도 위치에서 좌우로 가볍게 흔드는 \'펜듈럼 챌린지\'를 통해 상지 안정성을 극대화합니다.',
      ] },
      plank: { isNormal: true, items: [
        '한 팔을 180도 전방으로 뻗는 \'암 리치(Arm Reach)\' 동작 시, 견관절의 가동 범위가 충분하여 골반의 수평이 깨지지 않고 유지됩니다.',
        '팔을 끝까지 뻗는 과정에서 어깨가 귀에 붙는 과긴장 반응 없이 견갑골의 하방 안정화 능력이 안정적으로 나타납니다.',
        '상지의 우수한 가동성과 코어의 결합력이 시너지를 내어 동적인 팔 움직임 속에서도 전신 정렬이 일관되게 관찰됩니다.',
      ], methods: [
        '팔을 180도 뻗은 상태에서 가벼운 덤벨을 들고 상하좌우로 작은 원을 그리는 \'핸드 서클\'을 추가하여 회전 안정성을 극한으로 챌린지합니다.',
        '짐볼 위에 팔을 올리고 전방으로 최대한 밀어내는 동작을 통해, 최대 가동 범위에서의 코어 통제력을 시험합니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '양 팔을 머리 위(180도)로 길게 뻗은 상태에서도 목의 과도한 개입 없이 복부의 힘만으로 상체를 안정적으로 들어 올립니다.',
        '상지의 가동 범위가 확보되어 팔의 무게가 복부에 더 큰 저항을 전달하는 효율적인 웨이트 레버리지(Leverage)를 활용합니다.',
        '반복 수행 중에도 팔의 각도가 흐트러지지 않고 정중앙 라인을 유지하는 우수한 상체 조절 능력이 확인됩니다.',
      ], methods: [
        '양손에 토닝볼을 들고 팔을 180도 유지하며 컬업을 수행하여, 복부 수축의 강도와 상지 정렬 유지력을 동시에 챌린지합니다.',
        '상체를 들어 올린 정점에서 팔을 귀 뒤로 더 보내는 미세한 움직임을 추가하여 가동성 끝 범위에서의 근육 제어력을 향상시킵니다.',
      ] },
      clam: { isNormal: true, items: [
        '옆으로 누워 아래쪽 팔을 180도 위로 뻗었을 때, 흉추와 경추의 꺾임 없이 목과 어깨 라인이 편안하고 일직선으로 정렬됩니다.',
        '상지의 유연성 덕분에 옆구리 라인(측면 사슬)이 눌리지 않고 신장되어, 하체 동작(클램)을 위한 안정적인 베이스를 제공합니다.',
        '상지 가동 범위의 여유로 인해 동작 중 어깨 주변부의 불필요한 긴장이 관찰되지 않는 양호한 상태입니다.',
      ], methods: [
        '위쪽 팔까지 180도 전방이나 위로 뻗어 지지면을 최소화한 상태에서 클램을 수행하며 전신 밸런스를 챌린지합니다.',
        '팔을 180도 뻗은 채로 몸통 전체를 일직선으로 유지하는 \'사이드 라잉 전신 안정성\' 테스트를 병행합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '누워서 팔을 180도로 머리 위 지면에 밀착시킨 상태로 스트레칭이 가능하여, 전신 후면 사슬의 통합적 신장 효과를 얻기에 유리합니다.',
        '상지의 가동 범위가 충분하여 스트레칭 중 가슴이 들리거나 허리가 꺾이는 보상 작용 없이 골반의 중립을 유지하기 쉽습니다.',
        '팔부터 발끝까지 이어지는 대칭적 정렬을 통해 하체 유연성 밸런스를 더욱 정교하게 조절할 수 있는 상태입니다.',
      ], methods: [
        '양 팔을 180도 뻗어 고정된 물체(발레 바, 기둥 등)를 잡고 햄스트링을 신장하여 상·하체의 반대 방향 저항(Counter-tension)을 챌린지합니다.',
        '능동적으로 다리를 들어 올리는 동작 시, 머리 위 팔의 180도 정렬이 지면에서 뜨지 않도록 유지하며 전신 안정성을 시험합니다.',
      ] },
    },
    'arm:ARM_UNNORMAL': {
      squat: { isNormal: false, items: [
        '어깨 가동성 부족으로 바벨을 잡을 때 팔꿈치가 뒤로 과하게 빠지며 상체가 앞으로 숙여지는 보상이 나타납니다.',
        '흉추를 충분히 펴지 못해 하강 시 허리가 말리거나 골반이 일찍 주저앉는 \'벗윙크\' 현상이 발생하기 쉽습니다.',
        '상체의 지지력이 불안정하여 하중이 허리 뒤쪽으로 쏠리고 엉덩이 근육의 참여도가 저하됩니다.',
      ], methods: [
        '바벨을 잡는 손의 너비를 넓게 설정하여 어깨 부담을 줄이고 흉추를 최대한 세울 수 있는 환경을 만듭니다.',
        '무릎 아래 받침대를 활용하거나 가동 범위 내에서만 하강하여 척추 중립이 깨지지 않도록 관리합니다.',
        '운동 전 광배근과 가슴 근육을 충분히 이완하여 어깨 관절의 가동 범위를 일시적으로 확보한 후 실시합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '팔을 들어 올리는 능력이 낮아 중심을 잡을 때 상체가 앞뒤로 심하게 흔들리며 안정성이 떨어집니다.',
        '흉추가 굽은 상태로 수행하게 되어 시선이 아래로 떨어지고 앞무릎에 비정상적인 부하가 가해집니다.',
        '상하체 연결성이 약해져 하강 시 상체가 구부정해지며 골반의 수평 정렬이 쉽게 무너집니다.',
      ], methods: [
        '양팔을 벌려 좌우 균형을 잡거나 벽을 짚고 수행하여 상체의 흔들림을 물리적으로 억제합니다.',
        '"가슴 중앙을 정면 위로 들어 올린다"는 큐잉을 통해 흉추 신전을 유도하고 상체 수직 정렬을 맞춥니다.',
        '런지 동작 전 상체 스트레칭을 병행하여 굽은 정렬을 일시적으로 개선한 뒤 훈련을 진행합니다.',
      ] },
      plank: { isNormal: false, items: [
        '어깨 굴곡 각도가 나오지 않아 팔꿈치를 지면에 댈 때 상부 승모근의 과도한 긴장으로 목/어깨가 불편해질 수 있습니다.',
        '견갑골을 등 뒤로 고정하지 못하고 어깨가 앞으로 말리면서 코어의 힘이 중앙으로 모이지 않습니다.',
        '상부 등이 굽는 자세로 인해 골반이 아래로 처지는 보상이 나타나 허리 부담이 가중됩니다.',
      ], methods: [
        '일반 플랭크보다 높은 위치에 손을 대는 인클라인 플랭크를 통해 어깨의 각도 부담을 완화합니다.',
        '팔꿈치 사이 간격을 조절하여 견갑골 정렬을 최대한 편안하게 맞춘 상태에서 코어 압력을 유지합니다.',
        '유지 시간보다 등 상부를 평평하게 펴는 인지 능력을 기르는 데 집중하며 짧은 세트로 반복합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '어깨 가동성 제한으로 팔을 머리 뒤에 둘 때 이미 목과 어깨가 긴장된 상태가 되어 운동 효율이 급감합니다.',
        '상체를 말아 올릴 때 어깨의 뻣뻣함이 가슴 근육을 당겨 흉추의 유연한 굴곡을 방해합니다.',
        '복부 근육보다는 목의 힘으로 상체를 들어 올리려는 보상 작용이 강하게 나타납니다.',
      ], methods: [
        '손을 머리 뒤가 아닌 허벅지 위에 올려두고 손끝이 무릎을 향해 미끄러지듯 올라가는 방식으로 수정합니다.',
        '가동 범위에 집착하지 말고 등 상부가 바닥에서 살짝만 떨어지는 지점까지만 수축 자극을 느낍니다.',
        '호흡을 길게 내뱉으며 갈비뼈를 아래로 눌러주는 느낌을 강조하여 상체 긴장을 억제합니다.',
      ] },
      clam: { isNormal: false, items: [
        '옆으로 누웠을 때 머리를 받친 아래쪽 어깨 관절에 과도한 압박이 가해져 자세 유지가 힘들어집니다.',
        '상체의 뻣뻣함으로 인해 골반을 정면으로 고정하기 어렵고 몸통이 자꾸 앞으로 굽는 경향이 생깁니다.',
        '어깨의 불편함이 전신 긴장도를 높여 엉덩이 근육의 순수한 고립 수축을 방해하게 됩니다.',
      ], methods: [
        '머리 아래에 높은 베개나 블록을 받쳐 아래쪽 어깨의 각도 부담을 줄이고 목 정렬을 편안하게 맞춥니다.',
        '등 뒤에 벽을 대고 누워 상하체가 일직선이 되도록 강제 정렬한 상태에서 엉덩이 운동에 집중합니다.',
        '아래쪽 팔을 앞으로 뻗어 어깨 관절 공간을 확보한 뒤 몸통의 수평 정렬을 유지하며 수행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '상체 가동성 부족으로 손을 뻗는 동작에서 등이 과하게 굽어 정작 햄스트링은 늘어나지 않는 현상이 발생합니다.',
        '어깨와 흉추의 긴장이 하체까지 전달되어 근육이 이완되기보다 수축하려는 경향이 나타납니다.',
        '스트레칭 시 상체를 숙이는 각도가 제한되어 골반의 힌지 움직임을 충분히 활용하지 못합니다.',
      ], methods: [
        '손을 발끝에 닿게 하려 하지 말고 골반 위에 얹은 뒤 허리를 펴고 엉덩이만 뒤로 미는 동작을 연습합니다.',
        '스트레칭 로프나 수건을 활용하여 어깨를 무리하게 숙이지 않고도 다리를 당길 수 있는 환경을 만듭니다.',
        '선 자세보다는 누운 자세에서 스트레칭을 진행하여 상체 정렬의 영향을 최소화한 상태에서 이완합니다.',
      ] },
    },
    'arm:LEFT_ARM_UNNORMAL': {
      squat: { isNormal: false, items: [
        '왼쪽 어깨의 가동성 부족으로 바벨을 잡을 때 왼쪽 팔꿈치가 앞으로 밀리며 상체가 우측으로 회전합니다.',
        '하강 시 왼쪽 등의 긴장이 골반을 왼쪽 위로 당겨 올려 체중이 오른쪽으로 과하게 쏠리는 비대칭이 발생합니다.',
        '상승 시 좌우 어깨의 지지력 차이로 인해 바벨의 수평이 깨지며 척추에 비틀림 부하가 전달됩니다.',
      ], methods: [
        '왼쪽 손의 너비를 오른쪽보다 더 넓게 잡거나 스트랩을 활용하여 왼쪽 어깨의 부담을 줄여줍니다.',
        '하강 전 왼쪽 골반을 의도적으로 낮추고 상체의 정면 정렬을 확인한 뒤 대칭적으로 하중을 분배합니다.',
        '고중량 바벨 스쿼트 대신 고블렛 스쿼트(가슴 앞에 덤벨 지지)로 수정하여 어깨 비대칭의 영향을 차단합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 어깨의 긴장이 왼쪽 복사근을 당겨 하강 시 몸통이 왼쪽으로 기우는 현상이 나타납니다.',
        '앞발이 어느 쪽이냐에 따라 상체 비대칭이 하체 중심 잡기에 미치는 영향이 달라져 조절력이 저하됩니다.',
        '좌측 상체의 뻣뻣함이 골반의 수평 정렬을 방해하여 한쪽 무릎에만 과도한 하중이 쏠릴 수 있습니다.',
      ], methods: [
        '왼쪽 팔을 가볍게 굽혀 옆구리에 고정하고 오른쪽 팔로 좌우 균형을 잡으며 중심선 유지에 집중합니다.',
        '거울을 통해 양쪽 어깨의 높이가 수평을 유지하는지 체크하며 상체 회전 보상을 억제합니다.',
        '하강 시 왼쪽 골반이 위로 들리지 않도록 왼쪽 엉덩이 근육의 지지력을 강조하는 큐잉을 줍니다.',
      ] },
      plank: { isNormal: false, items: [
        '왼쪽 어깨가 지면을 충분히 밀어내지 못해 체중이 오른쪽 어깨로 은근히 전가되며 코어 비대칭이 발생합니다.',
        '유지 중 왼쪽 어깨가 귀 쪽으로 으쓱 올라가며 좌측 목 주변 근육에 과도한 피로가 집중됩니다.',
        '상체의 비틀림이 골반까지 전달되어 플랭크 중 골반이 시계 반대 방향으로 회전하는 보상이 나타납니다.',
      ], methods: [
        '왼쪽 팔꿈치 아래 낮은 패드를 깔아 지면 반발력을 인지시키고 좌우 어깨 높이를 강제로 맞춥니다.',
        '"왼쪽 겨드랑이 아래 힘으로 바닥을 밀라"는 큐잉을 통해 좌측 견갑골의 안정성을 확보합니다.',
        '긴 유지 시간보다 10초씩 끊어 수행하며 왼쪽 어깨의 정렬이 무너지기 전까지만 품질을 유지합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '팔을 머리 뒤로 둘 때 왼쪽 어깨의 긴장이 왼쪽 갈비뼈를 들어 올려 복부 수축을 방해합니다.',
        '상체를 들어 올릴 때 몸통이 왼쪽으로 미세하게 회전하며 복사근이 비대칭적으로 사용됩니다.',
        '왼쪽 목 근육이 오른쪽보다 더 과하게 개입되어 운동 후 좌측 목의 불편감을 호소할 수 있습니다.',
      ], methods: [
        '양손을 가슴 위에 교차하되 왼쪽 손이 아래로 가게 하여 왼쪽 어깨의 긴장도를 더 낮춰줍니다.',
        '상체를 말아 올릴 때 오른쪽 어깨보다 왼쪽 어깨가 바닥에서 늦게 떨어지는지 대칭성을 체크합니다.',
        '시선을 정면 중앙에 고정하고 몸통이 회전하지 않도록 코치가 거울/구두 큐잉으로 왼쪽 어깨의 수평을 안내합니다.',
      ] },
      clam: { isNormal: false, items: [
        '왼쪽으로 누웠을 때(아래쪽) 왼쪽 어깨의 가동성 제한으로 인해 상체가 앞으로 쏠리며 정렬이 깨집니다.',
        '오른쪽으로 누웠을 때(위쪽) 왼쪽 어깨의 긴장이 골반을 위로 잡아당겨 엉덩이 자극을 방해합니다.',
        '아래쪽 어깨의 불편함이 전신 긴장을 유도하여 엉덩이 근육의 순수한 고립력을 저하시킵니다.',
      ], methods: [
        '왼쪽으로 누울 때는 머리 아래 충분한 받침을 두어 아래쪽 어깨의 압박을 최소화하고 정렬을 맞춥니다.',
        '오른쪽으로 누울 때는 왼쪽 팔을 몸통 앞 바닥에 편안히 내려두어 견갑골이 위로 들리지 않게 관리합니다.',
        '왼쪽 옆구리가 바닥에서 과하게 눌리지 않도록 코어 텐션을 유지하여 골반 수평을 확보합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼쪽 팔의 가동성 부족으로 상체를 숙일 때 왼쪽 등이 더 굽어지며 좌측 요추에 비정상적 장력이 가해집니다.',
        '상체 비대칭이 골반을 비틀어 왼쪽 햄스트링은 덜 늘어나고 허리만 과하게 쓰이는 보상이 나타납니다.',
        '좌측 상체의 긴장도가 하체까지 전달되어 왼쪽 햄스트링의 이완 속도가 오른쪽보다 늦어집니다.',
      ], methods: [
        '손을 뻗는 대신 상체를 곧게 세운 상태에서 엉덩이만 뒤로 빼는 방식으로 좌우 대칭을 맞춥니다.',
        '왼쪽 햄스트링 스트레칭 시에는 팔의 움직임을 배제하고 골반의 정렬 유지에만 모든 집중을 둡니다.',
        '스트레칭 전 왼쪽 광배근을 먼저 이완하여 상체의 당김 현상을 줄인 뒤 하체 스트레칭에 들어갑니다.',
      ] },
    },
    'arm:RIGHT_ARM_UNNORMAL': {
      squat: { isNormal: false, items: [
        '오른쪽 어깨 가동성 부족으로 바벨을 잡을 때 오른쪽 팔꿈치가 위로 들리며 상체가 좌측으로 회전합니다.',
        '하강 시 오른쪽 등의 긴장이 골반 우측을 위로 당겨 하중이 왼쪽으로 과하게 쏠리는 비대칭이 관찰됩니다.',
        '상승 시 오른쪽 상체의 지지력이 흔들리며 바벨이 우측으로 처지는 등 척추 정렬이 비틀릴 수 있습니다.',
      ], methods: [
        '오른쪽 손 너비를 더 넓게 잡거나 손바닥이 아닌 손가락으로 가볍게 바벨을 지지하여 부담을 줄입니다.',
        '하강 전 오른쪽 골반을 아래로 낮추는 큐잉을 주고 양발 접지압이 동일한지 실시간 확인합니다.',
        '바벨 대신 덤벨을 양손에 들고 수행하는 스플릿 스쿼트로 수정하여 상체 비대칭의 영향을 최소화합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 어깨의 긴장이 우측 옆구리를 당겨 하강 시 상체가 오른쪽으로 기우는 보상이 나타납니다.',
        '흉추가 오른쪽으로 미세하게 회전된 상태로 수행하게 되어 골반 정렬이 깨지고 무릎 궤적이 흔들립니다.',
        '우측 상체의 뻣뻣함이 하체 지지 안정성을 방해하여 반복 수행 시 중심 유지가 불안정합니다.',
      ], methods: [
        '오른쪽 팔을 가볍게 굽혀 옆구리에 밀착시키고 상체 정면 정렬을 유지하는 데 집중합니다.',
        '하강 시 오른쪽 어깨가 귀 쪽으로 들리지 않도록 견갑골 하강 인지력을 높이는 큐잉을 줍니다.',
        '거울을 통해 양쪽 골반 상단(ASIS)의 수평이 유지되는지 체크하며 대칭적으로 하강합니다.',
      ] },
      plank: { isNormal: false, items: [
        '오른쪽 어깨가 지면을 충분히 밀어내지 못해 체중이 왼쪽으로 쏠리며 코어 수축의 좌우 편차가 발생합니다.',
        '유지 중 오른쪽 상부 승모근에 과도한 긴장이 쏠려 어깨 통증과 목의 불편감을 호소할 수 있습니다.',
        '상체의 비틀림 보상으로 인해 골반이 시계 방향으로 회전하며 허리 뒤쪽에 비정상적 부하가 가해집니다.',
      ], methods: [
        '오른쪽 팔꿈치 아래 얇은 패드를 깔아 지면 반발력을 높이고 양쪽 어깨 높이를 수평으로 맞춥니다.',
        '"오른쪽 날개뼈 아래 근육으로 바닥을 밀어내라"는 실시간 피드백으로 우측 안정성을 확보합니다.',
        '횟수보다 오른쪽 어깨 정렬이 유지되는 시간까지만 고품질로 수행하여 비대칭 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '팔을 머리 뒤로 둘 때 오른쪽 어깨의 긴장이 상체를 오른쪽으로 회전시켜 복사근 불균형을 만듭니다.',
        '상체를 말아 올릴 때 오른쪽 견갑골이 바닥에서 부자연스럽게 떨어지며 흉추 분절 운동을 방해합니다.',
        '오른쪽 목 주변 근육의 과도한 개입으로 인해 운동 후 우측 목의 피로도가 현저히 높아질 수 있습니다.',
      ], methods: [
        '양손을 가슴 위에 교차하되 오른쪽 손이 아래로 가게 하여 오른쪽 어깨의 각도 부담을 덜어줍니다.',
        '시선을 천장 중앙에 고정하고 상체가 올라올 때 오른쪽 어깨가 먼저 들리지 않도록 조절합니다.',
        '호흡과 함께 오른쪽 갈비뼈를 아래로 지긋이 눌러주며 상체 외측 긴장을 억제한 상태에서 수축합니다.',
      ] },
      clam: { isNormal: false, items: [
        '오른쪽으로 누웠을 때(아래쪽) 오른쪽 어깨의 가동성 제한으로 인해 상체가 앞으로 쏟아지기 쉽습니다.',
        '왼쪽으로 누웠을 때(위쪽) 오른쪽 어깨의 긴장이 골반 우측을 위로 당겨 엉덩이 수축을 방해합니다.',
        '아래쪽 어깨의 불편함이 전신 긴장을 유도하여 타깃 근육인 중둔근의 고립력을 저하시킵니다.',
      ], methods: [
        '오른쪽으로 누울 때는 머리 아래 블록을 받쳐 아래쪽 어깨 공간을 충분히 확보하고 목 정렬을 맞춥니다.',
        '왼쪽으로 누울 때는 오른쪽 팔을 골반 옆이나 바닥에 편안히 두어 견갑골 정렬을 중립으로 유지합니다.',
        '오른쪽 옆구리가 바닥에 주저앉지 않도록 코어 텐션을 유지하여 골반의 수평 축을 확보합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른쪽 팔의 가동성 부족으로 상체를 숙일 때 오른쪽 등이 더 굽어지며 척추 비대칭 부하가 발생합니다.',
        '상체 비틀림이 골반 우측을 위로 당겨 오른쪽 햄스트링이 제대로 늘어나지 않는 현상이 관찰됩니다.',
        '우측 상체의 긴장도가 하체까지 연결되어 오른쪽 햄스트링의 이완 효율이 왼쪽보다 떨어집니다.',
      ], methods: [
        '상체를 무리하게 숙이지 말고 등 정렬을 평평하게 유지한 상태에서 엉덩이 힌지 움직임만 수행합니다.',
        '오른쪽 스트레칭 시에는 어깨 움직임을 배제하고 골반의 수평 정렬을 유지하는 데만 모든 노력을 기울입니다.',
        '스트레칭 전 오른쪽 광배근과 가슴 근육을 먼저 이완하여 상체의 당김 보상을 최소화한 뒤 실시합니다.',
      ] },
    },
    // ── 상체 기울기 (body) ─────────────────────────────────────
    'body:NORMAL': {
      squat: { isNormal: true, items: [
        '하강 및 상승 시 상체가 앞으로 숙여지거나 뒤로 젖혀지지 않고 수직 궤적을 유지하여 척추 관절의 부하 분산이 이상적입니다.',
        '상체의 중립 각도 덕분에 하중이 요추에 집중되지 않고 하체 근육군으로 온전히 전달되는 고효율 패턴이 관찰됩니다.',
        '상하 움직임 중 몸통의 흔들림이 제어되어 전신 정렬의 일관성이 매우 높게 나타납니다.',
      ], methods: [
        '하단 구간에서 3~5초간 정지한 후 상체의 수직 각도를 유지하며 폭발적으로 상승하는 \'포즈 스쿼트\'를 실시합니다.',
        '바벨이나 케틀벨을 가슴 앞(고블렛) 혹은 머리 위(오버헤드)로 들고 수행하며, 변하는 무게 중심 속에서도 상체 각도를 사수합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '상체가 지면과 수직을 이루어 앞발과 뒷발에 가해지는 하중 배분이 역학적으로 매우 균형 잡힌 상태입니다.',
        '상체의 전·후방 기울임이 억제되어 동작 중 골반의 중립 정렬을 유지하기에 최적화된 조건을 갖추고 있습니다.',
        '수직으로 곧게 선 상체 덕분에 하강 시 무릎에 가해지는 전방 전단력이 최소화된 안전한 수행 능력을 보여줍니다.',
      ], methods: [
        '런지 자세에서 양손을 머리 뒤에 얹고(프리즌 런지) 수행하여, 상체가 앞으로 숙여지려는 관성을 이겨내며 수직 정렬을 챌린지합니다.',
        '뒷발을 벤치에 올린 상태(RFESS)에서도 상체 각도가 변하지 않도록 코어의 제어력을 극한으로 끌어올립니다.',
      ] },
      plank: { isNormal: true, items: [
        '머리부터 발꿈치까지 일직선 라인을 형성하며, 흉추나 요추의 과도한 굴곡/신전 없이 상체의 중립 각도가 우수하게 유지됩니다.',
        '상체의 안정적인 수평 각도 덕분에 전면 복부와 후면 기립근이 대칭적인 긴장도를 형성하여 코어의 결합력이 높습니다.',
        '유지 시간이 길어져도 상체 라인이 아래로 처지거나 위로 솟지 않는 견고한 지지 능력이 확인됩니다.',
      ], methods: [
        '플랭크 상태에서 몸을 앞뒤로 미는 \'소우(Saw)\' 동작 시, 상체의 수평 각도가 흐트러지지 않도록 척추 중립 능력을 챌린지합니다.',
        '등 위에 가벼운 원판이나 소도구를 올리고, 상체 각도의 미세한 변화로 도구가 떨어지지 않게 집중하며 유지 시간을 늘립니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '상체를 들어 올릴 때 척추의 마디별 분절이 정확히 이루어지며, 몸통 중심선이 좌우나 전후로 치우침 없이 곧게 유지됩니다.',
        '상체의 정교한 각도 조절 덕분에 목 주변 근육의 과긴장 없이 복직근의 수축에만 자극이 명확히 집중됩니다.',
        '반복적인 수축과 이완 과정에서도 상체의 정중앙 정렬과 각도의 일관성이 우수하게 관찰됩니다.',
      ], methods: [
        '상체를 들어 올린 정점에서 양팔을 귀 옆으로 뻗어 상체의 지면 저항을 높인 상태로 대칭적 수축 강도를 챌린지합니다.',
        '폼롤러 위에 세로로 누워 좁은 지면 위에서 상체의 수직 밸런스를 잡으며 컬업을 수행하는 고난도 훈련을 적용합니다.',
      ] },
      clam: { isNormal: true, items: [
        '옆으로 누운 상태에서 상체가 앞뒤로 기울어지지 않고 지면과 수직을 유지하여, 골반을 고정하기 위한 견고한 베이스를 제공합니다.',
        '상체의 우수한 정렬 안정성 덕분에 하체 동작(외회전) 시 발생하는 회전력이 몸통으로 분산되지 않고 둔근에 고립됩니다.',
        '동작 전체 과정에서 어깨와 골반을 잇는 상체 라인이 흔들림 없이 일직선으로 유지되는 능력이 확인됩니다.',
      ], methods: [
        '지면에서 옆구리를 띄운 채 상체의 수직 각도를 유지하며 클램을 수행하여 전신 사슬의 안정성을 챌린지합니다.',
        '위쪽 팔을 천장 방향으로 곧게 뻗어 지지면을 최소화한 상태에서 상체 각도가 흔들리지 않도록 제어하며 수행합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '스트레칭 시 상체가 굽어지거나 뒤로 젖혀지지 않고 중립을 유지하여, 골반의 위치를 고정한 채 목표 근육만 신장시킵니다.',
        '상체의 바른 각도 덕분에 허리의 보상 작용 없이 햄스트링 조직에만 이완 자극이 정확하고 깊게 전달됩니다.',
        '양측 스트레칭 시 상체 각도의 변화가 없어 유연성 밸런스를 동일한 기준에서 체크하기에 매우 유리합니다.',
      ], methods: [
        '상체의 중립 각도를 유지한 채 힙 힌지(Hip Hinge) 패턴을 적용하여, 척추 정렬을 사수하며 햄스트링을 능동적으로 신장합니다.',
        '서 있는 자세에서 상체 각도가 흐트러지지 않게 벽에 등을 기대고 한 다리를 들어 올리는 \'고정형 챌린지\'를 실시합니다.',
      ] },
    },
    'body:BODY_LEARN_FORWARD': {
      squat: { isNormal: false, items: [
        '상체가 앞으로 굽어 있어 하강 시 무게 중심이 발앞쪽으로 쏠리며 무릎 관절에 과한 압박이 집중됩니다.',
        '흉추 신전 능력이 부족하여 하단 구간에서 허리가 일찍 말리는 벗윙크 현상이 발생하기 쉽습니다.',
        '상체의 지지력이 약해져 바벨의 하중이 요추에 직접 전달되며 엉덩이 근육의 참여가 제한됩니다.',
      ], methods: [
        '시선을 정면 위쪽으로 두어 흉추 신전을 유도하고 상체를 최대한 수직으로 세우려 노력합니다.',
        '뒤꿈치 아래 낮은 받침을 활용하여 상체가 앞으로 쏠리는 것을 물리적으로 억제합니다.',
        '하강 깊이보다 상체 정렬 유지에 집중하며 광배근을 하강시켜 척추를 단단하게 고정합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '굽은 등으로 인해 상체 무게 중심이 앞발로 과하게 이동하여 앞무릎 주변에 부담이 커질 수 있습니다.',
        '가슴이 닫혀 있어 시선이 아래로 고정되며 몸통 코어의 협응 능력이 현저히 떨어집니다.',
        '하강 시 상체가 구부정해지며 골반이 전방으로 기울어 엉덩이 근육의 수축 효율이 저하됩니다.',
      ], methods: [
        '"가슴 중앙을 정면 위로 들어 올린다"는 큐잉을 통해 흉추를 펴고 상체 수직 정렬을 확보합니다.',
        '양손을 가볍게 뒤통수에 두어 견갑골을 모으고 가슴 근육을 확장한 상태에서 수행합니다.',
        '하강 시 상체가 숙여지지 않도록 코치가 거울/영상과 구두 큐잉으로 상체 각도를 안내합니다.',
      ] },
      plank: { isNormal: false, items: [
        '상부 등이 굽어 있어 날개뼈 사이가 움푹 들어가는 보상이 나타나며 견갑대 안정성이 붕괴됩니다.',
        '고개가 아래로 떨어지며 목 뒤쪽 근육에 과도한 장력이 발생하고 유지 시간이 급격히 짧아집니다.',
        '흉추 후만 보상으로 인해 골반이 아래로 처지며 허리 뒤쪽 공간에 날카로운 압박이 전달됩니다.',
      ], methods: [
        '팔꿈치로 지면을 강하게 밀어내어 굽은 등 부위를 천장 방향으로 채워 넣는 인지 훈련을 합니다.',
        '턱을 몸쪽으로 당기고 정수리를 앞으로 밀어내어 경추부터 흉추까지 길게 펴는 느낌을 유지합니다.',
        '유지 시간보다 등 상부를 평평하게 펴는 품질에 집중하며 짧은 고품질 세트로 반복합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '이미 굽은 상체 정렬로 인해 흉곽이 닫혀 있어 복부 근육의 가동 범위가 매우 짧고 답답함을 느낍니다.',
        '상체를 말아 올릴 때 어깨와 가슴 근육의 단축이 흉추의 유연한 움직임을 방해하여 목만 쓰게 됩니다.',
        '등 근육의 뻣뻣함이 반동을 유발하여 복직근의 순수 수축력을 저하시키는 원인이 됩니다.',
      ], methods: [
        '손을 머리 뒤가 아닌 허벅지 위에 두어 상체 긴장을 줄이고 견갑골이 살짝 들릴 때까지만 수축합니다.',
        '동작 전 폼롤러를 활용해 흉추를 충분히 신전시킨 후 실시하여 일시적인 가동 범위를 확보합니다.',
        '호흡을 길게 내뱉으며 명치 부위를 바닥으로 지긋이 눌러주는 깊은 수축 감각에 집중합니다.',
      ] },
      clam: { isNormal: false, items: [
        '옆으로 누웠을 때 어깨가 앞으로 말리며 몸통이 굽어 골반의 수직 축을 유지하기 어렵습니다.',
        '굽은 등 정렬이 전신 사슬의 긴장도를 높여 타깃 근육인 중둔근의 고립을 방해합니다.',
        '상체의 뻣뻣함으로 인해 고관절 벌림 시 허리가 대신 회전하는 보상이 강하게 나타납니다.',
      ], methods: [
        '머리 아래 충분한 받침을 두어 목과 어깨 정렬을 편안하게 맞추고 등을 곧게 펴려 노력합니다.',
        '등 뒤에 벽을 밀착시켜 상체가 구부정해지거나 뒤로 넘어가지 않도록 물리적으로 차단합니다.',
        '가슴을 열고 시선을 정면으로 유지하여 상하체 연결성을 개선한 상태에서 엉덩이 운동을 합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '상체가 굽어 있어 손끝을 발에 닿게 하려다 정작 골반의 힌지 움직임은 일어나지 않게 됩니다.',
        '흉추 후만이 요추의 과도한 굴곡을 유도하여 햄스트링 이완보다 허리 늘어남이 먼저 발생합니다.',
        '상체 긴장도가 높아 신경계가 하체 근육의 이완 신호를 차단하여 스트레칭 효율이 반감됩니다.',
      ], methods: [
        '상체를 숙이는 각도에 집착하지 말고 등을 평평하게 편 상태에서 엉덩이만 뒤로 미는 동작을 연습합니다.',
        '손으로 발끝을 잡지 말고 스트레칭 로프를 사용하여 어깨와 등을 세운 채 다리만 당겨 늘립니다.',
        '선 자세보다는 누워서 한 다리를 올리는 방식을 통해 상체 정렬의 보상을 차단하고 이완합니다.',
      ] },
    },
    'body:BODY_LEARN_BACKWARD': {
      squat: { isNormal: false, items: [
        '상체가 뒤로 젖혀진 정렬은 허리 아치를 과하게 만들어 허리(요추)에 부담이 크게 실릴 수 있습니다.',
        '무게 중심이 뒤로 쏠려 하강 시 발가락 끝의 접지력이 약해지고 뒤꿈치로만 버티게 됩니다.',
        '갈비뼈가 들리는(Rib flare) 보상이 나타나 복압 유지 능력이 떨어지고 코어 안정성이 약화됩니다.',
      ], methods: [
        '갈비뼈를 아래로 눌러주는 느낌을 유지하며 복압을 앞뒤좌우로 팽팽하게 채우는 훈련을 합니다.',
        '턱을 가볍게 당겨 상체의 무게 중심을 약간 앞으로 이동시켜 전신 균형을 맞춥니다.',
        '하강 시 과도한 허리 아치가 생기지 않도록 골반을 중립으로 유지하며 엉덩이 근육을 활성화합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '상체가 뒤로 기울어지며 뒷발에 과도한 체중이 실리고 허리 뒤쪽 공간이 압박받게 됩니다.',
        '복사근의 통제력이 부족하여 하강 시 몸통이 흔들리거나 골반이 전방으로 밀리는 보상이 나타납니다.',
        '흉추의 신전이 과하여 견갑골의 안정성이 떨어지고 상하체 협응력이 저하됩니다.',
      ], methods: [
        '상체를 수직보다 5도 정도 앞으로 살짝 기울여 체중을 앞발 엉덩이 근육에 집중시킵니다.',
        '내뱉는 호흡을 통해 갈비뼈를 닫고 코어 장력을 확보하여 상체가 뒤로 젖혀지는 것을 방지합니다.',
        '뒷발 무릎이 지면에 닿기 전까지만 하강하며 요추에 무리한 신전 장력이 가해지지 않게 조절합니다.',
      ] },
      plank: { isNormal: false, items: [
        '등 상부가 너무 평평하여 견갑골이 척추 쪽으로 과하게 모이며 코어 전면 근육이 늘어납니다.',
        '허리가 아래로 푹 꺼지는 현상이 나타나 코어보다 허리 주변 수동조직(결합조직)에 부담이 실릴 수 있습니다.',
        '복근의 수축력이 약해져 유지 중 허리가 불편해지거나 부담이 커질 수 있으며 골반이 처집니다.',
      ], methods: [
        '골반을 살짝 말아주는 느낌(골반 후방경사 유도)을 통해 요추 아치를 평평하게 만듭니다.',
        '복부 하단에 강한 힘을 주어 갈비뼈와 골반 사이의 간격을 좁힌 상태에서 버팁니다.',
        '횟수보다 허리가 처지지 않는 시간까지만 수행하며 코어의 대항력을 기르는 데 집중합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '흉추가 뻣뻣하게 신전되어 있어 상체를 동그랗게 마는 분절 움직임 자체가 매우 어렵습니다.',
        '복직근이 이미 늘어나 있는 정렬이라 수축 신호를 보내도 근육의 참여도가 현저히 떨어집니다.',
        '상체를 억지로 들어 올리려다 허리 뒤쪽 근육이 과하게 수축하며 허리 긴장을 유발합니다.',
      ], methods: [
        '바닥과 허리 사이의 공간을 없애는 \'임프린팅\' 동작을 먼저 숙달한 후 컬업을 실시합니다.',
        '상체를 높이 드는 것보다 등 하부가 바닥을 누르는 힘을 유지하며 가슴뼈를 골반으로 당깁니다.',
        '폼롤러를 등 상부에 대고 흉추의 굴곡 가동성을 충분히 인지시킨 후 동작을 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '상체가 뒤로 젖혀진 습관이 옆으로 누웠을 때도 나타나 골반이 뒤로 쉽게 회전하며 보상합니다.',
        '요추의 과신전 장력이 엉덩이 근육의 순수한 외회전 수축을 방해하고 허리 긴장을 만듭니다.',
        '갈비뼈가 들리면서 코어 고정력이 약해져 다리를 벌릴 때 몸통이 함께 흔들립니다.',
      ], methods: [
        '배꼽을 척추 쪽으로 당겨 요추 아치를 평평하게 조절한 상태에서 골반 안정성을 확보합니다.',
        '가슴을 의도적으로 닫고 시선을 약간 아래로 두어 상체가 뒤로 젖혀지는 보상을 억제합니다.',
        '아주 작은 범위에서 엉덩이 근육이 단독으로 수축되는지 코치가 실시간으로 확인하며 진행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '허리 아치가 과하여 스트레칭 시 햄스트링보다 요추 주변 근육이 먼저 긴장하게 됩니다.',
        '상체가 뒤로 기우는 성향 때문에 엉덩이 힌지를 활용해 앞으로 숙이는 동작이 부자연스럽습니다.',
        '햄스트링이 이완되기보다 골반이 앞으로 더 기울어지며(전방경사) 스트레칭 효율이 낮아집니다.',
      ], methods: [
        '갈비뼈를 닫고 복부 정면의 장력을 확보하여 허리가 꺾이지 않도록 통제한 상태에서 늘립니다.',
        '엉덩이를 뒤로 밀어낼 때 요추 아치가 심해지지 않는 범위 내에서만 정렬을 유지하며 이완합니다.',
        '의자에 앉아서 한 다리를 뻗는 방식을 통해 골반의 중립을 더 쉽게 확보한 상태에서 실시합니다.',
      ] },
    },
    // ── 발등 굽힘 (heel) ──────────────────────────────────────
    'heel:NORMAL': {
      squat: { isNormal: true, items: [
        '충분한 발등굽힘 가동성 덕분에 하강 시 발뒤꿈치가 지면에서 뜨지 않고 견고한 접지력을 유지합니다.',
        '발목의 가동 범위가 확보되어 깊은 하강 시에도 상체가 앞으로 과하게 쏠리지 않고 안정적인 무게 중심을 유지합니다.',
        '무릎이 발가락 방향으로 부드럽게 전진하며 하체 관절 전체의 역학적 부하를 효율적으로 분산시킵니다.',
      ], methods: [
        '발뒤꿈치가 붙은 상태를 유지하며 가장 깊은 지점(Full Squat)에서 5초간 버티는 \'가동성 끝 범위 제어\' 훈련을 실시합니다.',
        '발가락만 지면에서 살짝 든 채(발뒤꿈치와 발볼만 접지) 스쿼트를 수행하여 발목의 능동적 안정성을 챌린지합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '앞발의 발목 가동성이 우수하여 하강 시 뒤꿈치 들림 없이 발바닥 전체로 지면을 밀어내는 강한 지지력을 발휘합니다.',
        '발목의 유연한 움직임 덕분에 무릎이 전방으로 충분히 이동하며 런지 동작의 가동 범위를 깊게 확보합니다.',
        '양측 발목 가동성이 대칭적으로 우수하여 좌우 런지 수행 시 일관된 리듬과 깊이를 유지합니다.',
      ], methods: [
        '앞발의 발가락 쪽을 낮은 플레이트 위에 올리고(발등굽힘 강조) 런지를 수행하여, 더 깊은 발목 가동성 환경에서도 정렬을 사수합니다.',
        '뒷발을 벤치에 올린 상태(RFESS)에서 앞발 뒤꿈치가 뜨지 않게 유지하며 엉덩이를 깊게 내리는 고난도 챌린지를 적용합니다.',
      ] },
      plank: { isNormal: true, items: [
        '발목의 발등굽힘 각도가 정상 범위를 유지하여 뒤꿈치를 뒤로 밀어내는 전신 후면 사슬의 긴장도를 효과적으로 형성합니다.',
        '발목 관절의 중립 안정성을 바탕으로 종아리부터 코어까지 이어지는 힘의 전달 경로가 끊김 없이 연결됩니다.',
        '유지 시간 동안 발목의 각도가 무너지지 않고 일관된 접지 상태를 유지하는 능력이 확인됩니다.',
      ], methods: [
        '발가락 끝으로 지면을 밀어 몸을 앞뒤로 크게 이동시키는 \'락킹 플랭크\' 중에도 발목 가동성을 제어하며 뒤꿈치 위치를 사수합니다.',
        '한 다리를 들고 플랭크를 수행하며 지지하는 발목의 굴곡 각도가 변하지 않도록 코어의 하중 제어 능력을 챌린지합니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '발목 가동성이 확보되어 무릎을 굽히고 누운 자세에서 발바닥 전체가 지면에 밀착되어 안정적인 하체 지지대를 형성합니다.',
        '상체 굴곡 시 발등굽힘 조절 능력을 통해 하체가 들리거나 흔들리는 보상 작용을 억제하고 복부 수축에 집중합니다.',
        '반복적인 수축 과정에서도 발바닥의 접지 면적이 변하지 않고 일관된 지지력을 제공합니다.',
      ], methods: [
        '발바닥 전체를 지면에 붙인 상태를 유지하며, 다리를 조금씩 멀리 뻗어 발목 가동성을 시험함과 동시에 복부 저항을 높입니다.',
        '상체를 들어 올린 정점에서 발뒤꿈치로 지면을 더 강하게 누르는 큐잉을 적용하여 하체-코어의 협응력을 챌린지합니다.',
      ] },
      clam: { isNormal: true, items: [
        '준비 자세에서 발목의 가동 범위가 중립을 유지하여 양발 날이 안정적으로 맞닿아 고관절 움직임을 위한 견고한 축을 형성합니다.',
        '동작 수행 중 발목이 펴지거나 꺾이는 보상 패턴 없이 발목 각도가 일정하게 유지되어 둔근 자극에 집중하기 유리합니다.',
        '발목의 우수한 정적 정렬이 무릎과 골반의 위치를 고정하는 데 기여하여 움직임의 순도를 높입니다.',
      ], methods: [
        '양발을 지면에서 띄운 채 발목의 발등굽힘 상태를 유지하며 클램을 수행하여, 공중에서의 발목 정렬 유지력을 챌린지합니다.',
        '발목 사이에 저항 밴드를 감고 발목 각도가 무너지지 않게 버티며 무릎을 벌리는 고난도 고립 훈련을 실시합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '발등을 몸쪽으로 당기는 가동 범위가 충분하여, 스트레칭 시 종아리와 햄스트링으로 이어지는 후면 사슬 전체를 효과적으로 신장시킵니다.',
        '발목 유연성 덕분에 무릎을 완전히 편 상태에서도 발가락이 안으로 굽지 않고 정방향 정렬을 유지합니다.',
        '발목의 우수한 가동 범위 덕분에 스트레칭 강도를 정교하게 조절할 수 있는 이상적인 상태입니다.',
      ], methods: [
        '발등을 몸쪽으로 최대한 당긴(Dorsiflexion) 상태를 등척성으로 유지하며 스트레칭하여 신경 가동성을 극한으로 챌린지합니다.',
        '능동적으로 다리를 들어 올리는 동작 시, 본인의 근력으로 발목 각도를 끝까지 유지하며 유연성을 확보하는 능력을 시험합니다.',
      ] },
    },
    'heel:HEEL_UNNORMAL': {
      squat: { isNormal: false, items: [
        '하강 시 발목 가동성 부족으로 뒤꿈치가 들리며 상체가 앞으로 과하게 숙여지는 보상이 나타납니다.',
        '무게 중심이 발앞쪽으로 쏠려 무릎 관절에 과한 압박이 집중되고 허리 부담이 가중됩니다.',
        '척추 중립을 유지하지 못하고 하단 구간에서 골반이 일찍 말리는 벗윙크 현상이 발생합니다.',
      ], methods: [
        '뒤꿈치 아래 낮은 받침을 활용하여 발목 각도를 보완하고 상체 수직 정렬을 확보합니다.',
        '정렬이 유지되는 깊이까지만 하강하며 가동 범위 내에서 정교한 통제 능력을 기릅니다.',
        '운동 전 종아리 근육과 발바닥 근막을 충분히 이완하여 일시적 가동 범위를 확보합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발 발목 가동성 제한으로 하강 시 뒤꿈치가 지면에서 뜨며 중심 유지가 매우 불안정합니다.',
        '수직 하강이 어려워 상체가 앞으로 쏠리며 앞무릎 주변에 하중이 과도하게 실릴 수 있습니다.',
        '뒷발 발가락의 폄 가동성까지 부족할 경우 하강 깊이가 극도로 제한되어 운동 효율이 낮아집니다.',
      ], methods: [
        '보폭을 평소보다 줄여 발목에 가해지는 각도 부담을 낮춘 상태에서 정렬을 연습합니다.',
        '"앞발 뒤꿈치로 지면을 뚫는다"는 큐잉을 통해 지지력을 확보하고 엉덩이 참여를 유도합니다.',
        '코치가 거울/영상과 구두 큐잉으로 무릎 궤적을 실시간 안내하여 발목 제한으로 인한 보상 움직임을 억제합니다.',
      ] },
      plank: { isNormal: false, items: [
        '발목이 충분히 굽혀지지 않아 발가락 끝에 하중이 집중되며 종아리가 과하게 뻣뻣해지거나 당길 수 있습니다.',
        '하체 사슬의 긴장도가 높아 골반이 위로 들리거나 허리 아치가 심해지는 보상이 나타납니다.',
        '발목 불안정성이 코어의 힘을 분산시켜 유지 중 어깨와 손목에 과도한 하중이 쏠립니다.',
      ], methods: [
        '뒤꿈치를 벽에 대고 수행하여 물리적인 지지력을 확보하고 발목의 긴장도를 분산시킵니다.',
        '유지 시간보다 발목 정렬을 중립으로 유지하며 코어 압력을 채우는 품질에 집중합니다.',
        '짧은 시간 반복하더라도 하체 정렬이 무너지기 전까지만 수행하여 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '발목 가동성 부족으로 발바닥 전체 접지가 어려워 복부 수축 시 다리가 자꾸 들리는 현상이 생깁니다.',
        '하체 지지력이 약해 골반 고정이 불안정해지며 복부 대신 목과 어깨 힘으로 올라오게 됩니다.',
        '하체의 긴장도가 복부까지 전달되어 부드러운 흉추 굴곡 움직임을 방해합니다.',
      ], methods: [
        '발 위치를 몸에서 조금 더 멀리 두어 발목 각도 부담을 줄인 상태에서 접지력을 확보합니다.',
        '무릎 사이에 볼을 끼워 하체 정렬을 고정하고 복부 정방향 수축 인지력을 높입니다.',
        '횟수보다 상체가 올라올 때 뒤꿈치가 지면에서 떨어지지 않는지 품질 위주로 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '발목의 뻣뻣함이 옆으로 누운 자세의 안정성을 떨어뜨려 고관절 회전 시 골반 보상을 유도합니다.',
        '하체 외측 사슬의 긴장도가 높아 엉덩이 고립 수축보다 허리나 허벅지 근육 개입이 빨라집니다.',
        '발목 주변 근육의 과긴장으로 인해 엉덩이 근육의 자극 인지력이 현저히 낮아질 수 있습니다.',
      ], methods: [
        '발목을 편안한 각도로 두고 골반 수직 축 유지를 위해 벽/밴드/소도구로 정렬을 보조합니다.',
        '아주 작은 범위에서 엉덩이 근육이 단독 수축하는지 체크하며 제어 중심으로 수행합니다.',
        '동작 전 발목 주변 연부 조직을 이완하여 전신 긴장도를 낮춘 상태에서 훈련을 진행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발목 가동성 제한으로 발끝을 당기는 동작 자체가 불편감을 키울 수 있어 효율적 이완을 방해합니다.',
        '햄스트링보다 종아리 뒤쪽의 팽팽함이 먼저 느껴져 정작 타깃 근육은 늘어나지 않게 됩니다.',
        '상체 긴장이 하체까지 연결되어 신경계가 근육 이완 신호를 차단하는 현상이 나타납니다.',
      ], methods: [
        '발목을 억지로 당기지 말고 발바닥을 벽에 대는 방식을 통해 편안한 각도에서 이완합니다.',
        '스트레칭 로프를 사용하여 어깨와 등을 세운 채 다리만 서서히 당겨 늘립니다.',
        '범위 확대보다 골반 수평 정렬 유지를 최우선으로 하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'heel:LEFT_HEEL_UNNORMAL': {
      squat: { isNormal: false, items: [
        '하강 시 왼쪽 발목 제한으로 인해 골반이 오른쪽으로 밀리며 체중이 우측으로 과하게 쏠립니다.',
        '왼쪽 뒤꿈치가 일찍 들리며 상체가 우측으로 회전하는 보상이 나타나 척추 정렬을 비틉니다.',
        '상승 시 우측 지면 반발력이 우세하여 몸이 한쪽으로 기우는 조절력 저하가 관찰됩니다.',
      ], methods: [
        '왼쪽 뒤꿈치 아래에만 얇은 패드를 깔아 좌우 발목 각도 차이를 물리적으로 보정합니다.',
        '"왼쪽 뒤꿈치를 지면에 더 강하게 누르라"는 큐잉을 통해 좌우 하중 분배를 5:5로 맞춥니다.',
        '정렬이 깨지기 전까지만 하강하며 양쪽 무릎 궤적이 대칭을 이루는지 실시간 체크합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 다리가 앞일 때 뒤꿈치가 지면에서 뜨며 무릎이 안으로 흔들리는 불안정성이 극심합니다.',
        '좌측 발목 제한이 골반을 오른쪽 위로 밀어올려 런지 시 상체 수직 정렬이 무너집니다.',
        '좌우 수행 시 좌측의 안정 능력이 현저히 낮아 운동 품질의 심한 편차가 관찰됩니다.',
      ], methods: [
        '왼쪽 수행 시 보폭을 줄여 발목 부담을 낮추고 뒤꿈치 접지를 강조하여 수직 지지력을 확보합니다.',
        '거울을 통해 골반 수평과 무릎 궤적을 실시간 점검하며 코치의 구두/시각 피드백에 따라 하강합니다.',
        '왼쪽 발목 주변을 먼저 이완한 뒤 수행하여 좌우 수행 능력의 격차를 줄입니다.',
      ] },
      plank: { isNormal: false, items: [
        '왼쪽 발목의 뻣뻣함이 골반 좌측을 당겨 코어 중앙의 긴장 균형을 방해하게 됩니다.',
        '하중이 정상인 오른쪽 발로 은근히 전가되면서 코어 근육이 편향되게 수축합니다.',
        '유지 중 왼쪽 발가락 끝이 불편하거나 과하게 뻣뻣해질 수 있으며 정렬 품질이 급격히 저하됩니다.',
      ], methods: [
        '왼쪽 발을 오른쪽보다 약간 뒤에 위치시켜 각도 부담을 덜어주고 골반 수평을 맞춥니다.',
        '양쪽 뒤꿈치를 벽에 동일하게 밀착시켜 물리적 지지력을 대칭으로 확보합니다.',
        '정렬이 무너지기 전까지만 짧은 세트로 반복하여 보상 패턴 고착을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '왼쪽 발 접지가 약해지며 복부 수축 시 골반 좌측이 들썩이는 불안정성이 발생합니다.',
        '하체 지지력 비대칭이 상체 말기 동작의 궤적을 비틀어 복사근의 불균형을 유발합니다.',
        '왼쪽 목 근육이 오른쪽보다 과하게 개입되어 운동 후 좌측 목 피로도를 호소할 수 있습니다.',
      ], methods: [
        '왼쪽 발 위치를 조금 더 멀리 두어 좌측 뒤꿈치 접지력을 정상인 우측 수준으로 맞춥니다.',
        '복부 좌우 수축 강도를 실시간 피드백하여 비대칭적인 힘 사용을 즉각 수정합니다.',
        '무릎 사이에 볼을 끼워 하체 정렬을 강제 고정한 후 복부 중앙 수축 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '왼쪽 엉덩이 조절 능력이 우측보다 낮아 클램 수행 시 골반 회전 보상이 심해집니다.',
        '왼쪽 수행 시 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 패턴이 좌측에서 관찰됩니다.',
        '좌우 발목 정렬 차이가 고관절 회전 축의 비대칭을 만들어 운동 범위를 제한합니다.',
      ], methods: [
        '왼쪽 수행 시 코치가 골반이 흔들리지 않도록 가볍게 지지해 작은 범위에서 신경을 깨우는 데 집중합니다.',
        '왼쪽 발목을 최대한 편안한 위치에 두고 엉덩이 순수 수축에만 집중하도록 가이드합니다.',
        '좌측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 우측 수준으로 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼쪽 스트레칭 시 발목 제한으로 인해 햄스트링보다 종아리 바깥쪽이 먼저 당기게 됩니다.',
        '좌측 상체와 골반의 긴장도가 하체까지 전달되어 이완 효율이 우측보다 떨어집니다.',
        '왼쪽 무릎 관절에 비정상적인 회전 장력이 가해져 스트레칭 중 불편감이 발생합니다.',
      ], methods: [
        '왼쪽 발목을 억지로 당기지 말고 편안한 각도에서 골반 힌지 움직임에만 집중합니다.',
        '스트레칭 로프를 사용하여 왼쪽 다리를 당기되 뒤꿈치 저항을 최소화하며 늘립니다.',
        '가동 범위 확대보다 골반 수평 정렬 유지를 우선하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'heel:RIGHT_HEEL_UNNORMAL': {
      squat: { isNormal: false, items: [
        '하강 시 오른쪽 발목 제한으로 골반이 왼쪽으로 밀리며 우측 하중이 유실됩니다.',
        '오른쪽 뒤꿈치가 일찍 들리며 상체가 좌측으로 회전하는 보상이 나타나 정렬을 비틉니다.',
        '상승 시 왼쪽 지면 반발력이 우세하여 몸이 한쪽으로 기우는 현상이 발생합니다.',
      ], methods: [
        '오른쪽 뒤꿈치 아래 얇은 패드를 깔아 좌우 발목 각도의 비대칭을 물리적으로 해소합니다.',
        '"오른쪽 뒤꿈치를 지면에 더 강하게 누르라"는 큐잉으로 하중 분배를 대칭화합니다.',
        '거울을 통해 골반이 한쪽으로 빠지지 않는지 체크하며 가동 범위 내에서 수행합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 다리가 앞일 때 뒤꿈치가 뜨며 무릎이 안으로 무너지는 불안정성이 나타납니다.',
        '우측 발목 제한이 골반을 왼쪽 위로 밀어올려 하강 시 상체 수직 정렬이 무너집니다.',
        '좌우 수행 시 우측의 지지 능력이 현저히 낮아 운동 품질 편차가 명확히 관찰됩니다.',
      ], methods: [
        '오른쪽 수행 시 보폭을 줄여 발목 부담을 낮추고 뒤꿈치 전체 접지를 강조합니다.',
        '코치가 거울/영상과 구두 큐잉으로 우측 무릎 궤적을 실시간 안내하여 수직 정렬을 인지하도록 가이드합니다.',
        '오른쪽 발목 주변 연부 조직을 충분히 이완한 뒤 훈련을 진행하여 편차를 줄입니다.',
      ] },
      plank: { isNormal: false, items: [
        '오른쪽 발목의 뻣뻣함이 골반 우측을 당겨 코어 대칭 수축 품질을 떨어뜨립니다.',
        '하중이 정상인 왼쪽 발로 전가되면서 코어 근육이 편향되게 수축하는 비효율이 생깁니다.',
        '유지 중 오른쪽 발가락 끝에 과도한 긴장이 쏠려 허리 뒤쪽에 보상 긴장을 유발합니다.',
      ], methods: [
        '오른쪽 발을 왼쪽보다 약간 뒤에 위치시켜 각도 부담을 덜어주고 골반 수평을 맞춥니다.',
        '양쪽 뒤꿈치를 벽에 동일하게 밀착시켜 지면 반발력을 대칭으로 확보합니다.',
        '정렬이 무너지기 전까지만 짧은 세트로 반복하여 보상 패턴 고착을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '오른쪽 발 접지가 약해지며 복부 수축 시 골반 우측이 들썩이는 불안정성이 발생합니다.',
        '하체 지지력 비대칭이 상체 말기 동작의 궤적을 비틀어 복사근의 불균형을 만듭니다.',
        '오른쪽 목 근육이 왼쪽보다 과하게 개입되어 운동 후 우측 목 피로도를 유발할 수 있습니다.',
      ], methods: [
        '오른쪽 발 위치를 조금 더 멀리 두어 우측 뒤꿈치 접지력을 정상인 좌측 수준으로 맞춥니다.',
        '복부 좌우 수축 압력이 균등하게 느껴지는지 실시간 피드백하여 대칭 수축을 유도합니다.',
        '무릎 사이에 볼을 끼워 하체 정렬을 강제 고정한 후 복부 중앙 수축 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '오른쪽 엉덩이 조절 능력이 좌측보다 낮아 클램 수행 시 골반 회전 보상이 심해집니다.',
        '오른쪽 수행 시 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 수축이 나타납니다.',
        '비대칭적인 긴장 분포로 인해 우측 엉덩이 자극 인지력이 현저히 낮아질 수 있습니다.',
      ], methods: [
        '오른쪽 수행 시 코치가 골반이 흔들리지 않도록 가볍게 지지해 아주 작은 범위에서 신경을 깨우는 데 집중합니다.',
        '오른쪽 발목을 최대한 편안한 위치에 두고 엉덩이 순수 수축에만 집중하도록 가이드합니다.',
        '우측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 좌측 수준으로 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른쪽 스트레칭 시 발목 제한으로 인해 햄스트링보다 종아리 뒤쪽이 먼저 긴장됩니다.',
        '우측 골반 전방경사 성향으로 인해 순수 이완보다 허리 보상이 먼저 일어납니다.',
        '오른쪽 무릎 관절에 비정상적인 회전 장력이 가해져 스트레칭 품질이 저하됩니다.',
      ], methods: [
        '오른쪽 발목을 억지로 당기지 말고 발바닥을 벽에 대는 방식을 통해 편안하게 이완합니다.',
        '스트레칭 로프를 사용하여 오른쪽 다리를 당기되 뒤꿈치 저항을 최소화하며 늘립니다.',
        '가동 범위 확대보다 골반 수평 정렬 유지를 최우선으로 하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    // ── 발목 내·외측 기울기 (ankles) ───────────────────────────
    'ankles:NORMAL': {
      squat: { isNormal: true, items: [
        '발목의 내·외측 기울기 없이 수직 중립 상태가 우수하여 하강 시 하중을 발바닥 전체로 균등하게 분산시킵니다.',
        '발목 관절의 중립 안정성 덕분에 무릎과 골반의 정렬이 흐트러지지 않고 안정적인 수직 궤적을 유지합니다.',
        '동작 전체 구간에서 발목의 흔들림이 제어되어 하체 사슬의 역학적 효율이 매우 높게 나타납니다.',
      ], methods: [
        '지면이 불안정한 도구(밸런스 패드 등) 위에서 하강할 때 발목의 수직 중립이 무너지지 않는지 챌린지합니다.',
        '하강 시 발뒤꿈치를 가볍게 든 상태(Elevated Heel)에서도 발목이 안팎으로 꺾이지 않도록 중립 유지력을 시험합니다.',
        '폭발적인 점프 후 착지하는 순간 발목이 즉각적으로 수직 정렬을 회복하는 반응성 안정화 훈련을 실시합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '앞발의 발목 정렬이 중립을 유지하여 체중이 한쪽으로 쏠리지 않고 관절 정중앙으로 안정적으로 전달됩니다.',
        '발목의 측면 흔들림이 없어 하강 및 상승 시 무릎의 정면 궤적을 유지하기에 매우 유리한 조건입니다.',
        '양측 런지 수행 시 발목 안정성의 대칭성이 우수하여 전신 균형 감각이 뛰어난 패턴이 관찰됩니다.',
      ], methods: [
        '런지 자세에서 뒷발을 짐볼이나 슬라이더에 올리고 수행하여, 흔들리는 지면 위에서도 앞쪽 발목의 중립을 사수합니다.',
        '한 손에만 무게를 든 오프셋 로딩(Offset Loading) 상태에서 몸이 기울어지려 할 때 발목 정렬을 지켜내는 능력을 챌린지합니다.',
        '눈을 감고 런지를 수행하여 시각적 도움 없이 발목 주위 근육의 고유수용감각만으로 중립을 유지하도록 유도합니다.',
      ] },
      plank: { isNormal: true, items: [
        '양발의 뒤꿈치가 수직으로 곧게 세워져 발목의 내·외측 치우침 없이 하체 후면의 긴장도가 대칭적으로 형성됩니다.',
        '발목의 중립 정렬을 통해 지면을 밀어내는 힘이 종아리와 허벅지, 코어까지 손실 없이 전달됩니다.',
        '유지 시간이 길어져도 발목이 옆으로 눕거나 꺾이지 않고 견고한 지지대 역할을 수행합니다.',
      ], methods: [
        '발가락 끝으로 지면을 앞뒤로 미는 \'소우(Saw)\' 동작 중에도 발목이 좌우로 흔들리지 않고 수직 궤도를 유지하도록 챌린지합니다.',
        '한 다리를 들고 플랭크를 수행하며 지지하는 발목의 측면 안정성을 극한으로 끌어올리는 훈련을 적용합니다.',
        '발아래에 작은 볼을 두고 수행하여 불안정한 접지면 위에서 발목 중립을 유지하는 능력을 시험합니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '발목이 중립 정렬을 유지하며 지면을 고르게 지지하여 상체 굴곡 시 하체의 불필요한 보상 패턴을 차단합니다.',
        '발목 정렬의 안정성을 바탕으로 골반과 무릎의 위치가 고정되어 복부 수축에만 집중할 수 있는 환경이 조성됩니다.',
        '반복적인 수축에도 발목의 각도가 변하지 않고 일관된 지지력을 제공하는 우수한 제어 능력이 확인됩니다.',
      ], methods: [
        '발목 사이에 가벼운 도구를 끼워 발목 중립(Inversion/Eversion 방지)을 고정한 채로 복부의 대칭적 수축 강도를 높입니다.',
        '상체를 들어 올린 상태에서 다리를 교차하는 동작을 추가하여, 하체의 움직임 속에서도 발목 정렬을 통제하는 능력을 챌린지합니다.',
      ] },
      clam: { isNormal: true, items: [
        '준비 자세에서 양발의 날이 정확하게 맞물려 발목의 꺾임 없이 고관절 외회전의 정렬 기준점이 명확합니다.',
        '동작 수행 시 발목 관절의 각도가 중립으로 일정하게 유지되어 타깃 근육인 둔근에 자극이 명확히 고립됩니다.',
        '발목의 우수한 정적 정렬이 고관절의 회전 가동 범위를 확보하기 위한 안정적인 기초 지지대 역할을 수행합니다.',
      ], methods: [
        '양발을 지면에서 띄운 채 허공에서 발목 중립을 유지하며 클램을 수행하여, 하체의 고유수용감각과 제어 능력을 극한으로 챌린지합니다.',
        '최대 범위에서 멈춘 뒤 저항 밴드의 탄성을 이겨내며 발목 정렬이 무너지지 않는 범위 내에서의 등척성 수축을 유도합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '발목이 내·외측으로 돌아가는 보상 작용 없이 중립을 유지하여 햄스트링 조직 전체를 균등하게 이완시킵니다.',
        '발목의 우수한 정렬 덕분에 허벅지 뒷면 근육에만 이완 자극을 정확하고 깊게 전달할 수 있는 상태입니다.',
        '양발의 대칭적 정렬을 통해 하체 후면 사슬의 유연성 지표를 정교하게 파악하고 증진시키기에 이상적입니다.',
      ], methods: [
        '발목의 중립을 엄격히 유지한 상태에서 발등을 몸쪽으로 당겨(Dorsiflexion), 신경 가동성과 근육 이완을 동시에 챌린지합니다.',
        '능동적으로 다리를 들어 올리는 동작 시 본인의 근력으로 발목 정렬을 통제하며 유연성을 확보하도록 유도합니다.',
      ] },
    },
    'ankles:ANKLE_OUTWARD': {
      squat: { isNormal: false, items: [
        '체중이 발 바깥날로 쏠려 엄지발가락의 지면 지지력이 소실되고 균형이 불안정해집니다.',
        '발목 외측 긴장이 정강뼈 가쪽돌림을 유도하여 무릎이 밖으로 벌어지는 보상이 나타납니다.',
        '지면 반발력이 분산되어 상승 시 폭발적인 힘을 쓰기 어렵고 골반 안정성이 떨어집니다.',
      ], methods: [
        '"엄지발가락 아래 발볼을 지면에 꾹 누르라"는 큐잉으로 중심을 안쪽으로 이동시킵니다.',
        '내전근 활성화 훈련을 병행하여 외측으로 벌어지려는 하체 사슬을 중앙으로 모읍니다.',
        '하강 시 발바닥 안쪽 면이 지면에서 뜨지 않는 범위 내에서만 깊이를 조절합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발의 외측 쏠림으로 무릎이 밖으로 흔들리며 엉덩이 근육 수축이 제한됩니다.',
        '발목 바깥쪽 주변 조직에 부담이 커져 반복 수행 시 피로가 빠르게 누적될 수 있습니다.',
        '뒤꿈치 전체 접지가 불완전하여 하강 속도를 제어하는 조절 능력이 저하됩니다.',
      ], methods: [
        '앞발 엄지발볼 접지를 강조하여 무릎 궤적이 발등 정중앙을 지나도록 교정합니다.',
        '뒤꿈치 안쪽 면을 지면에 밀착시키는 훈련으로 수직 지지력을 확보합니다.',
        '보폭을 좁게 설정하여 발목 정렬을 스스로 통제할 수 있는 환경을 만듭니다.',
      ] },
      plank: { isNormal: false, items: [
        '발이 안으로 꺾이며 외측 근육만 긴장하여 코어 중앙으로 힘이 모이지 않습니다.',
        '지면 지지점이 발가락 외측에 집중되어 전신 장력 분포가 불균형해집니다.',
        '발목 불안정성으로 골반이 위로 들리거나 허리 뒤쪽에 보상적 과긴장이 나타납니다.',
      ], methods: [
        '양발을 정면으로 고정하고 엄지발가락 쪽 압력을 높여 하체 장력 균형을 맞춥니다.',
        '발뒤꿈치를 뒤로 강하게 밀어내는 힘을 유지하여 하체와 코어의 연결성을 확보합니다.',
        '정렬이 무너지기 전까지만 짧은 세트로 수행하여 보상 패턴 고착을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체 외측의 과긴장이 골반 중립을 방해하여 복부 수축 깊이를 물리적으로 제한합니다.',
        '발 지지가 바깥으로 쏠려 복부 수축 시 골반 고정력이 약해져 목과 어깨의 개입을 만듭니다.',
        '하체 힘을 제어하지 못해 복부 운동 중에도 종아리 외측이 과하게 긴장됩니다.',
      ], methods: [
        '발 위치를 정면으로 교정하고 발바닥 안쪽 면을 바닥에 견고히 밀착시킵니다.',
        '무릎 사이에 볼을 끼워 내측 사슬을 활성화하면 골반 정렬이 안정되어 복부 자극이 높아집니다.',
        '횟수보다 상체가 올라올 때 양발의 접지압이 동일하게 유지되는지 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '이미 가쪽돌림근이 우세한 정렬이라 중둔근보다 겉 근육이 과하게 개입됩니다.',
        '발목 안쪽번짐 긴장이 고관절의 순수한 벌림 범위를 방해하여 골반 보상을 유도합니다.',
        '벌어진 형태의 정렬에서 시작하게 되어 필요한 유효 수축 범위가 짧아집니다.',
      ], methods: [
        '발목을 중립으로 고정한 상태에서 아주 작은 범위부터 엉덩이 자극을 찾는 데 집중합니다.',
        '속도를 늦추어 조절 능력을 강화하고 외측 사슬의 과도한 긴장을 이완하며 수행합니다.',
        '트레이너가 벽·소도구·자세 세팅을 활용해 골반이 흔들리지 않는 환경을 만들고, 정확한 고립 수축을 유도합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발이 안으로 꺾인 상태에서 늘리면 외측 햄스트링만 과하게 당겨져 효율이 저하됩니다.',
        '햄스트링보다 발목 외측이나 종아리 바깥쪽의 팽팽함이 먼저 느껴져 이완을 방해합니다.',
        '골반이 가쪽돌림된 채 고정되기 쉬워 햄스트링 시작점을 분리하여 늘리는 데 한계가 있습니다.',
      ], methods: [
        '발등이 천장을 향하도록 수직 정렬을 철저히 유지하여 내측 섬유까지 고르게 늘립니다.',
        '엄지발가락 쪽을 몸쪽으로 당기는 힘을 유지하여 종아리 외측 개입을 줄입니다.',
        '가동 범위 확대보다 골반 수평 정렬 유지를 우선하여 안전한 스트레칭을 실시합니다.',
      ] },
    },
    'ankles:ANKLE_INWARD': {
      squat: { isNormal: false, items: [
        '발바닥 아치의 지지력 저하로 인해 하강 동작 시 무릎이 안으로 향하는 안쪽굽힘 패턴이 나타나며 관절 정렬의 안정성이 저하될 수 있습니다.',
        '지면을 밀어내는 힘이 안쪽으로 새어나가 엉덩이 근육의 힘 전달을 줄이는 데 도움이 될 수 있습니다.',
        '하단 구간에서 발목 안정성이 소실되어 골반이 앞으로 기우는 보상이 나타납니다.',
      ], methods: [
        '발가락으로 지면을 움켜쥐는 인지 훈련을 통해 발의 내측 아치를 살립니다.',
        '무릎 바깥쪽에 밴드를 착용하여 엉덩이 근육이 발목 무너짐을 상쇄하도록 유도합니다.',
        '뒤꿈치와 발 바깥날의 접지력을 강조하여 체중을 하체 전체로 고르게 분산시킵니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발 아치의 지지력이 약해지며 무릎이 안으로 정렬을 이탈하게 되고, 이로 인해 관절 내측으로 하중이 편중되어 전달되는 현상이 나타납니다.',
        '발목 가쪽번짐 정렬이 정강뼈 안쪽돌림을 유도하여 엉덩이 안정성이 급격히 떨어집니다.',
        '좌우 수행 시 발목 안정성 차이로 인해 중심 잡기가 어렵고 수행 품질 편차가 큽니다.',
      ], methods: [
        '앞발 아치를 세운 상태를 유지하고 무릎이 발등 라인 밖으로 나가지 않게 통제합니다.',
        '뒤꿈치 접지를 강화하여 발목에 쏠린 하중을 엉덩이 근육으로 이동시킵니다.',
        '트레이너가 거울/영상 피드백과 큐잉으로 발목 정렬을 안내하고, 필요 시 통증 없는 가벼운 터치 피드백으로 위치 인지를 돕습니다.',
      ] },
      plank: { isNormal: false, items: [
        '발이 바깥으로 꺾이며 하체 안쪽 사슬 과긴장을 유발해 골반이 아래로 처지기 쉽습니다.',
        '엄지발가락 쪽에만 과도한 하중이 쏠려 코어 근육과 하체의 연결성이 느슨해집니다.',
        '유지 시간이 길어질수록 발목 피로도가 코어보다 먼저 쌓여 정렬이 쉽게 무너집니다.',
      ], methods: [
        '발바닥 바깥날에 의도적인 힘을 주어 발목 가쪽번짐을 억제하고 양발 압력을 맞춥니다.',
        '뒤꿈치를 뒤로 밀어내는 힘을 통해 하부 사슬 텐션을 확보하고 골반 수평을 체크합니다.',
        '짧은 시간 반복하더라도 아치가 무너지기 전까지만 수행하여 보상 패턴을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체 안쪽 과긴장이 골반 전방경사를 유도하여 복부 수축 가동 범위를 제한합니다.',
        '발 위치의 흔들림으로 인해 복부 수축 시 골반의 고정력이 약해지며, 이로 인해 허리 주변부의 부하가 가중되어 움직임의 안정성이 저하될 수 있습니다.',
        '상체를 들어 올릴 때 무릎이 서로 붙으려 하며 복부 중앙 집중력을 떨어뜨립니다.',
      ], methods: [
        '발 위치를 정면으로 정렬하고 하체 안쪽의 과도한 힘을 뺀 상태에서 실시합니다.',
        '무릎 사이에 볼을 끼워 골반 정렬을 안정시킨 채 복부 말기에 집중합니다.',
        '횟수보다 상체가 올라올 때 발바닥 전체의 접지압이 일정한지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '발목이 안으로 무너진 상태라 엉덩이 안정근 활성도가 낮고 골반 보상이 심해집니다.',
        '무릎을 벌리는 힘이 부족하여 엉덩이 대신 허리 근육을 끌어다 쓰는 패턴이 나타납니다.',
        '고관절 순수 가쪽돌림 범위가 좁아져 있어 동작 시 골반이 뒤로 밀리기 쉽습니다.',
      ], methods: [
        '골반을 직접 고정하고 아주 작은 범위에서 엉덩이 깊은 곳의 신경을 깨우는 데 집중합니다.',
        '속도를 늦추어 조절 능력을 강화하고 발목 정렬이 엉덩이 수축에 미치는 영향을 인지시킵니다.',
        '양쪽 수행 시 감각 차이를 확인하여 약한 쪽 엉덩이 근육에 더 많은 시간을 투자합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발이 바깥으로 꺾인 상태에서 늘리면 내측 햄스트링만 과하게 당겨져 효율이 저하됩니다.',
        '무릎 관절 내측으로 하중이 편중되어 전달되면서, 스트레칭 중 정렬 유지가 어려워지거나 해당 부위의 긴장도가 높아질 수 있습니다.',
        '골반이 앞으로 기울어진 채 고정되어 햄스트링 시작점을 분리하여 늘리는 데 한계가 있습니다.',
      ], methods: [
        '무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별로 이완합니다.',
        '발바닥 아치를 살린 상태에서 스트레칭하여 무릎 내측 부하를 제거하고 타깃 근육만 늘립니다.',
        '범위보다 척추와 골반의 중립 정렬 유지를 우선하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'ankles:ANKLE_RIGHT': {
      squat: { isNormal: false, items: [
        '하강 시 체중이 왼쪽으로 치우치며 우측은 바깥날, 좌측은 안쪽으로 하중이 쏠립니다.',
        '양발의 상반된 접지력으로 인해 골반 수평이 깨지고 척추에 비대칭적 부하가 전달됩니다.',
        '상승 시 상체가 왼쪽으로 회전하려는 보상이 나타나 하중 분배 불균형이 심화됩니다.',
      ], methods: [
        '오른쪽은 엄지발볼을, 왼쪽은 발 바깥날 압력을 강조하여 양발의 중심선을 정렬합니다.',
        '정렬이 깨지기 전까지만 하강하며 양발 하중이 균등한지 실시간 피드백을 줍니다.',
        '상체가 기우는지 거울로 점검하며 골반의 수평 이동 궤적을 정교하게 다듬습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 발이 앞일 때 발목 외측 쏠림으로 흔들리고, 왼쪽이 앞일 때 아치가 무너집니다.',
        '좌우 정렬 차이로 인해 앞발의 접지 안정성 편차가 심해 조절 능력이 저하됩니다.',
        '비대칭적인 발목 정렬이 무릎 관절의 회전 부하를 유발하여 피로를 가속화합니다.',
      ], methods: [
        '각 발의 정렬 상태에 맞춰 오른쪽은 안쪽 지지를, 왼쪽은 아치 세우기를 개별 큐잉합니다.',
        '보폭을 조절하여 발목 정렬을 제어할 수 있는 가동 범위 내에서만 하강을 진행합니다.',
        '트레이너가 시각 피드백과 큐잉으로 무릎 궤적을 정렬하도록 돕고, 동작 중 스스로 유지할 수 있게 반복 학습을 설계합니다.',
      ] },
      plank: { isNormal: false, items: [
        '하중이 오른쪽은 외측, 왼쪽은 내측으로 쏠려 골반이 시계 반대 방향으로 회전하려 합니다.',
        '발목의 비대칭이 하체 사슬의 장력 균형을 깨뜨려 코어 수축 품질을 떨어뜨립니다.',
        '유지 중 왼쪽 발목의 피로도가 더 빠르게 상승하여 골반 수평 유지가 어려워집니다.',
      ], methods: [
        '오른쪽 발은 안쪽을, 왼쪽 발은 바깥쪽을 누르는 의도적 힘으로 대칭을 유도합니다.',
        '골반 좌우 높이가 지면과 평행한지 정밀 점검하여 비틀림을 수정합니다.',
        '짧은 시간 반복하더라도 골반 회전이 일어나기 전까지만 세트를 수행합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체 접지 비대칭이 골반 비틀림을 유발하여 복부 수축 시 상체가 한쪽으로 기웁니다.',
        '왼쪽 발 지지가 약해지며 왼쪽 골반이 전방으로 기울어져 복부 자극이 분산됩니다.',
        '하체 고정력이 좌우가 달라 척추가 바닥에 닿는 순서가 어긋날 수 있습니다.',
      ], methods: [
        '양발의 접지압이 동일해지도록 발 위치를 미세 조정하고 상체를 말아 올립니다.',
        '복부 좌우 수축 강도를 손으로 직접 확인하여 비대칭 사용을 즉각 수정합니다.',
        '무릎 사이에 볼을 끼워 양발이 정면을 바라보도록 강제 정렬한 뒤 실시합니다.',
      ] },
      clam: { isNormal: false, items: [
        '오른쪽 수행 시 고립이 어렵고, 왼쪽 수행 시 골반 흔들림 제어가 어렵습니다.',
        '좌우 발목 정렬 차이로 인해 엉덩이 근육의 시작점 장력이 다르게 형성됩니다.',
        '비대칭적인 고관절 회전 범위로 인해 한쪽 허리에만 과도한 보상이 발생합니다.',
      ], methods: [
        '오른쪽은 조절력 향상에, 왼쪽은 중립 유지 강화에 초점을 맞춰 처방합니다.',
        '골반 수직 축이 흐트러지지 않도록 벽이나 소도구를 활용해 환경을 세팅합니다.',
        '좌우 수행 후 자극 편차를 기록하여 약한 쪽의 신경근 인지 훈련을 추가합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른쪽은 외측 섬유 위주로, 왼쪽은 내측 섬유 위주로 스트레칭이 편향됩니다.',
        '골반의 비대칭 정렬이 척추의 측면 굽힘을 유도해 허리 불편감을 유발합니다.',
        '좌우 발목 방향 차이로 인해 스트레칭 시 관절의 뒤틀림 장력이 발생합니다.',
      ], methods: [
        '각 발목을 정중앙으로 강제 정렬한 상태를 유지하며 단계별로 이완합니다.',
        '골반 수평 상태를 최우선으로 확보하고 햄스트링 기시점이 평행한지 확인합니다.',
        '스트레칭 후 가동 범위를 측정하여 비대칭이 개선되었는지 재평가합니다.',
      ] },
    },
    'ankles:ANKLE_LEFT': {
      squat: { isNormal: false, items: [
        '하강 시 골반이 오른쪽으로 밀리며 우측 아치는 무너지고 좌측 발목은 바깥으로 꺾입니다.',
        '지면 지지력이 우측은 안쪽, 좌측은 바깥쪽으로 새어 나가 하체 조절력이 저하됩니다.',
        '상승 시 골반이 시계 방향으로 회전하려는 보상이 나타나 척추 부하를 높입니다.',
      ], methods: [
        '오른쪽은 발 바깥날을, 왼쪽은 엄지발가락 쪽을 누르도록 유도해 중앙을 맞춥니다.',
        '무릎 사이에 볼이나 밴드를 활용해 양쪽 다리의 상반된 보상을 물리적으로 차단합니다.',
        '상체의 수직 이동 경로가 정중앙을 유지하는지 전문가가 실시간 모니터링합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 발이 앞일 때 외측 쏠림으로 무릎이 흔들리고, 오른쪽이 앞일 때 아치가 무너집니다.',
        '앞발의 접지 특성이 좌우가 정반대라 신경계의 평형 조절 능력이 한계를 보입니다.',
        '비대칭 정렬이 하중 지지 능력을 저하시켜 엉덩이 활성도가 불균형하게 형성됩니다.',
      ], methods: [
        '각 다리 패턴에 맞춰 우측은 아치 유지를, 좌측은 엄지발볼 접지를 개별 큐잉합니다.',
        '트레이너가 템포 조절, 보폭 설정, 거울 피드백으로 무릎 궤적이 흔들리지 않도록 코칭합니다.',
        '수행 템포를 늦추어 발바닥 전체 압력이 균등하게 유지되는지 스스로 인지하게 합니다.',
      ] },
      plank: { isNormal: false, items: [
        '하중이 오른쪽은 내측, 왼쪽은 외측으로 쏠려 골반이 시계 방향으로 회전하려 합니다.',
        '발목 비대칭이 하체 사슬 장력을 깨뜨려 유지 중 골반 수평이 쉽게 무너집니다.',
        '오른쪽 발목 피로도가 더 빠르게 쌓여 코어 유지 시간보다 정렬 이탈이 먼저 발생합니다.',
      ], methods: [
        '오른쪽 발은 바깥쪽을, 왼쪽 발은 안쪽을 누르는 의도적 힘으로 대칭을 맞춥니다.',
        '골반 좌우 높이가 평행한지 정밀 점검하고 처진 쪽을 들어 올리도록 큐잉합니다.',
        '짧은 시간 반복하더라도 골반 비틀림이 나타나기 전까지만 세트를 수행합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체 접지 비대칭으로 복부 수축 시 골반이 회전하며 복사근 사용 불균형을 만듭니다.',
        '오른쪽 발 지지가 약해지며 오른쪽 골반이 전방으로 기울어 허리 부담이 늘어납니다.',
        '발목 방향 차이로 인해 양쪽 다리의 긴장도가 달라 코어 집중력이 떨어집니다.',
      ], methods: [
        '양발의 접지압이 동일해지도록 발 위치를 조정하고 복부 중앙 수축에 집중합니다.',
        '복부 좌우 수축 강도를 전문가가 확인하여 비대칭적인 힘 사용을 즉각 수정합니다.',
        '무릎 사이에 볼을 끼워 하체 정렬을 강제 고정한 후 컬업 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '오른쪽 수행 시 골반 흔들림이, 왼쪽 수행 시 고립 부족이 나타날 수 있습니다.',
        '좌우 발목 정렬 차이가 고관절 회전 축의 비대칭을 만들어 운동 범위를 제한합니다.',
        '비대칭적인 긴장 분포로 인해 한쪽 엉덩이 자극 인지력이 현저히 낮아질 수 있습니다.',
      ], methods: [
        '오른쪽은 중립 유지에, 왼쪽은 조절력 향상에 초점을 맞춰 운동 처방을 세분화합니다.',
        '골반 수직 축 유지를 위해 벽이나 트레이너의 보조를 활용합니다.',
        '좌우 수행 후 감각 차이를 체크하여 부족한 쪽의 신경근 활성화 시간을 늘립니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른쪽은 내측 섬유가, 왼쪽은 외측 섬유가 편향되게 스트레칭되어 밸런스가 깨집니다.',
        '골반 비대칭 정렬이 척추의 뒤틀림을 유발하여 스트레칭 중 골반 통증이 생길 수 있습니다.',
        '좌우 발목 방향 차이가 무릎 관절의 회전 장력을 유발해 이완을 방해합니다.',
      ], methods: [
        '각 발목을 정중앙 정렬로 고정한 상태를 유지하며 단계별 이완을 진행합니다.',
        '골반 수평 상태와 햄스트링 기시점의 평행 여부를 최우선으로 확보합니다.',
        '스트레칭 후 가동 범위를 비교 측정하여 좌우 비대칭 개선 여부를 재평가합니다.',
      ] },
    },
    'ankles:RIGHT_ANKLE_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 체중이 정상인 왼쪽으로 쏠리며 오른쪽 발목은 바깥으로 꺾이는 보상이 나타납니다.',
        '우측 발목의 외측 쏠림으로 우측 엉덩이 안정근의 활성도가 좌측보다 낮아집니다.',
        '상승 시 몸이 왼쪽으로 기우는 현상이 발생하여 척추의 수직 정렬을 방해합니다.',
      ], methods: [
        '오른쪽 엄지발가락 지지력을 강화하여 무게 중심을 중앙으로 이동시킵니다.',
        '오른쪽 엉덩이 근육에 더 강한 수축 신호를 주어 좌우 균형을 맞추도록 지도합니다.',
        '정렬이 무너지기 전까지만 하강하며 좌측과 대칭을 이루는지 실시간 체크합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 발이 앞일 때 발목 외측 흔들림으로 인해 무릎 안정성이 급격히 저하됩니다.',
        '우측 뒤꿈치 접지가 불안정하여 런지 하강 시 상체가 앞으로 쏠리는 보상이 나타납니다.',
        '좌우 수행 시 우측의 조절 능력이 낮아 운동 품질의 심한 편차가 관찰됩니다.',
      ], methods: [
        '오른쪽 수행 시 보폭을 좁혀 발목 조절력을 높이고 뒤꿈치 접지를 강조합니다.',
        '트레이너가 거울/영상 피드백과 큐잉으로 우측 무릎 궤적이 수직 정렬을 유지하도록 돕습니다.',
        '정상인 왼쪽의 수행 감각을 오른쪽에서도 동일하게 구현하도록 반복 학습합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 발목 안쪽번짐이 골반 우측 전방경사를 유도해 코어 하부 비대칭을 만듭니다.',
        '체중이 정상인 왼쪽 발로 은근히 전가되어 코어 근육이 편향되게 수축합니다.',
        '유지 중 우측 하체 외측 사슬 긴장도가 높아 골반 수평 유지력이 저하됩니다.',
      ], methods: [
        '우측 엄지발가락 압력을 높여 하체 안팎 장력 균형을 맞추고 5:5 하중을 유도합니다.',
        '골반 우측이 아래로 처지지 않는지 실시간 피드백하여 대칭 수축 품질을 유지합니다.',
        '정렬이 완벽한 상태에서만 수행하도록 짧은 세트 위주로 구성해 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체 외측 긴장이 복부 수축 시 골반 우측 회전을 유도해 좌우 편차를 만듭니다.',
        '오른쪽 발 지지 불안정으로 컬업 시 골반 고정력이 약해져 우측 목 근육이 과사용됩니다.',
        '하체 지지력 비대칭이 상체 말기 궤적을 비틀어 복사근의 불균형을 유발합니다.',
      ], methods: [
        '우측 발바닥 접지력을 수시로 확인하고 골반 수평 상태에서만 상체를 말아 올립니다.',
        '무릎 사이에 공을 끼워 우측 하체 정렬을 고정하고 복부 정방향 수축을 유도합니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 떨어지는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 근육 활성도가 정상인 좌측보다 낮아 골반 회전 보상이 더 심합니다.',
        '우측 수행 시 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 수축이 나타납니다.',
        '좌우 수축 감각 차이로 인해 우측의 정확한 자극 지점 인지가 어려울 수 있습니다.',
      ], methods: [
        '우측 수행 시 소도구(벽/볼 등)로 골반이 흔들리지 않게 세팅하고 작은 범위부터 자극을 찾습니다.',
        '속도를 절반 이하로 낮춰 뇌가 우측 엉덩이 수축을 정밀 제어하도록 가이드합니다.',
        '우측 수행 횟수를 늘려 양측 엉덩이의 신경근 밸런스를 좌측 수준으로 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 스트레칭 시 외측 섬유만 과하게 당겨져 정상인 좌측과 이완 품질이 달라집니다.',
        '오른쪽 골반 전방경사 성향으로 인해 순수 이완보다 허리 보상이 먼저 일어납니다.',
        '우측 발목 방향 차이가 무릎 관절에 비정상적인 회전 장력을 유발합니다.',
      ], methods: [
        '우측 발목을 정면 수직으로 고정한 상태를 유지하며 단계별 이완을 진행합니다.',
        '우측 골반 수평 상태를 최우선 확보하고 허리가 말리지 않는 범위에서 실시합니다.',
        '스트레칭 전후 가동 범위를 비교하여 우측 개선 효과를 직접 확인하도록 유도합니다.',
      ] },
    },
    'ankles:RIGHT_ANKLE_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 우측 아치가 무너지며 몸이 오른쪽으로 쏠리고 좌측 하중이 감소합니다.',
        '우측 발목 가쪽번짐이 우측 무릎 안쪽굽힘을 유도해 관절 내측 부하를 높입니다.',
        '상승 시 우측 지면 반발력이 약해져 골반이 한쪽으로 뒤틀리는 보상이 발생합니다.',
      ], methods: [
        '우측 발바닥 아치를 살리는 인지 훈련과 함께 뒤꿈치 접지력을 강조합니다.',
        '무릎 바깥쪽에 밴드를 착용해 우측 엉덩이 근육이 발목 무너짐을 상쇄하게 합니다.',
        '정상인 좌측 정렬을 기준으로 우측이 대칭을 이루는지 실시간 모니터링합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 발이 앞일 때 아치가 무너지며 무릎 흔들림이 심해 안정성이 결여됩니다.',
        '우측 발목 가쪽번짐이 정강뼈 안쪽돌림을 유도해 우측 엉덩이 활성도를 낮춥니다.',
        '좌우 수행 시 우측의 아치 서포트 능력이 낮아 운동 품질 편차가 명확히 보입니다.',
      ], methods: [
        '우측 앞발 아치를 세운 상태를 유지하고 무릎 궤적을 발등 중앙에 고정합니다.',
        '우측 뒤꿈치 접지를 강화해 발목 하중을 엉덩이 근육으로 이동시키는 큐잉을 줍니다.',
        '트레이너가 거울/영상 피드백과 큐잉으로 우측 발목 정렬과 지지 감각을 안내합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 발 가쪽번짐이 골반 하부 비대칭을 유도해 코어와 하체 연결성을 약화시킵니다.',
        '체중이 엄지발가락 쪽에 쏠려 우측 하체 안쪽 사슬만 과하게 긴장됩니다.',
        '유지 중 우측 발목 피로도가 먼저 쌓여 골반 수평 정렬이 쉽게 무너집니다.',
      ], methods: [
        '우측 발바닥 바깥날에 힘을 주어 가쪽번짐을 억제하고 양발 압력을 맞춥니다.',
        '뒤꿈치를 뒤로 밀어내는 힘으로 하부 사슬 텐션을 확보하고 골반 수평을 체크합니다.',
        '우측 정렬이 무너지기 전까지만 수행하도록 짧은 세트 위주로 구성해 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체 안쪽 과긴장이 골반 전방경사를 유도해 우측 복부 수축 범위를 제한합니다.',
        '우측 발 지지 불안정으로 복부 수축 시 골반 고정력이 약해져 허리 통증을 유발합니다.',
        '상체를 들어 올릴 때 우측 무릎이 안으로 모이며 복부 중앙 집중력을 떨어뜨립니다.',
      ], methods: [
        '우측 발 위치를 정면 정렬하고 하체 안쪽의 불필요한 힘을 뺀 상태에서 실시합니다.',
        '무릎 사이에 볼을 끼워 골반 정렬을 안정시킨 채 우측 복부 수축을 유도합니다.',
        '횟수보다 우측 발바닥 전체 접지압이 일정하게 유지되는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 안정근 활성도가 낮아 동작 시 골반 뒤로 넘어가는 보상이 심합니다.',
        '우측 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 수축이 우측에서만 나타납니다.',
        '우측 고관절 순수 외회전 범위가 좁아져 있어 자극 인지력이 현저히 낮아질 수 있습니다.',
      ], methods: [
        '우측은 소도구로 골반 흔들림을 줄인 상태에서 아주 작은 범위부터 엉덩이 자극을 찾습니다.',
        '속도를 늦춰 우측 발목 정렬이 엉덩이 수축에 미치는 영향을 인지하도록 돕습니다.',
        '우측 수행 횟수나 집중도를 높여 좌측 정상 수준으로 신경근 밸런스를 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 발 가쪽번짐으로 인해 내측 햄스트링만 편향되게 자극되어 밸런스가 깨집니다.',
        '우측 무릎 내측으로 하중이 편중되어 전달되면서, 스트레칭 시 정렬 유지가 어려워지거나 해당 부위의 긴장도가 상승할 수 있습니다.',
        '우측 골반 전방경사 고정으로 햄스트링 시작점 분리 이완에 한계가 생깁니다.',
      ], methods: [
        '우측 무릎과 발등이 정면 수직을 유지하도록 통제한 상태에서 단계별로 이완합니다.',
        '우측 발 아치를 살린 상태에서 실시해 무릎 내측 부하를 제거하고 타깃에 집중합니다.',
        '좌우 가동 범위를 측정해 우측 개선 효과를 회원이 직접 확인하도록 유도합니다.',
      ] },
    },
    'ankles:LEFT_ANKLE_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 체중이 정상인 오른쪽으로 쏠리며 왼쪽 발목은 외측으로 꺾이는 보상이 나타납니다.',
        '좌측 발목 안쪽번짐이 좌측 엉덩이 안정근 활성도를 낮춰 조절 능력이 저하됩니다.',
        '상승 시 몸이 우측으로 기우는 현상이 발생하여 척추의 수직 정렬을 방해합니다.',
      ], methods: [
        '왼쪽 엄지발가락 지지력을 강화하여 무게 중심을 발바닥 중앙으로 이동시킵니다.',
        '왼쪽 엉덩이 근육에 더 강한 수축 신호를 주어 대칭을 유지하도록 지도합니다.',
        '정렬이 무너지기 전까지만 하강하며 우측과 대칭을 이루는지 실시간 체크합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 발이 앞일 때 발목 외측 흔들림으로 인해 무릎 안정성이 급격히 저하됩니다.',
        '좌측 뒤꿈치 접지가 불안정해 하강 시 상체가 앞으로 쏠리는 보상이 나타납니다.',
        '좌우 수행 시 좌측 조절 능력이 낮아 운동 품질의 편차가 명확히 관찰됩니다.',
      ], methods: [
        '왼쪽 수행 시 보폭을 좁혀 발목 조절력을 높이고 뒤꿈치 접지를 강조합니다.',
        '트레이너가 거울/영상 피드백과 큐잉으로 좌측 무릎 궤적이 수직 정렬을 유지하도록 돕습니다.',
        '정상인 우측의 수행 감각을 왼쪽에서도 동일하게 구현하도록 반복 학습합니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 발목 안쪽번짐이 골반 좌측 전방경사를 유도해 코어 하부 비대칭을 만듭니다.',
        '체중이 정상인 오른쪽 발로 전가되어 코어 근육이 편향되게 수축합니다.',
        '유지 중 좌측 하체 외측 사슬 긴장도가 높아 골반 수평 유지력이 저하됩니다.',
      ], methods: [
        '좌측 엄지발가락 압력을 높여 하체 안팎 장력 균형을 맞추고 5:5 하중을 유도합니다.',
        '골반 좌측이 아래로 처지지 않는지 실시간 피드백하여 대칭 수축 품질을 유지합니다.',
        '정렬이 완벽한 상태에서만 수행하도록 짧은 세트 위주로 구성해 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체 외측 긴장이 복부 수축 시 골반 좌측 회전을 유도해 좌우 편차를 만듭니다.',
        '왼쪽 발 지지 불안정으로 컬업 시 골반 고정력이 약해져 좌측 목 근육이 과사용됩니다.',
        '하체 지지력 비대칭이 상체 말기 궤적을 비틀어 복사근의 불균형을 유발합니다.',
      ], methods: [
        '좌측 발바닥 접지력을 확인하고 골반 수평 상태에서만 상체를 말아 올립니다.',
        '무릎 사이에 공을 끼워 좌측 하체 정렬을 고정하고 복부 정방향 수축을 유도합니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 떨어지는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 근육 활성도가 정상인 우측보다 낮아 골반 회전 보상이 심해집니다.',
        '좌측 수행 시 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 수축이 나타납니다.',
        '좌우 수축 감각 차이로 인해 좌측의 정확한 자극 지점 인지가 어려울 수 있습니다.',
      ], methods: [
        '좌측 수행 시 소도구로 골반이 흔들리지 않게 세팅하고 작은 범위부터 자극을 찾습니다.',
        '속도를 절반 이하로 낮춰 뇌가 좌측 엉덩이 수축을 정밀 제어하도록 가이드합니다.',
        '좌측 수행 횟수를 늘려 양측 엉덩이의 신경근 밸런스를 우측 수준으로 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '좌측 스트레칭 시 외측 섬유만 과하게 당겨져 정상인 우측과 이완 품질이 달라집니다.',
        '왼쪽 골반 전방경사 성향으로 인해 순수 이완보다 허리 보상이 먼저 일어납니다.',
        '좌측 발목 방향 차이가 무릎 관절에 비정상적인 회전 장력을 유발합니다.',
      ], methods: [
        '좌측 발목을 정면 수직으로 고정한 상태를 유지하며 단계별 이완을 진행합니다.',
        '좌측 골반 수평 상태를 최우선 확보하고 허리가 말리지 않는 범위에서 실시합니다.',
        '스트레칭 전후 가동 범위를 비교하여 좌측 개선 효과를 직접 확인하도록 유도합니다.',
      ] },
    },
    'ankles:LEFT_ANKLE_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 좌측 아치가 무너지며 몸이 왼쪽으로 쏠리고 우측 하중이 감소합니다.',
        '좌측 발목 가쪽번짐이 좌측 무릎 안쪽굽힘을 유도해 관절 내측 부하를 높입니다.',
        '상승 시 좌측 지면 반발력이 약해져 골반이 한쪽으로 뒤틀리는 보상이 발생합니다.',
      ], methods: [
        '좌측 발바닥 아치를 살리는 인지 훈련과 함께 뒤꿈치 접지력을 강조합니다.',
        '무릎 바깥쪽에 밴드를 착용해 좌측 엉덩이 근육이 발목 무너짐을 상쇄하게 합니다.',
        '정상인 우측 정렬을 기준으로 좌측이 대칭을 이루는지 실시간 모니터링합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 발이 앞일 때 아치가 무너지며 무릎 흔들림이 심해 안정성이 결여됩니다.',
        '좌측 발목 가쪽번짐이 정강뼈 안쪽돌림을 유도해 좌측 엉덩이 활성도를 낮춥니다.',
        '좌우 수행 시 좌측 아치 서포트 능력이 낮아 운동 품질 편차가 명확히 보입니다.',
      ], methods: [
        '좌측 앞발 아치를 세운 상태를 유지하고 무릎 궤적을 발등 중앙에 고정합니다.',
        '좌측 뒤꿈치 접지를 강화해 발목 하중을 엉덩이 근육으로 이동시키는 큐잉을 줍니다.',
        '트레이너가 거울/영상 피드백과 큐잉으로 좌측 발목 정렬과 지지 감각을 안내합니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 발 가쪽번짐이 골반 하부 비대칭을 유도해 코어와 하체 연결성을 약화시킵니다.',
        '체중이 엄지발가락 쪽에 쏠려 좌측 하체 안쪽 사슬만 과하게 긴장됩니다.',
        '유지 중 좌측 발목 피로도가 먼저 쌓여 골반 수평 정렬이 쉽게 무너집니다.',
      ], methods: [
        '좌측 발바닥 바깥날에 힘을 주어 가쪽번짐을 억제하고 양발 압력을 맞춥니다.',
        '뒤꿈치를 뒤로 밀어내는 힘으로 하부 사슬 텐션을 확보하고 골반 수평을 체크합니다.',
        '좌측 정렬이 무너지기 전까지만 수행하도록 짧은 세트 위주로 구성해 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체 안쪽 과긴장이 골반 전방경사를 유도해 좌측 복부 수축 범위를 제한합니다.',
        '좌측 발 지지 불안정으로 복부 수축 시 골반 고정력이 약해져 허리 통증을 유발합니다.',
        '상체를 들어 올릴 때 좌측 무릎이 안으로 모이며 복부 중앙 집중력을 떨어뜨립니다.',
      ], methods: [
        '좌측 발 위치를 정면 정렬하고 하체 안쪽의 불필요한 힘을 뺀 상태에서 실시합니다.',
        '무릎 사이에 볼을 끼워 골반 정렬을 안정시킨 채 좌측 복부 수축을 유도합니다.',
        '횟수보다 좌측 발바닥 전체 접지압이 일정하게 유지되는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 안정근 활성도가 낮아 동작 시 골반 뒤로 넘어가는 보상이 심합니다.',
        '좌측 엉덩이 대신 허리 근육을 끌어다 쓰는 비효율적 수축이 좌측에서만 나타납니다.',
        '좌측 고관절 순수 외회전 범위가 좁아져 있어 자극 인지력이 낮아질 수 있습니다.',
      ], methods: [
        '좌측은 소도구로 골반 흔들림을 줄인 상태에서 아주 작은 범위부터 엉덩이 자극을 찾습니다.',
        '속도를 늦춰 좌측 발목 정렬이 엉덩이 수축에 미치는 영향을 인지하도록 돕습니다.',
        '좌측 수행 횟수나 집중도를 높여 우측 정상 수준으로 신경근 밸런스를 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '좌측 발 가쪽번짐으로 인해 내측 햄스트링만 편향되게 자극되어 밸런스가 깨집니다.',
        '좌측 무릎 내측에 장력이 가해져 스트레칭 중 무릎 불편감을 호소할 수 있습니다.',
        '좌측 골반 전방경사 고정으로 햄스트링 시작점 분리 이완에 한계가 생깁니다.',
      ], methods: [
        '좌측 무릎과 발등이 정면 수직을 유지하도록 통제한 상태에서 단계별 이완합니다.',
        '좌측 발 아치를 살린 상태에서 실시해 무릎 내측 부하를 제거하고 타깃에 집중합니다.',
        '좌우 가동 범위를 측정해 좌측 개선 효과를 회원이 직접 확인하도록 유도합니다.',
      ] },
    },
    // ── 골반 좌우 높이 (hipHigher) ────────────────────────────
    'hipHigher:NORMAL': {
      squat: { isNormal: true, items: [
        '골반의 좌우 높이가 수평을 유지하여 하강 시 양측 대퇴골에 실리는 체중 부하가 대칭적으로 분산됩니다.',
        '정점부터 하단 구간까지 골반의 측면 기울어짐(Lateral Tilt) 없이 안정적인 수직 궤적이 관찰됩니다.',
        '골반 수평 정렬의 안정성을 바탕으로 척추 정중앙 라인이 흐트러짐 없이 유지되는 양호한 상태입니다.',
      ], methods: [
        '한쪽 어깨에만 중량을 지지한 상태(Uneven Loading)에서도 골반의 수평 축이 무너지지 않도록 제어 능력을 챌린지합니다.',
        '하강 시 골반 수평을 유지하며 한쪽 발을 뒤로 살짝 뺀 \'스태거드 스턴스(Staggered Stance)\' 스쿼트를 통해 비대칭 저항 능력을 높입니다.',
        '하단에서 멈춘 상태로 좌우 골반 높이를 스스로 체크하며 심부 안정화 근육의 긴장도를 유지하는 훈련을 병행합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '앞다리를 내딛는 동작 중에도 골반의 좌우 수평이 유지되어 요추와 골반 주변 근육의 대칭적 사용이 가능합니다.',
        '골반 높이가 동일하게 제어됨에 따라 상체가 어느 한쪽으로 쏠리지 않고 수직 방향으로 바르게 정렬됩니다.',
        '좌우 런지 간 골반 높이의 차이가 관찰되지 않아 양측 하체의 협응 능력이 균형 있게 발달한 패턴입니다.',
      ], methods: [
        '앞발이나 뒷발을 불안정한 지면(밸런스 패드 등)에 두고 수행하며, 흔들림 속에서도 골반 수평을 사수하는 능력을 챌린지합니다.',
        '한 손에만 덤벨을 든 \'팜 홀드(Farm hold)\' 런지를 통해 측면에서 당기는 중력을 이겨내고 골반 수평을 유지하도록 유도합니다.',
        '런지 자세에서 골반 수평을 고정한 채 상체를 좌우로 기울이는(Lateral Flexion) 컨트롤을 추가하여 외측 코어의 안정성을 강화합니다.',
      ] },
      plank: { isNormal: true, items: [
        '골반 좌우 높이가 지면과 평행을 이루어 복부와 엉덩이 근육이 대칭적인 지지력을 발휘하고 있습니다.',
        '유지 시간 동안 골반이 어느 한쪽으로 처지거나 회전하지 않고 견고한 수평 상태를 유지합니다.',
        '골반 수평 안정성을 바탕으로 몸통 중심선이 정중앙에 위치하여 코어의 결합력이 우수하게 나타납니다.',
      ], methods: [
        '한쪽 다리나 팔을 들어 지지점을 줄인 상태(3포인트 플랭크)에서도 골반 수평 축이 회전하거나 처지지 않도록 극한으로 챌린지합니다.',
        '플랭크 상태에서 다리를 옆으로 벌리는 \'플랭크 잭\' 동작 시 착지 순간의 골반 수평 회복 능력을 시험합니다.',
        '요추-골반 부위에 가벼운 소도구를 올려두고, 그것이 떨어지지 않게 수평을 유지하며 버티는 인지력 훈련을 실시합니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '상체 굴곡 시 골반의 좌우 높이가 동일하게 유지되어 복직근과 복사근의 대칭적 수축을 유도합니다.',
        '골반의 수평 안정성 덕분에 척추가 한쪽으로 휘어지지 않고 직선적인 상체 움직임이 가능합니다.',
        '반복적인 수축 과정에서도 골반이 바닥에서 불균형하게 들리지 않고 안정적인 지지대 역할을 수행합니다.',
      ], methods: [
        '한 다리를 들고 컬업을 수행하며, 비대칭적인 하체 무게 속에서도 골반의 좌우 수평이 흐트러지지 않게 챌린지합니다.',
        '상체를 들어 올린 정점에서 양팔을 한쪽 방향으로만 뻗어 발생하는 회전 부하를 골반 수평 힘으로 저항하도록 유도합니다.',
        '폼롤러 위에 세로로 누워 좁은 지면 위에서 골반 수평 밸런스를 잡으며 컬업을 수행하는 고난도 챌린지를 적용합니다.',
      ] },
      clam: { isNormal: true, items: [
        '준비 자세에서 양쪽 골반의 수직 축이 일직선상에 놓여 있어 둔근을 고립하기 위한 정렬이 매우 우수합니다.',
        '동작 수행 중 위쪽 골반이 뒤로 넘어지거나 높이가 변하지 않아 목표 근육에만 자극이 명확히 집중됩니다.',
        '골반의 수평 및 수직 정렬 안정성을 바탕으로 고관절의 순수 외회전 가동 범위가 확보됩니다.',
      ], methods: [
        '옆으로 누운 상태에서 아래쪽 옆구리를 지면에서 띄운(사이드 플랭크 결합) 채로 골반 수평을 유지하며 클램을 수행합니다.',
        '저항 밴드의 강도를 높인 상태에서 무릎을 벌릴 때 골반이 뒤로 밀리지 않도록 고정력을 극한으로 챌린지합니다.',
        '최대 범위에서 등척성 버티기를 수행하며, 피로가 쌓이는 상황에서도 골반 높이가 변하지 않는지 시험합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '스트레칭 시 골반의 좌우 높이가 평행하여 햄스트링 조직을 한쪽으로 쏠림 없이 고르게 이완시킬 수 있습니다.',
        '골반 수평이 유지됨에 따라 허리 부위의 비대칭적인 긴장 없이 하체 후면 사슬에만 자극이 정확히 전달됩니다.',
        '양측 스트레칭 시 동일한 골반 정렬 기준을 적용할 수 있어 유연성 밸런스를 체크하기에 이상적입니다.',
      ], methods: [
        '스트레칭 중 골반을 미세하게 전방·후방 경사(Tilt)시키는 컨트롤을 추가하여 수평 상태에서의 인지력을 챌린지합니다.',
        '서 있는 자세에서 한 다리를 들고 골반 수평을 유지하며 상체를 숙이는(싱글 레그 데드리프트 패턴) 동적 스트레칭으로 전환합니다.',
        '능동적으로 다리를 들어 올리는 동작을 통해 본인의 근력으로 골반 수평을 통제하며 유연성을 확보하도록 유도합니다.',
      ] },
    },
    'hipHigher:RIGHT_HIP_HIGHER': {
      squat: { isNormal: false, items: [
        '하강 시 골반이 오른쪽으로 밀려 올라가며 체중이 왼쪽으로 과도하게 쏠리는 비대칭이 발생합니다.',
        '우측 고관절의 가동 범위가 상대적으로 제한되어 하단 구간에서 골반이 회전하는 보상이 나타납니다.',
        '상승 시 우측 지면 반발력이 왼쪽보다 늦게 전달되어 척추의 수직 정렬이 뒤틀릴 수 있습니다.',
      ], methods: [
        '왼쪽 발바닥 압력을 더 인지하게 유도하고 오른쪽 골반을 아래로 내리는 정렬 큐잉을 제공합니다.',
        '정렬이 무너지기 직전의 깊이까지만 하강하며 양쪽 골반의 수평 높이를 실시간 체크합니다.',
        '트레이너가 거울과 큐잉을 활용해 우측 골반이 수평을 이루는 이동 궤적을 인지하도록 돕습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 다리가 앞일 때 높은 골반으로 인해 가동 범위가 짧아지고 오른쪽 허리에 과도한 긴장이 발생합니다.',
        '왼쪽 다리가 앞일 때 왼쪽 중둔근이 체중을 받쳐주지 못해 골반이 오른쪽 위로 더 처지기 쉽습니다.',
        '좌우 수행 시 골반 수평 유지 능력이 극명히 달라 수행 품질의 큰 편차가 관찰됩니다.',
      ], methods: [
        '왼쪽이 앞일 때 오른쪽 골반이 올라가지 않도록 중둔근의 지지력을 강조하는 큐잉을 줍니다.',
        '오른쪽이 앞일 때는 보폭을 조절하여 우측 요방형근의 과긴장을 억제한 상태에서 하강합니다.',
        '거울을 통해 양쪽 골반 돌기(ASIS)의 수평 라인을 확인하며 아주 천천히 수행합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 허리 근육의 긴장이 코어 중앙의 힘을 흩트려 골반이 시계 반대 방향으로 뒤틀리기 쉽습니다.',
        '체중이 왼쪽 다리로 더 실리면서 코어 근육이 편향되게 수축하는 비효율이 발생합니다.',
        '유지 중 우측 허리에 뻐근한 피로가 먼저 쌓여 코어 유지 시간보다 정렬 이탈이 먼저 나타납니다.',
      ], methods: [
        '우측 발을 뒤로 더 밀어내고 오른쪽 골반을 의도적으로 낮추어 수평 상태를 유지합니다.',
        '거울/영상으로 골반 좌우 높이를 확인하고, 처진 쪽을 들어 올리도록 큐잉합니다.',
        '정렬이 깨지기 전까지만 짧은 세트로 반복하여 보상 패턴이 고착되지 않게 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '골반 비대칭이 복부 수축 시 상체를 왼쪽으로 미세하게 기울게 만들어 복사근 불균형을 만듭니다.',
        '우측 골반의 단축으로 인해 척추가 바닥에 닿는 순서가 어긋나 허리 통증을 유발할 수 있습니다.',
        '하체 고정력이 비대칭하여 상체를 말아 올릴 때 오른쪽 목 근육이 더 과하게 개입될 수 있습니다.',
      ], methods: [
        '양발 접지압이 동일해지도록 왼쪽 발 지지를 강화하고 상체를 정면으로 말아 올립니다.',
        '복부 좌우 수축 강도를 확인하고 우측의 과도한 긴장이 줄어들도록 큐잉합니다.',
        '무릎 사이에 볼을 끼워 골반 수평을 강제 고정한 후 복부 중앙 수축 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '왼쪽 중둔근의 약화로 인해 좌측 수행 시 골반 흔들림을 제어하는 능력이 현저히 낮습니다.',
        '우측 수행 시에는 이미 단축된 근육들로 인해 순수 엉덩이 자극보다 허리 긴장이 먼저 옵니다.',
        '좌우 고관절 회전 축의 비대칭이 운동 범위를 제한하여 한쪽만 자극이 오는 불균형이 나타납니다.',
      ], methods: [
        '왼쪽 수행 시에는 벽/소도구를 활용해 골반 수평이 유지되도록 세팅합니다.',
        '오른쪽은 가동 범위보다 우측 요방형근의 이완과 엉덩이 고립 수축에 초점을 맞춥니다.',
        '감각이 무딘 왼쪽 엉덩이의 신경근 활성화 시간을 전략적으로 늘려 밸런스를 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른쪽 골반이 높아 우측 스트레칭 시 햄스트링 기시점이 짧아져 이완 효율이 저하됩니다.',
        '왼쪽 스트레칭 시에는 골반이 아래로 처지며 허리 척추의 비정상적인 측면 굽힘을 유발합니다.',
        '좌우 골반 높이 차이로 인해 스트레칭 시 무릎 관절의 회전 뒤틀림 장력이 발생합니다.',
      ], methods: [
        '우측 스트레칭 전 요방형근을 먼저 이완하여 골반 높이를 맞춘 후 실시합니다.',
        '골반 수평 상태와 햄스트링 기시점의 평행 여부를 최우선 확보한 뒤 단계별로 늘립니다.',
        '스트레칭 후 골반 수평을 재측정하여 비대칭 개선 여부를 회원이 직접 확인하게 합니다.',
      ] },
    },
    'hipHigher:LEFT_HIP_HIGHER': {
      squat: { isNormal: false, items: [
        '하강 시 골반이 왼쪽으로 밀려 올라가며 체중이 오른쪽으로 과하게 쏠리는 비대칭이 나타납니다.',
        '좌측 고관절의 가동 범위가 제한되어 하단에서 골반이 회전하거나 허리가 꺾이는 보상이 동반됩니다.',
        '상승 시 좌측 지면 반발력이 지연되어 척추 정렬이 오른쪽으로 휘어질 수 있습니다.',
      ], methods: [
        '오른쪽 발바닥 압력을 더 인지하게 유도하고 왼쪽 골반을 아래로 지긋이 내리는 큐잉을 줍니다.',
        '골반 수평이 유지되는 깊이까지만 하강하며 양쪽 무릎 궤적이 대칭을 이루는지 체크합니다.',
        '거울/영상 피드백으로 상체의 수직 이동 경로가 정중앙을 유지하는지 확인하며 수행합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 다리가 앞일 때 높은 골반으로 인해 가동 범위가 제한되고 왼쪽 허리에 부하가 집중됩니다.',
        '오른쪽 다리가 앞일 때 우측 중둔근 지지력 부족으로 골반이 왼쪽 위로 더 들리는 현상이 발생합니다.',
        '좌우 수행 시 골반 안정성 편차가 커서 특정 방향 수행 시 중심 유지가 불안정합니다.',
      ], methods: [
        '오른쪽이 앞일 때 왼쪽 골반이 올라가지 않도록 우측 엉덩이 근육의 외전 힘을 강조합니다.',
        '왼쪽이 앞일 때는 보폭과 깊이를 조절하여 좌측 허리의 과긴장이 나타나지 않게 통제합니다.',
        '양쪽 골반 상단 라인이 거울상에서 수평을 이루는지 실시간 피드백을 주며 하강합니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 허리 근육의 긴장이 골반을 시계 방향으로 비틀어 코어 대칭 수축 품질을 떨어뜨립니다.',
        '하중이 우측 다리로 은근히 쏠리면서 코어 근육이 편향되게 수축하는 비효율이 관찰됩니다.',
        '유지 중 좌측 허리에 피로가 먼저 쌓여 코어 집중력보다 정렬 이탈이 먼저 발생합니다.',
      ], methods: [
        '좌측 발을 뒤로 더 밀어내고 왼쪽 골반 높이를 의도적으로 낮추어 수평을 유도합니다.',
        '거울/영상으로 골반 좌우 높이를 확인하고 처진 쪽을 큐잉으로 조정합니다.',
        '비대칭이 나타나기 전까지만 수행하도록 짧은 고품질 세트 위주로 처방합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체 비대칭 정렬이 골반 회전을 유도해 복부 수축 시 상체가 오른쪽으로 기우는 현상이 생깁니다.',
        '좌측 골반 단축으로 인해 허리 뒤쪽 공간이 비대칭하게 형성되어 분절 움직임이 제한됩니다.',
        '하체 고정력이 불완전하여 상체를 말아 올릴 때 왼쪽 목 근육의 보상적 긴장이 나타납니다.',
      ], methods: [
        '우측 발 지지를 강화하여 양발 접지압을 맞추고 상체를 정면 수직으로 말아 올립니다.',
        '복부 좌우 수축 강도를 확인하여 좌측의 과도한 개입을 억제하도록 수정합니다.',
        '무릎 사이에 볼을 끼워 골반 수평을 강제 고정하고 복부 정중앙 수축 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 중둔근의 약화로 인해 오른쪽 수행 시 골반 수평 유지 능력이 저하됩니다.',
        '좌측 수행 시에는 이미 단축된 근육들로 인해 엉덩이 고립 수축보다 허리 개입이 빠릅니다.',
        '비대칭적인 긴장 분포로 인해 약한 쪽 엉덩이의 자극 인지력이 현저히 낮아질 수 있습니다.',
      ], methods: [
        '오른쪽 수행 시 골반 수직 축 유지를 위해 소도구와 시각적 피드백을 적극 활용합니다.',
        '왼쪽은 가동 범위보다 좌측 요방형근 이완과 엉덩이 순수 수축에 초점을 맞춥니다.',
        '우측 엉덩이의 신경근 활성화 훈련을 보강하여 좌우 밸런스를 정상화합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼쪽 골반이 높아 좌측 스트레칭 시 햄스트링 기시점이 단축되어 이완 효율이 반감됩니다.',
        '오른쪽 스트레칭 시에는 골반이 처지며 허리 척추의 측면 뒤틀림 보상이 발생합니다.',
        '좌우 골반 높이 차이가 무릎 관절의 회전 장력을 유발해 이완의 질을 떨어뜨립니다.',
      ], methods: [
        '좌측 스트레칭 전 요방형근 이완을 먼저 실시하여 골반 정렬을 맞춘 후 진행합니다.',
        '골반 수평 상태를 최우선 확보하고 햄스트링 기시점이 평행한지 확인하며 늘립니다.',
        '스트레칭 후 골반 수평 개선 여부를 측정하여 회원이 직접 변화를 인지하게 합니다.',
      ] },
    },
    // ── 골반 좌우 중심 이동 (hipCenter) ─────────────────────────
    'hipCenter:HIP_NOT_CENTER_RIGHT': {
      squat: { isNormal: false, items: [
        '골반 정렬이 우측으로 치우치는 경향이 있어, 하강 시 체중 부하가 오른발 쪽으로 과도하게 쏠릴 가능성이 있습니다.',
        '내려가는 과정에서 골반의 수평 축이 흔들리며, 양쪽 하체의 대칭적인 움직임과 가동 범위가 제한될 수 있습니다.',
        '동작 중 골반이 우측으로 빠지는 보상 작용으로 인해, 우측 고관절 및 무릎 관절에 기계적 스트레스가 집중될 수 있습니다.',
      ], methods: [
        '보수나 밸런스 패드 위에 회원님을 세운 뒤, "왼쪽 엄지발가락과 뒤꿈치 안쪽으로 바닥을 더 강하게 눌러 골반이 오른쪽으로 밀리지 않게 하세요."라고 지시합니다.',
        '스쿼트 하강 중 골반이 우측으로 틀어지는 지점에서 멈추게 한 뒤, "오른쪽 골반을 왼쪽으로 3cm만 밀어 중앙 맞추고 3~5초 버티세요."라고 지시합니다.',
        '좌측 다리를 앞에 둔 스플릿 스쿼트 자세에서, 회원님에게 "체중의 80%를 왼쪽 앞발에 싣고 양쪽 골반 높이를 수평으로 맞춘 채 수직으로 내려가세요."라고 지시합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '전방으로 중심을 이동할 때 골반이 우측으로 밀리거나 회전하면서, 척수 수직선상으로 상체 무게를 안정적으로 지지하지 못할 가능성이 있습니다.',
        '골반의 대칭이 느슨해지면서 체중이 실린 앞쪽 무릎 정렬이 안쪽(Valgus) 또는 바깥쪽으로 흔들리는 비정상적 궤도를 보일 수 있습니다.',
        '좌우 런지를 번갈아 수행할 때 골반의 위치 제어가 일정하지 않아, 양측 다리의 독립적인 지지 능력에 차이가 나타날 수 있습니다.',
      ], methods: [
        '뒷발을 벤치에 올리고 좌측 다리를 앞발로 둔 뒤, 회원님에게 "왼쪽 무릎이 안쪽이나 바깥쪽으로 무너지지 않게 두 번째 발가락과 일직선을 유지하며 수직으로 앉으세요."라고 가이드합니다.',
        '런지 하강 상태에서 상체를 우측으로 돌릴 때, 트레이너가 회원님의 좌측 엉덩관절 바깥쪽을 손으로 지탱하며 "제 손을 밀어내며 골반은 정면 고정, 명치 위쪽만 오른쪽으로 돌리세요."라고 지시합니다.',
        '회원님의 오른손에만 덤벨을 쥐여준 뒤, "오른쪽 무게에 몸통과 골반이 찌그러지지 않게 왼쪽 옆구리와 왼쪽 엉덩이에 힘 줘서 골반 수평을 유지하세요."라고 큐잉합니다.',
      ] },
      plank: { isNormal: false, items: [
        '버티는 동안 척추와 골반 중심선이 우측으로 치우쳐, 전신 코어 근육이 대칭적으로 동원되지 못하고 한쪽으로 편중될 가능성이 있습니다.',
        '좌우 하체 및 골반 지지체에 실리는 하중 분배가 불균형해지면서, 둔근과 복부의 균등한 등척성 수축 능력이 저하될 수 있습니다.',
        '버티는 시간이 경과할수록 코어 피로도가 증가하여 골반이 우측이나 아래쪽으로 더 처지는 비대칭 패턴이 관찰될 수 있습니다.',
      ], methods: [
        '니플랭크 자세에서 회원님의 우측 다리나 좌측 팔을 들게 한 뒤, "오른쪽 골반이 들리거나 밀리지 않게 왼쪽 앞허벅지와 복부에 힘 줘서 양쪽 골반 높이를 맞추세요."라고 지시합니다.',
        '니플랭크 자세에서 미니볼 위에 한쪽 팔을 올리고 원을 그리게 할 때, 회원님에게 "오른쪽으로 크게 돌 때도 골반이 따라가지 않게 왼쪽 옆구리를 단단히 조여 중심선을 정중앙에 고정하세요."라고 가이드합니다.',
        '트레이너가 회원님의 좌측 골반 옆면을 손으로 잡고 오른쪽 방향으로 밀어내며, "골반이 밀리지 않게 스스로 버티는 벽을 만드세요."라고 지시합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '상체를 일으킬 때 몸통의 중심선이 우측으로 어긋나면서 복부 근육이 비대칭적으로 수축하고, 이로 인해 미세한 회전 보상이 일어날 수 있습니다.',
        '양쪽 복사근의 긴장도 차이로 인해 상체가 정직선으로 올라오지 못하고 한쪽으로 미세하게 비틀어지며 상승할 가능성이 있습니다.',
        '반복 횟수가 늘어남에 따라 상체가 똑바로 정면을 향하지 못하고 우측으로 치우치는 고정된 회전 패턴이 나타날 수 있습니다.',
      ], methods: [
        '상체를 들어 올린 정점에서 한 팔씩 머리 위로 뻗게 한 뒤, 회원님에게 "상체가 한쪽으로 비틀어지지 않게 양쪽 복부 높이를 맞춘 채 유지하세요."라고 큐잉합니다.',
        '컬업 정지 자세에서 다리를 교차로 뻗게 할 때, 회원님에게 "다리를 뻗어도 한쪽 골반이 처지지 않게 양쪽 허리 뒤쪽을 바닥에 균등하게 밀착시키세요."라고 가이드합니다.',
        '폼롤러 위에 세로로 눕혀 컬업을 시킨 뒤, 회원님에게 "등과 엉덩이가 한쪽으로 미끄러지지 않게 척추 라인이 폼롤러 정중앙을 따라 올라오세요."라고 지시합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 운동을 수행할 때 골반이 정면 정중앙을 유지하지 못하고 우측(바닥 쪽)으로 과도하게 밀려, 타겟인 엉덩이 근육의 고립 효율이 떨어질 수 있습니다.',
        '바깥돌리 시 골반이 뒤로 넘어가거나 틀어지는 보상 작용이 발생하여, 엉덩관절 고유의 순수한 가동 범위가 온전히 제한될 가능성이 있습니다.',
        '골반을 단단히 고정해주는 지지력이 약해지면서 엉덩이 근육 대신 허리 주변 근육(허리네모근 등)이 과도하게 동원될 수 있습니다.',
      ], methods: [
        '왼쪽으로 누워 밴드를 차고, "골반이 뒤로 눕지 않게 바닥과 수직으로 고정한 뒤, 오른쪽 엉덩이 힘으로만 무릎을 여세요."라고 지시합니다.',
        '바닥에 닿은 왼쪽 옆구리를 살짝 들게 한 뒤, "옆구리가 바닥에 무너지면 골반이 꺾이니, 왼쪽 옆구리를 단단하게 받쳐 들고 움직이세요."라고 가이드합니다.',
        '무릎을 벌린 정점에서 10초간 멈추게 한 뒤, "시간이 지나도 골반이 뒤로 도망가거나 무릎이 내려앉지 않게 그대로 고정하고 버티세요."라고 큐잉합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '골반 정렬이 우측으로 틀어지면서 장력이 분산되어, 스트레칭 시 좌측 허벅지 뒷면 근육의 신장(이완) 효율이 감소할 가능성이 있습니다.',
        '골반이 한쪽으로 빠지는 측방 변위 현상으로 인해, 타겟 근육에 균등한 이완 자극이 전달되지 못하고 척추 주변부에 보상성 스트레스가 갈 수 있습니다.',
        '좌우 스트레칭을 비교했을 때 골반 위치의 비대칭적 차이가 도드라져, 하체 후면 사슬 전반의 유연성이 불균형하게 나타날 수 있습니다.',
      ], methods: [
        '서서 상체를 숙일 때 우측 골반을 왼쪽으로 밀어주며, "골반이 오른쪽으로 빠지지 않게 왼쪽 발바닥 안쪽을 꾹 누르며 엉덩이를 뒤로 빼세요."라고 지시합니다.',
        '양발로 서서 숙였다 일어나는 동적 움직임 중, "무게중심이 오른쪽 뒤꿈치로 쏠리지 않게, 양발을 대칭으로 누르며 몸통 중심선을 매트 중앙에 고정하세요."라고 가이드합니다.',
        '좌측 골반 옆면에 세라밴드를 걸어 오른쪽으로 당겨지게 세팅한 뒤, "밴드가 오른쪽으로 잡아당기는 힘에 저항하면서, 골반을 스스로 왼쪽(중앙)으로 밀어내며 숙이세요."라고 지시합니다.',
      ] },
    },
    'hipCenter:HIP_NOT_CENTER_LEFT': {
      squat: { isNormal: false, items: [
        '하강 시 체중이 좌측으로 더 실리며 우측 하체의 지지 참여가 상대적으로 늦어질 수 있습니다.',
        '골반이 좌측으로 이동하면서 몸통 중심선(Midline) 유지가 어려워지고 정렬이 흔들릴 수 있습니다.',
        '깊이가 깊어질수록 좌측 치우침이 커지면 좌우 힘 전달 효율이 떨어질 수 있습니다.',
      ], methods: [
        '우측 발바닥 전체로 바닥을 강하게 밀어 체중을 5:5로 맞춘 범위까지만 내려갑니다.',
        '골반이 좌측으로 이동하기 직전 구간에서 부분 반복 스쿼트로 하강 패턴을 먼저 고정합니다.',
        '거울/촬영 피드백으로 골반 중심이 양발 중앙에 유지되는지 확인하며 속도를 낮춥니다.',
      ] },
      lunge: { isNormal: false, items: [
        '우측 런지에서 체중 싣기 타이밍이 늦어지며 상체가 좌측으로 기울 수 있습니다.',
        '우측 무릎-발 방향 정렬이 흔들리면 좌측 다리 의존도가 더 커질 수 있습니다.',
        '좌우 런지 수행 질 차이가 커지면 하체 사용 전략이 비대칭으로 고정될 수 있습니다.',
      ], methods: [
        '우측 런지는 보폭을 줄이고 천천히 싣는 컨트롤 런지로 정렬을 먼저 확보합니다.',
        '"우측 뒤꿈치–엄지발볼로 바닥을 누른다"는 큐로 우측 지지 감각을 올립니다.',
        '좌우 세트 구성은 우측(약한 쪽) 먼저 진행해 수행 질을 맞추는 방식이 효율적입니다.',
      ] },
      plank: { isNormal: false, items: [
        '체중이 좌측 팔·다리에 더 실리며 골반이 좌측으로 이동하는 패턴이 나타날 수 있습니다.',
        '우측 복부·우측 엉덩이 안정화 참여가 줄면 자세 유지 시간이 길어질수록 비대칭이 커질 수 있습니다.',
        '견갑·골반의 좌우 압력 차이가 커지면 중심선 유지가 어려워질 수 있습니다.',
      ], methods: [
        '우측 손과 발로 바닥을 더 강하게 밀어 좌우 압력을 맞추는 큐를 사용합니다.',
        '10–20초 짧은 유지로 시작해 정렬 유지 성공률을 우선으로 세트를 설계합니다.',
        '거울/촬영으로 골반이 한쪽으로 밀리기 시작하는 시점을 찾아 그 이전에서 반복합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '복부 수축 시 좌측 사용 비중이 커지면 몸통이 좌측으로 살짝 회전하는 경향이 나타날 수 있습니다.',
        '우측 복부의 긴장 형성이 늦어지면 반복 후반부에 대칭성이 무너질 수 있습니다.',
        '좌우 갈비뼈 하강(리브 다운) 패턴이 달라지면 복압 유지가 흔들릴 수 있습니다.',
      ], methods: [
        '"우측 갈비뼈도 바닥 쪽으로 내려온다"는 큐로 좌우 수축을 맞춥니다.',
        '낮은 반복(3–6회)에서 대칭 수축 유지를 확인한 뒤 점진적으로 반복을 늘립니다.',
        '회원에게는 "배에 힘을 양쪽 똑같이 켠다"는 표현으로 이해를 쉽게 안내합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 클램에서 골반이 뒤로 넘어가면 목표 근육 자극이 분산될 수 있습니다.',
        '좌측으로 치우친 패턴이 있으면 좌측 골반 고정이 과해져 우측 움직임이 작아질 수 있습니다.',
        '결과적으로 좌우 엉덩이 사용감 차이가 커져 비대칭이 유지될 수 있습니다.',
      ], methods: [
        '골반을 정면으로 고정하고 가동범위를 줄인 클램으로 우측 자극을 선명하게 만듭니다.',
        '옆구리·골반에 손을 대고 "골반은 고정, 다리만 열린다"는 촉각 피드백을 줍니다.',
        '좌우 동일 반복이 아니라 우측 1세트 추가처럼 상품화 가능한 처방이 가능합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 스트레칭에서 골반이 좌측으로 틀어지면 실제 신장감이 흐려질 수 있습니다.',
        '햄스트링보다 허리/골반 주변에 먼저 긴장이 느껴지면 정렬이 무너졌을 가능성이 있습니다.',
        '좌우 체감 차이가 커지면 스트레칭 강도가 한쪽으로만 올라갈 수 있습니다.',
      ], methods: [
        '우측 다리 스트레칭 시 골반이 정면을 향하도록 고정하고 범위를 작게 시작합니다.',
        '강도를 올리기보다 정렬 유지 시간(호흡 4–6회)을 먼저 늘립니다.',
        '좌우 동일 각도·동일 시간으로 진행해 "느낌"이 아니라 "기준"으로 관리합니다.',
      ] },
    },
    'hipCenter:NORMAL': {
      squat: { isNormal: false, items: [
        '체중이 좌우 5:5로 분산되더라도 깊이가 깊어지면 무릎/발목 정렬 변수가 새로 나타날 수 있습니다.',
        '부하가 증가하면 중심선은 유지돼도 속도-반동으로 하강 제어가 흐트러질 수 있습니다.',
        '피로가 누적되면 마지막 반복에서 정렬이 흔들리기 쉬워 품질 관리가 필요합니다.',
      ], methods: [
        '현재의 5:5 지지 감각을 유지하면서 템포 스쿼트(천천히 하강)로 제어 능력을 강화합니다.',
        '무릎-발 방향이 끝까지 유지되는 범위에서만 깊이를 확장합니다.',
        '정렬이 유지되면 덤벨→바벨 순으로 점진적 부하(Loading) 프로그램을 제안할 수 있습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '중심선이 좋아도 보폭이 과하면 골반이 전후로 흔들리며 안정성이 떨어질 수 있습니다.',
        '좌우 다리 길이·유연성 차이가 있으면 런지 깊이에서 미세한 비대칭이 생길 수 있습니다.',
        '속도가 빨라지면 무릎-발 정렬이 흐트러져 효율이 낮아질 수 있습니다.',
      ], methods: [
        '보폭을 고정하고 수직 하강을 우선으로 하는 정렬 런지로 반복 품질을 표준화합니다.',
        '좌우 동일 깊이·동일 속도 기준을 제시해 회원이 스스로 체크 가능하게 합니다.',
        '덤벨 로딩은 "정렬 유지가 되는 만큼만" 단계적으로 적용합니다.',
      ] },
      plank: { isNormal: false, items: [
        '중심선이 좋아도 어깨·견갑 위치가 무너지면 허리 보상이 생길 수 있습니다.',
        '호흡이 끊기면 복압이 풀려 자세 유지가 급격히 떨어질 수 있습니다.',
        "시간이 길어질수록 정렬이 무너지는지 '지속 품질' 평가가 필요합니다.",
      ], methods: [
        '"바닥을 밀어 견갑을 안정" + "갈비뼈를 내리고 호흡 유지" 두 가지 기준으로 코칭합니다.',
        '20–30초 단위로 끊어 품질 기반 세트를 구성합니다.',
        '정렬 유지가 되면 사이드 플랭크, 리치 등으로 난이도를 확장해 프로그램 가치를 높일 수 있습니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '중심선이 좋아도 목·어깨 힘이 먼저 들어가면 복부 자극이 분산될 수 있습니다.',
        '반복이 많아지면 리브 플레어(갈비뼈 들림)로 복압이 흔들릴 수 있습니다.',
        "반동이 생기면 복부 '조절' 목적이 약해질 수 있습니다.",
      ], methods: [
        '턱을 살짝 당기고 갈비뼈를 내린 상태에서 짧은 범위 컬업으로 시작합니다.',
        '6–10회 내에서 호흡과 복압 유지가 되는 반복만 수행합니다.',
        '숙련되면 팔 위치·템포 조절로 난이도를 높여도 정렬이 유지되는지 점검합니다.',
      ] },
      clam: { isNormal: false, items: [
        '중심선이 좋아도 골반이 뒤로 넘어가면 타깃 자극이 흐려질 수 있습니다.',
        '가동범위 욕심이 커지면 허리 회전으로 보상하기 쉽습니다.',
        '좌우 수행 질 차이가 나면 엉덩이 안정화가 한쪽만 강화될 수 있습니다.',
      ], methods: [
        '골반 고정(정면 유지) 기준을 먼저 잡고 가동범위는 작게 시작합니다.',
        '좌우 동일 템포·동일 범위로 표준화해 "대칭 수행"을 목표로 둡니다.',
        '밴드 강도는 정렬이 유지되는 선에서 단계적으로 올립니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '중심선이 좋아도 무릎이 과하게 펴지면 허리 긴장이 먼저 올라올 수 있습니다.',
        '좌우 유연성 차이가 있으면 한쪽만 과신장되는 방식으로 진행될 수 있습니다.',
        '호흡이 멈추면 스트레칭 강도 대비 효과가 떨어질 수 있습니다.',
      ], methods: [
        '무릎 각도를 약간 완화하고 골반 정면 유지 기준으로 스트레칭합니다.',
        '좌우 동일 시간으로 진행하고 체감이 다르면 각도만 조절합니다.',
        '호흡 4–6회 유지하며 강도보다 "정렬+호흡" 기준으로 진행합니다.',
      ] },
    },
    // ── 발 방향 (foot) ────────────────────────────────────────
    'foot:NORMAL': {
      squat: { isNormal: true, items: [
        '양발이 정면을 나란히 향하고 있어, 하강 시 하중을 수직으로 받아내기에 매우 유리한 기초 정렬을 갖추고 있습니다.',
        '발가락의 방향성이 우수하여 하강 깊이가 깊어져도 무릎 정렬이 발등 궤적을 이탈하지 않고 안정적으로 유지됩니다.',
        '발의 정방향 배치를 바탕으로 양측 하체의 대칭적인 힘 전달 패턴이 관찰됩니다.',
      ], methods: [
        '하강 시 발목이 안팎으로 기울지 않도록 중립을 유지하며, 지면을 발바닥 전체로 움켜쥐는 접지력 강화 훈련을 병행합니다.',
        '점프 후 착지 시 발가락 방향뿐만 아니라 발목의 내·외측 안정성까지 동시에 사수하는 반응성 챌린지를 적용합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '양발이 정면을 나란히 향하고 있어, 하강 시 하중을 수직으로 받아내기에 매우 유리한 기초 정렬을 갖추고 있습니다.',
        '발가락의 방향성이 우수하여 하강 깊이가 깊어져도 무릎 정렬이 발등 궤적을 이탈하지 않고 안정적으로 유지됩니다.',
        '발의 정방향 배치를 바탕으로 양측 하체의 대칭적인 힘 전달 패턴이 관찰됩니다.',
      ], methods: [
        '하강 시 발목이 안팎으로 기울지 않도록 중립을 유지하며, 지면을 발바닥 전체로 움켜쥐는 접지력 강화 훈련을 병행합니다.',
        '점프 후 착지 시 발가락 방향뿐만 아니라 발목의 내·외측 안정성까지 동시에 사수하는 반응성 챌린지를 적용합니다.',
      ] },
      plank: { isNormal: true, items: [
        '양발의 뒤꿈치가 벌어지거나 모이지 않는 정면 배치를 통해 후면 사슬 근육의 균등한 긴장 상태를 유도합니다.',
        '발가락 정렬이 중립을 유지하여 지면을 밀어내는 힘이 신체 중심선으로 고르게 전달됩니다.',
        '유지 시간 동안 발의 각도가 변하지 않고 일관된 정면 정렬을 유지하는 능력이 확인됩니다.',
      ], methods: [
        '발목의 내·외측 흔들림을 제어하며 한 다리를 들거나 움직이는 동작을 추가하여, 발목 중립 유지력을 챌린지합니다.',
        '플랭크 상태에서 체중을 앞뒤로 이동시킬 때 발목이 수직 궤도를 유지하도록 정교한 조절 능력을 향상시킵니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '양발이 정면을 나란히 응시하여 복부 수축 시 하체의 불필요한 보상 움직임이나 골반 회전을 효과적으로 억제합니다.',
        '무릎과 발가락의 정렬 일치로 상체 굴곡 시 하중이 척추 라인을 따라 정중앙으로 집중되는 양호한 패턴입니다.',
        '반복적인 수축 과정에서도 발바닥의 지면 접촉 상태가 대칭적으로 안정감 있게 유지됩니다.',
      ], methods: [
        '양발 사이에 도구를 끼워 하체 정렬(발목 중립 포함)을 고정한 채로 복부의 대칭적 수축 강도를 극대화합니다.',
        '지면에서 발을 살짝 띄운 채 정렬을 유지하며 컬업을 수행하여, 외부 지지 없이도 하체의 대칭성을 사수하는 챌린지를 적용합니다.',
      ] },
      clam: { isNormal: true, items: [
        '준비 자세에서 양발의 날이 정확히 맞물려 있어 고관절 외회전 시의 정렬 기준점이 매우 명확합니다.',
        '발의 정향 배치를 통해 움직임 중 발목의 불필요한 회전을 차단하고 목표 둔근에 자극을 고립시키기 유리합니다.',
        '발의 안정적인 정적 정렬이 고관절 가동 범위 확보를 위한 든든한 기초 지지대 역할을 수행합니다.',
      ], methods: [
        '동작 중 발목이 안팎으로 꺾이지 않도록 중립을 유지하며 저항 밴드의 탄성을 이겨내는 고립 수축 챌린지를 실시합니다.',
        '양발을 지면에서 띄운 채 허공에서 정렬을 유지하며 클램을 수행하여 하체 컨트롤 능력을 극한으로 끌어올립니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '발가락이 하늘을 향해 수직으로 정렬되어 있어, 햄스트링 조직을 편중 없이 고르게 이완시키는 최적의 각도를 확보했습니다.',
        '스트레칭 시 발목의 회전 보상 작용이 없어 목표 근육에만 신장 자극을 정확히 전달할 수 있는 상태입니다.',
        '양발의 대칭적 정렬을 통해 하체 유연성의 순수 지표를 정교하게 파악하기 좋은 조건입니다.',
      ], methods: [
        '발목의 중립(Inversion/Eversion 없음)을 엄격히 유지한 상태로 발등을 몸쪽으로 당겨 후면 사슬 전체의 긴장도를 시험합니다.',
        '정렬을 스스로 통제하며 다리를 들어 올리는 능동적 스트레칭을 통해, 움직임 속에서도 발목 중립을 사수하는 능력을 챌린지합니다.',
      ] },
    },
    'foot:FOOT_OUTWARD': {
      squat: { isNormal: false, items: [
        '발이 밖으로 벌어지면 하강 시 허벅지뼈의 안쪽 돌림 힘이 발생하여 무릎 안쪽 구조물에 날카로운 압박 부하가 집중됩니다.',
        '발목의 발등굽힘 가동성 부족을 보상하기 위해 상체를 과하게 숙이거나 허리를 꺾어 깊이를 채우려는 패턴이 나타납니다.',
        '하단 구간에서 발바닥 아치가 주저앉으며 지면 반발력을 잃고 하중이 발날이 아닌 발목 관절 자체에 실리게 됩니다.',
      ], methods: [
        '뒤꿈치 아래 낮은 받침을 활용해 발목 각도를 보완하고 상체를 세워 허리와 무릎의 부담을 즉각적으로 줄입니다.',
        '무릎이 두 번째 발가락 라인을 따라 움직이도록 허벅지 바깥쪽 근육 참여를 유도하여 내측 쏠림 하중을 분산합니다.',
        '발바닥 아치가 무너지기 직전까지만 범위를 설정하고 발바닥의 삼점 지지(뒤꿈치, 엄지발볼, 새끼발볼) 감각을 먼저 익힙니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 외전된 상태에서 하강하면 무릎이 방향을 잃고 안팎으로 흔들리는 불안정성이 커지며 관절에 불필요한 마찰을 만듭니다.',
        '지면과 발 사이의 지지력이 비효율적인 방향으로 작용하여 뒤꿈치가 지면에서 뜨고 앞발 끝에만 하중이 쏠립니다.',
        '비대칭 발 정렬로 인해 좌우 런지 수행 시 골반이 한쪽으로 빠지는 등 좌우 능력의 현격한 편차가 관찰됩니다.',
      ], methods: [
        '보폭을 좁혀 하체 근육들이 관절 정렬을 보호할 수 있는 범위를 확보하고 발의 외전 각도를 단계적으로 줄여 연습합니다.',
        '"뒤꿈치로 지면을 뚫는다"는 느낌의 큐잉을 통해 발 전체의 수직 지지력을 확보하고 엉덩이 근육의 참여도를 높입니다.',
        '무릎 궤적이 이탈할 때마다 전문가의 실시간 핸즈온 가이드를 통해 정렬을 수정하여 뇌에 올바른 움직임 길을 만들어줍니다.',
      ] },
      plank: { isNormal: false, items: [
        '발이 밖으로 밀리며 하체 바깥쪽 근육들만 과하게 긴장하여 코어 중앙으로 힘이 모이지 않고 분산됩니다.',
        '허벅지 바깥쪽과 종아리 근육의 피로도가 높아지면서 유지 시간이 급격히 짧아지고 허리 통증이 유발됩니다.',
        '발의 지지점이 불안정해지면 몸이 앞으로 쏠리면서 어깨 관절에 과도한 체중 하중이 전가됩니다.',
      ], methods: [
        '발을 정면으로 고정한 상태에서 엄지발가락 쪽의 접지력을 강화하여 하체 안쪽 사슬의 힘을 깨웁니다.',
        '60초 버티기보다 15초씩 고품질 유지를 반복하여 하체 정렬이 무너지기 전까지만 코어를 훈련합니다.',
        '발바닥 압력 분포가 바깥날로 쏠리지 않는지 지속적으로 확인하며 좌우 하중 균형을 잡아줍니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 외측 긴장도가 높으면 골반이 앞으로 회전(전방 경사)하기 쉬워 복부 근육의 수축 깊이가 방해받습니다.',
        '발의 위치가 바깥으로 벌어지면 복직근 수축 시 골반 고정력이 약해져 목과 어깨 근육의 과도한 개입을 만듭니다.',
        '하체 힘을 억제하지 못해 복부 운동임에도 불구하고 허벅지 앞쪽 근육이 과하게 쓰이는 현상이 나타납니다.',
      ], methods: [
        '발 위치를 정면으로 정렬하고 하체의 힘을 뺀 상태에서 복부 근육의 말기(Curling) 동작에만 집중합니다.',
        '무릎 사이에 가벼운 공을 끼워 안쪽 근육을 활성화하면 골반 전방 경사를 막고 복부 타격감을 높일 수 있습니다.',
        '반복 횟수보다 상체가 올라오는 궤적의 수평 정렬이 유지되는지 품질을 최우선으로 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '평소 발이 벌어진 정렬 특성상 외측 근육이 이미 단축되어 있어 순수한 중둔근 수축보다 겉 근육의 개입이 빨라집니다.',
        '다리를 벌릴 때 골반이 뒤로 과하게 넘어가는 보상 작용이 발생하여 엉덩이 대신 골반 주변 인대에 스트레스가 가해집니다.',
        '이미 벌어진 범위에서 시작하다 보니 실제 필요한 수축 구간의 가동 범위가 짧아 운동 효율이 떨어집니다.',
      ], methods: [
        '아주 작은 범위에서부터 골반을 고정하는 법을 먼저 익히고 엉덩이 깊은 곳의 뻐근한 자극에 집중합니다.',
        '움직이는 속도를 기존의 절반으로 낮춰 뇌가 정밀하게 근육 수축을 제어할 수 있는 환경을 만듭니다.',
        '좌측과 우측의 수축 감각 차이를 비교하여 밸런스를 맞추는 조절 훈련을 병행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발이 밖으로 벌어진 상태에서 늘리면 스트레칭 방향이 뒤틀려 햄스트링 외측 섬유만 과하게 자극될 수 있습니다.',
        '햄스트링보다 종아리 바깥쪽 근육의 팽팽함이 먼저 느껴져 효율적인 이완을 방해합니다.',
        '골반이 이미 바깥으로 돌아가 고정된 상태라 햄스트링의 시작점을 분리하여 늘리기 어렵습니다.',
      ], methods: [
        '발을 정면으로 정확히 정렬한 뒤 무릎의 궤적도 일치시킨 상태에서 스트레칭을 시작합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지하여 종아리 개입을 줄이고 순수 햄스트링 이완에 집중합니다.',
        '유연성 확보보다 골반의 수평 정렬 유지를 우선시하여 관절 손상 없는 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'foot:FOOT_INWARD': {
      squat: { isNormal: false, items: [
        '발가락 끝이 안으로 모이면서 체중이 발 바깥날로 쏠려 접지 면적이 좁아지고 하강 시 좌우 균형이 불안정해집니다.',
        '안쪽 모음 정렬이 엉덩관절의 가동 범위를 제한하여 하강 시 골반이 뒤로 과하게 빠지거나 허리가 말리는 보상이 나타납니다.',
        '하체 바깥쪽 근육이 과하게 긴장하며 무릎을 밖으로 밀어내려 하여 무릎 외측 관절면에 압박 부하를 유발할 수 있습니다.',
      ], methods: [
        '발가락 끝을 정면으로 정렬하여 중립을 확보하고 발바닥 삼점 접지(뒤꿈치, 엄지발볼, 새끼발볼) 감각을 다시 인지시킵니다.',
        '"엄지발가락 아래 발볼로 지면을 꾹 누르라"는 큐잉을 통해 외측으로 분산된 무게 중심을 중앙으로 이동시킵니다.',
        '발목의 회전 변이가 무릎 궤적을 방해하지 않는 범위 내에서만 하강하며 엉덩이 근육의 통제력을 체크합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발의 안쪽 모음으로 인해 하강 시 무릎이 중심선을 잃고 흔들리며 발목 바깥쪽 인대에 과도한 장력이 가해집니다.',
        '뒤꿈치 접지가 불안정해지면서 엉덩이 근육보다 종아리 외측 근육이 먼저 피로해지는 비효율적 패턴이 나타납니다.',
        '하체 외측 사슬의 긴장으로 인해 골반이 수직으로 내려가지 못하고 옆으로 빠지는 보상이 발생합니다.',
      ], methods: [
        '앞발을 정면으로 고정하고 뒤꿈치를 지면에 견고하게 붙여 엉덩이 근육이 하중을 온전히 받아내도록 유도합니다.',
        '보폭을 좁게 설정하여 발목의 정렬 통제권을 확보하고 하강 시 무릎 궤적을 전문가가 실시간 교정합니다.',
        '하강 템포를 늦춰 발바닥 전체의 압력이 균등하게 유지되는지 스스로 인지하는 훈련을 병행합니다.',
      ] },
      plank: { isNormal: false, items: [
        '양발이 안으로 모이며 하체 외측의 과긴장을 유발해 전신 장력이 코어 중앙으로 모이지 않고 분산됩니다.',
        '지면을 지지하는 발가락 끝에 힘이 쏠려 코어 유지 시간이 단축되고 허리 뒤쪽 근육에 보상적 긴장이 나타납니다.',
        '발의 지지점이 불안정해 골반이 위로 들리거나 좌우로 흔들리는 불안정성이 관찰됩니다.',
      ], methods: [
        '양발을 정면으로 나란히 고정하고 엄지발가락 쪽 압력을 높여 하체 안팎의 장력 균형을 대칭적으로 맞춥니다.',
        '발뒤꿈치를 뒤로 강하게 밀어내는 힘을 유지하여 하체와 코어의 연결성을 확보한 상태에서 세트를 수행합니다.',
        '짧은 시간 반복하더라도 골반 수평과 복압 유지 품질을 최우선으로 하여 보상 패턴을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 안쪽 모음 긴장이 골반 중립을 방해하여 복부 근육이 최대 수축 가동 범위에 도달하는 것을 저해합니다.',
        '하체 지지력의 불안정으로 복부 수축 시 골반 고정력이 약해져 목과 어깨 근육의 과도한 개입을 만듭니다.',
        '복부 운동임에도 불구하고 허벅지 바깥쪽 근육이 과하게 개입되어 협응력이 떨어지는 현상이 나타납니다.',
      ], methods: [
        '발 위치를 정면으로 교정하고 하체에 들어가는 불필요한 힘을 뺀 상태에서 복부 순수 굴곡에만 집중합니다.',
        '무릎 사이에 가벼운 볼을 끼워 안쪽 근육을 활성화하면 골반 정렬을 안정시켜 복부 타격감을 높일 수 있습니다.',
        '반복 횟수보다 상체가 올라오는 궤적의 정중앙 정렬이 유지되는지 품질 위주로 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '안쪽 모음 정렬로 인해 엉덩이 벌림근이 약화되어 동작 수행 시 골반이 뒤로 넘어가는 보상이 극심합니다.',
        '엉덩이 대신 허리 근육이나 허벅지 옆쪽 근육을 끌어다 쓰는 비효율적인 수축 패턴이 관찰됩니다.',
        '엉덩관절의 순수한 외회전 범위가 좁아져 가동 범위를 무리하게 넓히려다 척추 정렬이 무너집니다.',
      ], methods: [
        '등 뒤에 벽을 밀착시켜 골반 회전을 차단하고 아주 작은 범위에서 정확한 엉덩이 자극을 찾는 데 집중합니다.',
        '내리는 속도를 늦추어 조절 능력을 강화하고 약화된 엉덩이 근육의 신경을 깨우는 훈련을 실시합니다.',
        '양측의 조절력 편차를 확인하여 약한 쪽 엉덩이 근육에 더 많은 시간과 집중력을 투자합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발이 안으로 모인 상태에서 늘리면 햄스트링 외측 섬유만 과하게 당겨져 전체적인 이완 효율이 저하됩니다.',
        '햄스트링보다 발목 바깥쪽이나 종아리 외측의 팽팽함이 먼저 느껴져 효율적인 대퇴 부위 이완을 방해합니다.',
        '골반이 미세하게 회전된 채 고정되어 햄스트링의 시작점을 명확히 분리하여 늘리는 데 한계가 있습니다.',
      ], methods: [
        '발을 정면으로 정확히 정렬하고 무릎 궤적을 일치시킨 상태에서 엉덩이 힌지를 활용해 단계별로 이완합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지하여 종아리 개입을 줄이고 순수 햄스트링 신장에 집중합니다.',
        '유연성 확보보다 골반 수평 정렬 유지를 우선시하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'foot:FOOT_RIGHT': {
      squat: { isNormal: false, items: [
        '하강 시 골반이 오른쪽으로 미세하게 회전하며 오른쪽 엉덩관절에 압박이 가해지고 왼쪽 하체 지지력은 감소합니다.',
        '우측 발목의 벌림 정렬로 인해 오른쪽 무릎이 안으로 무너지기 쉬우며 척추에 비대칭적인 비틀림 부하가 발생합니다.',
        '지면을 밀어내는 힘이 불균형하여 일어나는 동작에서 상체가 오른쪽으로 기울어지는 현상이 관찰됩니다.',
      ], methods: [
        '"오른발은 안쪽, 왼발은 바깥쪽"으로 비트는 인지력을 부여하여 양발을 나란히 유지하고 골반 정면을 강제합니다.',
        '골반이 회전하기 직전까지만 내려가는 부분 반복을 통해 신체 중심선을 유지하는 인지 훈련을 실시합니다.',
        '왼쪽 발바닥 전체로 지면을 더 강하게 밀어내어 좌우 하중 분배를 5:5로 맞추는 협응력 강화에 집중합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발과 뒷발의 방향이 일치하지 않아 무릎의 수직 이동 궤적이 흔들리고 특히 왼쪽 다리가 앞일 때 중심 잡기가 어렵습니다.',
        '우측 발의 벌림으로 인해 앞발 수행 시 무릎 관절에 꼬이는 장력이 발생하여 주변 조직의 피로도를 높입니다.',
        '하강 구간에서 골반 수평이 깨지며 체중이 우측으로 쏠려 좌우 근육 발달의 불균형을 심화시킵니다.',
      ], methods: [
        '양발의 방향을 정면으로 고정한 뒤 뒤꿈치 접지 감각을 강조하여 수직 지지력을 먼저 확보합니다.',
        '거울을 통해 골반 수평과 무릎 궤적을 실시간으로 확인하며 아주 천천히 하강하는 템포 훈련을 적용합니다.',
        '비대칭이 심한 방향의 수행 횟수를 조절하거나 전문가의 핸즈온을 통해 올바른 궤적을 뇌에 학습시킵니다.',
      ] },
      plank: { isNormal: false, items: [
        '발의 비대칭 정렬이 골반의 미세 회전을 유도하여 코어 근육이 한쪽으로 뒤틀린 채 수축하는 비효율이 발생합니다.',
        '우측 허리 주변 근육에 과도한 긴장이 쏠리면서 유지 시간이 길어질수록 한쪽 허리만 뻐근한 통증이 나타납니다.',
        '지면을 지지하는 양발 압력이 불균형하여 코어 하부의 긴장도가 좌우 다르게 형성됩니다.',
      ], methods: [
        '양발 뒤꿈치를 벽에 붙이고 골반 수평을 맞춘 상태에서 하체 전체의 장력을 동일하게 유지하려 노력합니다.',
        '골반의 좌측과 우측 높이가 수평을 이루는지 전문가의 정밀 가이드를 통해 정렬 품질을 높입니다.',
        '60초 유지보다 골반 회전이 일어나기 전까지만 수행하는 고품질 세트 구성으로 코어 대칭 수축을 유도합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체에서 시작된 회전 보상이 복부 수축 시 상체를 우측으로 기울게 만들어 복사근의 불균형을 초래합니다.',
        '골반 회전으로 인해 척추 마디가 바닥에 닿는 순서가 어긋나며 척추 주변 근육에 불필요한 긴장을 만듭니다.',
        '하체 고정이 비대칭적이라 상체를 말아 올릴 때 특정 방향 목 근육이 더 과하게 개입됩니다.',
      ], methods: [
        '양발바닥 전체로 지면을 누르는 힘의 대칭을 확인하고 상체가 회전하지 않는 정방향으로만 실시합니다.',
        '복부 좌우 수축 압력이 균등하게 느껴지는지 실시간 언어 피드백을 통해 편향된 사용을 수정합니다.',
        '반복 횟수보다 양쪽 어깨뼈가 바닥에서 동시에 떨어지는지 품질 위주로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 근육은 이미 짧아진 반면 좌측은 활성도가 떨어지는 신경근 비대칭이 관찰됩니다.',
        '골반이 이미 한쪽으로 치우쳐 있어 동작 수행 시 수직 축을 유지하기 어렵고 허리 근육 개입이 빠릅니다.',
        '양쪽 엉덩이의 수축 타이밍이 달라 한쪽은 자극이 오고 한쪽은 오지 않는 현상이 나타납니다.',
      ], methods: [
        '좌측 수행 시 골반이 뒤로 밀리지 않게 물리적으로 고정하고 엉덩이 깊은 곳의 신경을 깨우는 데 집중합니다.',
        '우측은 가동 범위보다 조절 능력에 집중하여 과활성화된 근육을 이완하고 순수 엉덩이 근육을 고립시킵니다.',
        '감각이 무딘 쪽의 훈련 강도와 시간을 조절하여 양측의 신경계 밸런스를 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발 방향에 따라 햄스트링 긴장도가 달라 스트레칭 시 관절의 불필요한 회전이 발생합니다.',
        '골반 치우침으로 인해 스트레칭 시 허리 척추가 한쪽으로 꺾이는 보상이 일어나 효과가 분산됩니다.',
        '특정 근육 섬유만 당겨지고 나머지는 이완되지 않아 유연성 개선 속도가 저하됩니다.',
      ], methods: [
        '척추 중심선을 유지하며 양발이 정면을 보게 고정한 뒤 엉덩이 힌지를 활용해 이완합니다.',
        '무릎 정렬이 수직을 유지하도록 통제한 상태에서 호흡과 함께 아주 천천히 범위를 늘립니다.',
        '스트레칭 후 동작 재평가를 통해 확보된 가동 범위가 움직임 품질을 높였는지 확인합니다.',
      ] },
    },
    'foot:FOOT_LEFT': {
      squat: { isNormal: false, items: [
        '하강 시 골반이 왼쪽으로 회전하며 왼쪽 고관절에 압박이 가해지고 오른쪽 다리의 지지력은 유실됩니다.',
        '비대칭 발 정렬로 인해 오른쪽 무릎은 안으로, 왼쪽 무릎은 밖으로 벌어지는 회전 보상이 나타납니다.',
        '양발의 접지력이 달라 일어나면서 몸이 한쪽으로 뒤틀리는 조절력 저하 현상이 관찰됩니다.',
      ], methods: [
        '"왼발은 안으로, 오른발은 밖으로" 비트는 회전 인지력을 부여하여 양발 정면 정렬과 골반 수평을 강제합니다.',
        '골반이 회전하기 직전의 깊이까지만 하강하는 훈련을 통해 신체 중심선을 유지하는 감각을 복구합니다.',
        '오른쪽 발바닥 전체로 지면을 더 강하게 밀어내어 좌우 하중 분배를 5:5로 맞추는 데 집중합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '양발의 방향이 엇갈려 무릎 이동 궤적이 불안정하며 특히 오른쪽 다리가 앞일 때 중심 잡기가 어렵습니다.',
        '좌측 발의 바깥 벌림은 왼쪽 무릎의 내측 무너짐을 유도하여 좌우 다리의 수직 지지력 차이를 만듭니다.',
        '하강 시 골반 수평이 깨지며 체중이 왼쪽으로 쏠려 무릎 주변 근육의 비대칭적 발달을 가속화합니다.',
      ], methods: [
        '양발의 방향을 정면으로 엄격히 제한하고 발바닥 전체로 지면을 누르는 지지력을 확보합니다.',
        '거울을 통해 골반 수평과 무릎 궤적을 실시간 점검하며 전문가의 가이드 하에 아주 천천히 하강합니다.',
        '비대칭이 심한 쪽의 수행 품질을 높이기 위해 핸즈온 교정을 병행하며 올바른 수축 경로를 학습시킵니다.',
      ] },
      plank: { isNormal: false, items: [
        '비대칭 발 정렬이 골반 회전을 유도하여 코어 근육이 뒤틀린 채 수축하는 비효율적 패턴이 나타납니다.',
        '왼쪽 허리 주변 근육에 과도한 긴장이 쏠리면서 유지 중 특정 부위에만 통증이나 피로가 집중됩니다.',
        '지면을 지지하는 발의 압력이 불균형하여 하체와 코어를 연결하는 신경계 반응이 좌우 다르게 나타납니다.',
      ], methods: [
        '양발 뒤꿈치를 벽에 붙이고 골반 수평을 맞춘 상태에서 양발 압력을 대칭적으로 유지하려 노력합니다.',
        '골반의 좌우 높이가 수평인지 전문가의 정밀 측정을 통해 정렬 품질을 높입니다.',
        '60초 유지보다 골반 회전이 일어나기 전까지만 수행하는 고품질 인지 훈련 세트를 구성합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 회전 보상이 상체까지 전달되어 복부 수축 시 몸이 왼쪽으로 기울어지는 비대칭 수축이 발생합니다.',
        '골반 비틀림으로 인해 척추 분절 운동이 일정하지 않고 허리 뒤쪽 공간이 한쪽만 뜨는 불안정성이 관찰됩니다.',
        '하체 고정이 불완전하여 상체를 들어 올릴 때 특정 방향 목 근육만 과하게 긴장합니다.',
      ], methods: [
        '양발바닥 지면 지지력을 대칭으로 고정하고 상체가 회전하지 않는 정면 방향으로만 실시합니다.',
        '복부 좌우 수축 압력이 균등하게 느껴지는지 실시간 피드백을 주어 편향된 근육 사용을 수정합니다.',
        '반복 횟수보다 양쪽 견갑골이 바닥에서 동시에 떨어지는지 품질 위주로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 근육은 과활성되어 짧아진 반면 우측은 활성도가 낮아 자극 편차가 크게 발생합니다.',
        '골반이 이미 왼쪽으로 회전되어 있어 수직 축 유지가 어렵고 요추 주변의 보상 긴장이 유도됩니다.',
        '양쪽 엉덩관절의 가용 범위가 달라 한쪽은 자극이 오고 한쪽은 오지 않는 신경근 불균형이 나타납니다.',
      ], methods: [
        '우측 수행 시 골반이 뒤로 밀리지 않게 물리적으로 고정하고 엉덩이 깊은 곳의 신경을 깨우는 데 집중합니다.',
        '좌측은 가동 범위보다 조절 능력에 집중하여 과활성화된 근육을 이완하고 순수 중둔근만 고립시킵니다.',
        '감각이 무딘 쪽의 훈련 시간을 늘려 양측 엉덩이의 인지 밸런스를 맞추는 훈련을 병행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '발 방향 비대칭으로 인해 햄스트링 안팎의 긴장도가 달라 스트레칭 시 관절의 불필요한 비틀림이 발생합니다.',
        '골반 치우침이 허리 척추의 측면 굽힘을 유도하여 스트레칭 중 허리 불편감을 호소할 수 있습니다.',
        '특정 근육 섬유만 과하게 당겨지고 나머지는 이완되지 않아 유연성 개선 효과가 비대칭적으로 나타납니다.',
      ], methods: [
        '척추 중심선을 유지하며 양발 정면 정렬을 확보한 뒤 엉덩이 힌지를 활용해 이완합니다.',
        '무릎 궤적이 수직을 유지하도록 통제하고 호흡과 함께 아주 천천히 범위를 늘립니다.',
        '스트레칭 후 확보된 가동 범위가 움직임 품질을 개선했는지 즉각적으로 재평가합니다.',
      ] },
    },
    'foot:RIGHT_FOOT_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 오른쪽 무릎만 안으로 모이며 오른쪽 엉덩관절 안정성이 깨지고 체중이 왼쪽으로 쏠리게 됩니다.',
        '오른발 아치와 접지력이 흔들려 우측 하체 지면 지지력이 소실되고 상체 정렬이 우측으로 기웁니다.',
        '우측 고관절의 안쪽 돌림 보상이 발생하여 요추와 골반 정렬의 좌우 불균형을 심화시킵니다.',
      ], methods: [
        '오른쪽 무릎 바깥쪽에 저항 밴드를 활용해 우측 엉덩이 외회전근의 신경을 강제로 활성화합니다.',
        '오른발 엄지발볼 접지를 유지하면서 아치를 세우는 인지 훈련을 통해 우측 지지력을 복구합니다.',
        '양쪽 무릎이 각자의 발등 라인을 따라 나란히 하강하는지 전문가의 정밀 핸즈온 가이드를 받습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 오른발일 때 무릎이 안으로 흔들리며 우측 관절 내측 통증이나 불안정성을 유발할 수 있습니다.',
        '오른쪽 발목 안정성 부족으로 하강 속도 조절이 어렵고 엉덩이 근육에 하중이 제대로 전달되지 않습니다.',
        '좌우 런지 수행 시 우측의 지지 능력이 낮아 운동 품질의 심한 편차가 관찰됩니다.',
      ], methods: [
        '오른발 수행 시 보폭을 조절하여 무릎 정렬을 통제하고 발바닥 전체 접지력을 확보합니다.',
        '오른쪽 뒤꿈치 접지를 강조하여 우측 엉덩이 근육이 체중 부하를 견딜 수 있게 가이드합니다.',
        '전문가가 우측 무릎 궤적을 실시간 고정해 주어 올바른 수직 이동 경로를 뇌에 기억시킵니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 발의 안쪽 모음이 골반 우측 전방 경사를 유도하여 코어 하부 정렬의 비대칭을 만듭니다.',
        '체중이 왼쪽 발로 은근히 실리면서 코어 근육이 한쪽으로 치우쳐 수축하는 현상이 나타납니다.',
        '유지 중 우측 허벅지 안쪽 근육에만 과도한 긴장이 쏠려 골반 수평 유지가 어려워집니다.',
      ], methods: [
        '우측 발날의 접지력을 높여 하체 외측 사슬을 깨우고 양발 압력을 대칭적으로 맞춥니다.',
        '골반 우측이 아래로 처지지 않는지 실시간 피드백을 주어 코어 대칭 수축 품질을 유지합니다.',
        '정렬이 100%인 상태에서만 수행하도록 짧은 세트 위주로 구성하여 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체의 안쪽 모음이 복부 수축 시 골반 우측 회전을 유도해 복사근 사용의 좌우 편차를 만듭니다.',
        '오른쪽 엉덩굽힘근의 과도한 개입으로 인해 컬업 시 골반 우측이 들썩이는 불안정성이 발생합니다.',
        '우측 지지력 부족이 상체 굴곡 궤적을 비틀어 목 근육의 한쪽 긴장을 유발합니다.',
      ], methods: [
        '오른발바닥 전체 지면 지지력을 확인하고 골반 수평 상태에서만 상체를 정면으로 말아 올립니다.',
        '무릎 사이에 볼을 끼워 우측 하체 정렬을 고정하고 우측 복부의 정방향 수축 인지력을 높입니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 근육 활성도가 낮아 클램 수행 시 골반이 뒤로 넘어가는 보상이 극심하게 나타납니다.',
        '우측 엉덩이 대신 허리 근육이나 내전근을 끌어다 쓰는 비효율적인 수축 패턴이 관찰됩니다.',
        '좌우 수축 감각 차이가 커서 우측은 정확한 자극 지점을 찾기가 매우 어렵습니다.',
      ], methods: [
        '우측 수행 시 전문가가 골반을 직접 고정하고 아주 작은 범위에서 엉덩이 신경을 깨우는 데 집중합니다.',
        '속도를 절반 이하로 낮춰 뇌가 우측 엉덩이 근육 수축을 정밀하게 제어하도록 가이드합니다.',
        '우측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 맞추는 훈련을 병행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 햄스트링 내측 섬유의 과긴장으로 스트레칭 시 무릎 관절에 비정상적인 회전 장력이 발생합니다.',
        '오른쪽 골반 전방 경사 성향 때문에 순수 햄스트링 이완보다 허리 척추 보상이 먼저 일어납니다.',
        '우측 스트레칭 시 나타나는 무릎 내측 불편감이 효율적인 이완을 방해합니다.',
      ], methods: [
        '우측 무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별 이완을 진행합니다.',
        '오른발 아치를 살린 상태에서 스트레칭하여 무릎 내측 부하를 제거하고 타깃 근육만 늘립니다.',
        '스트레칭 전후 가동 범위를 측정하여 우측 개선 효과를 직접 확인하도록 유도합니다.',
      ] },
    },
    'foot:RIGHT_FOOT_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 오른쪽 무릎이 밖으로 벌어지며 체중이 발 바깥날로 쏠리고 우측 고관절 외측에 압박이 집중됩니다.',
        '우측 발목 가동성 부족을 보완하기 위해 상체가 과하게 숙여지며 허리 우측에 불필요한 긴장을 유발합니다.',
        '우측 하중 지지가 외측으로 분산되어 상승 시 힘의 효율이 떨어지고 골반이 비틀리게 됩니다.',
      ], methods: [
        '오른쪽 뒤꿈치 아래 낮은 받침을 활용해 발목 제한을 해소하고 우측 무릎이 정면을 향하도록 유도합니다.',
        '오른발 엄지발볼 접지력을 강화하여 지면 반발력을 중앙으로 모으고 발목 안정성을 높입니다.',
        '하강 시 오른쪽 무릎이 두 번째 발가락 라인을 유지하는지 전문가의 실시간 피드백을 받습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 오른발일 때 무릎이 밖으로 흔들리며 발바닥 전체 접지가 상실되어 중심 유지가 불안정합니다.',
        '오른쪽 발목 가동성 제한으로 하강 구간에서 뒤꿈치가 뜨려 하며 무릎 관절에 과도한 하중이 쏠립니다.',
        '좌우 수행 시 우측의 가용 범위가 짧아지거나 정렬이 깨지는 등 운동 품질의 편차가 큽니다.',
      ], methods: [
        '오른발 수행 시 보폭을 줄여 발목 부담을 낮추고 뒤꿈치 접지 감각을 강조해 수직 지지력을 확보합니다.',
        '오른쪽 무릎이 밖으로 벌어지지 않게 전문가가 핸즈온 고정하여 엉덩이 근육이 체중을 받게 합니다.',
        '정렬 유지가 가능한 범위 내에서만 하강 깊이를 설정해 올바른 궤적 학습에만 집중합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 발의 바깥 벌림이 하체 우측 외측 사슬 과긴장을 유발해 코어 중앙 긴장도를 방해합니다.',
        '체중이 우측 어깨나 허리로 은근히 전가되면서 유지 중 비대칭적 통증이 발생할 수 있습니다.',
        '우측 발 지지점이 불안정해 골반 수평을 유지하기 위한 코어 조절 능력이 한계를 드러냅니다.',
      ], methods: [
        '오른발을 정면으로 정확히 고정하고 엄지발가락 쪽 압력을 높여 전신 장력이 대칭으로 맞춥니다.',
        '골반 우측 높이가 왼쪽과 수평을 유지하는지 점검하여 코어 대칭 수축 품질을 확보합니다.',
        '우측 정렬이 무너지기 전까지만 짧은 세트로 훈련하여 보상 패턴이 고착되지 않게 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체의 외측 긴장도가 골반 우측 전방 경사를 유도해 우측 복부 수축 깊이를 제한합니다.',
        '오른발 벌림으로 인해 복부 수축 시 골반 고정력이 약해져 우측 어깨나 목 근육 과사용을 만듭니다.',
        '하체 지지력 비대칭이 상체 말기 동작 궤적을 비틀어 복사근의 불균형한 사용을 유발합니다.',
      ], methods: [
        '오른발 위치를 정면으로 정렬하고 하체 힘을 뺀 상태에서 복부 근육의 순수 굴곡 동작에만 집중합니다.',
        '무릎 사이에 볼을 끼워 우측 하체 정렬을 안정시키면 골반 흔들림을 막아 복부 자극을 높일 수 있습니다.',
        '반복 횟수보다 상체가 정면 수직 방향으로 올라오는지 품질 위주로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 외측 근육이 이미 단축된 상태라 순수 중둔근 수축보다 겉 근육 개입이 매우 빠릅니다.',
        '오른쪽 무릎을 벌릴 때 골반이 뒤로 과하게 회전하는 보상이 나타나 엉덩이 근육 이완을 방해합니다.',
        '이미 벌어진 범위에서 시작하게 되어 실제 필요한 유효 가동 범위가 짧아 운동 효율이 떨어집니다.',
      ], methods: [
        '우측 수행 시 골반 수평을 물리적으로 고정하고 아주 작은 범위에서 엉덩이 깊은 자극을 찾습니다.',
        '속도를 절반으로 낮춰 뇌가 우측 엉덩이 근육의 미세한 조절을 인지하도록 가이드합니다.',
        '우측 조절 능력이 좌측과 대칭을 이룰 때까지 정확한 자극 위주의 고립 훈련을 반복합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '오른발 벌림 정렬로 인해 스트레칭 시 햄스트링 외측 섬유만 과하게 자극되어 이완 효율이 반감됩니다.',
        '우측 햄스트링보다 종아리 바깥쪽 팽팽함이 먼저 느껴져 효율적인 대퇴 이완을 방해합니다.',
        '우측 골반이 외회전된 채 고정되어 햄스트링 시작점을 분리해 늘리는 데 구조적 한계가 있습니다.',
      ], methods: [
        '오른발을 정면으로 정확히 정렬하고 무릎 궤적을 일치시킨 상태에서 단계별 이완을 진행합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지해 종아리 개입을 줄이고 순수 햄스트링 신장에 집중합니다.',
        '가동 범위보다 골반 수평 정렬 유지를 우선해 관절 손상 없는 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'foot:LEFT_FOOT_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 왼쪽 무릎만 안으로 모이며 왼쪽 엉덩관절 안정성이 깨지고 체중이 오른쪽으로 쏠리게 됩니다.',
        '왼발 아치와 접지력이 흔들려 좌측 하체 지면 지지력이 소실되고 상체 정렬이 좌측으로 기웁니다.',
        '좌측 고관절의 안쪽 돌림 보상이 발생하여 전체적인 골반과 척추 정렬의 비대칭을 유발합니다.',
      ], methods: [
        '왼쪽 무릎 바깥쪽에 저항 밴드를 활용해 좌측 엉덩이 외회전근의 신경을 강제로 활성화합니다.',
        '왼발 엄지발볼 접지를 유지하면서 아치를 살리는 인지 훈련을 통해 좌측 지지력을 회복합니다.',
        '양쪽 무릎이 각자의 발등 라인을 따라 나란히 하강하는지 전문가의 정밀 핸즈온 가이드를 받습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 왼발일 때 무릎이 안으로 심하게 흔들리며 좌측 관절 내측 통증이나 불안정성을 유발할 수 있습니다.',
        '왼쪽 발목 안정성 부족으로 하강 속도 조절이 어렵고 엉덩이 근육에 하중이 전달되지 않습니다.',
        '좌우 런지 수행 시 좌측의 지지 능력이 현저히 낮아 운동 품질의 불균형이 명확히 관찰됩니다.',
      ], methods: [
        '왼발 수행 시 보폭을 조절하여 무릎 정렬을 통제하고 발바닥 전체 접지력을 확보합니다.',
        '왼쪽 뒤꿈치 접지를 강조하여 좌측 엉덩이 근육이 체중 부하를 견딜 수 있게 가이드합니다.',
        '전문가가 좌측 무릎 궤적을 실시간 고정해 주어 올바른 수직 이동 경로를 뇌에 기억시킵니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 발의 안쪽 모음이 골반 좌측 전방 경사를 유도하여 코어 하부 정렬의 비대칭을 만듭니다.',
        '체중이 오른쪽 발로 은근히 실리면서 코어 근육이 한쪽으로 치우쳐 수축하는 현상이 나타납니다.',
        '유지 중 좌측 허벅지 안쪽 근육에만 과도한 긴장이 쏠려 골반 수평 유지가 어려워집니다.',
      ], methods: [
        '좌측 발날의 접지력을 높여 하체 외측 사슬을 깨우고 양발 압력을 대칭적으로 맞춥니다.',
        '골반 좌측이 아래로 처지지 않는지 실시간 피드백을 주어 코어 대칭 수축 품질을 유지합니다.',
        '정렬이 100%인 상태에서만 수행하도록 짧은 세트 위주로 구성하여 보상을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체의 안쪽 모음이 복부 수축 시 골반 좌측 회전을 유도해 복사근 사용의 좌우 편차를 만듭니다.',
        '왼쪽 엉덩굽힘근의 과도한 개입으로 인해 컬업 시 골반 좌측이 들썩이는 불안정성이 발생합니다.',
        '좌측 지지력 부족이 상체 굴곡 궤적을 비틀어 왼쪽 목 근육의 과도한 긴장을 유발합니다.',
      ], methods: [
        '왼발바닥 전체 지면 지지력을 확인하고 골반 수평 상태에서만 상체를 정면으로 말아 올립니다.',
        '무릎 사이에 볼을 끼워 좌측 하체 정렬을 고정하고 좌측 복부의 정방향 수축 인지력을 높입니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 품질을 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 근육 활성도가 낮아 클램 수행 시 골반이 뒤로 넘어가는 보상이 극심하게 나타납니다.',
        '왼쪽 엉덩이 대신 허리 근육이나 내전근을 끌어다 쓰는 비효율적인 수축 패턴이 관찰됩니다.',
        '좌우 수축 감각 차이가 커서 좌측은 정확한 자극 지점을 찾기가 매우 어렵습니다.',
      ], methods: [
        '좌측 수행 시 전문가가 골반을 직접 고정하고 아주 작은 범위에서 엉덩이 신경을 깨우는 데 집중합니다.',
        '속도를 절반 이하로 낮춰 뇌가 좌측 엉덩이 근육 수축을 정밀하게 제어하도록 가이드합니다.',
        '좌측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 맞추는 훈련을 병행합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '좌측 햄스트링 내측 섬유의 과긴장으로 스트레칭 시 무릎 관절에 비정상적인 회전 장력이 발생합니다.',
        '왼쪽 골반의 전방 경사 성향 때문에 순수 햄스트링 이완보다 허리 척추 보상이 먼저 일어납니다.',
        '좌측 스트레칭 시 나타나는 무릎 내측 불편감이 효율적인 이완을 방해합니다.',
      ], methods: [
        '좌측 무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별 이완을 진행합니다.',
        '왼발 아치를 살린 상태에서 스트레칭하여 무릎 내측 부하를 제거하고 타깃 근육만 늘립니다.',
        '스트레칭 전후 가동 범위를 비교하여 회원이 좌측 개선 효과를 직접 확인하도록 유도합니다.',
      ] },
    },
    'foot:LEFT_FOOT_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 왼쪽 무릎이 밖으로 벌어지며 체중이 발 바깥날로 쏠리고 좌측 고관절 외측에 압박이 집중됩니다.',
        '좌측 발목 가동성 부족을 보완하기 위해 상체가 과하게 숙여지며 허리 좌측에 불필요한 긴장을 유발합니다.',
        '좌측 하중 지지가 외측으로 분산되어 상승 시 힘의 효율이 떨어지고 골반이 비틀리게 됩니다.',
      ], methods: [
        '왼쪽 뒤꿈치 아래 낮은 받침을 활용해 발목 제한을 해소하고 좌측 무릎이 정면을 향하도록 유도합니다.',
        '왼발 엄지발볼 접지력을 강화하여 지면 반발력을 중앙으로 모으고 발목 안정성을 높입니다.',
        '하강 시 왼쪽 무릎이 두 번째 발가락 라인을 유지하는지 전문가의 실시간 피드백을 받습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 왼발일 때 무릎이 밖으로 흔들리며 발바닥 전체 접지가 상실되어 중심 유지가 불안정합니다.',
        '왼쪽 발목 가동성 제한으로 하강 구간에서 뒤꿈치가 뜨려 하며 무릎 관절에 과도한 하중이 쏠립니다.',
        '좌우 수행 시 좌측의 가용 범위가 짧아지거나 정렬이 깨지는 등 운동 품질의 편차가 큽니다.',
      ], methods: [
        '왼발 수행 시 보폭을 줄여 발목 부담을 낮추고 뒤꿈치 접지 감각을 강조해 수직 지지력을 확보합니다.',
        '왼쪽 무릎이 밖으로 벌어지지 않게 전문가가 핸즈온 고정하여 엉덩이 근육이 체중을 받게 합니다.',
        '정렬 유지가 가능한 범위 내에서만 하강 깊이를 설정해 올바른 궤적 학습에만 집중합니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 발의 바깥 벌림이 하체 좌측 외측 사슬 과긴장을 유발해 코어 중앙 긴장도를 방해합니다.',
        '체중이 좌측 어깨나 허리로 은근히 전가되면서 유지 중 비대칭적 통증이 발생할 수 있습니다.',
        '좌측 발 지지점이 불안정해 골반 수평을 유지하기 위한 코어 조절 능력이 한계를 드러냅니다.',
      ], methods: [
        '왼발을 정면으로 정확히 고정하고 엄지발가락 쪽 압력을 높여 전신 장력이 대칭으로 맞춥니다.',
        '골반 좌측 높이가 오른쪽과 수평을 유지하는지 점검하여 코어 대칭 수축 품질을 확보합니다.',
        '좌측 정렬이 무너지기 전까지만 짧은 세트로 훈련하여 보상 패턴이 고착되지 않게 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체의 외측 긴장도가 골반 좌측 전방 경사를 유도해 좌측 복부 수축 깊이를 제한합니다.',
        '왼발 벌림으로 인해 복부 수축 시 골반 고정력이 약해져 좌측 어깨나 목 근육 과사용을 만듭니다.',
        '하체 지지력 비대칭이 상체 말기 동작 궤적을 비틀어 복사근의 불균형한 사용을 유발합니다.',
      ], methods: [
        '왼발 위치를 정면으로 정렬하고 하체 힘을 뺀 상태에서 복부 근육의 순수 굴곡 동작에만 집중합니다.',
        '무릎 사이에 볼을 끼워 좌측 하체 정렬을 안정시키면 골반 흔들림을 막아 복부 자극을 높일 수 있습니다.',
        '반복 횟수보다 상체가 정면 수직 방향으로 올라오는지 품질 위주로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 외측 근육이 이미 단축된 상태라 순수 중둔근 수축보다 겉 근육 개입이 매우 빠릅니다.',
        '왼쪽 무릎을 벌릴 때 골반이 뒤로 과하게 회전하는 보상이 나타나 엉덩이 근육 이완을 방해합니다.',
        '이미 벌어진 범위에서 시작하게 되어 실제 필요한 유효 가동 범위가 짧아 운동 효율이 떨어집니다.',
      ], methods: [
        '좌측 수행 시 골반 수평을 물리적으로 고정하고 아주 작은 범위에서 엉덩이 깊은 자극을 찾습니다.',
        '속도를 절반으로 낮춰 뇌가 좌측 엉덩이 근육의 미세한 조절을 인지하도록 가이드합니다.',
        '좌측 조절 능력이 우측과 대칭을 이룰 때까지 정확한 자극 위주의 고립 훈련을 반복합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼발 벌림 정렬로 인해 스트레칭 시 햄스트링 외측 섬유만 과하게 자극되어 이완 효율이 반감됩니다.',
        '좌측 햄스트링보다 종아리 바깥쪽 팽팽함이 먼저 느껴져 효율적인 대퇴 이완을 방해합니다.',
        '좌측 골반이 외회전된 채 고정되어 햄스트링 시작점을 분리해 늘리는 데 구조적 한계가 있습니다.',
      ], methods: [
        '왼발을 정면으로 정확히 정렬하고 무릎 궤적을 일치시킨 상태에서 단계별 이완을 진행합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지해 종아리 개입을 줄이고 순수 햄스트링 신장에 집중합니다.',
        '가동 범위보다 골반 수평 정렬 유지를 우선해 관절 손상 없는 안전한 스트레칭을 유도합니다.',
      ] },
    },
    // ── 무릎 좌우 이동 (knees) ────────────────────────────────────
    'knees:NORMAL': {
      squat: { isNormal: true, items: [
        '무릎 관절이 발등의 수직 라인과 일치하여 하강 시 체중 부하를 관절 면에 고르게 분산시키는 이상적인 상태입니다.',
        'Valgus(안쪽 모임)나 Varus(바깥 벌어짐) 패턴 없이 정면 궤적을 유지하며 대퇴사두근의 대칭적 발달을 유도합니다.',
        '동작이 깊어져도 무릎의 정면 정렬이 변함없이 유지되어 하체 관절의 역학적 안정성이 매우 높습니다.',
      ], methods: [
        '하단 구간에서 폭발적으로 상승하는 점프 스쿼트 수행 시에도 무릎 정렬이 일직선을 유지하는지 챌린지합니다.',
        '무릎 바로 위에 저항 밴드를 착용하고 밴드가 무릎을 안으로 당기는 힘을 이겨내며 정면 정렬을 사수하는 훈련을 실시합니다.',
        '바벨을 한쪽으로 치우쳐 지지한 상태(언밸런스 로딩)에서도 무릎 궤적이 흔들리지 않도록 제어 능력을 강화합니다.',
      ] },
      lunge: { isNormal: true, items: [
        '전방 런지 시 무릎이 발가락 방향과 정확히 일치하여 고관절과 발목 사이의 힘 전달 경로가 매우 효율적입니다.',
        '좌측과 우측 모두 무릎 정렬의 일관성이 우수하여 상체의 수직 중심선을 안정적으로 지지합니다.',
        '무릎의 측면 흔들림이 제어된 상태로 수행되어 슬관절 주변 조직의 불필요한 스트레스가 관찰되지 않습니다.',
      ], methods: [
        '뒷발을 벤치에 올린 상태(RFESS)에서 깊게 하강할 때 체중이 실린 앞쪽 무릎이 안팎으로 흔들리지 않는지 챌린지합니다.',
        '상체에 회전 부하를 주는 케이블이나 밴드를 잡고 런지를 수행하며 회전 저항 속에서도 무릎의 정면 정렬을 유지합니다.',
        '이동이 포함된 워킹 런지 시 착지 순간마다 무릎이 즉각적으로 수직 라인을 찾아가는 반응성 제어 능력을 향상시킵니다.',
      ] },
      plank: { isNormal: true, items: [
        '무릎이 완전히 펴진 상태에서 정면을 향해 나란히 배치되어 후면 사슬의 긴장도가 좌우 대칭적으로 형성됩니다.',
        '무릎의 내·외측 치우침 없이 하체의 중립 정렬이 유지되어 골반 수평을 지지하는 기초가 견고합니다.',
        '유지 시간 동안 무릎의 높이와 방향이 변하지 않고 일관된 정중앙 라인을 유지하는 능력이 확인됩니다.',
      ], methods: [
        '플랭크 상태에서 무릎을 가슴 쪽으로 당기는 마운틴 클라이머 동작 시 지지하는 쪽 무릎의 정렬이 무너지지 않도록 챌린지합니다.',
        '발 아래에 슬라이더를 두고 다리를 좌우로 벌렸다 모으는 동작 중에도 무릎의 중립 방향을 사수하도록 유도합니다.',
        '한 다리를 들고 플랭크를 수행하며 지면을 지지하는 무릎의 회전 안정성을 극한으로 끌어올립니다.',
      ] },
      curlUp: { isNormal: true, items: [
        '무릎 관절이 정면을 응시하며 양측 거리가 일정하게 유지되어 복부 수축 시 하체의 보상 작용이 관찰되지 않습니다.',
        '무릎 정렬의 안정성을 바탕으로 골반의 수평 축이 흔들림 없이 고정되어 복직근의 대칭적 수축에 기여합니다.',
        '반복적인 상체 굴곡에도 무릎이 안으로 모이거나 벌어지지 않고 안정적인 지지대 역할을 수행합니다.',
      ], methods: [
        '양 무릎 사이에 가벼운 볼을 끼워 내전근을 활성화한 상태에서 컬업을 수행하여 무릎 정렬과 코어의 협응력을 챌린지합니다.',
        '상체를 들어 올린 상태에서 다리를 교차하는 동작을 추가하여 하체의 동적 움직임 속에서도 무릎 방향을 통제하는 능력을 키웁니다.',
        '좁은 지면(폼롤러 등) 위에서 수행하며 무릎의 미세한 흔들림까지 제어하는 중립 정렬 유지력을 시험합니다.',
      ] },
      clam: { isNormal: true, items: [
        '준비 자세에서 양 무릎이 정확히 겹쳐져 있어 고관절 외회전 가동 범위를 측정하기에 최적화된 정렬입니다.',
        '동작 수행 시 무릎 관절의 각도가 일정하게 유지되어 타깃 근육인 둔근에 자극이 명확히 집중됩니다.',
        '무릎의 흔들림 없는 궤적을 통해 고관절 안정화 근육이 제 역할을 다하고 있음이 확인됩니다.',
      ], methods: [
        '저항 밴드를 착용하고 무릎을 벌릴 때 골반이 뒤로 밀리지 않도록 무릎의 정렬 유지력을 극한으로 챌린지합니다.',
        '사이드 플랭크 자세와 결합하여 아래쪽 무릎의 지면 지지력과 위쪽 무릎의 외회전 정렬을 동시에 사수합니다.',
        '최대 범위에서 멈춘 뒤 미세한 펄스(Pulse) 동작을 추가하여 정렬이 무너지지 않는 범위 내에서의 근지구력을 시험합니다.',
      ] },
      hamstring: { isNormal: true, items: [
        '무릎이 정면을 향해 곧게 펴져 있어 햄스트링 조직 전체를 편중 없이 신장시키기에 매우 유리한 상태입니다.',
        '스트레칭 중 무릎이 안으로 돌아가거나 굽혀지는 보상 패턴 없이 목표 근육에 이완 자극이 정확히 전달됩니다.',
        '무릎의 우수한 정렬 덕분에 하체 후면 사슬의 유연성을 정밀하게 평가하고 증진시킬 수 있습니다.',
      ], methods: [
        '무릎을 완전히 편 상태(Lock-out)를 유지하며 발등을 당겨 무릎 뒤쪽 오금 부위까지 포함된 후면 사슬 전체를 챌린지합니다.',
        '능동적으로 다리를 들어 올리는 동작을 통해 본인의 근력으로 무릎 정렬을 통제하며 유연성을 확보하도록 유도합니다.',
        '서서 하는 동적 스트레칭으로 전환하여 체중 이동 중에도 무릎이 굽혀지지 않고 정렬을 유지하는 능력을 챌린지합니다.',
      ] },
    },
    'knees:KNEE_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 엉덩이 벌림근 약화로 무릎이 안으로 모이며 무릎 안쪽에 부담이 커질 수 있습니다.',
        '발목의 엎침(Pronation)과 연동되어 아치가 무너지며 지면 지지력이 안쪽으로 과하게 쏠립니다.',
        '무릎의 내측 정렬 보상을 위해 허리가 과하게 꺾이거나 골반이 전방으로 기울어지기 쉽습니다.',
      ], methods: [
        '무릎 바깥쪽에 저항 밴드를 착용하여 엉덩이 근육이 무릎을 밖으로 밀어내도록 강제 활성화합니다.',
        '"발바닥으로 지면을 바깥으로 찢는 힘"을 주어 외측 사슬의 긴장도를 높이고 정렬을 바로잡습니다.',
        '무릎이 안으로 꺾이기 직전의 깊이까지만 하강하며 엉덩이 근육의 통제 범위를 점진적으로 늘립니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발 무릎이 수직 중심선 안으로 무너지며 발목 불안정성이 커지고 중심 잡기가 매우 어렵습니다.',
        '무릎 내측 쏠림으로 인해 대퇴사두근 내측광근에만 과도한 긴장이 발생하고 엉덩이 참여가 저하됩니다.',
        '하강 구간에서 무릎의 수직 정렬이 이탈함에 따라 특정 관절면에 비정상적인 부하가 집중되어 운동 효율을 저하시킬 수 있습니다.',
      ], methods: [
        '앞발의 엄지발볼 접지를 유지하면서도 무릎을 밖으로 밀어 정면 수직 궤적을 철저히 유지합니다.',
        '보폭을 평소보다 줄여 무릎 정렬을 통제하기 쉬운 환경을 만들고 엉덩이 안정성을 먼저 확보합니다.',
        '전문가가 직접 핸즈온으로 무릎 궤적을 고정해주어 뇌가 올바른 이동 경로를 학습하게 합니다.',
      ] },
      plank: { isNormal: false, items: [
        '무릎이 안으로 모인 상태는 하체 안쪽 사슬의 과긴장을 유발하여 골반의 전방 경사를 심화시킵니다.',
        '발목의 안정성이 떨어져 코어 근육이 척추를 지지하지 못하고 허리 뒤쪽 근육에만 긴장이 쏠립니다.',
        '유지 중 하중이 발 안쪽으로 쏠려 전신 장력이 고르게 분포되지 않고 상체 부하가 증가합니다.',
      ], methods: [
        '양발 뒤꿈치 사이에 소도구를 끼워 허벅지 안쪽과 하부 코어의 연결성을 높여 수평을 유지합니다.',
        '발바닥 바깥날에 의도적인 힘을 주어 하체 외측 사슬을 깨우고 양발 압력을 대칭으로 맞춥니다.',
        '정렬이 무너지기 전까지만 짧게 수행하여 허리 보상이 고착되지 않도록 조절합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 안쪽 모음 긴장이 골반의 중립을 방해하여 복부 수축 가동 범위를 물리적으로 제한합니다.',
        '상체를 들어 올릴 때 무릎이 서로 붙으려는 보상이 나타나 복부 근육의 집중도가 하체로 분산됩니다.',
        '하체 고정이 불안정하여 반복 후반부로 갈수록 호흡 리듬이 깨지고 목 주변 근육이 과활성됩니다.',
      ], methods: [
        '무릎 사이에 가벼운 볼을 끼우되 이를 통제하는 힘을 활용해 골반 정렬을 안정시킨 채 컬업합니다.',
        '발바닥 바깥쪽 압력을 높여 하체 정렬을 고정하고 복부 근육의 정방향 수축 인지력을 높입니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 품질 위주로 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '이미 엉덩이 벌림근이 약화된 상태라 동작 수행 시 골반이 뒤로 넘어가는 회전 보상이 극심합니다.',
        '엉덩이 대신 허리 근육이나 내전근을 과하게 끌어다 쓰는 비효율적인 수축 패턴이 관찰됩니다.',
        '순수 엉덩관절의 가쪽돌림 범위가 좁아져 있어 가동 범위 확보 자체가 어려운 경우가 많습니다.',
      ], methods: [
        '등 뒤에 벽을 밀착시켜 골반 회전을 차단하고 아주 작은 범위에서 엉덩이 자극을 찾는 데 집중합니다.',
        '무릎을 벌리는 속도보다 천천히 내리며 조절하는 구간의 통제력을 강화하여 신경을 깨웁니다.',
        '양쪽 수행 시 무릎 각도 차이를 확인하여 조절력이 떨어지는 쪽의 훈련 시간을 전략적으로 늘립니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '무릎이 안으로 모인 상태에서 늘리면 내측 햄스트링만 과하게 당겨져 전체 이완 효율이 떨어집니다.',
        '무릎 정렬 변위로 인해 스트레칭할 때 관절 안쪽으로 무게가 쏠려 부담을 느낄 수 있습니다.',
        '골반이 전방으로 기울어진 채 고정되어 햄스트링 시작점을 분리하여 늘리는 데 한계가 있습니다.',
      ], methods: [
        '무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별로 이완을 진행합니다.',
        '발바닥 아치를 살린 상태에서 스트레칭하여 무릎 내측 부하를 제거하고 타깃 근육만 늘립니다.',
        '가동 범위 확대보다 척추 정렬 유지를 우선하여 무리 없이 편안한 범위에서 진행합니다.',
      ] },
    },
    'knees:KNEE_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 무릎이 과하게 벌어지며 하중이 발 바깥날로 쏠리고 엉덩관절 집힘 현상이 나타날 수 있습니다.',
        '하체 외측의 과도한 긴장으로 인해 내전근과 골반저근의 협응 능력이 저하되어 중심이 불안정합니다.',
        '깊이가 깊어질수록 발 엄지발볼 지지력이 상실되며 골반이 뒤로 과하게 빠지는 보상이 동반됩니다.',
      ], methods: [
        '무릎 사이에 얇은 볼을 끼워 "허벅지 안쪽을 조이는 힘"을 인지시켜 내측 사슬의 긴장도를 높입니다.',
        '엄지발가락 쪽 접지력을 강조하여 외측으로 분산된 무게 중심을 발바닥 중앙으로 유도합니다.',
        '하강 시 무릎이 두 번째 발가락 라인을 유지하도록 외측 사슬의 과도한 벌림을 스스로 억제합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발 무릎이 바깥으로 벌어지며 발목 불안정성을 유발하고 엉덩이 근육의 이완성 수축이 제한됩니다.',
        '지면 지지력이 바깥으로 분산되어 수직 하강이 어렵고 골반이 한쪽으로 빠지는 보상이 나타납니다.',
        '무릎이 바깥으로 벌어진 상태로 운동을 반복하면 무게 중심이 무릎 바깥쪽으로 과하게 쏠리면서 관절 주변이 쉽게 피로해질 수 있습니다.',
      ], methods: [
        '뒷발의 정렬을 정면으로 엄격히 제한하여 무릎이 밖으로 돌아가는 회전 보상을 원천 차단합니다.',
        '앞발 엄지발볼을 지면에 밀착시키고 무릎이 발등 중심선 안에 머물도록 전문가가 실시간 교정합니다.',
        '보폭을 조절하여 하체 내측 근육들이 정렬을 보호할 수 있는 가동 범위 내에서만 수행합니다.',
      ] },
      plank: { isNormal: false, items: [
        '무릎이 벌어지는 정렬은 골반과 하체 코어의 연결성을 떨어뜨려 허리에 과도한 아치를 만들기 쉽습니다.',
        '하체 바깥쪽 근육들만 과하게 긴장하여 코어 중앙으로 힘이 모이지 않고 유지 중 골반이 흔들립니다.',
        '발 지지점이 불안정해지면서 어깨와 손목 관절에 과도한 체중 하중이 전가되는 현상이 나타납니다.',
      ], methods: [
        '양발 뒤꿈치를 나란히 모으고 허벅지 안쪽 근육을 서로 붙이는 느낌을 유지하여 전신 긴장도를 확보합니다.',
        '엄지발가락 쪽 압력을 높여 하부 사슬의 힘을 중앙으로 모으고 골반 수평 상태를 정밀 체크합니다.',
        '하체 정렬이 무너지기 전까지만 짧은 세트 위주로 수행하여 허리 주변의 보상 긴장을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '무릎이 벌어지면 골반이 전방으로 기울어지며 복부 근육의 수축 깊이가 방해받고 자극이 분산됩니다.',
        '하체 외측 사슬의 긴장으로 인해 복부 수축 시 골반 고정력이 약해져 목 근육의 과사용을 유발합니다.',
        '복부 운동 중에도 하체의 외회전 힘이 우세하게 작용하여 코어의 정중앙 집중력이 떨어집니다.',
      ], methods: [
        '무릎 사이에 가벼운 볼을 끼워 하체 정렬을 중립으로 고정하고 복부의 순수 굴곡 동작에 집중합니다.',
        '발 위치를 정면으로 정렬하고 하체의 외회전 힘을 억제한 상태에서 복압 유지 능력을 높입니다.',
        '반복 횟수보다 상체가 정면 수직 방향으로 일정하게 올라오는지 품질 기준으로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '이미 외회전근이 우세한 상태라 중둔근보다 겉 근육(넙다리근막긴장근 등)이 과하게 개입됩니다.',
        '무릎을 벌릴 때 골반이 뒤로 과하게 넘어가는 보상이 나타나 실제 엉덩이 자극 효율이 저하됩니다.',
        '이미 벌어진 범위에서 시작하게 되어 필요한 유효 가동 범위가 짧아지고 운동 감각 인지가 어렵습니다.',
      ], methods: [
        '아주 작은 범위에서부터 골반을 고정하는 법을 먼저 익히고 엉덩이 깊은 곳의 자극을 찾는 데 집중합니다.',
        '벌리는 속도보다 천천히 모으는 과정에서의 통제력을 강화하여 속근육의 조절 능력을 높입니다.',
        '골반 수직 축을 전문가가 물리적으로 고정해 주어 올바른 수축 궤적을 뇌에 학습시킵니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '무릎이 밖으로 돌아가려는 성질 때문에 스트레칭 시 외측 햄스트링만 과하게 자극될 수 있습니다.',
        '햄스트링보다 종아리 바깥쪽의 팽팽함이 먼저 느껴져 효율적인 대퇴 부위 이완을 방해합니다.',
        '골반이 이미 외회전된 채 고정되어 햄스트링 시작점을 분리하여 정직하게 늘리기 어렵습니다.',
      ], methods: [
        '발등과 무릎이 천장을 향하도록 수직 방향을 철저히 유지하여 내측 섬유까지 고르게 늘립니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지해 종아리 개입을 줄이고 순수 햄스트링 신장에 집중합니다.',
        '유연성 확보보다 골반의 수평 정렬 유지를 최우선으로 하여 안전한 스트레칭을 유도합니다.',
      ] },
    },
    'knees:KNEE_RIGHT': {
      squat: { isNormal: false, items: [
        '하강 시 체중이 왼쪽으로 치우치며 오른쪽 무릎은 안으로, 왼쪽 무릎은 밖으로 쏠리는 뒤틀림이 발생합니다.',
        '양쪽 무릎의 상반된 궤적으로 인해 하강 시 골반 수평이 깨지고 척추에 비대칭적 부하가 전달됩니다.',
        '일어나면서 몸이 한쪽으로 회전하려는 보상이 나타나 하중 분배가 5:5로 이루어지지 않습니다.',
      ], methods: [
        '오른쪽 무릎은 밖으로 미는 힘을, 왼쪽 허벅지는 안으로 조이는 힘을 동시에 인지하여 정렬을 맞춥니다.',
        '정렬이 깨지기 전까지만 하강하며 양발에 실리는 하중이 균등한지 실시간 피드백을 통해 교정합니다.',
        '상체가 한쪽으로 기우는지 거울로 점검하며 골반의 수평 이동 궤적을 정교하게 다듬는 훈련을 병행합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '앞발이 어느 쪽이냐에 따라 정렬 패턴이 완전히 달라져 신경계의 혼란과 조절력 저하가 관찰됩니다.',
        '오른쪽이 앞일 때 무릎이 안으로 무너지고, 왼쪽이 앞일 때 무릎이 밖으로 벌어지는 비대칭이 심화됩니다.',
        '양쪽 무릎의 방향이 서로 달라 운동할 때 한쪽 무릎이 다른 쪽보다 더 많은 무게를 짊어지게 됩니다.',
      ], methods: [
        '비대칭이 심한 쪽 다리 수행 시 전문가의 핸즈온을 통해 무릎 궤적을 강제로 수직화하여 인지력을 높입니다.',
        '각 방향의 정렬 특성에 맞춰 오른쪽은 밴드 저항을, 왼쪽은 내측 큐잉을 다르게 적용합니다.',
        '좌우 대칭성을 확보하기 위해 거울을 통한 시각 피드백으로 일정한 템포와 궤적을 유지합니다.',
      ] },
      plank: { isNormal: false, items: [
        '무릎의 엇갈린 정렬은 골반의 미세 회전을 유도하여 코어 근육이 뒤틀린 채 수축하는 비효율을 만듭니다.',
        '하체 하부 사슬의 장력 분포가 좌우가 다르게 형성되어 코어 유지 중 한쪽 허리에만 피로가 집중됩니다.',
        '발 지지점이 비대칭하여 골반 수평을 유지하기 위한 코어의 조절 능력이 한계를 드러내기 쉽습니다.',
      ], methods: [
        '양발 압력을 5:5로 맞추기 위해 정렬이 어긋난 쪽 발의 접지력을 의도적으로 수정하여 세팅합니다.',
        '골반 좌우 높이가 수평을 유지하는지 전문가가 정밀 체크하여 코어의 대칭 수축 품질을 확보합니다.',
        '짧은 시간 반복하더라도 골반 회전이 일어나기 전까지만 수행하여 보상 패턴의 고착을 방해합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 비대칭 정렬이 골반 회전을 유도하여 복부 수축 시 상체가 한쪽으로 기울어지는 수축이 발생합니다.',
        '골반 비틀림으로 인해 척추 분절 운동이 일정하지 않고 허리 뒤쪽 공간이 비대칭하게 형성됩니다.',
        '하체 고정이 불완전하여 상체를 말아 올릴 때 특정 방향 목 근육이 더 과하게 개입되는 경향이 있습니다.',
      ], methods: [
        '양발 지지력을 대칭으로 고정하고 상체가 정방향으로 올라오는지 품질 기준으로 세트를 진행합니다.',
        '복부 좌우 수축 압력이 균등하게 느껴지는지 실시간 피드백을 주어 편향된 근육 사용을 수정합니다.',
        '무릎 사이에 공을 끼워 양쪽 하체 정렬을 중립으로 강제 고정한 상태에서 컬업을 실시합니다.',
      ] },
      clam: { isNormal: false, items: [
        '오른쪽은 벌림근 강화가, 왼쪽은 외측 과긴장 억제가 필요한 상반된 환경이라 좌우 감각 차이가 큽니다.',
        '골반이 이미 한쪽으로 회전되어 있어 동작 수행 시 수직 축 유지가 어렵고 요추 주변의 긴장이 유도됩니다.',
        '양쪽 고관절의 수축 타이밍과 범위가 달라 한쪽은 자극이 오고 한쪽은 오지 않는 불균형이 나타납니다.',
      ], methods: [
        '오른쪽은 밴드 강도를 높여 약화된 벌림 힘을 깨우고, 왼쪽은 정밀한 조절 범위 내에서만 수행합니다.',
        '전문가가 골반 수평 축을 물리적으로 고정하여 좌우 대칭적인 수축 인지력을 회복하도록 돕습니다.',
        '수축 감각이 무딘 쪽의 훈련 시간을 전략적으로 늘려 양측 하체의 신경근 밸런스를 맞춥니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '좌우 무릎 궤적이 달라 스트레칭 시 한쪽은 내측 섬유가, 다른 한쪽은 외측 섬유가 편향되게 자극됩니다.',
        '골반 높이 차이로 인해 척추 중심축이 한쪽으로 기울어지며 허리 주변 근육에 비대칭적인 긴장이 전달됩니다.',
        '특정 근육 섬유만 과하게 당겨지고 나머지는 이완되지 않아 유연성 개선 속도가 좌우가 다르게 나타납니다.',
      ], methods: [
        '척추 중심선을 유지하며 양쪽 무릎이 정면을 보도록 개별적으로 정렬을 수정하여 이완을 진행합니다.',
        '각 무릎 패턴에 맞춰 발끝 방향을 세밀하게 조정하여 타깃 햄스트링 섬유가 정확히 늘어나게 유도합니다.',
        '스트레칭 후 동작 재평가를 통해 확보된 가동 범위가 움직임 품질을 개선했는지 즉각 확인합니다.',
      ] },
    },
    'knees:KNEE_LEFT': {
      squat: { isNormal: false, items: [
        '하강 시 무게 중심이 오른쪽으로 쏠리며 우측 무릎은 밖으로, 좌측 무릎은 안으로 휘어지는 뒤틀림이 발생합니다.',
        '비대칭 정렬로 오른쪽 엉덩관절 바깥쪽과 왼쪽 무릎 안쪽에 부담이 커질 수 있습니다.',
        '상승 시 골반이 오른쪽으로 회전하며 올라오는 보상이 나타나 좌우 하체 근력 사용의 불균형을 심화시킵니다.',
      ], methods: [
        '오른쪽 엄지발가락 접지를 강화하여 내측 정렬을 유도하고, 왼쪽 무릎은 밖으로 미는 힘을 주어 대칭을 맞춥니다.',
        '정렬이 어긋나기 직전의 깊이까지만 하강하며 양쪽 무릎이 각자의 두 번째 발가락 라인을 유지하게 조절합니다.',
        '상체의 중심선이 수직으로 일정하게 이동하는지 거울로 실시간 점검하며 하중 분배를 5:5로 가져갑니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 다리가 앞일 때 무릎이 안으로 휘청거리며 몸의 중심축이 무너질 수 있습니다. 이 경우 무게가 무릎 안쪽으로만 쏠려 관절 주변이 쉽게 피로해지고 운동의 안정성이 떨어지게 됩니다.',
        '오른쪽 다리가 앞일 때 무릎이 밖으로 벌어지며 뒤꿈치 지지력이 상실되고 엉덩이 근육 활성도가 저하됩니다.',
        '좌우 런지 수행 시 골반 수평 유지 능력이 달라 한쪽으로 몸이 기우는 불안정성이 명확히 관찰됩니다.',
      ], methods: [
        '왼쪽이 앞일 때는 무릎 바깥쪽에 저항을 주어 외측 힘을 깨우고, 오른쪽은 수직 궤적 유지에 집중합니다.',
        '보폭을 조절하여 양쪽 무릎이 각자의 정렬 변위에 따른 부하를 받지 않는 안전한 범위 내에서만 수행합니다.',
        '전문가가 무릎 궤적을 실시간으로 핸즈온 교정하여 뇌가 올바른 수직 이동 경로를 학습하게 가이드합니다.',
      ] },
      plank: { isNormal: false, items: [
        '하체 하부 사슬의 비대칭 장력 분포가 코어의 대칭 수축을 방해하여 한쪽 허리에만 긴장이 집중됩니다.',
        '오른쪽 발은 바깥날에, 왼쪽 발은 안쪽에 하중이 쏠려 전신 장력이 고르게 분포되지 않고 골반이 회전합니다.',
        '발 지지점의 불균형으로 인해 유지 중 어깨와 손목 관절에 비대칭적인 하중이 전가되는 현상이 나타납니다.',
      ], methods: [
        '양발의 압력을 대칭으로 맞추기 위해 정렬이 어긋난 발들의 접지 방향을 의도적으로 수정하여 세팅합니다.',
        '골반 좌우 높이가 수평을 이루는지 전문가가 정밀 체크하여 코어의 대칭적 수축 품질을 확보합니다.',
        '정렬 유지가 가능한 시간만큼만 짧은 세트로 반복하여 보상 패턴이 코어에 고착되지 않도록 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '하체의 비대칭 정렬이 골반 회전을 유도하여 복부 수축 시 상체가 오른쪽으로 미세하게 기우는 수축이 발생합니다.',
        '골반 비틀림으로 인해 허리 뒤쪽 공간이 비대칭하게 형성되어 척추 분절 운동의 질이 떨어지게 됩니다.',
        '하체 고정이 불완전하여 상체를 말아 올릴 때 특정 방향 목 근육이 더 과하게 개입되는 경향이 관찰됩니다.',
      ], methods: [
        '양발 지면 지지력을 대칭으로 고정하고 상체가 정면 수직 방향으로 올라오는지 품질 기준으로 세트를 진행합니다.',
        '무릎 사이에 볼을 끼워 양쪽 하체 정렬을 중립으로 강제 고정한 상태에서 복부 수축 인지력을 높입니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 실시간으로 체크하며 수행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '왼쪽은 벌림근 강화가, 오른쪽은 외측 과긴장 억제가 필요한 상반된 환경이라 좌우 감각 차이가 매우 큽니다.',
        '골반이 이미 한쪽으로 회전되어 있어 동작 수행 시 수직 축 유지가 어렵고 요추 주변의 보상 긴장이 유도됩니다.',
        '양쪽 고관절의 수축 타이밍과 범위가 달라 한쪽은 자극이 오고 한쪽은 오지 않는 신경근 불균형이 나타납니다.',
      ], methods: [
        '왼쪽은 밴드 저항을 높여 약화된 벌림 힘을 깨우고, 오른쪽은 정밀한 조절 범위 내에서만 고립 수축합니다.',
        '전문가가 골반 수평 축을 물리적으로 고정하여 좌우 대칭적인 수축 인지력을 회복하도록 돕습니다.',
        '감각이 무딘 쪽의 훈련 시간을 전략적으로 늘려 양측 엉덩이 근육의 신경근 밸런스를 맞추는 데 집중합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '좌우 무릎 궤적이 달라 스트레칭 시 한쪽은 외측 섬유가, 다른 한쪽은 내측 섬유가 편향되게 자극됩니다.',
        '골반 치우침이 척추의 측면 굽힘을 유도하여 스트레칭 도중 허리 부위의 불편감을 호소할 수 있습니다.',
        '특정 근육 섬유만 과하게 당겨지고 나머지는 이완되지 않아 유연성 개선 효과가 좌우 비대칭하게 나타납니다.',
      ], methods: [
        '척추 중심선을 유지하며 양쪽 무릎이 정면을 보도록 개별적으로 정렬을 수정하여 단계별로 이완합니다.',
        '각 무릎 패턴에 맞춰 발끝 방향을 세밀하게 조정하여 타깃 햄스트링 섬유가 정확히 늘어나게 유도합니다.',
        '스트레칭 후 동작 재평가를 통해 확보된 가동 범위가 움직임 품질을 실제로 개선했는지 즉각 확인합니다.',
      ] },
    },
    'knees:RIGHT_KNEE_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 오른쪽 무릎만 안으로 모이며 전체적인 무게 중심이 왼쪽으로 쏠리는 비대칭 하중 이동이 발생합니다.',
        '우측 하체의 지지력이 낮아 상승 시 골반 우측이 뒤로 빠지거나 흔들리는 조절력 저하 현상이 관찰됩니다.',
        '오른쪽 무릎이 안으로 살짝 기울어지면서 체중이 무릎 안쪽 면에만 과하게 쏠리고 있습니다. 이로 인해 하중이 골고루 나누어지지 못하고 오른쪽 관절 주변에만 피로가 집중되어 운동 효율이 낮아질 수 있습니다.',
      ], methods: [
        '오른쪽 무릎 바깥쪽에 저항 밴드를 착용하여 우측 엉덩이 근육이 정렬을 유지하도록 강제 활성화합니다.',
        '오른발 엄지발볼 접지를 유지하면서 아치를 세우는 인지 훈련을 통해 우측 하체 지지력을 복구합니다.',
        '양쪽 무릎이 대칭적으로 발등 라인을 따라 하강하는지 전문가의 정밀 핸즈온 가이드를 병행합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 다리가 앞일 때 무릎 흔들림이 심하며 엉덩이 근육보다 무릎 관절로 버티는 비효율적 패턴이 나타납니다.',
        '우측 무릎의 내측 쏠림으로 인해 골반이 왼쪽으로 밀려나며 상체 정렬까지 비틀리는 보상이 동반됩니다.',
        '좌우 런지 수행 시 우측의 안정성이 낮아 운동 품질의 심한 편차와 기술적 수행 능력의 차이가 보입니다.',
      ], methods: [
        '오른쪽이 앞일 때 가동 범위를 줄이더라도 무릎 궤적이 수직을 유지하는 고품질 반복에만 집중합니다.',
        '우측 뒤꿈치 접지를 강조하여 오른쪽 엉덩이 근육이 체중 부하를 견딜 수 있도록 실시간 큐잉합니다.',
        '전문가가 우측 무릎 궤적을 고정해주어 뇌가 올바른 수직 이동 경로를 정확히 기억하도록 가이드합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 발목과 무릎의 불안정성이 골반 우측의 전방 경사를 유도하여 코어 하부 정렬의 비대칭을 만듭니다.',
        '체중이 정상인 왼쪽 다리로 은근히 전가되면서 코어 근육이 한쪽으로 치우쳐 수축하는 현상이 나타납니다.',
        '유지 중 우측 하체 외측 사슬의 긴장도가 낮아 골반 수평을 유지하기 위한 조절 능력이 한계를 드러냅니다.',
      ], methods: [
        '우측 발날의 접지력을 높여 하체 외측을 깨우고 양발 압력이 대칭을 이루도록 의도적으로 수정합니다.',
        '골반 우측이 아래로 처지지 않는지 실시간 피드백을 주어 코어의 대칭 수축 품질을 유지하도록 유도합니다.',
        '정렬이 완벽한 상태에서만 수행하도록 짧은 세트 위주로 구성하여 우측의 보상 패턴 고착을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체의 안쪽 모임 긴장이 복부 수축 시 골반 우측 회전을 유도해 복사근 사용의 좌우 편차를 만듭니다.',
        '오른쪽 엉덩굽힘근의 과도한 개입으로 인해 컬업 시 골반 우측이 들썩이는 불안정성이 발생하기 쉽습니다.',
        '우측 지지력 부족이 상체 굴곡 궤적을 미세하게 비틀어 왼쪽 목 근육의 보상적 긴장을 유발할 수 있습니다.',
      ], methods: [
        '오른발바닥 전체의 지면 지지력을 확인하고 골반 수평 상태에서만 상체를 정면으로 말아 올립니다.',
        '무릎 사이에 볼을 끼워 우측 하체 정렬을 고정하고 우측 복부의 정방향 수축 인지력을 높이는 훈련을 합니다.',
        '반복 횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 품질 위주로 체크합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 근육 활성도가 정상인 왼쪽보다 낮아 클램 수행 시 골반이 뒤로 넘어가는 보상이 극심합니다.',
        '우측 엉덩이 대신 허리 근육이나 내전근을 끌어다 쓰는 비효율적인 수축 패턴이 우측에서만 관찰됩니다.',
        '좌우 수축 감각 차이가 커서 회원이 우측의 정확한 자극 지점을 인지하는 데 어려움을 겪게 됩니다.',
      ], methods: [
        '우측 수행 시 전문가가 골반을 직접 고정하고 아주 작은 범위에서 엉덩이 신경을 깨우는 데만 집중합니다.',
        '속도를 절반 이하로 낮춰 뇌가 우측 엉덩이 근육 수축을 정밀하게 제어할 수 있도록 가이드합니다.',
        '우측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 왼쪽 수준으로 끌어올립니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 햄스트링 내측 조직의 높은 긴장도로 인해 스트레칭 시 무릎 관절에 회전 부하가 가중됩니다.',
        '오른쪽 골반의 전방 경사 성향 때문에 순수 햄스트링 이완보다 허리 척추의 보상이 먼저 일어나게 됩니다.',
        '우측 스트레칭 시 나타나는 무릎 내측의 정렬 편차가 효율적인 근육 이완을 방해하는 요소로 작용하게 됩니다.',
      ], methods: [
        '우측 무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별로 이완을 진행합니다.',
        '오른발 아치를 살린 상태에서 스트레칭하여 무릎 내측 부하를 제거하고 타깃 근육만 정교하게 늘립니다.',
        '스트레칭 전후 가동 범위를 비교하여 회원이 우측의 개선 효과를 직접 체감하도록 유도합니다.',
      ] },
    },
    'knees:RIGHT_KNEE_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 오른쪽 무릎만 밖으로 벌어지며 하중이 발 바깥날로 쏠리고 우측 고관절 외측에 압박이 집중됩니다.',
        '우측 하중 지지가 외측으로 분산되어 상승 시 힘의 효율이 떨어지고 골반이 한쪽으로 비틀리게 됩니다.',
        '좌우 무릎 궤적의 비대칭으로 인해 골반 수평이 깨지며 척추에 불필요한 측면 하중이 전달됩니다.',
      ], methods: [
        '오른쪽 엄지발가락 접지력을 강화하여 지면 반발력을 중앙으로 모으고 발목과 무릎의 안정성을 높입니다.',
        '오른쪽 내전근을 사용하는 감각을 깨워 무릎이 과하게 벌어지는 외측 쏠림 현상을 스스로 억제하게 합니다.',
        '하강 시 우측 무릎이 왼쪽 무릎의 정상 궤적과 대칭을 이루는지 전문가의 실시간 피드백을 받습니다.',
      ] },
      lunge: { isNormal: false, items: [
        '오른쪽 다리가 앞일 때 무릎이 바깥으로 흔들리며 발바닥 전체 접지가 상실되어 중심 유지가 불안정합니다.',
        '우측 무릎의 외측 벌림으로 인해 골반이 오른쪽으로 빠지며 엉덩이 근육의 이완성 수축이 제한됩니다.',
        '좌우 수행 시 우측의 가용 범위가 짧아지거나 정렬이 깨지는 등 운동 품질의 편차가 명확히 나타납니다.',
      ], methods: [
        '우측 수행 시 보폭을 정밀하게 조절하고 뒤꿈치 접지 감각을 강조하여 수직 지지력을 확보합니다.',
        '오른쪽 무릎이 밖으로 벌어지지 않게 전문가가 핸즈온 고정하여 엉덩이 근육이 하중을 견디게 유도합니다.',
        '정렬 유지가 가능한 범위 내에서만 하강 깊이를 설정하여 올바른 이동 궤적 학습에만 최우선 집중합니다.',
      ] },
      plank: { isNormal: false, items: [
        '우측 하체 외측 사슬의 과긴장이 골반 우측을 당겨 코어 중앙의 긴장 균형을 방해하게 됩니다.',
        '체중이 우측 어깨나 허리로 편중되어 전달되면서 유지 중 비대칭적인 피로도 상승이나 불균형한 긴장 상태를 유발할 수 있습니다.',
        '우측 발의 지지점이 불안정해 골반 수평을 유지하기 위한 코어의 조절 능력이 한계를 드러냅니다.',
      ], methods: [
        '오른발을 정면으로 정확히 고정하고 엄지발가락 쪽 압력을 높여 전신 장력을 대칭으로 맞춥니다.',
        '골반 우측 높이가 왼쪽과 수평을 유지하는지 수시로 점검하여 코어의 대칭 수축 품질을 확보합니다.',
        '우측 정렬이 무너지기 전까지만 짧은 세트로 수행하여 외측 사슬의 보상 패턴 고착을 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '우측 하체의 외측 긴장도가 골반 우측 전방 경사를 유도하여 우측 복부의 수축 깊이를 제한합니다.',
        '오른쪽 발 벌림으로 인해 복부 수축 시 골반 고정력이 약해져 우측 어깨나 목 근육의 과사용을 만듭니다.',
        '하체 지지력의 비대칭이 상체 말기 동작의 궤적을 비틀어 복사근의 불균형한 사용을 유발하게 됩니다.',
      ], methods: [
        '오른발 위치를 정면으로 정렬하고 하체 힘을 뺀 상태에서 복부 근육의 순수 굴곡 동작에만 집중합니다.',
        '무릎 사이에 볼을 끼워 우측 하체 정렬을 안정시키면 골반 흔들림을 막아 복부 타격감을 높일 수 있습니다.',
        '반복 횟수보다 상체가 정면 수직 방향으로 일정하게 올라오는지 품질 기준으로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '우측 엉덩이 외측 근육이 이미 단축된 상태라 순수 중둔근 수축보다 겉 근육의 개입이 매우 빠르게 나타납니다.',
        '오른쪽 무릎을 벌릴 때 골반이 뒤로 과하게 회전하는 보상이 나타나 엉덩이 근육의 이완을 방해합니다.',
        '이미 벌어진 범위에서 시작하게 되어 실제 필요한 유효 가동 범위가 짧아 운동 효율이 크게 떨어집니다.',
      ], methods: [
        '우측 수행 시 골반 수평을 물리적으로 고정하고 아주 작은 범위에서 엉덩이 깊은 자극을 찾도록 유도합니다.',
        '속도를 절반 이하로 낮춰 뇌가 우측 엉덩이 근육의 미세한 조절을 인지하도록 정밀하게 가이드합니다.',
        '우측 조절 능력이 정상인 왼쪽과 대칭을 이룰 때까지 정확한 자극 위주의 고립 훈련을 반복 실시합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '우측 발 벌림 정렬로 인해 스트레칭 시 햄스트링 외측 섬유만 과하게 자극되어 이완 효율이 반감됩니다.',
        '우측 햄스트링보다 종아리 바깥쪽의 팽팽함이 먼저 느껴져 효율적인 대퇴 부위 이완을 방해하게 됩니다.',
        '우측 골반이 외회전된 채 고정되어 햄스트링 시작점을 분리하여 정교하게 늘리는 데 한계가 있습니다.',
      ], methods: [
        '오른발을 정면으로 정확히 정렬하고 무릎 궤적을 일치시킨 상태에서 단계별로 이완을 진행합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지하여 종아리 개입을 줄이고 순수 햄스트링 신장에만 집중합니다.',
        '가동 범위의 확장보다 골반 수평 정렬 유지를 최우선으로 하여 관절면에 가해지는 불필요한 부담을 최소화합니다.',
      ] },
    },
    'knees:LEFT_KNEE_INWARD': {
      squat: { isNormal: false, items: [
        '하강 시 왼쪽 무릎만 안으로 주저앉으며 상체가 오른쪽으로 기우는 비대칭 하중 이동이 발생합니다.',
        '왼쪽 발목의 불안정성이 상위 관절인 무릎의 무너짐을 유도하여 하체 좌우 근력 차이를 만듭니다.',
        '상승 시 왼쪽 엉덩이 근육이 힘을 쓰지 못해 골반이 왼쪽으로 빠지는 회전 보상이 관찰됩니다.',
      ], methods: [
        '왼쪽 무릎 바깥쪽에 저항 밴드를 활용하여 좌측 엉덩이 외회전근의 신경을 강제로 활성화합니다.',
        '왼쪽 발바닥 삼점 접지를 강조하여 좌측 하체의 지면 지지력을 정상인 오른쪽 수준으로 회복시킵니다.',
        '무릎이 안으로 꺾이기 직전의 가동 범위까지만 하강하며 좌측 엉덩이의 통제 능력을 점진적으로 늘립니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 다리가 앞일 때 하중 지지가 불안정하여 골반 수평 정렬이 이탈되고 이로 인해 무릎 내측 관절면의 부하가 가중되어 움직임의 안정성이 저하될 수 있습니다.',
        '좌측 무릎의 흔들림으로 인해 대퇴사두근에만 부하가 쏠리고 엉덩이 근육의 참여도가 현저히 저하됩니다.',
        '좌우 수행 시 좌측의 안정 능력이 낮아 운동 수행의 질적 차이가 육안으로 명확히 관찰됩니다.',
      ], methods: [
        '좌측 수행 시 거울을 통한 시각적 피드백으로 무릎 수직 궤적을 정밀하게 교정하며 하강합니다.',
        '좌측 뒤꿈치의 지면 접지력을 높여 왼쪽 엉덩관절 주변 근육이 하중을 효과적으로 지지하도록 실시간 움직임 가이드를 제공합니다.',
        '코치가 직접 좌측 무릎의 정렬을 보조하여 올바른 수직 이동 경로를 몸이 스스로 인지하고 숙달하도록 돕습니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 발목과 무릎의 정렬 변위가 골반 좌측의 불균형을 유도하여 코어 하부의 비대칭을 만듭니다.',
        '체중이 정상인 오른쪽 발로 은근히 전가되면서 코어 근육이 한쪽으로 치우쳐 수축하는 현상이 나타납니다.',
        '유지 중 좌측 하체 외측 사슬의 긴장도가 낮아 골반 수평을 유지하기 위한 조절 능력이 약화됩니다.',
      ], methods: [
        '좌측 발날의 접지력을 높여 하체 외측을 깨우고 양발 압력이 대칭을 이루도록 의도적으로 수정합니다.',
        '골반 좌측이 아래로 처지지 않는지 실시간 피드백을 주어 코어의 대칭 수축 품질을 유지하게 합니다.',
        '정렬이 100%인 상태에서만 수행하도록 짧은 세트 위주로 구성하여 좌측 보상 패턴의 고착을 막습니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체의 안쪽 모임 긴장이 복부 수축 시 골반 좌측 회전을 유도해 복사근 사용의 좌우 편차를 만듭니다.',
        '왼쪽 엉덩굽힘근의 과도한 개입으로 인해 컬업 시 골반 좌측이 들썩이는 불안정성이 발생하게 됩니다.',
        '좌측 지지력 부족이 상체 굴곡 궤적을 미세하게 비틀어 오른쪽 목 근육의 과도한 긴장을 유발할 수 있습니다.',
      ], methods: [
        '왼발바닥 전체의 지면 지지력을 확인하고 골반 수평 상태에서만 상체를 정면으로 말아 올립니다.',
        '무릎 사이에 볼을 끼워 좌측 하체 정렬을 고정하고 좌측 복부의 정방향 수축 인지력을 높이는 훈련을 합니다.',
        '횟수보다 상체가 올라올 때 양쪽 견갑골이 동시에 지면에서 떨어지는지 품질 위주로 체크하며 실시합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 근육 활성도가 정상인 오른쪽보다 낮아 클램 수행 시 골반이 뒤로 넘어가는 보상이 심합니다.',
        '왼쪽 엉덩이 대신 허리 근육이나 내전근을 끌어다 쓰는 비효율적인 수축 패턴이 좌측에서 관찰됩니다.',
        '좌우 수축 감각 차이가 커서 회원이 좌측의 정확한 자극 지점을 인지하는 데 상당한 어려움을 겪습니다.',
      ], methods: [
        '좌측 수행 시 전문가가 골반을 직접 고정하고 아주 작은 범위에서 엉덩이 신경을 깨우는 데 집중합니다.',
        '속도를 절반 이하로 낮춰 뇌가 좌측 엉덩이 근육 수축을 정밀하게 제어할 수 있도록 세심하게 가이드합니다.',
        '좌측 수행 횟수나 집중도를 높여 양측 엉덩이의 신경근 밸런스를 오른쪽 수준으로 회복시킵니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼쪽 햄스트링 내측 조직의 높은 긴장도로 인해 스트레칭 시 무릎 관절에 회전 부하가 가중될 수 있습니다.',
        '왼쪽 골반의 전방 경사 성향 때문에 순수 햄스트링 이완보다 허리 척추의 보상이 먼저 일어납니다.',
        '좌측 스트레칭 시 나타나는 무릎 내측의 불편함이 효율적인 근육 이완과 가동 범위 확보를 방해합니다.',
      ], methods: [
        '좌측 무릎과 발등이 정면 수직을 유지하도록 철저히 통제한 상태에서 단계별로 이완을 진행합니다.',
        '왼쪽 발바닥의 아치를 유지한 상태로 스트레칭하여 무릎 내측에 쏠리는 하중을 분산시키고 타깃 근육만 집중적으로 이완합니다.',
        '스트레칭 전후 가동 범위를 비교하여 회원이 좌측의 개선 효과를 직접 확인하도록 유도합니다.',
      ] },
    },
    'knees:LEFT_KNEE_OUTWARD': {
      squat: { isNormal: false, items: [
        '하강 시 왼쪽 무릎이 중심축을 벗어나 바깥쪽으로 향하면서 체중이 왼쪽 발목과 골반 외측으로 편중되어 전달되는 현상이 나타납니다.',
        '좌측의 외측 긴장이 골반을 왼쪽으로 미세하게 잡아당겨 전체적인 척추 정렬의 비대칭을 심화시킵니다.',
        '상승 시 왼쪽 지면 반발력이 중앙으로 모이지 않고 분산되어 좌우 하체 힘 전달의 균형이 무너집니다.',
      ], methods: [
        '왼쪽 발 안쪽 발볼에 체중을 더 싣도록 유도하여 외측으로 쏠린 하중을 발바닥 중앙으로 모읍니다.',
        '왼쪽 내전근을 사용하는 감각을 깨워 무릎이 과하게 밖으로 나가는 현상을 스스로 억제하게 큐잉합니다.',
        '양쪽 무릎이 대칭적으로 벌어지는지 확인하며 좌측 무릎이 우측의 정상 범위를 넘지 않게 조절합니다.',
      ] },
      lunge: { isNormal: false, items: [
        '왼쪽 다리가 앞일 때 무릎이 바깥으로 흔들리며 발바닥 전체 접지가 상실되어 중심 유지가 불안정해집니다.',
        '좌측 무릎의 외측 벌림으로 인해 골반이 왼쪽으로 빠지며 엉덩이 근육의 효율적인 수축이 제한됩니다.',
        '좌우 수행 시 좌측의 안정 능력이 낮아 가동 범위가 짧아지거나 정렬이 흔들리는 편차가 관찰됩니다.',
      ], methods: [
        '좌측 수행 시 보폭을 정밀하게 조절하고 뒤꿈치 접지 감각을 강조하여 수직 지지력을 확보합니다.',
        '왼쪽 무릎이 밖으로 벌어지지 않게 전문가가 핸즈온 고정하여 엉덩이 근육이 하중을 견디게 유도합니다.',
        '정렬 유지가 가능한 범위 내에서만 하강 깊이를 설정하여 올바른 이동 궤적을 뇌에 학습시키는 데 집중합니다.',
      ] },
      plank: { isNormal: false, items: [
        '좌측 하체 외측 사슬의 과긴장이 골반 좌측을 당겨 코어 중앙의 긴장 유지 능력을 저하시킵니다.',
        '체중이 좌측 어깨나 허리로 은근히 전가되면서 유지 중 비대칭적인 피로감이나 불편감이 발생할 수 있습니다.',
        '좌측 발의 지지점이 불안정해 골반 수평을 유지하기 위한 코어의 정밀 조절 능력이 한계를 보입니다.',
      ], methods: [
        '왼발을 정면으로 정확히 고정하고 엄지발가락 쪽 압력을 높여 전신 장력을 대칭으로 맞추려 노력합니다.',
        '골반 좌측 높이가 오른쪽과 수평을 유지하는지 수시로 점검하여 코어의 대칭 수축 품질을 확보합니다.',
        '좌측 정렬이 무너지기 전까지만 짧은 세트로 수행하여 외측 사슬의 보상 패턴 고착을 원천 차단합니다.',
      ] },
      curlUp: { isNormal: false, items: [
        '좌측 하체의 외측 긴장도가 골반 좌측 전방 경사를 유도하여 좌측 복부의 수축 가동 범위를 제한합니다.',
        '왼발의 바깥 벌림으로 인해 복부 수축 시 골반 고정력이 약해져 좌측 어깨나 목 근육의 과사용을 만듭니다.',
        '하체 지지력의 비대칭이 상체 말기 동작의 궤적을 비틀어 복사근의 불균형한 사용을 가속화하게 됩니다.',
      ], methods: [
        '왼발 위치를 정면으로 정렬하고 하체 힘을 뺀 상태에서 복부 근육의 순수 굴곡 동작에만 집중합니다.',
        '무릎 사이에 볼을 끼워 좌측 하체 정렬을 안정시키면 골반 흔들림을 막아 복부 자극을 극대화할 수 있습니다.',
        '반복 횟수보다 상체가 정면 수직 방향으로 일정하게 올라오는지 품질 기준으로 세트를 진행합니다.',
      ] },
      clam: { isNormal: false, items: [
        '좌측 엉덩이 외측 조직의 유연성이 저하된 상태로 타깃인 중둔근의 수축보다 표층 근육의 개입이 앞당겨지는 동원 순서의 불균형이 관찰됩니다.',
        '왼쪽 무릎을 벌릴 때 골반이 뒤로 과하게 회전하는 보상이 나타나 엉덩이 근육의 이완을 방해하게 됩니다.',
        '이미 벌어진 범위에서 시작하게 되어 실제 필요한 유효 가동 범위가 짧아지고 운동 효율이 낮아집니다.',
      ], methods: [
        '좌측 수행 시 골반 수평을 물리적으로 고정하고 아주 작은 범위에서 엉덩이 깊은 자극을 찾는 데 집중합니다.',
        '속도를 절반 이하로 낮춰 뇌가 좌측 엉덩이 근육의 미세한 조절을 인지하도록 정밀하게 가이드합니다.',
        '좌측 조절 능력이 정상인 오른쪽과 대칭을 이룰 때까지 정확한 자극 위주의 고립 훈련을 지속합니다.',
      ] },
      hamstring: { isNormal: false, items: [
        '왼발의 벌림 정렬로 인해 스트레칭 시 햄스트링 외측 섬유만 과하게 자극되어 이완 품질이 떨어집니다.',
        '좌측 햄스트링보다 종아리 바깥쪽의 팽팽함이 먼저 느껴져 효율적인 대퇴 부위 이완을 방해하게 됩니다.',
        '좌측 골반이 외회전된 채 고정되어 햄스트링 시작점을 분리하여 정직하게 늘리는 데 한계가 있습니다.',
      ], methods: [
        '왼발을 정면으로 정확히 정렬하고 무릎 궤적을 일치시킨 상태에서 단계별로 이완을 진행합니다.',
        '뒤꿈치를 몸쪽으로 당기는 힘을 유지하여 종아리 개입을 줄이고 순수 햄스트링 신장에만 집중합니다.',
        '가동 범위의 확장보다 골반 수평 정렬 유지를 최우선으로 하여 관절면에 가해지는 불필요한 부담을 최소화하는 안전한 스트레칭을 지향합니다.',
      ] },
    },
  };

export const FRONT_PATTERN_DB: Record<string, {
    stateAnalysis: string[];
    movementPatternAnalysis: string[];
    optimizationStrategy: string[];
  }> = {
    // ── 골반 중심 상태 ────────────────────────────────────────────
    'hipCenter:HIP_NOT_CENTER_RIGHT': {
      stateAnalysis: ['정면 기준에서 골반이 양발 중심선보다 오른쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '왼쪽 하체(발목·무릎·엉덩관절)의 가동성 또는 지지 효율 저하와 연관된 패턴 관찰됨',
        '→오른쪽 다리로 무게중심이 이동하며 골반 위치 변화가 동반됨',
        '→오른쪽 하체 사용 비중이 증가하고 왼쪽 하체의 체중 지지 참여가 지연되는 하체 조절 패턴이 나타남',
      ],
      optimizationStrategy: [
        '왼쪽 발바닥 전체로 지면을 강하게 밀어내며 체중을 5:5로 분배하는 연습이 필요합니다.',
        '골반이 오른쪽으로 이동하기 직전까지만 내려가는 \'부분 반복\'으로 하강 패턴을 먼저 안정화합니다.',
        '거울로 상체·골반이 한쪽으로 기울지 않도록 수직 정렬을 유지합니다.',
        '하체의 전체적인 협응력을 높이기 위해 왼쪽 다리에 체중이 실리는 감각을 확인하며 천천히 동작을 수행합니다.',
      ],
    },
    'hipCenter:HIP_NOT_CENTER_LEFT': {
      stateAnalysis: ['정면 기준에서 골반이 양발 중심선보다 왼쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '가동성 또는 지지 효율 저하와 연관된 패턴 관찰오른쪽 하체(발목·무릎·엉덩관절)의 됨',
        '→왼쪽 다리로 무게중심 이동과 골반 치우침이 동반됨',
        '→왼쪽 하체 사용 비중이 증가하며 오른쪽 하체의 지지 타이밍이 늦어지는 조절 패턴이 나타남',
      ],
      optimizationStrategy: [
        '오른쪽 발바닥 전체로 지면을 강하게 밀어내며 체중을 5:5로 분배하는 연습이 필요합니다.',
        '골반이 왼쪽으로 이동하기 직전까지만 내려가는 \'부분 반복\'으로 정렬을 먼저 고정합니다.',
        '거울로 상체·골반이 한쪽으로 밀리지 않는지 확인하며 내려갑니다.',
        '오른쪽 하체에 실리는 체중 감각을 유지한 범위에서 가동 범위를 점진적으로 늘립니다.',
      ],
    },
    'hipCenter:NORMAL': {
      stateAnalysis: ['정면 기준에서 골반 중심이 양발 사이 중심선에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '양쪽 하체(발목, 무릎, 엉덩관절)의 가동성과 안정성이 균형을 이루는 양상이 관찰됨',
        '→특정 부위의 회피 없이 신체 중심선(Midline)을 유지하며 수직 하강',
        '→체중이 좌·우 5:5로 고르게 분산되는 패턴을 보임',
      ],
      optimizationStrategy: [
        '지금처럼 양발에 체중을 5:5로 고르게 실어주는 감각을 유지합니다.',
        '무릎의 모임·벌어짐과 발목의 무너짐이 동반되지 않는지 추가로 확인합니다.',
        '기본 정렬이 안정적이면 덤벨·바벨로 점진적 부하 증가(Loading)를 적용할 수 있습니다.',
        '불안정한 지면이나 템포 조절로 난이도를 올려도 정렬이 유지되는지 점검합니다.',
      ],
    },
    // ── 발 방향 정렬 ─────────────────────────────────────────────
    'foot:NORMAL': {
      stateAnalysis: ['정면 기준에서 양발의 방향이 중립 위치에 있습니다.'],
      movementPatternAnalysis: [
        '양측 발목이 중립 정렬을 유지함',
        '→발바닥의 삼점 지지 기반이 안정적으로 형성된 상태가 관찰됨',
        '→지면 반력이 효율적으로 전달될 조건이 확보된 발 정렬 패턴이 나타남',
        '→상위 관절(무릎·엉덩관절)의 정렬 및 움직임 평가는 추가 관찰이 필요한 상태',
      ],
      optimizationStrategy: [
        '지금처럼 발 정면 정렬과 체중 5:5 분배 감각을 유지합니다.',
        '삼점 지지가 흐트러지지 않도록 발바닥 전체로 지면을 고르게 누르며 내려갑니다.',
        '거울로 무릎·골반이 한쪽으로 치우치지 않는지 함께 점검합니다.',
        '정렬이 유지되는 범위에서 덤벨·바벨 부하(Loading)나 템포 조절로 단계적으로 난이도를 올립니다.',
      ],
    },
    'foot:FOOT_OUTWARD': {
      stateAnalysis: ['정면 기준에서 양발이 바깥쪽을 향해 있습니다.(양발 벌림)'],
      movementPatternAnalysis: [
        '양측 발이 바깥 방향으로 향하는 정렬 패턴이 관찰됨',
        '→하강 과정에서 발목 움직임 범위 또는 안정성 부족을 보완하려는 전략이 동반됨',
        '→발바닥 아치가 낮아지는 경향과 함께 무릎 정렬 변화가 나타남',
        '→그 결과 무릎 안쪽 구조에 부담이 집중되는 사용 양상이 관찰됨',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도를 조절하고, 정렬 변화가 발목 움직임 범위와 연관되는지 확인하는 데 도움이 됩니다.',
        '뒤꿈치로 바닥을 지그시 누르며 무릎과 두 번째 발가락 방향을 나란히 유지합니다.',
        '발이 바깥으로 미끄러지지 않게 바닥을 가볍게 움켜쥐는 느낌으로 발바닥 아치를 살립니다.',
        '정렬이 유지되는 범위에서 반복 횟수→깊이→부하(덤벨·바벨) 순으로 단계적으로 난이도를 올립니다.',
      ],
    },
    'foot:FOOT_INWARD': {
      stateAnalysis: ['정면 기준에서 양발이 안쪽을 향해 있습니다.(양발 모음)'],
      movementPatternAnalysis: [
        '양측 발목이 안쪽으로 향하는 정렬 패턴이 관찰됨',
        '→지지 기반이 좁아지며 무릎 안쪽 모임과 연관된 양상이 동반됨',
        '→하강 과정에서 하체 정렬 안정성을 유지하기 위한 보상적 조절 전략이 나타남',
        '→발–무릎–엉덩관절 연결선 상에서 하중 분산 효율이 저하되는 경향이 시사됨',
      ],
      optimizationStrategy: [
        '발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려갑니다.',
        '이때 무릎이 두 번째 발가락 방향보다 안으로 들어오지 않게 바깥으로 벌리는 힘을 유지하여 엉덩이 근육의 참여를 유도합니다.',
        '동작이 어렵다면 탄력 밴드를 무릎 아래에 두고 밀어내는 느낌을 유지하며 시도합니다.',
        '발바닥 아치가 무너지거나 발끝이 안으로 돌아가기 직전까지만 내려가는 \'부분 반복\'을 통해 바른 정렬 감각을 먼저 익히고, 뒤꿈치에 낮은 받침을 활용해 점진적으로 깊게 앉는 연습을 병행합니다.',
      ],
    },
    'foot:FOOT_RIGHT': {
      stateAnalysis: ['정면 기준에서 발 방향이 우측으로 치우쳐 있습니다.(오른쪽 발 벌림 / 왼쪽 발 모음)'],
      movementPatternAnalysis: [
        '오른쪽 발목 벌림, 왼쪽 발목 모음 정렬 패턴이 관찰됨',
        '→좌우 발 방향 기준선이 일치하지 않으며 하체 정렬의 비대칭이 형성됨',
        '→하강 과정에서 오른쪽 하체 지지 비중이 상대적으로 증가하고 왼쪽 하체의 안정적 참여가 감소함',
        '→그 결과 하체 사용 전략이 좌우로 분리된 비대칭 패턴으로 나타남',
      ],
      optimizationStrategy: [
        '양쪽 발의 체중을 5:5로 똑같이 실어주는 연습을 합니다.',
        '이때 "오른쪽 발은 안쪽으로, 왼쪽 발은 바깥쪽으로 비트는 힘을 주어 양발이 나란하도록 유지한다"는 느낌으로 동작을 수행합니다.',
        '비대칭이 심하다면 뒤꿈치에 낮은 받침대를 두고 연습하여 발목의 움직임 제한을 먼저 해소합니다.',
        '골반이 오른쪽으로 돌아가기 전까지만 내려가는 \'부분 반복\'을 통해, 몸의 정면을 유지하며 앉는 바른 정렬 감각을 익히는 것을 최우선으로 합니다.',
      ],
    },
    'foot:FOOT_LEFT': {
      stateAnalysis: ['정면 기준에서 발 방향이 좌측으로 치우쳐 있습니다.(오른쪽 발 모음 / 왼쪽 발 벌림)'],
      movementPatternAnalysis: [
        '오른쪽 발목 모음, 왼쪽 발목 벌림 정렬 패턴이 관찰됨',
        '→양발 방향 기준선이 일치하지 않으며 좌우 하체 정렬의 비대칭이 형성됨',
        '→하강 과정에서 왼쪽 하체 지지 비중이 증가하고 오른쪽 하체의 조절 부담이 동반됨',
        '→하체 사용 전략이 좌우로 분리된 비대칭 패턴으로 나타남',
      ],
      optimizationStrategy: [
        '양쪽 발의 체중을 5:5로 똑같이 실어주는 연습을 합니다.',
        '이때 "왼쪽 발은 안쪽으로, 오른쪽 발은 바깥쪽으로 비트는 힘을 주어 양발이 나란하도록 유지한다"는 느낌으로 동작을 수행합니다.',
        '비대칭이 심하다면 뒤꿈치에 낮은 받침대를 두고 연습하여 발목의 움직임 제한을 먼저 해소합니다.',
        '골반이 왼쪽으로 돌아가기 전까지만 내려가는 \'부분 반복\'을 통해, 몸의 정면을 유지하며 앉는 바른 정렬 감각을 익히는 것을 최우선으로 합니다.',
      ],
    },
    'foot:RIGHT_FOOT_INWARD': {
      stateAnalysis: ['좌측 발은 중립 위치에 있으며, 우측 발만 안쪽을 향해 있습니다.(오른발 모음/왼발 중립 정렬)'],
      movementPatternAnalysis: [
        '오른쪽 발목 모음 정렬 패턴이 관찰됨',
        '→오른쪽 발의 지지 기반이 신체 중심선 쪽으로 치우치는 양상 나타남',
        '→오른쪽 무릎의 안쪽 이동과 연관된 정렬 변화가 동반됨',
        '→오른쪽 하체 정렬 안정성이 감소하는 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '오른쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려갑니다.',
        '"오른쪽 무릎이 두 번째 발가락 방향보다 안으로 들어오지 않게 바깥으로 벌린다"는 느낌에 집중하여 엉덩이 근육의 참여를 유도합니다.',
        '동작이 어렵다면 오른쪽 무릎에 탄력 밴드를 걸고 안쪽으로 당겨주어, 반사적으로 밴드의 저항을 이겨내며 바깥으로 밀어내는 힘을 쓰도록 돕습니다.',
        '발바닥 아치가 무너지거나 발끝이 안으로 돌아가기 직전까지만 내려가는 \'부분 반복\'을 진행하고, 뒤꿈치에 낮은 받침을 활용해 점진적으로 깊이를 늘립니다.',
      ],
    },
    'foot:RIGHT_FOOT_OUTWARD': {
      stateAnalysis: ['좌측 발은 중립 위치에 있으며, 우측 발만 바깥쪽을 향해 있습니다.(오른발 벌림/왼발 중립 정렬)'],
      movementPatternAnalysis: [
        '오른쪽 발목 벌림 정렬 패턴이 관찰됨',
        '→오른쪽 발의 지지 기반이 바깥쪽으로 확장되며 체중 분산 양상 변화',
        '→엉덩관절 바깥돌림·바깥쪽 사용 비중 증가와 연관된 하체 정렬 변화 동반됨',
        '→오른쪽 하체 사용 전략이 특정 방향으로 편향된 패턴이 나타남',
      ],
      optimizationStrategy: [
        '오른쪽 발뒤꿈치를 높여 발목 각도를 조절합니다. 이를 통해 동작 수행 시 나타나는 현상이 발목의 움직임 범위 문제인지 명확하게 확인합니다.',
        '발뒤꿈치로 바닥을 지그시 누르며, 두 번째 발가락과 무릎이 일직선상에 놓이도록 정렬을 유지하며 내려갑니다.',
        '발이 바깥으로 미끄러지지 않게 바닥을 가볍게 움켜쥐는 느낌을 주어 발바닥 아치를 살리고, 체중이 왼쪽으로 쏠리지 않도록 양쪽 하체에 균등한 힘을 분배하며 오른쪽 엉덩이 근육 참여에 집중합니다.',
      ],
    },
    'foot:LEFT_FOOT_INWARD': {
      stateAnalysis: ['우측 발은 중립 위치에 있으며, 좌측 발만 안쪽을 향해 있습니다.(왼발 모음/오른발 중립 정렬)'],
      movementPatternAnalysis: [
        '왼쪽 발목 모음 정렬 패턴이 관찰됨',
        '→왼쪽 발의 지지 기반이 신체 중심선 쪽으로 이동하는 양상 나타남',
        '→왼쪽 무릎의 안쪽 이동과 연관된 정렬 변화가 동반됨',
        '→왼쪽 하체의 정렬 안정성이 감소하는 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '왼쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려갑니다.',
        '"왼쪽 무릎이 두 번째 발가락 방향보다 안으로 들어오지 않게 바깥으로 벌린다"는 느낌에 집중하여 엉덩이 근육의 참여를 유도합니다.',
        '동작이 어렵다면 왼쪽 무릎에 탄력 밴드를 걸고 안쪽으로 당겨주어, 반사적으로 밴드의 저항을 이겨내며 바깥으로 밀어내는 힘을 쓰도록 돕습니다.',
        '발바닥 아치가 무너지거나 발끝이 안으로 돌아가기 직전까지만 내려가는 \'부분 반복\'을 진행하고, 뒤꿈치에 낮은 받침을 활용해 점진적으로 깊이를 늘립니다.',
      ],
    },
    'foot:LEFT_FOOT_OUTWARD': {
      stateAnalysis: ['우측 발은 중립 위치에 있으며, 좌측 발만 바깥쪽을 향해 있습니다.(왼발 벌림/오른발 중립 정렬)'],
      movementPatternAnalysis: [
        '왼쪽 발목 벌림 정렬 패턴이 관찰됨',
        '→왼쪽 발의 지지 기반이 바깥쪽으로 치우치며 체중 분산 변화 발생',
        '→엉덩관절 바깥돌림·바깥쪽 사용 비중 증가와 연관된 하체 정렬 변화 동반됨',
        '→왼쪽 하체 사용 전략이 특정 방향으로 편향된 패턴이 나타남',
      ],
      optimizationStrategy: [
        '왼쪽 발뒤꿈치를 높여 발목 각도를 조절합니다. 이를 통해 동작 수행 시 나타나는 현상이 발목의 움직임 범위 문제인지 명확하게 확인합니다.',
        '발뒤꿈치로 바닥을 지그시 누르며, 두 번째 발가락과 무릎이 일직선상에 놓이도록 정렬을 유지하며 내려갑니다.',
        '발이 바깥으로 미끄러지지 않게 바닥을 가볍게 움켜쥐는 느낌을 주어 발바닥 아치를 살리고, 체중이 오른쪽으로 쏠리지 않도록 양쪽 하체에 균등한 힘을 분배하며 왼쪽 엉덩이 근육 참여에 집중합니다.',
      ],
    },
    // ── 무릎 정렬 패턴 ──────────────────────────────────────────
    'knees:NORMAL': {
      stateAnalysis: ['정면 기준에서 양쪽 무릎이 곧게 정렬되어 있습니다.'],
      movementPatternAnalysis: [
        '양쪽 무릎이 발 방향과 나란하게 정렬된 상태가 관찰됨',
        '→내려가고 올라오는 과정에서 무릎의 이동 경로가 안정적으로 유지됨',
        '→엉덩관절·무릎·발목이 서로 잘 맞물려 움직이는 양상이 나타남',
        '→하체 전반의 지지와 조절이 안정적으로 작동하는 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '지금처럼 양발에 체중을 5:5로 똑같이 실어주는 느낌을 유지하세요.',
        '골반의 치우침 무릎의 모임-벌어짐 등을 추가로 확인합니다.',
        '기본 자세가 안정적이므로, 덤벨이나 바벨을 이용해 부하를 늘리거나(Loading), 불안정한 지면을 활용하는 등 난이도를 높여 훈련 효과를 극대화할 수 있습니다.',
      ],
    },
    'knees:KNEE_INWARD': {
      stateAnalysis: ['정면 기준에서 양쪽 무릎이 안쪽으로 모여 있습니다.'],
      movementPatternAnalysis: [
        '엉덩관절 벌림·바깥돌림 사용이 충분히 나타나지 않거나 발목 발등굽힘 제한과 연관된 움직임 양상이 관찰됨',
        '→하강 과정에서 넙다리뼈가 안쪽으로 향하며 무릎이 서로 모이는 정렬 패턴이 나타남',
        '→발바닥 아치 변화와 함께 무릎 안쪽에 부담이 집중되는 사용 양상이 관찰됨',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도를 조절합니다.',
        '이를 통해 동작 수행 시 무릎이 모이는 현상이 발목의 움직임 범위 문제인지 명확하게 확인합니다.',
        '양쪽 무릎에 탄력 밴드를 걸거나 파트너가 무릎을 안쪽으로 밀어줍니다. 이에 저항하며 반사적으로 엉덩이 근육을 사용하여 무릎을 벌리게 유도하고 바른 정렬 감각을 익힙니다.',
        '발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려갑니다. 이때 무릎이 두 번째 발가락 방향을 향하도록 유지하며 엉덩이 근육의 참여를 유도합니다.',
      ],
    },
    'knees:KNEE_OUTWARD': {
      stateAnalysis: ['정면 기준에서 양쪽 무릎이 바깥쪽으로 벌어져 있습니다.'],
      movementPatternAnalysis: [
        '엉덩관절 벌림·바깥돌림 사용 비중이 상대적으로 크게 나타나는 움직임 양상이 관찰됨',
        '→하강 과정에서 넙다리뼈가 바깥쪽으로 유지되며 무릎이 서로 벌어지는 정렬 패턴이 나타남',
        '→발바닥 지지 분포가 바깥쪽으로 치우치며 엄지발 접지 참여가 감소하는 양상이 동반됨',
        '→하체 사용 전략이 바깥쪽 지지에 편향되는 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '소도구(써클링등)를 무릎 안쪽에 끼우거나 파트너가 양쪽 무릎을 바깥으로 밀어줍니다. 이에 저항하며 반사적으로 허벅지 안쪽 근육을 사용하여 무릎을 모으는 바른 정렬 감각을 익히도록 유도합니다.',
        '엄지발가락 아래 발볼로 바닥을 꾹 누르며 내려갑니다. 발가락이 지면에서 떨어지지 않게 유지하여 무릎이 과하게 벌어지는 것을 방지하고 발바닥 아치의 안정적인 상태를 유지합니다.',
        '바른 정렬을 유지할 수 있는 범위 내에서만 동작을 수행하며, 하체의 안쪽과 바깥쪽 근육이 균형 있게 사용되는 패턴을 재설정합니다.',
      ],
    },
    'knees:KNEE_RIGHT': {
      stateAnalysis: ['정면 기준에서 오른쪽 무릎은 안쪽에, 왼쪽 무릎은 바깥쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '오른쪽 엉덩관절 조절이 충분히 드러나지 않는 움직임 양상이 관찰됨',
        '→그에 따라 오른쪽 무릎이 신체 중심선 쪽으로 이동하는 정렬 패턴이 나타남',
        '→하강 과정에서 상대적으로 왼쪽으로 무게중심이 이동하며 전신 비대칭 움직임이 동반됨',
      ],
      optimizationStrategy: [
        '오른쪽 무릎: 탄력 밴드나 파트너의 손을 이용해 무릎을 안쪽으로 당겨, 반사적으로 바깥으로 밀어내는 힘을 쓰도록 유도합니다.',
        '왼쪽 무릎: 탄력 밴드를 이용해 무릎을 바깥쪽으로 당겨 정렬을 확인합니다. 자세 유지가 어렵다면 오른쪽 무릎 위주로 먼저 실시합니다.',
        '오른쪽 발: 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 엉덩이 근육의 지지력을 활용해 내려갑니다.',
        '왼쪽 발: 엄지발가락 아래 발볼로 바닥을 꾹 누르며 발 안쪽이 지면에서 뜨지 않도록 견고하게 유지하며 내려갑니다.',
      ],
    },
    'knees:KNEE_LEFT': {
      stateAnalysis: ['정면 기준에서 오른쪽 무릎은 바깥쪽에, 왼쪽 무릎은 안쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '왼쪽 엉덩관절 조절이 충분히 드러나지 않는 움직임 양상이 관찰됨',
        '→그에 따라 왼쪽 무릎이 신체 중심선 쪽으로 이동하는 정렬 패턴이 나타남',
        '→하강 과정에서 오른쪽으로 무게중심이 이동하며 골반 이동과 상체 기울어짐이 동반됨',
      ],
      optimizationStrategy: [
        '왼쪽 무릎: 탄력 밴드나 파트너의 손을 이용해 무릎을 안쪽으로 당겨, 반사적으로 바깥으로 밀어내는 힘을 쓰도록 유도합니다.',
        '오른쪽 무릎: 탄력 밴드를 이용해 무릎을 바깥쪽으로 당겨 정렬을 확인합니다. 자세 유지가 어렵다면 왼쪽 무릎 위주로 먼저 실시합니다.',
        '왼쪽 발: 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 엉덩이 근육의 지지력을 활용해 내려갑니다.',
        '오른쪽 발: 엄지발가락 아래 발볼로 바닥을 꾹 누르며 발 안쪽이 지면에서 뜨지 않도록 견고하게 유지하며 내려갑니다.',
      ],
    },
    'knees:RIGHT_KNEE_INWARD': {
      stateAnalysis: ['정면 기준에서 왼쪽 무릎은 정상 위치에 있으며, 오른쪽 무릎만 안쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '오른쪽 엉덩이 벌림·바깥돌림 사용이 충분히 나타나지 않거나 발목 가동범위 제한과 연관된 움직임 양상이 관찰됨',
        '→그에 따라 넙다리뼈가 안쪽으로 향하며 오른쪽 무릎이 모이는 정렬 패턴이 나타남',
        '→오른쪽 하체에 국한된 조절 부담 증가와 함께 골반 정렬의 좌우 차이가 동반되는 경향이 관찰됨',
      ],
      optimizationStrategy: [
        '오른발 뒤꿈치를 높여 발목 각도를 교정합니다.\n이를 통해 무릎 정렬 변화에 발목 움직임 범위가 영향을 주는지 확인합니다.',
        '오른 무릎에 탄력밴드를 묶거나, 파트너가 오른 무릎을 안쪽으로 밀어줍니다. 반사적으로 엉덩이 근육을 사용해 무릎을 벌리게 되고 정렬 감각을 깨워줍니다.',
        '오른쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려가세요. 이때 "무릎이 두 번째 발가락 라인보다 안으로 들어오지 않게 바깥으로 벌린다"는 느낌에 집중하여 엉덩이 근육의 참여를 유도합니다.',
      ],
    },
    'knees:RIGHT_KNEE_OUTWARD': {
      stateAnalysis: ['정면 기준에서 왼쪽 무릎은 정상 위치에 있으며, 오른쪽 무릎만 바깥쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '오른쪽 엉덩관절의 조절 방식이 한쪽으로 치우친 양상이 관찰됨',
        '→허벅지가 바깥쪽으로 유지되며 오른쪽 무릎이 벌어지는 정렬 패턴이 나타남',
        '→발의 바깥쪽에 체중이 더 실리면서 하체 사용 방식이 바깥 방향으로 치우치는 경향이 관찰됨',
        '→오른쪽 하체 정렬이 균형 있게 유지되지 않는 양상이 동반됨',
      ],
      optimizationStrategy: [
        '오른쪽 발뒤꿈치를 높여 발목 각도를 조절합니다. 이를 통해 동작 수행 시 나타나는 현상이 발목의 움직임 범위 문제인지 명확하게 확인합니다.',
        '오른쪽 무릎에 탄력 밴드를 걸어 안쪽으로 당기거나, 파트너가 무릎을 안쪽으로 밀어줍니다. 그 저항을 이겨내며 바깥으로 밀어내는 힘을 사용해 정렬 감각을 익힙니다.',
        '오른쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려갑니다. 이때 무릎이 두 번째 발가락 방향을 향하도록 유지하며 엉덩이 근육의 참여를 유도합니다.',
      ],
    },
    'knees:LEFT_KNEE_INWARD': {
      stateAnalysis: ['정면 기준에서 오른쪽 무릎은 정상 위치에 있으며, 왼쪽 무릎만 안쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '왼쪽 엉덩관절 벌림·바깥돌림 사용 감소 또는 발목 가동범위 제한과 연관된 움직임이 관찰됨',
        '→넙다리뼈 안쪽돌림과 함께 왼쪽 무릎이 안쪽으로 모이는 정렬 패턴이 나타남',
        '→왼쪽 하체에 국한된 사용 패턴 변화와 함께 골반 정렬의 좌우 차이가 동반되는 경향이 관찰됨',
      ],
      optimizationStrategy: [
        '왼발 뒤꿈치를 높여 발목 각도를 교정합니다.\n이를 통해 무릎 정렬 변화에 발목 움직임 범위가 영향을 주는지 확인합니다.',
        '왼 무릎에 탄력밴드를 묶거나, 파트너가 왼 무릎을 안쪽으로 밀어줍니다. 반사적으로 엉덩이 근육을 사용해 무릎을 벌리게 되고 정렬 감각을 깨워줍니다.',
        '왼쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 내려가세요. 이때 "무릎이 두 번째 발가락 라인보다 안으로 들어오지 않게 바깥으로 벌린다"는 느낌에 집중하여 엉덩이 근육의 참여를 유도합니다.',
      ],
    },
    'knees:LEFT_KNEE_OUTWARD': {
      stateAnalysis: ['정면 기준에서 오른쪽 무릎은 정상 위치에 있으며, 왼쪽 무릎만 바깥쪽에 위치해 있습니다.'],
      movementPatternAnalysis: [
        '왼쪽 엉덩관절 벌림·바깥돌림 근육의 긴장도 증가 또는 길이 변화와 연관된 패턴이 관찰됨',
        '→넙다리가 바깥쪽으로 유지되며 무릎 안굽이(Varus)과 발 뒤침(supination) 정렬 양상이 동반됨',
        '→엄지발 접지 사용 감소와 함께 하체 안쪽 근육 사용 비중이 낮아지는 움직임 경향이 관찰됨',
      ],
      optimizationStrategy: [
        '왼쪽 무릎 안쪽에 탄력 밴드를 걸거나 파트너가 무릎을 바깥으로 밀어줍니다. 저항하며 무릎이 과하게 벌어지지 않는 정렬 감각을 익힙니다.',
        '왼쪽 엄지발가락 아래 발볼을 바닥에 꾹 누른 채 내려갑니다.',
        '발바닥 지지가 바깥쪽으로 쏠리지 않게 삼점 지지(엄지발볼·새끼발볼·뒤꿈치)를 유지합니다.',
        '정렬이 유지되는 범위에서 부분 반복→깊이 확대→부하(덤벨·바벨) 순으로 난이도를 올립니다.',
      ],
    },
  };

export const OHT_IMG_BASE = 'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/overhead-squat';

export const REAR_PATTERN_DB: Record<string, {
    stateAnalysis: string[];
    movementPatternAnalysis: string[];
    optimizationStrategy: string[];
  }> = {
    // ── 발목 지지 패턴 ────────────────────────────────────────────
    'ankles:NORMAL': {
      stateAnalysis: ['양쪽 발목에서 무너지는 경향은 보이지 않습니다.'],
      movementPatternAnalysis: [
        '발목 가동성이 정상 범위로 관찰되며 발바닥 접지가 안정적으로 유지됨',
        '→발바닥 아치가 무너지지 않고, 아킬레스건이 지면과 수직에 가까운 중립 정렬을 형성함',
        '→무릎과 엉덩관절의 비틀림 없이 안정적인 하체 운동 사슬이 나타남',
      ],
      optimizationStrategy: [
        '스쿼트 하강 중 발바닥 압력이 변하지 않는지 확인하기 위해, 발 아래 얇은 매트나 수건을 깔고 접지 변화 없이 반복합니다.',
        '하강 최저점에서 1초 정지한 뒤 다시 올라오며, 정지 구간에서도 발목과 발바닥의 안정성이 유지되는지 확인합니다.',
        '중량 또는 반복 횟수를 점진적으로 증가시키되, 발목 정렬이 흐트러질 경우 즉시 난이도를 조절하며 기준을 유지합니다.',
        '이후에는 속도 변화, 정지 구간, 비대칭 부하가 추가되더라도 발목 정렬이 자동으로 유지되는 수준을 목표로 훈련합니다.',
      ],
    },
    'ankles:ANKLE_OUTWARD': {
      stateAnalysis: ['양쪽 발목에서 안쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '하강 구간에서 발목이 필요한 만큼 안정적으로 접히지 않거나, 발바닥 전체로 지면을 지지하지 못하는 상황이 나타나며',
        '→제한된 범위를 피하기 위한 우회 전략과 함께 발아치 붕괴, 발이 안쪽으로 기울어지는 정렬, 뒤꿈치 바깥 밀림이 동반됨',
        '→연쇄적으로 무릎이 안쪽으로 더 많이 사용되는 방향의 힘 전달이 나타나고, 엉덩이 근육 사용이 줄어드는 패턴이 함께 관찰됨',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도 요구를 줄인 상태에서 스쿼트를 수행합니다.',
        '\'삼각대\' 접지를 유지하며 체중이 안쪽으로 쏠리지 않도록 내려갑니다.',
        '스쿼트 시작 전 발바닥을 바닥에 고정한 채, 무릎을 바깥으로 1cm 밀었다가 유지하며 하강합니다.',
        '동작이 어렵다면 탄력 밴드를 무릎이나 발목 위쪽에 걸고 안쪽으로 당겨, 저항에 맞서 바깥으로 버티는 힘을 사용하며 발 바깥쪽 접지와 아치 유지를 학습합니다.',
      ],
    },
    'ankles:ANKLE_INWARD': {
      stateAnalysis: ['양쪽 발목에서 바깥쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '하강 구간에서 하체가 근육을 통한 지지보다, 발의 끝부분 정렬에 의존해 버티는 패턴이 관찰됨',
        '→체중이 발날 쪽으로 이동하며 엄지발볼 접지가 줄고, 발이 바깥쪽으로 기울어지는 정렬이 나타남',
        '→과도한 아치 형성과 함께 접지 면적이 줄어들고, 충격 흡수 효율이 낮아지는 경향이 동반됨',
      ],
      optimizationStrategy: [
        '정렬이 무너지지 않는 범위에서 내려가기 위해, 기둥이나 파트너의 손을 가볍게 지탱하며 스쿼트를 실시합니다.',
        '엄지발가락 아래·새끼발가락 아래·뒤꿈치 세 지점이 바닥을 누르는 \'삼각대\' 접지를 유지하도록 유도합니다.',
        '특히 엄지발가락 아래 발볼로 지면에 도장을 찍는 느낌을 유지하며, 바른 패턴을 인식한 후 동작의 깊이를 점진적으로 늘립니다.',
        '하강 중 엄지발가락 아래 발볼을 바닥에 붙인 상태에서, 발가락을 살짝 들어 올린 채 스쿼트를 수행합니다.',
      ],
    },
    'ankles:ANKLE_RIGHT': {
      stateAnalysis: ['오른쪽 발목에서는 안쪽으로, 왼쪽 발목에서는 바깥쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '양쪽 엉덩관절·발목의 움직임 범위 및 안정성 차이와 연관된 패턴이 관찰됨',
        '→오른쪽 발은 무게 중심 이동과 함께 발아치 붕괴·발이 안쪽으로 기울어지는 정렬·무릎 안쪽 쏠림이 나타나고, 왼쪽 발은 발날 지지·엄지발가락 들림·발이 바깥쪽으로 기울어지는 정렬과 함께 보조적 균형 역할이 두드러짐',
      ],
      optimizationStrategy: [
        '스쿼트 시작 시 오른쪽 발의 바깥쪽 접지를 먼저 만든 뒤, 그 압력을 유지한 채 하강을 시작합니다.',
        '체중이 이미 오른쪽으로 쏠려 있다면 스쿼트 시작 전 골반을 왼쪽으로 이동시켜 5:5 체중 분배를 맞춥니다.',
        '오른쪽은 발바닥 전체로 바깥쪽으로 비트는 힘을, 왼쪽은 엄지발가락 아래 발볼 접지를 유지하며 내려갑니다.',
        '필요 시 오른쪽은 탄력 밴드를 안쪽으로, 왼쪽에는 바깥쪽으로 적용해 정렬 감각을 유도합니다.',
      ],
    },
    'ankles:ANKLE_LEFT': {
      stateAnalysis: ['오른쪽 발목에서는 바깥쪽으로, 왼쪽 발목에서는 안쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '양쪽 엉덩관절·발목의 움직임 범위 및 안정성 차이와 연관된 패턴이 관찰됨',
        '→왼쪽 발은 무게 중심 이동과 함께 발아치 붕괴·발이 안쪽으로 기울어지는 정렬·무릎 안쪽 쏠림이 나타나고, 오른쪽 발은 발날 지지·엄지발가락 들림·발이 바깥쪽으로 기울어지는 정렬과 함께 보조적 균형 역할이 두드러짐',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도 요구를 줄인 상태에서 스쿼트를 수행합니다.',
        '체중이 이미 왼쪽으로 쏠려 있다면 스쿼트 시작 전 골반을 오른쪽으로 이동시켜 5:5 체중 분배를 맞춥니다.',
        '왼쪽은 발바닥 전체로 바깥쪽으로 비트는 힘을, 오른쪽은 엄지발가락 아래 발볼 접지를 유지합니다.',
        '필요 시 왼쪽에는 탄력 밴드를 안쪽으로, 오른쪽에는 바깥쪽으로 적용해 정렬 감각을 유도합니다.',
      ],
    },
    'ankles:RIGHT_ANKLE_OUTWARD': {
      stateAnalysis: ['왼쪽 발목에서는 무너지는 경향이 보이지 않으며, 오른쪽 발목에서만 안쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '왼쪽은 정상적인 접지와 중립 정렬 유지 양상이 관찰됨',
        '→오른쪽에서는 체중이 발날 쪽으로 이동하며, 엄지발가락 아래 발볼 접지가 줄고 발이 바깥쪽으로 기울어지는 정렬이 관찰됨',
        '→근육 사용 감소와 함께 과도한 아치 형성, 신체 비대칭이 동반되는 경향',
      ],
      optimizationStrategy: [
        '정렬이 무너지지 않는 범위에서 내려가기 위해, 기둥이나 파트너의 손을 가볍게 지탱하며 스쿼트를 실시합니다.',
        '오른쪽 발이 바깥쪽으로 밀릴 경우, 내려가면서 오른쪽 엉덩관절의 안쪽돌림이 충분히 나오지 않아 발로 안정적으로 버티지 못하는 상황일 수 있어, 안쪽돌림이 자연스럽게 나오는 범위에서 동작을 조절해 연습합니다.',
        '엄지발가락 아래·새끼발가락 아래·뒤꿈치 세 지점이 바닥을 누르는 \'삼각대\' 접지를 유지하며 내려갑니다.',
        '특히 오른쪽 엄지발가락 아래 발볼 접지를 강조하고, 밴드를 활용해 반사적으로 안쪽 지지력을 사용하도록 유도합니다.',
      ],
    },
    'ankles:RIGHT_ANKLE_INWARD': {
      stateAnalysis: ['왼쪽 발목에서는 무너지는 경향이 보이지 않으며, 오른쪽 발목에서만 바깥쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '왼쪽은 정상적인 접지와 중립 정렬이 유지됨',
        '→오른쪽에서 발등굽힘이 필요한 만큼 활용되지 않으면서 발아치 붕괴, 발 안쪽으로 기울어지는 정렬, 뒤꿈치 바깥 밀림이 동반되는 양상이 관찰됨',
        '→연결된 오른쪽 무릎이 안쪽으로 쏠리는 연쇄 반응이 나타남',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도 요구를 줄인 상태에서 스쿼트를 수행합니다.',
        '오른쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 엉덩이 근육의 지지력을 활용해 내려갑니다.',
        '동작이 어렵다면 오른쪽 무릎이나 발목에 탄력 밴드를 걸고 안쪽으로 당겨, 반사적으로 바깥으로 밀어내는 힘을 쓰도록 유도합니다.',
      ],
    },
    'ankles:LEFT_ANKLE_OUTWARD': {
      stateAnalysis: ['오른쪽 발목에서는 무너지는 경향이 보이지 않으며, 왼쪽 발목에서만 안쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '오른쪽은 정상적인 접지와 중립 정렬이 유지됨',
        '→왼쪽에서는 체중이 발날 쪽으로 이동하며, 엄지발가락 아래 발볼 접지가 줄고 발이 바깥쪽으로 기울어지는 정렬이 관찰됨',
        '→근육 사용 감소와 함께 과도한 아치 형성 및 전신 비대칭 경향이 나타남',
      ],
      optimizationStrategy: [
        '정렬이 무너지지 않는 범위에서 내려가기 위해, 기둥이나 파트너의 손을 가볍게 지탱하며 스쿼트를 실시합니다.',
        '왼쪽 발이 바깥쪽으로 밀릴 경우, 내려가면서 왼쪽 엉덩관절의 안쪽돌림이 충분히 나오지 않아 발로 안정적으로 버티지 못하는 상황일 수 있어, 안쪽돌림이 자연스럽게 나오는 범위에서 동작을 조절해 연습합니다.',
        '엄지발가락 아래·새끼발가락 아래·뒤꿈치 세 지점을 바닥에 고르게 누르는 \'삼각대\' 접지를 유지합니다.',
        '특히 왼쪽 엄지발가락 아래 발볼 접지를 강조하고, 밴드를 활용해 반사적으로 안쪽 지지력을 사용하도록 유도합니다.',
      ],
    },
    'ankles:LEFT_ANKLE_INWARD': {
      stateAnalysis: ['오른쪽 발목에서는 무너지는 경향이 보이지 않으며, 왼쪽 발목에서만 바깥쪽으로 무너지는 경향이 나타납니다.'],
      movementPatternAnalysis: [
        '오른쪽은 정상적인 접지와 중립 정렬이 유지됨',
        '→왼쪽에서 발등굽힘이 필요한 만큼 활용되지 않으면서 발아치 붕괴, 발 안쪽으로 기울어지는 정렬, 뒤꿈치 바깥 밀림이 동반되는 양상이 관찰됨',
        '→연결된 왼쪽 무릎이 안쪽으로 쏠리는 연쇄 반응이 나타남',
      ],
      optimizationStrategy: [
        '발뒤꿈치를 높여 발목 각도 요구를 줄인 상태에서 스쿼트를 수행합니다.',
        '왼쪽 발바닥 전체로 지면을 바깥쪽으로 회전시키듯 비트는 힘을 주며 엉덩이 근육의 지지력을 활용해 내려갑니다.',
        '동작이 어렵다면 왼쪽 무릎이나 발목에 탄력 밴드를 걸고 안쪽으로 당겨, 반사적으로 바깥으로 밀어내는 힘을 사용하도록 유도합니다.',
      ],
    },
    // ── 골반 수평 정렬 ────────────────────────────────────────────
    'hipHigher:NORMAL': {
      stateAnalysis: ['좌우 골반 높이가 균형 있게 유지되고 있습니다.'],
      movementPatternAnalysis: [
        '허리네모근과 중간볼기근의 균형이 유지된 양상이 관찰됨',
        '→스쿼트 하강 시 골반의 좌우 높이가 유지되어, 한쪽이 올라가거나 내려가는 변화 없이 수평 정렬이 관찰됨',
        '→척추의 옆 기울어짐 없이 중립 정렬 안정성 유지',
      ],
      optimizationStrategy: [
        '바지의 허리 밴드 라인이 바닥과 평행하게 내려갔다 올라온다고 상상하며 현재의 정렬 감각을 강화합니다.',
        '양발 스쿼트에서는 안정적이나, 런지나 한 발 서기 같은 비대칭 동작에서도 골반 높이가 유지되는지 점검합니다.',
        '맨몸에서의 안정성이 확인되면, 중량을 추가한 상태에서도 골반이 한쪽으로 쏠리거나 들리지 않도록 난이도를 높여 훈련합니다.',
      ],
    },
    'hipHigher:RIGHT_HIP_HIGHER': {
      stateAnalysis: ['오른쪽 골반이 왼쪽보다 높게 위치하는 경향이 관찰됩니다.'],
      movementPatternAnalysis: [
        '오른쪽 하체가 하강 구간에서 충분히 지지 역할을 하지 못하는 경향과 연관된 패턴이 관찰됨',
        '→무게중심이 왼쪽으로 이동하며 왼쪽 엉덩이는 더 깊게 사용되고, 오른쪽 엉덩이는 상대적으로 높은 위치를 유지함',
        '→상체가 오른쪽으로 기울어지며 왼쪽 하체가 더 많이 지지·버티는 역할을 맡는 방향으로 힘 전달이 커지는 양상',
      ],
      optimizationStrategy: [
        '스쿼트 시작 전 양발 체중을 5:5로 맞춘 뒤, 오른쪽 하체로 지면을 더 강하게 누르며 골반을 수평으로 유지한 상태에서 하강합니다.',
        '하강 구간에서 상체가 오른쪽으로 기울어지지 않도록, 오른쪽 엉덩이를 아래로 보내는 느낌으로 내려가며 좌우 지지 균형을 유지합니다.',
        '정렬 유지가 어려울 경우 골반에 탄력 밴드를 걸고 왼쪽으로 당겨, 저항에 맞서 오른쪽으로 체중을 이동시키는 감각을 반복적으로 학습합니다.',
      ],
    },
    'hipHigher:LEFT_HIP_HIGHER': {
      stateAnalysis: ['왼쪽 골반이 오른쪽보다 높게 위치하는 경향이 관찰됩니다.'],
      movementPatternAnalysis: [
        '왼쪽 하체가 하강 구간에서 충분히 지지 역할을 하지 못하는 경향과 연관된 패턴이 관찰됨',
        '→무게중심이 오른쪽으로 이동하며 오른쪽 엉덩이는 더 깊게 사용되고, 왼쪽 엉덩이는 상대적으로 높은 위치를 유지함',
        '→상체가 왼쪽으로 기울어지며 오른쪽 하체가 더 많이 지지·버티는 역할을 맡는 방향으로 힘 전달이 커지는 양상',
      ],
      optimizationStrategy: [
        '스쿼트 시작 전 양발 체중을 5:5로 맞춘 뒤, 왼쪽 하체로 지면을 더 강하게 누르며 골반을 수평으로 유지한 상태에서 하강합니다.',
        '하강 구간에서 상체가 왼쪽으로 기울어지지 않도록, 왼쪽 엉덩이를 아래로 보내는 느낌으로 내려가며 좌우 지지 균형을 유지합니다.',
        '정렬 유지가 어려울 경우 골반에 탄력 밴드를 걸고 오른쪽으로 당겨, 저항에 맞서 왼쪽으로 체중을 이동시키는 정렬 감각을 반복적으로 익힙니다.',
      ],
    },
  };

export const JOINT_ROM_CONTENT_DB: Record<string, {
    compensationMotionDesc: string;
    compensationItems: Array<{ title: string; themeColor: string; assetKey: string }>;
    dailyUseItems: Array<{ title: string; themeColor: string }>;
    relatedConditionItems: Array<{ title: string; themeColor: string; iconKey: string }>;
    mainCausesRightCaption: string;
    mainCauseItems: Array<{ title: string; assetKey: string }>;
    futureProgramDirection: string;
    improvementGoal: string;
    routineItems: Array<{ order: number; name: string; assetKey: string }>;
    expectedEffect: string;
  }> = {
    NECK: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 눈 또는 몸통의 회전을 사용해 시야·방향을 보상하는 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '몸통 회전으로 방향 보상', themeColor: 'pink', assetKey: 'ROM_COMP_TRUNK_ROTATION' },
        { title: '어깨 들어올림 동반', themeColor: 'blue', assetKey: 'ROM_COMP_SHOULDER_ELEVATION' },
        { title: '눈 과도한 회전 사용', themeColor: 'gray', assetKey: 'ROM_COMP_EYE_ROTATION' },
      ],
      dailyUseItems: [
        { title: '운전 중 후방 확인 시 몸통 회전으로 보상', themeColor: 'pink' },
        { title: '옆 사람과 대화 시 어깨로 방향 돌림', themeColor: 'blue' },
        { title: '스마트폰 사용 시 고개를 과도하게 기울임', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '목 뒤쪽 결림', themeColor: 'pink', iconKey: 'ROM_CONDITION_NECK_TIGHTNESS' },
        { title: '어깨 위쪽 무거움', themeColor: 'blue', iconKey: 'ROM_CONDITION_UPPER_SHOULDER_HEAVINESS' },
        { title: '두통 또는 머리 무거움', themeColor: 'gray', iconKey: 'ROM_CONDITION_HEADACHE' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 고개 숙인 스마트폰·컴퓨터 사용', assetKey: 'ROM_CAUSE_SMARTPHONE_USE' },
        { title: '한쪽 방향으로 눕는 수면자세', assetKey: 'ROM_CAUSE_SLEEP_ONE_SIDE' },
        { title: '한쪽 어깨에 가방 메는 습관', assetKey: 'ROM_CAUSE_BAG_ONE_SIDE' },
        { title: '턱 괴는 습관', assetKey: 'ROM_CAUSE_CHIN_REST' },
      ],
      futureProgramDirection: '위등세모근·목갈비근 등 긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 목을 받치는 속근육(깊은목굽힘근)은 활성화·강화하여 유연성과 안정성의 균형을 맞춥니다. 등뼈와의 연동과 머리·목의 중립 정렬을 함께 다듬어 결림과 전방 머리 자세에 따른 부담을 줄입니다. 긴장과 정렬 이상이 누적되기 쉬운 부위인 만큼, 단계적 관리와 재측정으로 상태를 유지하고 변화를 점검합니다.',
      improvementGoal: '목의 정상 가동범위를 확보·유지하고, 머리·목의 중립 정렬과 목을 받치는 속근육(깊은목굽힘근)의 조절력을 회복·유지하여, 어깨·몸통의 보상 없이 통증 없는 목 움직임을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '벽 기대어 목 뒤 스트레칭', assetKey: 'ROM_ROUTINE_NECK_WALL_STRETCH' },
        { order: 2, name: '흉추 회전 운동 (Cat-cow 변형)', assetKey: 'ROM_ROUTINE_THORACIC_ROTATION' },
        { order: 3, name: '목 측면 스트레칭', assetKey: 'ROM_ROUTINE_NECK_LATERAL_STRETCH' },
      ],
      expectedEffect: '목 뒤쪽 결림 감소, 어깨 위쪽 무거움 완화, 두통 완화, 운전 중 방향 전환 시 보상 패턴 감소',
    },
    SHOULDER: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 어깨의 움직임을 다른 자세나 몸통 패턴으로 대신 사용하는 보상 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '몸통 반대쪽 기울기', themeColor: 'pink', assetKey: 'ROM_COMP_BODY_LEAN_OPPOSITE' },
        { title: '어깨를 위로 들어올림', themeColor: 'blue', assetKey: 'ROM_COMP_SHOULDER_ELEVATION' },
        { title: '팔꿈치 굽힘 동반', themeColor: 'gray', assetKey: 'ROM_COMP_ELBOW_FLEXION' },
      ],
      dailyUseItems: [
        { title: '팔 옆으로 들 때 몸통 기울임으로 보상', themeColor: 'pink' },
        { title: '상의 탈의 시 어깨를 들어 보상', themeColor: 'blue' },
        { title: '측면 위쪽의 물건을 집을 때 팔꿈치 굽힘이 동반됨', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '어깨 바깥쪽 결림', themeColor: 'pink', iconKey: 'ROM_CONDITION_OUTER_SHOULDER_TIGHTNESS' },
        { title: '어깨 관절 앞쪽 무거움', themeColor: 'blue', iconKey: 'ROM_CONDITION_FRONT_SHOULDER_HEAVINESS' },
        { title: '어깨 바깥쪽 관절 찌르는 느낌', themeColor: 'gray', iconKey: 'ROM_CONDITION_OUTER_SHOULDER_STINGING' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '옆으로 눕는 수면자세 (왼쪽이 아래)', assetKey: 'ROM_CAUSE_SLEEP_LEFT_DOWN' },
        { title: '손으로 턱 괴는 습관', assetKey: 'ROM_CAUSE_CHIN_REST' },
        { title: '머리카락 왼쪽으로 넘기는 습관', assetKey: 'ROM_CAUSE_HAIR_LEFT' },
        { title: '왼쪽 방향 가방 착용 습관', assetKey: 'ROM_CAUSE_BAG_LEFT' },
      ],
      futureProgramDirection: '넓은등근·큰가슴근·돌림근띠 등 긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 어깨뼈를 받치는 안정근(앞톱니근·아래등세모근)은 강화하여 가동성과 안정성의 균형을 맞춥니다. 등뼈-어깨 연동과 어깨뼈 정렬을 함께 다듬어 으쓱임 등 보상 없이 팔을 쓰도록 합니다. 가동성과 안정성이 함께 영향을 받기 쉬운 부위인 만큼, 단계적 관리와 재측정으로 상태를 유지하고 변화를 점검합니다.',
      improvementGoal: '어깨의 정상 가동범위를 확보·유지하고, 어깨뼈의 안정적인 정렬과 돌림근띠의 조절력을 회복·유지하여, 으쓱이거나 허리를 젖히는 보상 없이 팔을 자유롭게 쓰는 기능을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: 'Wall slide', assetKey: 'ROM_ROUTINE_WALL_SLIDE' },
        { order: 2, name: '가슴 열기 스트레칭', assetKey: 'ROM_ROUTINE_CHEST_OPENING' },
        { order: 3, name: '만세 동작으로 옆구리·겨드랑이 스트레칭 (전거근 스트레칭)', assetKey: 'ROM_ROUTINE_SIDE_STRETCH' },
      ],
      expectedEffect: '어깨 바깥쪽 결림 감소, 어깨 관절 앞쪽 무거움 완화, 어깨 바깥쪽 관절 찌르는 느낌 완화, 어깨 위 빠른감 완화',
    },
    ELBOW: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 어깨 또는 손목의 움직임을 과도하게 활용하는 보상 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '어깨 들어올림 동반', themeColor: 'pink', assetKey: 'ROM_COMP_SHOULDER_ELEVATION' },
        { title: '손목 과도한 굽힘 사용', themeColor: 'blue', assetKey: 'ROM_COMP_WRIST_FLEXION' },
        { title: '몸통 회전으로 보상', themeColor: 'gray', assetKey: 'ROM_COMP_TRUNK_ROTATION' },
      ],
      dailyUseItems: [
        { title: '물건 들 때 어깨를 앞으로 말아 보상', themeColor: 'pink' },
        { title: '글쓰기·타이핑 시 손목 꺾어 보상', themeColor: 'blue' },
        { title: '팔 굽혀 물 마실 때 어깨 들림 동반', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '팔꿈치 안쪽 결림', themeColor: 'pink', iconKey: 'ROM_CONDITION_INNER_ELBOW_TIGHTNESS' },
        { title: '전완 피로감', themeColor: 'blue', iconKey: 'ROM_CONDITION_FOREARM_FATIGUE' },
        { title: '손목 불편감', themeColor: 'gray', iconKey: 'ROM_CONDITION_WRIST_DISCOMFORT' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 팔꿈치 굽힌 자세 (스마트폰·모니터)', assetKey: 'ROM_CAUSE_ELBOW_BENT_POSTURE' },
        { title: '반복적인 팔꿈치 굽힘·펴기 동작', assetKey: 'ROM_CAUSE_REPETITIVE_ELBOW' },
        { title: '무거운 물건 장시간 들기', assetKey: 'ROM_CAUSE_HEAVY_CARRY' },
        { title: '손목 과사용 동반 작업', assetKey: 'ROM_CAUSE_WRIST_OVERUSE' },
      ],
      futureProgramDirection: '팔 앞뒤의 긴장이 쌓이기 쉬운 부위는 이완 운동으로 유연성을 회복·유지하고, 굽힘·폄 근력은 균형 있게 강화하여 가동성과 안정성의 균형을 맞춥니다. 어깨를 들썩이는 보상 없이 팔꿈치를 쓰도록 어깨-팔꿈치 연동과 바른 정렬을 함께 다듬으며, 단계적 관리와 재측정으로 상태를 유지하고 변화를 점검합니다.',
      improvementGoal: '팔꿈치의 정상 가동범위를 확보·유지하고, 굽힘·폄 근력의 균형과 끝범위에서의 안정적 조절력을 회복·유지하여, 어깨의 보상 없이 통증 없는 팔꿈치 움직임을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '전완 스트레칭 (손바닥 위쪽)', assetKey: 'ROM_ROUTINE_FOREARM_STRETCH_UP' },
        { order: 2, name: '전완 스트레칭 (손바닥 아래쪽)', assetKey: 'ROM_ROUTINE_FOREARM_STRETCH_DOWN' },
        { order: 3, name: '팔꿈치 굽힘-펴기 부드러운 반복', assetKey: 'ROM_ROUTINE_ELBOW_FLEXION_EXTENSION' },
      ],
      expectedEffect: '팔꿈치 안쪽 결림 감소, 전완 피로감 완화, 손목 불편감 감소, 팔 굽힘 동작 개선',
    },
    TORSO: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 골반 또는 고관절의 회전을 과도하게 사용하는 보상 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '골반 과도한 회전 사용', themeColor: 'pink', assetKey: 'ROM_COMP_PELVIS_ROTATION' },
        { title: '고관절 굽힘으로 보상', themeColor: 'blue', assetKey: 'ROM_COMP_HIP_FLEXION' },
        { title: '경추 과도한 굴곡 동반', themeColor: 'gray', assetKey: 'ROM_COMP_CERVICAL_FLEXION' },
      ],
      dailyUseItems: [
        { title: '상체 앞으로 구부릴 때 골반 과도하게 앞으로 밀림', themeColor: 'pink' },
        { title: '뒤를 볼 때 몸통이 충분히 돌아가지 않아 고개만 과도하게 돌림', themeColor: 'blue' },
        { title: '물건 집을 때 허리 과도하게 구부림', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '허리 뒤쪽 결림', themeColor: 'pink', iconKey: 'ROM_CONDITION_LOWER_BACK_TIGHTNESS' },
        { title: '옆구리 당기는 느낌', themeColor: 'blue', iconKey: 'ROM_CONDITION_FLANK_TIGHTNESS' },
        { title: '척추 주변 피로감', themeColor: 'gray', iconKey: 'ROM_CONDITION_SPINE_FATIGUE' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 앉아 있는 자세 (사무직·운전)', assetKey: 'ROM_CAUSE_PROLONGED_SITTING' },
        { title: '한쪽으로 치우친 수면자세', assetKey: 'ROM_CAUSE_SLEEP_ONE_SIDE' },
        { title: '한쪽 방향 작업 또는 스포츠 습관', assetKey: 'ROM_CAUSE_ONE_SIDE_WORK' },
        { title: '복근·코어 약화', assetKey: 'ROM_CAUSE_CORE_WEAKNESS' },
      ],
      futureProgramDirection: '긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 코어 안정성은 강화하여 가동성과 안정성의 균형을 맞춥니다. 엉덩관절과의 연동과 척추 중립 정렬을 함께 다듬어 특정 분절에 쏠리는 부담을 분산합니다. 보상 패턴이 자리 잡기 쉬운 부위인 만큼, 단계적 관리와 재측정으로 상태를 유지하고 악화를 예방합니다.',
      improvementGoal: '몸통의 정상 가동범위를 확보·유지하고, 척추의 중립 정렬과 코어 안정성을 회복·유지하여, 허리 한 분절에 쏠리거나 골반을 비트는 보상 없이 통증 없는 몸통 움직임을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '흉추 회전 (상체 돌리기)', assetKey: 'ROM_ROUTINE_THORACIC_ROTATION' },
        { order: 2, name: '허리 옆 스트레칭 (옆구리 늘리기)', assetKey: 'ROM_ROUTINE_LATERAL_TRUNK_STRETCH' },
        { order: 3, name: '캣-카우 (Cat-Cow)', assetKey: 'ROM_ROUTINE_CAT_COW' },
      ],
      expectedEffect: '허리 뒤쪽 결림 감소, 옆구리 당기는 느낌 완화, 척추 피로감 감소, 회전 동작 개선',
    },
    HIP: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 허리(요추) 또는 무릎의 과도한 굴곡을 사용하는 보상 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '허리 과도한 굴곡 동반', themeColor: 'pink', assetKey: 'ROM_COMP_LOWER_BACK_FLEXION' },
        { title: '반대쪽 골반 들어올림', themeColor: 'blue', assetKey: 'ROM_COMP_PELVIS_ELEVATION' },
        { title: '무릎 굽힘으로 보상', themeColor: 'gray', assetKey: 'ROM_COMP_KNEE_FLEXION' },
      ],
      dailyUseItems: [
        { title: '앉았다 일어날 때 허리를 과도하게 앞으로 숙임', themeColor: 'pink' },
        { title: '계단 오를 때 골반 흔들림 동반', themeColor: 'blue' },
        { title: '낮은 곳 물건 집을 때 골반 높이 차이 발생', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '고관절 앞쪽 당기는 느낌', themeColor: 'pink', iconKey: 'ROM_CONDITION_HIP_FRONT_TIGHTNESS' },
        { title: '허리 아래 긴장감', themeColor: 'blue', iconKey: 'ROM_CONDITION_LOWER_BACK_TENSION' },
        { title: '볼기 주변 무거움', themeColor: 'gray', iconKey: 'ROM_CONDITION_GLUTE_HEAVINESS' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 앉아 있는 자세', assetKey: 'ROM_CAUSE_PROLONGED_SITTING' },
        { title: '다리 꼬는 습관', assetKey: 'ROM_CAUSE_LEG_CROSS' },
        { title: '고관절 스트레칭 부족', assetKey: 'ROM_CAUSE_HIP_STRETCH_LACK' },
        { title: '비대칭 서기 자세', assetKey: 'ROM_CAUSE_ASYMMETRIC_STANDING' },
      ],
      futureProgramDirection: '엉덩이·허벅지 등 긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 골반을 받치는 안정근은 강화하여 가동성과 안정성의 균형을 맞춥니다. 허리-골반 연동과 정렬을 함께 다듬어 허리로 분산되던 부하를 엉덩관절이 담당하도록 하며, 단계적 관리와 재측정으로 상태를 유지하고 변화를 점검합니다.',
      improvementGoal: '엉덩관절의 정상 가동범위를 확보·유지하고, 골반의 안정적인 정렬과 엉덩이 근육의 조절력을 회복·유지하여, 허리·골반의 보상 없이 통증 없는 다리 움직임을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '고관절 굴곡근 스트레칭 (런지 자세)', assetKey: 'ROM_ROUTINE_HIP_FLEXOR_STRETCH' },
        { order: 2, name: '클램쉘 운동 (옆으로 누워 무릎 열기)', assetKey: 'ROM_ROUTINE_CLAMSHELL' },
        { order: 3, name: '90/90 고관절 스트레칭', assetKey: 'ROM_ROUTINE_HIP_90_90' },
      ],
      expectedEffect: '고관절 앞쪽 당기는 느낌 감소, 허리 아래 긴장감 완화, 볼기 주변 무거움 감소, 앉았다 일어나는 동작 개선',
    },
    KNEE: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 고관절 또는 발목의 과도한 움직임을 통해 보상하는 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '고관절 과도한 굴곡 동반', themeColor: 'pink', assetKey: 'ROM_COMP_HIP_FLEXION' },
        { title: '발목 발등굽힘 과사용', themeColor: 'blue', assetKey: 'ROM_COMP_ANKLE_DORSIFLEXION' },
        { title: '골반 기울기 변화', themeColor: 'gray', assetKey: 'ROM_COMP_PELVIS_TILT' },
      ],
      dailyUseItems: [
        { title: '앉을 때 엉덩이를 과도하게 앞으로 빼서 앉음', themeColor: 'pink' },
        { title: '계단 내려올 때 무릎을 충분히 굽히지 못하고 발목으로 보상', themeColor: 'blue' },
        { title: '쪼그려 앉기 어려워 발뒤꿈치를 들어 보상', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '무릎 뒤쪽 당기는 느낌', themeColor: 'pink', iconKey: 'ROM_CONDITION_KNEE_BACK_TIGHTNESS' },
        { title: '무릎 앞쪽 뻐근함', themeColor: 'blue', iconKey: 'ROM_CONDITION_KNEE_FRONT_STIFFNESS' },
        { title: '대퇴부 긴장감', themeColor: 'gray', iconKey: 'ROM_CONDITION_THIGH_TENSION' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 무릎 편 자세로 앉기 (사무직)', assetKey: 'ROM_CAUSE_KNEE_EXTENDED_SITTING' },
        { title: '반복적인 계단 오르내리기', assetKey: 'ROM_CAUSE_REPETITIVE_STAIRS' },
        { title: '대퇴사두근·뒤넙다리근 스트레칭 부족', assetKey: 'ROM_CAUSE_QUAD_HAMSTRING_STRETCH_LACK' },
        { title: '무릎 꿇는 자세 오래 유지', assetKey: 'ROM_CAUSE_KNEELING_PROLONGED' },
      ],
      futureProgramDirection: '허벅지·종아리 등 긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 무릎을 받치는 근력(넙다리네갈래근·뒤넙다리근)은 강화하여 가동성과 안정성의 균형을 맞춥니다. 엉덩관절·발목과의 연동과 발끝 방향 정렬을 함께 다듬어 무릎이 안팎으로 치우치지 않도록 합니다. 정렬 이상이 누적되기 쉬운 부위인 만큼, 단계적 관리와 재측정으로 상태를 유지하고 악화를 예방합니다.',
      improvementGoal: '무릎의 정상 가동범위를 확보·유지하고, 발끝 방향의 안정적인 정렬과 무릎 주변 근력(넙다리네갈래근·뒤넙다리근)의 조절력을 회복·유지하여, 안팎으로 쏠리는 보상 없이 통증 없는 무릎 움직임을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '뒤넙다리근 스트레칭 (앉아서 다리 뻗기)', assetKey: 'ROM_ROUTINE_HAMSTRING_STRETCH' },
        { order: 2, name: '대퇴사두근 스트레칭 (서서 발목 잡기)', assetKey: 'ROM_ROUTINE_QUAD_STRETCH' },
        { order: 3, name: '무릎 굽힘 부드러운 반복 (엎드려 발꿈치 당기기)', assetKey: 'ROM_ROUTINE_PRONE_KNEE_FLEXION' },
      ],
      expectedEffect: '무릎 뒤쪽 당기는 느낌 감소, 무릎 앞쪽 뻐근함 완화, 대퇴부 긴장감 감소, 쪼그려 앉기 및 계단 동작 개선',
    },
    ANKLE: {
      compensationMotionDesc: '해당 움직임이 제한될 경우 무릎 또는 고관절의 과도한 굴곡을 통해 보상하는 전략이 나타날 수 있습니다.',
      compensationItems: [
        { title: '무릎 과도한 굽힘 동반', themeColor: 'pink', assetKey: 'ROM_COMP_KNEE_FLEXION' },
        { title: '발 바깥쪽 벌림으로 보상', themeColor: 'blue', assetKey: 'ROM_COMP_FOOT_OUTWARD' },
        { title: '뒤꿈치 들림 동반', themeColor: 'gray', assetKey: 'ROM_COMP_HEEL_RISE' },
      ],
      dailyUseItems: [
        { title: '쪼그려 앉을 때 뒤꿈치가 들림', themeColor: 'pink' },
        { title: '계단 내려올 때 발목이 충분히 굽혀지지 않아 발 전체로 내려감', themeColor: 'blue' },
        { title: '스쿼트 동작 시 발이 바깥쪽으로 벌어짐', themeColor: 'gray' },
      ],
      relatedConditionItems: [
        { title: '발목 앞쪽 뻐근함', themeColor: 'pink', iconKey: 'ROM_CONDITION_ANKLE_FRONT_STIFFNESS' },
        { title: '종아리 긴장감', themeColor: 'blue', iconKey: 'ROM_CONDITION_CALF_TENSION' },
        { title: '발바닥 피로감', themeColor: 'gray', iconKey: 'ROM_CONDITION_PLANTAR_FATIGUE' },
      ],
      mainCausesRightCaption: '움직임 습관이나 사용 방식과 관련된 제한',
      mainCauseItems: [
        { title: '장시간 하이힐 또는 굽 있는 신발 착용', assetKey: 'ROM_CAUSE_HIGH_HEEL' },
        { title: '앉아서 발목 움직임 부족', assetKey: 'ROM_CAUSE_ANKLE_MOBILITY_LACK' },
        { title: '종아리 스트레칭 부족', assetKey: 'ROM_CAUSE_CALF_STRETCH_LACK' },
        { title: '반복적인 달리기·점프 동작', assetKey: 'ROM_CAUSE_REPETITIVE_RUNNING_JUMP' },
      ],
      futureProgramDirection: '종아리·발꿈치힘줄 등 긴장이 쌓이기 쉬운 부위는 스트레칭·이완 운동으로 유연성을 회복·유지하고, 발목을 받치는 근력과 균형 감각은 강화하여 가동성과 안정성의 균형을 맞춥니다. 무릎·발과의 연동과 바른 디딤 정렬을 함께 다듬어 반복적인 접질림 부담을 줄입니다. 불안정이 생기기 쉬운 부위인 만큼, 단계적 관리와 재측정으로 상태를 유지하고 변화를 점검합니다.',
      improvementGoal: '발목의 정상 가동범위를 확보·유지하고, 디딤 시 안정적인 정렬과 발목 주변 근력·균형 감각을 회복·유지하여, 발 안쪽이 무너지거나 다리로 보상하지 않는 안정적인 발목 기능을 달성하는 것을 목표로 합니다.',
      routineItems: [
        { order: 1, name: '종아리 스트레칭 (벽 기대어)', assetKey: 'ROM_ROUTINE_CALF_WALL_STRETCH' },
        { order: 2, name: '발목 원형 돌리기', assetKey: 'ROM_ROUTINE_ANKLE_CIRCLES' },
        { order: 3, name: '무릎 굽혀 발목 올리기 (Knee-to-wall)', assetKey: 'ROM_ROUTINE_KNEE_TO_WALL' },
      ],
      expectedEffect: '발목 앞쪽 뻐근함 감소, 종아리 긴장감 완화, 발바닥 피로감 감소, 스쿼트·보행 동작 개선',
    },
  };

export const SIDE_PATTERN_DB: Record<string, {
    stateAnalysis: string[];
    movementPatternAnalysis: string[];
    optimizationStrategy: string[];
  }> = {
    // ── 어깨 굽힘 가동범위 ────────────────────────────────────────
    'arm:NORMAL': {
      stateAnalysis: ['양쪽 팔이 180도까지 원활하게 올라가고 있습니다.'],
      movementPatternAnalysis: [
        '등이 충분히 펴지고 위로 세워지는 움직임이 잘 확보됨',
        '→넓은등근과 가슴근육의 적절한 유연성 유지',
        '→어깨뼈의 자연스러운 위쪽 돌림과 안정화로 어깨관절 180도 굽힘 가능',
        '→팔이 귀 옆 위치까지 수직 정렬됨',
      ],
      optimizationStrategy: [
        '운동 전후 흉추와 넓은 등근 스트레칭을 지속하여 현재 확보된 유연성을 유지합니다.',
        '팔이 180도로 올라간 상태에서도 코어(복부)가 풀리지 않고 단단히 유지되는지 지속적으로 확인합니다.',
        '가동성이 충분히 확보된 상태이므로 덤벨이나 바벨을 활용한 오버헤드 프레스를 통해 어깨 주변 근력과 안정성을 강화합니다.',
        '이때 팔꿈치가 완전히 펴진 상태(Lock-out)에서 흔들림 없이 정렬을 유지하는 데 집중합니다.',
      ],
    },
    'arm:ARM_UNNORMAL': {
      stateAnalysis: ['양쪽 팔이 머리 위까지 충분히 올라가지 않아 어깨 움직임 범위가 전반적으로 제한되어 보입니다.'],
      movementPatternAnalysis: [
        '등의 움직임이 충분히 활용되지 않아, 어깨뼈가 적절한 위치로 이동하지 못함',
        '→하강 시 상체가 일찍 당겨지며 팔이 머리 위로 충분히 올라가지 않음',
        '→움직임 범위를 확보하는 과정에서 상체가 더 앞으로 기울어지거나 허리 각도가 달라지는 양상이 관찰됨',
      ],
      optimizationStrategy: [
        '하강 깊이를 줄인 상태에서 팔 위치만 끝까지 유지하는 반복을 통해, 팔과 상체 정렬 감각을 먼저 확보합니다.',
        '손바닥이 서로 마주 보게 정렬한 뒤 엄지손가락을 뒤로 보내는 회전력을 활용하여 가슴 앞쪽 근육의 이완 통로를 확보합니다.',
        '팔꿈치를 완전히 펴 천장을 밀어낸다는 느낌으로 능동적으로 팔을 밀어 올려 흉추 폄을 유도합니다.',
        '앉거나 선 자세에서 턱을 당기고 정수리를 수직으로 뽑아 올려 척추 마디 사이의 가동 공간을 물리적으로 넓히는 연습을 합니다.',
      ],
    },
    'arm:LEFT_ARM_UNNORMAL': {
      stateAnalysis: ['오른쪽 팔은 머리 위까지 올라가지만, 왼쪽 팔은 끝까지 올라가지 않아 어깨 움직임 범위가 제한되어 보입니다.'],
      movementPatternAnalysis: [
        '왼쪽 등 쪽의 움직임이 다소 뻣뻣하게 나타나며, 오른쪽 등 쪽에서는 비교적 원활한 움직임 활용이 유지되는 양상이 관찰됨',
        '→하강 구간에서 왼쪽 등과 상체 뒤쪽이 길어지며 부담이 커질 때, 이를 줄이기 위해 왼쪽 팔을 머리 위보다 앞쪽으로 두는 움직임이 나타남',
        '→그 결과 상체가 비틀리며 허리와 어깨 쪽에 부담이 집중되는 양상이 함께 관찰됨',
      ],
      optimizationStrategy: [
        '왼쪽 팔꿈치를 완전히 펴 천장을 밀어낸다는 느낌으로 강하게 밀어 올립니다.',
        '능동적인 팔 움직임을 통해 등을 편 상태를 유지하고 등 근육이 유연한 길이를 유지하도록 유도합니다.',
        '왼쪽 겨드랑이 아래 공간에 가상의 공이 있다고 가정하고 숨을 들이마실 때 그 부위를 팽창시켜 갈비뼈 사이의 공간을 확보합니다.',
        '동작이 계속 어렵다면, 왼쪽으로 등과 몸통을 부드럽게 회전하는 동작을 먼저 진행한 뒤 다시 스쿼트를 수행합니다.',
      ],
    },
    'arm:RIGHT_ARM_UNNORMAL': {
      stateAnalysis: ['왼쪽 팔은 머리 위까지 올라가지만, 오른쪽 팔은 끝까지 올라가지 않아 어깨 움직임 범위가 제한되어 보입니다.'],
      movementPatternAnalysis: [
        '오른쪽 등 쪽의 움직임이 다소 뻣뻣하게 나타나며, 왼쪽 등 쪽에서는 비교적 원활한 움직임 활용이 유지되는 양상이 관찰됨',
        '→하강 구간에서 오른쪽 등과 상체 뒤쪽이 길어지며 부담이 커질 때, 이를 줄이기 위해 오른쪽 팔을 머리 위보다 앞쪽으로 두는 움직임이 나타남',
        '→그 결과 상체가 비틀리며 허리와 어깨 쪽에 부담이 집중되는 양상이 함께 관찰됨',
      ],
      optimizationStrategy: [
        '오른쪽 팔꿈치를 완전히 펴 천장을 밀어낸다는 느낌으로 강하게 밀어 올립니다.',
        '능동적인 팔 움직임을 통해 등을 편 상태를 유지하고 등 근육이 유연한 길이를 유지하도록 유도합니다.',
        '오른쪽 겨드랑이 아래 공간에 가상의 공이 있다고 가정하고 숨을 들이마실 때 그 부위를 팽창시켜 갈비뼈 사이의 공간을 확보합니다.',
        '동작이 계속 어렵다면, 오른쪽으로 등과 몸통을 부드럽게 회전하는 동작을 먼저 진행한 뒤 다시 스쿼트를 수행합니다.',
      ],
    },
    // ── 상체 기울기 조절 ─────────────────────────────────────────
    'body:NORMAL': {
      stateAnalysis: ['좌우 골반 높이가 균형 있게 유지되고 있습니다.'],
      movementPatternAnalysis: [
        '하강 구간에서 무릎이 발끝 방향으로 자연스럽게 이동하며, 엉덩이가 과도하게 뒤로 빠지지 않은 상태가 함께 나타남',
        '→그 결과 상체가 세워진 상태에 가까운 하강 각도가 유지됨',
        '→엉덩이, 등, 복부가 함께 작용해 허리가 꺾이거나 흔들리지 않는 안정적인 자세가 관찰됨',
      ],
      optimizationStrategy: [
        '발바닥 전체가 지면을 움켜쥐는 접지력을 강화하여 상하체의 유기적인 힘 전달 효율을 한 단계 높이는 훈련을 합니다.',
        '자세가 안정적인 상태이므로 중량이 추가되어도 상체 각도가 무너지지 않도록 코어에 집중합니다.',
        '한 발 스쿼트(Single Leg Squat)와 같은 비대칭 동작을 활용해 난이도를 높이고 정교한 안정성을 강화합니다.',
      ],
    },
    'body:BODY_LEARN_FORWARD': {
      stateAnalysis: ['스쿼트 동작에서 상체가 앞쪽으로 치우쳐 기울어진 상태'],
      movementPatternAnalysis: [
        '발목 움직임 활용이 충분히 나타나지 않아 무릎 전진보다 엉덩이 뒤쪽 이동이 먼저 나타나는 양상이 관찰됨',
        '→무게중심이 뒤로 이동하며 균형이 흐트러지는 양상이 나타남',
        '→균형을 맞추기 위해 상체를 급격히 앞으로 숙이는 보상 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '하강 시 무릎을 발가락 방향으로 더 과감하게 밀어내어 골반이 아래로 수직 하강할 수 있는 공간을 적극적으로 확보합니다.',
        '시선을 정면보다 15도 위쪽의 고정된 지점에 고정하여 흉곽이 자연스럽게 열린 상태로 동작이 수행되도록 유도합니다.',
        '상체를 앞으로 당기는 밴드의 저항에 본능적으로 저항하게 하여, 등 근육(척추세움근)이 스스로 상체를 세우는 정렬 감각을 뇌에 입력합니다.',
        '하강 동작 중 양팔 사이의 간격을 의도적으로 넓게 유지하여 가슴우리가 닫히지 않고 상체 박스가 수직으로 세워질 수 있는 구조적 여유를 만듭니다.',
      ],
    },
    'body:BODY_LEARN_BACKWARD': {
      stateAnalysis: ['스쿼트 동작에서 상체가 뒤쪽으로 과도하게 젖혀진 상태'],
      movementPatternAnalysis: [
        '하강 구간에서 복부에 힘을 유지하기보다 허리를 과도하게 젖혀 균형을 맞추려는 전략이 나타남',
        '→등 쪽 움직임 활용이 충분하지 않고 엉덩이 근육의 유연한 사용이 줄어든 상태가 함께 관찰됨',
        '→부족한 움직임 범위를 대신하기 위해 허리를 더 꺾어 내려가는 보상 패턴이 반복됨',
      ],
      optimizationStrategy: [
        '양팔을 머리 위로 뻗을 때 손바닥이 정면이 아닌 서로 마주 보게 하여, 광배근의 과도한 긴장으로 인해 흉곽이 앞으로 발사되듯 젖혀지는 현상을 방지합니다.',
        '강한 호흡과 함께 갈비뼈를 골반 쪽으로 끌어내려 코어 활성화를 유도합니다.',
        '하강 시 뒤꿈치에 쏠린 무게 중심을 발바닥 중앙(아치 부근)으로 미세하게 이동시켜, 체중이 뒤로 넘어가며 상체가 보상적으로 젖혀지는 패턴을 차단합니다.',
        '벽을 기준으로 머리와 등, 골반이 한 줄로 세워진 상태에서 하강하여, 상체가 뒤로 꺾이지 않고 위로 길게 유지되는 정렬 감각을 연습합니다.',
      ],
    },
    // ── 발목 발등굽힘 가동범위 ──────────────────────────────────
    'heel:NORMAL': {
      stateAnalysis: ['양쪽 발뒤꿈치가 바닥에 유지되며 발등굽힘이 정상적으로 나타납니다.'],
      movementPatternAnalysis: [
        '발목이 부드럽게 접히면서 무릎이 발끝 방향으로 자연스럽게 앞으로 이동함',
        '→엉덩이가 과도하게 뒤로 빠지지 않고, 상체가 세워진 상태에서 수직에 가까운 하강 패턴이 유지됨',
        '→엉덩이, 등, 복부가 함께 협응하여 허리가 꺾이거나 흔들리지 않는 안정적인 자세가 유지됨',
      ],
      optimizationStrategy: [
        '무릎이 발끝 라인을 넘어서는 지점에서 잠시 멈춰 발목 주변 근육의 버티는 힘을 강화하고 안정성을 정교화합니다.',
        '중량이 증가해도 상체 각도가 무너지지 않도록 코어 집중을 유지합니다.',
        'Single Leg Squat 등 비대칭 동작을 통해 안정성을 더욱 정교하게 발전시킵니다.',
      ],
    },
    'heel:HEEL_UNNORMAL': {
      stateAnalysis: ['스쿼트 하강 시 양쪽 발뒤꿈치가 들리며 발등굽힘에 제한이 나타납니다.'],
      movementPatternAnalysis: [
        '양쪽 발목 움직임을 충분히 활용하지 못한 상태에서 무릎 전진이 줄어들고 다른 보상 움직임이 동반되는 양상이 관찰됨',
        '→엉덩이가 뒤로 빠지며 무게중심이 후방으로 쏠리는 양상이 나타남',
        '→균형 유지를 위해 발뒤꿈치를 들어 무릎을 인위적으로 앞으로 보내는 패턴이 관찰됨',
      ],
      optimizationStrategy: [
        '뒤꿈치가 들리기 직전의 지점까지만 하강하며 발목 뒷부분 근육이 길게 늘어나는 장력을 인지하는 훈련을 반복합니다.',
        '무릎을 발끝 방향으로 넓게 열어 발목 관절 내부에 뼈가 움직일 수 있는 여유 공간을 확보함으로써, 정강이가 앞으로 더 깊게 숙여지도록 유도합니다.',
        '발등 전체를 위로 들어 올리려는 능동적인 힘을 주어 발목 앞쪽 근육을 활성화하고 가동 범위의 한계치를 높입니다.',
      ],
    },
    'heel:LEFT_HEEL_UNNORMAL': {
      stateAnalysis: ['오른쪽 발은 발등굽힘이 유지되며, 왼쪽 발에서 발뒤꿈치 들림으로 발등굽힘 제한이 나타납니다.'],
      movementPatternAnalysis: [
        '왼쪽 발목 움직임을 충분히 활용하지 못한 상태에서 무릎 전진이 줄어들고 다른 보상 움직임이 동반되는 양상이 관찰됨',
        '→균형 유지를 위해 왼쪽 뒤꿈치를 들어 무릎을 인위적으로 앞으로 보냄',
        '→지지 불안정으로 체중이 오른쪽으로 과도하게 이동하며 하체 비대칭 부하가 나타남',
      ],
      optimizationStrategy: [
        '왼쪽 엄지발가락 관절로 지면을 강하게 눌러 아치를 살림으로써, 발목이 안으로 무너지지 않고 정방향으로 깊게 굽혀질 수 있는 지지 기반을 구축합니다.',
        '왼쪽 엉덩관절을 오른쪽보다 더 깊게 접는다는 느낌으로 앉아, 발목이 뻣뻣해서 생기는 저항을 이겨내고 정강이가 앞으로 더 기울어지도록 능동적인 하중을 전달합니다.',
        '체중이 가동 범위가 넓은 오른쪽으로 쏠리지 않도록 왼쪽 뒤꿈치 바깥날에 무게 중심을 유지하여, 양쪽 하체의 수평 균형과 발목 가동 범위를 동시에 확보합니다.',
      ],
    },
    'heel:RIGHT_HEEL_UNNORMAL': {
      stateAnalysis: ['왼쪽 발은 발등굽힘이 유지되며, 오른쪽 발에서 발뒤꿈치 들림으로 발등굽힘 제한이 나타납니다.'],
      movementPatternAnalysis: [
        '오른쪽 발목 움직임을 충분히 활용하지 못한 상태에서 무릎 전진이 줄어들고 다른 보상 움직임이 동반되는 양상이 관찰됨',
        '→균형 유지를 위해 오른쪽 뒤꿈치를 들어 무릎을 인위적으로 앞으로 보냄',
        '→지지 불안정으로 체중이 왼쪽으로 과도하게 이동하며 하체 비대칭 부하가 나타남',
      ],
      optimizationStrategy: [
        '오른쪽 엄지발가락 관절로 지면을 강하게 눌러 아치를 살림으로써, 발목이 안으로 무너지지 않고 정방향으로 깊게 굽혀질 수 있는 지지 기반을 구축합니다.',
        '오른쪽 엉덩관절을 왼쪽보다 더 깊게 접는다는 느낌으로 앉아, 발목이 뻣뻣해서 생기는 저항을 이겨내고 정강이가 앞으로 더 기울어지도록 능동적인 하중을 전달합니다.',
        '체중이 가동 범위가 넓은 왼쪽으로 쏠리지 않도록 오른쪽 뒤꿈치 바깥날에 무게 중심을 유지하여, 양쪽 하체의 수평 균형과 발목 가동 범위를 동시에 확보합니다.',
      ],
    },
  };

