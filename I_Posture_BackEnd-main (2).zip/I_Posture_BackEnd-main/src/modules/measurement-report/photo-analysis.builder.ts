import { BodyDisplayMetrics } from '../analysis/helpers/body-display-metrics.helper';

const SIDE_THRESHOLD_PX = 5;

function lateralKo(pos: 'left' | 'right' | 'center'): string {
  if (pos === 'left') return '왼쪽';
  if (pos === 'right') return '오른쪽';
  return '중앙';
}

function hipDirLabel(dir: string): string {
  if (dir === '바깥') return '바깥';
  if (dir === '안쪽') return '안쪽';
  return '중앙';
}

function hipStateLabel(dir: string): string {
  return hipDirLabel(dir) === '중앙' ? '바르게 정렬된' : '회전된';
}

export function buildPhotoAnalysisContent(
  metrics: BodyDisplayMetrics,
  scoreDetail: any,
  files: any[],
  landmarks: any,
  getStatusColor: (score: number) => string,
  scoreOrDefault: (...values: any[]) => number,
) {
  const { back: bm, front: fm, side: sm } = metrics;

  const pelvisPosBullet = bm.hasLandmarks
    ? `골반은 몸의 중심선을 기준으로 <b>${lateralKo(bm.pelvisPosition)}</b>에 위치해 있습니다.`
    : '골반 위치 데이터를 확인할 수 없습니다.';

  const torsoAlignBullet = bm.hasLandmarks
    ? `골반 위치에 맞추어 균형을 유지하려는 과정에서 \n몸통이 골반을 기준으로 <b>${lateralKo(bm.torsoAlignment)}</b>으로 정렬되어 있습니다.`
    : '몸통 정렬 데이터를 확인할 수 없습니다.';

  const lr = scoreDetail.balanceIndex?.leftRightBalanceIndex?.balance ?? 'normal';
  const fb = scoreDetail.balanceIndex?.frontBackBalanceIndex?.balance ?? 'normal';
  const WEIGHT_CENTER_TEXT: Record<string, string> = {
    normal_normal: '체중심의 위치는 <b>중앙</b>에 놓여 있습니다.',
    normal_left: '체중심의 위치는 <b>왼쪽</b>에 놓여 있습니다.',
    normal_right: '체중심의 위치는 <b>오른쪽</b>에 놓여 있습니다.',
    front_normal: '체중심의 위치는 <b>앞</b>에 놓여 있습니다.',
    back_normal: '체중심의 위치는 <b>뒤</b>에 놓여 있습니다.',
    front_left: '체중심의 위치는 <b>앞</b>, <b>왼쪽</b>에 놓여 있습니다.',
    front_right: '체중심의 위치는 <b>앞</b>, <b>오른쪽</b>에 놓여 있습니다.',
    back_left: '체중심의 위치는 <b>뒤</b>, <b>왼쪽</b>에 놓여 있습니다.',
    back_right: '체중심의 위치는 <b>뒤</b>, <b>오른쪽</b>에 놓여 있습니다.',
  };
  const weightCenterBullet = WEIGHT_CENTER_TEXT[`${fb}_${lr}`] ?? WEIGHT_CENTER_TEXT.normal_normal;
  const backBullets = [weightCenterBullet, pelvisPosBullet, torsoAlignBullet];

  const { neckTilt, neckRotation, shoulderAsymmetry, raisedDropped, pelvisAsymmetry, pelvisRotation, hipRotation, legs } = fm;

  const neckTiltBullet =
    neckTilt.direction === '왼쪽'
      ? `목의 기울기가 <b>왼쪽</b>으로 <b>${neckTilt.displayAngle.toFixed(0)}도</b> 가쪽굽힘되어 있습니다.`
      : neckTilt.direction === '오른쪽'
        ? `목의 기울기가 <b>오른쪽</b>으로 <b>${neckTilt.displayAngle.toFixed(0)}도</b> 가쪽굽힘되어 있습니다.`
        : '목이 <b>중앙</b>으로 <b>회전없이 바르게 정렬</b>되어 있습니다.';

  const neckRotBullet =
    neckRotation.direction === '오른쪽'
      ? `목이 <b>오른쪽</b>으로 <b>${neckRotation.angle.toFixed(0)}</b>도 회전되어 있습니다.`
      : neckRotation.direction === '왼쪽'
        ? `목이 <b>왼쪽</b>으로 <b>${neckRotation.angle.toFixed(0)}</b>도 회전되어 있습니다.`
        : '목이 <b>중앙</b>으로 <b>회전없이 바르게 정렬</b>되어 있습니다.';

  const shoulderAsymAngle = shoulderAsymmetry.displayAngle;
  const shoulderAsymStatus = shoulderAsymmetry.status;
  let shoulderHeightBullet: string;
  if (shoulderAsymAngle.toFixed(0) === '0') {
    shoulderHeightBullet = '오른쪽 어깨는 왼쪽 어깨에 비해 <b>약 0</b>도 정도 <b>동일한</b> 위치에 있는 상태입니다.';
  } else if (shoulderAsymStatus === '낮은') {
    shoulderHeightBullet = `오른쪽 어깨는 왼쪽 어깨에 비해 <b>약 ${shoulderAsymAngle.toFixed(0)}</b>도 정도 <b>낮은</b> 위치에 있는 상태입니다.`;
  } else if (shoulderAsymStatus === '높은') {
    shoulderHeightBullet = `오른쪽 어깨는 왼쪽 어깨에 비해 <b>약 ${shoulderAsymAngle.toFixed(0)}</b>도 정도 <b>높은</b> 위치에 있는 상태입니다.`;
  } else {
    shoulderHeightBullet = `오른쪽 어깨는 왼쪽 어깨에 비해 <b>약 ${shoulderAsymAngle.toFixed(0)}</b>도 정도 <b>동일한</b> 위치에 있는 상태입니다.`;
  }

  const shoulderBullets: string[] = [shoulderHeightBullet];
  if (
    raisedDropped.leftState &&
    raisedDropped.rightState &&
    raisedDropped.leftState !== '양호한' &&
    raisedDropped.rightState !== '양호한'
  ) {
    shoulderBullets.push(
      `오른쪽 어깨는 높이가 <b>${raisedDropped.rightState}</b> 어깨, 왼쪽 어깨는 높이가 <b>${raisedDropped.leftState}</b> 어깨일 가능성이 높습니다.`,
    );
  }

  const pelvisAsymAngle = pelvisAsymmetry.displayAngle;
  const pelvisAsymStatus = pelvisAsymmetry.status;
  const pelvisHeightBullet =
    pelvisAsymStatus === '올라간'
      ? `오른쪽 골반은 왼쪽 골반과 비교했을 때 <b>약 ${pelvisAsymAngle.toFixed(0)}</b>도 정도로 높이가 <b>올라간</b> 상태입니다.`
      : pelvisAsymStatus === '내려간'
        ? `오른쪽 골반은 왼쪽 골반과 비교했을 때 <b>약 ${pelvisAsymAngle.toFixed(0)}</b>도 정도로 높이가 <b>내려간</b> 상태입니다.`
        : '오른쪽 골반은 왼쪽 골반과 비교했을 때 높이 차이 없이 <b>동일한</b> 상태입니다.';

  const pelvisRotBullet =
    pelvisRotation.direction === '오른쪽'
      ? `골반 회전은 <b>오른쪽</b>으로 <b>${pelvisRotation.angle.toFixed(0)}도 회전 </b>되어 있는 것으로 추정됩니다.`
      : pelvisRotation.direction === '왼쪽'
        ? `골반 회전은 <b>왼쪽</b>으로 <b>${pelvisRotation.angle.toFixed(0)}도 회전 </b>되어 있는 것으로 추정됩니다.`
        : '골반이 중앙으로 <b>바르게</b> 정렬되어 있는 것으로 추정됩니다.';

  const hipBullets = [
    `왼쪽 엉덩관절은 <b>${hipDirLabel(hipRotation.leftDir)}</b> 방향으로 <b>${hipStateLabel(hipRotation.leftDir)}</b> 상태입니다.`,
    `오른쪽 엉덩관절은 <b>${hipDirLabel(hipRotation.rightDir)}</b> 방향으로 <b>${hipStateLabel(hipRotation.rightDir)}</b> 상태입니다.`,
  ];

  const rightLegLine = legs.right.status
    ? `정면에서 본 <b>오른쪽 하지 정렬</b>은 <b>${legs.right.status}</b> 경향을 보이며,\n 골반-무릎-발목 각도는 기준 각도 <b>180도</b>에서 <b>약 ${Math.round(legs.right.diff)}도</b> 차이 수준으로 관찰됩니다.`
    : '정면에서 본 <b>오른쪽 하지 정렬</b>은 데이터를 확인할 수 없습니다.';
  const leftLegLine = legs.left.status
    ? `정면에서 본 <b>왼쪽 하지 정렬</b>은 <b>${legs.left.status}</b> 경향을 보이며,\n 골반-무릎-발목 각도는 기준 각도 <b>180도</b>에서 <b>약 ${Math.round(legs.left.diff)}도</b> 차이 수준으로 관찰됩니다.`
    : '정면에서 본 <b>왼쪽 하지 정렬</b>은 데이터를 확인할 수 없습니다. \n (정상 각도: 180도에서 약 ±5° 범위)';

  const frontSections = [
    {
      title: '목',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.neck?.neckTilt?.scoreUsage, scoreDetail.neck?.neckRotation?.scoreUsage)),
      bullets: [neckTiltBullet, neckRotBullet],
    },
    {
      title: '어깨높이',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.shoulder?.shoulderHeightAsymmetry?.scoreUsage)),
      bullets: shoulderBullets,
    },
    {
      title: '골반',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.pelvis?.pelvisAsymmetry?.scoreUsage, scoreDetail.pelvis?.pelvisRotate?.scoreUsage, scoreDetail.pelvis?.pelvisRotation?.scoreUsage)),
      bullets: [pelvisHeightBullet, pelvisRotBullet],
    },
    {
      title: '엉덩관절',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.scoreUsage, scoreDetail.lowerLimbAlignment?.legRotate?.scoreUsage)),
      bullets: hipBullets,
    },
    {
      title: '하지 정렬',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.scoreUsage, scoreDetail.knee?.backKnees?.scoreUsage, scoreDetail.knee?.bentKnees?.scoreUsage)),
      bullets: [rightLegLine, leftLegLine],
    },
  ];

  const pelvisSidePosLabel = sm.pelvisSidePosition;
  const sidePelvisDistanceDisplay = sm.pelvisDistanceSigned;
  const sidePelvisDistanceText = Math.abs(sidePelvisDistanceDisplay);
  const pelvisPosSentence = `골반은 몸의 중심을 기준으로 <b>${pelvisSidePosLabel}</b> 위치에 있으며,\n 중심선과의 거리는 <b>약 ${sidePelvisDistanceText}mm</b> 수준입니다.`;
  const overallBullet = `${pelvisPosSentence}\n\n 그로 인해 몸통은 골반을 기준으로\n <b>${sm.trunkRelative}</b> 위치에 있는 모습으로 나타납니다.`;

  const sideNeckBullet = `머리는 어깨를 기준으로 <b>${sm.neck.positionLabel}</b>에 있으며, \n어깨와의 각도 차이는 <b>약 ${sm.neck.angle.toFixed(0)}도</b> 정도로 관찰됩니다.`;

  const shoulderPosLabel = sm.shoulder.positionLabel;
  const shoulderSideBullet = `어깨는 몸의 중심선을 기준으로 <b>${shoulderPosLabel}</b> 위치에 있으며, \n중심선과의 거리는 <b>약 ${sm.shoulder.distance.toFixed(0)}mm</b> 수준으로 관찰됩니다.`;

  const pelvisTiltAngleForText = sm.pelvisTilt.status.includes('중립') ? 0 : Math.abs(sm.pelvisTilt.angle);
  const sidePelvisBullet = `골반은 기준 대비 <b>약 ${pelvisTiltAngleForText.toFixed(0)}도</b>의 기울임을 보이며,\n <b>${sm.pelvisTilt.label}</b> 상태로 관찰됩니다.`;

  const kneeStatus = sm.knee.status;
  const sideKneeBullet =
    kneeStatus === '굽혀진'
      ? '무릎은 <b>굽혀진</b> 상태로 나타납니다.'
      : kneeStatus === '과하게 펴진'
        ? '무릎은 <b>과하게 펴진</b> 상태로 나타납니다.'
        : '무릎은 <b>중립</b> 상태로 나타납니다.';

  const sideSections = [
    {
      title: '전체',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.pelvis?.pelvisTilt?.scoreUsage, scoreDetail.pelvis?.isSwayBack?.scoreUsage)),
      bullets: [overallBullet],
    },
    {
      title: '목',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.neck?.neckTurtleRaised?.scoreUsage, scoreDetail.neck?.straightNeck?.scoreUsage)),
      bullets: [sideNeckBullet],
    },
    {
      title: '어깨',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.shoulder?.shoulderPosition?.scoreUsage)),
      bullets: [shoulderSideBullet],
    },
    {
      title: '골반',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.pelvis?.pelvisTilt?.scoreUsage)),
      bullets: [sidePelvisBullet],
    },
    {
      title: '무릎',
      levelColor: getStatusColor(scoreOrDefault(scoreDetail.knee?.kneesBentOrBack?.scoreUsage)),
      bullets: [sideKneeBullet],
    },
  ];

  const neckTiltDir = neckTilt.direction;
  const neckTiltAngle = neckTilt.displayAngle;
  const tipEarLeft = neckTiltDir === '왼쪽' ? -neckTiltAngle : neckTiltDir === '오른쪽' ? +neckTiltAngle : 0;
  const tipEarRight = neckTiltDir === '왼쪽' ? +neckTiltAngle : neckTiltDir === '오른쪽' ? -neckTiltAngle : 0;

  const tipShLeft = shoulderAsymStatus === '낮은' ? +shoulderAsymAngle : shoulderAsymStatus === '높은' ? -shoulderAsymAngle : 0;
  const tipShRight = shoulderAsymStatus === '낮은' ? -shoulderAsymAngle : shoulderAsymStatus === '높은' ? +shoulderAsymAngle : 0;

  const tipPlLeft = pelvisAsymStatus === '내려간' ? +pelvisAsymAngle : pelvisAsymStatus === '올라간' ? -pelvisAsymAngle : 0;
  const tipPlRight = pelvisAsymStatus === '내려간' ? -pelvisAsymAngle : pelvisAsymStatus === '올라간' ? +pelvisAsymAngle : 0;

  const tipLegRight = legs.right.angle;
  const tipLegLeft = legs.left.angle;

  const neckAngle = sm.neck.angle;
  const earAnkleDiff = sm.neck.earAnkleDiff;
  const neckSidePosLabel = sm.neck.positionLabel;
  const tipSideNeckAngle = earAnkleDiff !== null
    ? (earAnkleDiff > SIDE_THRESHOLD_PX ? +neckAngle : earAnkleDiff < -SIDE_THRESHOLD_PX ? -neckAngle : 0)
    : (neckSidePosLabel === '앞쪽' ? +neckAngle : neckSidePosLabel === '뒤쪽' ? -neckAngle : 0);

  const shoulderPosDist = sm.shoulder.distance;
  const tipSideShDist =
    shoulderPosLabel === '앞' ? +shoulderPosDist
      : shoulderPosLabel === '뒤' ? -shoulderPosDist
        : 0;
  const tipSideShKeyword = shoulderPosLabel === '앞' ? 'Front' : shoulderPosLabel === '뒤' ? 'Back' : 'Neutral';

  const pelvisTiltStatus = sm.pelvisTilt.status;
  const pelvisTiltAngle = sm.pelvisTilt.angle;
  const tipSidePelvisAngle = pelvisTiltStatus.includes('앞')
    ? +Math.abs(pelvisTiltAngle)
    : pelvisTiltStatus.includes('뒤')
      ? -Math.abs(pelvisTiltAngle)
      : 0;
  const tipSidePelvisKeyword = pelvisTiltStatus.includes('앞')
    ? 'ATA'
    : pelvisTiltStatus.includes('뒤')
      ? 'PTA'
      : 'Neutral';

  const rightKneeRawAngle = sm.knee.rightAngle;

  const roundAbs = (v: number) => Math.sign(v) * Math.round(Math.abs(v));

  const frontLmRaw = landmarks?.front || {};
  const tipFootLeft = (frontLmRaw.LeftFootIndex && frontLmRaw.LeftAnkle)
    ? parseFloat((Math.atan2(
      Math.abs(frontLmRaw.LeftFootIndex.x - frontLmRaw.LeftAnkle.x),
      Math.abs(frontLmRaw.LeftFootIndex.y - frontLmRaw.LeftAnkle.y),
    ) * (180 / Math.PI)).toFixed(1))
    : null;
  const tipFootRight = (frontLmRaw.RightFootIndex && frontLmRaw.RightAnkle)
    ? parseFloat((Math.atan2(
      Math.abs(frontLmRaw.RightFootIndex.x - frontLmRaw.RightAnkle.x),
      Math.abs(frontLmRaw.RightFootIndex.y - frontLmRaw.RightAnkle.y),
    ) * (180 / Math.PI)).toFixed(1))
    : null;

  const frontTooltips = {
    guide: '해당 표시는 틀어짐 각도입니다.\n+는 올라간 쪽 / -는 내려간 쪽을 나타냅니다.',
    points: [
      { part: '귀', left: roundAbs(tipEarLeft), right: roundAbs(tipEarRight) },
      { part: '어깨', left: roundAbs(tipShLeft), right: roundAbs(tipShRight) },
      { part: '엉덩이', left: roundAbs(tipPlLeft), right: roundAbs(tipPlRight) },
      { part: '다리', left: roundAbs(tipLegLeft), right: roundAbs(tipLegRight) },
    ],
  };

  const sideTooltips = {
    guide: '귀 각도: 거북목 정도 / 골반 각도: +는 전방경사, -는 후방경사\n무릎 각도: +는 굽은 무릎, -는 과도하게 펴진 무릎\nmm: 중심선(빨간색)으로부터 떨어진 거리',
    points: [
      { part: '귀', angle: roundAbs(tipSideNeckAngle), distance: null, keyword: null },
      { part: '어깨', angle: null, distance: roundAbs(tipSideShDist), keyword: tipSideShKeyword },
      { part: '엉덩이', angle: roundAbs(tipSidePelvisAngle), distance: sidePelvisDistanceDisplay, keyword: tipSidePelvisKeyword },
      {
        part: '무릎',
        angle: roundAbs(180 - rightKneeRawAngle),
        distance: null,
        keyword: kneeStatus === '굽혀진' ? 'Bent' : kneeStatus === '과하게 펴진' ? 'Back' : 'Neutral',
      },
    ],
  };

  const backTooltips = {
    guide: '머리 중심(민트색)이 중심선(빨간색)과 일치하지 않으면 몸이 기울어진 상태입니다.\n틀어짐 각도에서 +는 올라간 쪽, -는 내려간 쪽을 나타냅니다.',
    points: [
      { part: '중심선', center: 0, left: null, right: null },
      { part: '귀', center: null, left: roundAbs(tipEarLeft), right: roundAbs(tipEarRight) },
      { part: '어깨', center: null, left: roundAbs(tipShLeft), right: roundAbs(tipShRight) },
      { part: '엉덩이', center: null, left: roundAbs(tipPlLeft), right: roundAbs(tipPlRight) },
      { part: '발', center: null, left: tipFootLeft !== null ? roundAbs(tipFootLeft) : null, right: tipFootRight !== null ? roundAbs(tipFootRight) : null },
    ],
  };

  return {
    title: '체형 사진 분석',
    back: {
      image: { url: files.find((f) => f.division === 'BACK')?.fileUrl || null, assetKey: 'PHOTO_BACK' },
      panelTitle: '후면 상세 분석',
      bullets: backBullets,
      tooltips: backTooltips,
    },
    front: {
      image: { url: files.find((f) => f.division === 'FRONT')?.fileUrl || null, assetKey: 'PHOTO_FRONT' },
      panelTitle: '정면 상세 분석',
      sections: frontSections,
      tooltips: frontTooltips,
    },
    side: {
      image: { url: files.find((f) => f.division === 'SIDE')?.fileUrl || null, assetKey: 'PHOTO_SIDE' },
      panelTitle: '측면 상세 분석',
      sections: sideSections,
      tooltips: sideTooltips,
    },
  };
}
