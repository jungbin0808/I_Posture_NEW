import {
  Controller,
  Get,
  Headers,
  Param,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiResponse, ApiHeader } from '@nestjs/swagger';
import { MeasurementReportService } from './measurement-report.service';
import { BodyMeasurementReportResponseDto } from './dto/measurement-report-response.dto';
import { resolveReportDisplayLanguage } from '../../common/helpers/resolve-report-display-language.helper';
import { SpineAlignmentReportResponseDto } from './dto/spine-alignment-report-response.dto';
import { BalanceSenseReportResponseDto } from './dto/balance-sense-report-response.dto';
import { JointRomReportResponseDto } from './dto/joint-rom-report-response.dto';
import { FullBodyFunctionReportResponseDto } from './dto/full-body-function-report-response.dto';
import { RecommendedPrecisionPartsResponseDto } from './dto/recommended-precision-parts.dto';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';

/**
 * 공개 체형리포트 - 인증 불필요 (공유 링크)
 */
@ApiTags('Measurement Report')
@Controller('measurement-reports')
export class PublicMeasurementReportController {
  constructor(private readonly measurementReportService: MeasurementReportService) {}

  /**
   * @summary 체형측정 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Body Measurement Report Detail (Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '체형측정 리포트 상세', type: BodyMeasurementReportResponseDto })
  @Get('member/:memberId/body-measurement/:id')
  async getBodyMeasurementReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<BodyMeasurementReportResponseDto> {
    return this.measurementReportService.getBodyMeasurementReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  /**
   * @summary 척추정렬검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Spinal Alignment Report Detail (Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '척추정렬검사 리포트 상세', type: SpineAlignmentReportResponseDto })
  @Get('member/:memberId/spinal-alignment/:id')
  async getSpineAlignmentReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<SpineAlignmentReportResponseDto> {
    return this.measurementReportService.getSpineAlignmentReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  /**
   * @summary 균형감각검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Balance Test Report Detail (Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '균형감각검사 리포트 상세', type: BalanceSenseReportResponseDto })
  @Get('member/:memberId/balance-test/:id')
  async getBalanceSenseReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<BalanceSenseReportResponseDto> {
    return this.measurementReportService.getBalanceSenseReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  /**
   * @summary 관절별 가동범위 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Joint Range of Motion Report Detail (Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '관절별 가동범위 리포트 상세', type: JointRomReportResponseDto })
  @Get('member/:memberId/joint-rom/:id')
  async getJointRomReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<JointRomReportResponseDto> {
    return this.measurementReportService.getJointRomReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  /**
   * @summary 전신기능검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Overhead Squat Report Detail (Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '전신기능검사 리포트 상세', type: FullBodyFunctionReportResponseDto })
  @Get('member/:memberId/overhead-squat/:id')
  async getFullBodyFunctionReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<FullBodyFunctionReportResponseDto> {
    return this.measurementReportService.getFullBodyFunctionReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }
}

/**
 * 센터용 공개 측정 리포트 — 인증 불필요 (공유 링크)
 * PublicMeasurementReportController와 완전히 동일한 서비스 로직을 재사용하는
 * /center/* 라우트. memberId 검증은 서비스 레벨에서 이미 수행됨.
 */
@ApiTags('Center Measurement Report Public')
@Controller('center/measurement-reports/public')
export class CenterMeasurementReportPublicController {
  constructor(private readonly measurementReportService: MeasurementReportService) {}

  @ApiOperation({ summary: 'Get Body Measurement Report Detail (Center / Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '체형측정 리포트 상세', type: BodyMeasurementReportResponseDto })
  @Get('member/:memberId/body-measurement/:id')
  async getBodyMeasurementReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<BodyMeasurementReportResponseDto> {
    return this.measurementReportService.getBodyMeasurementReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  @ApiOperation({ summary: 'Get Spinal Alignment Report Detail (Center / Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '척추정렬검사 리포트 상세', type: SpineAlignmentReportResponseDto })
  @Get('member/:memberId/spinal-alignment/:id')
  async getSpineAlignmentReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<SpineAlignmentReportResponseDto> {
    return this.measurementReportService.getSpineAlignmentReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  @ApiOperation({ summary: 'Get Balance Test Report Detail (Center / Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '균형감각검사 리포트 상세', type: BalanceSenseReportResponseDto })
  @Get('member/:memberId/balance-test/:id')
  async getBalanceSenseReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<BalanceSenseReportResponseDto> {
    return this.measurementReportService.getBalanceSenseReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  @ApiOperation({ summary: 'Get Joint Range of Motion Report Detail (Center / Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '관절별 가동범위 리포트 상세', type: JointRomReportResponseDto })
  @Get('member/:memberId/joint-rom/:id')
  async getJointRomReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<JointRomReportResponseDto> {
    return this.measurementReportService.getJointRomReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }

  @ApiOperation({ summary: 'Get Overhead Squat Report Detail (Center / Public)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @ApiResponse({ status: 200, description: '전신기능검사 리포트 상세', type: FullBodyFunctionReportResponseDto })
  @Get('member/:memberId/overhead-squat/:id')
  async getFullBodyFunctionReport(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<FullBodyFunctionReportResponseDto> {
    return this.measurementReportService.getFullBodyFunctionReport(
      memberId,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
  }
}

/**
 * 인증이 필요한 측정 리포트 API
 */
@ApiTags('Measurement Report')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('measurement-reports')
export class MeasurementReportController {
  constructor(private readonly measurementReportService: MeasurementReportService) {}

  /**
   * @summary 정밀측정 추천 부위 조회 (최신 체형리포트 기준)
   */
  @ApiOperation({ summary: 'Get Recommended Precision Measurement Parts based on Latest Body Report' })
  @ApiResponse({ status: 200, description: '추천 정밀측정 부위 목록', type: RecommendedPrecisionPartsResponseDto })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/recommended-precision-parts')
  async getRecommendedPrecisionParts(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query('bodyReportId') bodyReportId?: string,
  ): Promise<RecommendedPrecisionPartsResponseDto> {
    return this.measurementReportService.getRecommendedPrecisionParts(req.user.id, memberId, bodyReportId);
  }

  /**
   * @summary 체형측정 리포트 영문 payload 생성·저장 (Google Translate)
   */
  @ApiOperation({ summary: 'Generate and persist English body measurement report payload' })
  @ApiResponse({
    status: 200,
    description: '영문 리포트 payload (display_payload_en 저장 완료)',
    type: BodyMeasurementReportResponseDto,
  })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/body-measurement/:id/translate-en')
  async generateBodyMeasurementEnglishPayload(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<BodyMeasurementReportResponseDto>> {
    const data = await this.measurementReportService.generateAndPersistBodyReportEnglishPayload(
      req.user.id,
      memberId,
      id,
    );
    return SuccessResponse(data);
  }

  /**
   * @summary 척추정렬검사 리포트 영문 payload 생성·저장 (Google Translate)
   */
  @ApiOperation({ summary: 'Generate and persist English spinal alignment report payload' })
  @ApiResponse({
    status: 200,
    description: '영문 리포트 payload (display_payload_en 저장 완료)',
    type: SpineAlignmentReportResponseDto,
  })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/spinal-alignment/:id/translate-en')
  async generateSpinalAlignmentEnglishPayload(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<SpineAlignmentReportResponseDto>> {
    const data = await this.measurementReportService.generateAndPersistSpineAlignmentEnglishPayload(
      req.user.id,
      memberId,
      id,
    );
    return SuccessResponse(data);
  }

  /**
   * @summary 균형감각검사 리포트 영문 payload 생성·저장 (Google Translate)
   */
  @ApiOperation({ summary: 'Generate and persist English balance test report payload' })
  @ApiResponse({
    status: 200,
    description: '영문 리포트 payload (display_payload_en 저장 완료)',
    type: BalanceSenseReportResponseDto,
  })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/balance-test/:id/translate-en')
  async generateBalanceTestEnglishPayload(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<BalanceSenseReportResponseDto>> {
    const data = await this.measurementReportService.generateAndPersistBalanceSenseEnglishPayload(
      req.user.id,
      memberId,
      id,
    );
    return SuccessResponse(data);
  }

  /**
   * @summary 관절별 가동범위 리포트 영문 payload 생성·저장 (Google Translate)
   */
  @ApiOperation({ summary: 'Generate and persist English joint ROM report payload' })
  @ApiResponse({
    status: 200,
    description: '영문 리포트 payload (display_payload_en 저장 완료)',
    type: JointRomReportResponseDto,
  })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/joint-rom/:id/translate-en')
  async generateJointRomEnglishPayload(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<JointRomReportResponseDto>> {
    const data = await this.measurementReportService.generateAndPersistJointRomEnglishPayload(
      req.user.id,
      memberId,
      id,
    );
    return SuccessResponse(data);
  }

  /**
   * @summary 전신기능검사 리포트 영문 payload 생성·저장 (Google Translate)
   */
  @ApiOperation({ summary: 'Generate and persist English overhead squat report payload' })
  @ApiResponse({
    status: 200,
    description: '영문 리포트 payload (display_payload_en 저장 완료)',
    type: FullBodyFunctionReportResponseDto,
  })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/overhead-squat/:id/translate-en')
  async generateOverheadSquatEnglishPayload(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FullBodyFunctionReportResponseDto>> {
    const data = await this.measurementReportService.generateAndPersistFullBodyFunctionEnglishPayload(
      req.user.id,
      memberId,
      id,
    );
    return SuccessResponse(data);
  }
}

