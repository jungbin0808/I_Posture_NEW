/**
 * 체형 사진 상세분석 워딩 → 뼈대 이미지 매칭용 분류
 * body-display-metrics.helper와 동일한 랜드마크 기반 판단을 사용합니다.
 */

import {
  metricsToSkeletonWording,
  resolveBodyDisplayMetrics,
} from '../analysis/helpers/body-display-metrics.helper';

export type SkeletonPelvisMove = 'right' | 'left' | 'center';
export type SkeletonShoulderAsym = 'left_high' | 'right_high' | 'normal';
export type SkeletonLegType = 'knock' | 'bow' | 'normal';
export type SkeletonPelvisTilt = 'forward' | 'backward' | 'normal';
export type SkeletonKneeType = 'bent' | 'back' | 'normal';

export interface SkeletonWording {
  pelvisMove: SkeletonPelvisMove;
  shoulderAsym: SkeletonShoulderAsym;
  legType: SkeletonLegType;
  hasSwayback: boolean;
  pelvisTilt: SkeletonPelvisTilt;
  kneeType: SkeletonKneeType;
}

export function resolveSkeletonWording(analysisData: any): SkeletonWording {
  const metrics = resolveBodyDisplayMetrics(analysisData?.landmarks, analysisData?.scoreDetail);
  return metricsToSkeletonWording(metrics) as SkeletonWording;
}
