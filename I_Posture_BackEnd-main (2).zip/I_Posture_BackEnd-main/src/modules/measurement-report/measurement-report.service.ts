import { Injectable, OnModuleInit, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { UserEntity, Gender } from '../../database/entities/user.entity';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';
import { BodyMeasurementReportResponseDto } from './dto/measurement-report-response.dto';
import { RecommendedPrecisionPartsResponseDto } from './dto/recommended-precision-parts.dto';
import { SpineAlignmentReportResponseDto } from './dto/spine-alignment-report-response.dto';
import { BalanceSenseReportResponseDto } from './dto/balance-sense-report-response.dto';
import { JointRomReportResponseDto } from './dto/joint-rom-report-response.dto';
import { FullBodyFunctionReportResponseDto } from './dto/full-body-function-report-response.dto';
import { SPINAL_ALIGNMENT, BALANCE_ALIGNMENT } from '../analysis/analysis.constants';
import {
  BODY_PART_SCORE_KEYS,
  calculateBodyPartScoreFromDetail,
} from '../analysis/helpers/body-score-usage.helper';
import { resolveBodyDisplayMetrics } from '../analysis/helpers/body-display-metrics.helper';
import { resolvePelvicReaction } from '../analysis/helpers/pelvic-reaction.helper';
import {
  estimateHorizontalPxPerCm,
  formatCenterShiftDistanceCm,
  formatCenterShiftMetricLabel,
} from '../analysis/helpers/spinal-alignment-display.helper';
import { calculateHeightLossCm } from '../analysis/helpers/height-loss.helper';
import { calculateNeckLoadFromLandmarks } from '../analysis/helpers/neck-load.helper';
import { buildPhotoAnalysisContent } from './photo-analysis.builder';
import { resolveCenterLogoUrl } from './helpers/resolve-center-logo-url.helper';
import { BodyReportTranslationService } from '../report-translation/body-report-translation.service';
import { PrecisionReportTranslationService } from '../report-translation/precision-report-translation.service';
import { resolveSkeletonWording } from './skeleton-wording.helper';
import { rankBodyDiseases, DISCOMFORT_TO_FUNCTIONAL_CHANGE, pickRandom, BODY_TYPE_DISCOMFORT_LIST, DISEASE_KEY_NORMALIZATION } from '../consultation-log/action-plan.helper';
import {
  TOTAL_SCORE_STAGE_RULES,
  MUSCLE_IMBALANCE_MAP,
  OHT_CASE_DB,
  SPINAL_IMG_BASE,
  BALANCE_IMG_BASE,
  OVERHEAD_SQUAT_IMG_BASE,
  JOINT_ROM_IMG_BASE,
  JOINT_ROM_ICON_BASE,
  MUSCLE_MAP_IMG_BASE,
  SKELETON_IMG_BASE,
  RECOMMENDED_HABITS_IMG_BASE,
  HEIGHT_LOSS_IMG_BASE,
  BODY_BALANCE_IMG_BASE,
  BODY_POSTURE_ICON_IMG_BASE,
  ROM_CAUSE_IMAGE_NUMBER_BY_TITLE,
  HEIGHT_LOSS_THRESHOLDS,
  CAUTION_HABITS_BY_POSTURE_KO,
  DISEASE_KEY_TO_POSTURE_KO,
  POSTURE_IMAGE_NUMBER_MAP,
  POSTURE_CARD_LABEL_MAP,
  POSTURE_IMPRESSION_MAP,
  IMPRESSION_TO_IMPROVEMENT,
  POSTURE_DISCOMFORT_MAP,
  POSTURE_SYMPTOM_IMPROVEMENTS,
  MANAGEMENT_RECOMMENDATION_BY_SCORE,
  BALANCE_STATE_RULES,
  BODY_PART_SCORE_STAGE_RULES,
  MUSCLE_BALANCE_DB,
  SCENARIO_DB,
  EXERCISE_CASE_DB,
  FRONT_PATTERN_DB,
  OHT_IMG_BASE,
  REAR_PATTERN_DB,
  JOINT_ROM_CONTENT_DB,
  SIDE_PATTERN_DB,
} from './measurement-report.constants';

@Injectable()
export class MeasurementReportService implements OnModuleInit {
  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly bodyReportTranslationService: BodyReportTranslationService,
    private readonly precisionReportTranslationService: PrecisionReportTranslationService,
  ) {}

  onModuleInit() {
    this.validateAnkleDbConsistency();
  }

  /**
   * 리포트 GET(accept-language: en) 시 display_payload_en 이 없을 때 자동 번역·저장.
   * 운영 배포 전까지 false 유지 (미설정 시 false). 로컬/개발만 REPORT_EN_AUTO_TRANSLATE_ON_GET=true.
   */
  private isReportEnAutoTranslateOnGetEnabled(): boolean {
    return process.env.REPORT_EN_AUTO_TRANSLATE_ON_GET === 'true';
  }

  private async resolveCenterLogoUrl(trainerId?: string | null): Promise<string | null> {
    return resolveCenterLogoUrl(trainerId, {
      centerRepo: this.centerRepo,
      centerTrainerRepo: this.centerTrainerRepo,
    });
  }

  private async withCenterLogo<T>(
    payload: T,
    trainerId?: string | null,
  ): Promise<T & { centerLogoUrl: string | null }> {
    const centerLogoUrl = await this.resolveCenterLogoUrl(trainerId);
    return { ...payload, centerLogoUrl };
  }

  /**
   * 앱회원(A) ID → 연동된 트레이너가 관리하는 관리회원(C) ID.
   * 공유 리포트 조회 시 URL 의 :memberId 가 트레이너 측정 리포트의 실제 소유자(관리회원)와
   * 다를 수 있어(회원 앱은 앱회원 ID만 앎) 매핑을 거쳐야 함.
   */
  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({
      where: { appMemberId, status: IdentityLinkStatus.LINKED },
    });
    return link?.managedMemberId ?? null;
  }

  /**
   * 공유 리포트 조회용 :memberId 매핑. 넘어온 memberId 로 바로 리포트를 찾으면 그대로 쓰고
   * (트레이너 공유 - 관리회원 ID / 셀프측정 회원 공유 - 앱회원 ID 모두 이 경우),
   * 못 찾으면 넘어온 값을 앱회원 ID 로 간주해 연동된 관리회원 ID 로 재시도한다
   * (트레이너가 측정한 리포트를 회원 앱에서 공유하는 경우).
   */
  private async resolveShareableBodyReportMemberId(memberId: string, reportId: string): Promise<string> {
    const exists = await this.bodyReportRepo.existsBy({ id: reportId, userId: memberId });
    if (exists) return memberId;

    const managedMemberId = await this.resolveManagedMemberId(memberId);
    if (managedMemberId) {
      const existsViaLink = await this.bodyReportRepo.existsBy({ id: reportId, userId: managedMemberId });
      if (existsViaLink) return managedMemberId;
    }
    return memberId;
  }

  private async resolveSharablePrecisionReportMemberId(memberId: string, reportId: string): Promise<string> {
    const exists = await this.precisionReportRepo.existsBy({ id: reportId, userId: memberId });
    if (exists) return memberId;

    const managedMemberId = await this.resolveManagedMemberId(memberId);
    if (managedMemberId) {
      const existsViaLink = await this.precisionReportRepo.existsBy({ id: reportId, userId: managedMemberId });
      if (existsViaLink) return managedMemberId;
    }
    return memberId;
  }

  private async withCenterLogoForBodyReport<T>(
    memberId: string,
    reportId: string,
    payload: T,
  ): Promise<T & { centerLogoUrl: string | null }> {
    const report = await this.bodyReportRepo.findOne({
      where: { id: reportId, userId: memberId },
      select: ['id', 'trainerId'],
    });
    if (!report) {
      throw new NotFoundException('체형측정 리포트를 찾을 수 없습니다.');
    }

    return this.withCenterLogo(payload, report.trainerId);
  }

  private async withCenterLogoForPrecisionReport<T>(
    memberId: string,
    reportId: string,
    payload: T,
  ): Promise<T & { centerLogoUrl: string | null }> {
    const report = await this.precisionReportRepo.findOne({
      where: { id: reportId, userId: memberId },
      select: ['id', 'trainerId'],
    });
    if (!report) {
      throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
    }

    return this.withCenterLogo(payload, report.trainerId);
  }

  /**
   * 서버 시작 시 발목 DB 키-내용 일관성 검증.
   * ANKLE_OUTWARD↔ANKLE_INWARD, ANKLE_RIGHT↔ANKLE_LEFT 내용이
   * 뒤바뀐 채로 배포되면 즉시 서버 시작을 실패시킵니다.
   */
  private validateAnkleDbConsistency(): void {
    // OHT_CASE_DB stateAnalysis 검증
    const ohtChecks: [string, string][] = [
      ['ANKLE_OUTWARD', '안쪽으로 무너지는'],
      ['ANKLE_INWARD', '바깥쪽으로 무너지는'],
      ['ANKLE_RIGHT', '오른쪽 발목에서는 안쪽으로'],
      ['ANKLE_LEFT', '오른쪽 발목에서는 바깥쪽으로'],
    ];
    for (const [key, expected] of ohtChecks) {
      const value = OHT_CASE_DB[key]?.stateAnalysis;
      if (!value?.includes(expected)) {
        throw new Error(
          `[DB 불일치] OHT_CASE_DB[${key}].stateAnalysis 에 '${expected}' 없음 — 내용이 뒤바뀌었는지 확인하세요.`,
        );
      }
    }

    // REAR_PATTERN_DB stateAnalysis + movementPatternAnalysis 검증
    const rearChecks: [string, string, string][] = [
      ['ankles:ANKLE_OUTWARD', '안쪽으로 무너지는', '발아치 붕괴'],
      ['ankles:ANKLE_INWARD', '바깥쪽으로 무너지는', '발의 끝부분'],
      ['ankles:ANKLE_RIGHT', '오른쪽 발목에서는 안쪽으로', '오른쪽 발은 무게 중심 이동과 함께 발아치 붕괴'],
      ['ankles:ANKLE_LEFT', '왼쪽 발목에서는 안쪽으로', '왼쪽 발은 무게 중심 이동과 함께 발아치 붕괴'],
    ];
    for (const [key, expectedState, expectedMovement] of rearChecks) {
      const entry = REAR_PATTERN_DB[key];
      if (!entry?.stateAnalysis?.[0]?.includes(expectedState)) {
        throw new Error(
          `[DB 불일치] REAR_PATTERN_DB['${key}'].stateAnalysis[0] 에 '${expectedState}' 없음`,
        );
      }
      const movementText = entry?.movementPatternAnalysis?.join(' ') ?? '';
      if (!movementText.includes(expectedMovement)) {
        throw new Error(
          `[DB 불일치] REAR_PATTERN_DB['${key}'].movementPatternAnalysis 에 '${expectedMovement}' 없음`,
        );
      }
    }
  }

  /**
   * 척추정렬검사 정적 이미지 S3 base URL
   */

  /**
   * 척추정렬검사 일러스트 이미지 URL 결정
   * spinalTilt × shoulderAlignment 9가지 조합 → 각각의 이미지 파일명 매핑
   *
   * | spinalTilt         | shoulderAlignment  | 파일명                              |
   * |--------------------|--------------------|-------------------------------------|
   * | NORMAL             | NORMAL             | spine_normal.png                    |
   * | SPINE_TILTED_LEFT  | NORMAL             | spine_curved_left.png               |
   * | SPINE_TILTED_RIGHT | NORMAL             | spine_curved_right.png              |
   * | NORMAL             | SPINE_CURVED_LEFT  | spine_straight_tilted_left.png          |
   * | NORMAL             | SPINE_CURVED_RIGHT | spine_straight_but_tilted_right.png     |
   * | SPINE_TILTED_LEFT  | SPINE_CURVED_LEFT  | spine_curved_left_tilted_left.png       |
   * | SPINE_TILTED_RIGHT | SPINE_CURVED_RIGHT | spine_curved_right_tilted_right.png     |
   * | SPINE_TILTED_LEFT  | SPINE_CURVED_RIGHT | spine_curved_right_tilted_left.png      |
   * | SPINE_TILTED_RIGHT | SPINE_CURVED_LEFT  | spine_curved_left_tilted_right.png      |
   */
  private resolveSpineIllustrationUrl(spinalTilt: any, shoulderAlignment: any): string {
    const BASE = SPINAL_IMG_BASE;
    const tilt = spinalTilt?.disease ?? 'NORMAL';
    const shoulder = shoulderAlignment?.disease ?? 'NORMAL';

    const FILE_MAP: Record<string, string> = {
      'NORMAL|NORMAL': 'spine_normal.png',
      
      // 1. 중심축만 이동한 경우 (Tilted)
      'SPINE_TILTED_LEFT|NORMAL': 'spine_straight_tilted_left.png',
      'SPINE_TILTED_RIGHT|NORMAL': 'spine_straight_but_tilted_right.png',
      
      // 2. 등 높이(척추 라인)만 차이 나는 경우 (Curved)
      'NORMAL|SPINE_CURVED_LEFT': 'spine_curved_left.png',
      'NORMAL|SPINE_CURVED_RIGHT': 'spine_curved_right.png',
      
      // 3. 복합적인 경우
      'SPINE_TILTED_LEFT|SPINE_CURVED_LEFT': 'spine_curved_left_tilted_left.png',
      'SPINE_TILTED_RIGHT|SPINE_CURVED_RIGHT': 'spine_curved_right_tilted_right.png',
      'SPINE_TILTED_LEFT|SPINE_CURVED_RIGHT': 'spine_curved_right_tilted_left.png',
      'SPINE_TILTED_RIGHT|SPINE_CURVED_LEFT': 'spine_curved_left_tilted_right.png',
    };

    const key = `${tilt}|${shoulder}`;
    const filename = FILE_MAP[key] ?? 'spine_normal.png';
    return `${BASE}/${filename}`;
  }

  /**
   * 균형감각검사 정적 이미지 S3 base URL
   */

  /**
   * 전신기능검사 정적 이미지 S3 base URL
   */

  /**
   * 관절가동범위검사 정적 이미지 S3 base URL
   */

  /**
   * 관절가동범위 체감변화 아이콘 이미지 S3 base URL
   */

  /**
   * 체형측정리포트 근육불균형 figure 이미지 S3 base URL
   */

  /**
   * 체형 스켈레톤 이미지 S3 base URL
   */

  /**
   * 권장 생활자세 이미지 S3 base URL
   */

  /** 키손실 이미지 S3 base URL */

  /** 체중심 이미지 S3 base URL */

  /** 체형 유형 아이콘 이미지 base URL */

  /** POSTURE_ICON_{N} 번호를 실제 S3 파일명으로 해석 */
  private resolveBodyPostureIconUrl(imageNumber: number): string | null {
    const FILE_MAP: Record<number, string> = {
      1: '01-neck-lateral-flexion-right.png',
      2: '02-neck-lateral-flexion-left.png',
      3: '03-neck-rotation-right.png',
      4: '04-neck-rotation-left.png',
      5: '05-turtle-neck.png',
      6: '06-chin-poke.png',
      7: '07-straight-neck.png',
      8: '08-shoulder-height-asymmetry-right-up.png',
      9: '09-shoulder-height-asymmetry-left-up.png',
      10: '10-raised-shoulder-right.png',
      11: '11-raised-shoulder-left.png',
      12: '12-dropped-shoulder-right.png',
      13: '13-dropped-shoulder-left.png',
      14: '14-rounded-shoulder.png',
      15: '15-extended-shoulder.png',
      16: '16-17-arm-internal-rotation.png',
      17: '16-17-arm-internal-rotation.png',
      18: '18-19-arm-external-rotation.png',
      19: '18-19-arm-external-rotation.png',
      20: '20-21-bent-elbow.png',
      21: '20-21-bent-elbow.png',
      22: '22-extended-elbow-right.png',
      23: '23-extended-elbow-left.png',
      24: '24-rounded-back.png',
      25: '25-extended-back.png',
      26: '26-lumbar-hyperlordosis-anterior-pelvic-tilt.png',
      27: '27-flat-back-posterior-pelvic-tilt.png',
      28: '28-torso-tilt-right.png',
      29: '29-torso-tilt-left.png',
      30: '30-torso-rotation-right.png',
      31: '31-torso-rotation-left.png',
      32: '32-sway-back.png',
      33: '33-pelvis-asymmetry-right-up.png',
      34: '34-pelvis-asymmetry-left-up.png',
      35: '35-pelvis-rotation-right.png',
      36: '36-pelvis-rotation-left.png',
      37: '37-pelvis-shift-right.png',
      38: '38-pelvis-shift-left.png',
      39: '39-40-leg-external-rotation.png',
      40: '39-40-leg-external-rotation.png',
      41: '41-42-leg-internal-rotation.png',
      42: '41-42-leg-internal-rotation.png',
      43: '43-44-bow-legs-external.png',
      44: '43-44-bow-legs-external.png',
      45: '45-46-bow-legs-internal.png',
      46: '45-46-bow-legs-internal.png',
      47: '47-48-knock-knees.png',
      48: '47-48-knock-knees.png',
      49: '49-back-knees.png',
      50: '50-bent-knees.png',
      51: '51-52-flat-feet.png',
      52: '51-52-flat-feet.png',
      53: '53-54-high-arch-feet.png',
      54: '53-54-high-arch-feet.png',
    };

    const fileName = FILE_MAP[imageNumber];
    return fileName ? `${BODY_POSTURE_ICON_IMG_BASE}/${fileName}` : null;
  }

  /** CENTER_CORE_STRUCTURE_N → S3 URL */
  private resolveCoreStructureUrl(assetKey: string): string | null {
    const m = assetKey.match(/CENTER_CORE_STRUCTURE_(\d+)$/);
    if (!m) return null;
    return `${SPINAL_IMG_BASE}/final-assessment/core-structure/${m[1]}.png`;
  }

  /** BODY_CHANGE_LOWER_N / BODY_CHANGE_UPPER_N / BODY_CHANGE_SHOULDER_N → S3 URL */
  private resolveBodyChangeUrl(assetKey: string): string | null {
    const m = assetKey.match(/BODY_CHANGE_(?:LOWER|UPPER|SHOULDER)_(\d+)$/);
    if (!m) return null;
    return `${SPINAL_IMG_BASE}/final-assessment/body-change-patterns/${m[1]}.png`;
  }

  /**
   * BALANCE_WALKING/RUNNING/STAIRS/FALLING → daily-balance-patterns/
   * EX_NN_* (또는 RECOMMENDED_/CHALLENGE_ prefix) → functional-balance-training/N.png
   */
  private resolveBalanceUrl(assetKey: string): string | null {
    const ACTIVITY_MAP: Record<string, string> = {
      BALANCE_WALKING: 'daily-balance-patterns/walking.png',
      BALANCE_RUNNING: 'daily-balance-patterns/running.png',
      BALANCE_STAIRS:  'daily-balance-patterns/stair-up-down.png',
      BALANCE_FALLING: 'daily-balance-patterns/fall.png',
    };
    if (ACTIVITY_MAP[assetKey]) {
      return `${BALANCE_IMG_BASE}/${ACTIVITY_MAP[assetKey]}`;
    }
    const POSTURE_MAP: Record<string, string> = {
      BALANCE_FRONT_RIGHT_NORMAL: 'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/balance_front_right.png',
      BALANCE_FRONT_LEFT_NORMAL:  'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/balance_front_left.png',
      BALANCE_RIGHT_SIDE_NORMAL:  'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/balance_right.png',
      BALANCE_LEFT_SIDE_NORMAL:   'https://iposture-s3-bucket.s3.ap-northeast-2.amazonaws.com/balance_left.png',
    };
    if (POSTURE_MAP[assetKey]) {
      return POSTURE_MAP[assetKey];
    }
    const m = assetKey.match(/EX_(\d+)_/);
    if (m) {
      return `${BALANCE_IMG_BASE}/functional-balance-training/${parseInt(m[1], 10)}.png`;
    }
    return null;
  }

  /** CASE_SQUAT / CASE_LUNGE 등 → exercise-cases/{name}.png */
  private resolveOHTExerciseUrl(assetKey: string): string | null {
    const NAME_MAP: Record<string, string> = {
      CASE_SQUAT:     'squat',
      CASE_LUNGE:     'lunge',
      CASE_PLANK:     'plank',
      CASE_CURL_UP:   'curl-up',
      CASE_CLAM:      'clam',
      CASE_HAMSTRING: 'hamstring-stretch',
    };
    const name = NAME_MAP[assetKey];
    return name
      ? `${OVERHEAD_SQUAT_IMG_BASE}/exercise-cases/${name}.png`
      : null;
  }

  /** 전신기능검사 케이스 이미지 URL: cases/{N}/{view}.png */
  private resolveOHTCaseImageUrl(caseNumber: number, view: 'front' | 'back' | 'left' | 'right'): string {
    return `${OVERHEAD_SQUAT_IMG_BASE}/cases/${caseNumber}/${view}.png`;
  }

  /**
   * scoreDetail → OHT 케이스 번호 (1~54) 계산
   * (buildMuscleBalanceSheet의 분기 로직과 동일)
   */
  private computeOHTCaseNumber(scoreDetail: any): number {
    const DISEASE_PRIORITY_KEYS = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];
    const abnormal: Array<{ key: string; dbKey: string }> = [];
    for (const k of DISEASE_PRIORITY_KEYS) {
      const item = scoreDetail?.[k];
      if (item && item.disease !== 'NORMAL') {
        const dbKey = item.disease as string;
        abnormal.push({ key: k, dbKey });
      }
    }
    if (abnormal.length === 0) return 53;

    // 상위 연계 시나리오 기반으로 TYPE1/TYPE2 결정
    const topPairForImg = this.computeTopLinkedScenarioPair(scoreDetail);
    const type1Code = topPairForImg?.type1Key ?? null;
    const type2CodeFromTop = topPairForImg?.type2Key ?? null;

    const TYPE2_MAP: Record<string, Record<string, number>> = {
      HIP_NOT_CENTER_RIGHT: {
        KNEE_RIGHT: 1, FOOT_OUTWARD: 2, ANKLE_RIGHT: 3, BODY_LEARN_FORWARD: 4, RIGHT_HIP_HIGHER: 5,
        ANKLE_OUTWARD: 6, ANKLE_INWARD: 6, FOOT_RIGHT: 6, FOOT_LEFT: 6, FOOT_INWARD: 6,
        KNEE_INWARD: 6, KNEE_OUTWARD: 6, BODY_LEARN_BACKWARD: 6, HEEL_UNNORMAL: 6, ARM_UNNORMAL: 6,
        LEFT_HIP_HIGHER: 6,
      },
      HIP_NOT_CENTER_LEFT: {
        KNEE_LEFT: 7, FOOT_OUTWARD: 8, ANKLE_LEFT: 9, BODY_LEARN_FORWARD: 10, LEFT_HIP_HIGHER: 11,
      },
      KNEE_INWARD: {
        ANKLE_INWARD: 18, FOOT_OUTWARD: 19, RIGHT_HIP_HIGHER: 20, LEFT_HIP_HIGHER: 21,
        BODY_LEARN_FORWARD: 22, BODY_LEARN_BACKWARD: 23,
      },
      KNEE_RIGHT: {
        ANKLE_LEFT: 25, RIGHT_HIP_HIGHER: 26, BODY_LEARN_FORWARD: 27, RIGHT_HEEL_UNNORMAL: 28,
      },
      KNEE_OUTWARD: {
        ANKLE_OUTWARD: 54,
      },
      RIGHT_ARM_UNNORMAL: {
        BODY_LEARN_BACKWARD: 33, HIP_NOT_CENTER_RIGHT: 34, RIGHT_HEEL_UNNORMAL: 35,
      },
      KNEE_LEFT: {
        ANKLE_LEFT: 13, LEFT_HIP_HIGHER: 14, BODY_LEARN_FORWARD: 15, LEFT_HEEL_UNNORMAL: 16,
      },
      ARM_UNNORMAL: {
        BODY_LEARN_BACKWARD: 30, HEEL_UNNORMAL: 31, LEFT_HEEL_UNNORMAL: 32, RIGHT_HEEL_UNNORMAL: 49,
      },
      LEFT_ARM_UNNORMAL: {
        BODY_LEARN_BACKWARD: 37, HIP_NOT_CENTER_LEFT: 38, LEFT_HEEL_UNNORMAL: 39,
      },
      RIGHT_HIP_HIGHER: {
        ANKLE_LEFT: 41, RIGHT_HEEL_UNNORMAL: 42, BODY_LEARN_FORWARD: 43,
      },
      LEFT_HIP_HIGHER: {
        ANKLE_RIGHT: 45, LEFT_HEEL_UNNORMAL: 46, BODY_LEARN_FORWARD: 47,
      },
    };
    const FALLBACK_IMG: Record<string, number> = {
      HIP_NOT_CENTER_RIGHT: 6,
      HIP_NOT_CENTER_LEFT: 12,
      KNEE_INWARD: 24,
      KNEE_RIGHT: 29,
      KNEE_OUTWARD: 52,
      KNEE_LEFT: 17,
      ARM_UNNORMAL: 50,
      RIGHT_ARM_UNNORMAL: 36,
      LEFT_ARM_UNNORMAL: 40,
      RIGHT_HIP_HIGHER: 44,
      LEFT_HIP_HIGHER: 48,
    };

    if (type1Code) {
      const type2Lookup = TYPE2_MAP[type1Code] ?? {};
      if (type2CodeFromTop && type2CodeFromTop in type2Lookup) return type2Lookup[type2CodeFromTop];
      const fallback = FALLBACK_IMG[type1Code];
      if (fallback !== undefined) return fallback;
    }

    const hasBodyLeanForward = abnormal.some((a) => a.dbKey === 'BODY_LEARN_FORWARD');
    return hasBodyLeanForward ? 51 : 52;
  }

  /** ROM_COMP_* assetKey → compensation-movements/{N}.png */
  private resolveRomCompensationUrl(assetKey: string): string | null {
    const JPG_NUMBERS = new Set([9]);
    const directMatch = assetKey.match(/^ROM_COMP_IMG_(\d+)$/);
    if (directMatch) {
      const n = parseInt(directMatch[1], 10);
      const ext = JPG_NUMBERS.has(n) ? 'jpg' : 'png';
      return `${JOINT_ROM_IMG_BASE}/compensation-movements/${n}.${ext}`;
    }

    const NUM_MAP: Record<string, number> = {
      ROM_COMP_TRUNK_ROTATION:      7,
      ROM_COMP_SHOULDER_ELEVATION:  1,
      ROM_COMP_EYE_ROTATION:        9,
      ROM_COMP_BODY_LEAN_OPPOSITE:  19,
      ROM_COMP_ELBOW_FLEXION:       23,
      ROM_COMP_WRIST_FLEXION:       59,
      ROM_COMP_PELVIS_ROTATION:     73,
      ROM_COMP_HIP_FLEXION:         79,
      ROM_COMP_CERVICAL_FLEXION:    81,
      ROM_COMP_LOWER_BACK_FLEXION:  109,
      ROM_COMP_PELVIS_ELEVATION:    131,
      ROM_COMP_KNEE_FLEXION:        80,
      ROM_COMP_ANKLE_DORSIFLEXION:  121,
      ROM_COMP_PELVIS_TILT:         125,       
      ROM_COMP_FOOT_OUTWARD:        147,
      ROM_COMP_HEEL_RISE:           145,
    };
    const n = NUM_MAP[assetKey];
    if (n === undefined) return null;
    const ext = JPG_NUMBERS.has(n) ? 'jpg' : 'png';
    return `${JOINT_ROM_IMG_BASE}/compensation-movements/${n}.${ext}`;
  }

  private createRomMovementDetailOverride(
    imageNumbers: number[],
    patternTitles: string[],
    dailyExampleTitles: string[],
  ): {
    compensationItems: Array<{ title: string; themeColor: string; assetKey: string }>;
    dailyUseItems: Array<{ title: string; themeColor: string }>;
  } {
    const themeColors = ['pink', 'blue', 'gray'];
    return {
      compensationItems: patternTitles.map((title, index) => ({
        title,
        themeColor: themeColors[index] ?? 'gray',
        assetKey: `ROM_COMP_IMG_${imageNumbers[index]}`,
      })),
      dailyUseItems: dailyExampleTitles.map((title, index) => ({
        title,
        themeColor: themeColors[index] ?? 'gray',
      })),
    };
  }

  private resolveRomMovementDetailOverride(key: string): {
    compensationItems: Array<{ title: string; themeColor: string; assetKey: string }>;
    dailyUseItems: Array<{ title: string; themeColor: string }>;
  } | null {
    const k = String(key || '');

    if (k === 'NeckRightLateralFlexion') {
      return this.createRomMovementDetailOverride(
        [1, 3, 5],
        ['같은 쪽 어깨 들어올림', '상체 전체 기울임', '고개 회전 사용'],
        ['전화 통화 시 목 대신 어깨를 들어 귀 위치 맞춤', '드라이 중 목 대신 몸 전체를 기울여 각도 확보', '목 스트레칭 시 가쪽굽힘 대신 고개 회전 사용'],
      );
    }
    if (k === 'NeckLeftLateralFlexion') {
      return this.createRomMovementDetailOverride(
        [2, 4, 6],
        ['같은 쪽 어깨 들어올림', '상체 전체 기울임', '고개 회전 사용'],
        ['전화 통화 시 목 대신 어깨를 들어 귀 위치 맞춤', '드라이 중 목 대신 몸 전체를 기울여 각도 확보', '목 스트레칭 시 가쪽굽힘 대신 고개 회전 사용'],
      );
    }
    if (k === 'NeckRightRotation') {
      return this.createRomMovementDetailOverride(
        [7, 9, 11],
        ['상체 동반 회전', '과도한 안구 움직임', '발과 몸 방향 전환'],
        ['운전 중 고개 대신 상체를 돌려 좌우 확인', '뒤에서 부를 때 고개 대신 눈 움직임으로 반응', '보행 중 고개 대신 몸 방향을 바꿔 시선 확보'],
      );
    }
    if (k === 'NeckLeftRotation') {
      return this.createRomMovementDetailOverride(
        [8, 10, 12],
        ['상체 동반 회전', '과도한 안구 움직임', '발과 몸 방향 전환'],
        ['운전 중 고개 대신 상체를 돌려 좌우 확인', '뒤에서 부를 때 고개 대신 눈 움직임으로 반응', '보행 중 고개 대신 몸 방향을 바꿔 시선 확보'],
      );
    }
    if (k === 'NeckFlexion') {
      return this.createRomMovementDetailOverride(
        [13, 14, 15],
        ['윗등을 굽혀 사용', '고개를 앞으로 내밈', '상체 전체를 숙임'],
        ['스마트폰 볼 때 목 대신 등 굽힘 사용', '스마트폰 볼 때 목 대신 등 굽힘 사용', '바닥 확인 시 목 대신 몸 전체 숙임'],
      );
    }
    if (k === 'NeckExtension') {
      return this.createRomMovementDetailOverride(
        [16, 17, 18],
        ['허리를 과도하게 젖힘', '골반을 앞으로 밀며 몸통을 젖힘', '시선만 위로 올림'],
        ['위를 볼 때 목을 사용하지 않고 허리를 과도하게 젖힘', '선반의 물건을 꺼낼 때 목 대신 몸통을 과도하게 젖힘', '천장 볼 때 목 대신 시선만 위로 올림'],
      );
    }

    if (k.includes('Shoulder') && k.includes('Abduction')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [20, 22, 24] : [19, 21, 23],
        ['몸통 반대쪽 가쪽기울임', '어깨를 위로 들어 올림', '팔꿈치 굽힘 동반'],
        ['팔 옆으로 들 때 몸통 기울임으로 보상', '상의 탈의 시 어깨를 들어 보상', '측면 위쪽의 물건을 집을 때 팔꿈치 굽힘이 동반됨'],
      );
    }
    if (k.includes('Shoulder') && k.includes('Adduction')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [26, 28, 30] : [25, 27, 29],
        ['상체를 함께 틀어 움직임', '팔을 앞으로 들어 각도 보상', '팔꿈치를 굽혀 보상'],
        ['아이 안을 때 상체 회전으로 보상', '바닥 쓸 때 팔을 앞으로 들어 각도 확보', '커튼 닫을 때 팔꿈치 굽힘으로 거리 보상'],
      );
    }
    if (k.includes('Shoulder') && k.includes('Flexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [32, 34, 36] : [31, 33, 35],
        ['몸통을 뒤로 이동함', '어깨뼈를 들어 올림', '몸통을 반대쪽으로 가쪽굽힘'],
        ['머리 위의 물건을 집을 때 몸통을 과도하게 뒤로 젖힘', '빨래 널 때 어깨뼈를 들어 올림', '전등 교체 시 반대측 몸통 가쪽굽힘으로 보상함'],
      );
    }
    if (k.includes('Shoulder') && k.includes('Extension')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [38, 40, 42] : [37, 39, 41],
        ['몸통을 앞으로 숙임', '등을 굽혀 팔 위치를 만듦', '팔을 옆으로 벌려 보상함'],
        ['뒤로 손 보낼 때 몸을 앞으로 숙임', '뒷주머니 물건 꺼낼 때 등 굽힘 사용', '팔을 뒤로 흔드는 대신 옆으로 벌려 팔 스윙을 만듦'],
      );
    }
    if (k.includes('Shoulder') && k.includes('InternalRotation')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [44, 46, 48] : [43, 45, 47],
        ['몸통을 회전시켜 팔 위치를 맞춤', '팔꿈치를 굽혀 각도를 확보함', '손목을 많이 사용함'],
        ['등을 긁는 동작 시 몸통 회전으로 보상함', '등 뒤 옷 정리 시 팔꿈치 굽힘 사용', '물건 끌어안을 때 손목 사용 증가'],
      );
    }
    if (k.includes('Shoulder') && k.includes('ExternalRotation')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [50, 52, 54] : [49, 51, 53],
        ['몸통을 회전시켜 팔 위치를 맞춤', '허리를 과도하게 젖힘', '손목을 많이 사용함'],
        ['머리 뒤 손 올릴 때 몸 회전 사용', '뒤목 옷 정리할 때 허리를 젖혀서 보상함', '머리 묶을 때 손목 사용 증가'],
      );
    }

    if (k.includes('Elbow') && k.includes('Flexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [56, 58, 60] : [55, 57, 59],
        ['어깨를 들어 올려 팔 길이를 줄임', '몸을 앞으로 가져가 거리를 줄임', '손목을 과하게 굽힘'],
        ['휴대폰 사용할 때 어깨를 올려서 보상함', '세수 시 몸을 과도하게 앞으로 숙임', '물건을 들 때 손목을 과도하게 굽혀서 사용함'],
      );
    }
    if (k.includes('Elbow') && k.includes('Extension')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [62, 64, 66] : [61, 63, 65],
        ['어깨 움직임으로 보상', '몸통을 회전시켜 보상', '손목 움직임으로 보상'],
        ['문을 밀 때 어깨를 과도하게 앞으로 내밀어서 보상함', '팔 뻗을 때 몸통 회전 동반', '라켓 백스윙 시 손목 움직임 사용'],
      );
    }

    if (k.includes('Trunk') && k.includes('LateralFlexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [68, 70, 72] : [67, 69, 71],
        ['골반을 반대 방향으로 이동함', '어깨만 위아래로 움직임', '몸통 회전으로 각도 확보'],
        ['차량 세차·청소 중 옆면 닦을 때 골반을 반대쪽으로 밀어 보상', '좁은 통로 통과 시 어깨만 조절', '옆의 물건을 집을 때 몸통을 과도하게 회전함'],
      );
    }
    if (k.includes('Trunk') && k.includes('Rotation')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [74, 76, 78] : [73, 75, 77],
        ['골반 회전으로 보상', '어깨뼈를 앞뒤로 움직임', '목을 더 많이 돌려 시선을 확보함'],
        ['앉아 돌 때 골반 회전 동반', '차에서 벨트 잡을 때 어깨뼈 사용', '골프 스윙 시 몸통 대신 목 회전 위주로 동작함'],
      );
    }
    if (k === 'TrunkFlexion') {
      return this.createRomMovementDetailOverride(
        [79, 80, 81],
        ['엉덩이를 더 많이 접어 내려감', '무릎을 더 굽혀 내려감', '고개를 과하게 숙임'],
        ['설거지 시 엉덩이 접힘 증가', '바닥 청소 시 무릎 굽힘 동반', '세면대 사용 시 고개 과도 숙임'],
      );
    }
    if (k === 'TrunkExtension') {
      return this.createRomMovementDetailOverride(
        [82, 83, 84],
        ['골반을 앞으로 밀어 보상', '고개를 과하게 뒤로 젖힘', '시선을 위로 과도하게 올림'],
        ['위 선반 접근 시 골반을 앞으로 이동함', '기지개 시 고개 과도 젖힘', '전등·환풍기 등 위쪽 물건 점검 시 시선 과도 상승'],
      );
    }

    if (k.includes('Hip') && k.includes('Abduction')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [86, 88, 90] : [85, 87, 89],
        ['몸을 옆으로 기울임', '발끝을 바깥으로 돌림', '골반과 상체를 함께 회전함'],
        ['옆으로 장애물을 넘을 때 다리 대신 몸통을 옆으로 기울임', '차에서 내릴 때 다리 대신 발끝을 바깥쪽으로 돌림', '양반다리로 앉을 때 골반 또는 상체가 회전함'],
      );
    }
    if (k.includes('Hip') && k.includes('Adduction')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [92, 94, 96] : [91, 93, 95],
        ['몸을 옆으로 기울여 보상', '골반을 돌려 각도를 보상함', '발끝을 안쪽으로 돌림'],
        ['좁은 통로 이동 시 다리 대신 몸을 옆으로 기울임', '보행 중 다리 모음 대신 골반 회전 사용', '의자에 앉을 때 다리 대신 발끝을 안쪽으로 돌림'],
      );
    }
    if (k.includes('Hip') && k.includes('ExternalRotation')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [98, 100, 102] : [97, 99, 101],
        ['발끝을 바깥으로 돌려 보상', '골반 회전으로 보상', '상체 움직임으로 보상'],
        ['방향 전환 시 엉덩이 대신 발끝 회전 사용', '양반다리로 앉을 때 골반 또는 상체가 회전함', '4자 다리 시 상체를 옆으로 기울여서 사용함'],
      );
    }
    if (k.includes('Hip') && k.includes('InternalRotation')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [104, 106, 108] : [103, 105, 107],
        ['발끝을 안으로 돌려 보상', '골반을 돌려 각도를 보상함', '상체 움직임으로 보상'],
        ['서서 방향 전환 시 엉덩이 대신 발끝을 안쪽으로 돌림', '좁은 공간 통과 시 다리 대신 골반을 과도하게 회전함', '계단을 내려올 때 다리 대신 상체 움직임으로 착지 위치를 맞춤'],
      );
    }

    if (k.includes('Hip') && k.includes('Flexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [110, 112, 114] : [109, 111, 113],
        ['허리를 둥글게 말아 내려감', '골반을 돌려 각도를 보상함', '골반 후방경사(뒤로 기울임)로 보상'],
        ['의자에서 일어서기 초기 단계에서 허리를 지나치게 굽혀 사용함', '달리기 시 다리 끌어올림에서 골반 회전을 과도하게 사용함', '계단 오를 때 다리 들기 대신 골반을 과도하게 뒤로 기울여(후방경사) 보상함'],
      );
    }
    if (k.includes('Hip') && k.includes('Extension')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [116, 118, 120] : [115, 117, 119],
        ['허리를 과하게 젖힘', '골반 전방경사(앞으로 기울임)로 보상', '골반을 돌려 움직임을 대신함'],
        ['계단 오를 때 몸을 밀어올리며 허리를 과하게 젖힘', '의자에서 일어날 때 끝구간에 골반을 앞으로 기울여(전방경사) 보상함', '달리기·빠른 보행 시 뒤쪽 다리를 밀 때 골반 회전을 과도하게 사용함'],
      );
    }
    if (k.includes('Knee') && k.includes('Flexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [122, 124, 126] : [121, 123, 125],
        ['발목을 더 많이 사용함', '몸통을 기울임', '골반을 돌려 각도를 만듦'],
        ['계단 오를 때 무릎 대신 발목을 과도하게 사용함', '바닥 물건을 집을 때 몸을 과도하게 기울임', '쪼그려 앉을 때 골반이 회전함'],
      );
    }
    if (k.includes('Knee') && k.includes('Extension')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [128, 130, 132] : [127, 129, 131],
        ['골반 후방경사(뒤로 기울임)로 보상', '발목 움직임으로 보상', '같은 쪽 골반을 들어 올려 보상'],
        ['앉아 발을 올릴 때 골반을 뒤로 기울여(후방경사) 보상', '계단 오를 때 무릎 대신 발끝으로 밀어올림', '보행 중 착지 직전에 골반을 과도하게 들어 올림'],
      );
    }

    if (k.includes('Ankle') && k.includes('Inversion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [133, 136, 138] : [133, 135, 137],
        ['무릎을 벌려 각도를 확보함', '엉덩관절을 바깥쪽으로 회전시켜 보상', '엄지발가락을 들어 올림'],
        ['자갈·잔디길 보행 시 무릎을 벌려 균형 유지', '양말·바지 착용 시 한쪽 다리로 설 때 다리를 바깥으로 돌려 보상함', '대중교통에서 서 있을 때 발가락 움직임 위주로 중심을 유지함'],
      );
    }
    if (k.includes('Ankle') && k.includes('Eversion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [139, 142, 144] : [139, 141, 143],
        ['무릎을 모아 각도를 만듦', '엉덩관절을 안쪽으로 회전시켜 보상', '새끼발가락(또는 네 번째 발가락)을 들어 올려 보상'],
        ['불규칙한 바닥에서 무릎을 모아 안정성 확보', '양말·바지 착용 시 한쪽 다리로 설 때 다리를 안으로 돌려 보상함', '대중교통에서 서 있을 때 발가락 움직임 위주로 중심을 유지함'],
      );
    }
    if (k.includes('Ankle') && k.includes('Dorsiflexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [146, 148, 150] : [145, 147, 149],
        ['발가락을 들어 올려 보상함', '발목을 바깥이나 안쪽으로 틀어 보상', '무릎 굽힘.폄에 의한 각도 보상'],
        ['뒤꿈치 디딜 때 발가락을 과하게 듦', '경사진 곳을 오를 때 발목을 안팎으로 꺾어 보상함', '쪼그려 앉을 때 무릎 굽힘으로 각도 대체'],
      );
    }
    if (k.includes('Ankle') && k.includes('Plantarflexion')) {
      const left = k.includes('Left');
      return this.createRomMovementDetailOverride(
        left ? [152, 154, 156] : [151, 153, 155],
        ['발가락을 굽혀 보상함', '발목을 바깥이나 안쪽으로 틀어 보상', '무릎 굽힘.폄에 의한 각도 보상'],
        ['까치발로 물건 집을 때 발가락으로 지면 쥠', '경사면 내려갈 때 발목을 안팎으로 꺾어 보상함', '점프 도약 시 무릎 움직임으로 추진 보상'],
      );
    }

    return null;
  }

  /** 체감변화 아이콘 번호 → S3 URL */
  private resolveRomConditionIconUrl(n: number): string {
    return `${JOINT_ROM_ICON_BASE}/${n}.png`;
  }

  /** ROM 동작 키 → 체감변화 아이콘 번호 배열 (각 항목 순서 대응) */
  private resolveRomConditionIconNumbers(key: string): number[] | null {
    const k = String(key || '');

    if (k.includes('Neck') && k.includes('LateralFlexion')) return [2, 2, 1, 1];
    if (k.includes('Neck') && k.includes('Rotation'))       return [2, 3, 3, 1];
    if (k === 'NeckFlexion')                                return [2, 2, 2, 1];
    if (k === 'NeckExtension')                              return [2, 2, 2, 1];

    if (k.includes('Shoulder') && k.includes('Abduction'))         return [3, 3, 3, 3];
    if (k.includes('Shoulder') && k.includes('Adduction'))         return [3, 3, 6, 2];
    if (k.includes('Shoulder') && k.includes('Flexion'))           return [3, 3, 3, 3];
    if (k.includes('Shoulder') && k.includes('Extension'))         return [3, 3, 3, 3];
    if (k.includes('Shoulder') && k.includes('InternalRotation'))  return [3, 3, 3, 3];
    if (k.includes('Shoulder') && k.includes('ExternalRotation'))  return [3, 3, 2, 3];

    if (k.includes('Elbow') && k.includes('Flexion'))    return [6, 6, 12, 6];
    if (k.includes('Elbow') && k.includes('Extension'))  return [6, 6, 14, 12];

    if (k.includes('Trunk') && k.includes('LateralFlexion')) return [9, 9, 11, 9];
    if (k.includes('Trunk') && k.includes('Rotation'))       return [9, 9, 11, 9];
    if (k === 'TrunkFlexion')                                return [9, 9, 9, 9];
    if (k === 'TrunkExtension')                              return [9, 9, 9, 11];

    if (k.includes('Hip') && k.includes('Abduction'))         return [10, 11, 11, 11];
    if (k.includes('Hip') && k.includes('Adduction'))         return [11, 10, 9, 11];
    if (k.includes('Hip') && k.includes('ExternalRotation'))  return [10, 10, 10, 10];
    if (k.includes('Hip') && k.includes('InternalRotation'))  return [10, 10, 10, 8];
    if (k.includes('Hip') && k.includes('Flexion'))           return [10, 10, 8, 9];
    if (k.includes('Hip') && k.includes('Extension'))         return [11, 10, 9, 9];

    if (k.includes('Knee') && k.includes('Flexion'))    return [13, 13, 13, 13];
    if (k.includes('Knee') && k.includes('Extension'))  return [13, 13, 13, 13];

    if (k.includes('Ankle') && k.includes('Inversion'))      return [15, 15, 15, 15];
    if (k.includes('Ankle') && k.includes('Eversion'))       return [15, 15, 15, 15];
    if (k.includes('Ankle') && k.includes('Dorsiflexion'))   return [15, 8, 15, 15];
    if (k.includes('Ankle') && k.includes('Plantarflexion')) return [15, 15, 15, 15];

    return null;
  }

  private resolveRomConditionTitles(key: string): string[] | null {
    const k = String(key || '');

    if (k.includes('Neck') && k.includes('LateralFlexion')) {
      return ['목 옆 뻐근함', '뒷목 압박', '관자 조임', '귀 옆 묵직함'];
    }
    if (k.includes('Neck') && k.includes('Rotation')) {
      return ['회전 시 걸림', '팔로 퍼지는 묵직함', '상체 긴장', '한쪽 머리 욱신'];
    }
    if (k === 'NeckFlexion') {
      return ['숙일 때 압박', '목 전반 뻐근함', '뒷목 당김', '머리 무거움'];
    }
    if (k === 'NeckExtension') {
      return ['젖힐 때 압박', '목 뒤 중심부 답답함', '목 뻣뻣함', '뒷머리 욱신'];
    }

    if (k.includes('Shoulder') && k.includes('Abduction')) {
      return ['어깨 바깥쪽 걸림', '어깨 관절 안쪽 무거움', '어깨 바깥쪽 관절 찌르는 느낌', '어깨 위 뻐근'];
    }
    if (k.includes('Shoulder') && k.includes('Adduction')) {
      return ['가슴 앞 답답', '어깨 안쪽 뻐근', '팔 안쪽 저림', '목어깨 묵직'];
    }
    if (k.includes('Shoulder') && k.includes('Flexion')) {
      return ['어깨 앞쪽 관절 걸림', '어깨 앞쪽 근육 당김', '어깨 관절 깊은 피로', '팔 들 때 어깨 전체 무거움'];
    }
    if (k.includes('Shoulder') && k.includes('Extension')) {
      return ['팔꿈치 뒤쪽→어깨 뒤 당김', '어깨 관절 깊은 둔함', '등 중앙·견갑 사이 압박', '어깨 뒤 근육 뻐근함'];
    }
    if (k.includes('Shoulder') && k.includes('InternalRotation')) {
      return ['어깨 깊은 조임·둔함', '어깨 앞·위 찌르는 불편', '어깨 깊은 둔한 불편', '어깨 앞쪽 압박'];
    }
    if (k.includes('Shoulder') && k.includes('ExternalRotation')) {
      return ['어깨 바깥 깊은 무거움', '어깨 바깥 걸림', '목-어깨 경계 묵직함', '가슴 앞 답답함'];
    }

    if (k.includes('Elbow') && k.includes('Flexion')) {
      return ['팔꿈치 안쪽 당김', '팔꿈치 안쪽 저림', '손바닥 저림', '팔꿈치 뻣뻣함'];
    }
    if (k.includes('Elbow') && k.includes('Extension')) {
      return ['팔꿈치 바깥 당김', '팔꿈치 뒤쪽 당김', '끝까지 펼 때 뻣뻣함', '손 저림·피로'];
    }

    if (k.includes('Trunk') && k.includes('LateralFlexion')) {
      return ['허리 좌우 비대칭 뻐근함', '옆구리 근육 당김', '골반 한쪽 묵직함', '허리 옆쪽 뻐근함'];
    }
    if (k.includes('Trunk') && k.includes('Rotation')) {
      return ['회전 마지막 구간에서 허리 부담감', '허리 불안정 묵직함', '엉덩이→다리 묵직함', '허리 근육 피로'];
    }
    if (k === 'TrunkFlexion') {
      return ['허리 깊은 압박', '앞으로 숙일 때 허리 눌리는 느낌', '허리 뒤쪽 뻐근함', '허리 뒤 근육 당김'];
    }
    if (k === 'TrunkExtension') {
      return ['허리 젖힐 때 답답한 느낌', '뒤로 젖힐 때 압박', '허리 전반 경직', '뒤로 젖힐 때 균형 불편'];
    }

    if (k.includes('Hip') && k.includes('Abduction')) {
      return ['엉덩관절이 딱딱 걸림', '엉덩이 바깥쪽 당김', '엉덩관절 깊은 압박', '골반 옆 묵직함'];
    }
    if (k.includes('Hip') && k.includes('Adduction')) {
      return ['골반 뒤 가운데가 눌리는 느낌', '엉덩관절 안쪽 걸림 느낌', '허리 동반 불편', '엉덩관절 깊은 둔함'];
    }
    if (k.includes('Hip') && k.includes('ExternalRotation')) {
      return ['바깥 회전 시 깊은 걸림', '엉덩관절 회전 중 딸깍 느낌', '엉덩회전 시 둔한 불편', '허벅지 옆 당김'];
    }
    if (k.includes('Hip') && k.includes('InternalRotation')) {
      return ['안쪽 회전 시 압박감', '회전 범위 감소', '골반 안쪽 불편', '허리→다리 묵직함'];
    }
    if (k.includes('Hip') && k.includes('Flexion')) {
      return ['다리 들 때 깊은 압박', '엉덩관절 앞쪽 깊은 부위의 묵직한 불편감', '다리 뒤쪽 묵직함', '굽힘 시 허리 부담'];
    }
    if (k.includes('Hip') && k.includes('Extension')) {
      return ['골반 뒤쪽 불편', '허벅지 뒤 묵직함', '끝까지 폈을 때 눌리는 느낌', '펴는 동작 전반이 뻣뻣함'];
    }

    if (k.includes('Knee') && k.includes('Flexion')) {
      return ['무릎 안쪽 걸림', '무릎 앞 둔함', '무릎 굽힘 경직', '무릎 아래 당김'];
    }
    if (k.includes('Knee') && k.includes('Extension')) {
      return ['끝까지 폈을 때 뻣뻣함', '무릎 앞 당김', '무릎 안쪽 불안정', '무릎 펴는 중 걸림'];
    }

    if (k.includes('Ankle') && k.includes('Inversion')) {
      return ['발목 안쪽 불안', '발 안쪽 저림', '엄지 안쪽 압박', '발바닥 중앙 피로'];
    }
    if (k.includes('Ankle') && k.includes('Eversion')) {
      return ['발목 바깥 불안', '발가락 사이 찌릿', '발목이 뻑뻑한 느낌', '보행 시 발바닥 피로'];
    }
    if (k.includes('Ankle') && k.includes('Dorsiflexion')) {
      return ['발목 앞 압박', '종아리 아래 당김', '발목 전반 경직', '발 저림'];
    }
    if (k.includes('Ankle') && k.includes('Plantarflexion')) {
      return ['발바닥 중앙 뻐근함', '뒤꿈치 당김', '발가락 저림', '발목 깊은 곳의 둔한 불편감'];
    }

    return null;
  }

  private resolveRomRoutineAndExpectedEffectOverride(
    key: string,
  ): { routineItems: Array<{ name: string; assetKey: string }>; expectedEffect: string } | null {
    const k = String(key || '');
    const build = (items: Array<[string, number]>, expectedEffect: string) => ({
      routineItems: items.map(([name, imageNumber]) => ({
        name,
        assetKey: `ROM_ROUTINE_IMG_${imageNumber}`,
      })),
      expectedEffect,
    });

    if (k === 'NeckRightLateralFlexion') {
      return build(
        [['옆에서 봤을 때 귀-어깨 수직 정렬로 맞춘 뒤 10초 유지', 1], ['귀-어깨 수직 정렬 고정 후 왼쪽 위등세모근 스트레칭', 2], ['목 수건 스트레칭', 3]],
        '목 옆 뻐근함 완화, 뒷목 압박 완화, 관자 조임 완화, 귀 옆 묵직함 완화',
      );
    }
    if (k === 'NeckLeftLateralFlexion') {
      return build(
        [['옆에서 봤을 때 귀-어깨 수직 정렬로 맞춘 뒤 10초 유지', 1], ['귀-어깨 수직 정렬 고정 후 오른쪽 위등세모근 스트레칭', 5], ['목 수건 스트레칭', 6]],
        '목 옆 뻐근함 완화, 뒷목 압박 완화, 관자 조임 완화, 귀 옆 묵직함 완화',
      );
    }
    if (k === 'NeckRightRotation') {
      return build(
        [['옆에서 봤을 때 귀-어깨 수직 정렬로 맞춘 뒤 10초 유지', 1], ['귀-어깨 수직 정렬 고정 후 회전축 유지하며 오른쪽 회전', 8], ['시선과 목은 정면을 유지하고 상체를 왼쪽으로 최대 회전', 9]],
        '회전 시 걸림 감소, 팔로 퍼지는 묵직함 완화, 상체 긴장 완화, 한쪽 머리 욱신거림 완화',
      );
    }
    if (k === 'NeckLeftRotation') {
      return build(
        [['옆에서 봤을 때 귀-어깨 수직 정렬로 맞춘 뒤 10초 유지', 1], ['귀-어깨 수직 정렬 고정 후 회전축 유지하며 왼쪽 회전', 11], ['시선과 목은 정면을 유지하고 상체를 오른쪽으로 최대 회전', 12]],
        '회전 시 걸림 감소, 팔로 퍼지는 묵직함 완화, 상체 긴장 완화, 한쪽 머리 욱신거림 완화',
      );
    }
    if (k === 'NeckFlexion') {
      return build(
        [['뒤통수밑근 근육 이완 (마사지볼)', 14], ['뒤통수밑근 스트레칭', 15], ['캣앤카멜 (팔 바닥에 수직 유지)', 16]],
        '숙일 때 압박 완화, 목 전반 뻐근함 완화, 뒷목 당김 완화, 머리 무거움 완화',
      );
    }
    if (k === 'NeckExtension') {
      return build(
        [['목 수건 스트레칭', 3], ['가슴 열기 스트레칭', 18], ['등 펴기 운동', 19]],
        '젖힐 때 압박 완화, 목 젖힘 시 상체 긴장 완화, 목 뻣뻣함 완화, 뒷머리 욱신거림 완화',
      );
    }

    if (k.includes('Shoulder') && k.includes('Abduction')) {
      return build(
        k.includes('Left')
          ? [['Wall slide', 20], ['가슴 열기 스트레칭', 18], ['만세 동작으로 옆구리·겨드랑이 스트레칭 (넓은등근 스트레칭)', 25]]
          : [['Wall slide', 20], ['가슴 열기 스트레칭', 18], ['만세 동작으로 옆구리·겨드랑이 스트레칭 (넓은등근 스트레칭)', 22]],
        '어깨 바깥쪽 걸림 감소, 어깨 관절 안쪽 무거움 완화, 어깨 바깥쪽 관절 찌르는 느낌 완화, 어깨 위 뻐근함 완화',
      );
    }
    if (k.includes('Shoulder') && k.includes('Adduction')) {
      return build(
        k.includes('Left')
          ? [['겨드랑이에 수건 끼우고 어깨 모음 유지', 29], ['서서 팔꿈치 옆구리 누르기 (등척성 운동)', 30], ['크로스바디 어깨 스트레칭', 31]]
          : [['겨드랑이에 수건 끼우고 어깨 모음 유지', 26], ['서서 팔꿈치 옆구리 누르기 (등척성 운동)', 27], ['크로스바디 어깨 스트레칭', 28]],
        '가슴 앞 답답함 완화, 어깨 안쪽 뻐근함 완화, 팔 안쪽 저림 완화, 목어깨 묵직함 완화',
      );
    }
    if (k.includes('Shoulder') && k.includes('Flexion')) {
      return build(
        [['Wall slide', 20], ['가슴 열기 스트레칭', 18], ['등 펴기 운동', 19]],
        '어깨 앞쪽 관절 걸림 감소, 어깨 앞쪽 근육 당김 완화, 어깨 관절 깊은 피로 완화, 팔 들 때 어깨 무거움 완화',
      );
    }
    if (k.includes('Shoulder') && k.includes('Extension')) {
      return build(
        k.includes('Left')
          ? [['가슴 열기 스트레칭', 18], ['위팔두갈래근 스트레칭', 42], ['아래 등세모근 활성화 운동', 43]]
          : [['가슴 열기 스트레칭', 18], ['위팔두갈래근 스트레칭', 39], ['아래 등세모근 활성화 운동', 40]],
        '팔꿈치 뒤쪽→어깨 뒤 당김 완화, 어깨 관절 깊은 둔한 느낌 완화, 등 중앙·어깨뼈 사이 압박감 완화, 어깨 뒤 근육 뻐근함 완화',
      );
    }
    if (k.includes('Shoulder') && k.includes('InternalRotation')) {
      return build(
        k.includes('Left')
          ? [['회전근개 운동 (밴드 안쪽돌림)', 47], ['수건 잡고 등 뒤로 돌리기', 48], ['슬리퍼 스트레치', 49]]
          : [['회전근개 운동 (밴드 안쪽돌림)', 44], ['수건 잡고 등 뒤로 돌리기', 45], ['슬리퍼 스트레치', 46]],
        '어깨 깊은 조임·둔함 완화, 어깨 앞·위 찌르는 느낌 완화, 어깨 앞쪽 압박 완화',
      );
    }
    if (k.includes('Shoulder') && k.includes('ExternalRotation')) {
      return build(
        k.includes('Left')
          ? [['회전근개 운동 (밴드 가쪽돌림)', 50], ['만세 동작으로 옆구리·겨드랑이 스트레칭 (넓은등근 스트레칭)', 25], ['옆으로 누워 팔을 바깥쪽으로 돌리기', 55]]
          : [['회전근개 운동 (밴드 가쪽돌림)', 50], ['만세 동작으로 옆구리·겨드랑이 스트레칭 (넓은등근 스트레칭)', 22], ['옆으로 누워 팔을 바깥쪽으로 돌리기', 52]],
        '어깨 바깥 깊은 무거움 완화, 어깨 바깥 걸림 감소, 목-어깨 경계 묵직함 완화, 가슴 앞 답답함 완화',
      );
    }

    if (k.includes('Elbow') && k.includes('Flexion')) {
      return build(
        k.includes('Left')
          ? [['만세 자세에서 위팔세갈래근 스트레칭', 59], ['만세 자세에서 위팔세갈래근 스트레칭 + 같은 쪽 옆구리 스트레칭', 60], ['손목 굽힘·폄 풀기', 58]]
          : [['만세 자세에서 위팔세갈래근 스트레칭', 56], ['만세 자세에서 위팔세갈래근 스트레칭 + 같은 쪽 옆구리 스트레칭', 57], ['손목 굽힘·폄 풀기', 58]],
        '팔꿈치 안쪽 당김 완화, 팔꿈치 안쪽 저림 완화, 손바닥 저림 완화, 팔꿈치 뻣뻣함 완화',
      );
    }
    if (k.includes('Elbow') && k.includes('Extension')) {
      return build(
        k.includes('Left')
          ? [['위팔두갈래근 스트레칭', 42], ['가슴 열기 스트레칭', 18], ['손목 펴기 스트레칭 (아래팔 스트레칭)', 67]]
          : [['위팔두갈래근 스트레칭', 39], ['가슴 열기 스트레칭', 18], ['손목 펴기 스트레칭 (아래팔 스트레칭)', 64]],
        '팔꿈치 바깥 당김 완화, 팔꿈치 뒤쪽 당김 완화, 끝까지 펼 때 뻣뻣함 완화, 손 저림·피로 완화',
      );
    }

    if (k.includes('Trunk') && k.includes('LateralFlexion')) {
      return build(
        k.includes('Left')
          ? [['앉아서 골반 고정 후 옆구리 스트레칭', 71], ['팔 들고 옆으로 기울이기', 72], ['등 회전 운동 (팔 옆으로 들고 상체 회전)', 73]]
          : [['앉아서 골반 고정 후 옆구리 스트레칭', 68], ['팔 들고 옆으로 기울이기', 69], ['등 회전 운동 (팔 옆으로 들고 상체 회전)', 70]],
        '옆구리 근육 당김 완화, 골반 한쪽 묵직함 완화, 허리 옆쪽 뻐근함 완화',
      );
    }
    if (k.includes('Trunk') && k.includes('Rotation')) {
      return build(
        k.includes('Left')
          ? [['누워서 무릎 좌우 넘기기', 77], ['등 회전 운동 (팔 옆으로 들고 상체 회전)', 73], ['의자에 앉아 골반 고정 후 상체 회전', 79]]
          : [['누워서 무릎 좌우 넘기기', 74], ['등 회전 운동 (팔 옆으로 들고 상체 회전)', 70], ['의자에 앉아 골반 고정 후 상체 회전', 76]],
        '회전 마지막 구간 허리 부담감 완화, 허리 불안정 묵직함 완화, 엉덩이→다리 묵직함 완화, 허리 근육 피로 완화',
      );
    }
    if (k === 'TrunkFlexion') {
      return build(
        [['캣앤카멜 (팔 바닥에 수직 유지)', 16], ['롤다운·롤업', 81], ['허벅지 뒤쪽(뒤넙다리 근육)스트레칭', 82]],
        '허리 깊은 압박 완화,허리 뒤쪽 뻐근함 완화, 허리 뒤 근육 당김 완화',
      );
    }
    if (k === 'TrunkExtension') {
      return build(
        [['등 회전 운동 (팔 옆으로 들고 상체 회전)', 70], ['가슴 열기 스트레칭', 18], ['넙다리네갈래근 스트레칭', 85]],
        '허리 젖힐 때 답답함 완화, 뒤로 젖힐 때 압박 완화, 허리 전반 경직 완화',
      );
    }

    if (k.includes('Hip') && k.includes('Abduction')) {
      return build(
        k.includes('Left')
          ? [['엉덩관절 모음근 스트레칭', 89], ['스쿼트', 87], ['런지', 91]]
          : [['엉덩관절 모음근 스트레칭', 86], ['스쿼트', 87], ['런지', 88]],
        '엉덩관절 걸리는 느낌 감소, 엉덩이 바깥쪽 당김 완화, 엉덩관절 깊은 압박 완화, 골반 옆 묵직함 완화',
      );
    }
    if (k.includes('Hip') && k.includes('Adduction')) {
      return build(
        k.includes('Left')
          ? [['무릎 사이 볼 끼우기', 92], ['둔부 스트레칭 (앉아서)', 96], ['넙다리근막긴장근 이완 (폼롤러)', 97]]
          : [['무릎 사이 볼 끼우기', 92], ['둔부 스트레칭 (앉아서)', 93], ['넙다리근막긴장근 이완 (폼롤러)', 94]],
        '골반 뒤 가운데 눌림 느낌 완화, 엉덩관절 안쪽 걸림 느낌 감소, 엉덩관절 깊은 둔한 불편 완화',
      );
    }
    if (k.includes('Hip') && k.includes('ExternalRotation')) {
      return build(
        k.includes('Left')
          ? [['허벅지 앞쪽 스트레칭', 101], ['넙다리근막긴장근 이완 (폼롤러)', 97], ['와이드 스쿼트', 100]]
          : [['허벅지 앞쪽 스트레칭', 85], ['넙다리근막긴장근 이완 (폼롤러)', 94], ['와이드 스쿼트', 100]],
        '바깥 회전 시 걸리는 느낌 감소, 엉덩관절 회전 시 둔한 불편함 완화, 허벅지 옆 당김 완화',
      );
    }
    if (k.includes('Hip') && k.includes('InternalRotation')) {
      return build(
        k.includes('Left')
          ? [['둔부 스트레칭 (앉아서)', 96], ['골반 앞·뒤 기울이기 (앉아서)', 105], ['머메이드 자세에서 골반 들어 올렸다 내리기', 109]]
          : [['둔부 스트레칭 (앉아서)', 93], ['골반 앞·뒤 기울이기 (앉아서)', 105], ['머메이드 자세에서 골반 들어 올렸다 내리기', 106]],
        '안쪽 회전 시 골반 안쪽 압박감 완화, 골반 안쪽 불편 완화, 허리→다리 묵직함 완화',
      );
    }
    if (k.includes('Hip') && k.includes('Flexion')) {
      return build(
        k.includes('Left')
          ? [['엉덩허리근 스트레칭', 113], ['넙다리근막긴장근 이완 (폼롤러)', 97], ['둔부 스트레칭 (앉아서)', 115]]
          : [['엉덩허리근 스트레칭', 110], ['넙다리근막긴장근 이완 (폼롤러)', 94], ['둔부 스트레칭 (앉아서)', 114]],
        '다리 들 때 깊은 압박 완화, 엉덩관절 앞쪽 깊은 묵직한 불편감 완화, 다리 뒤쪽 묵직함 완화, 굽힐 때 허리 부담 완화',
      );
    }
    if (k.includes('Hip') && k.includes('Extension')) {
      return build(
        k.includes('Left')
          ? [['엉덩허리근 스트레칭', 113], ['넙다리네갈래근 스트레칭', 120], ['엎드려 무릎 굽혀 다리 들어 올리기', 121]]
          : [['엉덩허리근 스트레칭', 110], ['넙다리네갈래근 스트레칭', 117], ['엎드려 무릎 굽혀 다리 들어 올리기', 118]],
        '골반 뒤쪽 불편 완화, 허벅지 뒤 묵직함 완화, 끝까지 폈을 때 눌림 느낌 완화, 펴는 동작 시 뻣뻣함 완화',
      );
    }

    if (k.includes('Knee') && k.includes('Flexion')) {
      return build(
        k.includes('Left')
          ? [['넙다리 네갈래근 스트레칭', 101], ['오금근 마사지', 123], ['힐 슬라이드', 127]]
          : [['넙다리 네갈래근 스트레칭', 85], ['오금근 마사지', 123], ['힐 슬라이드', 124]],
        '무릎 안쪽 걸림 감소, 무릎 앞 둔한 느낌 완화, 무릎 굽힘 시 경직 완화, 무릎 아래 당김 완화',
      );
    }
    if (k.includes('Knee') && k.includes('Extension')) {
      return build(
        k.includes('Left')
          ? [['쿼드 세팅 운동(앉은상태에서)', 131], ['뒤넙다리 근육 스트레칭', 129], ['종아리 스트레칭', 133]]
          : [['쿼드 세팅 운동(앉은상태에서)', 128], ['뒤넙다리 근육 스트레칭', 129], ['종아리 스트레칭', 130]],
        '끝까지 폈을 때 뻣뻣함 완화, 무릎 안쪽 불안정 완화, 무릎 펴는 중 걸림 감소',
      );
    }

    if (k.includes('Ankle') && k.includes('Inversion')) {
      return build(
        k.includes('Left')
          ? [['서서 체중 싣고 발 바깥쪽으로 체중 이동', 137], ['엄지 들고 나머지 발가락 누르기', 135], ['수건 발가락 쥐기', 139]]
          : [['서서 체중 싣고 발 바깥쪽으로 체중 이동', 134], ['엄지 들고 나머지 발가락 누르기', 135], ['수건 발가락 쥐기', 136]],
        '발목 안쪽 불안 완화, 발 안쪽 저림 완화, 엄지 안쪽 압박 완화, 발바닥 피로 완화',
      );
    }
    if (k.includes('Ankle') && k.includes('Eversion')) {
      return build(
        k.includes('Left')
          ? [['서서 체중 싣고 발 안쪽으로 체중 이동', 143], ['발바닥 볼 마사지', 144], ['발목 돌리기 (바깥쪽 크게)', 145]]
          : [['서서 체중 싣고 발 안쪽으로 체중 이동', 140], ['발바닥 볼 마사지', 141], ['발목 돌리기 (바깥쪽 크게)', 142]],
        '발목 바깥 불안 완화, 발가락 사이 찌릿함 완화, 발목 뻑뻑함 완화, 걷기 시 발바닥 피로 완화',
      );
    }
    if (k.includes('Ankle') && k.includes('Dorsiflexion')) {
      return build(
        k.includes('Left')
          ? [['종아리 스트레칭', 133], ['벽 앞에서 발목 접고 체중 이동', 150], ['발바닥 볼 마사지', 144]]
          : [['종아리 스트레칭', 130], ['벽 앞에서 발목 접고 체중 이동', 147], ['발바닥 볼 마사지', 141]],
        '발목 앞 압박 완화, 종아리 아래 당김 완화, 발목 전반 경직 완화, 발 저림 완화',
      );
    }
    if (k.includes('Ankle') && k.includes('Plantarflexion')) {
      return build(
        k.includes('Left')
          ? [['종아리 스트레칭', 133], ['발바닥 볼 마사지', 144], ['앞정강근 이완 (폼롤러)', 154]]
          : [['종아리 스트레칭', 130], ['발바닥 볼 마사지', 141], ['앞정강근 이완 (폼롤러)', 154]],
        '발바닥 뻐근함 완화, 뒤꿈치 당김 완화, 발가락 저림 완화, 발목 깊은 곳 둔한 불편 완화',
      );
    }

    return null;
  }

  /** ROM_CAUSE_* assetKey → caution-habits/{N}.png */
  private resolveRomCauseUrl(assetKey: string): string | null {
    const directMatch = assetKey.match(/^ROM_CAUSE_IMG_(\d+)$/);
    if (directMatch) {
      return `${JOINT_ROM_IMG_BASE}/caution-habits/${directMatch[1]}.png`;
    }

    const NUM_MAP: Record<string, number> = {
      ROM_CAUSE_SMARTPHONE_USE:               31,
      ROM_CAUSE_SLEEP_ONE_SIDE:               1,
      ROM_CAUSE_BAG_ONE_SIDE:                 19,
      ROM_CAUSE_CHIN_REST:                    6,
      ROM_CAUSE_SLEEP_LEFT_DOWN:              2,
      ROM_CAUSE_HAIR_LEFT:                    9,
      ROM_CAUSE_BAG_LEFT:                     20,
      ROM_CAUSE_ELBOW_BENT_POSTURE:           33,
      ROM_CAUSE_REPETITIVE_ELBOW:             34,
      ROM_CAUSE_HEAVY_CARRY:                  22,
      ROM_CAUSE_WRIST_OVERUSE:                32,
      ROM_CAUSE_PROLONGED_SITTING:            32,
      ROM_CAUSE_ONE_SIDE_WORK:                51,
      ROM_CAUSE_CORE_WEAKNESS:                65,
      ROM_CAUSE_LEG_CROSS:                    38,
      ROM_CAUSE_HIP_STRETCH_LACK:             42,
      ROM_CAUSE_ASYMMETRIC_STANDING:          40,
      ROM_CAUSE_KNEE_EXTENDED_SITTING:        12,
      ROM_CAUSE_REPETITIVE_STAIRS:            62,
      ROM_CAUSE_QUAD_HAMSTRING_STRETCH_LACK:  65,
      ROM_CAUSE_KNEELING_PROLONGED:           43,
      ROM_CAUSE_HIGH_HEEL:                    61,
      ROM_CAUSE_ANKLE_MOBILITY_LACK:          65,
      ROM_CAUSE_CALF_STRETCH_LACK:            65,
      ROM_CAUSE_REPETITIVE_RUNNING_JUMP:      65,
    };
    const n = NUM_MAP[assetKey];
    return n !== undefined
      ? `${JOINT_ROM_IMG_BASE}/caution-habits/${n}.png`
      : null;
  }

  private normalizeRomCauseTitle(title: string): string {
    return String(title || '')
      .replace(/\s+/g, '')
      .replace(/[().,·]/g, '')
      .replace(/[/:]/g, '')
      .replace(/-/g, '')
      .trim();
  }


  private resolveRomCauseAssetKeyByTitle(title: string): string | null {
    const normalized = this.normalizeRomCauseTitle(title);
    const aliasMap: Record<string, string> = {
      '왼손으로턱괴는습관': '왼쪽팔꿈치로턱괴기',
      '오른손으로턱괴는습관': '오른쪽팔꿈치로턱괴기',
      '턱괴는습관': '오른쪽팔꿈치로턱괴기',
      '구부정하게앉은자세': '구부정한앉은자세',
      '낮은의자에앉은자세': '지나치게낮은의자사용',
      '골반을앞으로내밀고서있기': '골반을앞으로밀고서있기',
      '발의가쪽으로체중싣기': '발바깥쪽체중지지',
      '회전의자장시간사용': '회전의자사용',
      '테니스골프등회전운동': '회전운동편중골프테니스등',
      '다리꼬기': '다리꼬기오른쪽다리가위',
      '짝다리지지': '짝다리지지오른쪽',
      '옆으로눕는수면자세': '옆으로눕는수면자세오른쪽이아래',
      '한쪽으로수면': '옆으로눕는수면자세오른쪽이아래',
      '한쪽으로기대어앉는습관': '오른쪽으로기대어앉는습관',
      '장시간컴퓨터사용': '장시간책상업무자세유지',
    };

    const mappedTitle = aliasMap[normalized] ?? normalized;
    const imageNumber = ROM_CAUSE_IMAGE_NUMBER_BY_TITLE[mappedTitle];
    return imageNumber ? `ROM_CAUSE_IMG_${imageNumber}` : null;
  }

  /** ROM_ROUTINE_* assetKey → recommended-routines/{N}.png */
  private resolveRomRoutineUrl(assetKey: string): string | null {
    const directMatch = assetKey.match(/^ROM_ROUTINE_IMG_(\d+)$/);
    if (directMatch) {
      return `${JOINT_ROM_IMG_BASE}/recommended-routines/${directMatch[1]}.png`;
    }

    const NUM_MAP: Record<string, number> = {
      // 목
      ROM_ROUTINE_NECK_WALL_STRETCH:           1,   // 귀–어깨 수직 정렬
      ROM_ROUTINE_NECK_LATERAL_STRETCH:        2,   // 위등세모근 스트레칭
      ROM_ROUTINE_THORACIC_ROTATION:          70,   // 등 회전 운동 (상체 돌리기)
      ROM_ROUTINE_CAT_COW:                    16,   // 캣앤카멜
      // 어깨
      ROM_ROUTINE_WALL_SLIDE:                 20,   // Wall slide
      ROM_ROUTINE_CHEST_OPENING:              18,   // 가슴 열기 스트레칭
      ROM_ROUTINE_SIDE_STRETCH:               22,   // 만세 동작 옆구리·겨드랑이 스트레칭
      // 팔꿈치
      ROM_ROUTINE_FOREARM_STRETCH_UP:         64,   // 손목 펴기 스트레칭 (아래팔)
      ROM_ROUTINE_FOREARM_STRETCH_DOWN:       67,   // 손목 펴기 스트레칭 (왼쪽)
      ROM_ROUTINE_ELBOW_FLEXION_EXTENSION:    58,   // 손목 굽힘·폄 풀기
      // 몸통
      ROM_ROUTINE_LATERAL_TRUNK_STRETCH:      68,   // 앉아서 골반 고정 후 옆구리 스트레칭
      // 고관절
      ROM_ROUTINE_HIP_FLEXOR_STRETCH:        110,   // 엉덩허리근 스트레칭
      ROM_ROUTINE_CLAMSHELL:                  92,   // 무릎 사이 볼 끼우기
      ROM_ROUTINE_HIP_90_90:                  93,   // 둔부 스트레칭 (앉아서)
      // 무릎
      ROM_ROUTINE_HAMSTRING_STRETCH:         129,   // 뒤넙다리 근육 스트레칭
      ROM_ROUTINE_QUAD_STRETCH:               85,   // 넙다리네갈래근 스트레칭
      ROM_ROUTINE_PRONE_KNEE_FLEXION:        123,   // 오금근 마사지
      // 발목
      ROM_ROUTINE_CALF_WALL_STRETCH:         130,   // 종아리 스트레칭
      ROM_ROUTINE_ANKLE_CIRCLES:             142,   // 발목 돌리기 (바깥쪽 크게)
      ROM_ROUTINE_KNEE_TO_WALL:             147,   // 벽 앞에서 발목 접고 체중 이동
    };
    const n = NUM_MAP[assetKey];
    return n !== undefined
      ? `${JOINT_ROM_IMG_BASE}/recommended-routines/${n}.png`
      : null;
  }

  /** HABIT_CAUTION_{N} assetKey → joint-rom/caution-habits/{N}.png */
  private resolveHabitCautionUrl(assetKey: string): string | null {
    const m = assetKey.match(/^HABIT_CAUTION_(\d+)$/);
    if (!m) return null;
    return `${JOINT_ROM_IMG_BASE}/caution-habits/${m[1]}.png`;
  }

  /** MUSCLE_MAP_{N} assetKey → muscle-maps/{N}/front.png */
  private resolveMuscleMapUrl(assetKey: string): string | null {
    const m = assetKey.match(/^MUSCLE_MAP_(\d+)$/);
    if (!m) return null;
    return `${MUSCLE_MAP_IMG_BASE}/${m[1]}/front.png`;
  }

  /** HABIT_REC_{N} assetKey → recommended-habits/{N}.png */
  private resolveHabitRecUrl(assetKey: string): string | null {
    const m = assetKey.match(/^HABIT_REC_(\d+)$/);
    if (!m) return null;
    return `${RECOMMENDED_HABITS_IMG_BASE}/${m[1]}.png`;
  }

  /**
   * 키손실(cm) → 단계(1~6) 판정
   * 단계: 1=정상, 2=경미, 3=주의, 4=경계, 5=심각, 6=위험
   * ※ 임계값은 아래 HEIGHT_LOSS_THRESHOLDS에서 조정 (상한 미만)
   */

  private static getHeightLossStage(heightLossCm: number): { stage: number; label: string } {
    const found = HEIGHT_LOSS_THRESHOLDS.find((t) => heightLossCm < t.max);
    return found ?? { stage: 6, label: '위험' };
  }

  /** 체중심 → S3 이미지 URL */
  private resolveBodyBalanceImageUrl(leftRight: string, frontBack: string): string {
    const key = `${frontBack}_${leftRight}`;
    const FILE_MAP: Record<string, string> = {
      'normal_normal':   'img_balance_normal.png',
      'normal_left':     'img_balance_left.png',
      'normal_right':    'img_balance_right.png',
      'front_normal':    'img_balance_front.png',
      'back_normal':     'img_balance_back.png',
      'front_left':      'img_balance_frontleft.png',
      'front_right':     'img_balance_frontright.png',
      'back_left':       'img_balance_backleft.png',
      'back_right':      'img_balance_backright.png',
    };
    const fileName = FILE_MAP[key] ?? 'img_balance_normal.png';
    return `${BODY_BALANCE_IMG_BASE}/${fileName}`;
  }

  /** 키손실 단계 → S3 이미지 URL (96=1단계, 97=2·3단계, 98=4·5·6단계) */
  private resolveHeightLossImageUrl(stage: number): string | null {
    const FILE_MAP: Record<number, string> = {
      1: '96.png',
      2: '97.png',
      3: '97.png',
      4: '98.png',
      5: '98.png',
      6: '98.png',
    };
    const fileName = FILE_MAP[stage];
    return fileName
      ? `${HEIGHT_LOSS_IMG_BASE}/${fileName}`
      : null;
  }

  /** SKELETON_{VIEW}_{STATE}_{N} assetKey → 실제 skeleton 파일명 */
  private resolveSkeletonUrl(assetKey: string): string | null {
    const m = assetKey.match(/^SKELETON_(BACK|FRONT|SIDE)_(?:CURRENT|FUTURE|NORMAL)_([\d\-]+)$/);
    if (!m) return null;

    const view = m[1];
    const imageId = m[2]; // 예: "5-1", "62", "9"
    const imageNumber = Number(imageId); // 하이픈 포함이면 NaN

    // 측면 current/future 전용 (9~14) — 정면·후면 동일 번호는 {id}.png
    const sideCurrentFutureFileMap: Record<number, string> = {
      9: '09-pelvis-anterior-tilt-current.png',
      10: '10-pelvis-anterior-tilt-future.png',
      11: '11-pelvis-posterior-tilt-current.png',
      12: '12-pelvis-posterior-tilt-future.png',
      13: '13-sway-back-current.png',
      14: '14-sway-back-future.png',
    };

    const viewNormalFileMap: Record<string, Record<number, string>> = {
      SIDE: { 15: '15-side-normal.png' },
      FRONT: { 16: '16-front-normal.png' },
      BACK: { 17: '17-back-normal.png' },
    };

    let fileName: string;
    if (view === 'SIDE' && !isNaN(imageNumber) && sideCurrentFutureFileMap[imageNumber]) {
      fileName = sideCurrentFutureFileMap[imageNumber];
    } else if (!isNaN(imageNumber) && viewNormalFileMap[view]?.[imageNumber]) {
      fileName = viewNormalFileMap[view][imageNumber];
    } else {
      fileName = `${imageId}.png`;
    }
    return `${SKELETON_IMG_BASE}/${fileName}`;
  }

  /**
   * NOTE: 기존 하드코딩(TODO) 제거용.
   * 엑셀(체형측정리포트알고리즘 최종본)에서 추출한 텍스트/매핑을 코드에 인라인으로 반영.
   * (추후: DB/관리자 설정으로 분리 가능)
   */


  /** 엑셀 "권장/주의 생활 습관" 시트 기반(요약) */
  /** 체형별 주의 생활 습관 (라벨 + 이미지 번호) */

  /** 기존 disease key(영문) -> 엑셀에서 사용되는 체형명(한글) 매핑 */

  /** 체형 유형별 이미지 번호 매핑 (영문 키 사용) */

  /**
   * 주요 체형 카드에 표시할 최종 한글 라벨 마스터 맵.
   * 키: diseaseKey 또는 diseaseKey_RIGHT / diseaseKey_LEFT
   * 방향 없는 키(양쪽 포함) = 기본 라벨 (방향 suffix 없음)
   */

  /**
   * 양쪽(오른쪽+왼쪽) 체형이 모두 감지되었는지 확인합니다.
   */
  private static checkBothSides(diseaseKey: string, allDiseases: any[]): boolean {
    // 같은 diseaseKey를 가진 disease가 2개 이상 있고, 각각 다른 방향인지 확인
    const sameDiseases = allDiseases.filter((d: any) => d.key === diseaseKey);

    if (sameDiseases.length < 2) {
      return false;
    }

    // 오른쪽과 왼쪽이 모두 있는지 확인
    const hasRight = sameDiseases.some((d: any) => {
      const dir = this.extractDirectionFromDisease(d);
      return dir === '오른쪽';
    });

    const hasLeft = sameDiseases.some((d: any) => {
      const dir = this.extractDirectionFromDisease(d);
      return dir === '왼쪽';
    });

    return hasRight && hasLeft;
  }

  /**
   * disease 객체와 방향 정보를 기반으로 이미지 번호 키를 생성합니다.
   */
  private static getPostureImageKey(disease: any, allDiseases: any[]): string | null {
    if (!disease.key) return null;

    const direction = this.extractDirectionFromDisease(disease);
    const key = String(disease.key || '');

    // disease.key 기반으로 이미지 키 생성
    let imageKey = key;

    // 비대칭 키가 세부 접미사로 들어오는 경우를 먼저 정규화
    if (key.startsWith('SHOULDER_HEIGHT_ASYMMETRY_')) {
      if (key.includes('RIGHT')) return 'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP';
      if (key.includes('LEFT')) return 'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP';
    }
    if (key.startsWith('PELVIS_ASYMMETRY_')) {
      if (key.includes('RIGHT')) return 'PELVIS_ASYMMETRY_RIGHT_UP';
      if (key.includes('LEFT')) return 'PELVIS_ASYMMETRY_LEFT_UP';
    }

    // 방향이 필요한 체형 유형
    const needsDirection = [
      'NECK_TILT',
      'NECK_ROTATION',
      'RAISED_SHOULDER',
      'DROPPED_SHOULDER',
      'ARMS_TURNED_IN',
      'ARMS_TURNED_OUT',
      'BENT_ELBOW',
      'EXTENDED_ELBOW',
      'LEGS_TURNED_OUTWARD',
      'LEGS_TURNED_INWARD',
      'KNOCK_LEGS',
      'FLAT_FEET',
      'ARCHED_FEET',
    ];

    if (needsDirection.includes(key)) {
      // 양쪽 체형이 모두 있는지 확인
      const hasBoth = this.checkBothSides(key, allDiseases);

      if (hasBoth) {
        // 양쪽인 경우 (예: RAISED_SHOULDER_BOTH)
        imageKey = `${key}_BOTH`;
      } else if (direction === '오른쪽') {
        imageKey = `${key}_RIGHT`;
      } else if (direction === '왼쪽') {
        imageKey = `${key}_LEFT`;
      }
    }

    // 특수 케이스: 어깨높이 비대칭, 골반 비대칭은 "올라간" 방향
    if (key === 'SHOULDER_HEIGHT_ASYMMETRY' && direction) {
      imageKey = direction === '오른쪽'
        ? 'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP'
        : 'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP';
    }

    if (key === 'PELVIS_ASYMMETRY' && direction) {
      imageKey = direction === '오른쪽'
        ? 'PELVIS_ASYMMETRY_RIGHT_UP'
        : 'PELVIS_ASYMMETRY_LEFT_UP';
    }

    // 방향 문자열에서 판독이 되지 않더라도 key 자체에 RIGHT/LEFT가 있으면 보정
    if (key === 'SHOULDER_HEIGHT_ASYMMETRY' && !direction) {
      const keyStr = `${disease.result || ''} ${disease.description || ''} ${disease.detail || ''}`;
      if (keyStr.includes('오른') || keyStr.toLowerCase().includes('right')) {
        imageKey = 'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP';
      } else if (keyStr.includes('왼') || keyStr.toLowerCase().includes('left')) {
        imageKey = 'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP';
      }
    }

    if (key === 'PELVIS_ASYMMETRY' && !direction) {
      const keyStr = `${disease.result || ''} ${disease.description || ''} ${disease.detail || ''}`;
      if (keyStr.includes('오른') || keyStr.toLowerCase().includes('right')) {
        imageKey = 'PELVIS_ASYMMETRY_RIGHT_UP';
      } else if (keyStr.includes('왼') || keyStr.toLowerCase().includes('left')) {
        imageKey = 'PELVIS_ASYMMETRY_LEFT_UP';
      }
    }

    // 특수 케이스: 오다리 (바깥/안으로 돌아간 다리 조합)
    if (key === 'BOW_LEGS') {
      const hasBowBoth = this.checkBothSides('BOW_LEGS', allDiseases);
      const externalHasBoth = this.checkBothSides('LEGS_TURNED_OUTWARD', allDiseases);
      const internalHasBoth = this.checkBothSides('LEGS_TURNED_INWARD', allDiseases);

      if (hasBowBoth && externalHasBoth) {
        imageKey = 'BOW_LEGS_EXTERNAL_BOTH';
      } else if (hasBowBoth && internalHasBoth) {
        imageKey = 'BOW_LEGS_INTERNAL_BOTH';
      } else {
        const hasExternalSameSide = allDiseases.some((d: any) =>
          d.key === 'LEGS_TURNED_OUTWARD' && this.extractDirectionFromDisease(d) === direction,
        );
        const hasInternalSameSide = allDiseases.some((d: any) =>
          d.key === 'LEGS_TURNED_INWARD' && this.extractDirectionFromDisease(d) === direction,
        );

        if (hasExternalSameSide && direction) {
          imageKey = direction === '오른쪽' ? 'BOW_LEGS_EXTERNAL_RIGHT' : 'BOW_LEGS_EXTERNAL_LEFT';
        } else if (hasInternalSameSide && direction) {
          imageKey = direction === '오른쪽' ? 'BOW_LEGS_INTERNAL_RIGHT' : 'BOW_LEGS_INTERNAL_LEFT';
        }
      }
    }

    return imageKey;
  }

  /** 목에 가해지는 부담 계산 테이블 (Rt ear이 Rt shoulder 보다 앞으로 갔을 때) */

  /** 목에 가해지는 부담 계산 테이블 (Rt ear이 Rt shoulder 보다 뒤로 갔을 때) */

  /** 체형별 외형 인상 개선 효과 (엑셀 "외형 인상 영향 결과" 기반 - 영문 키) */

  /** 외형 인상(❌) → 개선 결과(✅) 변환 맵 */

  /** 체형별 동반될 수 있는 신체적 불편감 (엑셀 "증상" 기반 - 영문 키) */

  /** 체형별 질환 증상 개선 효과 */

  /** 총 건강 지수에 따른 관리 권장 문구 */

  /** 신체 균형 상태 단계별 룰 */

  private static pickTotalScoreStage(score: number) {
    const s = Math.max(0, Math.min(100, Math.floor(score || 0)));
    return (
      TOTAL_SCORE_STAGE_RULES.find((r) => s >= r.min && s <= r.max) ||
      TOTAL_SCORE_STAGE_RULES[TOTAL_SCORE_STAGE_RULES.length - 1]
    );
  }

  private static getPostureKoFromDiseaseKey(diseaseKey: string): string | null {
    if (!diseaseKey) return null;
    return DISEASE_KEY_TO_POSTURE_KO[diseaseKey] || null;
  }

  /**
   * 방향 정보를 고려하여 체형명(한글)을 반환합니다.
   * 방향성이 있는 체형의 경우 분석 데이터에서 방향을 추출합니다.
   */
  private static getPostureKoWithDirection(disease: any, allDiseases: any[]): string | null {
    if (!disease.key) return null;

    const basePostureKo = DISEASE_KEY_TO_POSTURE_KO[disease.key];
    if (!basePostureKo) return null;

    // 방향 정보가 필요한 체형 유형 목록
    const directionalPostures = [
      'NECK_TILT',           // 목 가쪽굽힘
      'NECK_ROTATION',       // 목 회전
      'SHOULDER_HEIGHT_ASYMMETRY', // 어깨높이 비대칭
      // RAISED_SHOULDER, DROPPED_SHOULDER: 최종명칭에 방향 없음
      'ARMS_TURNED_IN',      // 위팔 안쪽돌림
      'ARMS_TURNED_OUT',     // 위팔 가쪽돌림
      'BENT_ELBOW',          // 굽혀진 팔꿈치
      'EXTENDED_ELBOW',      // 과하게 펴진팔꿈치

      'TORSO_ROTATION_LEFT', // 회전된 몸통 (왼쪽)
      'TORSO_ROTATION_RIGHT',// 회전된 몸통 (오른쪽)
      'PELVIS_ASYMMETRY',    // 골반 비대칭
      'PELVIS_ROTATION_LEFT',// 골반 회전 (왼쪽)
      'PELVIS_ROTATION_RIGHT',// 골반 회전 (오른쪽)

      'LEGS_TURNED_OUTWARD', // 넙다리 가쪽돌림
      'LEGS_TURNED_INWARD',  // 넙다리 안쪽돌림
      'BOW_LEGS',            // 오다리
      'KNOCK_LEGS',          // 엑스다리
      'FLAT_FEET',           // 평발
      'ARCHED_FEET',         // 오목발
    ];

    if (directionalPostures.includes(disease.key)) {
      // disease 객체에서 방향 정보 추출
      const direction = this.extractDirectionFromDisease(disease);

      if (direction) {
        if (disease.key === 'SHOULDER_HEIGHT_ASYMMETRY') {
          return direction === '오른쪽'
            ? '어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)'
            : '어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)';
        }
        if (disease.key === 'PELVIS_ASYMMETRY') {
          return direction === '오른쪽'
            ? '골반 비대칭(오른쪽↑, 왼쪽↓)'
            : '골반 비대칭(왼쪽↑, 오른쪽↓)';
        }
        if (disease.key === 'PELVIS_ROTATION_LEFT' || disease.key === 'PELVIS_ROTATION_RIGHT') {
          return direction === '오른쪽' ? '골반 오른쪽 회전' : '골반 왼쪽 회전';
        }

        // 일반적인 경우: 간단하게 방향만 표시
        return `${basePostureKo}(${direction})`;
      }

      // TORSO_ROTATION_LEFT/RIGHT, PELVIS_ROTATION_LEFT/RIGHT는 키 자체에 방향 포함
      if (disease.key === 'TORSO_ROTATION_LEFT') {
        return '회전된 몸통(왼쪽)';
      }
      if (disease.key === 'TORSO_ROTATION_RIGHT') {
        return '회전된 몸통(오른쪽)';
      }
      if (disease.key === 'PELVIS_ROTATION_LEFT') {
        return '골반 왼쪽 회전';
      }
      if (disease.key === 'PELVIS_ROTATION_RIGHT') {
        return '골반 오른쪽 회전';
      }
    }

    return basePostureKo;
  }

  /**
   * disease 객체에서 방향(오른쪽/왼쪽) 정보를 추출합니다.
   * 다양한 형태의 방향 표현을 처리합니다:
   * - "오른쪽:176.3", "왼쪽:2.7"
   * - "올라간:179.1", "낮은:178.0", "높은:179.1"
   * - "우측으로", "좌측으로"
   */
  private static extractDirectionFromDisease(disease: any): string | null {
    // 1. disease.result, disease.description, disease.detail 체크
    const directFields = [
      disease.result,
      disease.description,
      disease.detail,
      disease.position,
      disease.direction,
    ];

    for (const field of directFields) {
      if (!field) continue;

      const fieldStr = String(field);

      // "오른쪽:176.3", "올라간:179.1", "높은:179.1", "낮은:178.0" 형태 처리
      if (fieldStr.includes(':')) {
        const parts = fieldStr.split(':');
        if (parts.length > 0) {
          const prefix = parts[0].trim();

          // 직접적인 방향 표현
          if (prefix.includes('오른') || prefix === 'right' || prefix.includes('Right')) {
            return '오른쪽';
          }
          if (prefix.includes('왼') || prefix === 'left' || prefix.includes('Left')) {
            return '왼쪽';
          }

          // 어깨/골반 비대칭 결과값: 오른쪽이 높음/올라감 → '오른쪽', 오른쪽이 낮음/내려감 → '왼쪽'
          if (prefix === '높은' || prefix === '올라간') {
            return '오른쪽';
          }
          if (prefix === '낮은' || prefix === '내려간') {
            return '왼쪽';
          }
        }
      }

      // JSON 파싱 시도: {"status":"오다리","diff":"7.9"} 형태
      try {
        if (fieldStr.startsWith('{')) {
          const parsed = JSON.parse(fieldStr);
          if (parsed.left && parsed.right) {
            // left/right 객체가 있으면 각각의 status나 diff 비교
            const leftDiff = parseFloat(parsed.left?.diff || 0);
            const rightDiff = parseFloat(parsed.right?.diff || 0);
            if (leftDiff > rightDiff) return '왼쪽';
            if (rightDiff > leftDiff) return '오른쪽';
          }
        }
      } catch (e) {
        // JSON 파싱 실패는 무시
      }

      // 일반 문자열 포함 체크
      if (fieldStr.includes('오른쪽') || fieldStr.startsWith('오른') || fieldStr.includes('우측')) {
        return '오른쪽';
      }
      if (fieldStr.includes('왼쪽') || fieldStr.startsWith('왼') || fieldStr.includes('좌측')) {
        return '왼쪽';
      }
      if (fieldStr.toLowerCase().includes('right')) {
        return '오른쪽';
      }
      if (fieldStr.toLowerCase().includes('left')) {
        return '왼쪽';
      }
    }

    return null;
  }

  /**
   * 키손실(cm) — 측면 랜드마크 기준, photoAnalysis와 동일 각도 소스.
   */
  private static calculateHeightLoss(analysisData: any, userHeight: number): number {
    try {
      return calculateHeightLossCm(userHeight, analysisData?.landmarks);
    } catch (error) {
      console.error('키손실 계산 중 오류:', error);
      return 0;
    }
  }

  /**
   * 목에 가해지는 부담(kg) — 측면 랜드마크 Rt ear / Rt shoulder 기준.
   * photoAnalysis 측면 목과 동일한 각도·방향 판정을 사용합니다.
   */
  private static calculateNeckLoad(analysisData: any): number {
    try {
      return calculateNeckLoadFromLandmarks(analysisData?.landmarks);
    } catch (error) {
      console.error('목 부담 계산 중 오류:', error);
      return 0;
    }
  }

  /**
   * 부위별 점수를 계산합니다.
   * analysisData.scoreDetail에서 각 부위의 점수를 추출하여 평균을 계산합니다.
   */
  private static calculateBodyPartScores(analysisData: any): {
    neck: number;
    shoulder: number;
    elbow: number;
    torso: number;
    pelvisWaist: number; // 표시용: pelvis 전용
    hip: number;         // 추천용: pelvis + hipJoint 통합
    legAlignment: number;
    knee: number;
    ankle: number;
    average: number;
  } {
    try {
      const scoreDetail = analysisData?.scoreDetail || {};

      const neck = calculateBodyPartScoreFromDetail(scoreDetail.neck, BODY_PART_SCORE_KEYS.neck);
      const shoulder = calculateBodyPartScoreFromDetail(scoreDetail.shoulder, BODY_PART_SCORE_KEYS.shoulder, scoreDetail);
      const pelvisWaist = calculateBodyPartScoreFromDetail(scoreDetail.pelvis, BODY_PART_SCORE_KEYS.pelvis);
      const legAlignment = calculateBodyPartScoreFromDetail(scoreDetail.lowerLimbAlignment, BODY_PART_SCORE_KEYS.lowerLimbAlignment);
      const knee = calculateBodyPartScoreFromDetail(scoreDetail.knee, BODY_PART_SCORE_KEYS.knee);
      const ankle = calculateBodyPartScoreFromDetail(scoreDetail.ankle, BODY_PART_SCORE_KEYS.ankle);

      const elbowScores = Object.values(scoreDetail.upperArm || {}).map((item: any) => item.scoreUsage ?? 100);
      const torsoScores = Object.values(scoreDetail.torso || {}).map((item: any) => item.scoreUsage ?? 100);
      const hipScores = [
        ...Object.values(scoreDetail.pelvis || {}),
        ...Object.values(scoreDetail.hipJoint || {}),
      ].map((item: any) => item.scoreUsage ?? 100);
      const elbow = elbowScores.length > 0 ? Math.min(...elbowScores) : 100;
      const torso = torsoScores.length > 0 ? Math.min(...torsoScores) : 100;
      const hip = hipScores.length > 0 ? Math.min(...hipScores) : 100;

      // 표시용 6개 부위 평균 (목/어깨/골반허리/하지정렬/무릎/발목)
      const average = Math.round((neck + shoulder + pelvisWaist + legAlignment + knee + ankle) / 6);

      return { neck, shoulder, elbow, torso, pelvisWaist, hip, legAlignment, knee, ankle, average };
    } catch (error) {
      console.error('부위별 점수 계산 중 오류:', error);
      return { neck: 100, shoulder: 100, elbow: 100, torso: 100, pelvisWaist: 100, hip: 100, legAlignment: 100, knee: 100, ankle: 100, average: 100 };
    }
  }

  /**
   * 신체 균형 상태 단계를 계산합니다.
   */
  /** 신체 부위별 기능 점수 단계 규칙 (81~100=1단계정상 … 0~30=6단계위험) */

  private static getBodyPartScoreStage(score: number | null | undefined) {
    if (score === null || score === undefined) return { stage: 0, label: '-', referenceScore: null };
    const s = Math.max(0, Math.min(100, Math.floor(score || 0)));
    return (
      BODY_PART_SCORE_STAGE_RULES.find((r) => s >= r.min && s <= r.max) ??
      BODY_PART_SCORE_STAGE_RULES[BODY_PART_SCORE_STAGE_RULES.length - 1]
    );
  }

  private static getBalanceStateStage(score: number | null | undefined) {
    if (score === null || score === undefined) {
      return { stage: 0, label: '-', description: '체형 측정을 해주세요!' };
    }
    const s = Math.max(0, Math.min(100, Math.floor(score || 0)));
    return (
      BALANCE_STATE_RULES.find((r) => s >= r.min && s <= r.max) ||
      BALANCE_STATE_RULES[BALANCE_STATE_RULES.length - 1]
    );
  }

  /**
   * 뼈대 이미지를 분석 데이터 기반으로 선택합니다.
   */
  private static getSkeletonImages(analysisData: any) {
    // 체형 사진 상세분석 워딩(정면/후면/측면)과 동일 기준으로 분류
    const wording = resolveSkeletonWording(analysisData);
    const pelvisDirection = wording.pelvisMove;
    const shoulderAsymmetry = wording.shoulderAsym;
    const hasSwayBack = wording.hasSwayback;
    const legType = wording.legType;
    const kneeType = wording.kneeType;

    // 정면/후면 이미지 선택 (뼈대 정면/후면 표 기준)
    const getFrontBackImages = (legType: 'normal' | 'bow' | 'knock') => {
      const mapping: Record<string, any> = {
        // 골반 우측이동 + 어깨 좌측↑ (우측높이↓)
        'right_left_high': { front: { current: '1-1', future: '2-1' }, back: { current: '1-3', future: '2-3' } },
        'right_left_high_bow': { front: { current: 2, future: 7 }, back: { current: 4, future: 9 } },
        'right_left_high_knock': { front: { current: 3, future: 8 }, back: { current: 5, future: 10 } },

        // 골반 우측이동 + 어깨 우측↑ (좌측높이↓)
        'right_right_high': { front: { current: '3-1', future: '4-1' }, back: { current: '3-3', future: '4-3' } },
        'right_right_high_bow': { front: { current: 22, future: 27 }, back: { current: 24, future: 29 } },
        'right_right_high_knock': { front: { current: 23, future: 28 }, back: { current: 25, future: 30 } },

        // 골반 좌측이동 + 어깨 좌측↑ (우측높이↓)
        'left_left_high': { front: { current: '3-2', future: '4-2' }, back: { current: '3-4', future: '4-4' } },
        'left_left_high_bow': { front: { current: 32, future: 37 }, back: { current: 34, future: 39 } },
        'left_left_high_knock': { front: { current: 33, future: 38 }, back: { current: 35, future: 40 } },

        // 골반 좌측이동 + 어깨 우측↑ (좌측높이↓)
        'left_right_high': { front: { current: '1-2', future: '2-2' }, back: { current: '1-4', future: '2-4' } },
        'left_right_high_bow': { front: { current: 12, future: 17 }, back: { current: 14, future: 19 } },
        'left_right_high_knock': { front: { current: 13, future: 18 }, back: { current: 15, future: 20 } },

        // 골반 중앙 + 어깨 좌측↑ (우측높이↓)
        'center_left_high': { front: { current: '5-1', future: '6-1' }, back: { current: '5-3', future: '6-3' } },
        'center_left_high_bow': { front: { current: 42, future: 47 }, back: { current: 44, future: 49 } },
        'center_left_high_knock': { front: { current: 43, future: 48 }, back: { current: 45, future: 50 } },

        // 골반 중앙 + 어깨 우측↑ (좌측높이↓)
        'center_right_high': { front: { current: '5-2', future: '6-2' }, back: { current: '5-4', future: '6-4' } },
        'center_right_high_bow': { front: { current: 52, future: 57 }, back: { current: 54, future: 59 } },
        'center_right_high_knock': { front: { current: 53, future: 58 }, back: { current: 55, future: 60 } },

        // 골반 중앙 + 어깨 대칭 (좌우 높이 같음)
        'center_normal': { front: { current: 62, future: 67 }, back: { current: 64, future: 69 } },
        // center_normal_bow, center_normal_knock: 검은 칸 (해당 이미지 없음) → null
      };

      const key = `${pelvisDirection}_${shoulderAsymmetry}${legType === 'bow' ? '_bow' : legType === 'knock' ? '_knock' : ''}`;
      return mapping[key] ?? (mapping[`${pelvisDirection}_${shoulderAsymmetry}`] ?? mapping['center_normal']);
    };

    // 측면 이미지 선택 (뼈대 측면 표 기준)
    const getSideImages = (kneeType: 'normal' | 'bent' | 'back') => {
      const mapping: Record<string, any> = {
        // Rt hip이 Rt shoulder에 비해 앞으로 (스웨이백)
        'swayback': { current: 13, future: 14 },
        'swayback_bent': { current: 72, future: 75 },
        'swayback_back': { current: 73, future: 76 },

        // 스웨이백X + 골반전방경사
        'forward': { current: 9, future: 10 },
        'forward_bent': { current: 78, future: 81 },
        'forward_back': { current: 79, future: 82 },

        // 스웨이백X + 골반후방경사
        'backward': { current: 11, future: 12 },
        'backward_bent': { current: 84, future: 87 },
        'backward_back': { current: 85, future: 88 },

        // 스웨이백X + 골반경사정상
        'normal': { current: 90, future: 93 },
        // normal_bent, normal_back: 검은 칸 (해당 이미지 없음) → null
      };

      let pelvisType = 'normal';
      if (hasSwayBack) pelvisType = 'swayback';
      else if (wording.pelvisTilt === 'forward') pelvisType = 'forward';
      else if (wording.pelvisTilt === 'backward') pelvisType = 'backward';

      const key = `${pelvisType}${kneeType === 'bent' ? '_bent' : kneeType === 'back' ? '_back' : ''}`;
      return mapping[key] ?? (mapping[pelvisType] ?? mapping['normal']);
    };

    const frontBack = getFrontBackImages(legType);
    const side = getSideImages(kneeType);

    return {
      front: {
        current: frontBack.front.current,
        future: frontBack.front.future,
        normal: 16,
      },
      back: {
        current: frontBack.back.current,
        future: frontBack.back.future,
        normal: 17,
      },
      side: {
        current: side.current,
        future: side.future,
        normal: 15,
      },
    };
  }

  /**
   * 종합 조언 문구를 생성합니다.
   */
  private static buildOverallAdvice(
    memberName: string,
    diseases: any[],
    totalScore: number,
    trainerComment?: string,
    scoreDetail: any = {},
  ): string {
    // scoreDetail 기반 방향 추론 (SHOULDER_HEIGHT_ASYMMETRY, PELVIS_ASYMMETRY 등)
    const inferDirectionFromScoreDetail = (diseaseKey: string): string | null => {
      let raw: any = null;
      if (diseaseKey === 'SHOULDER_HEIGHT_ASYMMETRY') raw = scoreDetail.shoulder?.shoulderHeightAsymmetry?.result;
      else if (diseaseKey === 'PELVIS_ASYMMETRY') raw = scoreDetail.pelvis?.pelvisAsymmetry?.result;
      const txt = String(raw || '');
      if (txt.includes('높은') || txt.includes('올라간')) return '오른쪽';
      if (txt.includes('낮은') || txt.includes('내려간')) return '왼쪽';
      return null;
    };

    // 1. 가장 안좋은 3개 체형 유형 (주요체형/목록/상세와 동일한 rankBodyDiseases 기준)
    const top3Diseases = rankBodyDiseases(diseases).slice(0, 3);

    const diseaseKeyToLabel: Record<string, string> = {
      NECK_TILT: '목 가쪽굽힘',
      NECK_ROTATION: '목 회전',
      TURTLE_NECK: '거북목',
      STRAIGHT_NECK: '일자목',
      RAISED_NECK: '들임목',
      SHOULDER_HEIGHT_ASYMMETRY: '어깨높이 비대칭',
      RAISED_SHOULDER: '올라간 어깨',
      DROPPED_SHOULDER: '처진 어깨',
      ROUNDED_SHOULDER: '라운드숄더',
      STRAIGHT_SHOULDER: '과도하게 펴진 어깨',
      ARMS_TURNED_IN: '위팔 안쪽돌림',
      ARMS_TURNED_OUT: '위팔 가쪽돌림',
      BENT_ELBOW: '굽혀진 팔꿈치',
      EXTENDED_ELBOW: '과하게 펴진팔꿈치',
      HUNCHED_BACK: '굽은등',
      FLAT_BACK: '펴진등',
      PELVIS_TILTS_FORWARD: '허리 과전만 & 골반 전방경사',
      PELVIS_TILTS_BACKWARD: '일자허리 & 골반 후방경사',
      TORSO_TILTED_RIGHT: '몸통 오른쪽 가쪽굽힘',
      TORSO_TILTED_LEFT: '몸통 왼쪽 가쪽굽힘',
      TORSO_ROTATION_LEFT: '회전된 몸통(왼쪽)',
      TORSO_ROTATION_RIGHT: '회전된 몸통(오른쪽)',
      SWAY_BACK: '스웨이백',
      PELVIS_ASYMMETRY: '골반 비대칭',
      PELVIS_ROTATION_LEFT: '골반 왼쪽 회전',
      PELVIS_ROTATION_RIGHT: '골반 오른쪽 회전',
      PELVIS_MOVE_RIGHT: '오른쪽으로 이동된 골반',
      PELVIS_MOVE_LEFT: '왼쪽으로 이동된 골반',
      LEGS_TURNED_OUTWARD: '넙다리 가쪽돌림',
      LEGS_TURNED_INWARD: '넙다리 안쪽돌림',
      BOW_LEGS: '오다리',
      KNOCK_LEGS: '엑스다리',
      BACK_KNEES: '과하게 펴진 무릎',
      BENT_KNEES: '굽혀진 무릎',
      FLAT_FEET: '평발',
      ARCHED_FEET: '오목발',
      ANKLE_MOVE_OUTWARD: '발목 가쪽번짐',
      ANKLE_MOVE_INWARD: '발목 안쪽번짐',
    };

    const postureNames = top3Diseases
      .map((d) => this.getPostureKoWithDirection(d, diseases) || diseaseKeyToLabel[d.key] || d.key)
      .join('/');

    // 2. 외형 인상 개선 2개 + 신체적 불편감 개선 2개 = 4개
    // 배열 랜덤 셔플 헬퍼
    const shuffleArr = <T>(arr: T[]): T[] => {
      const a = [...arr];
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    };

    // 외형 인상 개선 수집 (top 3 체형에서, 랜덤 2개 선택)
    const allImprovements: string[] = [];
    top3Diseases.forEach((d) => {
      const imageKey = MeasurementReportService.getPostureImageKey(d, diseases);
      const impressions = imageKey ? POSTURE_IMPRESSION_MAP[imageKey] : null;
      const impressionList = impressions ?? POSTURE_IMPRESSION_MAP[d.key] ?? [];
      const improvements = impressionList.map(
        (imp) => IMPRESSION_TO_IMPROVEMENT[imp] ?? imp
      );
      allImprovements.push(...improvements);
    });
    const pickedImprovements = shuffleArr(Array.from(new Set(allImprovements))).slice(0, 2);

    // 신체적 불편감 개선 수집 (top 3 체형에서, 랜덤 2개 선택 후 '완화' 추가)
    const allDiscomforts: string[] = [];
    top3Diseases.forEach((d) => {
      const imageKey = MeasurementReportService.getPostureImageKey(d, diseases);
      const bk = DISEASE_KEY_NORMALIZATION[imageKey ?? ''] ?? DISEASE_KEY_NORMALIZATION[d.key] ?? d.key;
      const discomfortList = pickRandom(BODY_TYPE_DISCOMFORT_LIST[bk] ?? [], 3);
      allDiscomforts.push(...discomfortList);
    });
    const pickedDiscomforts = shuffleArr(Array.from(new Set(allDiscomforts))).slice(0, 2).map(d =>
      DISCOMFORT_TO_FUNCTIONAL_CHANGE[d] ?? `${d} 완화`
    );

    // 외형 개선 2개 + 신체적 불편감 개선 2개 합산
    const selectedImprovements = [...pickedImprovements, ...pickedDiscomforts].join('/');

    // 3. 주의해야 할 생활 습관 (최대 3개) - 방향 정보 고려
    const allHabits: string[] = [];
    top3Diseases.forEach((d) => {
      // 1차: 방향 정보를 포함한 체형명으로 조회
      const postureKoWithDir = this.getPostureKoWithDirection(d, diseases);
      let habits = postureKoWithDir ? CAUTION_HABITS_BY_POSTURE_KO[postureKoWithDir] : null;

      // 1.5차: scoreDetail 기반 방향 추론 (SHOULDER_HEIGHT_ASYMMETRY, PELVIS_ASYMMETRY)
      if (!habits || habits.length === 0) {
        const direction = inferDirectionFromScoreDetail(d.key);
        if (direction) {
          const baseKo = MeasurementReportService.getPostureKoFromDiseaseKey(d.key);
          if (baseKo) {
            const dirKey = `${baseKo}(${direction})`;
            habits = CAUTION_HABITS_BY_POSTURE_KO[dirKey] || null;
            if (!habits && d.key === 'SHOULDER_HEIGHT_ASYMMETRY') {
              const fullKey = direction === '오른쪽'
                ? '어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)'
                : '어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)';
              habits = CAUTION_HABITS_BY_POSTURE_KO[fullKey] || null;
            }
            if (!habits && d.key === 'PELVIS_ASYMMETRY') {
              const fullKey = direction === '오른쪽'
                ? '골반 비대칭(오른쪽↑, 왼쪽↓)'
                : '골반 비대칭(왼쪽↑, 오른쪽↓)';
              habits = CAUTION_HABITS_BY_POSTURE_KO[fullKey] || null;
            }
          }
        }
      }

      // 2차 fallback: 방향 없는 기본 체형명으로 조회
      if (!habits || habits.length === 0) {
        const postureKo = this.getPostureKoFromDiseaseKey(d.key);
        habits = postureKo ? CAUTION_HABITS_BY_POSTURE_KO[postureKo] : null;
      }

      if (habits && habits.length > 0) {
        // habit 객체에서 label만 추출
        allHabits.push(...habits.map(h => h.label));
      }
    });

    const uniqueHabits = Array.from(new Set(allHabits));
    const selectedHabits = uniqueHabits.slice(0, 3).join('/');

    // 4. 총 건강 지수에 따른 관리 권장
    const managementRec = MANAGEMENT_RECOMMENDATION_BY_SCORE.find(
      (r) => totalScore >= r.min && totalScore <= r.max,
    );
    const managementText = managementRec?.text || '지속적인 관리가 필요합니다.';

    // 5. 최종 조합
    let advice = `${memberName}님의 현재 체형은 <b>${postureNames}</b> 개선에 우선적으로 집중할 필요가 있으며, \n`;

    if (selectedImprovements) {
      advice += `해당 정렬이 회복될 경우 <b>${selectedImprovements}</b>와 같은 기능적 개선이 기대됩니다.\n`;
    }

    if (selectedHabits) {
      advice += `이를 위해서는 <b>${selectedHabits}</b>와 같은\n습관을 주의해야 하며,`;
    }

    advice += `<b>${managementText}</b>`;

    return advice;
  }

  /**
   * 체형측정 리포트 조회 (analysisData를 리포트 구조로 변환)
   */
  async getBodyMeasurementReport(
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<BodyMeasurementReportResponseDto> {
    const resolvedMemberId = await this.resolveShareableBodyReportMemberId(memberId, id);
    const payload = lang === 'en'
      ? await this.ensureBodyReportEnglishPayload(resolvedMemberId, id)
      : await this.buildBodyMeasurementReportPayload(resolvedMemberId, id);

    return this.withCenterLogoForBodyReport(resolvedMemberId, id, payload);
  }

  /**
   * 체형 리포트 API 응답 payload 조립.
   * includeTrainerComment=false 시 영문 스냅샷 생성용 (코멘트는 저장 컬럼 제외).
   */
  async buildBodyMeasurementReportPayload(
    memberId: string,
    id: string,
    options?: { includeTrainerComment?: boolean },
  ): Promise<BodyMeasurementReportResponseDto> {
    const report = await this.bodyReportRepo.findOne({
      where: { id, userId: memberId },
      relations: ['user'],
    });
    if (!report) {
      throw new NotFoundException('체형측정 리포트를 찾을 수 없습니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedId: id } });
    files.sort((a, b) => {
      if (a.division && b.division) {
        return a.division.localeCompare(b.division);
      }
      return 0;
    });

    const analysisData = report.analysisData || {};
    const user = report.user;
    const includeTrainerComment = options?.includeTrainerComment ?? true;

    const reportData: BodyMeasurementReportResponseDto = {
      reportTitle: 'i-POSTURE 체형리포트',
      issuedAt: report.createdAt.toISOString().split('T')[0],
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : new Date(report.createdAt).toISOString(),
      member: {
        name: user.name,
        birthDate: user.birthDate || '',
        gender: user.gender === 'MALE' ? '남성' : user.gender === 'FEMALE' ? '여성' : '기타',
        shootingDate: report.createdAt.toISOString().split('T')[0],
      },
      totalScore: await this.buildTotalScore(report, memberId),
      majorPostures: this.buildMajorPostures(analysisData),
      photoAnalysis: this.buildPhotoAnalysis(analysisData, files),
      postureDetails: this.buildPostureDetails(analysisData),
      recommendedHabits: this.buildRecommendedHabits(),
      summary: this.buildSummary(analysisData, report, { includeTrainerComment }),
      files: files.map((f) => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      landmarks: analysisData.landmarks || null,
      previewWidth: analysisData.previewWidth ?? null,
      previewHeight: analysisData.previewHeight ?? null,
      scoreDetail: analysisData.scoreDetail || null,
    };

    return reportData;
  }

  /**
   * 한글 payload 를 Google Translate 로 영문 변환 (호출·저장 타이밍은 별도 결정).
   */
  async buildBodyMeasurementEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<BodyMeasurementReportResponseDto> {
    const koreanPayload = await this.buildBodyMeasurementReportPayload(memberId, id, {
      includeTrainerComment: false,
    });
    const translated = await this.bodyReportTranslationService.translatePayloadToEnglish(
      koreanPayload as unknown as Record<string, unknown>,
    );
    return translated as unknown as BodyMeasurementReportResponseDto;
  }

  /**
   * 영문 payload 생성 후 display_payload_en 컬럼에 저장.
   */
  async generateAndPersistBodyReportEnglishPayload(
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<BodyMeasurementReportResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const englishPayload = await this.buildBodyMeasurementEnglishPayload(memberId, id);
    await this.bodyReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return this.withCenterLogo(englishPayload, trainerId);
  }

  /**
   * 영문 조회 시 display_payload_en 이 없으면 최초 1회 번역·저장 후 반환.
   */
  private async ensureBodyReportEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<BodyMeasurementReportResponseDto> {
    const report = await this.bodyReportRepo.findOne({
      where: { id, userId: memberId },
      select: ['id', 'displayPayloadEn'],
    });
    if (!report) {
      throw new NotFoundException('체형측정 리포트를 찾을 수 없습니다.');
    }
    if (report.displayPayloadEn) {
      return report.displayPayloadEn as BodyMeasurementReportResponseDto;
    }

    // 운영 환경: 자동 번역 비활성화 → 저장된 영문 없으면 한글 fallback
    if (!this.isReportEnAutoTranslateOnGetEnabled()) {
      return this.buildBodyMeasurementReportPayload(memberId, id);
    }

    const englishPayload = await this.buildBodyMeasurementEnglishPayload(memberId, id);
    await this.bodyReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return englishPayload;
  }

  /**
   * 정밀 리포트 영문 조회 시 display_payload_en 이 없으면 최초 1회 번역·저장 후 반환.
   */
  private async ensurePrecisionReportEnglishPayload<T>(
    memberId: string,
    id: string,
    buildEnglish: () => Promise<T>,
    buildKorean: () => Promise<T>,
  ): Promise<T> {
    const stored = await this.precisionReportTranslationService.getDisplayPayloadEn(id, memberId);
    if (stored) {
      return stored as T;
    }

    // 운영 환경: 자동 번역 비활성화 → 저장된 영문 없으면 한글 fallback
    if (!this.isReportEnAutoTranslateOnGetEnabled()) {
      return buildKorean();
    }

    const englishPayload = await buildEnglish();
    await this.precisionReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return englishPayload;
  }

    /**
     * 정밀측정 추천 부위 조회 (최신 체형리포트 기준)
     * 신체 부위별 점수(bodyFunctionScores)에서 점수가 낮은 부위 순으로 추천
     */
    async getRecommendedPrecisionParts(
    trainerId: string,
    memberId: string,
    bodyReportId?: string,
    ): Promise<RecommendedPrecisionPartsResponseDto> {
    // 권한 확인
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    // 체형리포트 조회: bodyReportId 있으면 해당 리포트 우선, 없으면 최신 리포트
    const latestReport = bodyReportId
      ? await this.bodyReportRepo.findOne({ where: { id: bodyReportId, userId: memberId } })
        ?? await this.bodyReportRepo.findOne({ where: { userId: memberId }, order: { createdAt: 'DESC' } })
      : await this.bodyReportRepo.findOne({ where: { userId: memberId }, order: { createdAt: 'DESC' } });

    if (!latestReport) {
      throw new NotFoundException('체형측정 리포트가 없습니다.');
    }

    const analysisData = latestReport.analysisData || {};

    // 신체 부위별 점수 계산
    const bodyPartScores = MeasurementReportService.calculateBodyPartScores(analysisData);

    // 신체 기능별 점수(6개 표시 부위) → ROM 검사 추천 타입 매핑
    // 목 → 목(NECK)
    // 어깨 → 어깨관절(SHOULDER)
    // 골반/허리 → 몸통(TORSO), 엉덩관절(HIP)
    // 하지정렬 → 엉덩관절(HIP), 무릎관절(KNEE)
    // 무릎 → 무릎관절(KNEE)
    // 발목 → 발목관절(ANKLE)
    const partScoreList = [
      {
        type: 'NECK',
        label: '목',
        score: bodyPartScores.neck,
        measurementTypes: ['NECK'],
      },
      {
        type: 'SHOULDER',
        label: '어깨',
        score: bodyPartScores.shoulder,
        measurementTypes: ['SHOULDER'],
      },
      {
        type: 'PELVIS_WAIST',
        label: '골반/허리',
        score: bodyPartScores.pelvisWaist,
        measurementTypes: ['TORSO', 'HIP'],
      },
      {
        type: 'LEG_ALIGNMENT',
        label: '하지정렬',
        score: bodyPartScores.legAlignment,
        measurementTypes: ['HIP', 'KNEE'],
      },
      {
        type: 'KNEE',
        label: '무릎',
        score: bodyPartScores.knee,
        measurementTypes: ['KNEE'],
      },
      {
        type: 'ANKLE',
        label: '발목',
        score: bodyPartScores.ankle,
        measurementTypes: ['ANKLE'],
      },
    ];

    // 점수 낮은 순으로 정렬 (낮을수록 안 좋음)
    const sortedParts = partScoreList.sort((a, b) => a.score - b.score);

    // 상위 2개 추출 (추천 ROM 검사 타입은 중복 제거 후 최대 3개)
    const top3 = sortedParts.slice(0, 2);

    // 추천 사유 생성
    const recommendedParts = top3.map((part, index) => {
      let reason = '';
      if (part.score >= 81) {
        reason = `${part.label} 부위가 정상 범위이지만, 정밀 검사를 통해 더 정확한 상태를 확인할 수 있습니다.`;
      } else if (part.score >= 71) {
        reason = `${part.label} 부위가 양호한 상태이나, 정밀 검사를 통해 예방 관리가 가능합니다.`;
      } else if (part.score >= 61) {
        reason = `${part.label} 부위에 주의가 필요합니다. 정밀 검사를 통해 체계적인 관리를 시작하세요.`;
      } else if (part.score >= 51) {
        reason = `${part.label} 부위가 경계 단계입니다. 정밀 검사를 통해 집중 관리가 필요합니다.`;
      } else if (part.score >= 31) {
        reason = `${part.label} 부위가 심각한 수준입니다. 정밀 검사를 통한 즉시 관리를 권장합니다.`;
      } else {
        reason = `${part.label} 부위가 위험 수준입니다. 정밀 검사를 통한 전문적인 관리가 필수적입니다.`;
      }

      return {
        type: part.type,
        label: part.label,
        score: part.score,
        measurementTypes: part.measurementTypes,
        rank: index + 1,
        reason,
      };
    });

    // 추천된 3개 부위의 measurementTypes를 flat + 중복제거하여 반환
    const recommendedMeasurementTypes: string[] = [];
    for (const part of recommendedParts) {
      for (const mt of part.measurementTypes) {
        if (!recommendedMeasurementTypes.includes(mt)) {
          recommendedMeasurementTypes.push(mt);
        }
      }
    }

    return {
      recommendedParts,
      recommendedMeasurementTypes,
      baseReportId: latestReport.id,
      baseReportDate: latestReport.createdAt.toISOString().split('T')[0],
    };
    }

    private async buildTotalScore(report: BodyReportEntity, memberId: string) {
      const hasMeasuredScore = report.totalScore !== null && report.totalScore !== undefined;
      const score = hasMeasuredScore ? (report.totalScore as number) : 0;
      const stage = MeasurementReportService.pickTotalScoreStage(score);
      const label = hasMeasuredScore ? stage.label : '-';
      const headline = hasMeasuredScore ? stage.headline : '체형 측정을 해주세요!';
      const stageText = hasMeasuredScore ? stage.stageText : '체형 측정을 해주세요!';

    // 최근 12개월 측정 이력 조회
    const trendData = await this.buildTrendData(memberId);

    return {
      score,
      headline,
      stageText,
      distribution: {
        ranges: [
          { label: '위험', min: 0, max: 30 },
          { label: '심각', min: 31, max: 50 },
          { label: '경계', min: 51, max: 60 },
          { label: '주의', min: 61, max: 70 },
          { label: '경미', min: 71, max: 80 },
          { label: '정상', min: 81, max: 100 },
        ],
        current: { label, score },
      },
      trend: trendData,
    };
  }

  /**
   * 모든 측정 이력을 조회하여 trend 데이터 생성
   */
  private async buildTrendData(memberId: string) {
    // 해당 회원의 전체 체형 측정 이력 조회
    const reports = await this.bodyReportRepo.find({
      where: {
        userId: memberId,
      },
      order: {
        createdAt: 'ASC',
      },
      select: ['id', 'totalScore', 'createdAt'],
    });

    if (reports.length === 0) {
      return {
        xAxisLabels: [],
        points: [],
        note: '측정 이력이 없습니다.',
      };
    }

    // 월별로 그룹화 (같은 월에 여러 측정이 있으면 최신 것만)
    const monthlyData = new Map<string, { score: number; date: Date }>();

    reports.forEach(r => {
      const monthKey = `${r.createdAt.getFullYear()}-${String(r.createdAt.getMonth() + 1).padStart(2, '0')}`;
      const existing = monthlyData.get(monthKey);

      if (!existing || r.createdAt > existing.date) {
        monthlyData.set(monthKey, {
          score: r.totalScore || 0,
          date: r.createdAt,
        });
      }
    });

    // 실제 측정한 월만 추출
    const xAxisLabels: string[] = [];
    const points: Array<{ label: string; score: number }> = [];

    // 월별 데이터를 날짜순으로 정렬
    const sortedMonths = Array.from(monthlyData.entries()).sort((a, b) => {
      return a[1].date.getTime() - b[1].date.getTime();
    });

    sortedMonths.forEach(([monthKey, data]) => {
      const date = data.date;
      const monthLabel = `${date.getMonth() + 1}월`;

      xAxisLabels.push(monthLabel);
      points.push({
        label: `${date.getMonth() + 1}.${String(date.getDate()).padStart(2, '0')}`,
        score: data.score,
      });
    });

    return {
      xAxisLabels,
      points,
      note: '',
    };
  }

  private buildMajorPostures(analysisData: any) {
    const diseases = analysisData.disease || [];
    const scoreDetail = analysisData?.scoreDetail || {};

    // scoreDetail에서 방향 또는 양쪽 여부 추론 ('오른쪽'|'왼쪽'|'양쪽'|null)
    const inferDirectionFromScoreDetail = (diseaseKey: string): string | null => {
      if (diseaseKey === 'NECK_TILT') {
        const txt = String(scoreDetail.neck?.neckTilt?.result || '');
        if (txt.includes('오른') || txt.toLowerCase().includes('right')) return '오른쪽';
        if (txt.includes('왼') || txt.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      if (diseaseKey === 'NECK_ROTATION') {
        const txt = String(scoreDetail.neck?.neckRotation?.result || '');
        if (txt.includes('오른') || txt.toLowerCase().includes('right')) return '오른쪽';
        if (txt.includes('왼') || txt.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      if (diseaseKey === 'SHOULDER_HEIGHT_ASYMMETRY') {
        // result = "낮은:각도" → 오른쪽 낮음 → 왼쪽↑; "높은:각도" → 오른쪽↑
        const status = String(scoreDetail.shoulder?.shoulderHeightAsymmetry?.result || '').split(':')[0];
        if (status === '높은') return '오른쪽';
        if (status === '낮은') return '왼쪽';
        return null;
      }
      if (diseaseKey === 'PELVIS_ASYMMETRY') {
        const status = String(scoreDetail.pelvis?.pelvisAsymmetry?.result || '').split(':')[0];
        if (status === '올라간') return '오른쪽';
        if (status === '내려간') return '왼쪽';
        return null;
      }
      // 넙다리 가쪽돌림 / 안쪽돌림 — "leftDir:rightDir"
      if (diseaseKey === 'LEGS_TURNED_OUTWARD') {
        const parts = String(scoreDetail.hipJoint?.legsTurnedOutwardOrInward?.result || '').split(':');
        const lo = parts[0] === '바깥', ro = parts[1] === '바깥';
        if (lo && ro) return '양쪽';
        if (lo) return '왼쪽';
        if (ro) return '오른쪽';
        return null;
      }
      if (diseaseKey === 'LEGS_TURNED_INWARD') {
        const parts = String(scoreDetail.hipJoint?.legsTurnedOutwardOrInward?.result || '').split(':');
        const li = parts[0] === '안쪽', ri = parts[1] === '안쪽';
        if (li && ri) return '양쪽';
        if (li) return '왼쪽';
        if (ri) return '오른쪽';
        return null;
      }
      // 엑스다리 / 오다리 — JSON { left: { status }, right: { status } }
      if (diseaseKey === 'KNOCK_LEGS') {
        try {
          const p = JSON.parse(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.result || '{}');
          const lk = p.left?.status === '엑스다리', rk = p.right?.status === '엑스다리';
          if (lk && rk) return '양쪽';
          if (lk) return '왼쪽';
          if (rk) return '오른쪽';
        } catch {}
        return null;
      }
      if (diseaseKey === 'BOW_LEGS') {
        try {
          const p = JSON.parse(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.result || '{}');
          const lb = p.left?.status === '오다리', rb = p.right?.status === '오다리';
          if (lb && rb) return '양쪽';
          if (lb) return '왼쪽';
          if (rb) return '오른쪽';
        } catch {}
        return null;
      }
      // 올라간 / 처진 어깨 — "leftStatus:rightStatus"
      if (diseaseKey === 'RAISED_SHOULDER') {
        const parts = String(scoreDetail.shoulder?.raisedOrDroppedShoulder?.result || '').split(':');
        const lr = parts[0] === '올라간', rr = parts[1] === '올라간';
        if (lr && rr) return '양쪽';
        if (lr) return '왼쪽';
        if (rr) return '오른쪽';
        return null;
      }
      if (diseaseKey === 'DROPPED_SHOULDER') {
        const parts = String(scoreDetail.shoulder?.raisedOrDroppedShoulder?.result || '').split(':');
        const ld = parts[0] === '처진', rd = parts[1] === '처진';
        if (ld && rd) return '양쪽';
        if (ld) return '왼쪽';
        if (rd) return '오른쪽';
        return null;
      }
      // 평발 / 오목발 — "왼쪽:X, 오른쪽:Y" (FLAT < 90, ARCHED >= 91)
      if (diseaseKey === 'FLAT_FEET') {
        const raw = String(scoreDetail.ankle?.feetFlatOrArched?.result || '');
        const lm = raw.match(/왼쪽:([\d.]+)/), rm = raw.match(/오른쪽:([\d.]+)/);
        if (lm && rm) {
          const lf = parseFloat(lm[1]) < 90, rf = parseFloat(rm[1]) < 90;
          if (lf && rf) return '양쪽';
          if (lf) return '왼쪽';
          if (rf) return '오른쪽';
        }
        return null;
      }
      if (diseaseKey === 'ARCHED_FEET') {
        const raw = String(scoreDetail.ankle?.feetFlatOrArched?.result || '');
        const lm = raw.match(/왼쪽:([\d.]+)/), rm = raw.match(/오른쪽:([\d.]+)/);
        if (lm && rm) {
          const la = parseFloat(lm[1]) >= 91, ra = parseFloat(rm[1]) >= 91;
          if (la && ra) return '양쪽';
          if (la) return '왼쪽';
          if (ra) return '오른쪽';
        }
        return null;
      }
      return null;
    };

    // 모든 방법을 시도해서 방향 추출 (imageKey에서도 추론 가능)
    const resolveDirection = (d: any, imgKey?: string | null): string | null => {
      const byField = MeasurementReportService.extractDirectionFromDisease(d);
      if (byField) return byField;
      const key = String(d?.key || '');
      if (key.includes('RIGHT')) return '오른쪽';
      if (key.includes('LEFT')) return '왼쪽';
      // imageKey에서 방향 역추론 (SHOULDER_HEIGHT_ASYMMETRY 등 keyStr 기반으로 imageKey만 올바른 경우)
      if (imgKey?.includes('_RIGHT')) return '오른쪽';
      if (imgKey?.includes('_LEFT')) return '왼쪽';
      return inferDirectionFromScoreDetail(key);
    };

    // 방향 포함 라벨 생성 — POSTURE_CARD_LABEL_MAP 마스터에서만 조회
    const buildCardLabel = (d: any, baseLabel: string, imgKey?: string | null): string => {
      const key = String(d?.key || '');
      const direction = resolveDirection(d, imgKey);
      const map = POSTURE_CARD_LABEL_MAP;

      // 1. 방향이 있으면 directionKey(_RIGHT/_LEFT) 먼저 조회
      if (direction === '오른쪽' || direction === '왼쪽') {
        const suffix = direction === '오른쪽' ? '_RIGHT' : '_LEFT';
        const directionalKey = `${key}${suffix}`;
        if (map[directionalKey]) return map[directionalKey];
      }

      // 2. 기본 key 조회 (방향 없음, 양쪽, key 자체에 방향 포함된 경우)
      if (map[key]) return map[key];

      // 3. 최종 fallback (맵에 없는 새 질환 대비)
      return baseLabel;
    };

    // 체형 유형 한글 매핑 (전체) - buildCardLabel fallback용
    const diseaseKeyToLabel: Record<string, string> = {
      NECK_TILT: '목 가쪽굽힘',
      NECK_ROTATION: '목 회전',
      TURTLE_NECK: '거북목',
      STRAIGHT_NECK: '일자목',
      RAISED_NECK: '들임목',
      SHOULDER_HEIGHT_ASYMMETRY: '어깨높이 비대칭',
      RAISED_SHOULDER: '올라간 어깨',
      DROPPED_SHOULDER: '처진 어깨',
      ROUNDED_SHOULDER: '라운드숄더',
      STRAIGHT_SHOULDER: '과도하게 펴진 어깨',
      ARMS_TURNED_IN: '위팔 안쪽돌림',
      ARMS_TURNED_OUT: '위팔 가쪽돌림',
      BENT_ELBOW: '굽혀진 팔꿈치',
      EXTENDED_ELBOW: '과하게 펴진팔꿈치',
      HUNCHED_BACK: '굽은등',
      FLAT_BACK: '펴진등',
      PELVIS_TILTS_FORWARD: '허리 과전만 & 골반 전방경사',
      PELVIS_TILTS_BACKWARD: '일자허리 & 골반 후방경사',
      TORSO_TILTED_RIGHT: '몸통 오른쪽 가쪽굽힘',
      TORSO_TILTED_LEFT: '몸통 왼쪽 가쪽굽힘',
      TORSO_ROTATION_LEFT: '회전된 몸통(왼쪽)',
      TORSO_ROTATION_RIGHT: '회전된 몸통(오른쪽)',
      SWAY_BACK: '스웨이백',
      PELVIS_ASYMMETRY: '골반 비대칭',
      PELVIS_ROTATION_LEFT: '골반 왼쪽 회전',
      PELVIS_ROTATION_RIGHT: '골반 오른쪽 회전',
      PELVIS_MOVE_RIGHT: '오른쪽으로 이동된 골반',
      PELVIS_MOVE_LEFT: '왼쪽으로 이동된 골반',
      LEGS_TURNED_OUTWARD: '넙다리 가쪽돌림',
      LEGS_TURNED_INWARD: '넙다리 안쪽돌림',
      BOW_LEGS: '오다리',
      KNOCK_LEGS: '엑스다리',
      BACK_KNEES: '과하게 펴진 무릎',
      BENT_KNEES: '굽혀진 무릎',
      FLAT_FEET: '평발',
      ARCHED_FEET: '오목발',
      ANKLE_MOVE_OUTWARD: '발목 가쪽번짐',
      ANKLE_MOVE_INWARD: '발목 안쪽번짐',
    };

    const cards = rankBodyDiseases(diseases)
      .slice(0, 5)
      .map((d, index: number) => {
        const borderStyles = ['pink', 'orange', 'blue', 'green', 'purple'];
        const defaultIconByDiseaseKey: Record<string, number> = {
          NECK_TILT: 1,
          NECK_ROTATION: 3,
          TURTLE_NECK: 5,
          STRAIGHT_NECK: 7,
          RAISED_NECK: 6,
          SHOULDER_HEIGHT_ASYMMETRY: 8,
          RAISED_SHOULDER: 10,
          DROPPED_SHOULDER: 12,
          ROUNDED_SHOULDER: 14,
          STRAIGHT_SHOULDER: 15,
          ARMS_TURNED_IN: 16,
          ARMS_TURNED_OUT: 18,
          BENT_ELBOW: 20,
          EXTENDED_ELBOW: 22,
          HUNCHED_BACK: 24,
          FLAT_BACK: 25,
          PELVIS_TILTS_FORWARD: 26,
          PELVIS_TILTS_BACKWARD: 27,
          TORSO_TILTED_RIGHT: 28,
          TORSO_TILTED_LEFT: 29,
          TORSO_ROTATION_RIGHT: 30,
          TORSO_ROTATION_LEFT: 31,
          SWAY_BACK: 32,
          PELVIS_ASYMMETRY: 33,
          PELVIS_ROTATION_RIGHT: 35,
          PELVIS_ROTATION_LEFT: 36,
          PELVIS_MOVE_RIGHT: 37,
          PELVIS_MOVE_LEFT: 38,
          LEGS_TURNED_OUTWARD: 39,
          LEGS_TURNED_INWARD: 41,
          BOW_LEGS: 43,
          KNOCK_LEGS: 47,
          BACK_KNEES: 49,
          BENT_KNEES: 50,
          FLAT_FEET: 51,
          ARCHED_FEET: 53,
        };

        // 이미지 키 생성 (영문 키 + 방향)
        let imageKey = MeasurementReportService.getPostureImageKey(d, diseases);

        // imageKey 방향 보정: imageKey에 방향 없지만 scoreDetail에서 방향 추론된 경우 보정
        const baseKey = String(d?.key || '');
        const imageKeyHasDir = imageKey
          ? imageKey.includes('_RIGHT') || imageKey.includes('_LEFT')
          : false;
        if (!imageKeyHasDir) {
          const resolvedDir = resolveDirection(d, imageKey);
          // '양쪽' 케이스는 POSTURE_IMAGE_NUMBER_MAP에 BOTH 아이콘이 없으므로 보정 건너뜀
          if (resolvedDir && resolvedDir !== '양쪽') {
            const dirSuffix = resolvedDir === '오른쪽' ? '_RIGHT' : '_LEFT';
            const candidate = `${baseKey}${dirSuffix}`;
            if (POSTURE_IMAGE_NUMBER_MAP[candidate] != null) {
              imageKey = candidate;
            } else if (baseKey === 'SHOULDER_HEIGHT_ASYMMETRY') {
              imageKey = resolvedDir === '오른쪽' ? 'SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP' : 'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP';
            } else if (baseKey === 'PELVIS_ASYMMETRY') {
              imageKey = resolvedDir === '오른쪽' ? 'PELVIS_ASYMMETRY_RIGHT_UP' : 'PELVIS_ASYMMETRY_LEFT_UP';
            }
          }
        }

        let imageNumber = imageKey ? POSTURE_IMAGE_NUMBER_MAP[imageKey] : null;
        if (imageNumber == null && imageKey?.endsWith('_BOTH')) {
          imageNumber = POSTURE_IMAGE_NUMBER_MAP[imageKey.replace('_BOTH', '_RIGHT')]
            ?? POSTURE_IMAGE_NUMBER_MAP[imageKey.replace('_BOTH', '_LEFT')]
            ?? null;
        }
        if (imageNumber == null && d.key) {
          imageNumber = defaultIconByDiseaseKey[d.key] ?? null;
        }
        const assetKey = imageNumber ? `POSTURE_ICON_${imageNumber}` : `POSTURE_ICON_${d.key}`;

        return {
          label: buildCardLabel(d, diseaseKeyToLabel[d.key] ?? d.key, imageKey),
          assetKey,
          url: imageNumber ? this.resolveBodyPostureIconUrl(imageNumber) : null,
          borderStyle: borderStyles[index % borderStyles.length],
        };
      });

    return {
      title: '회원님의 주요 체형',
      cards,
      note: cards.length > 0 ? '' : '',
    };
  }

  private buildPhotoAnalysis(analysisData: any, files: any[]) {
    const scoreDetail = analysisData?.scoreDetail || {};
    const metrics = resolveBodyDisplayMetrics(analysisData?.landmarks, scoreDetail);

    const getStatusColor = (score: number): string => {
      if (score >= 81) return 'green';
      if (score >= 71) return 'blue';
      if (score >= 61) return 'yellow';
      if (score >= 51) return 'orange';
      if (score >= 31) return 'pink';
      return 'red';
    };

    const scoreOrDefault = (...values: any[]): number => {
      for (const v of values) {
        const n = Number(v);
        if (!Number.isNaN(n) && Number.isFinite(n) && n > 0) return n;
      }
      return 100;
    };

    return buildPhotoAnalysisContent(
      metrics,
      scoreDetail,
      files,
      analysisData?.landmarks,
      getStatusColor,
      scoreOrDefault,
    );
  }

  private buildPostureDetails(analysisData: any) {
    const diseases = analysisData.disease || [];
    const scoreDetail = analysisData?.scoreDetail || {};
    const details: any[] = [];

    // 주요 체형과 동일 정렬(rankBodyDiseases 기준 상위 3개)
    const selectedDiseases = rankBodyDiseases(diseases).slice(0, 3);

    // scoreDetail에서 방향 또는 양쪽 여부 추론 ('오른쪽'|'왼쪽'|'양쪽'|null)
    const inferSideFromScoreDetail = (diseaseKey: string): string | null => {
      if (diseaseKey === 'NECK_TILT') {
        const txt = String(scoreDetail.neck?.neckTilt?.result || '');
        if (txt.includes('오른') || txt.toLowerCase().includes('right')) return '오른쪽';
        if (txt.includes('왼') || txt.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      if (diseaseKey === 'NECK_ROTATION') {
        const txt = String(scoreDetail.neck?.neckRotation?.result || '');
        if (txt.includes('오른') || txt.toLowerCase().includes('right')) return '오른쪽';
        if (txt.includes('왼') || txt.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      if (diseaseKey === 'SHOULDER_HEIGHT_ASYMMETRY') {
        const raw = String(scoreDetail.shoulder?.shoulderHeightAsymmetry?.result || '');
        if (raw.includes('오른') || raw.toLowerCase().includes('right')) return '오른쪽';
        if (raw.includes('왼') || raw.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      if (diseaseKey === 'PELVIS_ASYMMETRY') {
        const raw = String(scoreDetail.pelvis?.pelvisAsymmetry?.result || '');
        if (raw.includes('오른') || raw.toLowerCase().includes('right')) return '오른쪽';
        if (raw.includes('왼') || raw.toLowerCase().includes('left')) return '왼쪽';
        return null;
      }
      // 넙다리 가쪽돌림 / 안쪽돌림 — "leftDir:rightDir" format
      if (diseaseKey === 'LEGS_TURNED_OUTWARD') {
        const parts = String(scoreDetail.hipJoint?.legsTurnedOutwardOrInward?.result || '').split(':');
        const leftOut = parts[0] === '바깥', rightOut = parts[1] === '바깥';
        if (leftOut && rightOut) return '양쪽';
        if (leftOut) return '왼쪽';
        if (rightOut) return '오른쪽';
        return null;
      }
      if (diseaseKey === 'LEGS_TURNED_INWARD') {
        const parts = String(scoreDetail.hipJoint?.legsTurnedOutwardOrInward?.result || '').split(':');
        const leftIn = parts[0] === '안쪽', rightIn = parts[1] === '안쪽';
        if (leftIn && rightIn) return '양쪽';
        if (leftIn) return '왼쪽';
        if (rightIn) return '오른쪽';
        return null;
      }
      // 엑스다리 — JSON { left: { status }, right: { status } }
      if (diseaseKey === 'KNOCK_LEGS') {
        try {
          const p = JSON.parse(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.result || '{}');
          const lk = p.left?.status === '엑스다리', rk = p.right?.status === '엑스다리';
          if (lk && rk) return '양쪽';
          if (lk) return '왼쪽';
          if (rk) return '오른쪽';
        } catch {}
        return null;
      }
      // 오다리 — JSON { left: { status }, right: { status } }
      if (diseaseKey === 'BOW_LEGS') {
        try {
          const p = JSON.parse(scoreDetail.lowerLimbAlignment?.legsBowOrKnock?.result || '{}');
          const lb = p.left?.status === '오다리', rb = p.right?.status === '오다리';
          if (lb && rb) return '양쪽';
          if (lb) return '왼쪽';
          if (rb) return '오른쪽';
        } catch {}
        return null;
      }
      // 올라간 / 처진 어깨 — "leftStatus:rightStatus"
      if (diseaseKey === 'RAISED_SHOULDER') {
        const parts = String(scoreDetail.shoulder?.raisedOrDroppedShoulder?.result || '').split(':');
        const lr = parts[0] === '올라간', rr = parts[1] === '올라간';
        if (lr && rr) return '양쪽';
        if (lr) return '왼쪽';
        if (rr) return '오른쪽';
        return null;
      }
      if (diseaseKey === 'DROPPED_SHOULDER') {
        const parts = String(scoreDetail.shoulder?.raisedOrDroppedShoulder?.result || '').split(':');
        const ld = parts[0] === '처진', rd = parts[1] === '처진';
        if (ld && rd) return '양쪽';
        if (ld) return '왼쪽';
        if (rd) return '오른쪽';
        return null;
      }
      // 평발 / 오목발 — "왼쪽:X, 오른쪽:Y" (numeric angle, FLAT < 90, ARCHED >= 91)
      if (diseaseKey === 'FLAT_FEET') {
        const raw = String(scoreDetail.ankle?.feetFlatOrArched?.result || '');
        const lm = raw.match(/왼쪽:([\d.]+)/), rm = raw.match(/오른쪽:([\d.]+)/);
        if (lm && rm) {
          const lf = parseFloat(lm[1]) < 90, rf = parseFloat(rm[1]) < 90;
          if (lf && rf) return '양쪽';
          if (lf) return '왼쪽';
          if (rf) return '오른쪽';
        }
        return null;
      }
      if (diseaseKey === 'ARCHED_FEET') {
        const raw = String(scoreDetail.ankle?.feetFlatOrArched?.result || '');
        const lm = raw.match(/왼쪽:([\d.]+)/), rm = raw.match(/오른쪽:([\d.]+)/);
        if (lm && rm) {
          const la = parseFloat(lm[1]) >= 91, ra = parseFloat(rm[1]) >= 91;
          if (la && ra) return '양쪽';
          if (la) return '왼쪽';
          if (ra) return '오른쪽';
        }
        return null;
      }
      return null;
    };

    const resolveBestMapKey = (d: any): string | null => {
      const baseKey = String(d?.key || '');
      if (!baseKey) return null;

      const primary = MeasurementReportService.getPostureImageKey(d, diseases);
      const side = MeasurementReportService.extractDirectionFromDisease(d) || inferSideFromScoreDetail(baseKey);

      const candidates: string[] = [];
      if (primary) candidates.push(primary);

      if (baseKey === 'SHOULDER_HEIGHT_ASYMMETRY') {
        if (side === '오른쪽') candidates.push('SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP');
        if (side === '왼쪽') candidates.push('SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP');
        candidates.push('SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP', 'SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP');
      } else if (baseKey === 'PELVIS_ASYMMETRY') {
        if (side === '오른쪽') candidates.push('PELVIS_ASYMMETRY_RIGHT_UP');
        if (side === '왼쪽') candidates.push('PELVIS_ASYMMETRY_LEFT_UP');
        candidates.push('PELVIS_ASYMMETRY_RIGHT_UP', 'PELVIS_ASYMMETRY_LEFT_UP');
      } else if (baseKey === 'BOW_LEGS') {
        // BOW_LEGS has EXTERNAL/INTERNAL subtypes determined by hip-joint rotation
        const hipParts = String(scoreDetail.hipJoint?.legsTurnedOutwardOrInward?.result || '').split(':');
        const leftExt = hipParts[0] === '바깥', rightExt = hipParts[1] === '바깥';
        const leftInt = hipParts[0] === '안쪽', rightInt = hipParts[1] === '안쪽';
        if (side === '양쪽') {
          if (leftExt && rightExt) candidates.push('BOW_LEGS_EXTERNAL_BOTH');
          else if (leftInt && rightInt) candidates.push('BOW_LEGS_INTERNAL_BOTH');
          else candidates.push('BOW_LEGS_EXTERNAL_BOTH', 'BOW_LEGS_INTERNAL_BOTH');
        } else if (side === '오른쪽') {
          if (rightExt) candidates.push('BOW_LEGS_EXTERNAL_RIGHT');
          else if (rightInt) candidates.push('BOW_LEGS_INTERNAL_RIGHT');
          candidates.push('BOW_LEGS_EXTERNAL_RIGHT', 'BOW_LEGS_INTERNAL_RIGHT');
        } else if (side === '왼쪽') {
          if (leftExt) candidates.push('BOW_LEGS_EXTERNAL_LEFT');
          else if (leftInt) candidates.push('BOW_LEGS_INTERNAL_LEFT');
          candidates.push('BOW_LEGS_EXTERNAL_LEFT', 'BOW_LEGS_INTERNAL_LEFT');
        } else {
          candidates.push('BOW_LEGS_EXTERNAL_RIGHT', 'BOW_LEGS_INTERNAL_RIGHT', 'BOW_LEGS_EXTERNAL_LEFT', 'BOW_LEGS_INTERNAL_LEFT', 'BOW_LEGS_EXTERNAL_BOTH', 'BOW_LEGS_INTERNAL_BOTH');
        }
      } else if (baseKey === 'NECK_TILT' || baseKey === 'NECK_ROTATION' || baseKey === 'RAISED_SHOULDER' || baseKey === 'DROPPED_SHOULDER'
        || baseKey === 'ARMS_TURNED_IN' || baseKey === 'ARMS_TURNED_OUT' || baseKey === 'BENT_ELBOW' || baseKey === 'EXTENDED_ELBOW'
        || baseKey === 'LEGS_TURNED_OUTWARD' || baseKey === 'LEGS_TURNED_INWARD'
        || baseKey === 'KNOCK_LEGS' || baseKey === 'FLAT_FEET' || baseKey === 'ARCHED_FEET') {
        if (side === '양쪽') {
          candidates.push(`${baseKey}_BOTH`);
          candidates.push(`${baseKey}_RIGHT`, `${baseKey}_LEFT`);
        } else {
          if (side === '오른쪽') candidates.push(`${baseKey}_RIGHT`);
          if (side === '왼쪽') candidates.push(`${baseKey}_LEFT`);
          candidates.push(`${baseKey}_RIGHT`, `${baseKey}_LEFT`, `${baseKey}_BOTH`);
        }
      }

      candidates.push(baseKey);

      for (const c of candidates) {
        if (MUSCLE_IMBALANCE_MAP[c] || POSTURE_IMPRESSION_MAP[c] || POSTURE_DISCOMFORT_MAP[c]) {
          return c;
        }
      }

      return primary || baseKey;
    };

    const normalizeDiseaseKey = (rawKey: string): string => {
      const key = String(rawKey || '');
      if (key.startsWith('SHOULDER_HEIGHT_ASYMMETRY')) return 'SHOULDER_HEIGHT_ASYMMETRY';
      if (key.startsWith('PELVIS_ASYMMETRY')) return 'PELVIS_ASYMMETRY';
      if (key.startsWith('LEGS_TURNED_OUTWARD')) return 'LEGS_TURNED_OUTWARD';
      if (key.startsWith('LEGS_TURNED_INWARD')) return 'LEGS_TURNED_INWARD';
      if (key.startsWith('BOW_LEGS')) return 'BOW_LEGS';
      if (key.startsWith('KNOCK_LEGS')) return 'KNOCK_LEGS';
      if (key.startsWith('FLAT_FEET')) return 'FLAT_FEET';
      if (key.startsWith('ARCHED_FEET')) return 'ARCHED_FEET';
      return key;
    };

    const resolveDirection = (d: any, normalizedKey: string): string | null => {
      const byField = MeasurementReportService.extractDirectionFromDisease(d);
      if (byField) return byField;

      const k = String(d?.key || '');
      if (k.includes('RIGHT')) return '오른쪽';
      if (k.includes('LEFT')) return '왼쪽';

      return inferSideFromScoreDetail(normalizedKey);
    };

    const resolveCautionHabitList = (d: any): Array<{ label: string; imageNumber: number }> => {
      const normalizedKey = normalizeDiseaseKey(String(d?.key || ''));
      const direction = resolveDirection(d, normalizedKey);
      const baseKo = MeasurementReportService.getPostureKoFromDiseaseKey(normalizedKey);
      const keys: string[] = [];

      const primaryKo = MeasurementReportService.getPostureKoWithDirection(d, diseases);
      if (primaryKo) keys.push(primaryKo);

      if (normalizedKey === 'PELVIS_ASYMMETRY') {
        if (direction === '오른쪽') keys.push('골반 비대칭(오른쪽↑, 왼쪽↓)', '골반 비대칭(오른쪽 ↑)');
        if (direction === '왼쪽') keys.push('골반 비대칭(왼쪽↑, 오른쪽↓)', '골반 비대칭(왼쪽 ↑)');
        if (!direction || direction === '양쪽') keys.push('골반 비대칭(오른쪽↑, 왼쪽↓)', '골반 비대칭(왼쪽↑, 오른쪽↓)');
      }

      if (normalizedKey === 'SHOULDER_HEIGHT_ASYMMETRY') {
        if (direction === '오른쪽') keys.push('어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)');
        if (direction === '왼쪽') keys.push('어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)');
        if (!direction || direction === '양쪽') keys.push('어깨높이 비대칭 (오른쪽 ↑, 왼쪽 ↓)', '어깨높이 비대칭 (왼쪽 ↑, 오른쪽 ↓)');
      }

      if (baseKo && direction && direction !== '양쪽') {
        keys.push(`${baseKo}(${direction})`);
      }
      // 양쪽인 경우 양방향 키를 모두 시도한 뒤 기본 키로 fallback
      if (baseKo && direction === '양쪽') {
        keys.push(`${baseKo}(오른쪽)`, `${baseKo}(왼쪽)`);
      }
      if (baseKo) {
        keys.push(baseKo);
      }

      for (const key of keys) {
        const habits = CAUTION_HABITS_BY_POSTURE_KO[key];
        if (habits && habits.length > 0) return habits;
      }

      return [];
    };

    selectedDiseases.forEach((d: any) => {
      if (d.key && d.key !== 'NORMAL') {
        // 방향 정보를 포함한 체형명 (한글 - 표시용)
        const koWithDirection = MeasurementReportService.getPostureKoWithDirection(d, diseases);
        const postureKo = koWithDirection || MeasurementReportService.getPostureKoFromDiseaseKey(d.key);

        // 영문 이미지 키 생성 (근육/외형/불편감 공통 매핑용)
        const mapKey = resolveBestMapKey(d);

        // 근육 데이터 조회 (영문 키 사용)
        let muscleData = mapKey ? MUSCLE_IMBALANCE_MAP[mapKey] : null;

        // fallback: disease.key로 직접 조회
        if (!muscleData) {
          muscleData = MUSCLE_IMBALANCE_MAP[d.key];
        }

        // 이미지 번호 (근육 매핑 이미지)
        const imageNumber = muscleData?.imageNumber;
        const assetKey = imageNumber ? `MUSCLE_MAP_${imageNumber}` : `FIGURE_${d.key}_MUSCLE_MAP`;

        // 외형 인상 데이터 조회 (영문 키 사용)
        let impressionData = mapKey ? POSTURE_IMPRESSION_MAP[mapKey] : null;
        if (!impressionData) {
          impressionData = POSTURE_IMPRESSION_MAP[d.key];
        }

        // 신체적 불편감 데이터 조회 (BODY_TYPE_DISCOMFORT_LIST 직접 사용)
        const baseKey = DISEASE_KEY_NORMALIZATION[mapKey ?? ''] ?? DISEASE_KEY_NORMALIZATION[d.key] ?? d.key;
        const discomfortData = pickRandom(BODY_TYPE_DISCOMFORT_LIST[baseKey] ?? [], 3);

        // 근사용 불균형 분석
        details.push({
          title: `${postureKo || d.key} 근사용 불균형 분석`,
          postureKey: d.key,
          figure: { assetKey, url: this.resolveMuscleMapUrl(assetKey) },
          muscleImbalance: {
            tight: muscleData?.tight || [],
            weak: muscleData?.weak || [],
          },
          discomfort: discomfortData || [],
          impression: impressionData || [],
        });

        // 주의 습관 - 방향 정보 고려
        details.push({
          title: `${postureKo || d.key} 방지를 위한 주의 생활 환경과 자세 습관`,
          postureKey: d.key,
          cautionHabits: (() => {
            const habits = resolveCautionHabitList(d);
            return habits.map((habit) => ({
              label: habit.label,
              assetKey: `HABIT_CAUTION_${habit.imageNumber}`,
              url: this.resolveHabitCautionUrl(`HABIT_CAUTION_${habit.imageNumber}`),
            }));
          })(),
        });
      }
    });

    return details;
  }

  private buildRecommendedHabits() {
    const rec = (n: number) => ({ assetKey: `HABIT_REC_${n}`, url: this.resolveHabitRecUrl(`HABIT_REC_${n}`) });
    return {
      title: '권장 생활 환경과 자세 습관',
      sections: [
        {
          title: '앉아있을 때',
          assets: [rec(68), rec(69)],
          bullets: [
            '귀–어깨–골반이 수직선상에 위치하도록 합니다.',
            '목은 과도하게 앞으로 나오거나 뒤로 젖혀지지 않도록 중립을 유지합니다.',
            '의자 깊숙이 앉고, 정수리를 하늘 방향으로 세워줍니다.',
            '발바닥은 바닥에 전체가 닿고, 허벅지 라인이 바닥과 수평해야 합니다.',
            '무릎은 골반 너비 정도로 자연스럽게 둡니다.',
            '의자에 깊게 앉아 엉덩이로 좌우 골반에 체중을 균등하게 분산합니다.',
          ],
        },
        {
          title: '업무 자세 및 환경 세팅',
          assets: [rec(70), rec(71), rec(72), rec(73)],
          bullets: [
            '책상높이는 위팔을 몸통에 붙이고 팔꿈치를 약 90°로 굽혔을 때 손목 높이에 위치합니다.(책상 세팅)',
            '키보드는 팔꿈치보다 약간 낮은 높이가 적절합니다 (키보드 세팅)',
            '마우스는 어깨가 들리지 않는 범위 내에서 가까이 둡니다.(마우스 세팅)',
            '의자 높이는 허벅지가 바닥과 수평을 이루고 발바닥 전체가 바닥에 닿도록 조절합니다.(의자 세팅)',
            '모니터 상단은 눈높이와 같거나 약 2~5cm 낮게 설정합니다. (모니터 세팅)',
            '모니터와 눈의 거리는 약 50~70cm를 유지하고, 화면은 위쪽이 약간 뒤로 기울어지도록 조정합니다.(모니터 세팅)',
            '모니터 중앙은 몸의 정중앙과 일치하도록 배치합니다.(모니터 세팅)',
          ],
        },
        {
          title: '서 있을 때',
          assets: [rec(74), rec(75)],
          bullets: [
            '엄지발가락, 새끼발가락, 발뒤꿈치가 골고루 바닥에 닿게 합니다.',
            '양 발에 체중이 똑같이 실리도록 합니다.',
            '배에 살짝 힘을 주고, 정수리를 하늘방향으로 밀어줍니다.',
            '턱을 몸쪽으로 살짝 당깁니다.',
          ],
        },
        {
          title: '서 있을 때 발바닥을 바르게 디디는 방법',
          assets: [rec(76), rec(77), rec(78)],
          bullets: [
            '체중은 좌우 발에 1:1로 동일하게 분산되도록 합니다.',
            '발끝은 정면을 향하도록 정렬합니다.',
            '발목은 안쪽이나 바깥쪽으로 꺾이지 않도록 합니다.',
            '발바닥 전체가 바닥에 편안하게 닿아 체중이 고르게 실리도록 합니다.',
          ],
        },
        {
          title: '걸을 때',
          assets: [rec(79), rec(80)],
          bullets: [
            '복부에 가볍게 힘을 주고 정수리를 위로 길게 하여 자연스럽게 걷습니다.',
            '시선은 정면을 향하고, 고개는 숙이거나 젖히지 않습니다.',
            '팔은 몸 옆에서 자연스럽게 앞뒤로 흔듭니다.',
            '발은 뒤꿈치 → 발바닥 중앙 → 발가락 순서로 착지합니다.',
            '보폭은 과하지 않게 하고 발끝은 진행 방향을 향하도록 합니다.',
            '골반은 좌우로 과도하게 흔들리지 않도록 합니다.',
          ],
        },
        {
          title: '위를 보고 누울 때',
          assets: [rec(81)],
          bullets: [
            '얼굴면이 천장과 수평을 이루도록 머리와 목을 자연스럽게 지지하는 높이의 베개를 사용합니다.',
            '몸의 긴장을 풀고, 등이 바닥 전체에 고르게 닿도록 합니다.',
            '무릎 아래에 베개를 놓아 무릎이 살짝 굽혀지도록 합니다.',
            '팔은 몸통 옆에 가지런히 놓습니다.',
          ],
        },
        {
          title: '옆으로 누울 때',
          assets: [rec(82)],
          bullets: [
            '베개 높이는 바로 누울 때보다 조금 더 높게 설정해 어깨 폭을 채우고, 고개가 한쪽으로 기울지 않도록 합니다.',
            '무릎 사이에 쿠션을 끼워 골반 정렬을 유지합니다.',
            '몸이 과도하게 웅크러지지 않도록 합니다.',
            '고개가 천장이나 바닥 쪽으로 돌아가지 않도록 합니다.',
          ],
        },
      ],
    };
  }

  private buildSummary(
    analysisData: any,
    report: BodyReportEntity,
    options?: { includeTrainerComment?: boolean },
  ) {
    const neckLoadValue = MeasurementReportService.calculateNeckLoad(analysisData);
    const bodyPartScores = MeasurementReportService.calculateBodyPartScores(analysisData);
    const balanceStage = MeasurementReportService.getBalanceStateStage(bodyPartScores.average);

    const diseases = analysisData.disease || [];
    const memberName = report.user?.name || '회원';
    const userHeight = report.user?.height || 170; // 사용자 키
    const heightLossValue = MeasurementReportService.calculateHeightLoss(analysisData, userHeight);
    const includeTrainerComment = options?.includeTrainerComment ?? true;
    const trainerComment = includeTrainerComment ? report.comment || '' : '';

    // ✅ 뼈대 이미지 동적 선택
    const skeletonImages = MeasurementReportService.getSkeletonImages(analysisData);

    // ✅ 종합 조언 동적 생성
    const overallAdvice = MeasurementReportService.buildOverallAdvice(
      memberName,
      diseases,
      report.totalScore || 0,
      trainerComment,
      analysisData.scoreDetail || {},
    );

    // 점수별 색상 매핑 (단계에 따라)
    const getStatusColor = (score: number): string => {
      if (score >= 81) return 'green';
      if (score >= 71) return 'blue';
      if (score >= 61) return 'yellow';
      if (score >= 51) return 'orange';
      if (score >= 31) return 'pink';
      return 'red';
    };

    return {
      title: '종합 요약',
      skeleton: {
        rows: [
          {
            view: 'back',
            current: skeletonImages.back.current != null ? { assetKey: `SKELETON_BACK_CURRENT_${skeletonImages.back.current}`, url: this.resolveSkeletonUrl(`SKELETON_BACK_CURRENT_${skeletonImages.back.current}`) } : null,
            future: skeletonImages.back.future != null ? { assetKey: `SKELETON_BACK_FUTURE_${skeletonImages.back.future}`, url: this.resolveSkeletonUrl(`SKELETON_BACK_FUTURE_${skeletonImages.back.future}`) } : null,
            normal: { assetKey: `SKELETON_BACK_NORMAL_${skeletonImages.back.normal}`, url: this.resolveSkeletonUrl(`SKELETON_BACK_NORMAL_${skeletonImages.back.normal}`) },
          },
          {
            view: 'front',
            current: skeletonImages.front.current != null ? { assetKey: `SKELETON_FRONT_CURRENT_${skeletonImages.front.current}`, url: this.resolveSkeletonUrl(`SKELETON_FRONT_CURRENT_${skeletonImages.front.current}`) } : null,
            future: skeletonImages.front.future != null ? { assetKey: `SKELETON_FRONT_FUTURE_${skeletonImages.front.future}`, url: this.resolveSkeletonUrl(`SKELETON_FRONT_FUTURE_${skeletonImages.front.future}`) } : null,
            normal: { assetKey: `SKELETON_FRONT_NORMAL_${skeletonImages.front.normal}`, url: this.resolveSkeletonUrl(`SKELETON_FRONT_NORMAL_${skeletonImages.front.normal}`) },
          },
          {
            view: 'side',
            current: skeletonImages.side.current != null ? { assetKey: `SKELETON_SIDE_CURRENT_${skeletonImages.side.current}`, url: this.resolveSkeletonUrl(`SKELETON_SIDE_CURRENT_${skeletonImages.side.current}`) } : null,
            future: skeletonImages.side.future != null ? { assetKey: `SKELETON_SIDE_FUTURE_${skeletonImages.side.future}`, url: this.resolveSkeletonUrl(`SKELETON_SIDE_FUTURE_${skeletonImages.side.future}`) } : null,
            normal: { assetKey: `SKELETON_SIDE_NORMAL_${skeletonImages.side.normal}`, url: this.resolveSkeletonUrl(`SKELETON_SIDE_NORMAL_${skeletonImages.side.normal}`) },
          },
        ],
      },
      heightLoss: {
        label: '키손실',
        value: heightLossValue,
        unit: 'cm',
        stage: MeasurementReportService.getHeightLossStage(heightLossValue).stage,
        stageLabel: MeasurementReportService.getHeightLossStage(heightLossValue).label,
        imageUrl: this.resolveHeightLossImageUrl(MeasurementReportService.getHeightLossStage(heightLossValue).stage),
      },
      neckLoad: {
        label: '목에 가해지는 부담',
        value: neckLoadValue, // ✅ 실제 계산값 사용
        unit: 'kg',
        description: `현재와 같은 체형 정렬에서는, 각도에 따라 목에 가해지는 머리 하중이 약 ${neckLoadValue}kg까지 증가할 수 있습니다.`,
      },
      balanceState: {
        title: '신체 균형 상태',
        stage: balanceStage.stage,
        label: balanceStage.label,
        score: bodyPartScores.average,
        description: balanceStage.description,
        weightCenterImage: {
          url: this.resolveBodyBalanceImageUrl(
            analysisData?.scoreDetail?.balanceIndex?.leftRightBalanceIndex?.balance ?? 'normal',
            analysisData?.scoreDetail?.balanceIndex?.frontBackBalanceIndex?.balance ?? 'normal',
          ),
          leftRight: analysisData?.scoreDetail?.balanceIndex?.leftRightBalanceIndex?.balance ?? 'normal',
          frontBack: analysisData?.scoreDetail?.balanceIndex?.frontBackBalanceIndex?.balance ?? 'normal',
        },
      },
      bodyFunctionScores: {
        title: '신체 부위별 기능 점수',
        average: {
          score: bodyPartScores.average,
          stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.average).stage,
          stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.average).label,
        },
        items: [
          { key: 'NECK',         label: '목',       score: bodyPartScores.neck,         statusColor: getStatusColor(bodyPartScores.neck),         stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.neck).stage,         stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.neck).label },
          { key: 'SHOULDER',     label: '어깨',     score: bodyPartScores.shoulder,     statusColor: getStatusColor(bodyPartScores.shoulder),     stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.shoulder).stage,     stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.shoulder).label },
          { key: 'PELVIS_WAIST', label: '골반/허리', score: bodyPartScores.pelvisWaist,  statusColor: getStatusColor(bodyPartScores.pelvisWaist),  stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.pelvisWaist).stage,  stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.pelvisWaist).label },
          { key: 'LEG_ALIGNMENT',label: '하지정렬',  score: bodyPartScores.legAlignment, statusColor: getStatusColor(bodyPartScores.legAlignment), stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.legAlignment).stage, stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.legAlignment).label },
          { key: 'KNEE',         label: '무릎',     score: bodyPartScores.knee,         statusColor: getStatusColor(bodyPartScores.knee),         stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.knee).stage,         stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.knee).label },
          { key: 'ANKLE',        label: '발목',     score: bodyPartScores.ankle,        statusColor: getStatusColor(bodyPartScores.ankle),        stage: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.ankle).stage,        stageLabel: MeasurementReportService.getBodyPartScoreStage(bodyPartScores.ankle).label },
        ],
        stageGuide: BODY_PART_SCORE_STAGE_RULES.map((r) => ({
          stage: r.stage, label: r.label, min: r.min, max: r.max, referenceScore: r.referenceScore,
        })),
        legend: ['위험', '심각', '경계', '주의', '양호', '정상'],
      },
      overallStage: { label: balanceStage.label, score: bodyPartScores.average }, // ✅ 균형 상태 단계 사용
      overallAdvice, // ✅ 동적 생성된 종합 조언
      ...(trainerComment ? {
        combinedContent: {
          title: '종합 코멘트',
          placeholder: trainerComment,
        },
      } : {}),
      disclaimer: [
        '본 리포트는 체형 측정 데이터를 바탕으로 한 추정 정보로서, 운동 및 생활 관리 시 참고용으로 제공되며 의료적 진단, 판단 또는 치료를 대체하지 않습니다.',
      ],
    };
  }

  /**
   * 척추정렬검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   * 측정 데이터는 추후 엑셀 기반으로 대체 예정이며, 현재는 하드코딩 템플릿 사용
   */
  async getSpineAlignmentReport(
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<SpineAlignmentReportResponseDto> {
    const resolvedMemberId = await this.resolveSharablePrecisionReportMemberId(memberId, id);
    const payload = lang === 'en'
      ? await this.ensurePrecisionReportEnglishPayload(
        resolvedMemberId,
        id,
        () => this.buildSpineAlignmentEnglishPayload(resolvedMemberId, id),
        () => this.buildSpineAlignmentReportPayload(resolvedMemberId, id),
      )
      : await this.buildSpineAlignmentReportPayload(resolvedMemberId, id);

    return this.withCenterLogoForPrecisionReport(resolvedMemberId, id, payload);
  }

  async buildSpineAlignmentReportPayload(
    memberId: string,
    id: string,
  ): Promise<SpineAlignmentReportResponseDto> {
    const report = await this.precisionReportRepo.findOne({
      where: { id, userId: memberId, type: MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST },
      relations: ['user'],
    });
    if (!report) {
      throw new NotFoundException('척추정렬검사 리포트를 찾을 수 없습니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedId: id } });
    const filesByDiv = Object.fromEntries(files.map((f) => [f.division, f.fileUrl]));

    const user = report.user;
    const genderLabel = user.gender === Gender.MALE ? '남성' : user.gender === Gender.FEMALE ? '여성' : '기타';
    const measurementDate = report.createdAt.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    // 실제 분석 데이터 추출
    const scoreDetail = report.analysisData?.scoreDetail || {};
    const spinalTilt = (() => {
      const raw = scoreDetail.centerShoulderHip;
      if (raw) {
        // 저장된 disease값 무시, result로 재계산
        const disease = Math.abs(raw.result) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX ? 'NORMAL'
          : raw.result > 0 ? 'SPINE_TILTED_RIGHT' : 'SPINE_TILTED_LEFT';
        return { ...raw, disease };
      }
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftShoulder || !back?.RightShoulder || !back?.LeftHip || !back?.RightHip) return undefined;
      const centerShoulderX = (back.LeftShoulder.x + back.RightShoulder.x) / 2;
      const centerHipX = (back.LeftHip.x + back.RightHip.x) / 2;
      const result = centerShoulderX - centerHipX;
      const disease = Math.abs(result) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX ? 'NORMAL'
        : result > 0 ? 'SPINE_TILTED_RIGHT' : 'SPINE_TILTED_LEFT';
      return { result, score: 0, disease };
    })();
    const shoulderAlignment = (() => {
      if (scoreDetail.higherShoulder) return scoreDetail.higherShoulder;
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftShoulder || !back?.RightShoulder) return undefined;
      const result = back.LeftShoulder.y - back.RightShoulder.y;
      const disease = Math.abs(result) <= SPINAL_ALIGNMENT.SHOULDER_HEIGHT_THRESHOLD_PX ? 'NORMAL'
        : back.RightShoulder.y < back.LeftShoulder.y ? 'SPINE_CURVED_RIGHT' : 'SPINE_CURVED_LEFT';
      return { result, score: 0, disease };
    })();
    const pelvicReaction = resolvePelvicReaction(
      scoreDetail.pelvicReaction,
      report.analysisData?.landmarks?.back,
    );
    const shoulderContour = (() => {
      if (scoreDetail.shoulderContour) {
        // diff 원시값으로 dominantSide 재계산
        // 후면 촬영: 인체 오른쪽 = 큰 X → diff > 0 = 오른쪽 윤곽 도드라짐
        const raw = scoreDetail.shoulderContour;
        const correctedDominant = raw.diff > 10 ? '오른쪽' : raw.diff < -10 ? '왼쪽' : '균형';
        return { ...raw, dominantSide: correctedDominant };
      }
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftShoulder || !back?.RightShoulder || !back?.LeftHip || !back?.RightHip) return null;
      const ls = back.LeftShoulder, rs = back.RightShoulder, lh = back.LeftHip, rh = back.RightHip;
      const hipMidX = (lh.x + rh.x) / 2;
      const rightOffset = rs.x - hipMidX;
      const leftOffset  = hipMidX - ls.x;
      const diff = rightOffset - leftOffset;
      const dominantSide = diff > SPINAL_ALIGNMENT.CONTOUR_THRESHOLD_PX ? '오른쪽' : diff < -SPINAL_ALIGNMENT.CONTOUR_THRESHOLD_PX ? '왼쪽' : '균형';
      return { rightOffset, leftOffset, diff, dominantSide, score: 0 };
    })();
    const legUsage = (() => {
      const calcDominant = (dx: number) =>
        Math.round(Math.abs(dx)) === 0 ? '균형' : dx > 0 ? '오른쪽' : '왼쪽';
      if (scoreDetail.legUsage) {
        const raw = scoreDetail.legUsage;
        // 저장된 dominantSide 무시, dx로 재계산 (구버전 임계값으로 잘못 저장됐을 수 있으므로)
        const dominantSide = raw.dx != null ? calcDominant(raw.dx) : (raw.dominantSide ?? '균형');
        return { ...raw, dominantSide };
      }
      const back = report.analysisData?.landmarks?.back;
      if (!back?.LeftAnkle || !back?.RightAnkle || !back?.LeftHip || !back?.RightHip) return null;
      const la = back.LeftAnkle, ra = back.RightAnkle, lh = back.LeftHip, rh = back.RightHip;
      // 문서 명세: X좌표 비교 방식. 후면 촬영 → 인체 오른쪽 = 큰 X
      const heelMidX = (la.x + ra.x) / 2;
      const hipMidX  = (lh.x + rh.x) / 2;
      const dx = hipMidX - heelMidX;
      return { heelMidX, hipMidX, dx, dominantSide: calcDominant(dx), score: 0 };
    })();
    const spineNormal = !spinalTilt || spinalTilt.disease === 'NORMAL';
    const shoulderNormal = !shoulderAlignment || shoulderAlignment.disease === 'NORMAL';

    const backLandmarks = report.analysisData?.landmarks?.back;
    const centerShiftPxPerCm = estimateHorizontalPxPerCm(backLandmarks, {
      heightCm: user.height != null ? Number(user.height) : undefined,
      previewHeight: report.analysisData?.previewHeight,
    });

    return {
      member: {
        name: user.name,
        gender: genderLabel,
        birthDate: user.birthDate || '',
        measurementDate,
      },
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : new Date(report.createdAt).toISOString(),
      notice:
        '본 분석은 의료 기관의 의학적 진단(X-ray 등)이 아닌 국제 표준 운동학적 지표와 근골격계 외형 데이터를 기반으로 한 전문가적 평가 결과이며,의학적 치료가 아닌 트레이닝을 통한 정렬 최적화 및 신체 기능 개선을 위한 핵심 참고 자료로 활용됨을 명시함',
      observationSummary: {
        images: {
          photo: { assetKey: 'SPINE_FRONT_PHOTO', url: filesByDiv['BACK'] ?? null },
          illustration: { assetKey: 'SPINE_FRONT_ILLUSTRATION', url: this.resolveSpineIllustrationUrl(spinalTilt, shoulderAlignment) },
        },
        metrics: [
          {
            label: '상체 중심 이동 경향',
            value: formatCenterShiftMetricLabel(spinalTilt, centerShiftPxPerCm),
          },
          {
            label: '숙일 때\n골반 반응 유형',
            value: !pelvicReaction ? '데이터 없음'
              : pelvicReaction.isNormal ? '좌우 평행'
              : pelvicReaction.higherSide === '왼쪽'
                ? `왼쪽 ${Math.round(Math.abs(pelvicReaction.result ?? 0))}° ↑ (오른쪽 대비)`
                : `오른쪽 ${Math.round(Math.abs(pelvicReaction.result ?? 0))}° ↑ (왼쪽 대비)`,
          },
          {
            label: '척추 라인방향',
            value: !shoulderAlignment ? '데이터 없음'
              : shoulderAlignment.disease === 'NORMAL' ? '중앙 정렬 유지'
              : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽 경향' : '왼쪽 경향',
          },
          {
            label: '숙일 때 등 높이 차이',
            value: !shoulderAlignment ? '데이터 없음'
              : shoulderAlignment.disease === 'NORMAL' ? '대칭 유지'
              : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT'
                ? `오른쪽 ↑ (왼쪽 대비)`
                : `왼쪽 ↑ (오른쪽 대비)`,
          },
        ],
        tooltips: {
          guide: '숙일 때 골반 반응 유형 (좌우 비교)',
          points: [
            {
              part: '엉덩이',
              left:  !pelvicReaction || pelvicReaction.isNormal ? 0
                : pelvicReaction.higherSide === '왼쪽'  ? +Math.round(Math.abs(pelvicReaction.result ?? 0))
                : -Math.round(Math.abs(pelvicReaction.result ?? 0)),
              right: !pelvicReaction || pelvicReaction.isNormal ? 0
                : pelvicReaction.higherSide === '오른쪽' ? +Math.round(Math.abs(pelvicReaction.result ?? 0))
                : -Math.round(Math.abs(pelvicReaction.result ?? 0)),
            },
          ],
        },
        analysis: this.buildSpinalAnalysisText(spinalTilt, shoulderAlignment, pelvicReaction, centerShiftPxPerCm),
        result: this.buildSpinalResultText(report.level || '', spinalTilt, shoulderAlignment, pelvicReaction),
      },
      ...this.buildAlignmentFlowAndTrainingGuides(
        pelvicReaction,
        legUsage,
        spinalTilt,
        shoulderAlignment,
      ),
      coreStructure: {
        description:
          '아래 이미지는 숙인 자세에서 관찰된 발 중심-골반 중심-어깨 중심의 위치 관계를 나타냅니다.\n\n신체의 중심은 아래에서 위로 쌓이듯 연결되며,\n이 중 어느 한 구간에서 위치 차이가 생기면 상체 전체의 정렬 흐름에도 영향을 줄 수 있습니다.\n\n굽힘 자세에서 양 발을 기준으로 한 골반 중심과,\n골반을 기준으로 한 상체 중심의 위치 관계는 전체 정렬 흐름을 이해하는 데 중요한 기준이 됩니다.\n측정 결과,',
        blocks: [
          {
            title: '',
            description: this.buildBodyCenterBlockDescription(spinalTilt),
            assetKey: (() => {
              if (!spinalTilt || spinalTilt.disease === 'NORMAL') return 'CENTER_CORE_STRUCTURE_6';
              return (spinalTilt.result ?? 0) > 0 ? 'CENTER_CORE_STRUCTURE_4' : 'CENTER_CORE_STRUCTURE_5';
            })(),
            url: this.resolveCoreStructureUrl((() => {
              if (!spinalTilt || spinalTilt.disease === 'NORMAL') return 'CENTER_CORE_STRUCTURE_6';
              return (spinalTilt.result ?? 0) > 0 ? 'CENTER_CORE_STRUCTURE_4' : 'CENTER_CORE_STRUCTURE_5';
            })()),
          },
          {
            title: '',
            description: this.buildLegUsageBlockDescription(legUsage),
            assetKey: (() => {
              if (!legUsage || legUsage.dominantSide === '균형') return 'CENTER_CORE_STRUCTURE_3';
              return legUsage.dominantSide === '오른쪽' ? 'CENTER_CORE_STRUCTURE_1' : 'CENTER_CORE_STRUCTURE_2';
            })(),
            url: this.resolveCoreStructureUrl((() => {
              if (!legUsage || legUsage.dominantSide === '균형') return 'CENTER_CORE_STRUCTURE_3';
              return legUsage.dominantSide === '오른쪽' ? 'CENTER_CORE_STRUCTURE_1' : 'CENTER_CORE_STRUCTURE_2';
            })()),
          },
        ],
        footer:
          '이러한 중심 배치는 중심 전달 과정에서의 사용 방향성을 파악하는 데 활용할 수 있습니다.\n\n위 중심 연결 구조를 기준으로\n일상적인 자세와 움직임 속에서 유사한 중심 흐름이 나타나는지 점검해보시기를 권장합니다.',
        comment: this.buildForwardBendComment(spinalTilt, shoulderAlignment, pelvicReaction, centerShiftPxPerCm),
        observationVariant: this.getForwardBendObservationVariant(spinalTilt, shoulderAlignment),
      },
      bodyChangeInsights: {
        intro:
          '본 파트는 정렬 특성에 따라 일상 움직임에서 다르게 나타날 수 있는 신체 반응과 인상을\n<b>개인 맞춤 트레이닝 방향 설정을 위한 참고 자료</b>로 정리한 내용입니다.',
        sections: [
          this.buildLowerBodySection(pelvicReaction, legUsage),
          this.buildUpperBodySection(spinalTilt, shoulderAlignment),
          this.buildShoulderSection(shoulderAlignment),
        ],
      },
      disclaimer: [
        '본 리포트는 체형 관찰 데이터를 기반으로 제공되는 참고 자료입니다.',
        '의학적 진단을 대신할 수 없으며 필요 시 전문 의료 상담을 권장합니다.',
      ],
      files: files.map((f) => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      landmarks: report.analysisData?.landmarks ?? null,
      previewWidth: report.analysisData?.previewWidth ?? null,
      previewHeight: report.analysisData?.previewHeight ?? null,
    };
  }

  async buildSpineAlignmentEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<SpineAlignmentReportResponseDto> {
    const koreanPayload = await this.buildSpineAlignmentReportPayload(memberId, id);
    const translated = await this.precisionReportTranslationService.translatePayloadToEnglish(
      koreanPayload as unknown as Record<string, unknown>,
    );
    return translated as unknown as SpineAlignmentReportResponseDto;
  }

  async generateAndPersistSpineAlignmentEnglishPayload(
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<SpineAlignmentReportResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const englishPayload = await this.buildSpineAlignmentEnglishPayload(memberId, id);
    await this.precisionReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return this.withCenterLogo(englishPayload, trainerId);
  }

  /**
   * 균형감각검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   * 측정 데이터는 추후 엑셀 기반으로 대체 예정이며, 현재는 하드코딩 템플릿 사용
   */
  async getBalanceSenseReport(
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<BalanceSenseReportResponseDto> {
    const resolvedMemberId = await this.resolveSharablePrecisionReportMemberId(memberId, id);
    const payload = lang === 'en'
      ? await this.ensurePrecisionReportEnglishPayload(
        resolvedMemberId,
        id,
        () => this.buildBalanceSenseEnglishPayload(resolvedMemberId, id),
        () => this.buildBalanceSenseReportPayload(resolvedMemberId, id),
      )
      : await this.buildBalanceSenseReportPayload(resolvedMemberId, id);

    return this.withCenterLogoForPrecisionReport(resolvedMemberId, id, payload);
  }

  async buildBalanceSenseReportPayload(
    memberId: string,
    id: string,
  ): Promise<BalanceSenseReportResponseDto> {
    const report = await this.precisionReportRepo.findOne({
      where: { id, userId: memberId, type: MEASUREMENT_TYPE.BALANCE_TEST },
      relations: ['user'],
    });
    if (!report) {
      throw new NotFoundException('균형감각검사 리포트를 찾을 수 없습니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedId: id } });
    const filesByDiv = Object.fromEntries(files.map((f) => [f.division, f.fileUrl]));

    const user = report.user;
    const birthDate = user.birthDate || '';
    const genderLabel = user.gender === Gender.MALE ? '남성' : user.gender === Gender.FEMALE ? '여성' : '기타';
    const measurementDate = report.createdAt.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const issuedAt = report.createdAt.toISOString().split('T')[0];

    // 나이 계산
    let age = 0;
    if (birthDate) {
      const birth = new Date(birthDate.replace(/\./g, '-'));
      const now = new Date();
      age = now.getFullYear() - birth.getFullYear();
      const hasBirthdayPassed =
        now.getMonth() > birth.getMonth() ||
        (now.getMonth() === birth.getMonth() && now.getDate() >= birth.getDate());
      if (!hasBirthdayPassed) age -= 1;
    }

    return {
      reportType: 'BALANCE_SENSE',
      reportTitle: 'i-POSTURE 정밀분석 균형감각검사',
      reportSubTitle: '균형감각 REPORT',
      issuedAt,
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : new Date(report.createdAt).toISOString(),
      member: {
        name: user.name,
        gender: genderLabel,
        birthDate,
        age,
        measurementDate,
      },
      introNotice:
        '',
      // ⚠️ Gating: sideLeg 실패 기록은 이미 저장 시점에 캡됐지만,
      // 구버전 데이터 대응을 위해 표시 시점에도 재적용
      ...this.buildBalanceTotalScore(
        (report.analysisData?.scoreDetail?.sideLeg?.disease === 'NORMAL')
          ? (report.score ?? 0)
          : Math.min(report.score ?? 0, 50),
      ),
      patternTypeAnalysis: this.buildBalancePatternTypeAnalysis(report.analysisData?.scoreDetail || {}),
      frontViewAnalysis: this.buildBalanceFrontViewAnalysis(report.analysisData?.scoreDetail || {}, filesByDiv),
      rightSideAnalysis: this.buildBalanceSideAnalysis(report.analysisData?.scoreDetail || {}, 'right', filesByDiv),
      leftSideAnalysis:  this.buildBalanceSideAnalysis(report.analysisData?.scoreDetail || {}, 'left', filesByDiv),
      dailyBalancePatterns: this.buildBalanceDailyPatterns(report.analysisData?.scoreDetail || {}),
      ...this.buildBalanceTrainingSections(
        (report.analysisData?.scoreDetail?.sideLeg?.disease === 'NORMAL')
          ? (report.score ?? 0)
          : Math.min(report.score ?? 0, 50),
      ),
      files: files.map((f) => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      landmarks: report.analysisData?.landmarks ?? null,
      previewWidth: report.analysisData?.previewWidth ?? null,
      previewHeight: report.analysisData?.previewHeight ?? null,
      disclaimer: [
        '본 리포트는 움직임 관찰과 균형 조절 패턴 분석을 기반으로 작성되었습니다.',
        '의학적 진단을 대체하지 않으며, 통증이나 기능 제한이 지속될 경우 전문의 또는 전문가 상담이 필요합니다.',
      ],
    };
  }

  async buildBalanceSenseEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<BalanceSenseReportResponseDto> {
    const koreanPayload = await this.buildBalanceSenseReportPayload(memberId, id);
    const translated = await this.precisionReportTranslationService.translatePayloadToEnglish(
      koreanPayload as unknown as Record<string, unknown>,
    );
    return translated as unknown as BalanceSenseReportResponseDto;
  }

  async generateAndPersistBalanceSenseEnglishPayload(
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<BalanceSenseReportResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const englishPayload = await this.buildBalanceSenseEnglishPayload(memberId, id);
    await this.precisionReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return this.withCenterLogo(englishPayload, trainerId);
  }

  /**
   * 관절별 가동범위 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   * 측정 데이터는 추후 엑셀 기반으로 대체 예정이며, 현재는 하드코딩 템플릿 사용
   */
  async getJointRomReport(
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<JointRomReportResponseDto> {
    const resolvedMemberId = await this.resolveSharablePrecisionReportMemberId(memberId, id);
    const payload = lang === 'en'
      ? await this.ensurePrecisionReportEnglishPayload(
        resolvedMemberId,
        id,
        () => this.buildJointRomEnglishPayload(resolvedMemberId, id),
        () => this.buildJointRomReportPayload(resolvedMemberId, id),
      )
      : await this.buildJointRomReportPayload(resolvedMemberId, id);

    return this.withCenterLogoForPrecisionReport(resolvedMemberId, id, payload);
  }

  async buildJointRomReportPayload(
    memberId: string,
    id: string,
  ): Promise<JointRomReportResponseDto> {
    const JOINT_ROM_TYPES = [
      MEASUREMENT_TYPE.NECK,
      MEASUREMENT_TYPE.SHOULDER,
      MEASUREMENT_TYPE.ELBOW,
      MEASUREMENT_TYPE.TORSO,
      MEASUREMENT_TYPE.HIP,
      MEASUREMENT_TYPE.KNEE,
      MEASUREMENT_TYPE.ANKLE,
    ];

    const report = await this.precisionReportRepo
      .createQueryBuilder('r')
      .leftJoinAndSelect('r.user', 'user')
      .where('r.id = :id', { id })
      .andWhere('r.user_id = :memberId', { memberId })
      .andWhere('r.type IN (:...types)', { types: JOINT_ROM_TYPES })
      .getOne();

    if (!report) {
      throw new NotFoundException('관절별 가동범위 리포트를 찾을 수 없습니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedId: id } });

    const user = report.user;
    const genderLabel = user.gender === Gender.MALE ? '남성' : user.gender === Gender.FEMALE ? '여성' : '기타';
    const measurementDate = report.createdAt.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const issuedAt = report.createdAt.toISOString().split('T')[0];
    const romContent = this.buildJointRomContent(report);

    return {
      reportType: 'JOINT_RANGE_OF_MOTION',
      reportTitle: 'i-POSTURE 정밀분석 각 관절별 가동범위',
      issuedAt,
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : new Date(report.createdAt).toISOString(),
      member: {
        name: user.name,
        gender: genderLabel,
        birthDate: user.birthDate || '',
        measurementDate,
      },
      summary: this.buildJointRomSummary(report, files),
      movementDetail: romContent.movementDetail,
      mainCauses: romContent.mainCauses,
      commentSection: romContent.commentSection,
      recommendedDailyRoutine: romContent.recommendedDailyRoutine,
      expectedEffect: romContent.expectedEffect,
      actionButton: { label: '솔루션' },
      disclaimer: [
        '본 리포트는 관절 가동범위 측정 및 움직임 패턴 분석을 바탕으로 작성된 참고 자료입니다.',
        '의학적 진단을 대체하지 않으며, 통증이 지속되거나 기능 제한이 심할 경우 전문 의료진과 상담이 필요합니다.',
      ],
      files: files.map((f) => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      landmarks: (() => {
        // ROM analysisData는 analysisData[key].steps[n].landmarks 구조로 저장됨
        // report.key가 없을 수 있으므로 analysisData의 모든 키를 순회
        const ad = report.analysisData;
        if (!ad) return null;
        const candidates = report.key ? [report.key] : Object.keys(ad);
        for (const k of candidates) {
          const keyData = ad[k];
          if (keyData?.steps?.length) {
            const mapped: Record<string, any> = {};
            for (const step of keyData.steps) {
              if (step.step && step.landmarks) {
                mapped[step.step] = step.landmarks;
              }
            }
            if (Object.keys(mapped).length > 0) return mapped;
          }
        }
        return ad?.landmarks ?? null;
      })(),
      previewWidth: report.analysisData?.previewWidth ?? null,
      previewHeight: report.analysisData?.previewHeight ?? null,
    };
  }

  async buildJointRomEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<JointRomReportResponseDto> {
    const koreanPayload = await this.buildJointRomReportPayload(memberId, id);
    const translated = await this.precisionReportTranslationService.translatePayloadToEnglish(
      koreanPayload as unknown as Record<string, unknown>,
    );
    return translated as unknown as JointRomReportResponseDto;
  }

  async generateAndPersistJointRomEnglishPayload(
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<JointRomReportResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const englishPayload = await this.buildJointRomEnglishPayload(memberId, id);
    await this.precisionReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return this.withCenterLogo(englishPayload, trainerId);
  }

  /**
   * 전신기능검사 리포트 상세 조회 (공유 리포트 - 인증 불필요)
   * 측정 데이터는 추후 엑셀 기반으로 대체 예정이며, 현재는 하드코딩 템플릿 사용
   */
  async getFullBodyFunctionReport(
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<FullBodyFunctionReportResponseDto> {
    const resolvedMemberId = await this.resolveSharablePrecisionReportMemberId(memberId, id);
    const payload = lang === 'en'
      ? await this.ensurePrecisionReportEnglishPayload(
        resolvedMemberId,
        id,
        () => this.buildFullBodyFunctionEnglishPayload(resolvedMemberId, id),
        () => this.buildFullBodyFunctionReportPayload(resolvedMemberId, id),
      )
      : await this.buildFullBodyFunctionReportPayload(resolvedMemberId, id);

    return this.withCenterLogoForPrecisionReport(resolvedMemberId, id, payload);
  }

  async buildFullBodyFunctionReportPayload(
    memberId: string,
    id: string,
  ): Promise<FullBodyFunctionReportResponseDto> {
    const report = await this.precisionReportRepo.findOne({
      where: { id, userId: memberId, type: MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST },
      relations: ['user'],
    });
    if (!report) {
      throw new NotFoundException('전신기능검사 리포트를 찾을 수 없습니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedId: id } });

    const user = report.user;
    const genderLabel = user.gender === Gender.MALE ? '남성' : user.gender === Gender.FEMALE ? '여성' : '기타';
    const measurementDate = report.createdAt.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const issuedAt = report.createdAt.toISOString().split('T')[0];

    return {
      reportType: 'FULL_BODY_FUNCTION',
      reportTitle: 'i-POSTURE 정밀분석 전신기능검사',
      issuedAt,
      createdAt: report.createdAt instanceof Date ? report.createdAt.toISOString() : new Date(report.createdAt).toISOString(),
      member: {
        name: user.name,
        gender: genderLabel,
        birthDate: user.birthDate || '',
        measurementDate,
      },
      exercisePerformanceIndex: this.buildOHTPerformanceIndex(report.analysisData?.scoreDetail ?? {}),
      movementBiomechanicsSummary: this.buildOHTBiomechanicsSummary(report.analysisData?.scoreDetail ?? {}),
      linkedScenario: this.buildLinkedScenario(report.analysisData?.scoreDetail ?? {}),
            muscleBalance: this.buildMuscleBalanceSheet(report.analysisData?.scoreDetail ?? {}),
            exerciseCases: this.buildExerciseCases(report.analysisData?.scoreDetail ?? {}),
      sidePatternAnalysis: this.buildSidePatternAnalysis(report.analysisData?.scoreDetail ?? {}, Object.fromEntries(files.map(f => [f.division, f.fileUrl]))),
      rearPatternAnalysis: this.buildRearPatternAnalysis(report.analysisData?.scoreDetail ?? {}, Object.fromEntries(files.map(f => [f.division, f.fileUrl]))),
      frontPatternAnalysis: this.buildFrontPatternAnalysis(report.analysisData?.scoreDetail ?? {}, Object.fromEntries(files.map(f => [f.division, f.fileUrl]))),
      disclaimer: [
        '본 리포트는 전신 기능 검사와 오버헤드 스쿼트 기반 움직임 분석 결과를 바탕으로 작성되었습니다.',
        '의학적 진단을 대체하지 않으며, 통증이나 기능 제한이 지속될 경우 전문 의료진 또는 전문가 상담이 필요합니다.',
      ],
      files: files.map((f) => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      landmarks: report.analysisData?.landmarks ?? null,
      previewWidth: report.analysisData?.previewWidth ?? null,
      previewHeight: report.analysisData?.previewHeight ?? null,
    };
  }

  async buildFullBodyFunctionEnglishPayload(
    memberId: string,
    id: string,
  ): Promise<FullBodyFunctionReportResponseDto> {
    const koreanPayload = await this.buildFullBodyFunctionReportPayload(memberId, id);
    const translated = await this.precisionReportTranslationService.translatePayloadToEnglish(
      koreanPayload as unknown as Record<string, unknown>,
    );
    return translated as unknown as FullBodyFunctionReportResponseDto;
  }

  async generateAndPersistFullBodyFunctionEnglishPayload(
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<FullBodyFunctionReportResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');
    }

    const englishPayload = await this.buildFullBodyFunctionEnglishPayload(memberId, id);
    await this.precisionReportTranslationService.persistDisplayPayloadEn(id, englishPayload);
    return this.withCenterLogo(englishPayload, trainerId);
  }

  // ─────────────────────────────────────────────────────────────
  // 리포트 헬퍼 메서드
  // ─────────────────────────────────────────────────────────────

  /** 척추정렬검사 관찰 분석 텍스트 생성 */
  private buildSpinalAnalysisText(
    spinalTilt: any,
    shoulderAlignment: any,
    pelvicReaction?: any,
    centerShiftPxPerCm?: number,
  ): string {
    // 문장 1: 상체 중심 이동 (거리 + 방향)
    const centerDist = centerShiftPxPerCm
      ? formatCenterShiftDistanceCm(spinalTilt?.result ?? 0, centerShiftPxPerCm)
      : Number(Math.abs(spinalTilt?.result ?? 0).toFixed(1));
    const centerIsZero = !spinalTilt || Math.abs(spinalTilt?.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX;
    const centerDir = spinalTilt?.result >= 0 ? '오른쪽' : '왼쪽';
    const line1 = centerIsZero
      ? `골반 중심선 대비 몸통이 <b>수직으로 정렬된</b> 상태를 보이며 상체 무게중심의 <b>안정성</b>이 있을 가능성이 높으며`
      : `골반 중심선 대비 몸통이 <b>${centerDist}</b>cm만큼 <b>${centerDir}으로 이동한</b> 상태를 보이며 상체 무게중심의 <b>치우침</b>이 있을 가능성이 높으며`;

    // 문장 2: 골반 반응 (방향 + 각도)
    const pelvicNormal = !pelvicReaction || pelvicReaction.isNormal;
    const pelvicAngle = Math.abs(pelvicReaction?.result ?? 0).toFixed(0);
    const line2 = pelvicNormal
      ? `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>좌우</b> 골반이 <b>평행한</b> 경향이 관찰되었습니다.`
      : `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>${pelvicReaction.higherSide}</b> 골반이 반대측보다 <b>${pelvicAngle}°만큼 높아진</b> 경향이 관찰되었습니다.`;

    // 문장 3: 척추 라인 방향
    const shoulderNormal = !shoulderAlignment || shoulderAlignment.disease === 'NORMAL';
    const spineDir = shoulderNormal ? '수직' : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';
    const spineStress = spineDir === '수직' ? '균형적인 부하 전달' : '비대칭적인 자극';
    const line3 = `동시에 척추 배열이 <b>${spineDir}</b> 방향의 흐름을 보여, 움직임 시 <b>${spineStress}</b>이 전달될 수 있고,`;

    // 문장 4: 등 높이 차이 (방향 + 각도)
    const backSide = shoulderNormal ? '양쪽 대칭' : spineDir;
    const backState1 = shoulderNormal ? '균형을 유지하는 양상이' : '더 높게 솟아오르는 양상이';
    const backState2 = shoulderNormal ? '안정적인 중립 정렬이' : '척추의 입체적인 정렬 변화가';
    const line4 = shoulderNormal
      ? `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`
      : `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`;

    return [line1, line2, line3, line4].join('\n');
  }

  private buildSpinalResultText(level: string, spinalTilt?: any, shoulderAlignment?: any, pelvicReaction?: any): string {
    const hasTorso    = !!(spinalTilt && spinalTilt.disease !== 'NORMAL'); // 상체 중심 이동
    const hasPelvic   = !!(pelvicReaction && !pelvicReaction.isNormal);          // 숙일 때 골반 반응 유형
    const hasShoulder = !!(shoulderAlignment && shoulderAlignment.disease !== 'NORMAL'); // 척추 라인 방향 & 숙일 때 등 높이 차이

    const count = [hasTorso, hasPelvic, hasShoulder].filter(Boolean).length;

    // 0개 — 전부 정상
    if (count === 0) {
      return '현재 외형적으로는 전반적인 신체 축이 수직으로 견고하게 정렬된 양상을 보이며, 하중 분산 능력이 매우 안정적일 가능성이 높게 분석됩니다.'
        + '다만, 이러한 정적 정렬이 실제 움직임이나 생활 습관 속에서도 유지되고 있는지 확인이 필요합니다.'
        + ' 이어지는 리포트를 통해, 보이지 않는 곳에서 정렬을 위협하는 미세한 습관이 있는지 점검하여 현재의 완벽한 균형을 유지하시길 권장합니다.';
    }

    // 1개 비정상
    if (count === 1) {
      if (hasTorso) {
        return '골반 중심축을 기준으로 상체가 한쪽으로 밀려 있는 양상을 보이며, 이는 서 있거나 움직일 때 체중이 특정 측면에만 과하게 실리고 있을 가능성을 시사합니다.'
          + '척추의 직접적인 회전은 적으나 중심축 자체가 쏠려 있어, 특정 관절에만 누적 스트레스가 쌓이기 쉬운 경향을 보입니다.';
      }
      if (hasPelvic) {
        return '상체를 숙였을 때 양쪽 골반의 수평 정렬이 어긋나는 양상이 확인되며, 이는 골반을 지지하는 하체 근육의 길이가 서로 다르거나 기능적 비대칭이 있을 가능성이 분석됩니다.'
          + '골반의 수평이 맞지 않으면 척추의 뿌리가 흔들리는 것과 같아 추후 허리 주변의 불편함으로 전이될 경향이 있습니다.';
      }
      if (hasShoulder) {
        return '숙인 자세에서 한쪽 등이 반대측보다 솟아오르는 양상을 보이며, 이는 단순히 어깨가 높은 것이 아니라 척추가 입체적으로 회전하며 구조적인 정렬 변화를 동반했을 가능성을 보여줍니다.'
          + '척추의 회전은 호흡 효율을 떨어뜨리고 한쪽 근육만 쉽게 뭉치게 만드는 경향이 있어 주의가 필요합니다.';
      }
    }

    // 2개 비정상
    if (count === 2) {
      if (hasTorso && hasPelvic) {
        return '골반의 수평이 어긋나면서 그 위의 상체 중심축까지 한쪽으로 밀려 있는 양상이 확인되며, 이는 신체 하부의 불안정이 상체의 위치 변화를 유도했을 가능성이 높게 분석됩니다.'
          + '무게중심이 한쪽으로 쏠린 상태가 지속되면 엉덩관절과 허리 관절에 비대칭적인 하중이 가해질 경향이 있습니다.';
      }
      if (hasPelvic && hasShoulder) {
        return '숙인 자세에서 골반의 수평이 맞지 않음과 동시에 등의 높낮이 차이가 관찰되는 것은, 골반의 기울기가 척추의 입체적인 회전 변화로까지 이어졌을 가능성을 시사합니다.'
          + ' 척추의 뿌리인 골반부터 상부 흐름까지 전반적인 정렬 양상이 변해 있을 경향이 있어 주의가 필요합니다.';
      }
      if (hasShoulder && hasTorso) {
        return '척추가 입체적으로 회전하며 등이 솟아오른 양상과 함께 상체 무게중심이 정중선을 벗어난 흐름이 확인되어, 상부의 정렬 변화가 전체적인 체중 분포에 영향을 주고 있을 가능성이 분석됩니다.'
          + '이러한 경향은 일상 움직임 시 특정 방향의 근육과 관절에만 과도한 긴장을 유발할 수 있습니다.';
      }
    }

    // 3개 모두 비정상
    return '골반 수평과 상체 중심축, 등 높이 모두에서 정렬 변화가 포착되어 신체 하부의 불안정이 상부로 전이되었을 가능성이 높게 분석됩니다.'
      + ' 이러한 전신 비대칭 양상은 관절 스트레스를 누적시킬 경향이 있으므로, 전문 트레이너를 통해 정확한 원인을 파악하고 개인별 정렬 최적화 트레이닝을 시작할 것을 강력히 권장합니다.';
  }

  /** 균형감각검사 totalScore 블록 (score 0-100 기준 5단계) */
  // ─────────────────────────────────────────────────────────────
  // 균형감각검사: 주유형 판별 (YES/NO 의사결정 트리)
  // ─────────────────────────────────────────────────────────────
  private determineBalanceType(sd: any): number {
    const verticalOk    = sd?.verticalBody?.disease    === 'NORMAL';
    const hipOk         = sd?.hip?.disease             === 'NORMAL';
    const horizontalOk  = sd?.horizontalBody?.disease  === 'NORMAL';
    const headOk        = sd?.head?.disease            === 'NORMAL';
    const sideLegNormal = sd?.sideLeg?.disease         === 'NORMAL';

    if (!verticalOk) {
      // A 루트: Q1 YES (몸통 좌우 흔들림 있음)
      if (!hipOk)        return 1; // Q2 YES → 골반 안정성 부족형
      if (!horizontalOk) return 2; // Q3 YES → 지지 다리 정렬 제어 부족형
      return 3;                    // Q3 NO  → 몸통 보상 중심 전략형
    } else {
      // B 루트: Q1 NO (몸통 안정)
      if (!horizontalOk) return 2; // Q4 YES → 지지 다리 정렬 제어 부족형
      if (!headOk)       return 4; // Q5 YES → 상체 각도 조절 의존형
      if (sideLegNormal) return 6; // Q6 YES → 전신 균형 전략 정립형
      return 5;                    // Q6 NO  → 균형 정밀 조절 발전형
    }
  }

  private buildBalancePatternTypeAnalysis(sd: any): any {
    const RADAR_LABELS = [
      '골반 안정성 부족형',
      '전신 균형 전략 정립형',
      '균형 정밀 조절 발전형',
      '상체 각도 조절 의존형',
      '몸통 보상 중심 전략형',
      '지지 다리 정렬 제어 부족형',
    ];
    const TYPE_DATA: Record<number, { typeName: string; meaning: string; causes: string[]; mainRadarValues: number[]; subRadarValues: number[] }> = {
      1: {
        typeName: '골반 안정성 부족형',
        meaning: '한 다리 지지 시 골반 안정성이 균형 유지의 핵심 제한 요인으로 작용하는 유형입니다.',
        causes: [
          '한 다리 지지 시 중간볼기근을 중심으로 한 골반 안정화 근육의 지지 역할이 충분히 발휘되지 않는 경향이 있습니다.',
          '이로 인해 체중 부하 초기에 골반 안정화 근육이 적절한 타이밍에 개입하지 못하는 경우가 많습니다.',
          '또한 장시간 앉아 있는 생활이나 힙을 적극적으로 사용하는 활동이 적은 환경이 이러한 근육 사용 빈도를 낮췄을 가능성이 있습니다.',
        ],
        // RADAR_LABELS: [0]골반안정성부족형 [1]전신균형전략정립형 [2]균형정밀조절발전형 [3]상체각도조절의존형 [4]몸통보상중심전략형 [5]지지다리정렬제어부족형
        mainRadarValues: [50, 40, 40, 40, 40, 40], // idx0 골반안정성부족형 ↑
        subRadarValues:  [30, 30, 30, 30, 35, 35],  // idx4 몸통보상, idx5 지지다리 ↑
      },
      2: {
        typeName: '지지 다리 정렬 제어 부족형',
        meaning: '균형 유지 과정에서 지지하는 다리의 정렬이 안정적으로 유지되지 않는 유형입니다.',
        causes: [
          '지지 다리에서 발–무릎–고관절을 연결하는 정렬 유지 근육들의 협응이 충분하지 않은 경향이 있습니다.',
          '이로 인해 체중을 싣는 순간 무릎 주변과 엉덩이 근육의 제어 타이밍이 어긋나는 경우가 자주 나타납니다.',
          '또한 오래 앉아 있는 생활이나 한쪽 다리에 체중을 싣는 습관이 이러한 정렬 패턴 형성에 영향을 주었을 가능성이 있습니다.',
        ],
        mainRadarValues: [40, 40, 40, 40, 40, 50], // idx5 지지다리정렬제어부족형 ↑
        subRadarValues:  [35, 30, 30, 30, 35, 30],  // idx0 골반안정성, idx4 몸통보상 ↑
      },
      3: {
        typeName: '몸통 보상 중심 전략형',
        meaning: '하체보다 몸통 움직임을 활용해 균형을 유지하는 비중이 높은 유형입니다.',
        causes: [
          '한 다리 지지 시 중둔근을 중심으로 한 골반 안정화 근육의 지지 역할이 충분히 발휘되지 않는 경향이 있습니다.',
          '이로 인해 복부·척추 주변 근육을 활용해 몸통을 좌우로 이동시키며 균형을 보완하는 전략이 하체 조절보다 더 익숙해진 상태일 수 있습니다.',
          '그 결과 골반이나 지지 다리가 안정되기 전에 몸통이 좌우로 흔들리며 균형을 유지하려는 패턴이 먼저 나타납니다.',
        ],
        mainRadarValues: [40, 40, 40, 40, 50, 40], // idx4 몸통보상중심전략형 ↑
        subRadarValues:  [35, 30, 30, 35, 30, 30],  // idx0 골반안정성, idx3 상체각도 ↑
      },
      4: {
        typeName: '상체 각도 조절 의존형',
        meaning: '균형 유지를 위해 상체의 숙임 또는 젖힘 각도를 적극적으로 사용하는 유형입니다.',
        causes: [
          '한 다리 지지 시 엉덩관절 굽힘, 폄을 통해 체중을 안정적으로 받아내는 조절 능력이 충분히 발휘되지 않는 경향이 있습니다.',
          '이로 인해 골반 위에서 몸을 세워 버티기보다, 상체를 앞이나 뒤로 이동시켜 무게중심 위치를 조정하는 전략이 우선적으로 사용됩니다.',
          '그 결과 좌우 이동보다는 상체의 숙임 또는 젖힘을 통한 전후 방향 조절 패턴이 균형 유지 방식으로 나타나는 것으로 추정됩니다.',
        ],
        mainRadarValues: [40, 40, 40, 50, 40, 40], // idx3 상체각도조절의존형 ↑
        subRadarValues:  [30, 30, 30, 30, 35, 35],  // idx4 몸통보상, idx5 지지다리 ↑
      },
      5: {
        typeName: '균형 정밀 조절 발전형',
        meaning: '기본적인 균형은 안정적으로 유지되며, 세부적인 조절 능력을 더 발전시킬 수 있는 유형입니다.',
        causes: [
          '한 다리 지지 시 전체적인 안정성은 유지되지만, 든 다리의 위치를 세밀하게 조절하는 데에는 제한이 남아 있는 상태입니다.',
          '균형 유지를 위한 기본적인 조절은 가능하나, 정교한 컨트롤 전략은 아직 충분히 활용되지 않는 경향이 있습니다.',
          '따라서 현재의 안정성을 기반으로 균형 정확도를 높이는 훈련이 필요한 단계로 볼 수 있습니다.',
        ],
        mainRadarValues: [40, 40, 50, 40, 40, 40], // idx2 균형정밀조절발전형 ↑
        subRadarValues:  [30, 30, 30, 35, 30, 35],  // idx3 상체각도, idx5 지지다리 ↑
      },
      6: {
        typeName: '전신 균형 전략 정립형',
        meaning: '한 다리 지지 시 전신 균형 전략이 안정적으로 정립되어 높은 수준의 움직임이 가능한 유형입니다.',
        causes: [
          '정면과 측면 모두에서 큰 흔들림 없이 안정적인 균형 패턴이 일관되게 유지되는 상태입니다.',
          '든 다리의 위치와 허벅지 라인까지 세밀하게 조절되며, 전신이 하나의 단위처럼 효율적으로 협응합니다.',
          '이러한 균형 능력을 바탕으로 기본 균형을 넘어 난이도 높은 동작과 퍼포먼스 향상 훈련으로 확장하기에 적합한 단계입니다.',
        ],
        mainRadarValues: [40, 50, 40, 40, 40, 40], // idx1 전신균형전략정립형 ↑
        subRadarValues:  [30, 30, 35, 35, 30, 30],  // idx2 균형정밀, idx3 상체각도 ↑
      },
    };

    const typeNum = this.determineBalanceType(sd);
    const t = TYPE_DATA[typeNum];

    return {
      title: `한 다리 지지 동작에서 <b>${t.typeName}</b> 패턴이 주로 관찰됩니다.`,
      chart: {
        assetKey: 'BALANCE_PATTERN_RADAR',
        url: null,
        labels: RADAR_LABELS,
        datasets: [
          { label: '주유형', values: t.mainRadarValues, color: 'blue' },
          { label: '보조유형', values: t.subRadarValues, color: 'lightblue' },
        ],
      },
      typeName: t.typeName,
      typeDescription: t.meaning,
      causeTitle: '원인',
      causeDescription: t.causes.join('\n\n'),
    };
  }

  private buildBalanceFrontViewAnalysis(sd: any, filesByDiv: Record<string, string> = {}): any {
    const hip          = sd?.hip          || {};
    const vertBody     = sd?.verticalBody  || {};
    const horizBody    = sd?.horizontalBody || {};
    const frontLeg     = sd?.frontLeg      || {};

    // ── Card 1: 좌우 골반 높이 대칭 상태 (hip) ──
    // rightLegRaise: hip.rightOk / hip.rightAngle
    let c1rObs: string, c1rPat: string;
    const rightAngle = hip.rightAngle ?? 0;
    const rightJudgeAngle = Math.trunc(rightAngle);
    if (
      rightJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MIN_DEG
      && rightJudgeAngle <= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MAX_DEG
    ) {
      c1rObs = '좌우 골반 높이 큰 차이 없이 유지(양호)';
      c1rPat = '한 다리 지지 상황에서도 골반 높이가 비교적 안정적으로 유지됩니다.\n하체에서 체중을 받아내는 기본적인 균형 전략이 잘 작동하고 있는 상태입니다.';
    } else if (rightJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_OVER_MIN_DEG) {
      c1rObs = '오른쪽 골반이 과도하게 올라가는 패턴 관찰';
      c1rPat = '균형을 유지하는 과정에서 오른쪽 골반을 과도하게 끌어올려 중심을 잡으려는 패턴이 나타납니다.\n하체에서 안정적으로 체중을 받아내기보다, 골반 위치 자체를 조정해 균형을 해결하려는 경향이 보입니다.\n이 경우 균형이 \'고정\'되기보다는 긴장으로 버티는 형태가 되기 쉽습니다.';
    } else {
      c1rObs = '오른쪽 골반이 아래로 내려가는 패턴 관찰';
      c1rPat = '오른쪽 다리를 들었을 때 오른쪽 골반이 떨어지는 모습은,\n지지 다리인 왼쪽 다리에서 골반을 안정적으로 지지하는 기능이 충분히 작동하지 못한 상태를 의미합니다.\n이로 인해 골반 수평이 먼저 무너지고, 이후 상체 기울기나 다리 정렬 변화로 균형을 보완하려는 패턴이 나타납니다.';
    }
    // leftLegRaise: hip.leftOk / hip.leftAngle
    let c1lObs: string, c1lPat: string;
    const leftAngle = hip.leftAngle ?? 0;
    const leftJudgeAngle = Math.trunc(leftAngle);
    if (
      leftJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MIN_DEG
      && leftJudgeAngle <= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MAX_DEG
    ) {
      c1lObs = '좌우 골반 높이 큰 차이 없이 유지(양호)';
      c1lPat = '한 다리 지지 상황에서도 골반 높이가 비교적 안정적으로 유지됩니다.\n하체에서 체중을 받아내는 기본적인 균형 전략이 잘 작동하고 있는 상태입니다.';
    } else if (leftJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_OVER_MIN_DEG) {
      c1lObs = '왼쪽 골반이 과도하게 올라가는 패턴 관찰';
      c1lPat = '균형을 유지하는 과정에서 왼쪽 골반을 과도하게 끌어올려 중심을 잡으려는 패턴이 나타납니다.\n하체에서 안정적으로 체중을 받아내기보다, 골반 위치 자체를 조정해 균형을 해결하려는 경향이 보입니다.\n이 경우 균형이 \'고정\'되기보다는 긴장으로 버티는 형태가 되기 쉽습니다.';
    } else {
      c1lObs = '왼쪽 골반이 아래로 내려가는 패턴 관찰';
      c1lPat = '왼쪽 다리를 들었을 때 왼쪽 골반이 떨어지는 모습은,\n지지 다리인 오른쪽 다리에서 골반을 안정적으로 지지하는 기능이 충분히 작동하지 못한 상태를 의미합니다.\n이로 인해 골반 수평이 먼저 무너지고, 이후 상체 기울기나 다리 정렬 변화로 균형을 보완하려는 패턴이 나타납니다.';
    }

    // ── Card 2: 상체 좌우 기울기 상태 (verticalBody) ──
    const c2rObs = vertBody.rightOk
      ? '상체가 바로 서서 안정적으로 유지(양호)'
      : '상체가 왼쪽 또는 오른쪽으로 기울어지는 패턴 관찰';
    const c2rPat = vertBody.rightOk
      ? '한 다리 지지 상황에서도 상체가 좌우로 크게 흔들리지 않습니다.\n균형 조절이 주로 하체와 골반에서 이루어지고 있음을 의미합니다.\n상체는 균형을 보조하는 역할에 머물러 있습니다.'
      : '균형이 흔들릴 때 하체보다 상체를 좌우로 이동시켜 중심을 맞추는 전략이 사용됩니다.\n몸통 움직임이 먼저 나타나며, 하체에서 미세하게 균형을 조절하는 비중은 줄어든 모습입니다.\n이 패턴은 균형을 빠르게 회복할 수 있지만, 안정성은 떨어질 수 있습니다.';
    const c2lObs = vertBody.leftOk
      ? '상체가 바로 서서 안정적으로 유지(양호)'
      : '상체가 왼쪽 또는 오른쪽으로 기울어지는 패턴 관찰';
    const c2lPat = vertBody.leftOk
      ? '한 다리 지지 상황에서도 상체가 좌우로 크게 흔들리지 않습니다.\n균형 조절이 주로 하체와 골반에서 이루어지고 있음을 의미합니다.\n상체는 균형을 보조하는 역할에 머물러 있습니다.'
      : '균형이 흔들릴 때 하체보다 상체를 좌우로 이동시켜 중심을 맞추는 전략이 사용됩니다.\n몸통 움직임이 먼저 나타나며, 하체에서 미세하게 균형을 조절하는 비중은 줄어든 모습입니다.\n이 패턴은 균형을 빠르게 회복할 수 있지만, 안정성은 떨어질 수 있습니다.';

    // ── Card 3: 지지 다리 정렬 상태 (horizontalBody) ──
    const resolveHorizSupportObs = (
      supportLabel: '왼쪽' | '오른쪽',
      status: string | undefined,
      isOk: boolean,
    ): { obs: string; pat: string } => {
      if (isOk || status === '바른정렬') {
        return {
          obs: `지지하는 ${supportLabel} 다리가 곧게 유지(양호)`,
          pat: '지지 다리가 체중을 곧게 받아 균형의 기준축 역할을 하고 있습니다.\n하체에서 안정적으로 체중을 수용하며, 불필요한 관절 보상이 적습니다.',
        };
      }
      if (status === '오다리') {
        return {
          obs: `지지하는 ${supportLabel} 무릎이 바깥으로 벌어지는 패턴 관찰(varus)`,
          pat: '체중을 지지하는 과정에서 엉덩관절을 바깥쪽으로 고정하여 무릎을 밀어 안정감을 확보하려는 패턴이 나타납니다.\n이는 지지 다리에서 엉덩 부위와 무릎 주변을 단단히 고정해 균형을 유지하려는 전략과 연관됩니다.\n또한 발 바깥쪽으로 체중을 싣는 지지 방식이 함께 나타날 경우, 무릎이 벌어진 정렬이 더 뚜렷해질 수 있습니다.',
        };
      }
      return {
        obs: `지지하는 ${supportLabel} 무릎이 안쪽으로 무너지는 패턴 관찰(valgus)`,
        pat: '체중을 지지하는 과정에서 엉덩관절이 안쪽으로 밀리며 무릎이 안쪽으로 무너지는 패턴이 나타납니다.\n이는 지지 다리에서 엉덩 부위의 바깥쪽 안정화 기능이 충분히 작동하지 못할 때 흔히 관찰됩니다.\n또한 발 안쪽으로 체중이 쏠리는 지지 전략이 함께 나타날 경우, 무릎 안쪽 붕괴가 더 쉽게 강화됩니다.',
      };
    };

    const c3r = resolveHorizSupportObs('왼쪽', horizBody.leftStatus, horizBody.leftOk);
    const c3l = resolveHorizSupportObs('오른쪽', horizBody.rightStatus, horizBody.rightOk);
    const c3rObs = c3r.obs;
    const c3rPat = c3r.pat;
    const c3lObs = c3l.obs;
    const c3lPat = c3l.pat;

    // ── Card 4: 든 다리 무릎-발목 수직 정렬 상태 (frontLeg) ──
    const c4rObs = frontLeg.rightOk
      ? '무릎–발목 정렬이 곧게 유지(양호)'
      : '오른쪽 발목이 무릎 기준 바깥 또는 안쪽으로 벗어나는 패턴 관찰';
    const c4rPat = frontLeg.rightOk
      ? '지지 다리(왼쪽 다리)에서 체중을 안정적으로 수용하고, 골반과 몸통 중심이 흔들림 없이 유지됩니다.\n이로 인해 든 다리(오른쪽)는 별도의 보상 없이 자연스럽게 제자리를 유지할 수 있습니다.\n즉, 든 다리의 수직 정렬은 지지 쪽과 중심 안정성이 충분히 확보된 결과로 해석됩니다.'
      : '지지 다리(왼쪽 다리)와 골반, 몸통에서 중심을 안정적으로 고정하지 못해 몸의 중심이 미세하게 흔들리는 양상이 나타납니다.\n이 중심 변화를 보완하기 위해 든 다리(오른쪽)가 바깥쪽으로 이동하거나 안쪽으로 끌려 들어오며 균형을 맞추려는 반응을 보입니다.\n즉, 든 다리 발목 위치 변화는 다리 자체의 문제가 아니라 지지 쪽과 중심 안정성 부족에 대한 보상적 위치 조절 결과로 해석할 수 있습니다.';
    const c4lObs = frontLeg.leftOk
      ? '무릎–발목 정렬이 곧게 유지(양호)'
      : '왼쪽 발목이 무릎 기준 바깥 또는 안쪽으로 벗어나는 패턴 관찰';
    const c4lPat = frontLeg.leftOk
      ? '지지 다리(오른쪽)에서 체중을 안정적으로 수용하고, 골반과 몸통 중심이 흔들림 없이 유지됩니다.\n이로 인해 든 다리(왼쪽 다리)는 별도의 보상 없이 자연스럽게 제자리를 유지할 수 있습니다.\n즉, 든 다리의 수직 정렬은 지지 쪽과 중심 안정성이 충분히 확보된 결과로 해석됩니다.'
      : '지지 다리(오른쪽)와 골반, 몸통에서 중심을 안정적으로 고정하지 못해 몸의 중심이 미세하게 흔들리는 양상이 나타납니다.\n이 중심 변화를 보완하기 위해 든 다리(왼쪽 다리)가 바깥쪽으로 이동하거나 안쪽으로 끌려 들어오며 균형을 맞추려는 반응을 보입니다.\n즉, 든 다리 발목 위치 변화는 다리 자체의 문제가 아니라 지지 쪽과 중심 안정성 부족에 대한 보상적 위치 조절 결과로 해석할 수 있습니다.';

    return {
      title: '정면',
      panels: [
        {
          title: '왼쪽 지지 구간',
          normalImage: { assetKey: 'BALANCE_FRONT_RIGHT_NORMAL', url: this.resolveBalanceUrl('BALANCE_FRONT_RIGHT_NORMAL') },
          currentImage: { assetKey: 'BALANCE_FRONT_RIGHT_CURRENT', url: filesByDiv['FRONT_RIGHT'] ?? null },
        },
        {
          title: '오른쪽 지지 구간',
          normalImage: { assetKey: 'BALANCE_FRONT_LEFT_NORMAL', url: this.resolveBalanceUrl('BALANCE_FRONT_LEFT_NORMAL') },
          currentImage: { assetKey: 'BALANCE_FRONT_LEFT_CURRENT', url: filesByDiv['FRONT_LEFT'] ?? null },
        },
      ],
      analysisCards: [
        {
          title: '좌우 골반 높이 대칭 상태',
          observationPoints: { rightLegRaise: c1rObs, leftLegRaise: c1lObs },
          patternAnalysis:   { rightLegRaise: c1rPat, leftLegRaise: c1lPat },
        },
        {
          title: '상체 좌우 기울기 상태',
          observationPoints: { rightLegRaise: c2rObs, leftLegRaise: c2lObs },
          patternAnalysis:   { rightLegRaise: c2rPat, leftLegRaise: c2lPat },
        },
        {
          title: '지지 다리 정렬 상태',
          observationPoints: { rightLegRaise: c3rObs, leftLegRaise: c3lObs },
          patternAnalysis:   { rightLegRaise: c3rPat, leftLegRaise: c3lPat },
        },
        {
          title: '든 다리 무릎–발목 수직 정렬 상태',
          observationPoints: { rightLegRaise: c4rObs, leftLegRaise: c4lObs },
          patternAnalysis:   { rightLegRaise: c4rPat, leftLegRaise: c4lPat },
        },
      ],
    };
  }

  private buildBalanceSideAnalysis(sd: any, side: 'left' | 'right', filesByDiv: Record<string, string> = {}): any {
    const P = 10; // posRange (전략 파일과 동일)
    const isRight = side === 'right';
    const legLabel     = isRight ? '오른쪽' : '왼쪽';
    const supportLabel = isRight ? '왼쪽'   : '오른쪽';

    const headOk      = isRight ? sd?.head?.rightOk    : sd?.head?.leftOk;
    const headDiff    = isRight ? (sd?.head?.rightAngle  ?? 0) : (sd?.head?.leftAngle  ?? 0);
    const sideLegOk   = isRight ? sd?.sideLeg?.rightOk : sd?.sideLeg?.leftOk;
    const sideLegDiff = isRight ? (sd?.sideLeg?.rightAngle ?? 0) : (sd?.sideLeg?.leftAngle ?? 0);

    // ── 항목5: 상체 전후 기울기 ──────────────────────────────────
    // rightDiff < -P → forward lean (right side view: shoulder.x - hip.x < 0)
    // leftDiff  > +P → forward lean (left  side view: shoulder.x - hip.x > 0)
    let headObs: string, headPat: string;
    if (headOk) {
      headObs = `상체가 곧게 서서 유지(양호)`;
      headPat = `지지 다리(${supportLabel} 다리)와 골반이 중심을 안정적으로 지지하여, 상체가 전후로 흔들리지 않고 유지됩니다.\n균형 조절이 주로 하체에서 이루어지고, 상체는 보상 역할을 최소화한 상태입니다.\n이 패턴은 한 다리 지지에서 효율적인 균형 전략이 확보된 결과로 해석됩니다.`;
    } else {
      // 문서 부호 규약: 음수 = shoulder가 hip보다 뒤(뒤로 기울어짐), 정상 범위 −4°~−17°
      // headDiff > -4  → 앞으로 기울어짐 (정상보다 덜 뒤로, 또는 앞쪽)
      // headDiff < -17 → 뒤로 과도하게 젖혀짐
      const isForward = headDiff > -4;
      if (isForward) {
        headObs = `상체가 앞으로 기울어지는 패턴 관찰`;
        headPat = `균형이 흔들릴 때 지지 다리(${supportLabel} 다리)로 몸통을 수직에 가깝게 지지하기보다, 상체를 앞으로 숙여 무게중심을 낮추는 전략이 나타납니다.\n이 과정에서 몸을 접어 중심을 낮추는 방식이 더 빠르고 익숙하게 사용되는 경향이 있습니다.\n그 결과 한 다리 지지에서 높이를 유지하는 정밀 조절보다, 낮춰서 버티는 균형 패턴이 먼저 관찰됩니다.`;
      } else {
        headObs = `상체가 뒤로 과도하게 젖혀지는 패턴 관찰`;
        headPat = `지지 다리(${supportLabel} 다리)에서 중심이 흔들릴 때 몸통을 뒤로 보내 자세를 고정해 안정감을 확보하려는 전략이 나타납니다.\n이 과정에서 허리 주변 긴장이 커지고, 관절 움직임을 줄이기 위해 자세를 끝범위 쪽으로 가져가 '조절'보다 '고정'이 우선되는 경향이 있습니다.\n그 결과 하체·골반의 미세한 균형 조절보다, 뒤로 젖힌 자세에 의존해 균형을 유지하는 패턴이 먼저 관찰됩니다.`;
      }
    }

    // ── 항목6: 든 다리 엉덩관절 높이 ────────────────────────────
    // sideLegDiff 정상범위: -11° ~ +6°
    // +6° 초과 → 과도하게 올라감, -11° 미만 → 평행까지 올라오지 않음
    let sideLegObs: string, sideLegPat: string;
    if (sideLegOk) {
      sideLegObs = `${legLabel} 허벅지 라인이 바닥과 평행하게 유지(양호)`;
      sideLegPat = `든 다리의 높이와 자세가 일정하게 유지되어, 균형 조절에 불필요한 보상 움직임이 거의 나타나지 않습니다.\n지지 다리·골반·몸통이 안정적으로 작동해 든 다리가 제자리를 유지하는 조건이 만들어진 상태입니다.\n이 패턴은 든 다리 높이 조절이 전신 협응과 함께 효율적으로 이루어지는 결과로 해석됩니다.`;
    } else if (sideLegDiff > 6) {
      // 문서 정상 상한(+6°) 초과 → over-raised
      sideLegObs = `${legLabel} 다리 높이가 과도하게 올라가는 패턴 관찰`;
      sideLegPat = `든 다리를 과하게 끌어올려 조절보다 '자세 고정'으로 안정감을 얻는 전략이 나타날 수 있습니다.\n조절이 불안정하거나 지지 쪽(${supportLabel} 다리)이 흔들릴 때 몸쪽으로 당겨 불안정 구간을 줄여 버티는 보상으로 나타나기 쉽습니다.\n그 결과 골반·몸통 긴장이 증가해, 부드러운 조절보다 긴장 기반 유지가 두드러질 수 있습니다.`;
    } else {
      // 정상 하한(-11°) 미달 → not raised enough
      sideLegObs = `${legLabel} 허벅지 라인이 바닥과 평행까지 올라오지 않는 패턴 관찰`;
      sideLegPat = `지지 다리(${supportLabel} 다리) 중심이 흔들리거나 든 다리 올림 조절이 초기에 부족하면, 허벅지 높이가 낮게 나타날 수 있습니다.\n이때 몸을 앞으로 굽힘(무게중심 낮추기) 또는 골반 높이 흔들림 같은 보상이 함께 나타나기 쉽습니다.\n그 결과 든 다리는 더 낮아질 수 있으며, 균형 조절이 상체 보상 쪽으로 이동하는 양상이 동반될 가능성이 있습니다.`;
    }

    const normalAssetKey = `BALANCE_${isRight ? 'RIGHT' : 'LEFT'}_SIDE_NORMAL`;
    const currentAssetKey = `BALANCE_${isRight ? 'RIGHT' : 'LEFT'}_SIDE_CURRENT`;
    const sideDiv = isRight ? (filesByDiv['RIGHT'] ?? null) : (filesByDiv['LEFT'] ?? null);

    return {
      title:  `${isRight ? '우' : '좌'}측면 균형패턴`,
      target: `${supportLabel} 지지구간`,
      images: {
        normalImage: { assetKey: normalAssetKey, url: this.resolveBalanceUrl(normalAssetKey) },
        currentImage: { assetKey: currentAssetKey, url: sideDiv ?? null },
      },
      cards: [
        { title: '든 다리 엉덩관절 높이 유지 상태', observationPoint: sideLegObs,   patternAnalysis: sideLegPat },
        { title: '상체 전후 기울기 상태',          observationPoint: headObs,      patternAnalysis: headPat },
      ],
    };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // 일상생활 속 한 다리 균형 패턴 (동적)
  // ──────────────────────────────────────────────────────────────────────────
  private buildBalanceDailyPatterns(sd: any): any {
    const P = 5;
    const hip         = sd?.hip           || {};
    const vertBody    = sd?.verticalBody   || {};
    const horizBody   = sd?.horizontalBody || {};
    const frontLeg    = sd?.frontLeg       || {};
    const head        = sd?.head           || {};
    const sideLeg     = sd?.sideLeg        || {};

    // ── 각 관찰 포인트의 케이스 판별 ──────────────────────────────────────
    // key 형식: `${항목id}_${side}` e.g. 'hip_right', 'hip_left'
    // state: 'ng_over' | 'ng_drop' | 'ok'  (항목에 따라 다름)

    type PatternCase = {
      key: string; title: string; itemTitle: string; image: { assetKey: string; url: null };
      currentPattern: string; correctionGuide: string;
    };

    // ── 항목별 케이스별 텍스트 DB ─────────────────────────────────────────
    const WALKING   = { label: '걷기',               assetKey: 'BALANCE_WALKING' };
    const RUNNING   = { label: '달리기',              assetKey: 'BALANCE_RUNNING' };
    const STAIRS    = { label: '계단 오르내리기',    assetKey: 'BALANCE_STAIRS' };
    const FALLING   = { label: '낙상 상황',           assetKey: 'BALANCE_FALLING' };

    type ActivityContent = { currentPattern: string; correctionGuide: string };
    type ActivityMap = Record<string, ActivityContent>;

    // 항목1: 좌우 골반 높이 (hip)  right=오른쪽 들기/r2, left=왼쪽 들기/r1
    const HIP_R_OVER: ActivityMap  = {
      walking: { currentPattern: "오른발 스윙에서 골반(옆구리)을 먼저 끌어올려 다리를 통째로 들면 발뒤꿈치→발바닥→발가락으로 이어지는 체중 이동이 끊겨 지면을 미는 추진이 약해지고, 발이 끌리거나 '터벅' 소리가 나기 쉽습니다.", correctionGuide: "오른발로 걸을 때 다리를 억지로 끌어올리지 말고, 딛고 있는 발로 바닥을 끝까지 밀어주는 반동을 이용해 다리가 가볍게 앞으로 나아가게 하세요." },
      running: { currentPattern: "오른발이 나갈 때 골반을 위로 과하게 들어 올리면 발이 몸보다 너무 앞에 착지하게 됩니다. 이는 전진하려는 힘을 막는 '브레이크' 역할을 하여 달리기를 더 힘들게 만들고, 충격이 그대로 전달되어 무릎과 정강이의 부상 위험을 높입니다.", correctionGuide: "골반을 수평으로 안정적으로 유지한 채 무릎만 가볍게 들어 올리세요. 발이 몸 바로 아래에 착지하도록 유도하면서, 딛고 있는 발로 지면을 뒤로 밀어내는 추진력을 이용해 효율적으로 나아가야 합니다." },
      stairs: { currentPattern: "계단을 오를 때 옆구리 힘으로 골반을 끌어올리면 하체 근육의 추진력을 쓰지 못하고 상체만 과도하게 쓰게 됩니다. 이는 하체 근력을 약화시키고 허리와 골반 주변 근육에 만성적인 피로와 통증을 유발하는 원인이 됩니다.", correctionGuide: "뒤꿈치를 포함한 발바닥 전체로 계단을 딛고, 엉덩이를 앞으로 밀어주는 힘을 이용해 무릎을 펴면서 올라가세요." },
      falling: { currentPattern: "균형을 잃어 몸이 한쪽으로 급히 꺾이게 되어 대처가 늦어지기 쉽고, 그 과정에서 옆구리·허리 주변 근육에 순간적인 부담이 커질 수 있습니다.", correctionGuide: "짝다리 습관을 줄이고 양발에 체중을 5:5로 분배하는 연습을 통해 중심을 잡는 감각을 기르는 것이 권장됩니다." },
    };
    const HIP_R_DROP: ActivityMap = {
      walking: { currentPattern: "왼발 지지에서 오른쪽 골반이 툭 내려가 중심이 흔들리며, 상체가 반대로 기울거나 다음 발을 급히 내딛어 균형을 맞추려 할 수 있습니다.", correctionGuide: "왼쪽 중간 볼기근을 '켜는' 연습이 우선이므로, 벽에 손을 짚고 왼발 한발서기로 골반을 수평 유지한 뒤 그 감각을 유지한 채 보폭을 줄여 걷는 것이 권장됩니다." },
      running: { currentPattern: "왼발 착지 순간 오른쪽 골반이 떨어져 중심이 좌우로 흔들리며 발이 몸 아래로 일정하게 내려오지 못해 착지 위치가 앞·옆으로 달라지기 쉽고, 이를 보상하려 다음 발을 급하게 내딛어 보폭과 리듬이 불규칙해질 수 있습니다.", correctionGuide: "거울을 보며 골반이 수평으로 유지되는 범위에서만 제자리 뛰기 속도를 점차 높여, 착지마다 골반이 내려가거나 올라가지 않도록 리듬을 안정화하는 것이 권장됩니다." },
      stairs: { currentPattern: "계단을 오르내릴 때 골반이 옆으로 빠져 몸통이 흔들리고, 이를 막기 위해 반대발을 급히 내딛거나 끌어올려 안정시키거나 난간에 더 의지하는 보상 패턴이 나타날 수 있습니다.", correctionGuide: "손잡이 의존을 줄인 상태에서 보폭·속도를 낮추고, 지지하는 발의 뒤꿈치와 엄지발가락으로 바닥을 꾹 눌러 엉덩이 근육을 활성화하고, 골반 수평을 유지하며 한 계단씩 천천히 오르내리세요." },
      falling: { currentPattern: "지지력이 약하면 작은 미끄러짐이나 흔들림에도 골반이 옆으로 쉽게 무너지며 중심을 급히 잡으려는 보상이 커질 수 있고, 이 패턴이 반복되면 엉덩관절 주변에 불편감이 생기거나 움직임 부담이 늘어날 수 있습니다.", correctionGuide: "양치할 때나 설거지할 때 한 다리로 서서 10초간 버티며 엉덩이의 '버티는 힘'을 기르는 것이 권장됩니다." },
    };
    const HIP_R_OK: ActivityMap = {
      walking: { currentPattern: "효율적인 에너지 전달로 장시간 보행 시에도 피로도가 적습니다.", correctionGuide: "현재의 안정성을 유지하며 보폭을 소폭 넓혀 큰볼기근의 개입을 높이는 것이 권장됩니다." },
      running: { currentPattern: "지면 반발력을 효과적으로 사용해 추진력이 좋고 부상 위험이 낮습니다.", correctionGuide: "달리기 전후로 엉덩관절 스트레칭을 병행해 현재의 유연성과 안정성을 유지하는 것이 권장됩니다." },
      stairs: { currentPattern: "중간 볼기근이 골반을 안정적으로 지지하면 큰볼기근도 함께 효율적으로 활성화되어, 계단 오르기가 하체 라인 개선과 체지방 관리 목적의 운동으로 활용되기 좋습니다.", correctionGuide: "허리를 곧게 펴고 상체를 살짝 앞으로 숙여 엉덩이 근육에 더 큰 자극이 느껴지도록 수행하는 것이 권장됩니다." },
      falling: { currentPattern: "신체 회복 탄력성이 좋아 넘어지려 할 때 빠르게 중심을 회복합니다.", correctionGuide: "현재의 컨디션 유지를 위해 전신 스트레칭과 꾸준한 근력 운동 루틴을 지속하는 것이 권장됩니다." },
    };
    const HIP_L_OVER: ActivityMap = {
      walking: { currentPattern: "왼발 스윙에서 골반(옆구리)을 먼저 끌어올려 다리를 통째로 들면 발뒤꿈치→발바닥→발가락으로 이어지는 체중 이동이 끊겨 지면을 미는 추진이 약해지고, 발이 끌리거나 '터벅' 소리가 나기 쉽습니다.", correctionGuide: "왼발로 걸을 때 다리를 억지로 끌어올리지 말고, 딛고 있는 발로 바닥을 끝까지 밀어주는 반동을 이용해 다리가 가볍게 앞으로 나아가게 하세요." },
      running: { currentPattern: "왼발이 나갈 때 골반을 위로 과하게 들어 올리면 발이 몸보다 너무 앞에 착지하게 됩니다. 이는 전진하려는 힘을 막는 '브레이크' 역할을 하여 달리기를 더 힘들게 만들고, 충격이 그대로 전달되어 무릎과 정강이의 부상 위험을 높입니다.", correctionGuide: "골반을 수평으로 안정적으로 유지한 채 무릎만 가볍게 들어 올리세요. 발이 몸 바로 아래에 착지하도록 유도하면서, 딛고 있는 발로 지면을 뒤로 밀어내는 추진력을 이용해 효율적으로 나아가야 합니다." },
      stairs: { currentPattern: "계단을 오를 때 옆구리 힘으로 골반을 끌어올리면 하체 근육의 추진력을 쓰지 못하고 상체만 과도하게 쓰게 됩니다. 이는 하체 근력을 약화시키고 허리와 골반 주변 근육에 만성적인 피로와 통증을 유발하는 원인이 됩니다.", correctionGuide: "뒤꿈치를 포함한 발바닥 전체로 계단을 딛고, 엉덩이를 앞으로 밀어주는 힘을 이용해 무릎을 펴면서 올라가세요." },
      falling: { currentPattern: "균형을 잃어 몸이 한쪽으로 급히 꺾이게 되어 대처가 늦어지기 쉽고, 그 과정에서 옆구리·허리 주변 근육에 순간적인 부담이 커질 수 있습니다.", correctionGuide: "짝다리 습관을 줄이고 양발에 체중을 5:5로 분배하는 연습을 통해 중심을 잡는 감각을 기르는 것이 권장됩니다." },
    };
    const HIP_L_DROP: ActivityMap = {
      walking: { currentPattern: "오른발 지지에서 왼쪽 골반이 툭 내려가 중심이 흔들리며, 상체가 반대로 기울거나 다음 발을 급히 내딛어 균형을 맞추려 할 수 있습니다.", correctionGuide: "오른쪽 중간 볼기근을 '켜는' 연습이 우선이므로, 벽에 손을 짚고 오른발 한발서기로 골반을 수평 유지한 뒤 그 감각을 유지한 채 보폭을 줄여 걷는 것이 권장됩니다." },
      running: { currentPattern: "오른발 착지 순간 왼쪽 골반이 떨어져 중심이 좌우로 흔들리며 발이 몸 아래로 일정하게 내려오지 못해 착지 위치가 앞·옆으로 달라지기 쉽고, 이를 보상하려 다음 발을 급하게 내딛어 보폭과 리듬이 불규칙해질 수 있습니다.", correctionGuide: "거울을 보며 골반이 수평으로 유지되는 범위에서만 제자리 뛰기 속도를 점차 높여, 착지마다 골반이 내려가거나 올라가지 않도록 리듬을 안정화하는 것이 권장됩니다." },
      stairs: { currentPattern: "계단을 오르내릴 때 골반이 옆으로 빠져 몸통이 흔들리고, 이를 막기 위해 반대발을 급히 내딛거나 끌어올려 안정시키거나 난간에 더 의지하는 보상 패턴이 나타날 수 있습니다.", correctionGuide: "손잡이 의존을 줄인 상태에서 보폭·속도를 낮추고, 지지하는 발의 뒤꿈치와 엄지발가락으로 바닥을 꾹 눌러 엉덩이 근육을 활성화하고, 골반 수평을 유지하며 한 계단씩 천천히 오르내리세요." },
      falling: { currentPattern: "지지력이 약하면 작은 미끄러짐이나 흔들림에도 골반이 옆으로 쉽게 무너지며 중심을 급히 잡으려는 보상이 커질 수 있고, 이 패턴이 반복되면 엉덩관절 주변에 불편감이 생기거나 움직임 부담이 늘어날 수 있습니다.", correctionGuide: "양치할 때나 설거지할 때 한 다리로 서서 10초간 버티며 엉덩이의 '버티는 힘'을 기르는 것이 권장됩니다." },
    };
    const HIP_L_OK: ActivityMap = HIP_R_OK;

    // 항목2: 상체 좌우 기울기 (verticalBody)
    const VERT_NG: ActivityMap = {
      walking: { currentPattern: "걸을 때마다 상체가 좌우로 흔들리는 '오뚜기 보행'이 나타납니다. 불필요한 에너지 소모가 크고 허리 옆구리 근육이 쉽게 피로해집니다.", correctionGuide: "정수리에 끈이 달려 위에서 당긴다는 느낌으로 몸을 세우세요. 가방을 한쪽으로만 메는 습관은 불균형을 심화시키니 주의가 필요합니다." },
      running: { currentPattern: "착지 시 신체 중심축을 바로 세우지 못해 척추와 주변 근육에 불필요한 회전 부하를 가하며, 하체 관절로 전달되는 충격 분산 효율을 떨어뜨리는 원인이 됩니다.", correctionGuide: "주행 시 암 스윙(Arm Swing)을 할 때 팔꿈치가 몸통에서 멀어지지 않게 유지하여 상체의 흔들림을 최소화하세요. 상체 정렬을 바로잡는 것만으로도 무릎에 가해지는 역학적 부담을 줄일 수 있으며, 양발에 하중을 5:5로 분배하는 연습을 통해 무너진 중심 감각을 회복하는 것이 권장됩니다." },
      stairs: { currentPattern: "계단을 오를 때 난간에 의지하거나, 상체를 과도하게 숙여 무게 중심을 앞으로 이동시키려는 보상 패턴이 관찰됩니다. 이러한 움직임은 엉덩이 근육의 참여도를 낮추고 하중을 무릎 앞쪽으로 집중시켜, 무릎 주변 조직에 역학적 부담을 가중시키는 원인이 됩니다.", correctionGuide: "계단을 오를 때 상체를 기울이기보다, 지지하는 발 뒤꿈치에 체중을 실어 엉덩이 근육이 몸을 세우게 하세요." },
      falling: { currentPattern: "중심이 이미 한쪽으로 무너져 있어 미끄러지는 순간 반사적인 대처가 불가능합니다. 상체와 하체가 따로 놀아 큰 부상으로 이어집니다.", correctionGuide: "평소 양치할 때나 서 있을 때, 거울을 보며 어깨 수평이 무너지지 않는지 수시로 확인하는 습관이 중요합니다." },
    };
    const VERT_OK: ActivityMap = {
      walking: { currentPattern: "상하좌우 흔들림 없이 직선적인 움직임이 가능합니다. 척추 주변 근육의 긴장도가 낮아 오래 걸어도 목과 어깨가 가볍습니다.", correctionGuide: "현재의 바른 자세를 유지하며, 시선을 멀리 두고 턱을 살짝 당겨 걷는 습관을 지속하세요." },
      running: { currentPattern: "지면을 밀어내는 힘이 상체로 분산되지 않고 추진력으로 전환됩니다. 부상 없이 효율적인 러닝이 가능한 몸 상태입니다.", correctionGuide: "지금의 안정성을 바탕으로 경사도 훈련이나 속도 변화를 주어 심폐 능력을 높이는 단계로 진행하셔도 좋습니다." },
      stairs: { currentPattern: "엉덩관절과 척추가 중립을 유지하여 엉덩이 근육을 효과적으로 사용합니다. 계단 운동이 '관절 소모'가 아닌 '근육 강화'가 됩니다.", correctionGuide: "하산 시나 계단을 내려올 때 발소리가 나지 않게 사뿐히 내려오는 연습으로 조절 능력을 더 정교하게 다듬어보세요." },
      falling: { currentPattern: "신체 무게 중심이 항상 중앙에 위치하여 미끄러운 상황에서도 상체가 빠르게 반응해 중심을 회복합니다.", correctionGuide: "현재의 우수한 밸런스를 유지하기 위해 주 1~2회 고유수용성 감각 훈련(눈 감고 서기 등)을 병행해 보세요." },
    };

    // 항목3: 지지 다리 정렬 (horizontalBody)  right=오른쪽 들기/leftOk(왼발 지지), left=왼쪽 들기/rightOk(오른발 지지)
    const HORIZ_VALGUS: ActivityMap = {
      walking: { currentPattern: "발이 지면에 닿을 때 지지하는 무릎이 안쪽으로 모이는 정렬 특성이 관찰됩니다. 이로 인해 발 안쪽에 하중이 집중되면서 아치가 낮아지고, 무릎 관절 내측에 불필요한 스트레스가 누적될 수 있는 움직임 환경입니다.", correctionGuide: "걸을 때 무릎 중앙이 두 번째 발가락과 수직 선상에 놓이도록 정렬을 인지하는 연습이 필요합니다. 신발 안쪽 바닥의 마모가 심하다면, 발바닥 전체의 고른 지지력을 회복하는 기능 훈련이 권장됩니다." },
      running: { currentPattern: "착지 시 발생하는 충격을 무릎이 정면에서 안정적으로 분산하지 못하고 안쪽으로 뒤틀리며 흡수하는 패턴이 나타납니다. 이는 무릎 주변 조직에 가해지는 역학적 부담을 높여 장기적으로 보행 효율성을 떨어뜨리는 원인이 됩니다.", correctionGuide: "지면을 딛는 순간 무릎이 정면을 향하도록 엉덩이 근육(중간볼기근)의 긴장도를 유지하세요. 발바닥 전체로 지면을 밀어내는 힘을 활용하여 하체의 안정적인 수직 축을 유지하며 달리는 것이 효과적입니다." },
      stairs: { currentPattern: "계단을 오를 때 무릎이 안으로 모이며 엉덩관절의 조절 능력 대신 무릎 관절에 의존하여 몸을 밀어 올리는 현상이 확인됩니다. 이러한 보상 패턴은 특정 근육의 과사용을 유발하고 전체적인 하체 기능의 불균형을 심화시킬 수 있습니다.", correctionGuide: "계단을 디딜 때 무릎을 의식적으로 살짝 바깥쪽으로 벌리는 정렬을 유지하며, 엉덩이 근육에 힘이 실리는 것을 느끼면서 발바닥 전체로 지면을 누르며 이동하십시오." },
      falling: { currentPattern: "갑자기 멈추거나 방향을 틀 때 무릎이 안으로 깊게 꺾이며 체중을 지지하는 동적 안정성이 저하된 상태입니다. 이는 하체 정렬의 통제력을 잃기 쉬운 패턴으로, 일상 속 돌발 상황에서 부상 노출 위험을 높이는 요소가 됩니다.", correctionGuide: "엉덩관절의 외부 조절 능력을 기르기 위해 무릎 바깥쪽에 저항 밴드를 활용한 정렬 유지 훈련을 병행하세요. 어떤 상황에서도 무릎이 모이지 않도록 스스로 조절하는 '정렬 인지 능력'을 강화하는 것이 핵심입니다." },
    };
    const HORIZ_VARUS: ActivityMap = {
      walking: { currentPattern: "보행 시 체중이 발바닥 바깥쪽에 집중되며 다리가 바깥으로 휘어지는 움직임 특성이 나타납니다.", correctionGuide: "발바닥 엄지발가락 뿌리 부분을 지면에 명확히 밀착시켜 하중을 발 전체로 고르게 분산하는 정렬 인지 학습이 권장됩니다." },
      running: { currentPattern: "지면 접촉 시 하중이 무릎 바깥쪽으로 쏠리며 허벅지 바깥쪽 조직의 역학적 긴장도를 높일 수 있는 환경이 확인됩니다.", correctionGuide: "주행 시 양발 사이의 간격을 적절히 조절하여 하체의 수직 정렬을 유지하고, 엉덩이 근육의 조절력을 활용해 무릎 방향을 통제하며 달리세요." },
      stairs: { currentPattern: "계단을 내려갈 때 하중이 무릎 외측으로 쏠려 무릎 주변 근육의 긴장도가 비정상적으로 높아집니다.", correctionGuide: "발을 내디딜 때 발가락 전체가 정면을 향하게 하고, 허벅지 안쪽 근육(모음근)에 살짝 힘을 주고 내려오세요." },
      falling: { currentPattern: "체중 지지축이 바깥으로 편향되어 있어 급격한 방향 전환이나 중심 상실 시 신체의 동적 안정성을 유지하기 어려운 상태입니다.", correctionGuide: "한 다리로 서서 중심을 잡을 때 무릎이 신체 중심축에서 벗어나지 않도록 일직선을 유지하는 '인지 트레이닝'을 반복하여 하체의 통제력을 강화하는 것이 효과적입니다." },
    };
    const HORIZ_OK: ActivityMap = {
      walking: { currentPattern: "관절의 특정 부위에 치우침 없이 체중이 고르게 분산되어 보행 정렬이 매우 안정적입니다.", correctionGuide: "현재의 안정적인 정렬을 유지하면서, 뒤꿈치부터 발가락 끝까지 사용하는 '롤링 보행'을 통해 하체 근육의 활성도를 더욱 높여보세요." },
      running: { currentPattern: "하체의 정렬이 바르게 유지되어 충격 흡수 효율이 높으며, 관절에 가해지는 역학적 부담이 적은 효율적인 패턴입니다.", correctionGuide: "현재 상태를 기반으로 주행 속도를 높이거나 지면의 변화가 있는 환경(트레일 러닝 등)에서 훈련하여 하체의 협응력을 더 키워보시는 것을 추천합니다." },
      stairs: { currentPattern: "엉덩이, 허벅지, 종아리 근육이 조화롭게 사용되어 무릎 관절을 견고하게 보호하며 이동하는 모습이 관찰됩니다.", correctionGuide: "계단을 내려올 때 앞꿈치부터 부드럽게 닿는 동작을 통해 하체의 '완충 능력'을 더 정교하게 다듬어보세요." },
      falling: { currentPattern: "신체의 하중 지지 축이 중앙에 있어 갑작스러운 균형 상실에도 하체가 단단히 버텨주며 부상 예방 능력이 우수한 상태입니다.", correctionGuide: "안정적인 정렬을 유지하면서 점프 후 착지 훈련(플라이오메트릭) 등을 병행하여 하체의 폭발적인 파워와 조절 능력을 보강해 보세요." },
    };

    // 항목4: 든 다리 무릎-발목 수직 정렬 (frontLeg)
    const FRONT_LEG_R_NG: ActivityMap = {
      walking: { currentPattern: "발을 내디딜 때 발끝이 안이나 밖으로 돌아가며 지면을 불안정하게 접촉합니다. 발목을 자주 삐끗하거나 종아리가 쉽게 붓습니다.", correctionGuide: "걸을 때 무릎이 정면을 향해 수직으로 나가는지 확인하세요. 계단이나 장애물을 넘을 때 평소보다 무릎을 조금 더 높이 드는 의식적 노력이 필요합니다." },
      running: { currentPattern: "다리가 공중에 떠 있는 동안 정렬이 무너져, 착지 시 발바닥 전체가 아닌 특정 부위(바깥날 등)로 강하게 충격이 전달됩니다.", correctionGuide: "발이 지면에 닿기 직전, 발등을 몸쪽으로 살짝 당겨 발목의 긴장감을 유지하는 '프리-액티베이션' 습관을 들이세요." },
      stairs: { currentPattern: "다음 칸을 디딜 때 오른쪽 발의 위치가 불안정하여 무릎이 좌우로 흔들리는 현상이 나타납니다. 이는 무릎 연골에 가해지는 압박력을 불균형하게 만드는 원인이 됩니다.", correctionGuide: "다음 계단을 디디기 전, 공중에 있는 다리의 엄지발가락 방향이 정면을 향하고 있는지 눈으로 확인하며 천천히 오르세요." },
      falling: { currentPattern: "발을 헛디뎠을 때 공중에서 다리 정렬을 바로잡지 못해, 발목이 꺾인 상태 그대로 체중을 실어버려 큰 부상으로 이어집니다.", correctionGuide: "의자에 앉아 한 다리를 들고 무릎과 발목을 일직선으로 유지하는 연습을 수시로 하여 '다리 조절 능력'을 키워야 합니다." },
    };
    const FRONT_LEG_L_NG: ActivityMap = {
      walking: { currentPattern: "발을 내디딜 때 발끝이 안이나 밖으로 돌아가며 지면을 불안정하게 접촉합니다. 발목을 자주 삐끗하거나 종아리가 쉽게 붓습니다.", correctionGuide: "걸을 때 무릎이 정면을 향해 수직으로 나가는지 확인하세요. 계단이나 장애물을 넘을 때 평소보다 무릎을 조금 더 높이 드는 의식적 노력이 필요합니다." },
      running: { currentPattern: "다리가 공중에 떠 있는 동안 정렬이 무너져, 착지 시 발바닥 전체가 아닌 특정 부위(바깥날 등)로 강하게 충격이 전달됩니다.", correctionGuide: "발이 지면에 닿기 직전, 발등을 몸쪽으로 살짝 당겨 발목의 긴장감을 유지하는 '프리-액티베이션' 습관을 들이세요." },
      stairs: { currentPattern: "다음 칸을 디딜 때 왼쪽 발의 위치가 불안정하여 무릎이 좌우로 흔들리는 현상이 나타납니다. 이는 무릎 연골에 가해지는 압박력을 불균형하게 만드는 원인이 됩니다.", correctionGuide: "다음 계단을 디디기 전, 공중에 있는 다리의 엄지발가락 방향이 정면을 향하고 있는지 눈으로 확인하며 천천히 오르세요." },
      falling: { currentPattern: "발을 헛디뎠을 때 공중에서 다리 정렬을 바로잡지 못해, 발목이 꺾인 상태 그대로 체중을 실어버려 큰 부상으로 이어집니다.", correctionGuide: "의자에 앉아 한 다리를 들고 무릎과 발목을 일직선으로 유지하는 연습을 수시로 하여 '다리 조절 능력'을 키워야 합니다." },
    };
    const FRONT_LEG_OK: ActivityMap = {
      walking: { currentPattern: "발을 내디딜 때 무릎과 발목이 수직 정렬을 유지하여 충격을 골고루 분산합니다. 장시간 보행에도 무릎과 허리의 피로도가 낮습니다.", correctionGuide: "현재의 안정성을 유지하며 보폭을 10~15% 넓혀보세요. 큰볼기근(엉덩이)의 개입을 극대화하여 걷기만으로도 힙업 효과를 볼 수 있습니다." },
      running: { currentPattern: "다리가 공중에 떠 있는 동안에도 정렬이 흐트러지지 않아 착지 시 지면 반발력을 추진력으로 100% 전환합니다. 무릎 부상 위험이 현저히 낮습니다.", correctionGuide: "평지뿐만 아니라 불규칙한 지면(트레일 러닝 등)에서도 이 정렬을 유지하는 연습을 통해 고유수용성 감각을 더 날카롭게 다듬으세요." },
      stairs: { currentPattern: "상체의 흔들림 없이 엉덩이와 허벅지의 협응만으로 수직 이동이 가능합니다. 계단 운동이 관절 소모가 아닌 하체 근력 강화의 기회가 됩니다.", correctionGuide: "발소리를 줄이고, 사뿐히 딛는 '충격 흡수 컨트롤'은 근육이 늘어나며 힘을 쓰는 '신장성 조절 능력'을 강화하여, 관절의 부담은 덜고 하체 탄력은 더해줍니다." },
      falling: { currentPattern: "신체의 무게 중심이 항상 중앙에 고정되어 있어, 돌발 상황에서도 공중에서 발의 위치를 빠르게 수정하여 안전하게 착지할 수 있습니다.", correctionGuide: "눈을 감고 한 다리로 서기, 혹은 불안정한 지면(보수 볼 등)에서의 훈련을 통해 어떤 위기에서도 몸을 지키는 '반사 신경'을 업그레이드하세요." },
    };

    // 항목5: 상체 전후 기울기 (head)  right=오른쪽 들기(right측면)/rightOk, left=왼쪽 들기(left측면)/leftOk
    const HEAD_FORWARD: ActivityMap = {
      walking: { currentPattern: "몸이 앞으로 고꾸라지듯 걷게 되어 종아리와 발바닥 앞쪽에 과도한 긴장이 생깁니다.", correctionGuide: "정수리를 위로 당기며 가슴을 펴고, 뒤꿈치부터 지면에 닿는 느낌을 의식하세요." },
      running: { currentPattern: "상체가 앞으로 숙여지며 무릎이 발끝보다 과하게 튀어나가게 되고, 이로 인해 무릎 앞쪽 조직에 반복적인 충격이 가해지는 환경입니다.", correctionGuide: "시선을 멀리 두고 골반을 앞으로 밀어낸다는 느낌으로 몸의 수직 축을 세우세요." },
      stairs: { currentPattern: "오를 때 상체를 과하게 숙여 허리 근육으로 몸을 끌어올리며, 세움근의 과부하를 유발합니다.", correctionGuide: "상체를 세우고 발뒤꿈치로 계단을 꾹 눌러 엉덩이 근육이 일하게 만드세요." },
      falling: { currentPattern: "중심이 앞에 있어 미끄러질 때 얼굴이나 상체 전면이 바닥에 부딪히는 위험한 상황이 발생합니다.", correctionGuide: "평소 복압을 유지하는 '코어 브레이싱' 훈련을 통해 상체의 앞뒤 중심을 잡아야 합니다." },
    };
    const HEAD_BACKWARD: ActivityMap = {
      walking: { currentPattern: "다리를 앞으로 내디딜 때 상체가 뒤로 젖혀지며, 골반이 앞으로 밀려 나가는 '스웨이백(Sway-back)' 스타일의 보행 특성이 관찰됩니다.", correctionGuide: "가슴을 정면으로 바르게 세우고, 골반이 발보다 먼저 나가지 않도록 복부 주변의 가벼운 긴장감을 유지하며 걸어보세요." },
      running: { currentPattern: "상체의 무게 중심이 뒤에 머물러 있어 추진력이 떨어지며, 발바닥이 지면을 긁듯이 착지하여 발목과 무릎에 전달되는 저항이 커지는 환경입니다.", correctionGuide: "시선을 약간 아래가 아닌 정면 멀리 두고, 몸 전체가 앞으로 5도 정도 아주 살짝 기울어진다는 느낌으로 주행하여 전진 동력을 확보하세요." },
      stairs: { currentPattern: "계단을 오를 때 상체를 뒤로 젖히며 반동을 이용하려는 모습이 보입니다. 이는 엉덩이 근육이 체중을 온전히 밀어 올리지 못하고 있음을 시사합니다.", correctionGuide: "계단을 딛는 발의 뒤꿈치에 힘을 집중하고, 상체가 뒤로 눕지 않게 명치 부근을 살짝 앞으로 당겨 하체 힘만으로 몸을 세우는 연습을 하세요." },
      falling: { currentPattern: "무게 중심이 뒤에 쏠려 있어 뒤로 넘어질 때 머리나 척추가 바닥에 직접 닿을 위험이 높은 상태입니다.", correctionGuide: "턱을 가슴 쪽으로 당기고 복근의 힘을 키우는 훈련을 통해, 어떤 방향에서도 신체 중심을 수직으로 유지하는 능력을 보강해야 합니다." },
    };
    const HEAD_OK: ActivityMap = {
      walking: { currentPattern: "보행 시 상체가 앞뒤나 좌우로 흔들리지 않고 신체의 무게 중심이 수직 선상에 안정적으로 머물러 있습니다.", correctionGuide: "현재의 안정적인 정렬을 유지하며 보폭을 10~15% 정도 넓혀보세요. 엉덩이 근육의 개입을 극대화하여 걷기만으로도 탄력 있는 하체 라인을 만드는 효과를 볼 수 있습니다." },
      running: { currentPattern: "주행 중에도 척추의 중립 정렬이 흐트러지지 않아, 지면에서 올라오는 반발력을 전진 추진력으로 100% 전환하는 효율적인 패턴입니다.", correctionGuide: "평지뿐만 아니라 불규칙한 지면(트레일 러닝 등)에서도 이 정렬을 유지하는 연습을 통해, 몸의 세밀한 균형을 잡는 '고유수용성 감각'을 더 날카롭게 다듬어보세요." },
      stairs: { currentPattern: "상체의 불필요한 보상 작용 없이 하체 근육의 협응만으로 수직 이동이 가능합니다. 이는 관절 소모를 최소화하는 아주 이상적인 움직임입니다.", correctionGuide: "내디딜 때 발소리가 나지 않게 사뿐히 걷는 '충격 흡수 컨트롤'에 더 집중해 보세요. 하체 근육의 브레이크 능력(신장성 조절)이 더욱 강화되어 무릎을 더 견고하게 보호해 줍니다." },
      falling: { currentPattern: "신체의 무게 중심이 항상 중앙에 고정되어 있어, 갑작스러운 흔들림에도 즉각적으로 자세를 바로잡는 동적 안정성이 우수합니다.", correctionGuide: "눈을 감고 한 다리로 서기나 보수 볼(Bosu ball) 위에서의 훈련을 통해, 어떤 위기 상황에서도 몸을 지키는 '반사 신경'을 업그레이드해 보십시오." },
    };

    // 항목6: 든 다리 엉덩관절 높이 (sideLeg)
    const SIDE_LEG_LOW: ActivityMap = {
      walking: { currentPattern: "다리를 들어 올리는 힘이 충분하지 않아 보폭이 좁아지고, 발끝이 지면에 걸리는 등 보행의 효율성이 떨어지는 패턴이 관찰됩니다.", correctionGuide: "평소보다 무릎을 5~10cm 정도 더 높이 들어 올린다는 느낌으로 걸어보세요. 하체 전면 근육의 참여도를 높여 보행 리듬을 경쾌하게 바꿀 수 있습니다." },
      running: { currentPattern: "무릎이 충분히 올라오지 않아 추진력을 얻기 어렵고, 지면 반발력을 온전히 활용하지 못해 다리가 무겁게 느껴질 수 있는 환경입니다.", correctionGuide: "제자리에서 무릎을 가슴 높이까지 올리는 '니 업(Knee-up)' 동작을 선행하여, 주행 시 필요한 하체의 동력을 미리 활성화하십시오." },
      stairs: { currentPattern: "다음 계단을 딛기 위해 다리를 충분히 들지 못해 발끝이 계단 모서리에 부딪히거나, 골반을 억지로 틀어 올리려는 보상 작용이 확인됩니다.", correctionGuide: "계단을 딛기 전 무릎을 수직으로 충분히 들어 올리는 동작에 집중하세요. 이는 엉덩이 깊은 곳의 근육(엉덩허리근 등)을 깨워 관절의 부담을 덜어줍니다." },
      falling: { currentPattern: "낮은 턱이나 장애물에 발이 걸렸을 때 즉각적으로 다리를 들어 대처하는 능력이 저하되어 있어, 전방으로 넘어질 위험이 높은 상태입니다.", correctionGuide: "의자에 앉아 한 다리를 바닥과 평행하게 들고 5초간 버티는 연습을 통해, 다리를 조절하는 기초 근력을 보강하는 것이 필수적입니다." },
    };
    const SIDE_LEG_HIGH: ActivityMap = {
      walking: { currentPattern: "다리를 내디딜 때 무릎이 필요 이상으로 높게 들리며 보행 리듬이 불규칙해지고, 착지 시 발바닥에 가해지는 충격이 커지는 패턴이 관찰됩니다.", correctionGuide: "무릎을 높이 들기보다 발을 앞으로 부드럽게 밀어낸다는 느낌으로 보행 리듬을 조절하여 하체의 에너지 소모를 줄여보세요." },
      running: { currentPattern: "과도한 니 업(Knee-up) 동작으로 인해 무게 중심이 위아래로 크게 흔들리며, 수평 추진력보다는 수직 저항에 더 많은 에너지를 쓰게 되는 환경입니다.", correctionGuide: "시선을 정면 멀리 두고, 무릎의 높이를 골반 라인 이하로 통제하며 지면을 뒤로 밀어내는 추진력에 집중하는 연습이 권장됩니다." },
      stairs: { currentPattern: "다음 칸을 딛을 때 다리를 과하게 들어 올리느라 지지하고 있는 반대쪽 골반이 뒤로 빠지거나 상체가 뒤로 눕는 보상 작용이 확인됩니다.", correctionGuide: "계단 높이에 딱 맞는 최소한의 가동 범위만 사용하도록 조절하고, 다리를 높이는 힘 대신 지지하는 발의 엉덩이 근육으로 몸을 밀어 올리는 데 집중하세요." },
      falling: { currentPattern: "다리를 높게 들수록 신체의 무게 중심이 높아져, 정지 상태에서 균형을 유지하기가 오히려 더 까다로워진 상태입니다.", correctionGuide: "다리를 바닥과 평행한 높이(90도)까지만 정확히 들어 올리고, 그 지점에서 흔들림 없이 5초 이상 버티는 '정교한 통제 훈련'이 필수적입니다." },
    };
    const SIDE_LEG_OK: ActivityMap = {
      walking: { currentPattern: "다리를 들어 올리는 높이가 적절하여 보행 시 지면과의 간격이 충분히 확보되며, 리드미컬하고 경쾌한 걸음걸이가 나타납니다.", correctionGuide: "현재의 안정적인 높이를 유지하며 보폭을 10~15% 넓혀보세요. 큰볼기근의 참여를 극대화하여 걷기만으로도 힙업 효과를 볼 수 있습니다." },
      running: { currentPattern: "다리가 공중에 떠 있는 동안에도 정렬이 흐트러지지 않아, 착지 시 지면 반발력을 전진 추진력으로 100% 전환하는 효율적인 상태입니다.", correctionGuide: "평지 외에도 경사도 변화가 있는 지면에서 훈련하여, 뛰어난 안정성을 바탕으로 하체의 폭발적인 파워를 끌어올리는 단계로 진입하세요." },
      stairs: { currentPattern: "상체의 흔들림 없이 엉덩이와 허벅지의 협응만으로 수직 이동이 가능합니다. 계단 운동이 관절 소모가 아닌 하체 근력 강화의 기회가 되는 아주 긍정적인 단계입니다.", correctionGuide: "계단을 디딜 때 뒤꿈치에 체중을 정확히 실어 엉덩이 근육이 몸을 수직으로 밀어 올리는 '힙 파워'에 집중해 보세요. 하체 전반의 에너지 소모를 높여 운동 효과를 극대화하고 무릎의 부담은 줄여줍니다." },
      falling: { currentPattern: "신체의 무게 중심이 항상 중앙에 안정적으로 고정되어 있어, 돌발 상황에서도 공중에서 발의 위치를 빠르게 수정하여 안전하게 착지할 수 있는 상태입니다.", correctionGuide: "눈을 감고 한 다리로 서기, 혹은 불안정한 지면(보수 볼 등)에서의 훈련을 통해 어떤 위기에서도 몸을 지키는 '반사 신경'을 업그레이드하세요." },
    };

    // ── horizontalBody ng 방향 판별 헬퍼 ──────────────────────────────────
    const resolveHorizDailyState = (status: string | undefined, isOk: boolean) => {
      if (isOk || status === '바른정렬') return 'ok';
      if (status === '오다리') return 'varus';
      return 'valgus';
    };
    const horizRState = resolveHorizDailyState(horizBody.leftStatus, horizBody.leftOk);
    const horizLState = resolveHorizDailyState(horizBody.rightStatus, horizBody.rightOk);

    // head forward/backward 판별
    // 문서 부호 규약: 음수 = 뒤로 기울어짐. 정상 범위 −4°~−17°
    // diff > -4  → forward(앞으로 기울어짐)
    // diff < -17 → backward(뒤로 과도하게 젖혀짐)
    const headRState = !head.rightOk
      ? ((head.rightAngle ?? 0) > -4 ? 'forward' : 'backward')
      : 'ok';
    const headLState = !head.leftOk
      ? ((head.leftAngle ?? 0) > -4 ? 'forward' : 'backward')
      : 'ok';

    // sideLeg low/high 판별
    // 문서 정상범위: -11° ≤ diff ≤ +6°
    // +6° 초과 = 과도하게 올림(high), -11° 미만 = 못 올림(low)
    const sideLegRState = !sideLeg.rightOk
      ? ((sideLeg.rightAngle ?? 0) > 6 ? 'high' : 'low')
      : 'ok';
    const sideLegLState = !sideLeg.leftOk
      ? ((sideLeg.leftAngle ?? 0) > 6 ? 'high' : 'low')
      : 'ok';

    // hip over/drop 판별 (표시 각도 절삭 기준)
    // rightAngle = Rt hip 대비 Lt hip 각도 (든 쪽 hip이 위일수록 양수)
    // 정상 범위 2~10° → 11° 이상 = over(과도하게 높음), 2° 미만 = drop(아래로 내려감)
    const hipRightJudgeAngle = Math.trunc(hip.rightAngle ?? 0);
    const hipLeftJudgeAngle = Math.trunc(hip.leftAngle ?? 0);
    const hipRNormal = hipRightJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MIN_DEG
      && hipRightJudgeAngle <= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MAX_DEG;
    const hipLNormal = hipLeftJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MIN_DEG
      && hipLeftJudgeAngle <= BALANCE_ALIGNMENT.FRONT_HIP_NORMAL_MAX_DEG;
    const hipRState = hipRNormal
      ? 'ok'
      : (hipRightJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_OVER_MIN_DEG ? 'over' : 'drop');
    // leftAngle = Lt hip 대비 Rt hip 각도 (왼발 든 구간)
    const hipLState = hipLNormal
      ? 'ok'
      : (hipLeftJudgeAngle >= BALANCE_ALIGNMENT.FRONT_HIP_OVER_MIN_DEG ? 'over' : 'drop');

    // ── 후보 카드 목록 구성 ──────────────────────────────────────────────
    type Candidate = {
      itemKey: string; side: 'right' | 'left'; isNg: boolean;
      titleLabel: string; observationPoint: string;
      activities: ActivityMap; assetKey: string;
    };

    const getHorizMap = (state: string) =>
      state === 'valgus' ? HORIZ_VALGUS : state === 'varus' ? HORIZ_VARUS : HORIZ_OK;
    const getHeadMap = (state: string) =>
      state === 'forward' ? HEAD_FORWARD : state === 'backward' ? HEAD_BACKWARD : HEAD_OK;
    const getSideLegMap = (state: string) =>
      state === 'high' ? SIDE_LEG_HIGH : state === 'low' ? SIDE_LEG_LOW : SIDE_LEG_OK;
    const getHipMap = (state: string) =>
      state === 'over' ? HIP_R_OVER : state === 'drop' ? HIP_R_DROP : HIP_R_OK;
    const getHipLMap = (state: string) =>
      state === 'over' ? HIP_L_OVER : state === 'drop' ? HIP_L_DROP : HIP_L_OK;
    const getHipObs = (state: string, side: 'right' | 'left') => {
      if (side === 'right') {
        if (state === 'over') return '오른쪽 골반이 과도하게 올라가는 패턴 관찰';
        if (state === 'drop') return '오른쪽 골반이 아래로 내려가는 패턴 관찰';
        return '좌우 골반 높이 큰 차이 없이 유지(양호)';
      } else {
        if (state === 'over') return '왼쪽 골반이 과도하게 올라가는 패턴 관찰';
        if (state === 'drop') return '왼쪽 골반이 아래로 내려가는 패턴 관찰';
        return '좌우 골반 높이 큰 차이 없이 유지(양호)';
      }
    };

    const candidates: Candidate[] = [
      // 항목1: hip right
      { itemKey: 'hip', side: 'right', isNg: hipRState !== 'ok',
        titleLabel: '좌우 골반 높이 대칭 상태',
        observationPoint: getHipObs(hipRState, 'right'),
        activities: getHipMap(hipRState), assetKey: 'BALANCE_WALKING' },
      // 항목1: hip left
      { itemKey: 'hip', side: 'left', isNg: hipLState !== 'ok',
        titleLabel: '좌우 골반 높이 대칭 상태',
        observationPoint: getHipObs(hipLState, 'left'),
        activities: getHipLMap(hipLState), assetKey: 'BALANCE_WALKING' },
      // 항목2: verticalBody right
      { itemKey: 'vertBody', side: 'right', isNg: !vertBody.rightOk,
        titleLabel: '상체 좌우 기울기 상태',
        observationPoint: vertBody.rightOk ? '상체가 바로 서서 안정적으로 유지(양호)' : '상체가 좌우로 기울어지는 패턴 관찰',
        activities: vertBody.rightOk ? VERT_OK : VERT_NG, assetKey: 'BALANCE_RUNNING' },
      // 항목2: verticalBody left
      { itemKey: 'vertBody', side: 'left', isNg: !vertBody.leftOk,
        titleLabel: '상체 좌우 기울기 상태',
        observationPoint: vertBody.leftOk ? '상체가 바로 서서 안정적으로 유지(양호)' : '상체가 좌우로 기울어지는 패턴 관찰',
        activities: vertBody.leftOk ? VERT_OK : VERT_NG, assetKey: 'BALANCE_RUNNING' },
      // 항목3: horizontalBody right (왼발 지지)
      { itemKey: 'horizBody', side: 'right', isNg: horizRState !== 'ok',
        titleLabel: '지지 다리 정렬 상태',
        observationPoint: horizRState === 'ok' ? '지지하는 왼쪽 다리가 곧게 유지(양호)' : horizRState === 'valgus' ? '지지하는 왼쪽 무릎이 안쪽으로 무너지는 패턴 관찰(valgus)' : '지지하는 왼쪽 무릎이 바깥으로 벌어지는 패턴 관찰(varus)',
        activities: getHorizMap(horizRState), assetKey: 'BALANCE_STAIRS' },
      // 항목3: horizontalBody left (오른발 지지)
      { itemKey: 'horizBody', side: 'left', isNg: horizLState !== 'ok',
        titleLabel: '지지 다리 정렬 상태',
        observationPoint: horizLState === 'ok' ? '지지하는 오른쪽 다리가 곧게 유지(양호)' : horizLState === 'valgus' ? '지지하는 오른쪽 무릎이 안쪽으로 무너지는 패턴 관찰(valgus)' : '지지하는 오른쪽 무릎이 바깥으로 벌어지는 패턴 관찰(varus)',
        activities: getHorizMap(horizLState), assetKey: 'BALANCE_STAIRS' },
      // 항목4: frontLeg right
      { itemKey: 'frontLeg', side: 'right', isNg: !frontLeg.rightOk,
        titleLabel: '든 다리 무릎–발목 수직 정렬 상태',
        observationPoint: frontLeg.rightOk ? '무릎–발목 정렬이 곧게 유지(양호)' : '오른쪽 발목이 무릎 기준 바깥 또는 안쪽으로 벗어나는 패턴 관찰',
        activities: frontLeg.rightOk ? FRONT_LEG_OK : FRONT_LEG_R_NG, assetKey: 'BALANCE_FALLING' },
      // 항목4: frontLeg left
      { itemKey: 'frontLeg', side: 'left', isNg: !frontLeg.leftOk,
        titleLabel: '든 다리 무릎–발목 수직 정렬 상태',
        observationPoint: frontLeg.leftOk ? '무릎–발목 정렬이 곧게 유지(양호)' : '왼쪽 발목이 무릎 기준 바깥 또는 안쪽으로 벗어나는 패턴 관찰',
        activities: frontLeg.leftOk ? FRONT_LEG_OK : FRONT_LEG_L_NG, assetKey: 'BALANCE_FALLING' },
      // 항목5: head right
      { itemKey: 'head', side: 'right', isNg: headRState !== 'ok',
        titleLabel: '상체 전후 기울기 상태',
        observationPoint: headRState === 'ok' ? '상체가 곧게 서서 유지(양호)' : headRState === 'forward' ? '상체가 앞으로 기울어지는 패턴 관찰' : '상체가 뒤로 기울어지는 패턴 관찰',
        activities: getHeadMap(headRState), assetKey: 'BALANCE_FALLING' },
      // 항목5: head left
      { itemKey: 'head', side: 'left', isNg: headLState !== 'ok',
        titleLabel: '상체 전후 기울기 상태',
        observationPoint: headLState === 'ok' ? '상체가 곧게 서서 유지(양호)' : headLState === 'forward' ? '상체가 앞으로 기울어지는 패턴 관찰' : '상체가 뒤로 기울어지는 패턴 관찰',
        activities: getHeadMap(headLState), assetKey: 'BALANCE_FALLING' },
      // 항목6: sideLeg right
      { itemKey: 'sideLeg', side: 'right', isNg: sideLegRState !== 'ok',
        titleLabel: '든 다리 엉덩관절 높이 유지 상태',
        observationPoint: sideLegRState === 'ok' ? '오른쪽 허벅지 라인이 바닥과 평행하게 유지(양호)' : sideLegRState === 'high' ? '오른쪽 다리 높이가 과도하게 올라가는 패턴 관찰' : '오른쪽 허벅지 라인이 바닥과 평행까지 올라오지 않는 패턴 관찰',
        activities: getSideLegMap(sideLegRState), assetKey: 'BALANCE_WALKING' },
      // 항목6: sideLeg left
      { itemKey: 'sideLeg', side: 'left', isNg: sideLegLState !== 'ok',
        titleLabel: '든 다리 엉덩관절 높이 유지 상태',
        observationPoint: sideLegLState === 'ok' ? '왼쪽 허벅지 라인이 바닥과 평행하게 유지(양호)' : sideLegLState === 'high' ? '왼쪽 다리 높이가 과도하게 올라가는 패턴 관찰' : '왼쪽 허벅지 라인이 바닥과 평행까지 올라오지 않는 패턴 관찰',
        activities: getSideLegMap(sideLegLState), assetKey: 'BALANCE_WALKING' },
    ];

    // ── 활동 목록 (각 패턴에 매핑되는 4개 상황) ────────────────────────────
    const ACT_CONTENT = [
      { actKey: 'walking', activity: '걷기',            assetKey: 'BALANCE_WALKING' },
      { actKey: 'running', activity: '달리기',           assetKey: 'BALANCE_RUNNING' },
      { actKey: 'stairs',  activity: '계단 오르내리기', assetKey: 'BALANCE_STAIRS'  },
      { actKey: 'falling', activity: '낙상 상황',        assetKey: 'BALANCE_FALLING' },
    ];

    // ── 2개 선발 로직 (문서 규약: 항상 패턴 2개, 동일 관찰포인트 좌·우 동시 금지) ──
    // 선발 단위 = 패턴(candidate), 각 패턴에 4개 활동 상황 모두 포함
    const shuffleFn = (arr: Candidate[]): Candidate[] => [...arr].sort(() => Math.random() - 0.5);

    const pickTwoCandidates = (pool: Candidate[]): Candidate[] => {
      const shuffled = shuffleFn(pool);
      const result: Candidate[] = [];
      for (const c of shuffled) {
        if (result.length >= 2) break;
        // 동일 itemKey(관찰포인트) 좌·우 동시 선택 금지
        if (!result.some(p => p.itemKey === c.itemKey)) {
          result.push(c);
        }
      }
      return result;
    };

    const ngCandidates = candidates.filter(c => c.isNg);
    const okCandidates = candidates.filter(c => !c.isNg);

    let selectedCandidates: Candidate[];
    if (ngCandidates.length >= 2) {
      // 비정상 2개 이상 → NG 후보 중 랜덤 2개 (동일 항목 좌·우 제외)
      selectedCandidates = pickTwoCandidates(ngCandidates);
    } else if (ngCandidates.length === 1) {
      // 비정상 1개 → NG 1개 + 동일 항목 제외한 OK 중 랜덤 1개
      const filteredOk = okCandidates.filter(c => c.itemKey !== ngCandidates[0].itemKey);
      const okPick = shuffleFn(filteredOk)[0] ?? null;
      selectedCandidates = okPick ? [ngCandidates[0], okPick] : [ngCandidates[0]];
    } else {
      // 전부 정상 → OK 후보 중 랜덤 2개 (동일 항목 좌·우 제외)
      selectedCandidates = pickTwoCandidates(okCandidates);
    }

    // ── 활동별 카드 생성: 4개 활동 × 선발 패턴 2개의 보상패턴·수정가이드 ──
    // 구조: items[i] = 활동 1개, 그 안에 patterns[] = 선발된 패턴 2개
    const items = ACT_CONTENT.map(({ actKey, activity, assetKey }) => ({
      activity,
      image: { assetKey, url: this.resolveBalanceUrl(assetKey) },
      patterns: selectedCandidates.map((c) => ({
        title: c.titleLabel,
        observationPoint: c.observationPoint,
        currentPattern: c.activities[actKey].currentPattern,
        correctionGuide: c.activities[actKey].correctionGuide,
      })),
    }));

    return {
      title: '일상생활 한 다리 균형 패턴',
      items,
    };
  }

  // ──────────────────────────────────────────────────────────────────────────
  // 기능적 균형 트레이닝 목표 + 권장/챌린지 상세 (동적)
  // ──────────────────────────────────────────────────────────────────────────
  private buildBalanceTrainingSections(score: number) {
    const s = Math.max(0, Math.min(10, Math.round(score / 10)));
    // 현재 레벨 / 챌린지 레벨
    let currentLevel: number;
    if      (s >= 10) currentLevel = 5;
    else if (s >= 8)  currentLevel = 4;
    else if (s >= 6)  currentLevel = 3;
    else if (s >= 4)  currentLevel = 2;
    else              currentLevel = 1;
    const challengeLevel = Math.min(6, currentLevel + 1);

    // ── 레벨별 메타 ─────────────────────────────────────────────────────────
    const LEVEL_META: Record<number, { levelDescription: string; overview: string }> = {
      1: {
        levelDescription: '골반 및 고관절 주변부 기능적 강화 단계',
        overview: '한 발 서기에서 보였던 불안정성을 근본적으로 해결하기 위해, 골반을 지탱하는 핵심 근육들을 기초부터 단단하게 보강하는 단계입니다.',
      },
      2: {
        levelDescription: '고유수용성 기반 통합 코어 컨트롤 단계',
        overview: '몸이 뒤틀리는 상황에서도 뇌가 즉각적으로 코어 근육을 사용하게 만드는 신경-근 협응력을 깨우는 세션입니다.',
      },
      3: {
        levelDescription: '고유수용성 감각 및 정적 안정화 단계',
        overview: '단순히 서 있는 것이 아니라, 발바닥과 관절에서 오는 신호를 뇌가 정확히 읽어내어 몸을 세우는 고유감각 시스템을 리셋하는 과정입니다.',
      },
      4: {
        levelDescription: '다관절 통합 하체 기능 사슬 훈련 단계',
        overview: '누워서 하던 기초를 지나, 체중을 완전히 실은 상태에서 모든 관절이 조화롭게 움직이도록 만드는 기능적 사슬(Kinetic Chain) 형성 단계입니다.',
      },
      5: {
        levelDescription: '동적 밸런스 및 하체 통합 파워 훈련 단계',
        overview: '걷기, 계단 오르기 등 실제 일상 속 역동적인 움직임을 가장 완벽하고 가벼운 상태로 만들어내는 최적화 단계입니다.',
      },
      6: {
        levelDescription: '동적 감속 및 반응성 강화 단계',
        overview: '돌발 상황이나 착지 시 근육이 충격을 대신 흡수해 관절을 지켜주는 신체 에어백 능력을 몸에 심어주는 최종 단계입니다.',
      },
    };

    // ── 운동 전체 DB (이미지 번호 = assetKey 인덱스) ──────────────────────
    interface ExerciseEntry {
      name: string; assetKey: string;
      goal: string; method: string[];
      checkPoints: string[]; stimulus: string;
    }
    const EXERCISES: ExerciseEntry[] = [
      // Level 1
      {
        name: '클램쉘(밴드 가능)', assetKey: 'EX_01_CLAMSHELL',
        goal: '골반·엉덩관절 안정으로 한발 지지 균형을 돕습니다.',
        method: ['옆으로 누워 무릎을 90도로 굽히고, 발은 붙입니다.', '골반은 고정한 채 위쪽 무릎만 천천히 벌립니다.', '1-2초 멈춘 뒤 천천히 닫습니다.'],
        checkPoints: ['골반이 돌아가지 않게', '상체가 흔들리지 않게', '발뒤꿈치가 떨어지지 않게'],
        stimulus: '엉덩이 옆(골반 바깥쪽)에 자극이 옵니다.',
      },
      {
        name: '사이드라잉 힙 어브덕션', assetKey: 'EX_02_SIDE_LYING_HIP_ABDUCTION',
        goal: '중간볼기근 안정으로 골반 수평과 좌우 흔들림을 줄입니다.',
        method: ['옆으로 누워 몸과 다리를 일직선으로 곧게 폅니다.', '위쪽 다리의 발끝을 정면으로 향하게 맞춥니다.', '골반 고정 후 골반높이 유지 범위에서 다리를 천천히 들고 내립니다.'],
        checkPoints: ['몸통이 흔들리지 않게', '다리가 골반보다 살짝 뒤에 있도록', '옆구리가 짧아지지 않게'],
        stimulus: '위쪽 엉덩이 옆과 바깥 허벅지 윗부분에 자극이 옵니다.',
      },
      {
        name: '슈파인 브릿지', assetKey: 'EX_03_SUPINE_BRIDGE',
        goal: '코어·골반 컨트롤로 중심 안정(밸런스)을 키웁니다.',
        method: ['바로 누워 무릎을 세우고 발은 골반 너비로 둡니다.', '배에 힘을 주고 발로 바닥을 밀어 골반을 들어 올립니다.', '천천히 내려옵니다.'],
        checkPoints: ['갈비뼈가 들리지 않게', '무릎이 안쪽·바깥으로 무너지지 않게', '골반을 과도하게 들지 않게(목이 꺾이지 않게)'],
        stimulus: '엉덩이(둔근), 허리에 자극이 옵니다.',
      },
      {
        name: '프로그', assetKey: 'EX_04_FROG',
        goal: '둔근 중심의 골반 안정으로 중심 잡기(밸런스)를 돕습니다.',
        method: ['엎드려 무릎을 굽히고 발뒤꿈치를 서로 붙여 개구리 자세를 만듭니다(다리가 다이아몬드 모양).', '배에 힘을 주고 골반을 고정한 채, 발뒤꿈치를 붙인 상태로 무릎을 바닥에서 살짝 들어 올립니다.', '정지 시간은 상태에 맞춰 조절한 뒤 천천히 내려옵니다.'],
        checkPoints: ['허리가 꺾이지 않게', '다리가 다이아몬드 모양을 유지하게', '발뒤꿈치가 떨어지지 않게'],
        stimulus: '엉덩이 아래쪽~중앙(둔근)에 자극이 옵니다.',
      },
      {
        name: '힙 익스텐션', assetKey: 'EX_05_HIP_EXTENSION',
        goal: '엉덩관절을 안정적으로 펴는 힘으로 자세·보행 균형을 돕습니다.',
        method: ['엎드리거나 네발기기에서 배에 힘을 줍니다.', '한쪽 다리를 골반이 돌아가지 않는 범위에서 뒤로 천천히 들어 올립니다.', '정지 시간은 상태에 맞춰 조절한 뒤 천천히 내려옵니다.'],
        checkPoints: ['골반이 회전하지 않게', '허리가 꺾이지 않게', '골반이 좌우로 흔들리지 않게'],
        stimulus: '들어 올리는 쪽 엉덩이에 자극이 옵니다.',
      },
      // Level 2
      {
        name: '사이드 플랭크', assetKey: 'EX_06_SIDE_PLANK',
        goal: '옆라인 코어 안정으로 몸통 흔들림을 줄여 균형을 올립니다.',
        method: ['옆으로 누워 팔꿈치를 90도로 굽혀 어깨 아래에 둡니다.', '골반을 들어 머리–골반–발을 일직선으로 만듭니다.', '10–30초 버틴 뒤 내려옵니다.'],
        checkPoints: ['어깨가 올라가지 않게', '골반이 뒤로 빠지지 않게', '허리가 꺾이지 않게'],
        stimulus: '옆구리와 엉덩이 옆에 자극이 옵니다.',
      },
      {
        name: '사이드밴딩 (half kneeling)', assetKey: 'EX_07_SIDE_BENDING_HALF_KNEELING',
        goal: '옆라인 컨트롤로 골반·몸통 정렬을 유지해 균형을 돕습니다.',
        method: ['한쪽 무릎을 90도로 굽혀 무릎으로 서고 반대쪽 다리는 엉덩·무릎 90도로 굽혀 앞에 디딘 뒤 몸통을 곧게 세웁니다.', '손은 머리 뒤에 두고 복부에 힘을 줍니다.', '앞쪽으로 지지한 다리 쪽으로 천천히 몸을 기울였다가 원위치로 돌아옵니다.'],
        checkPoints: ['몸통이 앞으로 숙여지지 않게', '과도하게 기울여 넘어지지 않게', '허리가 꺾이지 않게'],
        stimulus: '옆구리 라인(배빗근)과 옆등에 자극이 옵니다.',
      },
      {
        name: '한다리 브릿지', assetKey: 'EX_08_SINGLE_LEG_BRIDGE',
        goal: '한발 지지 상황의 골반 수평을 만들어 균형을 강화합니다.',
        method: ['무릎을 세우고 누운 자세에서 한쪽 다리를 45°로 듭니다.', '지지발로 바닥을 밀어 엉덩이를 들어 올립니다.', '정지 시간은 상태에 맞춰 조절한 뒤 천천히 내려옵니다.'],
        checkPoints: ['골반이 돌아가지 않게', '무릎이 모이거나 벌어지지 않게', '허리가 젖혀지지 않게'],
        stimulus: '지지하는 쪽 엉덩이에 자극이 옵니다.',
      },
      {
        name: '네발기기 자세 + 힙 어브덕션', assetKey: 'EX_09_QUADRUPED_HIP_ABDUCTION',
        goal: '몸통·골반 안정과 팔·다리 협응으로 균형을 올립니다.',
        method: ['네발기기에서 손은 어깨 아래, 무릎은 골반 아래에 둡니다.', '한쪽 다리를 골반 높이 전까지만 옆으로 들어 올립니다.', '정지 시간은 상태에 맞춰 조절한 뒤 천천히 내려옵니다.'],
        checkPoints: ['골반이 돌아가지 않게', '허리가 꺾이지 않게', '지지다리가 바닥과 수직이 되게 유지'],
        stimulus: '들어 올린 다리의 엉덩이 옆과 몸통(코어)에 자극이 옵니다.',
      },
      {
        name: '크로스 크런치', assetKey: 'EX_10_CROSS_CRUNCH',
        goal: '회전 코어 컨트롤로 비틀림 상황의 균형을 올립니다.',
        method: ['바로 누워 무릎을 세우고 손은 가볍게 머리 뒤에 둡니다.', '상체를 들어 올리며 몸통을 오른쪽으로 돌려 오른쪽 무릎과 왼쪽 팔꿈치를 가깝게 합니다.', '천천히 내려오고 반대도 반복합니다.'],
        checkPoints: ['손으로 목을 과도하게 당기지 않게', '상체 회전에 집중', '몸통이 흔들리지 않게'],
        stimulus: '배 옆(배빗근)에 자극이 옵니다.',
      },
      // Level 3
      {
        name: '벽잡고 한다리서기 + 골반수평맞추기', assetKey: 'EX_11_WALL_SINGLE_LEG_STAND',
        goal: '한발 지지 골반 수평을 만들어 기본 균형을 강화합니다.',
        method: ['벽을 손끝으로 가볍게 짚고 한발로 섭니다.', '골반이 한쪽으로 처지지 않게 수평을 맞춥니다.', '10–30초 유지합니다.'],
        checkPoints: ['지지발 무릎이 안쪽·바깥으로 무너지지 않게', '상체가 한쪽으로 기울지 않게', '손은 보조만 하게'],
        stimulus: '지지하는 쪽 엉덩이 옆과 발바닥(아치)에 자극이 옵니다.',
      },
      {
        name: '탠덤 스탠스 & 상체 수직 유지', assetKey: 'EX_12_TANDEM_STANCE',
        goal: '좁은 지지면에서 균형 감각과 자세 제어를 높입니다.',
        method: ['한 발을 다른 발 앞에 일자로 놓고 섭니다(뒤꿈치-발끝).', '시선 정면, 상체 수직을 유지합니다.', '20–40초 유지 후 발을 바꿉니다.'],
        checkPoints: ['골반이 틀어지지 않게', '어깨 힘을 빼고 호흡 유지', '흔들리면 좌우 간격을 조금 넓게'],
        stimulus: '발목 주변과 종아리, 코어에 자극이 옵니다.',
      },
      {
        name: '벽 등대고 한다리 서기 + 등 밀기', assetKey: 'EX_13_WALL_BACK_SINGLE_LEG',
        goal: '벽을 기준으로 정렬을 잡아 한발 균형을 안정화합니다.',
        method: ['양 발을 벽에서 10cm 정도 띄우고, 벽에 등을 대고 한발로 섭니다.', '등을 벽에 가볍게 밀며 몸통을 곧게 세웁니다(골반 뒤, 등, 머리 뒤쪽이 벽에 밀착되게).', '15–30초 유지합니다.'],
        checkPoints: ['골반 수평 유지', '지지발 무릎 정렬 유지', '벽에서 골반 뒤·등·머리 뒤가 떨어지지 않게'],
        stimulus: '지지하는 쪽 둔근·코어·종아리에 자극이 옵니다.',
      },
      {
        name: '든 다리 벽 밀기', assetKey: 'EX_14_WALL_PRESS_RAISED_LEG',
        goal: '들어올린 다리의 힘을 쓰며 지지발 균형을 강화합니다.',
        method: ['벽 앞에서 한발로 서고 반대 다리를 들어 무릎을 세웁니다.', '든 다리의 발로 벽을 가볍게 밉니다.', '10–20초 유지 후 교대합니다.'],
        checkPoints: ['상체가 뒤로 밀리거나 굽지 않게', '지지발 무릎이 안쪽으로 무너지지 않게', '골반이 돌아가지 않게'],
        stimulus: '지지발 엉덩이 옆과 들어올린 다리 앞쪽, 코어에 자극이 옵니다.',
      },
      {
        name: '한다리 서기 + Y 레이즈', assetKey: 'EX_15_SINGLE_LEG_Y_RAISE',
        goal: '한발 균형 + 상체 안정(어깨뼈 컨트롤)을 동시에 강화합니다.',
        method: ['한발로 서서 시선 정면을 유지합니다.', '양팔을 대각선 위로 Y 모양으로 올립니다(어깨는 올라가지 않게).', '정지 시간은 상태에 맞춰 조절한 뒤 천천히 내려옵니다.'],
        checkPoints: ['어깨가 올라가지 않게', '몸통이 흔들리면 팔 높이를 낮게', '골반 수평 유지'],
        stimulus: '지지발 둔근·발목과 등 전반(어깨뼈 아래~중간)에 자극이 옵니다.',
      },
      // Level 4
      {
        name: '스쿼트', assetKey: 'EX_16_SQUAT',
        goal: '하체 정렬과 중심 이동을 안정화해 균형 기반을 만듭니다.',
        method: ['발을 골반~어깨 너비로 서고 시선은 정면을 둡니다.', '엉덩이를 뒤로 보내 의자에 앉듯 앉았다가 일어섭니다.', '천천히 반복합니다.'],
        checkPoints: ['무릎이 발끝 방향으로 움직이게', '발바닥 3점(엄지·새끼·뒤꿈치) 지지 유지', '상체가 과도하게 숙여지지 않게'],
        stimulus: '엉덩이·허벅지에 자극이 옵니다.',
      },
      {
        name: '런지', assetKey: 'EX_17_LUNGE',
        goal: '좌우 비대칭 자세에서 균형과 하체 정렬을 강화합니다.',
        method: ['한 발을 앞으로 내딛고 상체를 세웁니다.', '양 무릎을 굽혀 내려갔다가 올라옵니다.', '반복 후 다리를 바꿉니다.'],
        checkPoints: ['앞무릎이 안쪽으로 무너지지 않게', '골반이 비틀리지 않게', '중심이 좌우로 흔들리지 않게'],
        stimulus: '앞에 위치한 다리 엉덩이·허벅지에 자극이 옵니다.',
      },
      {
        name: '사이드 런지', assetKey: 'EX_18_SIDE_LUNGE',
        goal: '좌우 이동 시 중심 제어와 고관절 안정 균형을 강화합니다.',
        method: ['다리를 골반 너비보다 넓게 섭니다.', '한쪽으로 체중을 옮기며 그쪽 무릎을 굽혀 앉고, 반대 다리는 편 상태로 둡니다.', '지지한 발로 바닥을 밀어 다시 가운데로 돌아오고 반대쪽도 반복합니다.'],
        checkPoints: ['무릎이 발끝 방향을 유지하게', '상체가 한쪽으로 기울지 않게'],
        stimulus: '내딛은 쪽 엉덩이와 허벅지 안쪽에 자극이 옵니다.',
      },
      {
        name: '리버스 런지', assetKey: 'EX_19_REVERSE_LUNGE',
        goal: '뒤로 이동하며 균형 유지와 무릎 부담을 줄인 하체 안정 훈련입니다.',
        method: ['한 발을 뒤로 내딛고 상체를 세웁니다.', '내려갔다가 앞발로 밀어 올라옵니다.', '반복 후 교대합니다.'],
        checkPoints: ['중심이 앞으로 쏠리지 않게', '앞무릎 정렬 유지', '골반이 흔들리지 않게'],
        stimulus: '앞다리 엉덩이·허벅지에 자극이 옵니다.',
      },
      {
        name: '크로스 런지(크로스오버)', assetKey: 'EX_20_CROSS_LUNGE',
        goal: '교차 스텝에서 무게중심 이동과 골반·무릎 정렬 제어를 훈련해 동적 균형을 강화합니다.',
        method: ['한 발을 대각선 뒤로 교차해 내딛습니다.', '골반을 의자에 앉듯 내려갔다가 앞쪽 지지발로 바닥을 밀어 올라옵니다.', '반복 후 교대합니다.'],
        checkPoints: ['골반이 과하게 돌아가지 않게', '앞무릎이 안쪽·바깥으로 무너지지 않게', '상체가 한쪽으로 기울지 않게'],
        stimulus: '앞쪽 지지 다리의 엉덩이 옆과 허벅지에 자극이 옵니다.',
      },
      {
        name: '스텝업(낮은 박스)', assetKey: 'EX_21_STEP_UP_LOW',
        goal: '한발 지지에서 중심 이동과 착지 안정(밸런스)을 강화합니다.',
        method: ['낮은 박스(높이: 정강이 중간~아래 정도)에 한발을 올리고 상체를 세웁니다.', '올린 발로 밀어 올라가며 반대 무릎을 90도로 들어 올립니다.', '들었던 발로 바닥을 디디며 천천히 내려옵니다.'],
        checkPoints: ['박스 위 무릎이 안쪽·바깥으로 무너지지 않게', '일정한 리듬으로 진행', '상체를 수직으로 유지하며 진행'],
        stimulus: '박스에 올린 지지 다리의 엉덩이·허벅지에 자극이 옵니다.',
      },
      // Level 5
      {
        name: '런지 투 니드라이브(런지 후 무릎 들기)', assetKey: 'EX_22_LUNGE_TO_KNEE_DRIVE',
        goal: '동작 전환에서 균형 회복 능력을 강화합니다.',
        method: ['런지로 내려갔다가 올라옵니다.', '올라오며 뒤쪽 다리 무릎을 90도로 들어 앞으로 가져와 한발로 섭니다.', '다시 런지로 내려갑니다.'],
        checkPoints: ['전환 구간에서 과도하게 흔들리지 않게', '골반 수평 최대한 유지', '지지발 무릎이 안쪽·바깥으로 무너지지 않게'],
        stimulus: '지지발 엉덩이·종아리와 코어에 자극이 옵니다.',
      },
      {
        name: '스텝업(중간 높이)', assetKey: 'EX_23_STEP_UP_MID',
        goal: '더 큰 범위에서 한발 지지 균형과 하체 안정성을 강화합니다.',
        method: ['중간 높이 박스(대체로 무릎 아래~무릎 정도)에 한발을 올립니다.', '올린 발로 밀어 올라가며 반대 무릎을 90도로 들어 올립니다.', '들었던 발로 바닥을 디디며 천천히 내려옵니다.'],
        checkPoints: ['박스 위 무릎이 안쪽·바깥으로 무너지지 않게', '일정한 리듬으로 진행', '상체를 수직으로 유지하며 진행'],
        stimulus: '박스에 올린 지지 다리의 엉덩이·허벅지에 자극이 옵니다.',
      },
      {
        name: '스타 익스커전/3방향 리치(앞-옆-뒤)', assetKey: 'EX_24_STAR_EXCURSION',
        goal: '한발 지지에서 방향 전환 균형과 고관절 안정성을 강화합니다.',
        method: ['한발로 지지하고 지지 무릎을 굽히며 반대발을 바깥으로 뻗어 바닥을 가볍게 터치합니다.', '뻗은 다리를 돌아오며 지지 무릎을 펴 중심을 다시 세웁니다.', '옆(바깥) 터치 → 앞 터치 → 뒤 터치 순으로 진행합니다(반대쪽도 동일).'],
        checkPoints: ['지지발 무릎이 안쪽으로 무너지지 않게', '골반이 돌아가지 않게', '발목이 안쪽·바깥으로 무너지지 않게'],
        stimulus: '지지발 엉덩이 옆과 발목 주변에 자극이 옵니다.',
      },
      {
        name: '한다리 데드리프트', assetKey: 'EX_25_SINGLE_LEG_DEADLIFT',
        goal: '힙힌지 기반의 한발 균형과 항회전 능력, 몸통 안정성을 강화합니다.',
        method: ['한발로 서서 골반을 수평으로 맞춥니다.', '척추 중립을 유지하며 상체를 앞으로 기울이고 반대 다리를 뒤로 뻗습니다.', '엄지발가락–발목–무릎 정렬을 유지한 채 다시 올라옵니다.'],
        checkPoints: ['허리가 말리지 않게', '골반이 열리지 않게', '흔들리면 범위를 줄여서'],
        stimulus: '지지발 엉덩이·햄스트링에 자극이 옵니다.',
      },
      {
        name: '한발 서기 체스트 패스(벽 패스)', assetKey: 'EX_26_SINGLE_LEG_CHEST_PASS',
        goal: '상체 힘 전달과 몸통 고정 능력을 키워 균형 유지 중에도 안정적으로 힘을 쓰는 것을 목적으로 합니다.',
        method: ['벽에서 1~2m 앞에 서고 한발로 지지한 뒤 반대 무릎은 가볍게 듭니다.', '미니볼 또는 메디신 볼을 가슴 앞에 들고 배에 힘을 줍니다.', '볼을 정면으로 던지고 가슴 앞에서 받아 균형을 유지하며 반복합니다.'],
        checkPoints: ['골반 수평 유지', '몸통이 앞뒤·좌우로 흔들리지 않게', '받는 순간 중심이 무너지지 않게'],
        stimulus: '지지하는 다리의 엉덩이·발목 주변과 가슴·어깨·삼두, 코어에 자극이 옵니다.',
      },
      // Level 6
      {
        name: '스케이터 스텝(좌우 이동 후 정지)', assetKey: 'EX_27_SKATER_STEP',
        goal: '신체 가속도를 순간적으로 제어하는 감속 및 정지 능력 강화.',
        method: ['좌우로 이동하며 무게 중심을 한 발에서 반대 발로 강하게 던집니다.', '착지한 발로 바닥을 움켜쥐듯 3초간 멈춥니다.', '몸이 완전히 고정되면 다시 반대쪽으로 뜁니다.'],
        checkPoints: ['무릎 정렬 유지', '속도 과도하게 빠르지 않게', '상체 좌우 흔들리지 않게'],
        stimulus: '착지하는 쪽 엉덩이 옆·허벅지·발목에 자극이 옵니다.',
      },
      {
        name: '보수 위 뛰기', assetKey: 'EX_28_BOSU_JUMP',
        goal: '불안정 지면에서 반응 균형과 재정렬 능력을 강화합니다.',
        method: ['보수 앞에서 준비하고 시선 정면을 둡니다.', '보수 위로 가볍게 점프해 스쿼트 자세를 잡습니다.', '중심을 잡고 내려옵니다.'],
        checkPoints: ['착지 후 흔들림 빠르게 줄이기', '무릎이 안쪽·바깥으로 무너지지 않게', '보수가 미끄러지지 않게 고정'],
        stimulus: '종아리·발목과 코어에 자극이 옵니다.',
      },
      {
        name: '싱글레그 랜딩(한발로 점프 후 조용히 착지)', assetKey: 'EX_29_SINGLE_LEG_LANDING',
        goal: '한발 착지 안정과 충격 흡수 균형을 강화합니다.',
        method: ['한발로 서서 작은 점프를 합니다.', '같은 위치에 한발로 조용히 착지합니다.', '2초 멈춘 뒤 반복합니다.'],
        checkPoints: ['무릎 정렬 유지', '착지 소리 줄이기', '착지 후 흔들림 줄이기'],
        stimulus: '지지발 엉덩이·허벅지와 발목에 자극이 옵니다.',
      },
      {
        name: '싱글레그 랜딩(한발로 점프하면서 앞으로 나감)', assetKey: 'EX_30_SINGLE_LEG_FORWARD_LANDING',
        goal: '전진 착지에서 균형 회복과 정렬 능력을 강화합니다.',
        method: ['한발로 서서 앞으로 짧게 점프합니다.', '한발로 착지 후 1-2초 멈춥니다.', '천천히 반복합니다.'],
        checkPoints: ['착지 시 상체가 앞으로 무너지지 않게', '무릎이 안쪽으로 무너지지 않게', '점프 거리 조절'],
        stimulus: '착지하는 쪽 엉덩이·허벅지와 코어에 자극이 옵니다.',
      },
      {
        name: '한 발 서기 + 벽 교대 회전 던지기', assetKey: 'EX_31_SINGLE_LEG_ROTATION_THROW',
        goal: '몸통이 돌아가는 순간에도 하체가 흔들리지 않는 회전 제어력을 강화합니다.',
        method: ['한 발로 서서 중심을 잡고 벽을 측면이나 정면에 둡니다.', '공을 들고 몸통을 회전시켜 벽에 던진 후 다시 잡습니다.', '좌우로 번갈아 가며 던지거나 방향을 바꿔가며 반복합니다.'],
        checkPoints: ['속도가 너무 빠르지 않게', '발바닥 지지 유지', '상체를 수직으로 세우기'],
        stimulus: '엉덩이·종아리·발목과 옆구리(배빗근)에 자극이 옵니다.',
      },
    ];

    // 레벨별 운동 매핑 (인덱스 기준 5개씩: L1=0~4, L2=5~9, L3=10~14, L4=15~20(6개), L5=21~25(5개→실제6개), L6=26~30(5개))
    const LEVEL_EXERCISES: Record<number, number[]> = {
      1: [0, 1, 3, 2, 4],          // 클램쉘, 사이드라잉, 프로그, 슈파인브릿지, 힙익스텐션
      2: [5, 7, 8, 6, 9],          // 사이드플랭크, 한다리브릿지, 네발기기, 사이드밴딩, 크로스크런치
      3: [14, 13, 11, 10, 12],     // Y레이즈, 든다리벽밀기, 탠덤스탠스, 벽잡고한다리서기, 벽등대고
      4: [18, 19, 20, 15, 16, 17], // 리버스런지, 크로스런지, 스텝업낮은, 스쿼트, 런지, 사이드런지
      5: [25, 24, 22, 21, 23],     // 한발체스트패스, 한다리데드리프트, 스텝업중간, 런지투니드라이브, 스타익스커전
      6: [28, 27, 30, 26, 29],     // 싱글레그랜딩, 보수위뛰기, 한발서기회전던지기, 스케이터스텝, 싱글레그앞으로
    };

    const toExerciseItem = (idx: number) => ({
      name: EXERCISES[idx].name,
      assetKey: EXERCISES[idx].assetKey,
      url: this.resolveBalanceUrl(EXERCISES[idx].assetKey),
    });
    const toDetailExercise = (idx: number, prefix: string) => ({
      name: EXERCISES[idx].name,
      assetKey: `${prefix}_${EXERCISES[idx].assetKey}`,
      url: this.resolveBalanceUrl(EXERCISES[idx].assetKey),
    });

    // 권장/챌린지 대표 운동: 각 레벨의 첫 번째 운동
    // 레벨별 상세 대표 운동 (디자인 기준)
    const LEVEL_DETAIL_IDX: Record<number, number> = {
      1: 0,   // 클램쉘
      2: 7,   // 한다리 브릿지
      3: 14,  // 한다리 서기 Y 레이즈
      4: 18,  // 리버스 런지
      5: 25,  // 한발 서기 체스트 패스
      6: 28,  // 싱글레그 랜딩
    };
    const recIdx = LEVEL_DETAIL_IDX[currentLevel] ?? LEVEL_EXERCISES[currentLevel][0];
    const chalIdx = LEVEL_DETAIL_IDX[challengeLevel] ?? LEVEL_EXERCISES[challengeLevel][0];

    return {
      functionalBalanceTrainingGoals: {
        title: '기능적 균형 트레이닝 목표',
        currentLevel,
        currentLevelLabel: '현재 권장 트레이닝',
        challengeLevelLabel: '챌린지 트레이닝',
        levels: [1, 2, 3, 4, 5, 6].map(lv => ({
          level: lv,
          ...(lv === currentLevel ? { recommended: true } : {}),
          ...(lv === challengeLevel ? { challenge: true } : {}),
          levelDescription: LEVEL_META[lv].levelDescription,
          exercises: LEVEL_EXERCISES[lv].map(toExerciseItem),
        })),
      },
      recommendedTrainingDetail: {
        title: '현재 권장 트레이닝',
        level: currentLevel,
        levelText: `Level ${currentLevel}`,
        levelDescription: LEVEL_META[currentLevel].levelDescription,
        overview: LEVEL_META[currentLevel].overview,
        exercise: toDetailExercise(recIdx, 'RECOMMENDED'),
        goal: EXERCISES[recIdx].goal,
        method: EXERCISES[recIdx].method.map((step, i) => `${i + 1}. ${step}`),
        checkPoints: EXERCISES[recIdx].checkPoints,
        stimulus: EXERCISES[recIdx].stimulus,
      },
      challengeTrainingDetail: {
        title: '챌린지 트레이닝',
        level: challengeLevel,
        levelText: `Level ${challengeLevel}`,
        levelDescription: LEVEL_META[challengeLevel].levelDescription,
        overview: LEVEL_META[challengeLevel].overview,
        exercise: toDetailExercise(chalIdx, 'CHALLENGE'),
        goal: EXERCISES[chalIdx].goal,
        method: EXERCISES[chalIdx].method.map((step, i) => `${i + 1}. ${step}`),
        checkPoints: EXERCISES[chalIdx].checkPoints,
        stimulus: EXERCISES[chalIdx].stimulus,
      },
    };
  }

  private buildBalanceTotalScore(score: number): { totalScore: any } {
    // score는 0-100으로 정규화된 값 → 0-10 스케일로 변환
    const s = Math.max(0, Math.min(10, Math.round(score / 10)));
    let stage: string;
    let summaryTitle: string;
    let meaning: string;
    let balanceControlFeature: string;
    let dailyLifeConnection: string;
    let bottomMessage: string;

    if (s >= 10) {
      stage = '안정';
      summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>안정</b> 단계에 해당합니다.';
      meaning = '신경계·근육·관절이 매우 효율적으로 협응되는 상태';
      balanceControlFeature = '한 다리 지지 상황에서도 전신이 하나의 단위처럼 안정적으로 작동하며, 균형 유지를 위해 과도한 노력이나 보상이 거의 필요하지 않은 상태입니다.';
      dailyLifeConnection = '다양한 일상 동작에서도 안정감이 높고, 움직임이 부드러우며 여유가 느껴지는 상태입니다.';
      bottomMessage = '전반적인 균형 조절 능력이 매우 우수하며, 고난도 운동이나 복합 동작으로 확장하기에 적합한 단계입니다.';
    } else if (s >= 8) {
      stage = '기능적 안정';
      summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>기능적 안정</b> 단계에 해당합니다.';
      meaning = '일상 및 운동 수행에 충분한 균형 조절 능력 보유';
      balanceControlFeature = '균형 유지는 가능하지만, 상황이나 피로도에 따라 균형을 유지하기 위한 추가적인 조절이 요구되는 경우가 있는 상태입니다.';
      dailyLifeConnection = '일상생활에서는 큰 불편이 없으나, 빠른 움직임이나 불안정한 환경에서는 흔들림이 나타날 수 있는 상태입니다.';
      bottomMessage = '기본적인 균형 능력은 확보되어 있으며, 안정성을 유지한 상태에서 움직임을 강화하는 훈련이 필요한 단계입니다.';
    } else if (s >= 6) {
      stage = '보상적 안정';
      summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>보상적 안정</b> 단계에 해당합니다.';
      meaning = '균형을 유지하지만 다른 부위의 보상으로 버티는 상태';
      balanceControlFeature = '균형 자체는 유지되지만, 몸의 일부를 더 많이 사용해 버티는 경향이 나타나며 전신 협응 효율이 떨어지는 상태입니다.';
      dailyLifeConnection = '오래 서 있거나 한쪽 다리를 사용하는 상황에서 피로가 빨리 쌓이고 불편감이 생기기 쉬운 상태입니다.';
      bottomMessage = '현재는 효율적인 균형 전략이 부족하므로, 불필요한 보상을 줄이고 균형 조절 능력을 개선하는 훈련이 필요한 단계입니다.';
    } else if (s >= 4) {
      stage = '불안정';
      summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>불안정</b> 단계에 해당합니다.';
      meaning = '신경-근육 조절 능력이 충분히 작동하지 않는 상태';
      balanceControlFeature = '한 다리 지지 상황에서 균형을 유지하기 위한 조절이 지속적으로 필요하며, 안정적인 패턴을 유지하기 어려운 상태입니다.';
      dailyLifeConnection = '일상 동작에서도 불안정함을 느끼기 쉽고, 특정 상황에서는 넘어질 위험이 커질 수 있는 상태입니다.';
      bottomMessage = '현재는 근력보다 기초적인 균형 조절 능력을 우선적으로 향상시키는 접근이 필요한 단계입니다.';
    } else {
      stage = '조절상실';
      summaryTitle = '현재 한 다리 지지 시 균형 종합 능력은\n <b>조절상실</b> 단계에 해당합니다.';
      meaning = '균형을 능동적으로 조절하지 못하는 상태';
      balanceControlFeature = '균형 조절 전략이 충분히 형성되지 않아 한 다리 지지 상태를 유지하는 것 자체가 어려운 상태입니다.';
      dailyLifeConnection = '일상생활에서도 불안정성이 높아 안전에 대한 관리가 특히 중요한 상태입니다.';
      bottomMessage = '안전을 최우선으로 고려하여 매우 기초적인 균형 조절 능력부터 단계적으로 접근해야 하는 단계입니다.';
    }

    return {
      totalScore: {
        scoreText: `BALANCE SCORE : ${s}/10 (${stage})`,
        score: s,
        scoreMax: 10,
        stage,
        levelGuide: [
          { label: '조절상실', color: 'red' },
          { label: '불안정', color: 'orange' },
          { label: '보상적 안정', color: 'yellow' },
          { label: '기능적 안정', color: 'green' },
          { label: '안정', color: 'blue' },
        ],
        summaryTitle,
        meaning,
        balanceControlFeature,
        dailyLifeConnection,
        bottomMessage,
      },
    };
  }

  /** ROM 단계 레이블 */
  private getRomLevelLabel(level: string): string {
    const map: Record<string, string> = {
      GOOD: '양호',
      MILD: '경미',
      CAUTION: '주의',
      SERIOUS: '심각',
      VERY_SERIOUS: '매우 심각',
    };
    return map[level] ?? '확인 필요';
  }

  /** 관절별 가동범위 summary 블록 동적 생성 */
  private buildJointRomSummary(report: any, files: any[] = []): any {
    const romInfo = report.analysisData?.romInfo || {};
    const measuredAngle: number = Math.round(romInfo.measuredAngle ?? 0);
    const normalAngle: number = Math.round(romInfo.normalAngle ?? 0);
    const romDiff: number = romInfo.romDiff ?? 0;
    const score: number = report.score ?? 0;

    // 과가동성 단계 확인: result 내 어떤 항목에든 hypermobilityLevel이 있으면 사용
    const resultValues = Object.values(report.analysisData?.result || {}) as any[];
    const hypermobilityEntry = resultValues.find(v => v && v.hypermobilityLevel);
    const hypermobilityLevel: string | undefined = hypermobilityEntry?.hypermobilityLevel;

    let levelLabel = this.getRomLevelLabel(report.level || '');
    if (hypermobilityLevel) {
      // '매우심각' → '매우 심각' 정규화 (riskBar stages 레이블과 통일)
      levelLabel = hypermobilityLevel === '매우심각' ? '매우 심각' : hypermobilityLevel;
    }

    const name: string = report.name || '';
    const key: string = report.key || '';
    const assetKeyBase = key.replace(/([A-Z])/g, '_$1').toUpperCase().replace(/^_/, '');

    // division = "{key}_{stepKey}" 형식으로 저장됨
    // 시작자세(step1) → skeletonGuide, 측정이미지(마지막 step) → measurementPhoto
    const keyFiles = files.filter(f => f.division?.startsWith(`${key}_`));
    const sortedKeyFiles = [...keyFiles].sort((a, b) => {
      const stepA = parseInt((a.division?.split('_').pop() || '').replace('step', '') || '0', 10);
      const stepB = parseInt((b.division?.split('_').pop() || '').replace('step', '') || '0', 10);
      return stepA - stepB;
    });
    const startFile = sortedKeyFiles[0] ?? null;
    const endFile = sortedKeyFiles[sortedKeyFiles.length - 1] ?? null;

    return {
      title: '요약',
      partTitle: `Part | ${name}`,
      inspectionPart: `검사 부위: ${name}`,
      images: {
        measurementPhoto: { assetKey: `ROM_${assetKeyBase}_PHOTO`, url: endFile?.fileUrl ?? null },
        skeletonGuide: { assetKey: `ROM_${assetKeyBase}_SKELETON`, url: startFile?.fileUrl ?? null },
      },
      metrics: [
        {
          label: '측정값 / 일반범위',
          value: normalAngle > 0 ? `${measuredAngle}° / ${normalAngle}°` : `${score}%`,
        },
        {
          label: '편차 / 퍼센트 / 단계',
          value: normalAngle > 0
            ? `${romDiff < 0 ? '▼' : '▲'} ${Math.abs(Math.round(romDiff))}° / ${score}% / ${levelLabel}`
            : `${score}% / ${levelLabel}`,
        },
      ],
      riskBar: {
        currentStage: levelLabel,
        stages: [
          { label: '매우 심각', color: 'red' },
          { label: '심각', color: 'orange' },
          { label: '주의', color: 'yellow' },
          { label: '경미', color: 'green' },
          { label: '양호', color: 'blue' },
        ],
      },
      analysis: (() => {
        const statusGuideMap: Record<string, string> = {
          GOOD: '비교적 안정적인 움직임이 가능함',
          MILD: '일부 동작에서 움직임의 부담이 느껴질 수 있으며',
          CAUTION: '일부 동작에서 움직임의 부담이 느껴질 수 있으며',
          SERIOUS: '움직임 전반에서 부담이 느껴질 수 있으며',
          VERY_SERIOUS: '움직임 전반에서 부담이 느껴질 수 있으며',
        };
        const levelColorMap: Record<string, string> = {
          GOOD: 'blue', MILD: 'green', CAUTION: 'yellow', SERIOUS: 'orange', VERY_SERIOUS: 'red',
        };
        // 과가동성 단계별 색상 및 안내 문구
        const hyperColorMap: Record<string, string> = {
          '경미': 'green', '주의': 'yellow', '심각': 'orange', '매우심각': 'red',
        };
        const hyperStatusGuideMap: Record<string, string> = {
          '경미': '관절 가동범위가 정상보다 약간 과도하여 안정성에 주의가 필요하며',
          '주의': '과도한 가동범위로 인해 관절 부담이 증가할 수 있으며',
          '심각': '과가동성이 심각하여 관절 손상 위험이 높을 수 있으며',
          '매우심각': '과가동성이 매우 심각하여 즉각적인 전문 관리가 필요하며',
        };
        const statusGuide = hypermobilityLevel
          ? (hyperStatusGuideMap[hypermobilityLevel] ?? '가동범위 과도로 주의가 필요하며')
          : (statusGuideMap[report.level || ''] ?? '일상적인 움직임에서 불편으로');
        const levelColor = hypermobilityLevel
          ? (hyperColorMap[hypermobilityLevel] ?? 'green')
          : (levelColorMap[report.level || ''] ?? 'blue');
        let statusFull = statusGuide;
        if (hypermobilityLevel || (report.level || '') !== 'GOOD') {
          const conditions = this.resolveRomConditionTitles(key);
          if (conditions && conditions.length > 0) {
            const randomCondition = conditions[Math.floor(Math.random() * conditions.length)];
            statusFull = `${statusGuide}, ${randomCondition}`;
          }
        }
        // 과가동성일 때는 DB에 저장된 comment(GOOD 문구일 수 있음) 대신 전용 문구 사용
        const hypermobilityCommentMap: Record<string, string> = {
          '경미': '해당 관절의 가동범위가 일반 기준보다 약간 초과된 단계로 분류됩니다. 일상 동작에는 큰 제약이 없으나, 관절 주변 안정화 근육 강화와 과도한 범위 사용을 줄이는 방향의 관리가 권장됩니다.',
          '주의': '해당 관절의 가동범위가 일반 기준을 초과하여 과가동성이 확인된 단계입니다. 관절 안정성 저하로 반복 동작 시 부담이 증가할 수 있으며, 안정화 운동과 함께 사용 패턴 점검이 필요합니다.',
          '심각': '해당 관절의 가동범위가 과가동성 심각 단계로 분류됩니다. 관절 손상 위험이 높아질 수 있으며, 전문적인 움직임 지도 하에 안정화 훈련을 우선적으로 진행하는 것이 권장됩니다.',
          '매우심각': '해당 관절의 가동범위가 과가동성 매우 심각 단계로 분류됩니다. 즉각적인 전문 관리와 함께, 과도한 가동 범위를 유발하는 동작 패턴을 즉시 교정해야 하는 구간입니다.',
          '매우 심각': '해당 관절의 가동범위가 과가동성 매우 심각 단계로 분류됩니다. 즉각적인 전문 관리와 함께, 과도한 가동 범위를 유발하는 동작 패턴을 즉시 교정해야 하는 구간입니다.',
        };
        const commentText = hypermobilityLevel
          ? (hypermobilityCommentMap[hypermobilityLevel] ?? '해당 관절의 가동범위가 일반 기준을 초과하여 과가동성이 확인된 단계입니다. 관절 안정화 관리가 권장됩니다.')
          : (report.comment ?? '');
        if (commentText) {
          return `<b>${name}</b> 가동범위가 평가 기준상 <b><${levelColor}>${levelLabel}</${levelColor}></b> 단계로 분류됩니다.\n 이러한 가동범위 특성은 개인에 따라 일상적인 움직임에서 \n <b>${statusFull}</b> (으)로 이어질 수 있습니다.\n<b>${commentText}</b>`;
        }
        return `${name} 가동범위가 ${levelLabel} 단계로 분류됩니다.`;
      })(),
    };
  }

  /**
   * 전신기능검사 운동수행 지수 블록 (disease 수 기반 5단계) */
  public buildOHTPerformanceIndex(scoreDetail: any): any {
    // 유형에 대한 심각도(score 1~5)의 평균
    const keys = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];
    const scores = keys.map((k) => scoreDetail?.[k]?.score ?? 1);
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    // 평균을 0~25 범위로 환산: (avg - 1) * 25 / 4 → 대략적인 0~25 지수
    const index = Math.round((avg - 1) * 25 / 4);

    let label: string;
    let status: string;
    let analysisContent: string;
    let strategyContent: string;

    if (index <= 5) {
      label = 'Level 1'; status = '양호';
      analysisContent = '오버헤드 스쿼트 동작에서 전신 협응과 관절 사용이 조화롭게 나타나며, 현재 단계에서 효율적인 동작 패턴이 관찰됩니다.';
      strategyContent = '현재의 움직임 특성을 유지하면서, 팔·몸통·하체 연결을 더욱 정교하게 다듬는 동작 최적화 과정을 통해 운동 효율을 높일 수 있습니다.';
    } else if (index <= 10) {
      label = 'Level 2'; status = '경미';
      analysisContent = '오버헤드 스쿼트 하강 및 전환 구간에서 전반적인 정렬은 유지되나, 동작 연결 과정에서 움직임 효율이 다소 분산되는 양상이 관찰됩니다.';
      strategyContent = '기존의 장점을 유지하며, 하강–상승 전환 시 리듬과 연결을 정리하는 훈련을 통해 동작 효율을 향상시킬 수 있습니다.';
    } else if (index <= 15) {
      label = 'Level 3'; status = '주의';
      analysisContent = '오버헤드 스쿼트 특정 구간에서 지지 방식과 조절 전략이 달라지며, 동작의 일관성이 감소하는 경향이 관찰됩니다.';
      strategyContent = '중량 증가 이전에 기본 지지 인식과 팔–몸통–하체 정렬을 정리하는 훈련을 병행하여 안정적인 동작 수행 기반을 마련하는 것이 권장됩니다.';
    } else if (index <= 20) {
      label = 'Level 4'; status = '심각';
      analysisContent = '오버헤드 스쿼트 수행 전반에서 지지와 움직임 선택이 분리되어 사용되며, 보완적인 사용 전략이 두드러지게 나타납니다.';
      strategyContent = '반복 수행보다 트레이너의 단계적 가이드를 통해 오버헤드 스쿼트 동작에서의 사용 전략을 재정렬하는 접근이 우선적으로 필요합니다.';
    } else {
      label = 'Level 5'; status = '매우심각';
      analysisContent = '오버헤드 스쿼트 동작 중 전신 조절보다 특정 부위 의존도가 높아, 일관된 동작 전략이 형성되지 않은 양상이 관찰됩니다.';
      strategyContent = '단순 반복보다는 트레이너와의 밀착 가이드를 통해 오버헤드 스쿼트의 기본 동작 구조와 사용 전략을 재구성하는 접근이 권장됩니다.';
    }

    return {
      title: '운동 수행 지수 (Exercise Performance Index)',
      stage: label,
      scoreRangeLabel: status,
      index,
      scale: [
        { label: '매우심각', color: 'red' },
        { label: '심각', color: 'orange' },
        { label: '주의', color: 'yellow' },
        { label: '경미', color: 'lightgreen' },
        { label: '양호', color: 'green' },
      ],
      summary: { title: '분석', content: analysisContent },
      strategy: { title: '전략', content: strategyContent },
    };
  }

  // ─── OHT 케이스별 텍스트 DB ───────────────────────────────────

  // ─── 근육 동원 및 유연성 밸런스 DB (이미지 번호 기준) ────────────

  private buildOHTBiomechanicsSummary(scoreDetail: any): any {
    const DISEASE_PRIORITY = [
      'hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel',
    ];

    // 비정상 항목 추출 (disease !== 'NORMAL')
    // dbKey: HIP_NOT_CENTER는 방향별 키로 해석
    const abnormal: Array<{ key: string; disease: string; dbKey: string; score: number }> = [];
    for (const k of DISEASE_PRIORITY) {
      const item = scoreDetail?.[k];
      if (item && item.disease !== 'NORMAL') {
        const dbKey = item.disease as string;
        abnormal.push({ key: k, disease: item.disease, dbKey, score: item.score ?? 1 });
      }
    }

    const allNormal = abnormal.length === 0;

    // ── 상위 연계 시나리오 기반 TYPE1 / TYPE2 결정 ───────────────
    const topPair = this.computeTopLinkedScenarioPair(scoreDetail);
    const type1Code = topPair?.type1Key ?? null;
    const type2Code = topPair?.type2Key ?? null;
    const type1Entry = type1Code ? OHT_CASE_DB[type1Code] : null;
    const type2Entry = type2Code ? OHT_CASE_DB[type2Code] : null;

    // ── 패턴명 빌드: 상위 연계 시나리오의 TYPE1 + TYPE2 ──────────
    let patternLabel: string;
    if (allNormal) {
      patternLabel = '양쪽 발 정상 정렬 + 골반 중심 안정';
    } else if (type1Entry) {
      patternLabel = type2Entry
        ? `${type1Entry.patternName} + ${type2Entry.patternName}`
        : type1Entry.patternName;
    } else {
      // SCENARIO_DB 미매칭 시 — 첫 번째 비정상 항목 사용
      patternLabel = OHT_CASE_DB[abnormal[0]?.dbKey]?.patternName ?? abnormal[0]?.disease ?? '';
    }

    // ── 과긴장/저활성: TYPE1+TYPE2 조합 MUSCLE_BALANCE_DB에서 앞 3개씩 ─
    const muscleImgNum = this.computeOHTCaseNumber(scoreDetail);
    const muscleEntry = MUSCLE_BALANCE_DB[muscleImgNum] ?? MUSCLE_BALANCE_DB[52];
    const overStr = muscleEntry.overactiveItems.slice(0, 3).join(', ') || '관련 근육';
    const underStr = muscleEntry.underactiveItems.slice(0, 3).join(', ') || '관련 근육';

    if (allNormal) {
      const normalKeys = ['KNEES_NORMAL', 'ARM_NORMAL'];
      const normalMgmtParts = normalKeys.map((key) => {
        const entry = OHT_CASE_DB[key];
        return `<b>${entry.patternName}</b> 패턴에 대한 움직임 관리를 위해\n→\n${entry.managementStrategy}`;
      });
      return {
        title: '운동 역학적 총평',
        paragraphs: [
          `회원님은 오버헤드 스쿼트 패턴에서 <b>${patternLabel}</b> 패턴이 관찰됩니다.`,
          `이 패턴은 오버헤드 스쿼트 수행 시 <b>하체 움직임의 기능적 협응</b>과 <b>큰볼기근, 중간볼기근 등 둔부의 적절한 활성 패턴</b>이 함께 나타날 가능성을 시사합니다.`,
          `또한 오버헤드 스쿼트 수행 전반에서 골반 중심, 좌우 높이, 상체 각도, 팔의 움직임, 하부 관절 사용이 일관되고 안정적인 패턴으로 유지됩니다. 동작의 깊이와 반복이 진행되는 동안에도 특정 관절에 과도하게 의존하지 않고 상·하체가 조화롭게 역할을 분담하며 움직이는 양상이 관찰됩니다. 이는 현재의 움직임 전략이 효율적으로 형성되어 있으며, 기본적인 정렬과 조절 능력이 잘 유지되고 있음을 의미합니다.`,
        ],
        managementText: normalMgmtParts.join('\n\n또한\n'),
        bottomBox: '이러한 조절이 이루어질 경우, 오버헤드 스쿼트 수행 시 하체와 골반의 기능적 움직임이 보다 안정적으로 나타나며, 일상생활에서는 보행, 계단 동작, 장시간 서 있기 등 기본적인 움직임 전반에서 안정성과 효율이 함께 향상될 수 있습니다.',
      };
    }

    // ── 비정상 케이스 처리 ─────────────────────────────────────
    // 상위 연계 시나리오의 content를 직접 사용
    const scenarioDesc = topPair?.content ?? '';

    // 동작 관리 텍스트: 상위 시나리오의 TYPE1 + TYPE2 사용
    const mgmtCodes: string[] = [];
    if (type1Code) {
      mgmtCodes.push(type1Code);
      if (type2Code) mgmtCodes.push(type2Code);
    }
    
    const mgmtParts = mgmtCodes.map((code) => {
      const entry = OHT_CASE_DB[code];
      const tipLines = (entry?.managementStrategy ?? '')
        .split('\n')
        .filter(l => l.trim().length > 0)
        .slice(0, 2)
        .map(l => `→\n<b>${l.trim()}</b>`);
      return `<b>${entry?.patternName ?? code}</b> 패턴에 대한 움직임 관리를 위해\n${tipLines.join('\n')}`;
    });
    // TYPE1도 없는 경우 fallback
    if (mgmtParts.length === 0) {
      const fb = OHT_CASE_DB[abnormal[0]?.dbKey];
      const fbLines = (fb?.managementStrategy ?? '')
        .split('\n')
        .filter(l => l.trim().length > 0)
        .slice(0, 2)
        .map(l => `→\n<b>${l.trim()}</b>`);
      mgmtParts.push(`<b>${fb?.patternName ?? ''}</b> 패턴에 대한 움직임 관리를 위해\n${fbLines.join('\n')}`);
    }
    const managementText = mgmtParts.join('\n\n또한\n');

    return {
      title: '운동 역학적 총평',
      paragraphs: [
        `회원님은 오버헤드 스쿼트 패턴에서 <b>${patternLabel}</b> 패턴이 관찰됩니다.`,
        `이 패턴은 오버헤드 스쿼트 수행 시 <b>${overStr}의 과긴장 양상</b>과 <b>${underStr}의 저활성 패턴</b>이 함께 나타날 가능성을 시사합니다.`,
        scenarioDesc ? `또한 ${scenarioDesc}` : '',
      ].filter(Boolean),
      managementText,
      bottomBox: '이러한 조절이 이루어질 경우, 오버헤드 스쿼트 수행 시 하체와 골반의 기능적 움직임이 보다 안정적으로 나타나며, 일상생활에서는 보행, 계단 동작, 장시간 서 있기 등 기본적인 움직임 전반에서 안정성과 효율이 함께 향상될 수 있습니다.',
    };
  }

  private buildMuscleBalanceSheet(scoreDetail: any): any {
    const imageNumber = this.computeOHTCaseNumber(scoreDetail);
    const effectiveNumber = MUSCLE_BALANCE_DB[imageNumber] ? imageNumber : 52;
    const entry = MUSCLE_BALANCE_DB[effectiveNumber];

    const { type1Label, type2Label } = this.resolveOHTTypeLabels(scoreDetail, entry);

    return this.formatMuscleBalance(imageNumber, effectiveNumber, type1Label, type2Label, entry);
  }

  /** 운동 역학적 총평과 동일한 TYPE1/TYPE2 라벨 (연계 시나리오 우선) */
  private resolveOHTTypeLabels(
    scoreDetail: any,
    fallbackEntry?: { type1Label: string; type2Label: string | null },
  ): { type1Label: string; type2Label: string | null } {
    const topPair = this.computeTopLinkedScenarioPair(scoreDetail);
    if (topPair?.type1Key) {
      return {
        type1Label: OHT_CASE_DB[topPair.type1Key]?.patternName ?? topPair.type1Key,
        type2Label: topPair.type2Key
          ? (OHT_CASE_DB[topPair.type2Key]?.patternName ?? topPair.type2Key)
          : null,
      };
    }

    if (
      fallbackEntry &&
      fallbackEntry.type2Label !== '나머지 케이스' &&
      fallbackEntry.type1Label !== '기타 패턴'
    ) {
      return {
        type1Label: fallbackEntry.type1Label,
        type2Label: fallbackEntry.type2Label ?? null,
      };
    }

    return this.computeDynamicDiseaseLabels(scoreDetail);
  }

  private computeDynamicDiseaseLabels(scoreDetail: any): { type1Label: string; type2Label: string | null } {
    const DISEASE_PRIORITY_KEYS = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];
    const abnormal: Array<{ key: string; dbKey: string }> = [];
    
    for (const k of DISEASE_PRIORITY_KEYS) {
      const item = scoreDetail?.[k];
      if (item && item.disease !== 'NORMAL') {
        const dbKey = item.disease as string;
        abnormal.push({ key: k, dbKey });
      }
    }

    const TYPE1_PRIORITY = [
      'HIP_NOT_CENTER_RIGHT', 'HIP_NOT_CENTER_LEFT',
      'KNEE_INWARD', 'KNEE_RIGHT', 'KNEE_OUTWARD', 'KNEE_LEFT',
      'RIGHT_ARM_UNNORMAL', 'LEFT_ARM_UNNORMAL', 'ARM_UNNORMAL',
      'RIGHT_HIP_HIGHER', 'LEFT_HIP_HIGHER',
    ];

    const DISEASE_LABEL_MAP: Record<string, string> = {
      // 골반 중심
      'HIP_NOT_CENTER_RIGHT': '골반 오른쪽 이동',
      'HIP_NOT_CENTER_LEFT': '골반 왼쪽 이동',
      // 발
      'FOOT_INWARD': '양쪽 발 모음',
      'FOOT_OUTWARD': '양쪽 발 벌림',
      'FOOT_RIGHT': '오른쪽 발 벌림 / 왼쪽 발 정면',
      'FOOT_LEFT': '왼쪽 발 벌림 / 오른쪽 발 정면',
      'RIGHT_FOOT_OUTWARD': '오른쪽 발 벌림',
      'LEFT_FOOT_OUTWARD': '왼쪽 발 벌림',
      'RIGHT_FOOT_INWARD': '오른쪽 발 모음',
      'LEFT_FOOT_INWARD': '왼쪽 발 모음',
      // 무릎
      'KNEE_INWARD': '양쪽 무릎 밖굽이',
      'KNEE_OUTWARD': '양쪽 무릎 안굽이(varus)',
      'KNEE_RIGHT': '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      'KNEE_LEFT': '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이',
      'RIGHT_KNEE_INWARD': '오른쪽 무릎 밖굽이',
      'LEFT_KNEE_INWARD': '왼쪽 무릎 밖굽이',
      'RIGHT_KNEE_OUTWARD': '오른쪽 무릎 안굽이(varus)',
      'LEFT_KNEE_OUTWARD': '왼쪽 무릎 안굽이(varus)',
      // 발목
      'ANKLE_INWARD': '양쪽 발목 안쪽번짐',
      'ANKLE_OUTWARD': '양쪽 발목 가쪽번짐',
      'ANKLE_LEFT': '오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      'ANKLE_RIGHT': '오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐',
      'RIGHT_ANKLE_INWARD': '오른쪽 발목 안쪽번짐',
      'LEFT_ANKLE_INWARD': '왼쪽 발목 안쪽번짐',
      'RIGHT_ANKLE_OUTWARD': '오른쪽 발목 가쪽번짐',
      'LEFT_ANKLE_OUTWARD': '왼쪽 발목 가쪽번짐',
      // 골반 높이
      'RIGHT_HIP_HIGHER': '오른쪽 골반 높이 상승',
      'LEFT_HIP_HIGHER': '왼쪽 골반 높이 상승',
      // 어깨
      'ARM_UNNORMAL': '양쪽 어깨관절 굽힘 가동범위 제한',
      'LEFT_ARM_UNNORMAL': '왼쪽 어깨관절 굽힘 가동범위 제한',
      'RIGHT_ARM_UNNORMAL': '오른쪽 어깨관절 굽힘 가동범위 제한',
      // 상체
      'BODY_LEARN_BACKWARD': '상체 과도한 뒤로 젖힘',
      'BODY_LEARN_FORWARD': '상체 과도한 앞으로 숙임',
      // 발등굽힘
      'HEEL_UNNORMAL': '양쪽 발등굽힘 가동범위 제한',
      'LEFT_HEEL_UNNORMAL': '왼쪽 발등굽힘 가동범위 제한',
      'RIGHT_HEEL_UNNORMAL': '오른쪽 발등굽힘 가동범위 제한',
    };

    const type1Item = abnormal.find((a) => TYPE1_PRIORITY.includes(a.dbKey));
    if (!type1Item) {
      return { type1Label: '정상', type2Label: null };
    }

    const type1Label = DISEASE_LABEL_MAP[type1Item.dbKey] || type1Item.dbKey;

    const topPair = this.computeTopLinkedScenarioPair(scoreDetail);
    if (topPair?.type2Key) {
      return {
        type1Label,
        type2Label: OHT_CASE_DB[topPair.type2Key]?.patternName ?? topPair.type2Key,
      };
    }

    const remaining = abnormal.filter((a) => a.dbKey !== type1Item.dbKey);
    
    let type2Label: string | null = null;
    if (remaining.length > 0) {
      const type2Item = remaining[0];
      type2Label = DISEASE_LABEL_MAP[type2Item.dbKey] || type2Item.dbKey;
    }

    return { type1Label, type2Label };
  }

  private formatMuscleBalance(imageNumber: number, effectiveNumber: number, type1Label: string, type2Label: string | null, entry: any): any {
    return {
      title: '근육 동원 및 유연성 밸런스',
      imageNumber,
      images: {
        front: this.resolveOHTCaseImageUrl(effectiveNumber, 'front'),
        back:  this.resolveOHTCaseImageUrl(effectiveNumber, 'back'),
        left:  this.resolveOHTCaseImageUrl(effectiveNumber, 'left'),
        right: this.resolveOHTCaseImageUrl(effectiveNumber, 'right'),
      },
      type1Label,
      type2Label,
      overactiveMuscles: {
        title: '과긴장된 근육',
        items: entry.overactiveItems,
      },
      underactiveMuscles: {
        title: '저활성된 근육',
        items: entry.underactiveItems,
      },
    };
  }

  // ─── 전신 움직임 패턴 연계 시나리오 DB ──────────────────────────
  // key = "TYPE1|TYPE2" (항상 사전순으로 정렬하여 순서 무관 조회)

  /** SCENARIO_DB에서 최상위 우선순위 시나리오 content를 반환 (비정상 없으면 빈 문자열) */
  /**
   * 연계 시나리오 정렬 로직(buildLinkedScenario와 동일)으로 최상위 시나리오를 결정하고,
   * 해당 쌍의 type1Key / type2Key를 함께 반환한다.
   * buildOHTBiomechanicsSummary 와 computeOHTCaseNumber 가 공통으로 사용.
   */
  private computeTopLinkedScenarioPair(scoreDetail: any): {
    key: string; title: string; content: string; type1Key: string; type2Key: string | null;
  } | null {
    const KEYS = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];
    const TYPE1_PRIORITY = [
      'HIP_NOT_CENTER_RIGHT', 'HIP_NOT_CENTER_LEFT',
      'KNEE_INWARD', 'KNEE_RIGHT', 'KNEE_OUTWARD', 'KNEE_LEFT',
      'RIGHT_ARM_UNNORMAL', 'LEFT_ARM_UNNORMAL', 'ARM_UNNORMAL',
      'RIGHT_HIP_HIGHER', 'LEFT_HIP_HIGHER',
    ];
    const abnormal: Array<{ dbKey: string; score: number }> = [];
    for (const k of KEYS) {
      const item = scoreDetail?.[k];
      if (!item || item.disease === 'NORMAL') continue;
      abnormal.push({ dbKey: item.disease as string, score: item.score ?? 1 });
    }
    if (abnormal.length === 0) return null;

    const allDbKeys = new Set(abnormal.map((a) => a.dbKey));
    const hipNormal =
      !allDbKeys.has('HIP_NOT_CENTER_RIGHT') && !allDbKeys.has('HIP_NOT_CENTER_LEFT') &&
      !allDbKeys.has('RIGHT_HIP_HIGHER') && !allDbKeys.has('LEFT_HIP_HIGHER');
    if (hipNormal) allDbKeys.add('HIP_CENTER_STABLE');

    const dbKeyArr = [...allDbKeys];
    const matched: Array<{ key: string; title: string; content: string; priority: number; maxScore: number }> = [];
    const seen = new Set<string>();
    for (let i = 0; i < dbKeyArr.length; i++) {
      for (let j = i; j < dbKeyArr.length; j++) {
        const [k1, k2] = [dbKeyArr[i], dbKeyArr[j]].sort();
        const key = `${k1}|${k2}`;
        if (seen.has(key)) continue;
        seen.add(key);
        const entry = SCENARIO_DB[key];
        if (!entry) continue;
        const scoreA = abnormal.find((x) => x.dbKey === dbKeyArr[i])?.score ?? 1;
        const scoreB = abnormal.find((x) => x.dbKey === dbKeyArr[j])?.score ?? 1;
        matched.push({ key, title: entry.title, content: entry.content, priority: entry.priority, maxScore: Math.max(scoreA, scoreB) });
      }
    }
    if (matched.length === 0) return null;

    const _tier = (s: number) => s > 20 ? 5 : s > 15 ? 4 : s > 10 ? 3 : s > 5 ? 2 : 1;
    matched.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      const aStable = a.key.includes('HIP_CENTER_STABLE');
      const bStable = b.key.includes('HIP_CENTER_STABLE');
      if (aStable !== bStable) return aStable ? 1 : -1;
      const td = _tier(b.maxScore) - _tier(a.maxScore);
      if (td !== 0) return td;
      const scoreDiff = b.maxScore - a.maxScore; // 같은 tier 내에서 raw 점수 높은 쪽 먼저
      if (scoreDiff !== 0) return scoreDiff;
      return a.key.localeCompare(b.key);   // 완전 동일: 결정론적 (알파벳 순)
    });

    const top = matched[0];
    const [rawK1, rawK2] = top.key.split('|');
    const type1Key = TYPE1_PRIORITY.includes(rawK1)
      ? rawK1
      : (TYPE1_PRIORITY.includes(rawK2) ? rawK2 : rawK1);
    const type2Key = type1Key === rawK1 ? rawK2 : rawK1;
    const effectiveType2 = type2Key === 'HIP_CENTER_STABLE' ? null : type2Key;

    return { key: top.key, title: top.title, content: top.content, type1Key, type2Key: effectiveType2 };
  }

  private buildLinkedScenario(scoreDetail: any): any {
    const DISEASE_PRIORITY_KEYS = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];

    const abnormal: Array<{ dbKey: string; score: number }> = [];
    for (const k of DISEASE_PRIORITY_KEYS) {
      const item = scoreDetail?.[k];
      if (!item || item.disease === 'NORMAL') continue;
      const dbKey: string = item.disease;
      abnormal.push({ dbKey, score: item.score ?? 1 });
    }

    // ── 2. 전부 정상 ─────────────────────────────────────────
    if (abnormal.length === 0) {
      return {
        title: '전신 움직임 패턴 연계 시나리오',
        description: '본 내용은 진단이나 치료 목적이 아닌, 동작 수행 시 관찰되는 움직임 패턴을 기능·분류하기 위한 참고입니다.',
        typeName: '안정적 통합패턴',
        steps: [{
          order: 1,
          title: '안정적 통합패턴',
          content: '오버헤드 스쿼트 수행 전반에서\n골반 중심, 좌우 높이, 상체 각도, 팔의 움직임, 하부 관절 사용이\n일관되고 안정적인 패턴으로 유지됩니다.\n\n동작의 깊이와 반복이 진행되는 동안에도\n특정 관절에 과도하게 의존하지 않고\n상·하체가 조화롭게 역할을 분담하며 움직이는 양상이 관찰됩니다.\n\n이는 현재의 움직임 전략이 효율적으로 형성되어 있으며,\n기본적인 정렬과 조절 능력이 잘 유지되고 있음을 의미합니다.',
        }],
      };
    }

    // ── 3. 골반 정상 여부 판단 (hipCenter, hipHigher 모두 정상일 때 HIP_CENTER_STABLE 추가)
    const allDbKeys = new Set(abnormal.map((a) => a.dbKey));
    const hipNormal =
      !allDbKeys.has('HIP_NOT_CENTER_RIGHT') &&
      !allDbKeys.has('HIP_NOT_CENTER_LEFT') &&
      !allDbKeys.has('RIGHT_HIP_HIGHER') &&
      !allDbKeys.has('LEFT_HIP_HIGHER');
    if (hipNormal) allDbKeys.add('HIP_CENTER_STABLE');

    // ── 4. 모든 가능한 쌍에서 시나리오 매칭 ─────────────────
    const dbKeyArr = [...allDbKeys];
    const matched: Array<{ key: string; title: string; priority: number; content: string; maxScore: number; minRank: number; maxRank: number }> = [];
    const seenKeys = new Set<string>();

    const DB_KEY_TO_CATEGORY: Record<string, string> = {
      HIP_NOT_CENTER_LEFT: 'hipCenter', HIP_NOT_CENTER_RIGHT: 'hipCenter', HIP_CENTER_STABLE: 'hipCenter',
      FOOT_OUTWARD: 'foot', FOOT_INWARD: 'foot',
      KNEE_LEFT: 'knees', KNEE_RIGHT: 'knees', KNEE_INWARD: 'knees',
      ANKLE_RIGHT: 'ankles', ANKLE_LEFT: 'ankles', ANKLE_INWARD: 'ankles', ANKLE_OUTWARD: 'ankles',
      LEFT_ANKLE_INWARD: 'ankles', LEFT_ANKLE_OUTWARD: 'ankles', RIGHT_ANKLE_INWARD: 'ankles', RIGHT_ANKLE_OUTWARD: 'ankles',
      LEFT_HIP_HIGHER: 'hipHigher', RIGHT_HIP_HIGHER: 'hipHigher',
      ARM_UNNORMAL: 'arm', LEFT_ARM_UNNORMAL: 'arm', RIGHT_ARM_UNNORMAL: 'arm',
      BODY_LEARN_FORWARD: 'body', BODY_LEARN_BACKWARD: 'body',
      HEEL_UNNORMAL: 'heel', LEFT_HEEL_UNNORMAL: 'heel', RIGHT_HEEL_UNNORMAL: 'heel',
    };
    const getKeyRank = (dbKey: string) => {
      const cat = DB_KEY_TO_CATEGORY[dbKey];
      return cat ? DISEASE_PRIORITY_KEYS.indexOf(cat) : 999;
    };

    for (let i = 0; i < dbKeyArr.length; i++) {
      for (let j = i; j < dbKeyArr.length; j++) {
        const a = dbKeyArr[i];
        const b = dbKeyArr[j];
        // 사전순 정렬로 양방향 키 통일
        const [k1, k2] = [a, b].sort();
        const scenarioKey = `${k1}|${k2}`;
        if (seenKeys.has(scenarioKey)) continue;
        seenKeys.add(scenarioKey);
        const entry = SCENARIO_DB[scenarioKey];
        if (!entry) continue;
        // 두 dbKey 중 더 높은 score
        const scoreA = abnormal.find((x) => x.dbKey === a)?.score ?? 1;
        const scoreB = abnormal.find((x) => x.dbKey === b)?.score ?? 1;
        const maxScore = Math.max(scoreA, scoreB);
        const rankA = getKeyRank(a);
        const rankB = getKeyRank(b);
        matched.push({ key: scenarioKey, title: entry.title, priority: entry.priority, content: entry.content, maxScore, minRank: Math.min(rankA, rankB), maxRank: Math.max(rankA, rankB) });
      }
    }

    // ── 5. 우선순위 정렬: 색상(priority) asc → 심각도 구간 desc → raw점수 desc → 결정론적 ─────
    // 심각도 구간: 0~5=1, 6~10=2, 11~15=3, 16~20=4, 20초과=5
    const getScoreTier = (score: number): number => {
      if (score > 20) return 5;
      if (score > 15) return 4;
      if (score > 10) return 3;
      if (score > 5) return 2;
      return 1;
    };
    matched.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      // HIP_CENTER_STABLE 포함 조합은 같은 priority 내에서 항상 후순위
      const aStable = a.key.includes('HIP_CENTER_STABLE');
      const bStable = b.key.includes('HIP_CENTER_STABLE');
      if (aStable !== bStable) return aStable ? 1 : -1;
      const tierDiff = getScoreTier(b.maxScore) - getScoreTier(a.maxScore);
      if (tierDiff !== 0) return tierDiff; // 높은 심각도 먼저
      const scoreDiff = b.maxScore - a.maxScore; // 같은 tier 내에서 raw 점수 높은 쪽 먼저
      if (scoreDiff !== 0) return scoreDiff;
      return a.key.localeCompare(b.key);   // 완전 동일: 결정론적 (알파벳 순)
    });

    // ── 6. 다양성 보장 상위 3개 선정 ─────────────────────────
    // 이미 선택된 두 key가 완전히 겹치는 조합은 건너뜀 (중복 방지)
    const top3: typeof matched = [];
    const usedDbKeys = new Set<string>();
    for (const m of matched) {
      if (top3.length >= 3) break;
      const [kA, kB] = m.key.split('|');
      if (usedDbKeys.has(kA) && usedDbKeys.has(kB)) continue; // 둘 다 이미 노출됨 → 건너뜀
      top3.push(m);
      usedDbKeys.add(kA);
      usedDbKeys.add(kB);
    }
    // 다양한 조합이 부족한 경우 나머지로 채움
    for (const m of matched) {
      if (top3.length >= 3) break;
      if (!top3.some(s => s.key === m.key)) top3.push(m);
    }

    // ── 7. 타이틀 자동 완성 (priority 9 등 "+B" 없는 항목) ────
    const DB_KEY_LABELS: Record<string, string> = {
      HIP_NOT_CENTER_LEFT: '골반 왼쪽 이동', HIP_NOT_CENTER_RIGHT: '골반 오른쪽 이동',
      HIP_CENTER_STABLE: '골반 중심 안정', RIGHT_HIP_HIGHER: '오른쪽 골반 높이 상승', LEFT_HIP_HIGHER: '왼쪽 골반 높이 상승',
      KNEE_INWARD: '양쪽 무릎 밖굽이', KNEE_RIGHT: '오른쪽 무릎 밖굽이 / 왼쪽 무릎 안굽이',
      KNEE_LEFT: '오른쪽 무릎 안굽이 / 왼쪽 무릎 밖굽이', KNEE_OUTWARD: '양쪽 무릎 안굽이',
      ANKLE_RIGHT: '오른쪽 발목 가쪽번짐 / 왼쪽 발목 안쪽번짐', ANKLE_LEFT: '오른쪽 발목 안쪽번짐 / 왼쪽 발목 가쪽번짐',
      ANKLE_INWARD: '양쪽 발목 안쪽번짐', ANKLE_OUTWARD: '양쪽 발목 가쪽번짐',
      FOOT_OUTWARD: '양쪽 발 벌림', FOOT_INWARD: '양쪽 발 모음',
      FOOT_RIGHT: '오른쪽 발 벌림 / 왼쪽 발 정면', FOOT_LEFT: '왼쪽 발 벌림 / 오른쪽 발 정면',
      ARM_UNNORMAL: '양쪽 어깨관절 굽힘 가동범위 제한', RIGHT_ARM_UNNORMAL: '오른쪽 어깨관절 굽힘 가동범위 제한', LEFT_ARM_UNNORMAL: '왼쪽 어깨관절 굽힘 가동범위 제한',
      BODY_LEARN_FORWARD: '상체 과도한 앞으로 숙임', BODY_LEARN_BACKWARD: '상체 과도한 뒤로 젖힘',
      HEEL_UNNORMAL: '양쪽 발뒤꿈치 들림', RIGHT_HEEL_UNNORMAL: '오른쪽 발뒤꿈치 들림', LEFT_HEEL_UNNORMAL: '왼쪽 발뒤꿈치 들림',
    };
    const resolveTitle = (key: string, rawTitle: string): string => {
      const trimmed = rawTitle.trim();
      if (trimmed.includes('+')) return trimmed; // 이미 두 항목 표시됨
      const [kA, kB] = key.split('|');
      // DISEASE_PRIORITY_KEYS 순위가 낮은(중요도 높은) 쪽을 앞에 표기
      const [primary, secondary] = getKeyRank(kA) <= getKeyRank(kB) ? [kA, kB] : [kB, kA];
      if (secondary === 'HIP_CENTER_STABLE') return DB_KEY_LABELS[primary] ?? primary;
      return `${DB_KEY_LABELS[primary] ?? primary} + ${DB_KEY_LABELS[secondary] ?? secondary}`;
    };

    const PRIORITY_COLORS: Record<number, string> = {
      1: 'purple',  // 보라 (골반 이동 핵심)
      2: 'blue',    // 파랑 (골반 높이 비대칭)
      3: 'green',   // 초록 (어깨 가동범위 제한)
      4: 'white',   // 하얀 (무릎 정렬 이상 + 골반 안정 조합)
      5: 'orange',  // 오렌지 (잔여 케이스 fallback)
    };

    return {
      title: '전신 움직임 패턴 연계 시나리오',
      description: '본 내용은 진단이나 치료 목적이 아닌, 동작 수행 시 관찰되는 움직임 패턴을 기능·분류하기 위한 참고입니다.',
      steps: top3.map((s, idx) => ({
        order: idx + 1,
        title: resolveTitle(s.key, s.title),
        themeColor: PRIORITY_COLORS[s.priority] ?? 'gray',
        content: s.content,
      })),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 8대표 운동별 케이스 전략 DB + 빌더
  // ─────────────────────────────────────────────────────────────

  /**
   * 카테고리 키:
   *   arm   → scoreDetail.arm.disease   (NORMAL | ARM_UNNORMAL | LEFT_ARM_UNNORMAL | RIGHT_ARM_UNNORMAL)
   *   body  → scoreDetail.body.disease  (NORMAL | BODY_LEARN_FORWARD | BODY_LEARN_BACKWARD)
   *   heel  → scoreDetail.heel.disease  (NORMAL | HEEL_UNNORMAL | LEFT_HEEL_UNNORMAL | RIGHT_HEEL_UNNORMAL)
   *   ankles→ scoreDetail.ankles.disease (NORMAL | ANKLE_OUTWARD | ANKLE_INWARD | ANKLE_RIGHT | ANKLE_LEFT
   *           + LEFT_ANKLE_INWARD | LEFT_ANKLE_OUTWARD | RIGHT_ANKLE_INWARD | RIGHT_ANKLE_OUTWARD)
   *   hipHigher→ scoreDetail.hipHigher.disease (NORMAL | RIGHT_HIP_HIGHER | LEFT_HIP_HIGHER)
   *
   * 각 엔트리: { isNormal, items[], methods[] }
   *   isNormal=true  → items = 운동 수행 분석, methods = 추천 수정 방법(챌린지)
   *   isNormal=false → items = 운동 수행 제한 요인, methods = 추천 수정 방법
   */

  /**
   * scoreDetail에서 해당 카테고리의 disease 코드를 추출하여
   * EXERCISE_CASE_DB에서 매칭되는 6종 운동 전략을 반환합니다.
   * 우선순위에 따라 첫 번째로 발견된 이상 카테고리만 반환합니다.
   */
  private buildExerciseCases(scoreDetail: any): any {
    // computeOHTCaseNumber의 우선순위와 동일하게 정렬
    const CATEGORY_MAP: Array<{
      category: string;
      label: string;
      sdKey: string;
      resolveDisease?: (sd: any) => string;
    }> = [
      { category: 'hipCenter', label: '골반 좌우 중심 이동', sdKey: 'hipCenter',
        resolveDisease: (sd) => {
          const d = sd?.hipCenter?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d;
        },
      },
      { category: 'foot', label: '발 방향', sdKey: 'foot',
        resolveDisease: (sd) => {
          const d = sd?.foot?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // FOOT_OUTWARD | FOOT_INWARD | FOOT_RIGHT | FOOT_LEFT
                    // | RIGHT_FOOT_OUTWARD | RIGHT_FOOT_INWARD | LEFT_FOOT_OUTWARD | LEFT_FOOT_INWARD
        },
      },
      { category: 'knees', label: '무릎 좌우 이동', sdKey: 'knees',
        resolveDisease: (sd) => {
          const d = sd?.knees?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // KNEE_INWARD | KNEE_OUTWARD | KNEE_RIGHT | KNEE_LEFT
                    // | RIGHT_KNEE_INWARD | RIGHT_KNEE_OUTWARD | LEFT_KNEE_INWARD | LEFT_KNEE_OUTWARD
        },
      },
      { category: 'ankles', label: '발목 내·외측 기울기', sdKey: 'ankles',
        resolveDisease: (sd) => {
          const d = sd?.ankles?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d;
        },
      },
      { category: 'hipHigher', label: '골반 좌우 높이', sdKey: 'hipHigher',
        resolveDisease: (sd) => {
          const d = sd?.hipHigher?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // RIGHT_HIP_HIGHER | LEFT_HIP_HIGHER
        },
      },
      { category: 'arm', label: '팔 위치', sdKey: 'arm',
        resolveDisease: (sd) => {
          const d = sd?.arm?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // ARM_UNNORMAL | LEFT_ARM_UNNORMAL | RIGHT_ARM_UNNORMAL
        },
      },
      { category: 'body', label: '상체 기울기', sdKey: 'body',
        resolveDisease: (sd) => {
          const d = sd?.body?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // BODY_LEARN_FORWARD | BODY_LEARN_BACKWARD
        },
      },
      { category: 'heel', label: '발등 굽힘', sdKey: 'heel',
        resolveDisease: (sd) => {
          const d = sd?.heel?.disease;
          if (!d || d === 'NORMAL') return 'NORMAL';
          return d; // HEEL_UNNORMAL | LEFT_HEEL_UNNORMAL | RIGHT_HEEL_UNNORMAL
        },
      },
    ];

    const EXERCISE_NAMES: Array<{ key: string; name: string; assetKey: string }> = [
      { key: 'squat', name: '스쿼트', assetKey: 'CASE_SQUAT' },
      { key: 'lunge', name: '런지', assetKey: 'CASE_LUNGE' },
      { key: 'plank', name: '플랭크', assetKey: 'CASE_PLANK' },
      { key: 'curlUp', name: '컬업', assetKey: 'CASE_CURL_UP' },
      { key: 'clam', name: '클램', assetKey: 'CASE_CLAM' },
      { key: 'hamstring', name: '햄스트링 스트레칭', assetKey: 'CASE_HAMSTRING' },
    ];

    // 우선순위에 따라 첫 번째로 발견된 이상 카테고리만 사용
    let selectedCategory: any = null;
    for (const cat of CATEGORY_MAP) {
      const disease = cat.resolveDisease
        ? cat.resolveDisease(scoreDetail)
        : (scoreDetail?.[cat.sdKey]?.disease ?? 'NORMAL');
      
      if (disease === 'NORMAL') continue;
      
      const dbKey = `${cat.category}:${disease}`;
      const entry = EXERCISE_CASE_DB[dbKey];
      if (!entry) continue;

      const exercises = EXERCISE_NAMES.map((ex) => {
        const e = (entry as any)[ex.key];
        if (!e) return null;
        return {
          exerciseName: ex.name,
          assetKey: ex.assetKey,
          url: this.resolveOHTExerciseUrl(ex.assetKey),
          strategy: {
            isNormal: e.isNormal,
            movementAnalysis: e.items,
            recommendedMethod: e.methods,
          },
        };
      }).filter(Boolean);

      selectedCategory = {
        //categoryLabel: cat.label,
        diseaseCode: disease,
        exercises,
      };
      break; // 첫 번째 이상 카테고리만 사용
    }

    return {
      title: '대표 운동별 케이스 기반 수행 특성 및 조절 전략',
      description: '현재 움직임 패턴을 바탕으로 대표 운동을 보다 효율적으로 수행하기 위한 조절 전략입니다.',
      categories: selectedCategory ? [selectedCategory] : [],
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 정면 동작 패턴 분석: FRONT_PATTERN_DB + buildFrontPatternAnalysis
  // ─────────────────────────────────────────────────────────────


  /**
   * scoreDetail에서 골반 중심(hipCenter), 발 방향(foot), 무릎 정렬(knees)의
   * disease를 읽어 FRONT_PATTERN_DB 기반으로 정면 패턴 분석 섹션을 동적 생성합니다.
   */

  public buildFrontPatternAnalysis(scoreDetail: any, filesByDiv: Record<string, string> = {}): any {
    const getSection = (category: string, dbKey: string, sectionTitle: string, imgNum: number) => {
      const entry = FRONT_PATTERN_DB[`${category}:${dbKey}`];
      if (!entry) return null;
      return {
        title: sectionTitle,
        image: { url: `${OHT_IMG_BASE}/${imgNum}.png` },
        stateAnalysis: entry.stateAnalysis,
        movementPatternAnalysis: entry.movementPatternAnalysis,
        optimizationStrategy: entry.optimizationStrategy,
      };
    };

    // 골반 중심 상태
    const hipDisease: string = scoreDetail?.hipCenter?.disease ?? 'NORMAL';
    const hipDbKey = hipDisease;

    // 발 방향 정렬
    const footDisease: string = scoreDetail?.foot?.disease ?? 'NORMAL';

    // 무릎 정렬 패턴
    const kneesDisease: string = scoreDetail?.knees?.disease ?? 'NORMAL';

    const sections = [
      getSection('hipCenter', hipDbKey, '골반 중심 상태', 1),
      getSection('foot', footDisease, '발 방향 정렬', 2),
      getSection('knees', kneesDisease, '무릎 정렬 패턴', 3),
    ].filter(Boolean);

    const allNormal =
      hipDisease === 'NORMAL' &&
      footDisease === 'NORMAL' &&
      kneesDisease === 'NORMAL';

    return {
      title: '정면 동작 패턴 분석 및 동작 최적화 전략',
      images: {
        photo: { assetKey: 'FRONT_PATTERN_PHOTO', url: filesByDiv['END_FRONT'] ?? null },
        analysisImage: { assetKey: 'FRONT_PATTERN_ANALYSIS', url: `${OHT_IMG_BASE}/over_head_front.png` },
      },
      centerLine: {
        bodyCenterLineLabel: '몸의 중심선',
        observation: allNormal
          ? '양측 하체 사용 비율이 균형 잡힌 상태'
          : '중심선 기준 좌우 하체 사용량 차이 관찰',
      },
      sections,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 후면 동작 패턴 분석: REAR_PATTERN_DB + buildRearPatternAnalysis
  // ─────────────────────────────────────────────────────────────


  /**
   * scoreDetail에서 발목 지지 패턴(ankles)과 골반 수평 정렬(hipHigher)의
   * disease를 읽어 REAR_PATTERN_DB 기반으로 후면 패턴 분석 섹션을 동적 생성합니다.
   */
  public buildRearPatternAnalysis(scoreDetail: any, filesByDiv: Record<string, string> = {}): any {
    const getSection = (category: string, disease: string, sectionTitle: string, imgNum: number) => {
      const entry = REAR_PATTERN_DB[`${category}:${disease}`];
      if (!entry) return null;
      return {
        title: sectionTitle,
        image: { url: `${OHT_IMG_BASE}/${imgNum}.png` },
        stateAnalysis: entry.stateAnalysis,
        movementPatternAnalysis: entry.movementPatternAnalysis,
        optimizationStrategy: entry.optimizationStrategy,
      };
    };

    const anklesDisease: string = scoreDetail?.ankles?.disease ?? 'NORMAL';
    const hipHigherDisease: string = scoreDetail?.hipHigher?.disease ?? 'NORMAL';

    const sections = [
      getSection('ankles', anklesDisease, '발목 지지 패턴', 4),
      getSection('hipHigher', hipHigherDisease, '골반 수평 정렬', 5),
    ].filter(Boolean);

    return {
      title: '후면 동작 패턴 분석 및 동작 최적화 전략',
      images: {
        photo: { assetKey: 'REAR_PATTERN_PHOTO', url: filesByDiv['END_BACK'] ?? null },
        analysisImage: { assetKey: 'REAR_PATTERN_ANALYSIS', url: `${OHT_IMG_BASE}/over_head_back.png` },
      },
      sections,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 관절별 가동범위 리포트: JOINT_ROM_CONTENT_DB + buildJointRomContent
  // ─────────────────────────────────────────────────────────────


  /**
   * 관절별 가동범위 주요 원인: key(좌/우/동작) 기준 오버라이드
  * - report.type 단위 기본 템플릿 위에 key 기반 문구를 덮어씁니다.
  * - 이미지는 엑셀의 생활 패턴 번호와 title 기반으로 직접 매핑합니다.
   */
  private resolveRomMainCauseTitles(key: string): string[] | null {
    const k = String(key || '').toLowerCase();

    // Neck
    if (k.includes('neck') && k.includes('lateral') && k.includes('right')) {
      return [
        '옆으로 눕는 수면자세 (왼쪽이 아래)',
        '왼손으로 턱 괴는 습관',
        '머리카락 왼쪽으로 넘기는 습관',
        '왼쪽 방향 가방 착용 습관',
        '전화기 왼쪽 어깨로 끼우기',
      ];
    }
    if (k.includes('neck') && k.includes('lateral') && k.includes('left')) {
      return [
        '옆으로 눕는 수면자세 (오른쪽이 아래)',
        '오른손으로 턱 괴는 습관',
        '머리카락 오른쪽으로 넘기는 습관',
        '오른쪽 방향 가방 착용 습관',
        '전화기 오른쪽 어깨로 끼우기',
      ];
    }
    if (k.includes('neck') && k.includes('rotation') && k.includes('right')) {
      return [
        '듀얼 모니터 왼쪽 편중 배치',
        '옆으로 눕는 수면자세 (왼쪽이 아래)',
        '왼쪽으로 고개를 돌린 수면자세',
      ];
    }
    if (k.includes('neck') && k.includes('rotation') && k.includes('left')) {
      return [
        '듀얼 모니터 오른쪽 편중 배치',
        '옆으로 눕는 수면자세 (오른쪽이 아래)',
        '오른쪽으로 고개를 돌린 수면자세',
      ];
    }
    if (k.includes('neck') && k.includes('flexion')) {
      return [
        '테이블에 팔꿈치를 대고 몸을 기댄 자세',
        '구부정하게 앉은 자세',
        '장시간 책상 업무 자세 유지',
      ];
    }
    if (k.includes('neck') && k.includes('extension')) {
      return [
        '고개 숙임 중심의 업무 환경',
        '고개 숙인 상태의 장시간 휴대폰 사용',
        '낮은 모니터 위치(노트북 사용 환경)',
        '과도하게 높은 베개 사용',
      ];
    }

    // Shoulder (좌/우 동일)
    if (k.includes('shoulder') && k.includes('abduction')) {
      return [
        '낮은 모니터 위치(노트북 사용 환경)',
        '구부정한 앉은 자세',
        '지나치게 낮은 의자 사용',
        '무거운 가방 착용',
      ];
    }
    if (k.includes('shoulder') && k.includes('adduction')) {
      return [
        '장시간 컴퓨터 사용',
        '구부정하게 앉은 자세 / 웅크린 자세',
        '한쪽으로 수면',
        '한쪽으로 기대어 앉는 습관',
      ];
    }
    if (k.includes('shoulder') && k.includes('flexion')) {
      return [
        '낮은 모니터 위치(노트북 사용 환경)',
        '구부정한 앉은 자세',
        '지나치게 낮은 의자 사용',
        '무거운 가방 착용',
      ];
    }
    if (k.includes('shoulder') && k.includes('extension')) {
      return [
        '장시간 책상 업무 자세 유지',
        '장시간 운전',
        '구부정한 앉은 자세',
        '손으로 무거운 물건 반복 운반',
      ];
    }
    if (k.includes('shoulder') && k.includes('internal') && k.includes('rotation')) {
      return [
        '과도한 등 펴기',
        '과도한 바른자세 강박 (과도한 등·허리 펴기)',
        '과도한 등 근력운동',
      ];
    }
    if (k.includes('shoulder') && k.includes('external') && k.includes('rotation')) {
      return [
        '낮은 모니터 위치(노트북 사용 환경)',
        '구부정한 앉은 자세',
        '옆으로 눕는 수면자세',
        '지나치게 낮은 의자 사용',
      ];
    }

    // Elbow (좌/우 동일)
    if (k.includes('elbow') && k.includes('flexion')) {
      return [
        '체중을 팔꿈치로 지탱하는 습관',
        '팔 지지 운동 시 팔꿈치 잠금 고정 (푸쉬업 등)',
      ];
    }
    if (k.includes('elbow') && k.includes('extension')) {
      return [
        '키보드 과도하게 가까운 배치',
        '손으로 무거운 물건 반복 운반',
        '고개 숙인 상태의 장시간 휴대폰 사용',
      ];
    }

    // Trunk
    if (k.includes('trunk') && k.includes('lateral') && k.includes('right')) {
      return [
        '오른쪽 방향 가방 착용 습관',
        '다리 꼬기',
        '짝다리 지지',
        '왼쪽으로 기대어 앉는 습관',
      ];
    }
    if (k.includes('trunk') && k.includes('lateral') && k.includes('left')) {
      return [
        '왼쪽 방향 가방 착용 습관',
        '다리 꼬기',
        '짝다리 지지',
        '오른쪽으로 기대어 앉는 습관',
      ];
    }
    if (k.includes('trunk') && k.includes('rotation') && k.includes('right')) {
      return [
        '몸통만 사용하는 회전 습관 (왼쪽 회전)',
        '회전의자 사용',
        '회전 운동 편중 (골프·테니스 등)',
      ];
    }
    if (k.includes('trunk') && k.includes('rotation') && k.includes('left')) {
      return [
        '몸통만 사용하는 회전 습관 (오른쪽 회전)',
        '회전의자 사용',
        '회전 운동 편중 (골프·테니스 등)',
      ];
    }
    if (k.includes('trunk') && k.includes('flexion')) {
      return [
        '골반을 뒤로 빼고 허리를 꺾어 앉기',
        '지나치게 높은 의자 사용',
        '과도한 바른자세 강박 (과도한 등·허리 펴기)',
        '잦은 하이힐 착용',
      ];
    }
    if (k.includes('trunk') && k.includes('extension')) {
      return [
        '골반을 앞으로 빼고 등받이에 기대앉기',
        '지나치게 낮은 의자 사용',
        '장시간 운전',
      ];
    }

    // Hip
    if (k.includes('hip') && k.includes('abduction') && k.includes('right')) {
      return [
        '짝다리 지지 (오른쪽)',
        '회전의자 사용',
        '다리꼬기',
        '안짱걸음',
      ];
    }
    if (k.includes('hip') && k.includes('abduction') && k.includes('left')) {
      return [
        '짝다리 지지 (왼쪽)',
        '회전의자 사용',
        '다리꼬기',
        '안짱걸음',
      ];
    }
    if (k.includes('hip') && k.includes('adduction') && k.includes('right')) {
      return [
        '짝다리 지지 (왼쪽)',
        '회전의자 사용',
        '장시간 양반다리',
        '의자에 다리 간격을 넓게 두고 앉는 자세',
      ];
    }
    if (k.includes('hip') && k.includes('adduction') && k.includes('left')) {
      return [
        '짝다리 지지 (오른쪽)',
        '회전의자 사용',
        '장시간 양반다리',
        '의자에 다리 간격을 넓게 두고 앉는 자세',
      ];
    }
    if (k.includes('hip') && k.includes('external') && k.includes('rotation')) {
      return [
        '다리 꼬기',
        '회전의자 사용',
        '안짱걸음',
        '테니스,골프등 회전운동',
        '무릎을 붙이고 종아리를 바깥으로 두는 앉은 자세',
      ];
    }
    if (k.includes('hip') && k.includes('internal') && k.includes('rotation')) {
      return [
        '장시간 양반다리',
        '팔자걸음',
        '회전의자 장시간 사용',
        '테니스,골프 등 회전운동',
      ];
    }
    if (k.includes('hip') && k.includes('flexion')) {
      return [
        '골반을 앞으로 내밀고 서있기',
        '다리꼬기',
        '장시간 양반다리',
      ];
    }
    if (k.includes('hip') && k.includes('extension')) {
      return [
        '낮은의자에 앉은자세',
        '장시간 운전',
        '장시간 쪼그려 앉기',
      ];
    }

    // Knee (좌/우 동일)
    if (k.includes('knee') && k.includes('flexion')) {
      return [
        '잦은 하이힐 착용',
        '과도한 바른자세 강박 (과도한 등·허리 펴기)',
        '다리꼬기',
      ];
    }
    if (k.includes('knee') && k.includes('extension')) {
      return [
        '낮은의자에 앉은자세',
        '장시간 쪼그려 앉기',
        '장시간 운전',
      ];
    }

    // Ankle
    if (k.includes('ankle') && k.includes('inversion') && k.includes('right')) {
      return ['발 안쪽 체중 지지', '짝다리 지지 (왼쪽)'];
    }
    if (k.includes('ankle') && k.includes('inversion') && k.includes('left')) {
      return ['발 안쪽 체중 지지', '짝다리 지지 (오른쪽)'];
    }
    if (k.includes('ankle') && k.includes('eversion') && k.includes('right')) {
      return ['발 바깥쪽 체중 지지', '짝다리 지지 (오른쪽)'];
    }
    if (k.includes('ankle') && k.includes('eversion') && k.includes('left')) {
      return ['발 바깥쪽 체중 지지', '짝다리 지지 (왼쪽)'];
    }
    if (k.includes('ankle') && k.includes('dorsiflexion')) {
      return [
        '잦은 하이힐 착용',
        '과도한 바른자세 강박 (과도한 등·허리 펴기)',
        '발의 가쪽으로 체중싣기',
        '발 안쪽 체중 지지',
      ];
    }
    if (k.includes('ankle') && k.includes('plantarflexion')) {
      return [
        '골반을 앞으로 내밀고 서있기',
        '장시간 쪼그려 앉기',
        '발의 가쪽으로 체중싣기',
        '발 안쪽 체중 지지',
      ];
    }

    return null;
  }

  private buildJointRomContent(report: any): any {
    const type: string = report.type ?? '';
    const romInfo = report.analysisData?.romInfo || {};
    const measuredAngle: number = Math.round(romInfo.measuredAngle ?? 0);
    const normalAngle: number = Math.round(romInfo.normalAngle ?? 0);
    const romDiff: number = romInfo.romDiff ?? 0;
    const name: string = report.name || report.type || '';
    const levelLabel = this.getRomLevelLabel(report.level || '');
    const c = JOINT_ROM_CONTENT_DB[type];

    if (!c) {
      return {
        movementDetail: { title: '관절 및 움직임별 상세', compensationMotionWhenRestricted: null, dailyUseExamples: null, relatedCondition: null },
        mainCauses: null,
        commentSection: { title: 'COMMENT', comment: `${name} 가동범위가 ${levelLabel} 단계로 분류됩니다.`, futureProgramDirection: null, improvementGoal: null },
        recommendedDailyRoutine: null,
        expectedEffect: null,
      };
    }

    const mainCauseOverrideTitles = this.resolveRomMainCauseTitles(report.key ?? '');
    const mainCauseItems = mainCauseOverrideTitles && mainCauseOverrideTitles.length > 0
      ? mainCauseOverrideTitles.map((title, idx) => ({
          title,
          assetKey: this.resolveRomCauseAssetKeyByTitle(title)
            ?? c.mainCauseItems[idx]?.assetKey
            ?? c.mainCauseItems[0]?.assetKey
            ?? `ROM_CAUSE_CUSTOM_${idx + 1}`,
        }))
      : c.mainCauseItems;

    const movementDetailOverride = this.resolveRomMovementDetailOverride(report.key ?? '');
    const compensationItems = movementDetailOverride?.compensationItems ?? c.compensationItems;
    const dailyUseItems = movementDetailOverride?.dailyUseItems ?? c.dailyUseItems;
    const conditionTitleOverride = this.resolveRomConditionTitles(report.key ?? '');
    const conditionIconNumbers = this.resolveRomConditionIconNumbers(report.key ?? '');
    const relatedConditionItems = conditionTitleOverride && conditionTitleOverride.length > 0
      ? conditionTitleOverride.map((title, idx) => ({
          title,
          themeColor: ['pink', 'blue', 'gray', 'gray'][idx] ?? 'gray',
          iconKey: c.relatedConditionItems[idx]?.iconKey ?? c.relatedConditionItems[0]?.iconKey ?? 'ROM_CONDITION_GENERIC',
          iconNumber: conditionIconNumbers?.[idx] ?? null,
        }))
      : c.relatedConditionItems.map((item: any, idx: number) => ({
          ...item,
          iconNumber: conditionIconNumbers?.[idx] ?? null,
        }));
    const routineExpectedOverride = this.resolveRomRoutineAndExpectedEffectOverride(report.key ?? '');
    const routineItems = routineExpectedOverride && routineExpectedOverride.routineItems.length > 0
      ? routineExpectedOverride.routineItems.map((item, idx) => ({
          order: c.routineItems[idx]?.order ?? idx + 1,
          name: item.name,
          assetKey: item.assetKey,
        }))
      : c.routineItems;
    const expectedEffectContent = routineExpectedOverride?.expectedEffect ?? c.expectedEffect;

    const causesList = mainCauseItems.slice(0, 2).map(i => i.title).join(', ');
    const dailyList = dailyUseItems.slice(0, 2).map(i => i.title).join(', ');
    const conditionList = relatedConditionItems.slice(0, 2).map(i => i.title).join(', ');
    const absDiff = Math.abs(Math.round(romDiff));

    const levelDescMap: Record<string, string> = {
      '매우 심각': '관절 움직임이 일상 기능 수행에까지 영향을 주는',
      '심각': '관절 가동범위 부족으로 특정 동작에서 보상이 반복되는',
      '주의': '가동범위 여유가 부족해 관리 여부에 따라 제한이 심화될 수 있는',
      '경미': '일상 동작은 가능하나 가동범위 여유가 감소한',
      '양호': '정상 가동범위 내에서 안정적으로 움직임이 유지되는',
    };
    const levelDesc = levelDescMap[levelLabel] ?? '';
    const levelWithDesc = levelDesc ? levelDesc : levelLabel;

    const comment = normalAngle > 0
      ? (() => {
          const introLines = [
            `회원님의 <b>${name}</b> 가동범위는 현재 <b>${measuredAngle}°</b>로 측정되었습니다.`,
            `정상적인 움직임에서 활용되는 범위를 기준으로 보면, <b>${name}</b>은 약 <b>${normalAngle}°</b>까지 사용되는 경우가 일반적입니다.`,
            `이에 따라 정상 가동범위 기준과 비교했을 때 현재 <b>${absDiff}°</b> 정도의 가동범위 편차가 확인됩니다.`,
          ].join('\n');

          if (levelLabel === '양호') {
            return `${introLines}\n\n현재 상태는 전반적인 움직임 평가 기준에서 <b>${levelWithDesc}</b> 단계로 판단되며, 이에 따라 현재 상태에 적합한 관리 방향을 아래와 같이 안내드립니다.`;
          }

          return `${introLines}\n\n해당 가동범위의 변화는 일상생활에서 반복되는 <b>${causesList}</b> 등과 같은 생활습관과 연관되어 나타나는 경우가 많습니다.\n\n이러한 움직임 감소는 일상생활에서 <b>${dailyList}</b> 등과 같은 사용 패턴으로 나타나며, 그 결과 <b>${conditionList}</b> 등의 불편감으로 이어질 수 있습니다.\n\n현재 상태는 전반적인 움직임 평가 기준에서 <b>${levelWithDesc}</b> 단계로 판단되며, 이에 따라 현재 상태에 적합한 관리 방향을 아래와 같이 안내드립니다.`;
        })()
      : `${name} 가동범위가 ${levelWithDesc} 단계로 분류됩니다.`;

    return {
      movementDetail: {
        title: '관절 및 움직임별 상세',
        compensationMotionWhenRestricted: {
          title: '가동범위 사용 변화에 따른 움직임 패턴',
          description: c.compensationMotionDesc,
          items: compensationItems.map(i => ({ title: i.title, themeColor: i.themeColor, image: { assetKey: i.assetKey, url: this.resolveRomCompensationUrl(i.assetKey) } })),
        },
        dailyUseExamples: {
          title: '일상 동작에서 나타날 수 있는 움직임 사용 예시',
          items: dailyUseItems.map(i => ({ title: i.title, themeColor: i.themeColor })),
        },
        relatedCondition: {
          title: '가동범위 사용 변화와 함께 느껴질 수 있는 체감 변화',
          items: relatedConditionItems.map((i: any) => ({
            title: i.title,
            themeColor: i.themeColor,
            iconKey: i.iconKey,
            image: i.iconNumber != null
              ? { assetKey: `ROM_CONDITION_ICON_${i.iconNumber}`, url: this.resolveRomConditionIconUrl(i.iconNumber) }
              : null,
          })),
        },
      },
      mainCauses: {
        title: '해당 가동범위 제한의 주요 원인',
        subTitle: '가동범위 제한 관련 생활 패턴',
        rightCaption: c.mainCausesRightCaption,
        items: mainCauseItems.map(i => ({ title: i.title, image: { assetKey: i.assetKey, url: this.resolveRomCauseUrl(i.assetKey) } })),
      },
      commentSection: {
        title: 'COMMENT',
        comment,
        futureProgramDirection: {
          title: '앞으로 프로그램의 방향',
          content: c.futureProgramDirection,
        },
        improvementGoal: {
          title: '중점 개선 목표',
          content: c.improvementGoal,
        },
      },
      recommendedDailyRoutine: {
        title: '추천 생활 루틴',
        items: routineItems.map(i => ({ order: i.order, name: i.name, image: { assetKey: i.assetKey, url: this.resolveRomRoutineUrl(i.assetKey) } })),
      },
      expectedEffect: {
        title: '기대효과',
        content: expectedEffectContent,
      },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 측면 동작 패턴 분석: SIDE_PATTERN_DB + buildSidePatternAnalysis
  // ─────────────────────────────────────────────────────────────


  /**
   * scoreDetail에서 어깨 굽힘 가동범위(arm), 상체 기울기(body), 발등굽힘 가동범위(heel)의
   * disease를 읽어 SIDE_PATTERN_DB 기반으로 측면 패턴 분석 섹션을 동적 생성합니다.
   * 발등굽힘(heel)은 측정 disease와 무관하게 항상 NORMAL 문구를 사용합니다.
   */
  public buildSidePatternAnalysis(scoreDetail: any, filesByDiv: Record<string, string> = {}): any {
    const getSection = (category: string, disease: string, sectionTitle: string, imgNum: number) => {
      const entry = SIDE_PATTERN_DB[`${category}:${disease}`];
      if (!entry) return null;
      return {
        title: sectionTitle,
        image: { url: `${OHT_IMG_BASE}/${imgNum}.png` },
        stateAnalysis: entry.stateAnalysis,
        movementPatternAnalysis: entry.movementPatternAnalysis,
        optimizationStrategy: entry.optimizationStrategy,
      };
    };

    const armDisease: string = scoreDetail?.arm?.disease ?? 'NORMAL';
    const bodyDisease: string = scoreDetail?.body?.disease ?? 'NORMAL';

    const sections = [
      getSection('arm', armDisease, '어깨 굽힘 가동범위', 6),
      getSection('body', bodyDisease, '상체 기울기 조절', 7),
      // 발등굽힘: 측정값과 무관하게 상태분석·동작패턴·최적화 문구는 항상 정상(NORMAL) 기준
      getSection('heel', 'NORMAL', '발목 발등굽힘 가동범위', 8),
    ].filter(Boolean);

    return {
      title: '측면 동작 패턴 분석 및 동작 최적화 전략',
      topImages: {
        left: { label: '왼쪽', photoAssetKey: 'SIDE_LEFT_PHOTO', photoUrl: filesByDiv['END_LEFT'] ?? null, referenceUrl: `${OHT_IMG_BASE}/over_head_left.png` },
        right: { label: '오른쪽', photoAssetKey: 'SIDE_RIGHT_PHOTO', photoUrl: filesByDiv['END_RIGHT'] ?? null, referenceUrl: `${OHT_IMG_BASE}/over_head_right.png` },
      },
      sections,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 척추정렬검사 전굴 관련 헬퍼 메서드
  // ─────────────────────────────────────────────────────────────

  /** coreStructure.blocks[0]: 골반 기준 상체 중심 설명 */
  private buildBodyCenterBlockDescription(bodyCenter: any): string {
    const isNormal = !bodyCenter || Math.abs(bodyCenter.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX;
    if (isNormal) return '골반 기준으로 한 상체 중심은\n <b>골반과 수직선상에 놓인</b> 흐름으로 관찰되며,';
    const dir = (bodyCenter.result ?? 0) > 0 ? '오른쪽' : '왼쪽';
    return `골반 기준으로 한 상체 중심은\n <b>${dir}으로 이동한</b> 흐름으로 관찰되며,`;
  }

  /** coreStructure.blocks[1]: 발 기준 골반 중심 설명 */
  private buildLegUsageBlockDescription(legUsage: any): string {
    if (!legUsage) return '발 기준 골반 중심 데이터를 측정할 수 없습니다.';
    if (legUsage.dominantSide === '균형') return '발을 기준으로 한 골반 중심은\n <b>정중앙에 위치한</b> 양상으로 나타납니다.';
    return `발을 기준으로 한 골반 중심은\n <b>${legUsage.dominantSide}으로 이동한</b> 양상으로 나타납니다.`;
  }

  /** bodyChangeInsights.sections[0].summary: 하체 정렬 요약 */
  private buildLowerBodySummary(pelvicReaction: any, legUsage: any): string {
    const pelvicText = pelvicReaction
      ? (pelvicReaction.isNormal
          ? '굽힘 자세에서 골반 높이는 좌우 균형이 관찰되며'
          : `굽힘 자세에서 골반 높이는 <b>${pelvicReaction.higherSide}이 상대적으로 높은</b> 양상으로 나타나며`)
      : '굽힘 자세에서 골반 높이 측정을 위한 전굴 사진이 필요하며';

    const legText = legUsage
      ? (legUsage.dominantSide === '균형'
          ? '다리 사용 패턴은 균형적인 경향으로 관찰됩니다.'
          : `동시에 다리 사용 패턴은 <b>${legUsage.dominantSide} 다리 사용이 두드러지는</b> 경향으로 관찰됩니다.`)
      : '다리 사용 측정을 위한 발목 랜드마크 데이터가 필요합니다.';

    return `${pelvicText}, ${legText}\n이러한 특징은 아래와 같은 방향의 점진적인 변화로 이어질 수 있습니다.`;
  }

  /**
   * 전굴 관찰 코멘트 생성 (문장1 + 문장2)
   *
   * as-is 기반: centerShoulderHip(상체 중심 이동), higherShoulder(어깨/척추 라인) disease 사용
   */
  private buildForwardBendComment(
    centerShoulderHip: any,
    higherShoulder: any,
    pelvicReaction?: any,
    centerShiftPxPerCm?: number,
  ): string {
    const sentence1 = this.buildForwardBendSentence1(centerShoulderHip, higherShoulder, pelvicReaction, centerShiftPxPerCm);
    const sentence2 = this.buildForwardBendSentence2(centerShoulderHip, higherShoulder, pelvicReaction);
    return `${sentence1}\n\n${sentence2}`;
  }

  private buildForwardBendSentence1(
    centerShoulderHip: any,
    higherShoulder: any,
    pelvicReaction?: any,
    centerShiftPxPerCm?: number,
  ): string {
    // 상체 중심 이동 방향
    const centerDist = centerShiftPxPerCm
      ? formatCenterShiftDistanceCm(centerShoulderHip?.result ?? 0, centerShiftPxPerCm)
      : Number(Math.abs(centerShoulderHip?.result ?? 0).toFixed(1));
    const centerIsZero = !centerShoulderHip || Math.abs(centerShoulderHip?.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX;
    const centerDir = (centerShoulderHip?.result ?? 0) >= 0 ? '오른쪽' : '왼쪽';
    const line1 = centerIsZero
      ? `골반 중심선 대비 몸통이 <b>수직으로 정렬된</b> 상태를 보이며 상체 무게중심의 <b>안정성</b>이 있을 가능성이 높으며`
      : `골반 중심선 대비 몸통이 <b>${centerDist}</b>cm만큼 <b>${centerDir}으로 이동한</b> 상태를 보이며 상체 무게중심의 <b>치우침</b>이 있을 가능성이 높으며`;

    // 숙일 때 골반 반응
    const pelvicNormal = !pelvicReaction || pelvicReaction.isNormal;
    const pelvicAngle = Math.abs(pelvicReaction?.result ?? 0).toFixed(0);
    const line2 = pelvicNormal
      ? `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>좌우</b> 골반이 <b>평행한</b> 경향이 관찰되었습니다.`
      : `이와 함께 숙이는 동작에서 골반의 수평 정렬을 측정한 결과 <b>${pelvicReaction.higherSide}</b> 골반이 반대측보다 <b>${pelvicAngle}°만큼 높아진</b> 경향이 관찰되었습니다.`;

    // 척추 라인 방향 (어깨 높은 쪽 = 척추가 휘는 방향)
    const shoulderNormal = !higherShoulder || higherShoulder.disease === 'NORMAL';
    const spineDir = shoulderNormal ? '수직' : higherShoulder.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';
    const line3 = `동시에 척추 배열이 <b>${spineDir}</b> 방향의 흐름을 보이며, 움직임 과정에서 좌우 사용 패턴의 차이가 관찰될 수 있고,`;

    // 등 높이 차이 방향 + 각도
    const backSide = shoulderNormal ? '양쪽 대칭' : spineDir;
    const backState1 = shoulderNormal ? '균형을 유지하는 양상이' : '더 높게 솟아오르는 양상이';
    const backState2 = shoulderNormal ? '안정적인 척추 정렬이' : '척추의 입체적인 정렬 변화가';
    const line4 = shoulderNormal
      ? `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`
      : `최종적으로는 상체를 숙였을 때 등 뒤쪽이 <b>${backSide}</b>으로 <b>${backState1}</b> 확인되어, 이에 따라 <b>${backState2}</b> 동반되었을 가능성이 분석됩니다.`;

    return [line1, line2, line3, line4].join('\n');
  }

  private buildForwardBendSentence2(centerShoulderHip: any, higherShoulder: any, pelvicReaction?: any): string {
    const abnormalA = !!(centerShoulderHip && centerShoulderHip.disease !== 'NORMAL'); // 상체 중심 이동
    const abnormalB = !!(pelvicReaction && !pelvicReaction.isNormal);                  // 골반 반응
    const abnormalC = !!(higherShoulder && higherShoulder.disease !== 'NORMAL');        // 어깨/척추 라인

    const count = [abnormalA, abnormalB, abnormalC].filter(Boolean).length;

    if (count === 0) {
      return '현재 외형적으로는 전반적인 신체 축이 수직으로 견고하게 정렬된 양상을 보이며, 하중 분산 능력이 매우 안정적일 가능성이 높게 분석됩니다.\n다만, 이러한 정적 정렬이 실제 움직임이나 생활 습관 속에서도 유지되고 있는지 확인이 필요합니다. 이어지는 리포트를 통해, 보이지 않는 곳에서 정렬을 위협하는 미세한 습관이 있는지 점검하여 현재의 완벽한 균형을 유지하시길 권장합니다.';
    }
    if (count === 1) {
      if (abnormalA) {
        return '골반 중심축을 기준으로 상체가 한쪽으로 밀려 있는 양상을 보이며, 이는 서 있거나 움직일 때 체중이 특정 측면에만 과하게 실리고 있을 가능성을 시사합니다.\n척추의 직접적인 회전은 적으나 중심축 자체가 쏠려 있어, 특정 관절에만 누적 스트레스가 쌓이기 쉬운 경향을 보입니다.';
      }
      if (abnormalB) {
        return '상체를 숙였을 때 양쪽 골반의 수평 정렬이 어긋나는 양상이 확인되며, 이는 골반을 지지하는 하체 근육의 길이가 서로 다르거나 기능적 비대칭이 있을 가능성이 분석됩니다.\n골반의 수평이 맞지 않으면 척추의 뿌리가 흔들리는 것과 같아 추후 허리 주변의 불편함으로 전이될 경향이 있습니다.';
      }
      // abnormalC
      return '숙인 자세에서 한쪽 등이 반대측보다 솟아오르는 양상을 보이며, 이는 단순히 어깨가 높은 것이 아니라 척추가 입체적으로 회전하며 구조적인 정렬 변화를 동반했을 가능성을 보여줍니다.\n척추의 회전은 호흡 효율을 떨어뜨리고 한쪽 근육만 쉽게 뭉치게 만드는 경향이 있어 주의가 필요합니다.';
    }
    if (count === 2) {
      if (abnormalA && abnormalB) {
        return '골반의 수평이 어긋나면서 그 위의 상체 중심축까지 한쪽으로 밀려 있는 양상이 확인되며, 이는 신체 하부의 불안정이 상체의 위치 변화를 유도했을 가능성이 높게 분석됩니다.\n무게중심이 한쪽으로 쏠린 상태가 지속되면 엉덩관절과 허리 관절에 비대칭적인 하중이 가해질 경향이 있습니다.';
      }
      if (abnormalB && abnormalC) {
        return '숙인 자세에서 골반의 수평이 맞지 않음과 동시에 등의 높낮이 차이가 관찰되는 것은, 골반의 기울기가 척추의 입체적인 회전 변화로까지 이어졌을 가능성을 시사합니다.\n척추의 뿌리인 골반부터 상부 흐름까지 전반적인 정렬 양상이 변해 있을 경향이 있어 주의가 필요합니다.';
      }
      // abnormalA && abnormalC
      return '척추가 입체적으로 회전하며 등이 솟아오른 양상과 함께 상체 무게중심이 정중선을 벗어난 흐름이 확인되어, 상부의 정렬 변화가 전체적인 체중 분포에 영향을 주고 있을 가능성이 분석됩니다.\n이러한 경향은 일상 움직임 시 특정 방향의 근육과 관절에만 과도한 긴장을 유발할 수 있습니다.';
    }
    // count === 3
    return '골반 수평과 상체 중심축, 등 높이 모두에서 정렬 변화가 포착되어 신체 하부의 불안정이 상부로 전이되었을 가능성이 높게 분석됩니다.\n이러한 전신 비대칭 양상은 관절 스트레스를 누적시킬 경향이 있으므로, 전문 트레이너를 통해 정확한 원인을 파악하고 개인별 정렬 최적화 트레이닝을 시작할 것을 강력히 권장합니다.';
  }

  /**
   * 전굴 관찰 이미지 변형 코드 (1-9)
   *
   * 두 차원:
   *   D1: 상체 중심 이동 방향 (중앙=0, 오른쪽=1, 왼쪽=2)  ← centerShoulderHip.disease
   *   D2: 어깨 높이 방향 (수직=0, 왼쪽 높음=1, 오른쪽 높음=2)  ← higherShoulder.disease
   * 조합: (D1*3 + D2) + 1  → 1~9
   */
  private getForwardBendObservationVariant(centerShoulderHip: any, higherShoulder: any): number {
    const d1 = !centerShoulderHip || centerShoulderHip.disease === 'NORMAL' ? 0
      : (centerShoulderHip.result ?? 0) > 0 ? 1 : 2;
    // D2: 정상=0, 왼쪽 높음(SPINE_CURVED_LEFT)=1, 오른쪽 높음(SPINE_CURVED_RIGHT)=2
    const d2 = !higherShoulder || higherShoulder.disease === 'NORMAL' ? 0
      : higherShoulder.disease === 'SPINE_CURVED_LEFT' ? 1 : 2;

    return d1 * 3 + d2 + 1; // 1-9
  }

  // ─────────────────────────────────────────────────────────────
  // 정렬 특성에 따른 신체 변화 양상 헬퍼 (bodyChangeInsights)
  // ─────────────────────────────────────────────────────────────

  /**
   * ① 하체 정렬과 사용 밸런스 분석
   *   - pelvicState: 오른쪽높음 / 왼쪽높음 / 균형
   *   - legDominant: 오른쪽 / 왼쪽 / 균형
   *   - 이미지 assetKey: 정렬 특성에 따른 신체 변화 양상 1-6 중 조합 선택
   *     골반(1-3) + 다리(4-6)   →   골반 이미지: R높=1, L높=2, 균형=3
   *                                  다리 이미지: R높=4, L높=5, 균형=6
   */
  private buildLowerBodySection(pelvicReaction: any, legUsage: any): any {
    // ── 골반 상태 분류
    const pelvicState: '오른쪽' | '왼쪽' | '균형' = !pelvicReaction || pelvicReaction.isNormal
      ? '균형'
      : pelvicReaction.higherSide === '오른쪽' ? '오른쪽' : '왼쪽';

    // ── 다리 사용 분류
    const legDominant: '오른쪽' | '왼쪽' | '균형' = !legUsage || legUsage.dominantSide === '균형'
      ? '균형'
      : legUsage.dominantSide === '오른쪽' ? '오른쪽' : '왼쪽';

    // ── 매칭 assetKey (이미지 번호)
    const pelvicAsset = pelvicState === '오른쪽' ? 'BODY_CHANGE_LOWER_1'
      : pelvicState === '왼쪽' ? 'BODY_CHANGE_LOWER_2'
      : 'BODY_CHANGE_LOWER_3';

    const legAsset = legDominant === '오른쪽' ? 'BODY_CHANGE_LOWER_4'
      : legDominant === '왼쪽' ? 'BODY_CHANGE_LOWER_5'
      : 'BODY_CHANGE_LOWER_6';

    // ── summary 텍스트
    const pelvicText = pelvicState === '오른쪽' ? '오른쪽이 상대적으로 높은'
      : pelvicState === '왼쪽' ? '왼쪽이 상대적으로 높은'
      : '좌우 높이가 유사한';
    const legText = legDominant === '오른쪽' ? '오른쪽 다리 사용이 두드러지는'
      : legDominant === '왼쪽' ? '왼쪽 다리 사용이 두드러지는'
      : '양쪽 다리 사용이 비교적 균형적인';

    const summary =
      `굽힘 자세에서 골반 높이는 <b>${pelvicText}</b> 양상으로 나타나며,\n` +
      `동시에 다리 사용 패턴은 <b>${legText}</b> 경향으로 관찰됩니다.\n` +
      `이러한 특징은 아래와 같은 방향의 점진적인 변화로 이어질 수 있습니다.`;

    // ── 골반 상태별 텍스트 데이터
    const PELVIC_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '오른쪽 다리로 체중을 지지하며 짝다리를 짚는 경향 확인됨',
          '보행 시 왼쪽 골반이 상대적으로 더 많이 들리는 움직임 관찰됨(특히 유각기)',
          '앉은 자세에서 오른쪽 엉덩이에 체중이 실리며, 상체가 왼쪽으로 기울어지는 경향 관찰됨',
          '상체를 숙이는 동작에서 오른쪽 허리 근육의 긴장이 먼저 나타나며, 움직임이 다소 뻣뻣해지는 양상 관찰됨',
        ],
        bodyStress: [
          '오른쪽 허리 뒤쪽(허리네모근 부위)에 지속적인 긴장감이 인지됨',
          '상체를 숙일 때 허리에 묵직한 압박감이 함께 느껴짐',
          '오래 앉아 있다가 일어날 때 오른쪽 골반 주변이 즉각적으로 펴지지 않는 느낌이 나타남',
          '엉덩이 뒤쪽 또는 꼬리뼈 주변에서 불편감이나 불안정한 느낌이 동반됨',
        ],
        appearanceImpact: [
          '골반 높이 차이로 인한 순환 저하로 오른쪽 허벅지와 승마살 부위가 유독 쉽게 붓고 살이 붙는 양상을 보임',
          '오른쪽 허리 라인이 짧아지면서 옆구리 살이 위로 접히거나 반대편보다 튀어나와 보이는 인상을 형성함',
          '엉덩이 높이 불균형에 따라 오른쪽 엉덩이 하단부(힙딥)가 아래로 처지거나 더 커 보이는 시각적 특징을 보임',
          '상체가 왼쪽으로 기우는 보상 작용으로 인해 오른쪽 목 라인이 두꺼워지며 얼굴이 한쪽으로 커 보일 가능성이 있음',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '왼쪽 다리로 체중을 지지하며 짝다리를 짚는 경향 확인됨',
          '보행 시 오른쪽 골반이 상대적으로 더 많이 들리는 움직임 관찰됨(특히 유각기)',
          '앉은 자세에서 왼쪽 엉덩이에 체중이 실리며, 상체가 오른쪽으로 기울어지는 경향 관찰됨',
          '상체를 숙이는 동작에서 왼쪽 허리 근육의 긴장이 먼저 나타나며, 움직임이 다소 뻣뻣해지는 양상 관찰됨',
        ],
        bodyStress: [
          '왼쪽 허리 뒤쪽(허리네모근 부위)에 지속적인 긴장감이 인지됨',
          '상체를 숙일 때 허리에 묵직한 압박감이 함께 느껴짐',
          '오래 앉아 있다가 일어날 때 왼쪽 골반 주변이 즉각적으로 펴지지 않는 느낌이 나타남',
          '엉덩이 뒤쪽 또는 꼬리뼈 주변에서 불편감이나 불안정한 느낌이 동반됨',
        ],
        appearanceImpact: [
          '골반 높이 차이로 인한 순환 저하로 왼쪽 허벅지와 승마살 부위가 유독 쉽게 붓고 살이 붙는 양상을 보임',
          '왼쪽 허리 라인이 짧아지면서 옆구리 살이 위로 접히거나 반대편보다 튀어나와 보이는 인상을 형성함',
          '엉덩이 높이 불균형에 따라 왼쪽 엉덩이 하단부(힙딥)가 아래로 처지거나 더 커 보이는 시각적 특징을 보임',
          '상체가 오른쪽으로 기우는 보상 작용으로 인해 왼쪽 목 라인이 두꺼워지며 얼굴이 한쪽으로 커 보일 가능성이 있음',
        ],
      },
      균형: {
        dailyPatterns: [
          '허리를 숙이거나 구부리는 동작 시 좌우 허리네모근과 세움근이 대칭적으로 이완되며 척추 하부의 부드러운 가동 범위가 확보됨',
          '바닥의 물건을 집어 올릴 때 골반 수평 정렬이 유지되어 요추 마디에 가해지는 중력 부하가 좌우 균등하게 분산되는 양상을 보임',
          '의자에 앉아 업무를 볼 때 좌우 엉덩이에 체중이 고르게 실려, 한쪽 골반이 들리거나 상체가 비틀리는 자세가 나타나지 않음',
          '보행 시 다리를 들어 올리고 딛는 과정에서 골반의 상하 흔들림이 일정하여 에너지 소모가 적고 효율적인 이동 패턴을 유지함',
        ],
        bodyStress: [
          '골반 주변부 근긴장도가 균형을 이루어 장시간 앉아 있거나 서 있어도 특정 한쪽 허리만 뻐근하거나 쑤시는 피로 누적이 적음',
          '허리 하부에 한쪽으로 쏠리는 압박이 없어, 기상 후 허리 주변의 뻣뻣한 느낌이 나타나지 않음',
          '골반 정렬 이탈로 인한 신경 압박 가능성이 낮아 다리 저림이나 원인 모를 감각 이상 반응 없이 하체의 쾌적한 상태가 유지됨',
          '엉덩관절 가동 범위의 좌우 차이가 적어 격한 움직임이나 스트레칭 시에도 골반 깊은 곳에서 집히거나 당기는 불편감이 관찰되지 않음',
        ],
        appearanceImpact: [
          '골반 수평이 안정적이라 허벅지 바깥쪽 라인이 매끄럽고 양쪽 다리 붓기가 일정하여 슬림한 하체 라인을 유지함',
          '골반 바로 위 허리 곡선이 좌우로 대칭을 이루어, 타이트한 옷 착용 시 허리 라인이 잘록하고 정돈된 인상 형성됨',
          '엉덩이 근육이 좌우 고르게 분포되어 힙업 상태가 대칭적이며 뒷모습에서 건강하고 탄력 있는 실루엣을 형성함',
          '하체 순환이 원활하여 특정 부위에 군살이 집중되지 않고 전체적으로 매끄럽고 균형 잡힌 다리 실루엣을 보임',
        ],
      },
    };

    // ── 다리 상태별 텍스트 데이터
    const LEG_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '가만히 서 있을 때 무의식적으로 오른쪽 다리에만 모든 체중을 싣는 \'짝다리\' 자세가 습관화되어 나타남',
          '보행이나 달리기 시 오른쪽 발바닥이 지면을 차는 힘이 왼쪽보다 강하여 신체 중심이 오른쪽으로 미세하게 쏠리는 경향을 보임',
          '계단을 오르내릴 때 항상 오른쪽 다리를 먼저 내디디며 오른쪽 하체 관절에 누적 하중이 집중되는 패턴이 반복됨',
          '양치질이나 세안을 위해 상체를 숙일 때 무게중심이 오른쪽으로 치우쳐 골반과 척추 정렬의 비대칭을 유발함',
          '신발을 신거나 양말을 신기 위해 한쪽 다리로 버텨야 하는 상황에서 오른쪽으로 지탱할 때의 안정감이 왼쪽보다 현저히 높음',
        ],
        bodyStress: [
          '오른쪽 하체 근육의 과사용으로 인한 혈류 정체로 저녁 시간대 오른쪽 종아리만 유독 묵직한 피로감과 부종이 발생함',
          '오른쪽 무릎 주변 인대와 근육의 긴장도가 높아져 가벼운 운동 후에도 오른쪽 관절 주변에서 뻐근한 압박감을 자주 느낌',
          '보행 시 발바닥에 실리는 압력이 오른쪽에 더 몰려, 오래 걸으면 오른쪽 발바닥에서 타는 듯하거나 콕콕 쑤시는 불편함이 느껴짐',
          '하체 무게중심 이탈을 보상하기 위해 반대쪽인 왼쪽 허리 근육이 과하게 긴장하며 원인 모를 만성 허리 피로도가 누적됨',
          '엉덩관절 가동성 불균형으로 인해 오래 앉아 있다 일어날 때 오른쪽 서혜부 주변이 즉각적으로 펴지지 않고 뻣뻣함이 지속됨',
        ],
        appearanceImpact: [
          '오른쪽 다리에 체중 하중이 집중되면서 오른쪽 종아리 알 근육이 반대편보다 비정상적으로 발달해 보일 수 있음',
          '혈액 순환의 불균형으로 인해 저녁 시간대 오른쪽 발목 주변이 두껍게 붓고 발등까지 살이 차오르는 양상을 보임',
          '오른쪽 허벅지 앞쪽 근육이 과하게 쓰이면서 앞 허벅지 살이 튀어나와 보이고 다리가 짧아 보이는 인상을 줌',
          '한쪽 다리 사용이 많아 골반이 한쪽으로 돌아가면서, 얼굴에도 좌우 차이가 생겨 오른쪽 턱선이 더 도드라져 보이는 인상 형성됨',
          '무게중심이 쏠린 오른쪽 발바닥 쪽으로 체액이 몰려 신발이 한쪽만 꽉 끼는 등 시각적인 부종 증상이 도드라짐',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '가만히 서 있을 때 무의식적으로 왼쪽 다리에만 모든 체중을 싣는 \'짝다리\' 자세가 습관화되어 나타남',
          '보행이나 달리기 시 왼쪽 발바닥이 지면을 차는 힘이 오른쪽보다 강하여 신체 중심이 왼쪽으로 미세하게 쏠리는 경향을 보임',
          '계단을 오르내릴 때 항상 왼쪽 다리를 먼저 내디디며 왼쪽 하체 관절에 누적 하중이 집중되는 패턴이 반복됨',
          '양치질이나 세안을 위해 상체를 숙일 때 무게중심이 왼쪽으로 치우쳐 골반과 척추 정렬의 비대칭을 유발함',
          '신발을 신거나 양말을 신기 위해 한쪽 다리로 버텨야 하는 상황에서 왼쪽으로 지탱할 때의 안정감이 오른쪽보다 현저히 높음',
        ],
        bodyStress: [
          '왼쪽 하체 근육의 과사용으로 인한 혈류 정체로 저녁 시간대 왼쪽 종아리만 유독 묵직한 피로감과 부종이 발생함',
          '왼쪽 무릎 주변 인대와 근육의 긴장도가 높아져 가벼운 운동 후에도 왼쪽 관절 주변에서 뻐근한 압박감을 자주 느낌',
          '보행 시 발바닥에 실리는 압력이 왼쪽에 더 몰려, 오래 걸으면 왼쪽 발바닥에서 타는 듯하거나 콕콕 쑤시는 불편함이 느껴짐',
          '하체 무게중심 이탈을 보상하기 위해 반대쪽인 오른쪽 허리 근육이 과하게 긴장하며 원인 모를 만성 허리 피로도가 누적됨',
          '엉덩관절 가동성 불균형으로 인해 오래 앉아 있다 일어날 때 왼쪽 서혜부 주변이 즉각적으로 펴지지 않고 뻣뻣함이 지속됨',
        ],
        appearanceImpact: [
          '왼쪽 다리에 체중 하중이 집중되면서 왼쪽 종아리 알 근육이 반대편보다 비정상적으로 발달해 보일 수 있음',
          '혈액 순환의 불균형으로 인해 저녁 시간대 왼쪽 발목 주변이 두껍게 붓고 발등까지 살이 차오르는 양상을 보임',
          '왼쪽 허벅지 앞쪽 근육이 과하게 쓰이면서 앞 허벅지 살이 튀어나와 보이고 다리가 짧아 보이는 인상을 줌',
          '한쪽 다리 사용이 많아 골반이 한쪽으로 돌아가면서, 얼굴에도 좌우 차이가 생겨 왼쪽 턱선이 더 도드라져 보이는 인상 형성됨',
          '무게중심이 쏠린 왼쪽 발바닥 쪽으로 체액이 몰려 신발이 한쪽만 꽉 끼는 등 시각적인 부종 증상이 도드라짐',
        ],
      },
      균형: {
        dailyPatterns: [
          '보행이나 주행 시 양발의 지면 접촉 시간과 추진력이 일정하여 신체의 흔들림이 적고 리듬감 있는 효율적인 움직임을 지속함',
          '서 있는 자세에서 무의식적으로 한쪽 다리에만 체중을 싣는 \'짝다리\' 습관 없이 양발에 하중을 고르게 지지하는 중립 상태를 유지함',
          '계단을 오르내릴 때 양쪽 무릎 관절에 가해지는 충격 하중이 균등하여 특정 관절의 마모와 연쇄적인 피로 누적 리스크가 매우 낮음',
          '스쿼트나 런지 등 하체 운동 시 좌우 근파워의 출력이 균일하게 발생하여 골반의 틀어짐 없이 정교하고 파워풀한 동작 수행이 가능함',
          '대중교통 이용 등 서서 대기하는 환경에서 신체 중심의 좌우 이동이 적어 특정 다리에만 국소적으로 피로가 쌓이는 현상이 방지됨',
        ],
        bodyStress: [
          '하체 근육의 과사용과 저활용의 불균형이 없어 저녁 시간대 특정 다리만 유독 붓거나 무거운 부종 증상이 현저히 적게 나타남',
          '무릎 관절과 발목 주변부 인대의 긴장도가 좌우 동일하게 유지되어 특정 한쪽 부위에만 만성적인 관절 피로감이 느껴지지 않음',
          '다리 사용 비중 차이로 인한 골반 비틀림 유발 가능성이 낮아 척추 하부 정렬 유지와 만성 허리 통증 리스크가 매우 낮은 상태임',
          '운동 후 나타나는 근육통의 강도가 양측 다리에 비슷하게 느껴져, 근육 사용과 회복이 균형 있게 이루어지고 있는 모습 관찰됨',
          '발바닥 근막에 가해지는 압력이 균등하게 분산되어 장시간 보행 후에도 발바닥의 특정 부위만 타는 듯하거나 쑤시는 통증이 발생하지 않음',
        ],
        appearanceImpact: [
          '양쪽 종아리 근육 발달이 대칭적이라 반바지나 치마 착용 시 다리 라인이 곧고 매끄러워 보이는 인상을 형성함',
          '발목 주위 부종이 없어 복사뼈 라인이 선명하게 드러나며 하체 전반의 순환이 원활한 건강한 상태를 보여줌',
          '턱과 얼굴 근육에 실리는 긴장이 고르게 분산되어, 얼굴 윤곽이 비교적 대칭적이고 정돈된 인상으로 보임',
          '양쪽 신발 밑창이 고르게 마모되며 보행 시 신체 중심이 안정되어 우아하고 당당한 체형미를 시각적으로 전달함',
        ],
      },
    };

    const pelvicD = PELVIC_DATA[pelvicState];
    const legD = LEG_DATA[legDominant];

    const pick2 = <T>(arr: T[]): T[] => {
      const shuffled = [...arr].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 2);
    };

    return {
      order: 1,
      title: '하체 정렬과 사용 밸런스 분석',
      images: [
        { assetKey: pelvicAsset, url: this.resolveBodyChangeUrl(pelvicAsset) },
        { assetKey: legAsset, url: this.resolveBodyChangeUrl(legAsset) },
      ],
      summary,
      dailyPatterns: [...pick2(pelvicD.dailyPatterns), ...pick2(legD.dailyPatterns)],
      bodyStress: [...pick2(pelvicD.bodyStress), ...pick2(legD.bodyStress)],
      appearanceImpact: [...pick2(pelvicD.appearanceImpact), ...pick2(legD.appearanceImpact)],
    };
  }

  /**
   * ② 상체 중심 정렬과 척추 흐름 특성
   *   - bodyCenter: forwardBend.bodyCenter (오른쪽/왼쪽/균형)
   *   - shoulderAlignment: 기립 어깨 정렬 (척추 라인 방향 = 어깨 높은 쪽)
   *   이미지 assetKey: 상체 중심(7-9) + 척추 라인 방향은 기존 척추 측만증 아이콘 사용
   */
  private buildUpperBodySection(bodyCenter: any, shoulderAlignment: any): any {
    // 상체 중심 방향은 동일 임계값(TILT_THRESHOLD_PX)으로 판정
    const centerDir: '오른쪽' | '왼쪽' | '균형' = !bodyCenter || Math.abs(bodyCenter.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX
      ? '균형'
      : (bodyCenter.result ?? 0) > 0 ? '오른쪽' : '왼쪽';

    // 척추 라인 방향 (어깨 높은 쪽 = 척추가 휘는 방향)
    const spineDir: '오른쪽' | '왼쪽' | '중앙' = !shoulderAlignment || shoulderAlignment.disease === 'NORMAL'
      ? '중앙'
      : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';

    // 매칭 이미지 (엑셀 기준: 오른쪽=8, 왼쪽=7, 균형=9)
    const assetKey = centerDir === '오른쪽' ? 'BODY_CHANGE_UPPER_8'
      : centerDir === '왼쪽' ? 'BODY_CHANGE_UPPER_7'
      : 'BODY_CHANGE_UPPER_9';

    const centerText = centerDir === '오른쪽' ? '오른쪽으로 치우친'
      : centerDir === '왼쪽' ? '왼쪽으로 치우친'
      : '골반과 비교적 일치한';
    const spineText = spineDir === '오른쪽' ? '오른쪽 방향의 척추 라인'
      : spineDir === '왼쪽' ? '왼쪽 방향의 척추 라인'
      : '중앙에 가까운 척추라인';

    const summary =
      `굽힘 자세에서 상체 중심은 <b>${centerText}</b> 양상으로 나타나며,\n` +
      `동시에 척추 라인은 <b>${spineText}</b> 형태가 관찰됩니다.\n` +
      `이러한 특징은 아래와 같은 방향의 점진적인 변화로 이어질 수 있습니다.`;

    // 상체 중심 방향별 텍스트
    const CENTER_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '컴퓨터 작업 시 상체를 숙여 화면을 볼 때, 몸 중심이 오른쪽으로 밀리며 한쪽 팔에만 체중을 기대는 자세 경향 관찰됨',
          '보행 시 왼쪽 골반이 바깥쪽으로 밀리는 움직임 패턴 관찰됨',
          '상체를 숙여 물건을 집을 때 오른쪽 어깨가 왼쪽보다 먼저 앞으로 나가는 경향 관찰됨',
          '허리를 숙이는 동작에서 몸이 오른쪽으로 비틀리며, 좌우 가동 범위 차이가 나타나는 양상 관찰됨',
        ],
        bodyStress: [
          '오른쪽 목 주변 근육의 좌우 긴장 차이로 인해 목이 뻣뻣하게 느껴지거나 피로감이 쉽게 누적되는 느낌 인지됨',
          '오른쪽 날개뼈 안쪽 주변에서 긴장감이 지속적으로 느껴지며, 등 상부에 피로감이 자주 동반되는 양상 인지됨',
          '등을 세우는 근육 사용이 균형적이지 않게 느껴지며, 등 전체에 묵직한 압박감이 동반되는 느낌 인지됨',
          '오른쪽 엉덩관절 주변 사용 비중 증가로 인해 엉덩이 깊은 부위에서 묵직한 느낌이 인지됨',
        ],
        appearanceImpact: [
          '상체 무게가 오른쪽으로 쏠리며 오른쪽 겨드랑이 주변 살(부유방 부위)이 반대편보다 도드라져 보일 수 있음',
          '오른쪽 목 근육인 등세모근이 두꺼워져 목이 짧아 보이고 상대적으로 오른쪽 얼굴이 커 보이는 인상을 형성함',
          '척추 보상 작용으로 인해 오른쪽 옆구리에 살이 뭉쳐 보이거나 하의 위로 살이 튀어나오는 양상을 보임',
          '중심축 이탈로 인해 쇄골 라인이 비대칭적으로 변하며 오른쪽 쇄골 주변이 붓고 묻혀 보이는 특징이 나타남',
          '오른쪽 어깨가 말리면서 팔뚝 바깥쪽 살이 더 넓게 퍼져 보여 팔이 두꺼워 보이는 시각적 효과가 발생함',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '컴퓨터 작업 시 상체를 숙여 화면을 볼 때, 몸 중심이 왼쪽으로 밀리며 한쪽 팔에만 체중을 기대는 자세 경향 관찰됨',
          '보행 시 오른쪽 골반이 바깥쪽으로 밀리는 움직임 패턴 관찰됨',
          '상체를 숙여 물건을 집을 때 왼쪽 어깨가 오른쪽보다 먼저 앞으로 나가는 경향 관찰됨',
          '허리를 숙이는 동작에서 몸이 왼쪽으로 비틀리며, 좌우 가동 범위 차이가 나타나는 양상 관찰됨',
        ],
        bodyStress: [
          '왼쪽 목 주변 근육의 좌우 긴장 차이로 인해 목이 뻣뻣하게 느껴지거나 피로감이 쉽게 누적되는 느낌 인지됨',
          '왼쪽 날개뼈 안쪽 주변에서 긴장감이 지속적으로 느껴지며, 등 상부에 피로감이 자주 동반되는 양상 인지됨',
          '등을 세우는 근육 사용이 균형적이지 않게 느껴지며, 등 전체에 묵직한 압박감이 동반되는 느낌 인지됨',
          '왼쪽 엉덩관절 주변 사용 비중 증가로 인해 엉덩이 깊은 부위에서 묵직한 느낌이 인지됨',
        ],
        appearanceImpact: [
          '상체 무게가 왼쪽으로 쏠리며 왼쪽 겨드랑이 주변 살(부유방 부위)이 반대편보다 도드라져 보일 수 있음',
          '왼쪽 목 근육인 등세모근이 두꺼워져 목이 짧아 보이고 상대적으로 왼쪽 얼굴이 커 보이는 인상을 형성함',
          '척추 보상 작용으로 인해 왼쪽 옆구리에 살이 뭉쳐 보이거나 하의 위로 살이 튀어나오는 양상을 보임',
          '중심축 이탈로 인해 쇄골 라인이 비대칭적으로 변하며 왼쪽 쇄골 주변이 붓고 묻혀 보이는 특징이 나타남',
          '왼쪽 어깨가 말리면서 팔뚝 바깥쪽 살이 더 넓게 퍼져 보여 팔이 두꺼워 보이는 시각적 효과가 발생함',
        ],
      },
      균형: {
        dailyPatterns: [
          '신체의 무게중심축이 수직 정렬되어 중력에 대항하는 최소한의 에너지만으로 바른 자세를 유지하는 효율성을 보임',
          '의자에 앉거나 일어설 때 상체가 좌우로 불필요하게 흔들리지 않고 수직 축을 따라 매끄럽게 이동하는 안정적인 패턴을 유지함',
          '무거운 물건을 들 때 상·하체가 함께 사용되어, 한쪽 허리 아래에 부담이 몰리지 않고 전신 힘을 고르게 쓰는 모습 관찰됨',
          '보행 시 상체의 좌우 흔들림이 적고 시선 처리가 안정적이며 보폭의 일관성이 유지되어 세련되고 당당한 걸음걸이 양상을 보임',
          '장시간 서 있는 업무 중에도 중심축이 견고하게 잡혀 있어 골반이나 어깨 주변 근육의 보상적 긴장 발생 리스크가 매우 낮은 상태임',
        ],
        bodyStress: [
          '중심축 이탈에 따른 특정 근육의 보상적 과부하가 발생하지 않아 전신적인 근육 피로도가 매우 낮은 쾌적한 신체 컨디션을 유지함',
          '척추 마디마디에 가해지는 수직 압력이 균등하게 분산되어 디스크 및 관절 조직의 퇴행성 변화를 방지하는 구조적 안정성이 확보됨',
          '특정 한쪽 어깨나 허리만 무거운 편측성 불편감이 관찰되지 않으며 전반적인 신체 에너지 효율과 항상성이 잘 유지되고 있음',
          '코어 근육이 적절한 긴장도를 유지하며 내부 장기를 보호하여 복압 유지 및 소화 효율이 안정적인 생체 역학적 양상을 나타냄',
          '고중량 운동 시 척추의 중립 상태 유지력이 매우 우수하여 부상 위험도가 낮고 근력 향상을 위한 최적의 정렬 상태를 유지함',
        ],
        appearanceImpact: [
          '중심축이 정중앙에 위치하여 양쪽 겨드랑이와 옆구리 라인이 매끄럽게 정돈되어 슬림한 상체 실루엣을 형성함',
          '등세모근 라인이 대칭적으로 낮게 유지되어 목이 길어 보이고 얼굴이 작고 갸름해 보이는 시각적 효과가 큼',
          '쇄골 라인이 좌우 대칭으로 선명하게 드러남',
          '상체 무게가 분산되어 팔뚝 살이 한쪽으로 쏠리지 않고 매끄럽게 정돈되어 세련된 상의 핏을 완성함',
        ],
      },
    };

    // 척추 라인 방향별 텍스트
    const SPINE_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '뒤를 돌아볼 때 오른쪽 회전은 수월하나 왼쪽 회전 시 척추 마디가 뻑뻑하게 걸려 몸통 전체를 돌려야 하는 불편함이 있음',
          '의자에 앉을 때 무너지는 중심축을 지탱하기 위해 오른쪽 팔이나 턱에 상체 체중을 과하게 기대는 보상 습관이 고착됨',
          '계단을 오르거나 빠른 보행 시 흉곽의 팽창 제한으로 인해 남들보다 호흡이 빨리 가빠지며 쉽게 지치는 양상을 보임',
          '양쪽 어깨 끈을 모두 착용해도 척추 회전 변이로 인해 가방이 자꾸 한쪽으로 치우치거나 끈이 어깨에서 이탈함',
          '운전이나 업무 중 정면을 응시할 때 고개가 미세하게 오른쪽 대각선으로 기울어져 시야의 수평이 깨지는 현상이 관찰됨',
        ],
        bodyStress: [
          '오른쪽 날개뼈 안쪽 또는 등 중앙에서 당김과 빠른 피로감이 동반됨',
          '왼쪽 등 부위에서 묵직하거나 눌리는 듯한 답답함 인지됨',
          '등을 세우는 근육 사용이 좌우로 균형적이지 않게 느껴짐',
          '흉곽의 비대칭적 압박으로 인해 갈비뼈 하단부나 명치 부근에서 원인 모를 답답함과 소화 불량 증상이 자주 수반됨',
          '목과 어깨 주변 근육 사용 증가로 위등세모근 피로가 쉽게 누적됨',
        ],
        appearanceImpact: [
          '척추가 볼록한 오른쪽 등 부위가 튀어나와 보이며 그 주변으로 살집이 두껍게 붙어 보이는 인상을 형성함',
          '볼록한 쪽의 갈비뼈 사이사이 근육이 팽창하여 오른쪽 가슴 밑이나 옆구리 살이 유독 도드라져 보일 수 있음',
          '척추 회전으로 인해 오른쪽 어깨 뒤쪽 견갑골 주변이 붓고 살이 차올라 뒷모습이 넓고 둔해 보이는 양상을 보임',
          '목뼈까지 이어진 변위로 인해 얼굴의 오른쪽 광대나 턱 라인이 더 부각되어 얼굴 비대칭이 강조되어 보임',
          '척추의 곡선 흐름 때문에 오른쪽 등 근육이 항상 긴장되어 안색이 칙칙해 보이거나 상체가 부어 보이는 인상을 줌',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '뒤를 돌아볼 때 왼쪽 회전은 수월하나 오른쪽 회전 시 척추 마디가 뻑뻑하게 걸려 몸통 전체를 돌려야 하는 불편함이 있음',
          '의자에 앉을 때 무너지는 중심축을 지탱하기 위해 왼쪽 팔이나 턱에 상체 체중을 과하게 기대는 보상 습관이 고착됨',
          '계단을 오르거나 빠른 보행 시 흉곽의 팽창 제한으로 인해 남들보다 호흡이 빨리 가빠지며 쉽게 지치는 양상을 보임',
          '양쪽 어깨 끈을 모두 착용해도 척추 회전 변이로 인해 가방이 자꾸 한쪽으로 치우치거나 끈이 어깨에서 이탈함',
          '운전이나 업무 중 정면을 응시할 때 고개가 미세하게 왼쪽 대각선으로 기울어져 시야의 수평이 깨지는 현상이 관찰됨',
        ],
        bodyStress: [
          '왼쪽 날개뼈 안쪽 또는 등 중앙에서 당김과 빠른 피로감이 동반됨',
          '오른쪽 등 부위에서 묵직하거나 눌리는 듯한 답답함 인지됨',
          '등을 세우는 근육 사용이 좌우로 균형적이지 않게 느껴짐',
          '흉곽의 비대칭적 압박으로 인해 갈비뼈 하단부나 명치 부근에서 원인 모를 답답함과 소화 불량 증상이 자주 수반됨',
          '목과 어깨 주변 근육 사용 증가로 위등세모근 피로가 쉽게 누적됨',
        ],
        appearanceImpact: [
          '척추가 볼록한 왼쪽 등 부위가 튀어나와 보이며 그 주변으로 살집이 두껍게 붙어 보이는 인상을 형성함',
          '볼록한 쪽의 갈비뼈 사이사이 근육이 팽창하여 왼쪽 가슴 밑이나 옆구리 살이 유독 도드라져 보일 수 있음',
          '척추 회전으로 인해 왼쪽 어깨 뒤쪽 견갑골 주변이 붓고 살이 차올라 뒷모습이 넓고 둔해 보이는 양상을 보임',
          '목뼈까지 이어진 변위로 인해 얼굴의 왼쪽 광대나 턱 라인이 더 부각되어 얼굴 비대칭이 강조되어 보임',
          '왼쪽 등 근육이 항상 긴장되어 안색이 칙칙해 보이거나 상체가 부어 보이는 인상을 줌',
        ],
      },
      중앙: {
        dailyPatterns: [
          '척추의 가동 범위가 좌우 대칭적으로 확보되어 몸통을 회전하거나 옆으로 숙이는 동작 시 뻣뻣함이나 걸리는 느낌 없이 부드럽게 수행함',
          '앉은 자세에서 척추 기립근이 양측 동일한 힘으로 상체를 지지하여 등받이 없이도 바른 척추 정렬 유지가 수월한 뛰어난 지지력을 보임',
          '뒤를 돌아보거나 고개를 돌릴 때 척추 마디마디의 분절 움직임이 이상적으로 발생하여 목과 어깨 주변의 피로 누적을 방지함',
          '무거운 가방을 메거나 짐을 들 때 척추 중심축이 무너지지 않고 하중을 골반으로 직접 전달하여 척추 주변부의 부상을 예방함',
          '보행 시 팔의 흔들림 폭이 좌우 일정하게 나타나 신체 회전 밸런스가 매끄럽게 조절되며 세련된 보행 패턴을 유지하고 있음',
        ],
        bodyStress: [
          '척추 마디 사이의 불균형한 압박이 없어 신경 자극에 따른 찌릿함이나 원인 모를 결림 증상 없이 편안한 신체 감각을 유지함',
          '세움근의 좌우 긴장도가 일정하여 수면 중 근육이 충분히 이완되며 기상 후 등의 뻐근함 없이 개운한 컨디션 회복 속도를 보임',
          '특정 부위의 척추 가동성 저하에 따른 보상 작용이 발생하지 않아 목이나 허리 하부의 연쇄적인 피로 누적 리스크가 매우 낮음',
          '흉추의 유연성이 안정적으로 확보되어 깊은 호흡 시 흉곽의 대칭적 팽창이 자유롭고 산소 섭취 효율이 높은 기능적 상태를 유지함',
          '장시간 고정된 자세를 유지한 후에도 등이나 허리 주변의 만성적인 묵직함이 빠르게 해소되는 우수한 근육 회복 탄력성을 보임',
        ],
        appearanceImpact: [
          '등 근육의 윤곽이 좌우 대칭적으로 나타나며 척추 라인이 곧아 뒷모습에서 슬림하고 정돈된 이미지를 형성함',
          '옆구리 살이 좌우 고르게 분포되어 잘록한 허리 라인이 강조되며 상의를 입었을 때 뒷태가 매끄러워 보임',
          '날개뼈 주변에 불필요한 부종이나 군살이 없어 어깨 라인이 탄탄하고 건강한 전문가적 체형을 보여줌',
          '척추 정렬을 통해 안면부 혈류가 원활해져 안색이 맑아 보이고 턱 라인이 대칭적이고 갸름한 인상을 형성함',
          '상체 전반의 근육 톤이 균일하여 어떤 각도에서도 신체 정렬이 안정적이고 자신감 넘치는 외형적 특징을 보임',
        ],
      },
    };

    const centerD = CENTER_DATA[centerDir];
    const spineD = SPINE_DATA[spineDir];

    const pick2Upper = <T>(arr: T[]): T[] => {
      const shuffled = [...arr].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 2);
    };

    const spineIllustUrl = this.resolveSpineIllustrationUrl(bodyCenter, shoulderAlignment);
    return {
      order: 2,
      title: '상체 중심 정렬과 척추 흐름 특성',
      images: [
        { assetKey, url: this.resolveBodyChangeUrl(assetKey) },
        { assetKey: 'SPINE_FRONT_ILLUSTRATION', url: spineIllustUrl },
      ],
      summary,
      dailyPatterns: [...pick2Upper(centerD.dailyPatterns), ...pick2Upper(spineD.dailyPatterns)],
      bodyStress: [...pick2Upper(centerD.bodyStress), ...pick2Upper(spineD.bodyStress)],
      appearanceImpact: [...pick2Upper(centerD.appearanceImpact), ...pick2Upper(spineD.appearanceImpact)],
    };
  }

  /**
   * ③ 어깨 높이와 입체 윤곽 정렬
   *   - shoulderAlignment: 기립 어깨 정렬 (higherSide = 어깨 높은 쪽 = 윤곽 도드라지는 쪽)
   *   이미지 assetKey:
   *     어깨 높이(10-12): 오른쪽높음=10, 왼쪽높음=11, 유사=12
   *     윤곽(13-15):      오른쪽=13, 왼쪽=14, 유사=15
   *   (전굴 어깨 높이 = 척추라인&등높이 방향과 동일)
   */
  private buildShoulderSection(shoulderAlignment: any): any {
    const higherSide: '오른쪽' | '왼쪽' | '균형' = !shoulderAlignment || shoulderAlignment.disease === 'NORMAL'
      ? '균형'
      : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';

    // 윤곽 방향도 어깨 높이와 동일 조건으로 결정 (숙였을 때 높은 쪽 = 윤곽이 도드라지는 쪽)
    const contourSide = higherSide;

    const shoulderAsset = higherSide === '오른쪽' ? 'BODY_CHANGE_SHOULDER_10'
      : higherSide === '왼쪽' ? 'BODY_CHANGE_SHOULDER_11'
      : 'BODY_CHANGE_SHOULDER_12';
    const contourAsset = contourSide === '오른쪽' ? 'BODY_CHANGE_SHOULDER_13'
      : contourSide === '왼쪽' ? 'BODY_CHANGE_SHOULDER_14'
      : 'BODY_CHANGE_SHOULDER_15';

    const shoulderText = higherSide === '오른쪽' ? '오른쪽이 상대적으로 높게 보이는'
      : higherSide === '왼쪽' ? '왼쪽이 상대적으로 높게 보이는'
      : '좌우 높이가 유사하게 보이는';
    const contourText = contourSide === '오른쪽' ? '오른쪽 등·어깨 윤곽이 더 도드라지는'
      : contourSide === '왼쪽' ? '왼쪽 등·어깨 윤곽이 더 도드라지는'
      : '양쪽 등·어깨 윤곽이 유사한';

    const summary =
      `굽힘 자세에서 어깨 높이는 <b>${shoulderText}</b> 양상으로 나타나며,\n` +
      `동시에 등·어깨 윤곽은 <b>${contourText}</b> 경향으로 관찰됩니다.\n` +
      `이러한 특징은 아래와 같은 방향의 점진적인 변화로 이어질 수 있습니다.`;

    const SHOULDER_HIGHER_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '바닥의 물건을 집기 위해 몸을 구부릴 때 오른쪽 어깨 근육에 긴장과 힘이 집중되는 양상 관찰됨',
          '왼쪽 방향으로 회전하려 할 때 움직임이 뻣뻣하거나 제한되는 느낌 인지됨',
          '오른쪽 팔을 들어 올릴 때 등세모근 사용 비중이 과도하게 높아지는 양상 관찰됨',
          '빠른 보행이나 계단 오르기 시 호흡이 비교적 빨리 가빠지는 양상 인지됨',
          '왼쪽 어깨에서 가방 끈이나 의류가 쉽게 흘러내리는 현상 관찰됨',
        ],
        bodyStress: [
          '오른쪽 등세모근과 목 연결 부위에 지속적인 긴장감이 느껴지는 양상 인지됨',
          '고개를 숙인 자세를 오래 유지할 때 목 주변에 날카롭게 걸리는 느낌이 동반됨',
          '오른쪽 날개뼈 안쪽 또는 등 중앙에서 팽팽하게 당기는 느낌과 빠른 피로감 인지됨',
          '왼쪽 등 부위에서 묵직하거나 눌리는 듯한 답답한 느낌 인지됨',
          '수면 후에도 어깨 주변의 긴장이 충분히 풀리지 않아 상체 전반에 무거운 피로감이 남아 있는 느낌 인지됨',
        ],
        appearanceImpact: [
          '오른쪽 등세모근이 항상 솟아 있어 목이 한쪽으로 짧아 보이고 오른쪽 얼굴이 하단부로 커 보이는 인상을 줌',
          '오른쪽 어깨 앞쪽 작은 가슴근 긴장으로 인해 부유방 살이 더 튀어나와 보이고 가슴 라인이 비대칭으로 관찰됨',
          '오른쪽 목 주변 림프 순환 저하로 인해 오른쪽 눈가가 잘 붓거나 턱밑 살이 더 두툼하게 잡힐 가능성이 있음',
          '어깨 높이 차이로 인해 오른쪽 팔뚝 살이 위로 당겨져 보여 팔 라인이 반대편보다 짧고 두꺼운 인상을 형성함',
          '뒷목과 어깨가 만나는 부위(버섯 증후군 부위) 살이 오른쪽만 유독 솟아올라 뒷모습이 나이 들어 보일 수 있음',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '바닥의 물건을 집기 위해 몸을 구부릴 때 왼쪽 어깨 근육에 긴장과 힘이 집중되는 양상 관찰됨',
          '오른쪽 방향으로 회전하려 할 때 움직임이 뻣뻣하거나 제한되는 느낌 인지됨',
          '왼쪽 팔을 들어 올릴 때 등세모근 사용 비중이 과도하게 높아지는 양상 관찰됨',
          '빠른 보행이나 계단 오르기 시 호흡이 비교적 빨리 가빠지는 양상 인지됨',
          '오른쪽 어깨에서 가방 끈이나 의류가 쉽게 흘러내리는 현상 관찰됨',
        ],
        bodyStress: [
          '왼쪽 등세모근과 목 연결 부위에 지속적인 긴장감이 느껴지는 양상 인지됨',
          '고개를 숙인 자세를 오래 유지할 때 목 주변에 날카롭게 걸리는 느낌이 동반됨',
          '왼쪽 날개뼈 안쪽 또는 등 중앙에서 팽팽하게 당기는 느낌과 빠른 피로감 인지됨',
          '오른쪽 등 부위에서 묵직하거나 눌리는 듯한 답답한 느낌 인지됨',
          '수면 후에도 어깨 주변의 긴장이 충분히 풀리지 않아 상체 전반에 무거운 피로감이 남아 있는 느낌 인지됨',
        ],
        appearanceImpact: [
          '왼쪽 등세모근이 항상 솟아 있어 목이 한쪽으로 짧아 보이고 왼쪽 얼굴이 하단부로 커 보이는 인상을 줌',
          '왼쪽 어깨 앞쪽 작은 가슴근 긴장으로 인해 부유방 살이 더 튀어나와 보이고 가슴 라인이 비대칭으로 관찰됨',
          '왼쪽 목 주변 림프 순환 저하로 인해 왼쪽 눈가가 잘 붓거나 턱밑 살이 더 두툼하게 잡힐 가능성이 있음',
          '어깨 높이 차이로 인해 왼쪽 팔뚝 살이 위로 당겨져 보여 팔 라인이 반대편보다 짧고 두꺼운 인상을 형성함',
          '뒷목과 어깨가 만나는 부위(버섯 증후군 부위) 살이 왼쪽만 유독 솟아올라 뒷모습이 나이 들어 보일 수 있음',
        ],
      },
      균형: {
        dailyPatterns: [
          '허리를 숙여 세안하거나 바닥의 물건을 잡을 때 양쪽 어깨 관절이 지면과 평행하게 이동하는 뛰어난 대칭적 가동 패턴을 유지함',
          '상체 구부림 동작에서 견갑골(날개뼈) 주변 근육이 좌우 동일한 길이로 늘어나 부드럽고 걸림 없는 상체 움직임을 지원함',
          '양손을 뻗어 물건을 잡을 때 상체의 불필요한 비틀림 없이 정면으로 곧게 뻗어 나가는 효율적이고 정교한 움직임 패턴을 보임',
          '옷을 입거나 가방 끈을 조절할 때 양쪽 어깨의 가동 범위가 일치하여 동작의 제약 없이 신속하고 편안하게 움직일 수 있음',
          '수영이나 골프 등 상체 회전이 필요한 운동 시 양쪽 어깨 회전축이 안정적으로 고정되어 일관성 있는 높은 퍼포먼스 수행이 가능함',
        ],
        bodyStress: [
          '상부 승모근과 견갑거근의 좌우 긴장도가 균형을 이루어 목과 어깨 주변부의 만성적인 결림이나 피로감이 현저히 적은 상태임',
          '어깨 높이 차이에 따른 목 정렬의 보상 작용이 발생하지 않아 긴장성 두통이나 안구 피로 리스크가 낮은 쾌적한 컨디션을 유지함',
          '견관절 주변 조직에 가해지는 압박이 균등하게 분산되어 충돌 증후군 등 퇴행성 질환 예방에 유리한 구조적 안정성을 확보함',
          '장시간 고개를 숙여 업무를 보거나 스마트폰을 사용할 때 특정 한쪽 어깨만 솟아오르는 긴장 반응 없이 근육의 피로도가 완만함',
          '어깨 주변 근육의 혈류 순환이 원활하여 운동 후 근육 내 노폐물 배출이 빠르고 상체 피로 회복 속도가 매우 우수한 상태임',
        ],
        appearanceImpact: [
          '목 라인이 좌우로 균형 있게 길어 보이며, 얼굴이 작아 보이고 목선이 깔끔한 인상 형성됨',
          '쇄골 라인이 비교적 일직선으로 드러나고 어깨선이 매끄럽게 이어져, 다양한 의류 착용 시에도 정돈된 옷태 연출됨',
          '목 주변의 긴장이 한쪽으로 몰리지 않아 얼굴 붓기가 덜해 보이며, 턱선과 광대 라인이 또렷하게 유지되는 인상 나타남',
          '어깨와 팔이 이어지는 라인이 좌우로 균형을 이루어, 팔 라인이 정돈되어 보이고 민소매 착용 시에도 깔끔한 실루엣 형성됨',
          '전체적인 어깨 프레임이 안정적으로 보이며, 단정하고 자신감 있어 보이는 인상 형성됨',
        ],
      },
    };

    const CONTOUR_DATA: Record<string, { dailyPatterns: string[]; bodyStress: string[]; appearanceImpact: string[] }> = {
      오른쪽: {
        dailyPatterns: [
          '깊은 숨을 들이마실 때 오른쪽 가슴우리 움직임이 원활하지 않아, 가슴 안쪽이 답답하게 느껴지는 양상 인지됨',
          '의자에 앉아 업무를 볼 때 가슴우리 회전에 따라 상체가 미세하게 오른쪽으로 돌아가는 자세 관찰됨',
          '똑바로 누워 잠을 잘 때 오른쪽 등이 바닥에 더 닿아, 상체가 한쪽으로 돌아가려는 자세가 반복됨',
          '가벼운 달리기나 보행 시 팔 흔들림 폭이 일정하지 않으며, 가슴우리 움직임의 좌우 차이 관찰됨',
        ],
        bodyStress: [
          '오른쪽 갈비뼈 주변 근육의 비대칭적 긴장 누적으로 인해 만성적인 등 결림과 가슴우리 주변의 묵직한 압박감이 상시 발생할 가능성이 높음',
          '척추와 갈비뼈가 만나는 관절 부위의 가동성 저하로 인해 특정 방향으로 몸을 숙일 때마다 등 뒤쪽에서 당기는 듯한 기분 나쁜 불편감이 수반됨',
          '얕은 호흡 패턴이 고착화되어 충분한 산소 공급이 저해됨에 따라 만성적인 안구 피로와 무거운 머리 무게감을 자주 느끼는 양상을 보임',
          '오른쪽 등 근육인 넓은등근과 세움근이 비정상적으로 신장된 상태로 과하게 일하면서 등 마디마디가 콕콕 쑤시는 예민한 통증이 상존함',
          '가슴우리 회전이 내부 장기를 미세하게 압박하여 식사 후 원인 모를 소화 불량이나 명치 부근의 답답함이 동반될 경향이 분석됨',
        ],
        appearanceImpact: [
          '오른쪽 등이 솟아오르며 등 뒤쪽 살이 두껍게 뭉쳐 보여 뒷모습이 실제보다 훨씬 체격이 커 보이는 인상을 줌',
          '흉곽 회전으로 인해 오른쪽 가슴이 왼쪽보다 더 돌출되어 보이거나 반대로 묻혀 보이는 입체적 비대칭이 나타남',
          '오른쪽 날개뼈가 바깥으로 밀려나며 오른쪽 팔뚝 뒷살이 비대칭적으로 쳐지거나 두꺼워 보이는 양상을 보임',
        ],
      },
      왼쪽: {
        dailyPatterns: [
          '깊은 숨을 들이마실 때 왼쪽 가슴우리 움직임이 원활하지 않아, 가슴 안쪽이 답답하게 느껴지는 양상 인지됨',
          '의자에 앉아 업무를 볼 때 가슴우리 회전에 따라 상체가 미세하게 왼쪽으로 돌아가는 자세 관찰됨',
          '똑바로 누워 잠을 잘 때 왼쪽 등이 바닥에 더 닿아, 상체가 한쪽으로 돌아가려는 자세가 반복됨',
          '가벼운 달리기나 보행 시 팔 흔들림 폭이 일정하지 않으며, 가슴우리 움직임의 좌우 차이 관찰됨',
        ],
        bodyStress: [
          '왼쪽 갈비뼈 주변 근육의 비대칭적 긴장 누적으로 인해 만성적인 등 결림과 가슴우리 주변의 묵직한 압박감이 상시 발생할 가능성이 높음',
          '척추와 갈비뼈가 만나는 관절 부위의 가동성 저하로 인해 특정 방향으로 몸을 숙일 때마다 등 뒤쪽에서 당기는 듯한 기분 나쁜 불편감이 수반됨',
          '얕은 호흡 패턴이 고착화되어 충분한 산소 공급이 저해됨에 따라 만성적인 안구 피로와 무거운 머리 무게감을 자주 느끼는 양상을 보임',
          '왼쪽 등 근육인 넓은등근과 세움근이 비정상적으로 신장된 상태로 과하게 일하면서 등 마디마디가 콕콕 쑤시는 예민한 통증이 상존함',
          '가슴우리 회전이 내부 장기를 미세하게 압박하여 식사 후 원인 모를 소화 불량이나 명치 부근의 답답함이 동반될 경향이 분석됨',
        ],
        appearanceImpact: [
          '왼쪽 등이 솟아오르며 등 뒤쪽 살이 두껍게 뭉쳐 보여 뒷모습이 실제보다 훨씬 체격이 커 보이는 인상을 줌',
          '가슴우리 회전으로 인해 왼쪽 가슴이 오른쪽보다 더 돌출되어 보이거나 반대로 묻혀 보이는 입체적 비대칭이 나타남',
          '왼쪽 갈비뼈 주변 근육 긴장으로 인해 왼쪽 옆구리와 허리 살이 툭 튀어나와 보이는 인상을 형성함',
          '상체 입체 뒤틀림이 목의 회전까지 유발하여 왼쪽 얼굴 면적이 오른쪽보다 더 넓게 보이는 안면 비대칭을 유도함',
          '왼쪽 날개뼈가 바깥으로 밀려나며 왼쪽 팔뚝 뒷살이 비대칭적으로 쳐지거나 두꺼워 보이는 양상을 보임',
        ],
      },
      균형: {
        dailyPatterns: [
          '척추의 입체적 회전 변위 없이 상체가 정중앙을 유지하며 굽혀져 흉곽의 좌우 움직임이 일정하고 대칭적으로 조절되는 양상을 보임',
          '숙이는 동작에서 등 근육(광배근 및 기립근)이 양측 동일한 장력으로 신장되어 척추를 지지하는 안정적인 움직임 기능을 유지함',
          '몸통을 굽힌 상태에서 물건을 옆으로 옮길 때 척추 마디의 비틀림이나 보상 작용 없이 안전하고 부드러운 회전 움직임 수행이 가능함',
          '호흡 시 좌우 늑골이 대칭적으로 확장하고 수축하여 폐 용적을 최대한 활용하는 효율적이고 깊은 호흡 패턴을 정상적으로 수행함',
          '바닥에 엎드린 운동 자세(Plank 등)에서 등의 면적이 수평을 유지하여 코어 근육의 균형 잡힌 발달을 돕는 최적의 움직임 환경임',
        ],
        bodyStress: [
          '흉곽의 비대칭적 회전 압박이 발생하지 않아 갈비뼈 주변이나 명치 부근의 답답함 없이 일상 속 호흡이 매우 편안한 상태임',
          '등 뒤쪽 근육의 불균형한 수축이나 늘어남이 없어 만성적인 등 결림이나 날개뼈 안쪽의 찌릿한 불편감 발생 리스크가 매우 낮음',
          '척추 분절의 정렬이 바르게 유지되어 장시간 구부정한 자세를 유지한 후에도 등 주변의 피로 해소가 빠른 뛰어난 회복 탄력성을 보임',
          '늑골과 척추가 만나는 관절 부위의 가동성이 원활하게 확보되어 상체 움직임 시 소리가 나거나 걸리는 이물감 없이 매끄러움',
          '등 주변 근육의 긴장도가 좌우 고르게 분산되어 특정 부위의 근육 피로로 인해 수면을 방해받거나 기상 후 뻐근함이 느껴지지 않음',
        ],
        appearanceImpact: [
          '등이 평평하고 매끄러워, 뒷모습에서 군살 없이 슬림한 실루엣으로 보임',
          '가슴우리 정렬이 안정적으로 유지되어 앞가슴 라인이 좌우로 대칭적이고, 상의 핏이 깔끔하게 보임',
          '날개뼈 주변이 부풀어 보이지 않아, 등 라인이 또렷하고 탄탄해 보이는 인상 형성됨',
          '상체 회전이 두드러지지 않아 얼굴이 정면을 향하며, 좌우 얼굴 라인이 비교적 균형 있게 보임',
          '상체 전체 볼륨이 좌우로 조화를 이루어, 실제보다 날씬해 보이는 시각적 인상 형성됨',
        ],
      },
    };

    const shoulderD = SHOULDER_HIGHER_DATA[higherSide];
    const contourD = CONTOUR_DATA[contourSide];

    const pick2Shoulder = <T>(arr: T[]): T[] => {
      const shuffled = [...arr].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 2);
    };

    return {
      order: 3,
      title: '어깨 높이와 입체 윤곽 정렬',
      images: [
        { assetKey: shoulderAsset, url: this.resolveBodyChangeUrl(shoulderAsset) },
        { assetKey: contourAsset, url: this.resolveBodyChangeUrl(contourAsset) },
      ],
      summary,
      dailyPatterns: [...pick2Shoulder(shoulderD.dailyPatterns), ...pick2Shoulder(contourD.dailyPatterns)],
      bodyStress: [...pick2Shoulder(shoulderD.bodyStress), ...pick2Shoulder(contourD.bodyStress)],
      appearanceImpact: [...pick2Shoulder(shoulderD.appearanceImpact), ...pick2Shoulder(contourD.appearanceImpact)],
    };
  }

  // ─────────────────────────────────────────────────────────────
  // 정렬 특성에 따른 일상-트레이닝 적용 가이드 + 정렬 흐름 요약
  // ─────────────────────────────────────────────────────────────

  /**
   * `alignmentFlowSummary` + `trainingGuides` 두 블록을 한 번에 반환.
   * 각 카테고리의 조합 키로 개입 방향 + 실행 접근 방법을 결정한다.
   *
   * @param pelvicReaction  forwardBend.pelvicReaction
   * @param legUsage        scoreDetail.legUsage
   * @param bodyCenter      forwardBend.bodyCenter
   * @param shoulderAlignment higherShoulder (어깨 높이·척추 라인)
   */
  private buildAlignmentFlowAndTrainingGuides(
    pelvicReaction: any,
    legUsage: any,
    bodyCenter: any,
    shoulderAlignment: any,
  ): { alignmentFlowSummary: any; trainingGuides: any } {

    // ── 상태 분류
    const pelvicState: '오른쪽' | '왼쪽' | '균형' =
      !pelvicReaction || pelvicReaction.isNormal ? '균형'
        : pelvicReaction.higherSide === '오른쪽' ? '오른쪽' : '왼쪽';

    const legDominant: '오른쪽' | '왼쪽' | '균형' =
      !legUsage || legUsage.dominantSide === '균형' ? '균형'
        : legUsage.dominantSide === '오른쪽' ? '오른쪽' : '왼쪽';

    const centerDir: '오른쪽' | '왼쪽' | '중앙' =
      !bodyCenter || Math.abs(bodyCenter.result ?? 0) <= SPINAL_ALIGNMENT.TILT_THRESHOLD_PX ? '중앙'
        : (bodyCenter.result ?? 0) > 0 ? '오른쪽' : '왼쪽';

    const spineDir: '오른쪽' | '왼쪽' | '중앙' =
      !shoulderAlignment || shoulderAlignment.disease === 'NORMAL' ? '중앙'
        : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';

    const shoulderHigher: '오른쪽' | '왼쪽' | '균형' =
      !shoulderAlignment || shoulderAlignment.disease === 'NORMAL' ? '균형'
        : shoulderAlignment.disease === 'SPINE_CURVED_RIGHT' ? '오른쪽' : '왼쪽';

    // 윤곽: 상태분석·사진과 동일 — 숙일 때 어깨 높은 쪽 = 등·어깨 윤곽 도드라진 쪽
    const contourHigher = shoulderHigher;

    // ── 하체 지지 밸런스 가이드 데이터 (9조합)
    type LBKey = `${string}_${string}`;
    const LOWER_BODY_GUIDES: Record<LBKey, { direction: string; approaches: string[] }> = {
      '오른쪽_오른쪽': {
        direction: '왼쪽 하체 지지 감각 강화와 체중 중심 왼쪽 이동 유도',
        approaches: [
          '서 있을 때 왼쪽 다리에 체중 60% 배분을 통한 오른쪽 골반 내려오는 감각 유도',
          '계단 오르기 시 왼쪽 다리 우선 사용을 통한 오른쪽 하체 부담 감소',
          '사이드 레그 레이즈를 통한 왼쪽 중간 엉덩이 근육 강화 및 골반 수평 유지 능력 향상',
        ],
      },
      '오른쪽_왼쪽': {
        direction: '왼쪽 다리 피로 완화와 오른쪽 지지 감각 회복 유도',
        approaches: [
          '보행 시 오른쪽 발바닥 바닥 밀기 감각 강화를 통한 골반 내려오는 움직임 활성화',
          '왼쪽 사이드 크런치를 통한 왼쪽 복부 탄력 회복 및 몸통 중심 유지',
          '앉은 자세에서 양발 고른 접지를 통한 상하체 연결 감각 균형 향상',
        ],
      },
      '오른쪽_균형': {
        direction: '오른쪽 옆구리 공간 확보와 골반 수평 상태 회복 유도',
        approaches: [
          '서 있는 자세에서 오른쪽 골반 아래 방향 인지를 통한 수평 정렬 인식',
          '보행 시 오른쪽 발바닥 깊은 접지를 통한 오른쪽 골반 내려오는 감각 형성',
          '버드독 동작을 통한 오른쪽 옆 공간 확장',
        ],
      },
      '왼쪽_오른쪽': {
        direction: '오른쪽 다리 피로 완화와 왼쪽 지지 감각 회복 유도',
        approaches: [
          '보행 시 왼쪽 다리 바닥 밀기 강화를 통한 왼쪽 하체 사용 활성화',
          '오른쪽 사이드 크런치를 통한 오른쪽 복부 탄력 회복 및 몸통 중심 유지',
          '왼쪽 다리 지지 런지를 통한 왼쪽 하체 지지력 및 정렬 유지 능력 강화',
        ],
      },
      '왼쪽_왼쪽': {
        direction: '체중 재배치 유도와 왼쪽 측면 공간 회복 유도',
        approaches: [
          '양발 지지 시 체중 오른쪽 60% 배분을 통한 왼쪽 골반 높이 조절 보조',
          '계단 오르기 시 오른쪽 다리 집중 사용을 통한 오른쪽 지지 기능 회복',
          '사이드 레그 레이즈를 통한 오른쪽 중간 엉덩이 근육 강화 및 골반 수평 유지 능력 향상',
        ],
      },
      '왼쪽_균형': {
        direction: '왼쪽으로 올라가려는 경향 완화와 오른쪽 지지 감각 강화',
        approaches: [
          '앉은 자세에서 왼쪽 엉덩이 깊은 지지를 통한 골반 안정 하강 유도',
          '보행 시 왼쪽 발바닥 깊은 접지를 통한 왼쪽 골반 내려오는 감각 형성',
          '벽을 이용한 스쿼트 동작 중 왼쪽 골반 하강 인지를 통한 하체 균형 유지',
        ],
      },
      '균형_오른쪽': {
        direction: '오른쪽 다리 사용 집중 완화와 체중 배분 균형 유도',
        approaches: [
          '보행 시 왼쪽 발바닥 전체 접지를 통한 양발 추진력 균형 조절',
          '보행 시 왼쪽 발가락까지 바닥 밀기 감각 활성화를 통한 추진력 균형 유지',
          '왼쪽 다리 중심 스텝 업 운동을 통한 왼쪽 하체 추진력 강화',
        ],
      },
      '균형_왼쪽': {
        direction: '왼쪽 다리 부담 완화와 오른쪽 지지 감각 회복 유도',
        approaches: [
          '서 있는 자세에서 오른쪽 발바닥 세 지점 지지 상태 점검',
          '보행 시 오른쪽 발바닥 전체 접지를 통한 양발 사용 균형 조절',
          '오른쪽 한 발 서기를 통한 오른쪽 지지 감각 및 안정성 향상',
        ],
      },
      '균형_균형': {
        direction: '몸 중심 안정감 유지와 위로 길어지는 자세 감각 관리',
        approaches: [
          '앉은 자세에서 양쪽 엉덩이뼈 체중 5:5 분배 점검',
          '정수리를 위로 길게 늘리는 감각 유지를 통한 곧은 자세 인식',
          '데드버그 운동을 통한 팔다리 움직임 중 몸 중심 안정 유지',
        ],
      },
    };

    // ── 상체 중심 흐름 조정 가이드 데이터 (9조합)
    const UPPER_BODY_GUIDES: Record<string, { direction: string; approaches: string[] }> = {
      '오른쪽_오른쪽': {
        direction: '오른쪽으로 쏠린 상체의 왼쪽 이동 유도와 왼쪽 측면 공간 압박 완화',
        approaches: [
          '앉은 자세에서 몸통 왼쪽 이동과 오른쪽 등 뒤 쿠션 활용을 통한 상체 쏠림 감소',
          '왼쪽 팔 위로 뻗는 스트레칭을 통한 왼쪽 옆구리 공간 확보',
          '팔로프 프레스 시 오른쪽 당김에 버티며 상체 왼쪽 중심 유지',
        ],
      },
      '오른쪽_왼쪽': {
        direction: '오른쪽으로 치우친 자세의 가운데 회복 유도와 오른쪽 측면 공간 확장',
        approaches: [
          '모니터 왼쪽 배치를 통한 작업 중 몸 중심 조정',
          '아이 자세에서 왼쪽 대각선 팔 뻗기를 통한 오른쪽 옆 공간 확장',
          '오른쪽 팔 위로 뻗는 스트레칭을 통한 오른쪽 옆구리 공간 확장',
        ],
      },
      '오른쪽_중앙': {
        direction: '오른쪽으로 밀린 상체 위치를 가운데로 맞추고 왼쪽 상체 사용 감각 활성화',
        approaches: [
          '벽 지지 상태에서 왼쪽 골반 오른쪽 밀기를 통한 몸 중심 바로 세우기',
          '한 팔 당기기 동작에서 왼쪽 몸통 지지 활용을 통한 상체 쏠림 방지',
          '팔로프 프레스에서 왼쪽 몸통 사용을 통한 상체 중심 유지',
        ],
      },
      '왼쪽_오른쪽': {
        direction: '왼쪽으로 치우친 자세의 가운데 회복 유도와 왼쪽 측면 공간 확장',
        approaches: [
          '모니터 오른쪽 배치를 통한 작업 중 몸 중심 조정',
          '아이 자세에서 오른쪽 대각선 팔 뻗기를 통한 왼쪽 옆 공간 확장',
          '왼쪽 팔 위로 뻗는 스트레칭을 통한 왼쪽 옆구리 공간 확보',
        ],
      },
      '왼쪽_왼쪽': {
        direction: '왼쪽으로 쏠린 상체의 오른쪽 이동 유도와 오른쪽 측면 공간 압박 완화',
        approaches: [
          '앉은 자세에서 몸통 오른쪽 이동과 왼쪽 등 뒤 쿠션 활용을 통한 상체 쏠림 감소',
          '오른쪽 팔 위로 뻗는 스트레칭을 통한 오른쪽 옆구리 공간 확보',
          '팔로프 프레스 시 왼쪽 당김에 버티며 상체 오른쪽 중심 유지',
        ],
      },
      '왼쪽_중앙': {
        direction: '상체 왼쪽 치우침 방지를 위한 오른쪽 몸통 지지 감각 강화와 수직 정렬 유도',
        approaches: [
          '벽 지지 상태에서 오른쪽 골반 왼쪽 밀기를 통한 몸 중심 바로 세우기',
          '원 암 로우 시 오른쪽 몸통 지지 활용을 통한 상체 쏠림 방지',
          '팔로프 프레스에서 오른쪽 몸통 사용을 통한 상체 중심 유지',
        ],
      },
      '중앙_오른쪽': {
        direction: '몸 중심 유지 유도와 왼쪽 측면 공간 확장을 통한 좌우 사용 불균형 완화',
        approaches: [
          '왼쪽 팔 위로 뻗는 스트레칭을 통한 왼쪽 가슴 옆 공간 확보',
          '오른쪽 팔 앞으로 뻗기와 왼쪽 어깨 뒤로 당김을 통한 상체 회전 균형 조절',
          '오른쪽 가슴 스트레칭을 통한 오른쪽 가슴 열기',
        ],
      },
      '중앙_왼쪽': {
        direction: '전체 중심 유지 유도와 오른쪽 측면 공간 확장을 통한 좌우 균형 회복',
        approaches: [
          '오른쪽 팔 위로 뻗는 스트레칭을 통한 오른쪽 가슴 옆 공간 확보',
          '왼쪽 팔 앞으로 뻗기와 오른쪽 어깨 뒤로 당김을 통한 상체 회전 균형 조절',
          '왼쪽 가슴 스트레칭을 통한 왼쪽 가슴 열기',
        ],
      },
      '중앙_중앙': {
        direction: '안정적인 자세 유지를 위한 좌우 지지 감각 균형 확보와 중립 상태 관리',
        approaches: [
          '물건 들기 시 양손 사용을 통한 좌우 흔들림 최소화',
          '정수리를 위로 끌어올리는 감각 유지를 통한 중심 정렬 유지',
          '플랭크 동작을 통한 머리부터 발끝까지 가운데 정렬 유지',
        ],
      },
    };

    // ── 어깨·상체 윤곽 관리 가이드 데이터 (9조합)
    const SHOULDER_GUIDES: Record<string, { direction: string; approaches: string[] }> = {
      '오른쪽_오른쪽': {
        direction: '왼쪽 등 공간 확장을 통한 상체 사용 균형 회복과 어깨 위치 안정화 유도',
        approaches: [
          '가방 착용 시 왼쪽 어깨 사용을 통한 어깨 높이 균형 유도',
          '월 슬라이드와 월 푸시업 플러스를 통한 오른쪽 어깨 안정 위치 유도',
          '오른쪽 가슴 스트레칭을 통한 오른쪽 가슴 열림',
        ],
      },
      '오른쪽_왼쪽': {
        direction: '오른쪽 등 공간 확장을 통한 상체 사용 균형 회복과 어깨 위치 안정화 유도',
        approaches: [
          '문을 지나가거나 물건을 집을 때 오른쪽으로 몸을 돌려 접근',
          '월 슬라이드와 월 푸시업 플러스를 통한 왼쪽 어깨 안정 위치 유도',
          '암 서클 동작을 통한 왼쪽 앞쪽 공간 입체적 확장',
        ],
      },
      '오른쪽_균형': {
        direction: '오른쪽 등세모근 긴장 완화와 어깨 높이 균형 회복을 위한 상체 정렬 유도',
        approaches: [
          '가방 착용 시 낮은 쪽 왼쪽 어깨 사용을 통한 어깨 수평 유도',
          '통화 시 무선 이어폰 사용을 통한 어깨 중립 상태 유지',
          '숄더 프레스 중 오른쪽 어깨 상승 방지를 위한 범위와 속도 조절',
        ],
      },
      '왼쪽_오른쪽': {
        direction: '왼쪽 등 공간 확장을 통한 상체 사용 균형 회복과 어깨 위치 안정화 유도',
        approaches: [
          '문을 지나가거나 물건을 집을 때 왼쪽으로 몸을 돌려 접근',
          '월 슬라이드와 월 푸시업 플러스를 통한 오른쪽 어깨 안정화 유도',
          '암 서클 동작을 통한 오른쪽 앞쪽 공간 입체적 확장',
        ],
      },
      '왼쪽_왼쪽': {
        direction: '오른쪽 등 공간 확장을 통한 상체 사용 균형 회복과 어깨 위치 안정화 유도',
        approaches: [
          '가방 착용 시 오른쪽 어깨 사용을 통한 어깨 높이 균형 유도',
          '월 슬라이드와 월 푸시업 플러스를 통한 왼쪽 어깨 안정화 유도',
          '왼쪽 가슴 스트레칭을 통한 왼쪽 가슴 열림',
        ],
      },
      '왼쪽_균형': {
        direction: '왼쪽 등세모근 긴장 완화와 어깨 높이 균형 회복을 위한 상체 정렬 유도',
        approaches: [
          '가방 착용 시 낮은 쪽 오른쪽 어깨 사용을 통한 어깨 수평 유도',
          '통화 시 무선 이어폰 사용을 통한 어깨 이완 상태 유지',
          '숄더 프레스 중 왼쪽 어깨 상승 방지를 위한 동작 조절',
        ],
      },
      '균형_오른쪽': {
        direction: '오른쪽 어깨 안정화 유도',
        approaches: [
          '푸시업 플러스 동작을 통한 오른쪽 앞톱니근 사용 감각 활성화',
          '네발기기 자세에서 왼손 들기와 오른손 바닥 밀기를 통한 오른쪽 등 라인 정리 유도',
          '월 런지 자세에서 오른손 지지를 통한 상체 정면 유지',
        ],
      },
      '균형_왼쪽': {
        direction: '왼쪽 어깨 안정화 유도',
        approaches: [
          '푸시업 플러스 동작을 통한 왼쪽 앞톱니근 사용 감각 활성화',
          '네발기기 자세에서 오른손 들기와 왼손 바닥 밀기를 통한 왼쪽 등 라인 정리 유도',
          '월 런지 자세에서 왼손 지지를 통한 상체 정면 유지',
        ],
      },
      '균형_균형': {
        direction: '대칭 자세 유지를 위한 날개뼈 중립 위치 인식과 몸통 중심 조절 감각 관리',
        approaches: [
          '장시간 앉은 자세에서 50분 간격 정수리 위쪽 신장 감각 유지',
          '보행 시 팔 흔들림과 발 추진력의 일정성 점검',
          '플랭크와 사이드 플랭크를 통한 몸통 중심 버티기 힘 관리',
        ],
      },
    };

    // ── 각 카테고리 가이드 조합 선택
    const lowerKey = `${pelvicState}_${legDominant}` as LBKey;
    const upperKey = `${centerDir}_${spineDir}`;
    const shoulderKey = `${shoulderHigher}_${contourHigher}`;

    const lowerGuide = LOWER_BODY_GUIDES[lowerKey];
    const upperGuide = UPPER_BODY_GUIDES[upperKey];
    const shoulderGuide = SHOULDER_GUIDES[shoulderKey];

    // ── trainingGuides 빌드
    const trainingGuides = {
      guides: [
        {
          category: '하체 지지 밸런스 가이드',
          themeColor: 'pink',
          direction: lowerGuide.direction,
          approaches: lowerGuide.approaches,
        },
        {
          category: '상체 중심 흐름 조정 가이드',
          themeColor: 'blue',
          direction: upperGuide.direction,
          approaches: upperGuide.approaches,
        },
        {
          category: '어깨·상체 윤곽 관리 가이드',
          themeColor: 'gray',
          direction: shoulderGuide.direction,
          approaches: shoulderGuide.approaches,
        },
      ],
      footerNote:
        '이를 지속적으로 적용할 경우 몸의 사용 방식이 보다 체계적으로 관리되며 트레이닝 효과가 안정적으로 축적될 수 있습니다.',
    };

    // ── alignmentFlowSummary 빌드

    // 균형 여부 판단
    // 민트(fully balanced) = 3개 카테고리 모두 완전 균형
    const isLowerBalanced = pelvicState === '균형' && legDominant === '균형';
    const isUpperBalanced = centerDir === '중앙' && spineDir === '중앙';
    const isShoulderBalanced = shoulderHigher === '균형' && contourHigher === '균형';
    const isMint = isLowerBalanced && isUpperBalanced && isShoulderBalanced;

    // ── 1번 빈칸 조합 텍스트 테이블 (27조합)
    const LOWER_COMBO: Record<string, string> = {
      '오른쪽_오른쪽': '오른쪽 골반 상승 · 오른쪽 지지 경향',
      '오른쪽_왼쪽': '오른쪽 골반 상승 · 왼쪽 지지 경향',
      '오른쪽_균형': '오른쪽 골반 상승 · 하체 균형 경향',
      '왼쪽_오른쪽': '왼쪽 골반 상승 · 오른쪽 지지 경향',
      '왼쪽_왼쪽': '왼쪽 골반 상승 · 왼쪽 지지 경향',
      '왼쪽_균형': '왼쪽 골반 상승 · 하체 균형 경향',
      '균형_오른쪽': '골반 안정 · 오른쪽 지지 경향',
      '균형_왼쪽': '골반 안정 · 왼쪽 지지 경향',
      '균형_균형': '골반 안정 · 하체 균형 경향',
    };
    const UPPER_COMBO: Record<string, string> = {
      '오른쪽_오른쪽': '상체 오른쪽 이동 · 척추 오른쪽 흐름 경향',
      '오른쪽_왼쪽': '상체 오른쪽 이동 · 척추 왼쪽 흐름 경향',
      '오른쪽_중앙': '상체 오른쪽 이동 · 중앙 척추 흐름 경향',
      '왼쪽_오른쪽': '상체 왼쪽 이동 · 척추 오른쪽 흐름 경향',
      '왼쪽_왼쪽': '상체 왼쪽 이동 · 척추 왼쪽 흐름 경향',
      '왼쪽_중앙': '상체 왼쪽 이동 · 중앙 척추 흐름 경향',
      '중앙_오른쪽': '상체-골반 일치 · 척추 오른쪽 흐름 경향',
      '중앙_왼쪽': '상체-골반 일치 · 척추 왼쪽 흐름 경향',
      '중앙_중앙': '상체-골반 일치 · 중앙 척추 흐름 경향',
    };
    const SHOULDER_COMBO: Record<string, string> = {
      '오른쪽_오른쪽': '오른쪽 어깨 높이 · 오른쪽 윤곽 두드러짐 경향',
      '오른쪽_왼쪽': '오른쪽 어깨 높이 · 왼쪽 윤곽 두드러짐 경향',
      '오른쪽_균형': '오른쪽 어깨 높이 · 윤곽 균형 경향',
      '왼쪽_오른쪽': '왼쪽 어깨 높이 · 오른쪽 윤곽 두드러짐 경향',
      '왼쪽_왼쪽': '왼쪽 어깨 높이 · 왼쪽 윤곽 두드러짐 경향',
      '왼쪽_균형': '왼쪽 어깨 높이 · 윤곽 균형 경향',
      '균형_오른쪽': '어깨 높이 유사 · 오른쪽 윤곽 두드러짐 경향',
      '균형_왼쪽': '어깨 높이 유사 · 왼쪽 윤곽 두드러짐 경향',
      '균형_균형': '어깨 높이 유사 · 윤곽 균형 경향',
    };

    // ── 우선순위에 따른 대표 카테고리 선택
    // 1순위: 하체(골반/하체 비정상) → 2순위: 상체(상체/척추 비정상) → 3순위: 어깨(어깨/윤곽 비정상)
    // 4순위(민트): 모두 균형 → 무작위 선택
    const primaryCategory: 'shoulder' | 'upper' | 'lower' = !isLowerBalanced
      ? 'lower'
      : !isUpperBalanced
      ? 'upper'
      : !isShoulderBalanced
      ? 'shoulder'
      : (['lower', 'upper', 'shoulder'] as const)[Math.floor(Math.random() * 3)];

    const comboText =
      primaryCategory === 'shoulder' ? SHOULDER_COMBO[shoulderKey]
      : primaryCategory === 'upper' ? UPPER_COMBO[upperKey]
      : LOWER_COMBO[lowerKey];

    // ── patternSummary
    // 검은색(비정상): 이는 질환이나 이상이 아니라...
    // 빨간색(균형/민트): 이는 질환이나 이상을 의미하는 것이 아니라...
    const patternSuffix = isMint
      ? '이는 질환이나 이상을 의미하는 것이 아니라, 지금까지의 일상 자세·신체 사용 습관·운동 방식이 비교적 균형 있게 유지되며 형성된 현재의 신체 사용 경향으로 해석할 수 있습니다.'
      : '이는 질환이나 이상이 아니라, 일상 자세와 움직임 사용이 누적되며 만들어진 현재의 신체 사용 패턴으로 볼 수 있습니다.';

    const patternSummary =
      `회원님의 주요 정렬·움직임 패턴을 종합해보면,\n` +
      `현재 신체는 특정 방향으로 <b>${comboText}</b>을 보이고 있습니다.\n` +
      `<b>${patternSuffix}</b>`;

    // ── 무작위 항목 선택 헬퍼
    const pickRandom = (arr: string[]): string =>
      arr[Math.floor(Math.random() * arr.length)] ?? '';

    // 각 섹션 데이터를 primaryCategory에 해당하는 섹션에서만 가져옴
    // (1번 빈칸을 결정한 카테고리와 동일한 섹션에서 1~3번 문장 픽)
    const lowerSec = this.buildLowerBodySection(pelvicReaction, legUsage);
    const upperSec = this.buildUpperBodySection(bodyCenter, shoulderAlignment);
    const shoulderSec = this.buildShoulderSection(shoulderAlignment);

    const primarySec =
      primaryCategory === 'lower' ? lowerSec
      : primaryCategory === 'upper' ? upperSec
      : shoulderSec;

    const selectedPattern = pickRandom(primarySec.dailyPatterns);
    const selectedStress = pickRandom(primarySec.bodyStress);
    const selectedAppearance = pickRandom(primarySec.appearanceImpact);

    // 한국어 조사 헬퍼 (받침 여부에 따라 결정)
    const josa = (word: string, withBatchim: string, noBatchim: string): string => {
      const ch = word.replace(/[.!?·\s]+$/, '').slice(-1);
      const code = ch.charCodeAt(0);
      return code >= 0xAC00 && code <= 0xD7A3 && (code - 0xAC00) % 28 > 0
        ? withBatchim
        : noBatchim;
    };

    const pattern =
      `이러한 패턴으로 인해,\n일상 움직임에서의 사용 패턴에서는\n` +
      `<b>${selectedPattern}</b>${josa(selectedPattern, '과', '와')} 같이\n` +
      `현재의 몸 사용 상태를 보여주는 양상이 관찰될 수 있습니다.`;

    const dailyMovementImpact =
      `일상에서 느껴지는 신체 부담에서는\n` +
      `<b>${selectedStress}</b>${josa(selectedStress, '과', '와')} 같이,\n` +
      `현재 정렬 상태가 신체 부담의 정도와 체감 양상에 반영되는 모습으로 인지될 수 있습니다.`;

    const trainingDirection =
      `체형 변화로 인한 외형 인상에서는\n` +
      `<b>${selectedAppearance}</b>${josa(selectedAppearance, '과', '와')} 같이\n` +
      `현재 정렬 상태가 외형적으로 반영되는 특징으로 이어질 수 있습니다.`;

    // ── futurePlan
    // 1번 빈칸 = primaryCategory의 개입 방향
    // 2번 빈칸 = 해당 가이드의 무작위 접근 방법
    const primaryGuide =
      primaryCategory === 'shoulder' ? shoulderGuide
      : primaryCategory === 'upper' ? upperGuide
      : lowerGuide;

    const randomApproach = pickRandom(primaryGuide.approaches);
    const dirEulReul = josa(primaryGuide.direction, '을', '를');
    const appWaGwa = josa(randomApproach, '과', '와');

    // suffix3 / result: 민트(균형) vs 비민트(비정상)
    const futureSuffix3 = isMint
      ? '현재의 안정적인 중심 정렬이 유지되면서 신체 사용의 균형이 더욱 정교해지고,\n일상 움직임·체형 인상·운동 동작 전반에서 가볍고 효율적인 움직임이 이어질 수 있습니다.'
      : '몸의 중심이 점차 중앙으로 정리되면서 신체 사용의 편차가 완화되고, 일상 움직임·체형 인상·운동 동작 전반에서\n보다 안정감 있는 변화가 나타날 수 있습니다.';

    const result = isMint
      ? '앞으로도\n회원님의 몸이 가진 현재의 좋은 패턴을 안정적으로 유지하고\n더 높은 움직임 효율로 확장될 수 있도록, 트레이닝을 단계별로 정교하게 설계해드리겠습니다.'
      : '앞으로도\n회원님의 몸이 가장 자연스럽고 효율적인 패턴으로 돌아갈 수 있도록\n트레이닝을 단계별로 안전하게 맞춰드리겠습니다.';

    const futurePlan =
      `이러한 사용 패턴을 보다 효율적으로 조절하기 위해,\n` +
      `앞으로의 트레이닝 프로그램은\n` +
      `<b>${primaryGuide.direction}</b>${dirEulReul} 핵심 방향으로 설정하여,\n` +
      `<b>${randomApproach}</b>${appWaGwa} 같은 접근을 중심으로 진행할 예정입니다.\n` +
      `<b>${futureSuffix3}</b>`;

    const alignmentFlowSummary = {
      patternSummary,
      pattern,
      dailyMovementImpact,
      trainingDirection,
      futurePlan,
      result,
      solutionButton: '맞춤 운동 솔루션',
    };

    return { alignmentFlowSummary, trainingGuides };
  }
}

