import { Repository } from 'typeorm';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../../database/entities/center-trainer.entity';

export async function resolveCenterLogoUrl(
  trainerId: string | null | undefined,
  deps: {
    centerRepo: Repository<CenterEntity>;
    centerTrainerRepo: Repository<CenterTrainerEntity>;
  },
): Promise<string | null> {
  if (!trainerId) {
    return null;
  }

  const ownedCenter = await deps.centerRepo.findOne({
    where: { ownerId: trainerId },
    select: ['logoUrl'],
  });
  if (ownedCenter?.logoUrl) {
    return ownedCenter.logoUrl;
  }

  const affiliation = await deps.centerTrainerRepo.findOne({
    where: {
      trainerId,
      status: CenterTrainerStatus.WORKING,
    },
    relations: ['center'],
  });

  return affiliation?.center?.logoUrl ?? null;
}
