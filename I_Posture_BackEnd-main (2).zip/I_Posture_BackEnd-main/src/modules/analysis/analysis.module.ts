import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnalysisController, DevAnalysisController } from './analysis.controller';
import { AnalysisService } from './analysis.service';
import { AnalyticService } from './analytic.service';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity'; // 추가
import { BodyStrategy } from './strategies/body.strategy';
import { NeckStrategy } from './strategies/neck.strategy';
import { ShouldersStrategy } from './strategies/shoulders.strategy';
import { KneesStrategy } from './strategies/knees.strategy';
import { PelvisStrategy } from './strategies/pelvis.strategy';
import { TorsoStrategy } from './strategies/torso.strategy';
import { ElbowsStrategy } from './strategies/elbows.strategy';
import { AnkleStrategy } from './strategies/ankle.strategy';
import { SpinalAlignmentTestStrategy } from './strategies/spinal-alignment-test.strategy';
import { OverheadSquatTestStrategy } from './strategies/overhead-squat-test.strategy';
import { BalanceTestStrategy } from './strategies/balance-test.strategy';
import { S3Module } from '../../s3/s3.module';
import { CapacityModule } from '../capacity/capacity.module';
import { AnkleAnalysis } from './strategies/body/ankle.analysis';
import { BackAnalysis } from './strategies/body/back.analysis';
import { BalanceIndexAnalysis } from './strategies/body/balance-index.analysis';
import { HipJointAnalysis } from './strategies/body/hip-joint.analysis';
import { KneeAnalysis } from './strategies/body/knee.analysis';
import { LowerLimbAlignmentAnalysis } from './strategies/body/lower-limb-alignment.analysis';
import { NeckAnalysis } from './strategies/body/neck.analysis';
import { PelvisAnalysis } from './strategies/body/pelvis.analysis';
import { ShoulderAnalysis } from './strategies/body/shoulder.analysis';
import { TorsoAnalysis } from './strategies/body/torso.analysis';
import { UpperArmAnalysis } from './strategies/body/upper-arm.analysis';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      BodyReportEntity,
      PrecisionReportEntity,
      FileEntity,
      RomStandardEntity, // 추가
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
    ]),
    S3Module,
    CapacityModule,
  ],
  controllers: [AnalysisController, DevAnalysisController],
  providers: [
    AnalysisService,
    AnalyticService,
    BodyStrategy,
    NeckStrategy,
    ShouldersStrategy,
    KneesStrategy,
    PelvisStrategy,
    TorsoStrategy,
    ElbowsStrategy,
    AnkleStrategy,
    SpinalAlignmentTestStrategy,
    OverheadSquatTestStrategy,
    BalanceTestStrategy,
    AnkleAnalysis,
    BackAnalysis,
    BalanceIndexAnalysis,
    HipJointAnalysis,
    KneeAnalysis,
    LowerLimbAlignmentAnalysis,
    NeckAnalysis,
    PelvisAnalysis,
    ShoulderAnalysis,
    TorsoAnalysis,
    UpperArmAnalysis,
    SubscriptionGuard,
  ],
})
export class AnalysisModule {}
