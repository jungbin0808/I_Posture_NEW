import { Injectable } from '@nestjs/common';
import { AnalyticStrategy } from './strategies/analytic.strategy';
import { AnalyticResult } from './strategies/analytic.result';
import { Landmarks } from './analysis.types';

@Injectable()
export class AnalyticService {
  private strategy!: AnalyticStrategy;

  public setStrategy(strategy: AnalyticStrategy) {
    this.strategy = strategy;
  }

  public async execute(landmarks: Landmarks): Promise<AnalyticResult> {
    return await this.strategy.execute(landmarks);
  }
}
