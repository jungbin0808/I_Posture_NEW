import { Body, Controller, Post, Param, Req, UploadedFiles, UseGuards, UseInterceptors, BadRequestException, Get, Logger } from '@nestjs/common';
import { FileFieldsInterceptor, AnyFilesInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiParam, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { AnalysisService } from './analysis.service';
import { CreateAnalysisDto } from './dto/create-analysis.dto';
import { CreatePrecisionAnalysisDto } from './dto/create-precision-analysis.dto';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';

@ApiTags('Analysis')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('analysis')
export class AnalysisController {
  private readonly logger = new Logger(AnalysisController.name);

  constructor(private readonly analysisService: AnalysisService) {}

  @ApiOperation({ summary: 'Create Body Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'front_file', maxCount: 1 },
    { name: 'side_file', maxCount: 1 },
    { name: 'back_file', maxCount: 1 },
  ]))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        type: { type: 'string', enum: ['BODY'] },
        landmarks: { type: 'string', description: 'JSON string' },
        measuredAt: { type: 'string', format: 'date-time' },
        __previewSize: { type: 'string', description: 'JSON string of {width, height}' },
        front_file: { type: 'string', format: 'binary' },
        side_file: { type: 'string', format: 'binary' },
        back_file: { type: 'string', format: 'binary' },
      },
    },
  })
  async create(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() body: any,
    @UploadedFiles() files: { front_file?: Express.Multer.File[], side_file?: Express.Multer.File[], back_file?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<BodyReportEntity>> {
    const createDto = new CreateAnalysisDto();
    createDto.type = body.type as any;
    createDto.measuredAt = body.measuredAt;
    
    try {
      if (typeof body.landmarks === 'string') {
        createDto.landmarks = JSON.parse(body.landmarks);
      } else {
        createDto.landmarks = body.landmarks;
      }
      if (body.__previewSize) {
        if (typeof body.__previewSize === 'string') {
          createDto.__previewSize = JSON.parse(body.__previewSize);
        } else {
          createDto.__previewSize = body.__previewSize;
        }
      }
    } catch (e) {
      this.logger.error(`JSON parse error: ${(e as Error).message}, body: ${JSON.stringify(body)}`);
      throw new BadRequestException('Invalid JSON string in body');
    }

    if (!createDto.landmarks || typeof createDto.landmarks !== 'object') {
      throw new BadRequestException('landmarks must be a JSON object');
    }

    const result = await this.analysisService.analysis(req.user, memberId, createDto, files) as BodyReportEntity;
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '내 체형측정(셀프) 등록 - Role.Member' })
  @Roles(Role.Member)
  @Post('me')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'front_file', maxCount: 1 },
    { name: 'side_file', maxCount: 1 },
    { name: 'back_file', maxCount: 1 },
  ]))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        landmarks: { type: 'string', description: 'JSON string (step1_front/step2_right/step3_rear 3장 랜드마크)' },
        measuredAt: { type: 'string', format: 'date-time' },
        __previewSize: { type: 'string', description: 'JSON string of {width, height}' },
        front_file: { type: 'string', format: 'binary' },
        side_file: { type: 'string', format: 'binary' },
        back_file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createSelf(
    @Req() req: { user: UserEntity },
    @Body() body: any,
    @UploadedFiles() files: { front_file?: Express.Multer.File[], side_file?: Express.Multer.File[], back_file?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<BodyReportEntity>> {
    const createDto = new CreateAnalysisDto();
    createDto.type = 'BODY' as any;
    createDto.measuredAt = body.measuredAt;

    try {
      createDto.landmarks = typeof body.landmarks === 'string' ? JSON.parse(body.landmarks) : body.landmarks;
      if (body.__previewSize) {
        createDto.__previewSize = typeof body.__previewSize === 'string' ? JSON.parse(body.__previewSize) : body.__previewSize;
      }
    } catch (e) {
      this.logger.error(`JSON parse error: ${(e as Error).message}, body: ${JSON.stringify(body)}`);
      throw new BadRequestException('Invalid JSON string in body');
    }

    if (!createDto.landmarks || typeof createDto.landmarks !== 'object') {
      throw new BadRequestException('landmarks must be a JSON object');
    }

    const result = await this.analysisService.analyzeSelf(req.user, createDto, files);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Create Spinal Alignment Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('spinal-alignment/member/:memberId')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'back_file', maxCount: 1 },
    { name: 'back_bend_file', maxCount: 1 },
  ]))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        landmarks: { type: 'string', description: 'JSON string with back and optional back_bend keys' },
        measuredAt: { type: 'string', format: 'date-time' },
        back_file: { type: 'string', format: 'binary' },
        back_bend_file: { type: 'string', format: 'binary', description: '전굴 자세 뒷면 사진 (선택)' },
      },
    },
  })
  async createSpinalAlignment(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() body: any,
    @UploadedFiles() files: { back_file?: Express.Multer.File[]; back_bend_file?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<PrecisionReportEntity>> {
    const createDto = new CreateAnalysisDto();
    createDto.type = 'SPINAL_ALIGNMENT_TEST' as any;
    createDto.measuredAt = body.measuredAt;
    try {
      createDto.landmarks = typeof body.landmarks === 'string' ? JSON.parse(body.landmarks) : body.landmarks;
    } catch (e) {
      throw new BadRequestException('Invalid JSON string in body');
    }
    const result = await this.analysisService.createSpinalAlignmentAnalysis(req.user, memberId, createDto, files);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Create Balance Test Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('balance-test/member/:memberId')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'front_left_file', maxCount: 1 },
    { name: 'front_right_file', maxCount: 1 },
    { name: 'left_file', maxCount: 1 },
    { name: 'right_file', maxCount: 1 },
  ]))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        landmarks: { type: 'string', description: 'JSON string with front_left, front_right, left, right keys' },
        measuredAt: { type: 'string', format: 'date-time' },
        front_left_file: { type: 'string', format: 'binary' },
        front_right_file: { type: 'string', format: 'binary' },
        left_file: { type: 'string', format: 'binary' },
        right_file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createBalanceTest(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() body: any,
    @UploadedFiles() files: { front_left_file?: Express.Multer.File[]; front_right_file?: Express.Multer.File[]; left_file?: Express.Multer.File[]; right_file?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<PrecisionReportEntity>> {
    const createDto = new CreateAnalysisDto();
    createDto.type = 'BALANCE_TEST' as any;
    createDto.measuredAt = body.measuredAt;
    try {
      createDto.landmarks = typeof body.landmarks === 'string' ? JSON.parse(body.landmarks) : body.landmarks;
    } catch (e) {
      throw new BadRequestException('Invalid JSON string in body');
    }
    const result = await this.analysisService.createBalanceTestAnalysis(req.user, memberId, createDto, files);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Create Overhead Squat Test Analysis' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('overhead-squat/member/:memberId')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'start_front_file', maxCount: 1 },
    { name: 'start_back_file', maxCount: 1 },
    { name: 'start_left_file', maxCount: 1 },
    { name: 'start_right_file', maxCount: 1 },
    { name: 'end_front_file', maxCount: 1 },
    { name: 'end_back_file', maxCount: 1 },
    { name: 'end_left_file', maxCount: 1 },
    { name: 'end_right_file', maxCount: 1 },
  ]))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        landmarks: { type: 'string', description: 'JSON string with end_front, end_back, end_left, end_right keys' },
        measuredAt: { type: 'string', format: 'date-time' },
        start_front_file: { type: 'string', format: 'binary' },
        start_back_file: { type: 'string', format: 'binary' },
        start_left_file: { type: 'string', format: 'binary' },
        start_right_file: { type: 'string', format: 'binary' },
        end_front_file: { type: 'string', format: 'binary' },
        end_back_file: { type: 'string', format: 'binary' },
        end_left_file: { type: 'string', format: 'binary' },
        end_right_file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createOverheadSquat(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() body: any,
    @UploadedFiles() files: { start_front_file?: Express.Multer.File[]; start_back_file?: Express.Multer.File[]; start_left_file?: Express.Multer.File[]; start_right_file?: Express.Multer.File[]; end_front_file?: Express.Multer.File[]; end_back_file?: Express.Multer.File[]; end_left_file?: Express.Multer.File[]; end_right_file?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<PrecisionReportEntity>> {
    const createDto = new CreateAnalysisDto();
    createDto.type = 'OVERHEAD_SQUAT_TEST' as any;
    createDto.measuredAt = body.measuredAt;
    try {
      createDto.landmarks = typeof body.landmarks === 'string' ? JSON.parse(body.landmarks) : body.landmarks;
    } catch (e) {
      throw new BadRequestException('Invalid JSON string in body');
    }
    const result = await this.analysisService.createOverheadSquatAnalysis(req.user, memberId, createDto, files);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: 'Create Precision Analysis' })

  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('precision/member/:memberId')
  @UseInterceptors(AnyFilesInterceptor())
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        type: { type: 'string' },
        key: { type: 'string' },
        landmarks: { type: 'string', description: 'JSON string' },
        measuredAt: { type: 'string', format: 'date-time' },
        // step1_file, step2_file... 동적 필드
      },
    },
  })
  async createPrecision(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() body: any,
    @UploadedFiles() files: Array<Express.Multer.File>,
  ): Promise<ISuccessResponse<PrecisionReportEntity>> {
    this.logger.log(`createPrecision body: ${JSON.stringify(body)}`);

    const createDto = new CreatePrecisionAnalysisDto();
    createDto.type = body.type;
    createDto.key = body.key;
    createDto.measuredAt = body.measuredAt;
    
    try {
      if (typeof body.landmarks === 'string') {
        createDto.landmarks = JSON.parse(body.landmarks);
      } else {
        createDto.landmarks = body.landmarks;
      }
    } catch (e) {
      this.logger.error(`JSON parse error: ${(e as Error).message}, body: ${JSON.stringify(body)}`);
      throw new BadRequestException('Invalid JSON string in body');
    }

    const result = await this.analysisService.createPrecisionAnalysis(req.user, memberId, createDto, files);
    return SuccessResponse(result);
  }

  // ─── 어드민 전용: 재분석 API ──────────────────────────────────────────────

  @ApiOperation({ summary: '[Admin] 체형 리포트 단건 재분석 (scoreDetail/disease 재계산)' })
  @ApiParam({ name: 'reportId', description: 'BodyReport ID' })
  @Roles(Role.Admin)
  @Post('admin/reanalyze/body/:reportId')
  async reanalyzeBody(@Param('reportId') reportId: string) {
    const result = await this.analysisService.reanalyzeBodyReport(reportId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '[Admin] 정밀 리포트 단건 재분석' })
  @ApiParam({ name: 'reportId', description: 'PrecisionReport ID' })
  @Roles(Role.Admin)
  @Post('admin/reanalyze/precision/:reportId')
  async reanalyzePrecision(@Param('reportId') reportId: string) {
    const result = await this.analysisService.reanalyzePrecisionReport(reportId);
    return SuccessResponse(result);
  }
}

// ─── 개발용 (인증 없음): 재분석 API ─────────────────────────────────────────

@ApiTags('Analysis')
@Controller('analysis')
export class DevAnalysisController {
  constructor(private readonly analysisService: AnalysisService) {}

  @ApiOperation({ summary: '[Dev] 체형 리포트 단건 재분석 (인증 없음)' })
  @Get('dev/reanalyze/body/:reportId')
  async devReanalyzeBody(@Param('reportId') reportId: string) {
    const result = await this.analysisService.reanalyzeBodyReport(reportId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '[Dev] 정밀 리포트 단건 재분석 (인증 없음)' })
  @Get('dev/reanalyze/precision/:reportId')
  async devReanalyzePrecision(@Param('reportId') reportId: string) {
    const result = await this.analysisService.reanalyzePrecisionReport(reportId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '[Dev] BALANCE_TEST 전체 재분석 (인증 없음)' })
  @Get('dev/reanalyze/all/balance')
  async devReanalyzeAllBalance() {
    const result = await this.analysisService.reanalyzeAllPrecisionReportsByType(MEASUREMENT_TYPE.BALANCE_TEST);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '[Dev] OVERHEAD_SQUAT_TEST 전체 재분석 (인증 없음)' })
  @Get('dev/reanalyze/all/overhead-squat')
  async devReanalyzeAllOverheadSquat() {
    const result = await this.analysisService.reanalyzeAllPrecisionReportsByType(MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '[Dev] 체형 리포트 전체 재분석 (인증 없음)' })
  @Get('dev/reanalyze/all/body')
  async devReanalyzeAllBody() {
    const result = await this.analysisService.reanalyzeAllBodyReports();
    return SuccessResponse(result);
  }
}
