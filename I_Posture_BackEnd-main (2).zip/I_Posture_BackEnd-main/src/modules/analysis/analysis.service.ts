import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity';
import { CreateAnalysisDto } from './dto/create-analysis.dto';
import { CreatePrecisionAnalysisDto } from './dto/create-precision-analysis.dto';
import { AnalyticService } from './analytic.service';
import { BodyReportService } from '../body-report/body-report.service';
import { BodyStrategy } from './strategies/body.strategy';
import { NeckStrategy } from './strategies/neck.strategy';
import { ShouldersStrategy } from './strategies/shoulders.strategy';
import { KneesStrategy } from './strategies/knees.strategy';
import { PelvisStrategy } from './strategies/pelvis.strategy';
import { TorsoStrategy } from './strategies/torso.strategy';
import { ElbowsStrategy } from './strategies/elbows.strategy';
import { AnkleStrategy } from './strategies/ankle.strategy';
import { SpinalAlignmentTestStrategy } from './strategies/spinal-alignment-test.strategy';
import { OverheadSquatTestStrategy } from './strategies/overhead-squat-test.strategy';
import { BalanceTestStrategy } from './strategies/balance-test.strategy';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';
import { S3Service } from '../../s3/s3.service';
import { CapacityService } from '../capacity/capacity.service';
import { FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { Landmarks, Point } from './analysis.types';
import { getHypermobilityLevel, HYPER_STAGES } from './helpers/hypermobility.helper';
import { parseAsymmetryAngleFromResult, resolvePelvisAsymmetryReportAngle } from './helpers/body-display-metrics.helper';
import { MemberNotificationService } from '../notification/member-notification.service';

// 과가동성 단계 → ROM level 값 매핑
const HYPERMOBILITY_LEVEL_MAP: Record<string, string> = {
  '경미': 'MILD',
  '주의': 'CAUTION',
  '심각': 'SERIOUS',
  '매우심각': 'VERY_SERIOUS',
};

const HYPERMOBILITY_COMMENT_MAP: Record<string, string> = {
  '경미': '해당 관절의 가동범위가 일반 기준보다 약간 초과된 단계로 분류됩니다. 일상 동작에는 큰 제약이 없으나, 관절 주변 안정화 근육 강화와 과도한 범위 사용을 줄이는 방향의 관리가 권장됩니다.',
  '주의': '해당 관절의 가동범위가 일반 기준을 초과하여 과가동성이 확인된 단계입니다. 관절 안정성 저하로 반복 동작 시 부담이 증가할 수 있으며, 안정화 운동과 함께 사용 패턴 점검이 필요합니다.',
  '심각': '해당 관절의 가동범위가 과가동성 심각 단계로 분류됩니다. 관절 손상 위험이 높아질 수 있으며, 전문적인 움직임 지도 하에 안정화 훈련을 우선적으로 진행하는 것이 권장됩니다.',
  '매우심각': '해당 관절의 가동범위가 과가동성 매우 심각 단계로 분류됩니다. 즉각적인 전문 관리와 함께, 과도한 가동 범위를 유발하는 동작 패턴을 즉시 교정해야 하는 구간입니다.',
};

const ROM_LEVEL_GUIDE = [
  { min: 0, max: 20, level: 'VERY_SERIOUS', comment: '해당 관절의 가동범위가 평가 기준상 매우 제한된 단계로 분류됩니다. 움직임 범위가 거의 사용되지 않는 패턴이 형성된 상태로, 일상적인 동작에서 움직임 조절이 어려울 수 있습니다. 센터에서의 전문적인 움직임 지도 하에, 매우 작은 범위부터 단계적으로 가동범위를 회복해 나가는 관리가 필요한 구간입니다.' },
  { min: 21, max: 50, level: 'SERIOUS', comment: '해당 관절의 가동범위가 뚜렷하게 제한된 단계로 확인됩니다. 특정 동작에서 가동범위 활용이 충분하지 않아 움직임이 축소되어 나타날 수 있습니다. 센터에서의 맞춤 운동 지도를 통해 가동범위를 점진적으로 확장하고, 사용 패턴을 재교육해야 하는 단계입니다.' },
  { min: 51, max: 70, level: 'CAUTION', comment: '해당 관절의 가동범위가 다소 제한된 단계로 분류됩니다. 일상적인 움직임은 가능하나, 습관적인 사용 패턴으로 인해 가동범위가 충분히 활용되지 않을 수 있습니다. 가동범위를 의식적으로 사용하고 확장하는 운동과 생활습관 관리가 필요한 구간입니다.' },
  { min: 71, max: 85, level: 'MILD', comment: '해당 관절의 가동범위가 비교적 안정적이지만 일부 제한이 남아 있는 단계로 확인됩니다. 일상 동작에는 큰 제약이 없으나, 가동범위의 끝 범위 활용이 부족할 수 있습니다. 잔여 제한을 개선하여 움직임의 질을 높이기 위한 가동범위 개선 운동과 사용 습관 점검이 필요한 단계입니다.' },
  { min: 86, max: Infinity, level: 'GOOD', comment: '해당 관절의 가동범위가 양호한 단계로 분류됩니다. 움직임이 자연스럽게 사용되고 있으나, 관리 없이 방치할 경우 가동범위 감소가 다시 나타날 수 있습니다. 현재의 가동범위를 유지하고 장기적으로 안정성을 높이기 위한 운동 및 생활습관 관리가 권장됩니다.' },
];

const ROM_LEVEL_LABEL_MAP: Record<string, string> = {
  VERY_SERIOUS: '매우 심각',
  SERIOUS: '심각',
  CAUTION: '주의',
  MILD: '경미',
  GOOD: '양호',
};

const ROM_STATUS_GUIDE_MAP: Record<string, string> = {
  GOOD: '비교적 안정적인 움직임이 가능하며',
  MILD: '일부 동작에서 움직임의 부담이 느껴질 수 있으며',
  CAUTION: '일부 동작에서 움직임의 부담이 느껴질 수 있으며',
  SERIOUS: '움직임 전반에서 부담이 느껴질 수 있으며',
  VERY_SERIOUS: '움직임 전반에서 부담이 느껴질 수 있으며',
};

@Injectable()
export class AnalysisService {
  private readonly logger = new Logger(AnalysisService.name);

  constructor(
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(RomStandardEntity)
    private readonly romStandardRepo: Repository<RomStandardEntity>,
    private readonly analyticService: AnalyticService,
    private readonly bodyStrategy: BodyStrategy,
    private readonly neckStrategy: NeckStrategy,
    private readonly shouldersStrategy: ShouldersStrategy,
    private readonly kneesStrategy: KneesStrategy,
    private readonly pelvisStrategy: PelvisStrategy,
    private readonly torsoStrategy: TorsoStrategy,
    private readonly elbowsStrategy: ElbowsStrategy,
    private readonly ankleStrategy: AnkleStrategy,
    private readonly spinalAlignmentTestStrategy: SpinalAlignmentTestStrategy,
    private readonly overheadSquatTestStrategy: OverheadSquatTestStrategy,
    private readonly balanceTestStrategy: BalanceTestStrategy,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    private readonly memberNotificationService: MemberNotificationService,
  ) {}

  private extractPreviewSize(landmarks: any): { width: number, height: number } | null {
    if (!landmarks) return null;
    
    for (const key in landmarks) {
      const arr = landmarks[key];
      if (Array.isArray(arr)) {
        const previewObj = arr.find(item => item && item.__previewSize === true);
        if (previewObj) {
          return { width: previewObj.width, height: previewObj.height };
        }
      }
    }
    
    if (Array.isArray(landmarks)) {
        const previewObj = landmarks.find(item => item && item.__previewSize === true);
        if (previewObj) {
            return { width: previewObj.width, height: previewObj.height };
        }
    }

    return null;
  }

  /**
   * 클라이언트가 보낸 랜드마크 입력을 { front, back, right_side } 형태로 정규화. BODY/정밀측정 공통 사용.
   */
  private processLandmarksInput(
    landmarks: any,
    explicitPreviewSize?: { width: number; height: number } | null,
  ): { processedLandmarks: Landmarks; previewSize: { width: number; height: number } | null } {
    const previewSize = explicitPreviewSize || this.extractPreviewSize(landmarks);

    const processedLandmarks: Landmarks = {
      front: {},
      back: {},
      right_side: {},
    };

    const mapLandmarks = (source: any[], target: any) => {
      if (!source || !Array.isArray(source)) return;
      source.forEach((point) => {
        if (point.type) {
          target[point.type] = {
            x: point.x,
            y: point.y,
            z: point.z,
            visibility: point.inFrameLikelihood,
          };
        }
      });
    };

    if (landmarks['step1_front'] || landmarks['step3_rear'] || landmarks['step2_right']) {
      if (landmarks['step1_front']?.landmarks) {
        mapLandmarks(landmarks['step1_front'].landmarks, processedLandmarks.front);
      }
      if (landmarks['step3_rear']?.landmarks) {
        mapLandmarks(landmarks['step3_rear'].landmarks, processedLandmarks.back);
      }
      if (landmarks['step2_right']?.landmarks) {
        mapLandmarks(landmarks['step2_right'].landmarks, processedLandmarks.right_side);
      }
    }
    else if (landmarks['front'] || landmarks['back'] || landmarks['right_side']) {
      if (Array.isArray(landmarks['front'])) {
        mapLandmarks(landmarks['front'], processedLandmarks.front);
      } else if (landmarks['front']) {
        Object.assign(processedLandmarks.front!, landmarks['front']);
      }

      if (Array.isArray(landmarks['back'])) {
        mapLandmarks(landmarks['back'], processedLandmarks.back);
      } else if (landmarks['back']) {
        Object.assign(processedLandmarks.back!, landmarks['back']);
      }

      if (Array.isArray(landmarks['right_side'])) {
        mapLandmarks(landmarks['right_side'], processedLandmarks.right_side);
      } else if (landmarks['right_side']) {
        Object.assign(processedLandmarks.right_side!, landmarks['right_side']);
      }
    }
    else {
       Object.assign(processedLandmarks, landmarks);
    }

    return { processedLandmarks, previewSize };
  }

  /**
   * 회원 셀프 체형측정 등록 - 계산 엔진(BodyStrategy)은 트레이너용과 동일하게 재사용.
   * trainerId 없이(본인 소유), 사진은 무료 무제한 정책이라 용량 체크/차감 없이 저장.
   */
  async analyzeSelf(
    member: UserEntity,
    dto: CreateAnalysisDto,
    files: { front_file?: Express.Multer.File[], side_file?: Express.Multer.File[], back_file?: Express.Multer.File[] },
  ): Promise<BodyReportEntity> {
    try {
      const { landmarks, __previewSize } = dto;
      const { processedLandmarks, previewSize } = this.processLandmarksInput(landmarks, __previewSize);

      this.analyticService.setStrategy(this.bodyStrategy);
      const { scoreDetail, disease } = await this.analyticService.execute(processedLandmarks);

      const analysisData = {
        landmarks: processedLandmarks,
        scoreDetail,
        disease,
        previewWidth: previewSize?.width,
        previewHeight: previewSize?.height,
      };
      const bodyPartScores = BodyReportService.calculateBodyPartScores(analysisData);
      const bodyReport = this.bodyReportRepo.create({
        userId: member.id,
        trainerId: undefined,
        totalScore: bodyPartScores.average,
        analysisData,
        neckScore: (() => {
          const r = scoreDetail?.neck?.neckTurtleRaised?.result;
          return r != null ? Math.max(0, parseFloat((180 - parseFloat(r)).toFixed(1))) : 0;
        })(),
        pelvisAsymmetryScore: resolvePelvisAsymmetryReportAngle(processedLandmarks),
        shoulderAsymmetryScore: parseAsymmetryAngleFromResult(scoreDetail?.shoulder?.shoulderHeightAsymmetry?.result),
      });
      const savedReport = await this.bodyReportRepo.save(bodyReport);

      const uploadSelfFile = async (file: Express.Multer.File, division: string) => {
        await this.s3Service.uploadFile(file, {
          memberId: member.id,
          uploaderId: member.id,
          ownerType: FileOwnerType.MEMBER,
          ownerId: member.id,
          relatedType: FileRelatedType.BODY,
          relatedId: savedReport.id,
          division,
        });
      };

      if (files) {
        if (files.front_file?.[0]) await uploadSelfFile(files.front_file[0], 'FRONT');
        if (files.side_file?.[0]) await uploadSelfFile(files.side_file[0], 'SIDE');
        if (files.back_file?.[0]) await uploadSelfFile(files.back_file[0], 'BACK');
      }

      return savedReport;
    } catch (error) {
      console.error(error);
      throw new BadRequestException('분석 중 오류가 발생했습니다.');
    }
  }

  async analysis(
    trainer: UserEntity,
    memberId: string,
    dto: CreateAnalysisDto,
    files: { front_file?: Express.Multer.File[], side_file?: Express.Multer.File[], back_file?: Express.Multer.File[] },
  ): Promise<BodyReportEntity | PrecisionReportEntity> {
    try {
      const { type, landmarks, measuredAt, __previewSize } = dto;
      const measurementType = type as MEASUREMENT_TYPE;

      const { processedLandmarks, previewSize } = this.processLandmarksInput(landmarks, __previewSize);

      const actionMap = new Map<MEASUREMENT_TYPE, () => void>([
        [MEASUREMENT_TYPE.BODY, () => this.analyticService.setStrategy(this.bodyStrategy)],
        [MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST, () => this.analyticService.setStrategy(this.spinalAlignmentTestStrategy)],
        [MEASUREMENT_TYPE.ANKLE, () => this.analyticService.setStrategy(this.ankleStrategy)],
        [MEASUREMENT_TYPE.KNEE, () => this.analyticService.setStrategy(this.kneesStrategy)],
        [MEASUREMENT_TYPE.ELBOW, () => this.analyticService.setStrategy(this.elbowsStrategy)],
        [MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST, () => this.analyticService.setStrategy(this.overheadSquatTestStrategy)],
        [MEASUREMENT_TYPE.NECK, () => this.analyticService.setStrategy(this.neckStrategy)],
        [MEASUREMENT_TYPE.HIP, () => this.analyticService.setStrategy(this.pelvisStrategy)],
        [MEASUREMENT_TYPE.SHOULDER, () => this.analyticService.setStrategy(this.shouldersStrategy)],
        [MEASUREMENT_TYPE.TORSO, () => this.analyticService.setStrategy(this.torsoStrategy)],
        [MEASUREMENT_TYPE.BALANCE_TEST, () => this.analyticService.setStrategy(this.balanceTestStrategy)],
      ]);

      const action = actionMap.get(measurementType);
      if (!action) {
        throw new BadRequestException('지원하지 않는 분석 유형입니다.');
      }
      action();

      const { score, scoreDetail, disease } = await this.analyticService.execute(processedLandmarks);

      if (measurementType === MEASUREMENT_TYPE.BODY) {
        const analysisData = {
          landmarks: processedLandmarks,
          scoreDetail,
          disease,
          previewWidth: previewSize?.width,
          previewHeight: previewSize?.height,
        };
        const bodyPartScores = BodyReportService.calculateBodyPartScores(analysisData);
        const bodyReport = this.bodyReportRepo.create({
          userId: memberId,
          trainerId: trainer.id,
          totalScore: bodyPartScores.average,
          analysisData,
          // 대시보드용 점수 컬럼 추가
          neckScore: (() => {
            const r = scoreDetail?.neck?.neckTurtleRaised?.result;
            return r != null ? Math.max(0, parseFloat((180 - parseFloat(r)).toFixed(1))) : 0;
          })(),
          pelvisAsymmetryScore: resolvePelvisAsymmetryReportAngle(processedLandmarks),
          shoulderAsymmetryScore: parseAsymmetryAngleFromResult(scoreDetail?.shoulder?.shoulderHeightAsymmetry?.result),
        });
        const savedReport = await this.bodyReportRepo.save(bodyReport);

        const uploadAndSave = async (file: Express.Multer.File, relatedType: FileRelatedType, division: string) => {
          const uploadedFile = await this.s3Service.uploadFile(file, {
            memberId,
            uploaderId: trainer.id,
            ownerType: FileOwnerType.TRAINER,
            ownerId: trainer.id,
            relatedType: relatedType,
            relatedId: savedReport.id,
            division: division,
          });
          await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
        };

        if (files) {
          if (files.front_file && files.front_file[0]) await uploadAndSave(files.front_file[0], FileRelatedType.BODY, 'FRONT');
          if (files.side_file && files.side_file[0]) await uploadAndSave(files.side_file[0], FileRelatedType.BODY, 'SIDE');
          if (files.back_file && files.back_file[0]) await uploadAndSave(files.back_file[0], FileRelatedType.BODY, 'BACK');
        }

        this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, 'BODY');
        return savedReport;
      } else {
        const precisionReport = this.precisionReportRepo.create({
          userId: memberId,
          trainerId: trainer.id,
          type: measurementType,
          analysisData: { 
            landmarks: processedLandmarks, 
            scoreDetail,
            disease,
            previewWidth: previewSize?.width,
            previewHeight: previewSize?.height,
          },
        });
        const savedReport = await this.precisionReportRepo.save(precisionReport);

        const uploadAndSave = async (file: Express.Multer.File, relatedType: FileRelatedType, division: string) => {
          const uploadedFile = await this.s3Service.uploadFile(file, {
            memberId,
            uploaderId: trainer.id,
            ownerType: FileOwnerType.TRAINER,
            ownerId: trainer.id,
            relatedType: relatedType,
            relatedId: savedReport.id,
            division: division,
          });
          await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
        };

        if (files) {
          if (files.front_file && files.front_file[0]) await uploadAndSave(files.front_file[0], FileRelatedType.PRECISION, 'FRONT');
          if (files.side_file && files.side_file[0]) await uploadAndSave(files.side_file[0], FileRelatedType.PRECISION, 'SIDE');
          if (files.back_file && files.back_file[0]) await uploadAndSave(files.back_file[0], FileRelatedType.PRECISION, 'BACK');
        }

        this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, measurementType);
        return savedReport;
      }
    } catch (error) {
      console.error(error);
      throw new BadRequestException('분석 중 오류가 발생했습니다.');
    }
  }

  private readonly LANDMARK_TYPE_ALIASES: Record<string, string> = {
    LeftFootIndex: 'LeftToe',
    RightFootIndex: 'RightToe',
  };

  private mapLandmarksFromArray(landmarks: any): Landmarks {
    const processed: Landmarks = {};
    if (!landmarks || typeof landmarks !== 'object') return processed;
    for (const key of Object.keys(landmarks)) {
      const val = landmarks[key];
      if (Array.isArray(val)) {
        processed[key] = {};
        val.forEach((point: any) => {
          if (point.type) {
            const mapped = {
              x: point.x,
              y: point.y,
              z: point.z,
              visibility: point.inFrameLikelihood,
            };
            processed[key][point.type] = mapped;
            const alias = this.LANDMARK_TYPE_ALIASES[point.type];
            if (alias) {
              processed[key][alias] = mapped;
            }
          }
        });
      } else {
        processed[key] = val;
      }
    }
    return processed;
  }

  async createSpinalAlignmentAnalysis(
    trainer: UserEntity,
    memberId: string,
    dto: CreateAnalysisDto,
    files: { back_file?: Express.Multer.File[]; back_bend_file?: Express.Multer.File[] },
  ): Promise<PrecisionReportEntity> {
    try {
      const { landmarks, measuredAt, __previewSize } = dto;
      const previewSize = __previewSize || this.extractPreviewSize(landmarks);

      const processedLandmarks: Landmarks = this.mapLandmarksFromArray(landmarks);

      this.analyticService.setStrategy(this.spinalAlignmentTestStrategy);
      const { score, scoreDetail, disease } = await this.analyticService.execute(processedLandmarks);

      const level = this.resolveSpinalAlignmentLevel(disease.length);

      const precisionReport = this.precisionReportRepo.create({
        userId: memberId,
        trainerId: trainer.id,
        type: MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST,
        name: '척추 정렬 검사',
        score,
        level,
        analysisData: {
          landmarks: processedLandmarks,
          scoreDetail,
          disease,
          previewWidth: previewSize?.width,
          previewHeight: previewSize?.height,
        },
      });
      const savedReport = await this.precisionReportRepo.save(precisionReport);

      const uploadAndSave = async (file: Express.Multer.File, division: string) => {
        const uploadedFile = await this.s3Service.uploadFile(file, {
          memberId,
          uploaderId: trainer.id,
          ownerType: FileOwnerType.TRAINER,
          ownerId: trainer.id,
          relatedType: FileRelatedType.PRECISION,
          relatedId: savedReport.id,
          division,
        });
        await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      };

      if (files) {
        if (files.back_file && files.back_file[0]) await uploadAndSave(files.back_file[0], 'BACK');
        if (files.back_bend_file && files.back_bend_file[0]) await uploadAndSave(files.back_bend_file[0], 'BACK_BEND');
      }

      this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST);
      return savedReport;
    } catch (error) {
      console.error(error);
      throw new BadRequestException('분석 중 오류가 발생했습니다.');
    }
  }

  /** 척추 정렬 검사: 이상 항목 수에 따라 레벨 결정 */
  private resolveSpinalAlignmentLevel(diseaseCount: number): string {
    return this.resolvePrecisionTestLevel(diseaseCount);
  }

  /** 정밀 검사 공통: 이상 항목 수에 따라 레벨 결정 */
  private resolvePrecisionTestLevel(diseaseCount: number): string {
    if (diseaseCount === 0) return 'NORMAL';
    if (diseaseCount <= 2) return 'CAUTION';
    return 'DANGER';
  }

  async createBalanceTestAnalysis(
    trainer: UserEntity,
    memberId: string,
    dto: CreateAnalysisDto,
    files: {
      front_left_file?: Express.Multer.File[];
      front_right_file?: Express.Multer.File[];
      left_file?: Express.Multer.File[];
      right_file?: Express.Multer.File[];
    },
  ): Promise<PrecisionReportEntity> {
    try {
      const { landmarks, measuredAt, __previewSize } = dto;
      const previewSize = __previewSize || this.extractPreviewSize(landmarks);

      const processedLandmarks: Landmarks = this.mapLandmarksFromArray(landmarks);

      this.analyticService.setStrategy(this.balanceTestStrategy);
      const { score, scoreDetail, disease } = await this.analyticService.execute(processedLandmarks);

      const BALANCE_TEST_MAX_SCORE = 10;
      // score는 감점 합계(음수)이므로 만점에서 차감한 실제 점수를 계산
      const actualScore = Math.max(0, BALANCE_TEST_MAX_SCORE + score);
      const rawNormalizedScore = Math.round((actualScore / BALANCE_TEST_MAX_SCORE) * 100);
      // ⚠️ Gating: sideLeg(다리 들기) 실패 시 '불안정' 상한(50)으로 강제 캡
      // sideLeg가 NORMAL이 아니면 다리를 들지 않은 것으로 간주
      const sideLegPassed = scoreDetail?.sideLeg?.disease === 'NORMAL';
      const normalizedScore = sideLegPassed ? rawNormalizedScore : Math.min(rawNormalizedScore, 50);
      const balanceLevel = this.resolvePrecisionTestLevel(disease.length);

      const precisionReport = this.precisionReportRepo.create({
        userId: memberId,
        trainerId: trainer.id,
        type: MEASUREMENT_TYPE.BALANCE_TEST,
        name: '균형 검사',
        score: normalizedScore,
        level: balanceLevel,
        analysisData: {
          landmarks: processedLandmarks,
          scoreDetail,
          disease,
          previewWidth: previewSize?.width,
          previewHeight: previewSize?.height,
        },
      });
      const savedReport = await this.precisionReportRepo.save(precisionReport);

      const uploadAndSave = async (file: Express.Multer.File, division: string) => {
        const uploadedFile = await this.s3Service.uploadFile(file, {
          memberId,
          uploaderId: trainer.id,
          ownerType: FileOwnerType.TRAINER,
          ownerId: trainer.id,
          relatedType: FileRelatedType.PRECISION,
          relatedId: savedReport.id,
          division,
        });
        await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      };

      if (files) {
        if (files.front_left_file?.[0]) await uploadAndSave(files.front_left_file[0], 'FRONT_LEFT');
        if (files.front_right_file?.[0]) await uploadAndSave(files.front_right_file[0], 'FRONT_RIGHT');
        if (files.left_file?.[0]) await uploadAndSave(files.left_file[0], 'LEFT');
        if (files.right_file?.[0]) await uploadAndSave(files.right_file[0], 'RIGHT');
      }

      this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, MEASUREMENT_TYPE.BALANCE_TEST);
      return savedReport;
    } catch (error) {
      console.error(error);
      throw new BadRequestException('분석 중 오류가 발생했습니다.');
    }
  }

  async createOverheadSquatAnalysis(
    trainer: UserEntity,
    memberId: string,
    dto: CreateAnalysisDto,
    files: {
      start_front_file?: Express.Multer.File[];
      start_back_file?: Express.Multer.File[];
      start_left_file?: Express.Multer.File[];
      start_right_file?: Express.Multer.File[];
      end_front_file?: Express.Multer.File[];
      end_back_file?: Express.Multer.File[];
      end_left_file?: Express.Multer.File[];
      end_right_file?: Express.Multer.File[];
    },
  ): Promise<PrecisionReportEntity> {
    try {
      const { landmarks, measuredAt, __previewSize } = dto;
      const previewSize = __previewSize || this.extractPreviewSize(landmarks);

      const processedLandmarks: Landmarks = this.mapLandmarksFromArray(landmarks);

      this.analyticService.setStrategy(this.overheadSquatTestStrategy);
      const { score: _ohtScore, scoreDetail, disease } = await this.analyticService.execute(processedLandmarks);

      const ohtLevel = this.resolvePrecisionTestLevel(disease.length);

      const precisionReport = this.precisionReportRepo.create({
        userId: memberId,
        trainerId: trainer.id,
        type: MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST,
        name: '전신 기능 검사',
        score: 0,
        level: ohtLevel,
        analysisData: {
          landmarks: processedLandmarks,
          scoreDetail,
          disease,
          previewWidth: previewSize?.width,
          previewHeight: previewSize?.height,
        },
      });
      const savedReport = await this.precisionReportRepo.save(precisionReport);

      const uploadAndSave = async (file: Express.Multer.File, division: string) => {
        const uploadedFile = await this.s3Service.uploadFile(file, {
          memberId,
          uploaderId: trainer.id,
          ownerType: FileOwnerType.TRAINER,
          ownerId: trainer.id,
          relatedType: FileRelatedType.PRECISION,
          relatedId: savedReport.id,
          division,
        });
        await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      };

      if (files) {
        if (files.start_front_file?.[0]) await uploadAndSave(files.start_front_file[0], 'START_FRONT');
        if (files.start_back_file?.[0]) await uploadAndSave(files.start_back_file[0], 'START_BACK');
        if (files.start_left_file?.[0]) await uploadAndSave(files.start_left_file[0], 'START_LEFT');
        if (files.start_right_file?.[0]) await uploadAndSave(files.start_right_file[0], 'START_RIGHT');
        if (files.end_front_file?.[0]) await uploadAndSave(files.end_front_file[0], 'END_FRONT');
        if (files.end_back_file?.[0]) await uploadAndSave(files.end_back_file[0], 'END_BACK');
        if (files.end_left_file?.[0]) await uploadAndSave(files.end_left_file[0], 'END_LEFT');
        if (files.end_right_file?.[0]) await uploadAndSave(files.end_right_file[0], 'END_RIGHT');
      }

      this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST);
      return savedReport;
    } catch (error) {
      console.error(error);
      throw new BadRequestException('분석 중 오류가 발생했습니다.');
    }
  }

  async createPrecisionAnalysis(
    trainer: UserEntity,
    memberId: string,
    dto: CreatePrecisionAnalysisDto,
    files: Array<Express.Multer.File>,
  ): Promise<PrecisionReportEntity> {
    const { type, key, landmarks, measuredAt } = dto;
    
    const previewSize = this.extractPreviewSize(landmarks);
    
    const analysisData: any = {
        previewWidth: previewSize?.width,
        previewHeight: previewSize?.height,
    };
    const landmarksForStrategy: any = {};

    let stepKeys: string[] = [];
    if (landmarks && !Array.isArray(landmarks)) {
      stepKeys = Object.keys(landmarks)
        .filter(k => k.startsWith('step'))
        .sort((a, b) => {
          const numA = parseInt(a.replace('step', ''), 10);
          const numB = parseInt(b.replace('step', ''), 10);
          return numA - numB;
        });
    }

    if (stepKeys.length < 1) {
      throw new BadRequestException('No step data found in landmarks');
    }

    const mapLandmarks = (source: any[]) => {
      const target: any = {};
      if (!source || !Array.isArray(source)) return target;
      source.forEach((point) => {
        if (point.type) {
          target[point.type] = {
            x: point.x,
            y: point.y,
            z: point.z,
            visibility: point.inFrameLikelihood,
          };
        }
      });
      return target;
    };

    const startStepKey = stepKeys[0];
    const endStepKey = stepKeys[stepKeys.length - 1];
    
    const startLandmarks = mapLandmarks(landmarks![startStepKey]);
    const endLandmarks = mapLandmarks(landmarks![endStepKey]);

    // Strategy 매핑
    this.applyKeyToLandmarksStrategy(key, startLandmarks, endLandmarks, landmarksForStrategy);

    analysisData[key] = {
      steps: stepKeys.map(k => ({
        step: k,
        landmarks: mapLandmarks(landmarks![k])
      })),
    };

    let strategy: any;
    if (type === 'NECK') strategy = this.neckStrategy;
    else if (type === 'SHOULDER') strategy = this.shouldersStrategy;
    else if (type === 'TORSO') strategy = this.torsoStrategy;
    else if (type === 'ELBOW') strategy = this.elbowsStrategy;
    else if (type === 'KNEE') strategy = this.kneesStrategy;
    else if (type === 'ANKLE') strategy = this.ankleStrategy;
    else if (type === 'HIP') strategy = this.pelvisStrategy;
    else if (type === 'SPINAL_ALIGNMENT_TEST') strategy = this.spinalAlignmentTestStrategy;
    else if (type === 'OVERHEAD_SQUAT_TEST') strategy = this.overheadSquatTestStrategy;
    else if (type === 'BALANCE_TEST') strategy = this.balanceTestStrategy;

    let result: any = {};
    if (strategy) {
      const analyticResult = await strategy.execute(landmarksForStrategy);
      result = analyticResult.scoreDetail;
    }

    let score = 0;
    let level = '';
    let name = key;
    let comment = '';
    let romDiff = 0;

    let measuredAngle = 0;
    let targetResult: any = null;
    const resultValues = Object.values(result) as any[];
    
    this.logger.log(`Key: ${key}, Result: ${JSON.stringify(result)}`);

    if (resultValues.length > 0) {
      if (key === 'NeckLeftLateralFlexion') targetResult = result.sideBendLeft;
      else if (key === 'NeckRightLateralFlexion') targetResult = result.sideBendRight;
      else if (key === 'NeckFlexion') targetResult = result.bendingForward;
      else if (key === 'NeckExtension') targetResult = result.bendingBackward;
      else if (key === 'NeckLeftRotation') targetResult = result.rotationLeft;
      else if (key === 'NeckRightRotation') targetResult = result.rotationRight;
      else if (key.includes('Shoulder') && key.includes('Abduction')) targetResult = key.includes('Left') ? result.jointMovingLeft : result.jointMovingRight;
      else if (key.includes('Shoulder') && key.includes('Adduction')) targetResult = key.includes('Left') ? result.jointAdductionLeft : result.jointAdductionRight;
      else if (key.includes('Shoulder') && key.includes('Flexion')) targetResult = key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
      else if (key.includes('Shoulder') && key.includes('Extension')) targetResult = key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
      else if (key.includes('Shoulder') && key.includes('InternalRotation')) targetResult = key.includes('Left') ? result.jointTurningInLeft : result.jointTurningInRight;
      else if (key.includes('Shoulder') && key.includes('ExternalRotation')) targetResult = key.includes('Left') ? result.jointTurningOutLeft : result.jointTurningOutRight;
      else if (key.includes('Elbow') && key.includes('Flexion')) targetResult = key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
      else if (key.includes('Elbow') && key.includes('Extension')) targetResult = key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
      else if (key.includes('Trunk') && key.includes('LateralFlexion')) targetResult = key.includes('Left') ? result.sideBendingLeft : result.sideBendingRight;
      else if (key.includes('Trunk') && key.includes('Rotation')) targetResult = key.includes('Left') ? result.rotationLeft : result.rotationRight;
      else if (key === 'TrunkFlexion') targetResult = result.bending;
      else if (key === 'TrunkExtension') targetResult = result.straightening;
      else if (key.includes('Hip') && key.includes('Adduction')) targetResult = key.includes('Left') ? result.jointMovingInwardLeft : result.jointMovingInwardRight;
      else if (key.includes('Hip') && key.includes('Abduction')) targetResult = key.includes('Left') ? result.jointMovingLeft : result.jointMovingRight;
      else if (key.includes('Hip') && key.includes('Flexion')) targetResult = key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
      else if (key.includes('Hip') && key.includes('Extension')) targetResult = key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
      else if (key.includes('Hip') && key.includes('InternalRotation')) targetResult = key.includes('Left') ? result.jointTurningInwardLeft : result.jointTurningInwardRight;
      else if (key.includes('Hip') && key.includes('ExternalRotation')) targetResult = key.includes('Left') ? result.jointTurningOutwardLeft : result.jointTurningOutwardRight;
      else if (key.includes('Knee') && key.includes('Flexion')) targetResult = key.includes('Left') ? result.bendingLeft : result.bendingRight;
      else if (key.includes('Knee') && key.includes('Extension')) targetResult = key.includes('Left') ? result.extendingLeft : result.extendingRight;
      else if (key.includes('Ankle') && key.includes('Dorsiflexion')) targetResult = key.includes('Left') ? result.bendingLeft : result.bendingRight;
      else if (key.includes('Ankle') && key.includes('Plantarflexion')) targetResult = key.includes('Left') ? result.extentionLeft : result.extentionRight;
      else if (key.includes('Ankle') && key.includes('Inversion')) targetResult = key.includes('Left') ? result.inwardCollapseLeft : result.inwardCollapseRight;
      else if (key.includes('Ankle') && key.includes('Eversion')) targetResult = key.includes('Left') ? result.outwardCollapseLeft : result.outwardCollapseRight;

      if (!targetResult) {
         targetResult = resultValues.find(r => r && r.result);
      }

      if (targetResult != null && targetResult.result != null && targetResult.result !== '') {
        let angleStr = targetResult.result;
        try {
            const jsonResult = JSON.parse(angleStr);
            if (jsonResult.angle) angleStr = jsonResult.angle;
            else if (jsonResult.distance) angleStr = jsonResult.distance;
        } catch (e) {}

        const match = String(angleStr).match(/-?[\d.]+/);
        if (match) {
          const parsed = parseFloat(match[0]);
          // 음수값 = 측정 방향 반대(자세 미수행) → 0으로 처리해야 하는 항목들
          // 방향 보정(angle = condition ? angle : -angle)을 사용하는 모든 항목은
          // 정상 수행 시 절대 음수가 나올 수 없으므로 필요 시 아래 목록에 추가:
          // NeckExtension, NeckLeftLateralFlexion, NeckRightLateralFlexion,
          // NeckLeftRotation, NeckRightRotation,
          // Shoulder 전종목, Elbow 전종목, Trunk 전종목,
          // Hip 전종목, Knee 전종목, Ankle(Inversion/Eversion/Plantarflexion) 전종목
          const clampToZeroKeys = [
            'NeckFlexion',
            'NeckExtension',
          ];
          measuredAngle = clampToZeroKeys.includes(key) ? Math.max(0, parsed) : parsed;
        }
      }
    }
    
    this.logger.log(`Measured Angle: ${measuredAngle}`);

    const allStandards = await this.romStandardRepo.find();
    const standard = allStandards.find(s => s.reportNameEn.replace(/\s/g, '') === key);

    if (standard) {
      name = standard.reportNameKo;
      const normal = standard.normalDeg;
      score = Math.min(Math.round((measuredAngle / normal) * 100), 100);
      romDiff = measuredAngle - normal;
      
      const guide = ROM_LEVEL_GUIDE.find(g => score >= g.min && score <= g.max);
      if (guide) {
        level = guide.level;
        const levelLabel = ROM_LEVEL_LABEL_MAP[guide.level] ?? '확인 필요';
        const statusGuide = ROM_STATUS_GUIDE_MAP[guide.level] ?? '일상적인 움직임에서 불편으로';
        const levelColorMap: Record<string, string> = {
          VERY_SERIOUS: 'red', SERIOUS: 'orange', CAUTION: 'yellow', MILD: 'green', GOOD: 'blue',
        };
        const levelColor = levelColorMap[guide.level] ?? 'blue';

        // 과가동성(hypermobility)이 감지된 경우 level/comment를 별도 문구로 교체
        const detectedHypermobility = targetResult?.hypermobilityLevel as string | undefined;
        if (detectedHypermobility && HYPERMOBILITY_COMMENT_MAP[detectedHypermobility]) {
          level = HYPERMOBILITY_LEVEL_MAP[detectedHypermobility] ?? guide.level;
          comment = HYPERMOBILITY_COMMENT_MAP[detectedHypermobility];
        } else {
          // 상세 페이지용 (짧은 코멘트)
          comment = `${guide.comment}`;
        }
      }
      
      this.logger.log(`Calculated Score: ${score}, Level: ${level}, Diff: ${romDiff}`);
    } else {
        this.logger.warn(`No standard found for key: ${key}`);
    }

    analysisData.romInfo = {
        measuredAngle,
        normalAngle: standard?.normalDeg || 0,
        romDiff,
    };

    const report = this.precisionReportRepo.create({
      userId: memberId,
      trainerId: trainer.id,
      type: type as MEASUREMENT_TYPE,
      key,
      name,
      score,
      level,
      analysisData: { ...analysisData, result },
      comment,
    });
    const savedReport = await this.precisionReportRepo.save(report);

    if (files) {
      for (const stepKey of stepKeys) {
        const fileKey = `${stepKey}_file`;
        const file = files.find(f => f.fieldname === fileKey);
        
        if (file) {
          const division = `${key}_${stepKey}`;

          const uploadedFile = await this.s3Service.uploadFile(file, {
            memberId,
            uploaderId: trainer.id,
            ownerType: FileOwnerType.TRAINER,
            ownerId: trainer.id,
            relatedType: FileRelatedType.PRECISION,
            relatedId: savedReport.id,
            division: division,
          });
          await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
        }
      }
    }

    this.memberNotificationService.notifyTrainerReport(memberId, savedReport.id, type as MEASUREMENT_TYPE);
    return savedReport;
  }

  /**
   * 기존 리포트의 landmarks를 그대로 사용해 scoreDetail/disease/score/level만 재계산 후 업데이트.
   * 어드민 전용 API에서 호출. 파일은 그대로 유지.
   */
  async reanalyzeBodyReport(reportId: string): Promise<{ updated: number }> {
    const report = await this.bodyReportRepo.findOne({ where: { id: reportId } });
    if (!report) throw new BadRequestException(`BodyReport not found: ${reportId}`);

    const landmarks: Landmarks = report.analysisData?.landmarks ?? {};
    this.analyticService.setStrategy(this.bodyStrategy);
    const { scoreDetail, disease } = await this.analyticService.execute(landmarks);

    const analysisData = {
      ...report.analysisData,
      scoreDetail,
      disease,
    };
    const bodyPartScores = BodyReportService.calculateBodyPartScores(analysisData);
    await this.bodyReportRepo.update(reportId, {
      totalScore: bodyPartScores.average,
      analysisData,
      neckScore: (() => {
        const r = scoreDetail?.neck?.neckTurtleRaised?.result;
        return r != null ? Math.max(0, parseFloat((180 - parseFloat(r)).toFixed(1))) : 0;
      })(),
      pelvisAsymmetryScore: resolvePelvisAsymmetryReportAngle(landmarks),
      shoulderAsymmetryScore: parseAsymmetryAngleFromResult(scoreDetail?.shoulder?.shoulderHeightAsymmetry?.result),
    });
    return { updated: 1 };
  }

  /** key → landmarksForStrategy 매핑 (createPrecisionAnalysis & reanalyzePrecisionReport 공용) */
  private applyKeyToLandmarksStrategy(
    key: string,
    startLandmarks: any,
    endLandmarks: any,
    out: any,
  ): void {
    if (key === 'NeckLeftLateralFlexion') {
      out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks;
    } else if (key === 'NeckRightLateralFlexion') {
      out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks;
    } else if (key === 'NeckFlexion') {
      out['start_forward_right'] = startLandmarks; out['end_forward_right'] = endLandmarks;
    } else if (key === 'NeckExtension') {
      out['start_backward_left'] = startLandmarks; out['end_backward_left'] = endLandmarks;
    } else if (key === 'NeckLeftRotation') {
      out['start_rotation_left'] = startLandmarks; out['end_rotation_left'] = endLandmarks;
    } else if (key === 'NeckRightRotation') {
      out['start_rotation_right'] = startLandmarks; out['end_rotation_right'] = endLandmarks;
    } else if (key.includes('Shoulder') && key.includes('Abduction')) {
      if (key.includes('Left')) { out['start_left_arm_up'] = startLandmarks; out['end_left_arm_up'] = endLandmarks; }
      else { out['start_right_arm_up'] = startLandmarks; out['end_right_arm_up'] = endLandmarks; }
    } else if (key.includes('Shoulder') && key.includes('Flexion')) {
      if (key.includes('Left')) { out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks; }
      else { out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks; }
    } else if (key.includes('Shoulder') && key.includes('Extension')) {
      if (key.includes('Left')) { out['start_straighten_left'] = startLandmarks; out['end_straighten_left'] = endLandmarks; }
      else { out['start_straighten_right'] = startLandmarks; out['end_straighten_right'] = endLandmarks; }
    } else if (key.includes('Shoulder') && key.includes('InternalRotation')) {
      if (key.includes('Left')) { out['start_turn_in_left'] = startLandmarks; out['end_turn_in_left'] = endLandmarks; }
      else { out['start_turn_in_right'] = startLandmarks; out['end_turn_in_right'] = endLandmarks; }
    } else if (key.includes('Shoulder') && key.includes('ExternalRotation')) {
      if (key.includes('Left')) { out['start_turn_out_left'] = startLandmarks; out['end_turn_out_left'] = endLandmarks; }
      else { out['start_turn_out_right'] = startLandmarks; out['end_turn_out_right'] = endLandmarks; }
    } else if (key.includes('Shoulder') && key.includes('Adduction')) {
      if (key.includes('Left')) { out['start_adduction_left'] = startLandmarks; out['end_adduction_left'] = endLandmarks; }
      else { out['start_adduction_right'] = startLandmarks; out['end_adduction_right'] = endLandmarks; }
    } else if (key.includes('Elbow') && key.includes('Flexion')) {
      if (key.includes('Left')) { out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks; }
      else { out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks; }
    } else if (key.includes('Elbow') && key.includes('Extension')) {
      if (key.includes('Left')) { out['start_straighten_left'] = startLandmarks; out['end_straighten_left'] = endLandmarks; }
      else { out['start_straighten_right'] = startLandmarks; out['end_straighten_right'] = endLandmarks; }
    } else if (key.includes('Trunk') && key.includes('LateralFlexion')) {
      if (key.includes('Left')) { out['start_side_bend_left'] = startLandmarks; out['end_side_bend_left'] = endLandmarks; }
      else { out['start_side_bend_right'] = startLandmarks; out['end_side_bend_right'] = endLandmarks; }
    } else if (key.includes('Trunk') && key.includes('Rotation')) {
      if (key.includes('Left')) { out['start_rotation_left'] = startLandmarks; out['end_rotation_left'] = endLandmarks; }
      else { out['start_rotation_right'] = startLandmarks; out['end_rotation_right'] = endLandmarks; }
    } else if (key === 'TrunkFlexion') {
      out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks;
    } else if (key === 'TrunkExtension') {
      out['start_straighten_left'] = startLandmarks; out['end_straighten_left'] = endLandmarks;
    } else if (key.includes('Hip') && key.includes('Adduction')) {
      if (key.includes('Left')) { out['start_inward_left'] = startLandmarks; out['end_inward_left'] = endLandmarks; }
      else { out['start_inward_right'] = startLandmarks; out['end_inward_right'] = endLandmarks; }
    } else if (key.includes('Hip') && key.includes('Abduction')) {
      if (key.includes('Left')) { out['start_move_left'] = startLandmarks; out['end_move_left'] = endLandmarks; }
      else { out['start_move_right'] = startLandmarks; out['end_move_right'] = endLandmarks; }
    } else if (key.includes('Hip') && key.includes('Flexion')) {
      if (key.includes('Left')) { out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks; }
      else { out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks; }
    } else if (key.includes('Hip') && key.includes('Extension')) {
      if (key.includes('Left')) { out['start_straighten_left'] = startLandmarks; out['end_straighten_left'] = endLandmarks; }
      else { out['start_straighten_right'] = startLandmarks; out['end_straighten_right'] = endLandmarks; }
    } else if (key.includes('Hip') && key.includes('InternalRotation')) {
      if (key.includes('Left')) { out['start_turn_in_left'] = startLandmarks; out['end_turn_in_left'] = endLandmarks; }
      else { out['start_turn_in_right'] = startLandmarks; out['end_turn_in_right'] = endLandmarks; }
    } else if (key.includes('Hip') && key.includes('ExternalRotation')) {
      if (key.includes('Left')) { out['start_turn_out_left'] = startLandmarks; out['end_turn_out_left'] = endLandmarks; }
      else { out['start_turn_out_right'] = startLandmarks; out['end_turn_out_right'] = endLandmarks; }
    } else if (key.includes('Knee') && key.includes('Flexion')) {
      if (key.includes('Left')) { out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks; }
      else { out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks; }
    } else if (key.includes('Knee') && key.includes('Extension')) {
      if (key.includes('Left')) { out['start_straighten_left'] = startLandmarks; out['end_straighten_left'] = endLandmarks; }
      else { out['start_straighten_right'] = startLandmarks; out['end_straighten_right'] = endLandmarks; }
    } else if (key.includes('Ankle') && key.includes('Dorsiflexion')) {
      if (key.includes('Left')) { out['start_bend_left'] = startLandmarks; out['end_bend_left'] = endLandmarks; }
      else { out['start_bend_right'] = startLandmarks; out['end_bend_right'] = endLandmarks; }
    } else if (key.includes('Ankle') && key.includes('Plantarflexion')) {
      if (key.includes('Left')) { out['start_extension_left'] = startLandmarks; out['end_extension_left'] = endLandmarks; }
      else { out['start_extension_right'] = startLandmarks; out['end_extension_right'] = endLandmarks; }
    } else if (key.includes('Ankle') && key.includes('Inversion')) {
      if (key.includes('Left')) { out['start_inward_left'] = startLandmarks; out['end_inward_left'] = endLandmarks; }
      else { out['start_inward_right'] = startLandmarks; out['end_inward_right'] = endLandmarks; }
    } else if (key.includes('Ankle') && key.includes('Eversion')) {
      if (key.includes('Left')) { out['start_outward_left'] = startLandmarks; out['end_outward_left'] = endLandmarks; }
      else { out['start_outward_right'] = startLandmarks; out['end_outward_right'] = endLandmarks; }
    }
  }

  /** key → 과가동성 기준 스테이지 매핑 (ROM 재분석용) */
  private resolveHyperStages(key: string): [number, string][] | null {
    const k = key;
    // 캡 처리 항목: 최댓값이 정상 범위 상한으로 고정되므로 과가동성 없음
    if (k.includes('Neck') && (k.includes('LateralFlexion') || k.includes('Rotation'))) return null;
    if (k.includes('Trunk') && (k.includes('Rotation') || k.includes('Extension'))) return null;
    if (k.includes('Neck')) return [...HYPER_STAGES.NECK];
    if (k.includes('Shoulder') && (k.includes('Abduction') || k.includes('Flexion'))) return [...HYPER_STAGES.SHOULDER_LARGE];
    if (k.includes('Shoulder')) return [...HYPER_STAGES.SHOULDER_SMALL];
    if (k.includes('Elbow')) return [...HYPER_STAGES.ELBOW];
    if (k.includes('Trunk') && k.includes('LateralFlexion')) return [...HYPER_STAGES.TORSO_LATERAL];
    if (k.includes('Trunk')) return [...HYPER_STAGES.TORSO_FLEX];
    if (k.includes('Hip') && (k.includes('Abduction') || k.includes('ExternalRotation'))) return [...HYPER_STAGES.HIP_LARGE];
    if (k.includes('Hip') && k.includes('Adduction')) return [...HYPER_STAGES.HIP_ADD];
    if (k.includes('Hip') && k.includes('InternalRotation')) return [...HYPER_STAGES.HIP_SMALL];
    if (k.includes('Hip')) return [...HYPER_STAGES.HIP_FLEX_EXT];
    if (k.includes('Knee') && k.includes('Extension')) return [...HYPER_STAGES.KNEE_EXT];
    if (k.includes('Knee')) return [...HYPER_STAGES.KNEE_FLEX];
    return null;
  }

  /** key → result 필드 매핑 (ROM 재분석용) */
  private resolveTargetResult(key: string | undefined, result: any): any {
    if (!key || !result) return null;
    if (key === 'NeckLeftLateralFlexion') return result.sideBendLeft;
    if (key === 'NeckRightLateralFlexion') return result.sideBendRight;
    if (key === 'NeckFlexion') return result.bendingForward;
    if (key === 'NeckExtension') return result.bendingBackward;
    if (key === 'NeckLeftRotation') return result.rotationLeft;
    if (key === 'NeckRightRotation') return result.rotationRight;
    if (key.includes('Shoulder') && key.includes('Abduction')) return key.includes('Left') ? result.jointMovingLeft : result.jointMovingRight;
    if (key.includes('Shoulder') && key.includes('Adduction')) return key.includes('Left') ? result.jointAdductionLeft : result.jointAdductionRight;
    if (key.includes('Shoulder') && key.includes('Flexion')) return key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
    if (key.includes('Shoulder') && key.includes('Extension')) return key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
    if (key.includes('Shoulder') && key.includes('InternalRotation')) return key.includes('Left') ? result.jointTurningInLeft : result.jointTurningInRight;
    if (key.includes('Shoulder') && key.includes('ExternalRotation')) return key.includes('Left') ? result.jointTurningOutLeft : result.jointTurningOutRight;
    if (key.includes('Elbow') && key.includes('Flexion')) return key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
    if (key.includes('Elbow') && key.includes('Extension')) return key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
    if (key.includes('Trunk') && key.includes('LateralFlexion')) return key.includes('Left') ? result.sideBendingLeft : result.sideBendingRight;
    if (key.includes('Trunk') && key.includes('Rotation')) return key.includes('Left') ? result.rotationLeft : result.rotationRight;
    if (key === 'TrunkFlexion') return result.bending;
    if (key === 'TrunkExtension') return result.straightening;
    if (key.includes('Hip') && key.includes('Adduction')) return key.includes('Left') ? result.jointMovingInwardLeft : result.jointMovingInwardRight;
    if (key.includes('Hip') && key.includes('Abduction')) return key.includes('Left') ? result.jointMovingLeft : result.jointMovingRight;
    if (key.includes('Hip') && key.includes('Flexion')) return key.includes('Left') ? result.jointBendingLeft : result.jointBendingRight;
    if (key.includes('Hip') && key.includes('Extension')) return key.includes('Left') ? result.jointStraighteningLeft : result.jointStraighteningRight;
    if (key.includes('Hip') && key.includes('InternalRotation')) return key.includes('Left') ? result.jointTurningInwardLeft : result.jointTurningInwardRight;
    if (key.includes('Hip') && key.includes('ExternalRotation')) return key.includes('Left') ? result.jointTurningOutwardLeft : result.jointTurningOutwardRight;
    if (key.includes('Knee') && key.includes('Flexion')) return key.includes('Left') ? result.bendingLeft : result.bendingRight;
    if (key.includes('Knee') && key.includes('Extension')) return key.includes('Left') ? result.extendingLeft : result.extendingRight;
    if (key.includes('Ankle') && key.includes('Dorsiflexion')) return key.includes('Left') ? result.bendingLeft : result.bendingRight;
    if (key.includes('Ankle') && key.includes('Plantarflexion')) return key.includes('Left') ? result.extentionLeft : result.extentionRight;
    if (key.includes('Ankle') && key.includes('Inversion')) return key.includes('Left') ? result.inwardCollapseLeft : result.inwardCollapseRight;
    if (key.includes('Ankle') && key.includes('Eversion')) return key.includes('Left') ? result.outwardCollapseLeft : result.outwardCollapseRight;
    return (Object.values(result) as any[]).find((r: any) => r && r.result) ?? null;
  }

  async reanalyzePrecisionReport(reportId: string): Promise<{ updated: number }> {
    const report = await this.precisionReportRepo.findOne({ where: { id: reportId } });
    if (!report) throw new BadRequestException(`PrecisionReport not found: ${reportId}`);

    const type = report.type as MEASUREMENT_TYPE;

    // ROM 타입: 저장된 result를 기반으로 score/level/comment/romInfo 재계산
    const ROM_TYPES = new Set([
      MEASUREMENT_TYPE.SHOULDER, MEASUREMENT_TYPE.NECK, MEASUREMENT_TYPE.ELBOW,
      MEASUREMENT_TYPE.KNEE, MEASUREMENT_TYPE.HIP, MEASUREMENT_TYPE.ANKLE, MEASUREMENT_TYPE.TORSO,
    ]);

    if (ROM_TYPES.has(type)) {
      const key = report.key;
      if (!key) return { updated: 0 };

      const allStandards = await this.romStandardRepo.find();
      const standard = allStandards.find(s => s.reportNameEn.replace(/\s/g, '') === key);

      if (!standard) {
        this.logger.warn(`No standard found for key: ${key}`);
        return { updated: 0 };
      }

      // 저장된 steps에서 랜드마크 복원 → 전략 재실행으로 올바른 angle 계산
      const storedSteps: Array<{ step: string; landmarks: any }> | undefined =
        (report.analysisData as any)?.[key]?.steps;

      let measuredAngle = 0;
      let reanalyzedResult: any = null;

      if (storedSteps && storedSteps.length >= 1) {
        const startLandmarks = storedSteps[0].landmarks;
        const endLandmarks = storedSteps[storedSteps.length - 1].landmarks;
        const landmarksForStrategy: any = {};
        this.applyKeyToLandmarksStrategy(key, startLandmarks, endLandmarks, landmarksForStrategy);

        let strategy: any;
        if (type === MEASUREMENT_TYPE.NECK) strategy = this.neckStrategy;
        else if (type === MEASUREMENT_TYPE.SHOULDER) strategy = this.shouldersStrategy;
        else if (type === MEASUREMENT_TYPE.TORSO) strategy = this.torsoStrategy;
        else if (type === MEASUREMENT_TYPE.ELBOW) strategy = this.elbowsStrategy;
        else if (type === MEASUREMENT_TYPE.KNEE) strategy = this.kneesStrategy;
        else if (type === MEASUREMENT_TYPE.ANKLE) strategy = this.ankleStrategy;
        else if (type === MEASUREMENT_TYPE.HIP) strategy = this.pelvisStrategy;

        if (strategy) {
          const analyticResult = await strategy.execute(landmarksForStrategy);
          reanalyzedResult = analyticResult.scoreDetail;
          const targetResult = this.resolveTargetResult(key, analyticResult.scoreDetail);
          if (targetResult?.result !== undefined && targetResult?.result !== null) {
            let angleStr: any = targetResult.result;
            try {
              const jsonResult = JSON.parse(String(angleStr));
              if (jsonResult.angle) angleStr = jsonResult.angle;
              else if (jsonResult.distance) angleStr = jsonResult.distance;
            } catch (e) {}
            const match = String(angleStr).match(/-?[\d.]+/);
            if (match) measuredAngle = parseFloat(match[0]);
          }
        }
      } else {
        // fallback: 저장된 result 값 사용
        const storedResult = report.analysisData?.result ?? {};
        const targetResult = this.resolveTargetResult(key, storedResult);
        if (targetResult?.result !== undefined && targetResult?.result !== null) {
          let angleStr: any = targetResult.result;
          try {
            const jsonResult = JSON.parse(String(angleStr));
            if (jsonResult.angle) angleStr = jsonResult.angle;
            else if (jsonResult.distance) angleStr = jsonResult.distance;
          } catch (e) {}
          const match = String(angleStr).match(/-?[\d.]+/);
          if (match) measuredAngle = parseFloat(match[0]);
        }
      }

      const normalAngle = standard.normalDeg;
      const score = Math.min(Math.round((measuredAngle / normalAngle) * 100), 100);
      const romDiff = measuredAngle - normalAngle;

      // 과가동성: measuredAngle로 직접 재계산
      const hyperStages = this.resolveHyperStages(key);
      const excess = measuredAngle - normalAngle;
      const recomputedHyperLevel = (hyperStages && excess > 0)
        ? (getHypermobilityLevel(excess, hyperStages) ?? undefined)
        : undefined;

      const guide = ROM_LEVEL_GUIDE.find(g => score >= g.min && score <= g.max);
      let level = 'GOOD';
      let comment = '';
      if (guide) {
        level = guide.level;
        if (recomputedHyperLevel && HYPERMOBILITY_COMMENT_MAP[recomputedHyperLevel]) {
          level = HYPERMOBILITY_LEVEL_MAP[recomputedHyperLevel] ?? guide.level;
          comment = HYPERMOBILITY_COMMENT_MAP[recomputedHyperLevel];
        } else {
          comment = guide.comment;
        }
      }

      await this.precisionReportRepo.update(reportId, {
        name: standard.reportNameKo,
        score,
        level,
        comment,
        analysisData: {
          ...report.analysisData,
          ...(reanalyzedResult !== null ? { result: reanalyzedResult } : {}),
          romInfo: { measuredAngle, normalAngle, romDiff },
        },
      });
      return { updated: 1 };
    }

    // 비-ROM 타입: 기존 전략 실행 방식
    const landmarks: Landmarks = report.analysisData?.landmarks ?? {};

    const strategyMap = new Map<MEASUREMENT_TYPE, () => void>([
      [MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST, () => this.analyticService.setStrategy(this.spinalAlignmentTestStrategy)],
      [MEASUREMENT_TYPE.BALANCE_TEST,          () => this.analyticService.setStrategy(this.balanceTestStrategy)],
      [MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST,   () => this.analyticService.setStrategy(this.overheadSquatTestStrategy)],
    ]);

    const setStrategy = strategyMap.get(type);
    if (!setStrategy) throw new BadRequestException(`재분석 미지원 타입: ${type}`);
    setStrategy();

    const { score, scoreDetail, disease } = await this.analyticService.execute(landmarks);

    let newScore = score;
    let newLevel = this.resolvePrecisionTestLevel(disease.length);

    if (type === MEASUREMENT_TYPE.BALANCE_TEST) {
      const BALANCE_MAX = 10;
      // score는 감점 합계(음수)이므로 만점에서 차감한 실제 점수를 계산
      const actualScore = Math.max(0, BALANCE_MAX + score);
      const raw = Math.round((actualScore / BALANCE_MAX) * 100);
      const sideLegPassed = scoreDetail?.sideLeg?.disease === 'NORMAL';
      newScore = sideLegPassed ? raw : Math.min(raw, 50);
    }
    if (type === MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST) {
      newScore = 0; // OHT는 score 미사용
    }

    await this.precisionReportRepo.update(reportId, {
      score: newScore,
      level: newLevel,
      analysisData: {
        ...report.analysisData,
        scoreDetail,
        disease,
      },
    });
    return { updated: 1 };
  }

  /**
   * 특정 타입의 모든 PrecisionReport를 일괄 재분석.
   * 건수가 많을 경우 오래 걸릴 수 있으므로 타입을 반드시 지정.
   */
  async reanalyzeAllPrecisionReportsByType(type: MEASUREMENT_TYPE): Promise<{ updated: number }> {
    const reports = await this.precisionReportRepo.find({ where: { type } });
    let updated = 0;
    for (const report of reports) {
      try {
        await this.reanalyzePrecisionReport(report.id);
        updated++;
      } catch (e) {
        this.logger.warn(`reanalyze failed for ${report.id}: ${(e as Error).message}`);
      }
    }
    return { updated };
  }

  async reanalyzeAllBodyReports(): Promise<{ updated: number }> {
    const reports = await this.bodyReportRepo.find();
    let updated = 0;
    for (const report of reports) {
      try {
        await this.reanalyzeBodyReport(report.id);
        updated++;
      } catch (e) {
        this.logger.warn(`reanalyze failed for ${report.id}: ${(e as Error).message}`);
      }
    }
    return { updated };
  }
}
