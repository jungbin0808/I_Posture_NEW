import { ApiProperty } from '@nestjs/swagger';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '관련 타입 (BODY_FRONT, BODY_SIDE, BODY_BACK)' })
  relatedType?: string;
}

export class BodyReportDetailResponseDto {
  @ApiProperty({ description: '리포트 ID' })
  id!: string;

  @ApiProperty({ description: '회원 ID' })
  userId!: string;

  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '종합 점수' })
  totalScore!: number;

  @ApiProperty({ description: '분석 데이터 (JSON)' }) // type: 'object' 제거
  analysisData!: any;

  @ApiProperty({ description: '코멘트', nullable: true })
  comment?: string;

  @ApiProperty({ description: '측정일시' })
  createdAt!: Date;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto] })
  files!: FileDto[];
}
