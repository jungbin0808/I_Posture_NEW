import { IsString, IsNotEmpty, IsEnum, IsOptional, IsObject, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { MEASUREMENT_TYPE } from '../../../common/enums/measurement-type.enum';

class PreviewSizeDto {
  @IsNotEmpty()
  width!: number;

  @IsNotEmpty()
  height!: number;
}

export class CreateAnalysisDto {
  @IsEnum(MEASUREMENT_TYPE)
  @IsNotEmpty()
  type!: string;

  @IsNotEmpty()
  landmarks!: any;

  @IsString()
  @IsNotEmpty()
  measuredAt!: string;

  @IsObject()
  @IsOptional()
  @ValidateNested()
  @Type(() => PreviewSizeDto)
  __previewSize?: PreviewSizeDto;

}
