import { IsString, IsNotEmpty, IsEnum, IsOptional } from 'class-validator';
import { MEASUREMENT_TYPE } from '../../../common/enums/measurement-type.enum';

export class CreatePrecisionAnalysisDto {
  @IsEnum(MEASUREMENT_TYPE)
  @IsNotEmpty()
  type!: string;

  @IsString()
  @IsNotEmpty()
  key!: string;

  @IsNotEmpty()
  landmarks!: any;

  @IsString()
  @IsNotEmpty()
  measuredAt!: string;
}
