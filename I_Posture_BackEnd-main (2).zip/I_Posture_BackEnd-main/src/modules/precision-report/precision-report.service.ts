import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity';
import { FindPrecisionReportDto } from './dto/find-precision-report.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { PrecisionReportResponseDto, PrecisionReportDetailResponseDto } from './dto/precision-report-response.dto';
import { DeletePrecisionReportsDto } from './dto/delete-precision-reports.dto';
import { StoredFileReleaseService } from '../capacity/stored-file-release.service';
import { Transactional } from 'typeorm-transactional';
import { MeasurementReportService } from '../measurement-report/measurement-report.service';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';
import { ReportDisplayLanguage } from '../../common/helpers/resolve-report-display-language.helper';
import { JointRomReportResponseDto } from '../measurement-report/dto/joint-rom-report-response.dto';
import { SpineAlignmentReportResponseDto } from '../measurement-report/dto/spine-alignment-report-response.dto';
import { BalanceSenseReportResponseDto } from '../measurement-report/dto/balance-sense-report-response.dto';
import { FullBodyFunctionReportResponseDto } from '../measurement-report/dto/full-body-function-report-response.dto';

const JOINT_ROM_TYPES = [
  MEASUREMENT_TYPE.NECK,
  MEASUREMENT_TYPE.SHOULDER,
  MEASUREMENT_TYPE.ELBOW,
  MEASUREMENT_TYPE.TORSO,
  MEASUREMENT_TYPE.HIP,
  MEASUREMENT_TYPE.KNEE,
  MEASUREMENT_TYPE.ANKLE,
];

export type PrecisionMeasurementReportDto =
  | JointRomReportResponseDto
  | SpineAlignmentReportResponseDto
  | BalanceSenseReportResponseDto
  | FullBodyFunctionReportResponseDto;

@Injectable()
export class PrecisionReportService {
  constructor(
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(RomStandardEntity)
    private readonly romStandardRepo: Repository<RomStandardEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly storedFileReleaseService: StoredFileReleaseService,
    private readonly measurementReportService: MeasurementReportService,
  ) {}

  /**
   * 앱 회원(A) ID → 트레이너가 관리하는 관리회원(C) ID. 정밀 리포트는 전부 트레이너가 등록하므로
   * 관리회원 ID 기준으로 저장됨 - 회원 본인 조회 시 반드시 이 매핑을 먼저 거쳐야 함.
   */
  private async resolveManagedMemberId(appMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    return link?.managedMemberId ?? null;
  }

  /**
   * 회원의 정밀 리포트 목록을 조회합니다. (트레이너용)
   */
  async findAllByMemberId(trainerId: string, memberId: string, dto: FindPrecisionReportDto): Promise<IPageData<PrecisionReportResponseDto>> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    return this.fetchList(memberId, dto);
  }

  /**
   * 내 정밀 리포트 목록을 조회합니다. (회원 본인용) - 연동된 트레이너가 없으면 빈 목록
   */
  async findAllForOwnMember(appMemberId: string, dto: FindPrecisionReportDto): Promise<IPageData<PrecisionReportResponseDto>> {
    const managedMemberId = await this.resolveManagedMemberId(appMemberId);
    if (!managedMemberId) {
      const { page = 1, limit = 10 } = dto;
      return { items: [], paging: buildPaging(0, limit, page) };
    }
    return this.fetchList(managedMemberId, dto);
  }

  private async fetchList(memberId: string, dto: FindPrecisionReportDto): Promise<IPageData<PrecisionReportResponseDto>> {
    const { page = 1, limit = 10, startDate, endDate, type, types, sort } = dto;
    const query = this.precisionReportRepo.createQueryBuilder('report')
      .where('report.userId = :userId', { userId: memberId })
      .andWhere('report.deletedAt IS NULL');

    if (startDate) query.andWhere('report.createdAt >= :startDate', { startDate });
    if (endDate) query.andWhere('report.createdAt <= :endDate', { endDate });
    if (types && types.length > 0) {
      query.andWhere('report.type IN (:...types)', { types });
    } else if (type) {
      query.andWhere('report.type = :type', { type });
    }

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('report.createdAt', sortDirection);

    const total = await query.getCount();
    const reports = await query.offset((page - 1) * limit).limit(limit).getMany();

    const items: PrecisionReportResponseDto[] = reports.map(report => {
      const analysisData = typeof report.analysisData === 'string'
        ? JSON.parse(report.analysisData)
        : report.analysisData;
      return {
        id: report.id,
        type: report.type,
        key: report.key || '',
        name: report.name || '',
        score: report.score,
        level: report.level || 'NORMAL',
        createdAt: (report.createdAt instanceof Date ? report.createdAt : new Date(report.createdAt)).toISOString(),
        measuredAt: (report.createdAt instanceof Date ? report.createdAt : new Date(report.createdAt)).toISOString().split('T')[0],
        comment: report.comment,
        scoreRangeLabel: this.resolveScoreRangeLabel(report.type, report.score, analysisData?.scoreDetail),
      };
    });

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 정밀 리포트 상세 정보를 조회합니다. (트레이너용)
   */
  async findOne(trainerId: string, memberId: string, id: string): Promise<PrecisionReportDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    return this.fetchOne(memberId, id);
  }

  /**
   * 내 정밀 리포트 상세 정보를 조회합니다. (회원 본인용)
   * 트레이너 앱의 "상세 화면"과 동일한 축약 응답 - 각 관절별(joint-rom 계열)은 트레이너 쪽도
   * 상세 화면과 리포트 화면이 따로 있어서, 여기서는 상세만 반환한다(리포트는 findReportForOwnMember).
   * 척추/전신/균형 3종은 트레이너 쪽에 애초에 이 "상세" 화면 자체가 없다 - 회원 쪽도 호출 시
   * 404를 던져 findReportForOwnMember(리포트 전용)로 유도한다.
   */
  async findOneForOwnMember(appMemberId: string, id: string): Promise<PrecisionReportDetailResponseDto> {
    const report = await this.authorizeOwnMemberAccess(appMemberId, id);

    const NO_DETAIL_SCREEN_TYPES: MEASUREMENT_TYPE[] = [
      MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST,
      MEASUREMENT_TYPE.BALANCE_TEST,
      MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST,
    ];
    if (NO_DETAIL_SCREEN_TYPES.includes(report.type)) {
      throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
    }

    return this.fetchOne(report.userId, id);
  }

  /**
   * 내 정밀 리포트 "리포트" 조회 (회원 본인용) - 트레이너 앱과 동일한 풀 리포트를 그대로 반환.
   * 프론트가 필요한 필드만 골라 쓰면 되므로 트레이너용과 다른 축약 응답을 따로 만들지 않는다.
   * type에 따라 4가지 리포트 중 하나로 분기(joint-rom/spinal-alignment/balance-test/overhead-squat).
   */
  async findReportForOwnMember(
    appMemberId: string,
    id: string,
    lang: ReportDisplayLanguage = 'ko',
  ): Promise<PrecisionMeasurementReportDto> {
    const report = await this.authorizeOwnMemberAccess(appMemberId, id);

    if (report.type === MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST) {
      return this.measurementReportService.getSpineAlignmentReport(report.userId, id, lang);
    }
    if (report.type === MEASUREMENT_TYPE.BALANCE_TEST) {
      return this.measurementReportService.getBalanceSenseReport(report.userId, id, lang);
    }
    if (report.type === MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST) {
      return this.measurementReportService.getFullBodyFunctionReport(report.userId, id, lang);
    }
    if ((JOINT_ROM_TYPES as MEASUREMENT_TYPE[]).includes(report.type)) {
      return this.measurementReportService.getJointRomReport(report.userId, id, lang);
    }

    throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
  }

  /** 회원 본인 또는 연동된 트레이너 소유가 맞는지 확인 후 report 반환 (아니면 404) */
  private async authorizeOwnMemberAccess(appMemberId: string, id: string): Promise<PrecisionReportEntity> {
    const report = await this.precisionReportRepo.findOne({ where: { id } });
    if (!report) throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');

    const isSelfOwned = report.userId === appMemberId && !report.trainerId;
    let isOwnedByLinkedTrainer = false;
    if (!isSelfOwned && report.trainerId) {
      const managedMemberId = await this.resolveManagedMemberId(appMemberId);
      isOwnedByLinkedTrainer = !!managedMemberId && report.userId === managedMemberId;
    }

    if (!isSelfOwned && !isOwnedByLinkedTrainer) {
      throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');
    }

    return report;
  }

  private async fetchOne(memberId: string, id: string): Promise<PrecisionReportDetailResponseDto> {
    const report = await this.precisionReportRepo.findOne({ where: { id, userId: memberId } });
    if (!report) throw new NotFoundException('정밀 리포트를 찾을 수 없습니다.');

    const files = await this.fileRepo.find({ where: { relatedId: id } });

    // 파일 정렬 (division 기준 오름차순: step1 -> step2)
    files.sort((a, b) => {
      if (a.division && b.division) {
        return a.division.localeCompare(b.division);
      }
      return 0;
    });

    // ROM Standard 조회
    let romStandard: RomStandardEntity | null = null;
    if (report.key) {
        const allStandards = await this.romStandardRepo.find({
            relations: ['sensations', 'movementPatterns', 'habits']
        });
        romStandard = allStandards.find(s => s.reportNameEn.replace(/\s/g, '') === report.key) || null;
    }

    return {
      id: report.id,
      type: report.type,
      key: report.key || '',
      name: report.name || '',
      score: report.score,
      level: report.level || 'NORMAL',
      createdAt: (report.createdAt instanceof Date ? report.createdAt : new Date(report.createdAt)).toISOString(),
      measuredAt: (report.createdAt instanceof Date ? report.createdAt : new Date(report.createdAt)).toISOString().split('T')[0],
      comment: report.comment,
      analysisData: report.analysisData,
      files: files.map(f => ({
        id: f.id,
        fileUrl: f.fileUrl,
        relatedType: f.relatedType,
        division: f.division,
      })),
      detailInfo: {
        sensations: romStandard?.sensations.map(s => ({
            content: s.sensationContent
        })) || [],
        movementPatterns: romStandard?.movementPatterns.map(p => ({
            content: p.patternContent,
            imageNo: p.imageNo,
            dailyExample: p.dailyExample
        })) || [],
        habits: romStandard?.habits.map(h => ({
            content: h.habitContent,
            imageNo: h.imageNo
        })) || [],
      },
      landmarks: report.analysisData?.[report.key || '']?.steps || report.analysisData?.landmarks, // 랜드마크 추가
      previewWidth: report.analysisData?.previewWidth ?? null,
      previewHeight: report.analysisData?.previewHeight ?? null,
    };
  }

  /**
   * 정밀 리포트를 일괄 삭제합니다. (논리적 삭제)
   */
  @Transactional()
  async delete(trainerId: string, memberId: string, dto: DeletePrecisionReportsDto): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 삭제할 권한이 없습니다.');

    const reports = await this.precisionReportRepo.find({ where: { id: In(dto.ids), userId: memberId } });
    if (reports.length !== dto.ids.length) {
      throw new NotFoundException('일부 정밀 리포트를 찾을 수 없습니다.');
    }

    for (const report of reports) {
      if (report.trainerId !== trainerId) {
        throw new ForbiddenException(`리포트 ${report.id}를 삭제할 권한이 없습니다.`);
      }
    }

    await this.storedFileReleaseService.releaseForTrainer(trainerId, dto.ids);
    await this.precisionReportRepo.softDelete(dto.ids);
    return { success: true };
  }

  /** type에 따라 scoreRangeLabel 계산 */
  private resolveScoreRangeLabel(type: string, score: number, scoreDetail: any): string | null {
    if (type === 'OVERHEAD_SQUAT_TEST') return this.resolveOHTScoreRangeLabel(scoreDetail);
    if (type === 'BALANCE_TEST') {
      // 상세 API와 동일한 sideLeg 게이팅 적용
      const sideLegPassed = scoreDetail?.sideLeg?.disease === 'NORMAL';
      const effectiveScore = sideLegPassed ? score : Math.min(score, 50);
      return this.resolveBalanceStage(effectiveScore);
    }
    return null;
  }

  /** 균형감각검사: score(0-100) → stage */
  private resolveBalanceStage(score: number): string {
    const s = Math.max(0, Math.min(10, Math.round(score / 10)));
    if (s >= 10) return '안정';
    if (s >= 8) return '기능적 안정';
    if (s >= 6) return '보상적 안정';
    if (s >= 4) return '불안정';
    return '조절상실';
  }

  /** OVERHEAD_SQUAT_TEST: scoreDetail로 scoreRangeLabel 계산 */
  private resolveOHTScoreRangeLabel(scoreDetail: any): string | null {
    if (!scoreDetail) return null;
    const keys = ['hipCenter', 'foot', 'knees', 'ankles', 'hipHigher', 'arm', 'body', 'heel'];
    const scores = keys.map((k) => scoreDetail?.[k]?.score ?? 1);
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    const index = Math.round((avg - 1) * 25 / 4);
    if (index <= 5) return '양호';
    if (index <= 10) return '경미';
    if (index <= 15) return '주의';
    if (index <= 20) return '심각';
    return '매우심각';
  }
}
