import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { RomStandardEntity } from '../../database/entities/rom-standard.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { PrecisionReportController } from './precision-report.controller';
import { PrecisionReportService } from './precision-report.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { CapacityModule } from '../capacity/capacity.module';
import { MeasurementReportModule } from '../measurement-report/measurement-report.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      PrecisionReportEntity,
      UserEntity,
      TrainerUserEntity,
      FileEntity,
      RomStandardEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
      MemberIdentityLinkEntity,
    ]),
    CapacityModule,
    MeasurementReportModule,
  ],
  controllers: [PrecisionReportController],
  providers: [PrecisionReportService, SubscriptionGuard],
  exports: [PrecisionReportService],
})
export class PrecisionReportModule {}
