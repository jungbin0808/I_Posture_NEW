import { ApiProperty } from '@nestjs/swagger';

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '관련 타입 (PRECISION)' })
  relatedType?: string;

  @ApiProperty({ description: '구분 (Key_stepN)', nullable: true })
  division?: string;
}

class RomSensationDto {
  @ApiProperty({ description: '체감 변화 내용' })
  content!: string;
}

class RomMovementPatternDto {
  @ApiProperty({ description: '움직임 패턴 내용' })
  content!: string;

  @ApiProperty({ description: '이미지 번호' })
  imageNo!: number;

  @ApiProperty({ description: '일상 예시' })
  dailyExample!: string;
}

class RomHabitDto {
  @ApiProperty({ description: '습관/자세 내용' })
  content!: string;

  @ApiProperty({ description: '이미지 번호' })
  imageNo!: number;
}

class DetailInfoDto {
  @ApiProperty({ description: '질환 및 통증 (체감 변화)', type: [RomSensationDto] })
  sensations!: RomSensationDto[];

  @ApiProperty({ description: '움직임 패턴', type: [RomMovementPatternDto] })
  movementPatterns!: RomMovementPatternDto[];

  @ApiProperty({ description: '습관 및 자세', type: [RomHabitDto] })
  habits!: RomHabitDto[];
}

export class PrecisionReportResponseDto {
  @ApiProperty({ description: '리포트 ID' })
  id!: string;

  @ApiProperty({ description: '분석 부위 (NECK, SHOULDERS 등)' })
  type!: string;

  @ApiProperty({ description: '동작 키' })
  key!: string;

  @ApiProperty({ description: '동작명' })
  name!: string;

  @ApiProperty({ description: '가동범위 도달률 (%)' })
  score!: number;

  @ApiProperty({ description: '단계 (NORMAL, CAUTION, DANGER)' })
  level!: string;

  @ApiProperty({ description: '측정일시' })
  createdAt!: string;

  @ApiProperty({ description: '측정날짜 (KST, YYYY-MM-DD)' })
  measuredAt!: string;

  @ApiProperty({ description: '코멘트', nullable: true })
  comment?: string;

  @ApiProperty({ description: '운동수행지수 단계 레이블 (경미, 보통 등)', nullable: true })
  scoreRangeLabel?: string | null;
}

export class PrecisionReportDetailResponseDto extends PrecisionReportResponseDto {
  @ApiProperty({ description: '분석 데이터 (JSON)' })
  analysisData!: any;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto] })
  files!: FileDto[];

  @ApiProperty({ description: '상세 정보', type: DetailInfoDto })
  detailInfo?: DetailInfoDto;

  @ApiProperty({ description: '랜드마크 데이터 (JSON)', nullable: true })
  landmarks?: any;

  @ApiProperty({ description: '촬영 미리보기 너비', nullable: true })
  previewWidth?: number | null;

  @ApiProperty({ description: '촬영 미리보기 높이', nullable: true })
  previewHeight?: number | null;
}
