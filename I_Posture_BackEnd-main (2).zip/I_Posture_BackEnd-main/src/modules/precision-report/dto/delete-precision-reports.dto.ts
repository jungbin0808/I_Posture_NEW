import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsString, IsNotEmpty } from 'class-validator';

export class DeletePrecisionReportsDto {
  @ApiProperty({ description: '삭제할 리포트 ID 목록' })
  @IsArray()
  @IsString({ each: true })
  @IsNotEmpty()
  ids!: string[];
}
