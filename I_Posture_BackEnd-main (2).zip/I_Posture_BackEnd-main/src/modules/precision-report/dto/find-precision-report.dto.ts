import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsDateString, IsEnum, IsOptional, IsString, Min } from 'class-validator';
import { Type } from 'class-transformer';

export enum PrecisionReportSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindPrecisionReportDto {
  @ApiProperty({ description: '페이지 번호', required: false, default: 1 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page?: number = 1;

  @ApiProperty({ description: '페이지 당 항목 수', required: false, default: 10 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit?: number = 10;

  @ApiProperty({ description: '시작 날짜 (YYYY-MM-DD)', required: false })
  @IsOptional()
  @IsDateString()
  startDate?: string;

  @ApiProperty({ description: '종료 날짜 (YYYY-MM-DD)', required: false })
  @IsOptional()
  @IsDateString()
  endDate?: string;

  @ApiProperty({ description: '분석 부위 (NECK, SPINAL_ALIGNMENT_TEST 등)', required: false })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsOptional()
  @IsString()
  type?: string;

  @ApiProperty({
    description: '분석 부위 목록 (ROM 등 복수 타입 조회 시)',
    required: false,
    type: [String],
  })
  @IsOptional()
  @Transform(({ value }) => {
    if (value === '' || value === undefined || value === null) {
      return undefined;
    }
    if (Array.isArray(value)) {
      return value;
    }
    return String(value).split(',').map((item) => item.trim()).filter(Boolean);
  })
  @IsArray()
  @IsString({ each: true })
  types?: string[];

  @ApiProperty({ description: '정렬 순서', enum: PrecisionReportSortOrder, required: false, default: PrecisionReportSortOrder.DATE_DESC })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsEnum(PrecisionReportSortOrder)
  @IsOptional()
  sort?: PrecisionReportSortOrder = PrecisionReportSortOrder.DATE_DESC;
}
