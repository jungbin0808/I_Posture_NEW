import { Body, Controller, Delete, Get, Headers, Param, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiHeader, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { PrecisionReportService, PrecisionMeasurementReportDto } from './precision-report.service';
import { FindPrecisionReportDto } from './dto/find-precision-report.dto';
import { PrecisionReportResponseDto, PrecisionReportDetailResponseDto } from './dto/precision-report-response.dto';
import { DeletePrecisionReportsDto } from './dto/delete-precision-reports.dto';
import { resolveReportDisplayLanguage } from '../../common/helpers/resolve-report-display-language.helper';

@ApiTags('Precision Report')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('precision-reports')
export class PrecisionReportController {
  constructor(private readonly precisionReportService: PrecisionReportService) {}

  /**
   * @summary 내 정밀 리포트 목록 조회 (회원 본인)
   */
  @ApiOperation({ summary: 'Get My Precision Report List' })
  @Roles(Role.Member)
  @Get('me')
  async findAllForOwnMember(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const pageData = await this.precisionReportService.findAllForOwnMember(req.user.id, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 내 정밀 리포트 상세 조회 (회원 본인) - 트레이너 앱의 "상세 화면"과 동일.
   * 관절별(joint-rom 계열)만 해당 - 척추/전신/균형은 상세 화면 자체가 없어 404, /report만 사용.
   */
  @ApiOperation({ summary: 'Get My Precision Report Detail (joint-rom types only)' })
  @Roles(Role.Member)
  @Get('me/:id')
  async findOneForOwnMember(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<PrecisionReportDetailResponseDto>> {
    const data = await this.precisionReportService.findOneForOwnMember(req.user.id, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 내 정밀 리포트의 "리포트" 조회 (회원 본인) - 트레이너 앱과 동일한 풀 리포트.
   * 관절별/척추/전신/균형 전부 이 엔드포인트로 조회 (type에 따라 자동 분기).
   */
  @ApiOperation({ summary: 'Get My Precision Report (full report, all types)' })
  @ApiHeader({
    name: 'Accept-Language',
    required: false,
    description: '리포트 표시 언어 (en: 저장된 영문 payload, 미지정: 한글)',
    example: 'en',
  })
  @Roles(Role.Member)
  @Get('me/:id/report')
  async findReportForOwnMember(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<PrecisionMeasurementReportDto>> {
    const data = await this.precisionReportService.findReportForOwnMember(
      req.user.id,
      id,
      resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  /**
   * @summary 회원의 정밀 리포트 목록 조회
   */
  @ApiOperation({ summary: 'Get Member Precision Report List' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() findDto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const pageData = await this.precisionReportService.findAllByMemberId(req.user.id, memberId, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 정밀 리포트 상세 조회
   */
  @ApiOperation({ summary: 'Get Precision Report Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/:id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<PrecisionReportDetailResponseDto>> {
    const data = await this.precisionReportService.findOne(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 정밀 리포트 일괄 삭제
   */
  @ApiOperation({ summary: 'Delete Precision Reports' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() deleteDto: DeletePrecisionReportsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.precisionReportService.delete(req.user.id, memberId, deleteDto);
    return SuccessResponse(result);
  }
}
