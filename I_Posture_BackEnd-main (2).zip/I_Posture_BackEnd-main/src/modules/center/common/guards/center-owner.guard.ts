import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { UserEntity, UserType } from '../../../../database/entities/user.entity';

/**
 * 센터 웹 API 공통 가드 — CENTER(센터 오너)만 허용
 * @UseGuards(AccessTokenGuard, CenterOwnerGuard)
 */
@Injectable()
export class CenterOwnerGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const { user } = context.switchToHttp().getRequest<{ user: UserEntity }>();
    if (!user || user.userType !== UserType.CENTER) {
      throw new ForbiddenException('센터 오너 계정만 이용할 수 있습니다.');
    }
    return true;
  }
}
