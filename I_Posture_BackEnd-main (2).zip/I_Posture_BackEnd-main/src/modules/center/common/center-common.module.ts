import { Module } from '@nestjs/common';
import { AuthModule } from '../../auth/auth.module';
import { CenterOwnerGuard } from './guards/center-owner.guard';

@Module({
  imports: [AuthModule],
  providers: [CenterOwnerGuard],
  exports: [AuthModule, CenterOwnerGuard],
})
export class CenterCommonModule {}
