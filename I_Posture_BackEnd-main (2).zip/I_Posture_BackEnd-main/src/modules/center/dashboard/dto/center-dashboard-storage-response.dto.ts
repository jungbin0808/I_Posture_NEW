import { ApiProperty } from '@nestjs/swagger';

export class CenterDashboardSubscriptionMemberUsageDto {
  @ApiProperty({ description: '이용권 사용 중인 회원 수' })
  count!: number;

  @ApiProperty({ description: '할당 용량 (bytes)' })
  allocatedCapacity!: string;

  @ApiProperty({ description: '할당 용량 표시용', example: '20GB' })
  allocatedCapacityLabel!: string;
}

export class CenterDashboardStorageResponseDto {
  @ApiProperty({ description: '남은 데이터 요약 (남은GB/총GB)', example: '30/110' })
  remainingSummary!: string;

  @ApiProperty({ description: '총 확보 용량 (bytes)' })
  totalCapacity!: number;

  @ApiProperty({ description: '센터 총 데이터 사용량 (bytes)' })
  usedCapacity!: number;

  @ApiProperty({ description: '할당된 용량 (bytes)' })
  allocatedCapacity!: number;

  @ApiProperty({ description: '남은 용량 (bytes)' })
  remainingCapacity!: number;

  @ApiProperty({ description: '총 확보 용량 표시용', example: '110GB' })
  totalCapacityLabel!: string;

  @ApiProperty({ description: '센터 총 데이터 사용량 표시용', example: '30GB' })
  usedCapacityLabel!: string;

  @ApiProperty({ description: '남은 용량 표시용', example: '80GB' })
  remainingCapacityLabel!: string;

  @ApiProperty({ description: '이용권 사용 중인 트레이너 담당 회원' })
  trainerSubscriptionMembers!: CenterDashboardSubscriptionMemberUsageDto;

  @ApiProperty({ description: '이용권 사용 중인 일반 회원 (센터 직접 할당)' })
  generalSubscriptionMembers!: CenterDashboardSubscriptionMemberUsageDto;
}
