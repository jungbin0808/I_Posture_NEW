import { ApiProperty } from '@nestjs/swagger';
import { CenterDashboardMetricKey } from './center-dashboard-metric-key.enum';
import { CenterDashboardTier } from './center-dashboard-tier.enum';

export class CenterDashboardPeriodDto {
  @ApiProperty({ description: '집계 시작월 (YYYY-MM)' })
  fromMonth!: string;

  @ApiProperty({ description: '집계 종료월 (YYYY-MM)' })
  toMonth!: string;

  @ApiProperty({ description: '집계 개월 수', example: 6 })
  months!: number;
}

export class CenterDashboardMetricDefinitionDto {
  @ApiProperty({ enum: CenterDashboardMetricKey })
  key!: CenterDashboardMetricKey;

  @ApiProperty({ description: '지표명' })
  label!: string;
}

export class CenterDashboardTrainerMetricDto {
  @ApiProperty({ enum: CenterDashboardMetricKey })
  key!: CenterDashboardMetricKey;

  @ApiProperty({ description: '비율 (%)', example: 47 })
  rate!: number;

  @ApiProperty({ description: '6개월 누적 건수 (체험 등록 전환율만 예외적으로 명수 — 회원 단위 집계)', example: 7 })
  count!: number;

  @ApiProperty({ description: '센터 내 순위', example: 1 })
  rank!: number;

  @ApiProperty({ enum: CenterDashboardTier })
  tier!: CenterDashboardTier;

  @ApiProperty({ description: '센터 내 상대평가', example: '선두권' })
  tierLabel!: string;
}

export class CenterDashboardTrainerCompetencyItemDto {
  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너명' })
  name!: string;

  @ApiProperty({ type: [CenterDashboardTrainerMetricDto] })
  metrics!: CenterDashboardTrainerMetricDto[];
}

export class CenterDashboardTrainerCompetencyDto {
  @ApiProperty({ type: CenterDashboardPeriodDto })
  period!: CenterDashboardPeriodDto;

  @ApiProperty({ type: [CenterDashboardMetricDefinitionDto] })
  metricDefinitions!: CenterDashboardMetricDefinitionDto[];

  @ApiProperty({ type: [CenterDashboardTrainerCompetencyItemDto] })
  trainers!: CenterDashboardTrainerCompetencyItemDto[];
}

export class CenterDashboardNoSaleRankingItemDto {
  @ApiProperty({ description: '순위', example: 1 })
  rank!: number;

  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너명' })
  name!: string;

  @ApiProperty({ description: '당월 미등록률 (%p)', example: 11 })
  noSaleRate!: number;

  @ApiProperty({ description: '당월 미등록 건수', example: 3 })
  noSaleCount!: number;

  @ApiProperty({ description: '당월 트레킹 노트 총 건수', example: 12 })
  totalConsultations!: number;

  @ApiProperty({ description: '1위 경보 여부' })
  isAlert!: boolean;
}

export class CenterDashboardAlertsDto {
  @ApiProperty({ description: '당월 미등록률 순위 (높은 순)' })
  monthlyNoSaleRanking!: CenterDashboardNoSaleRankingItemDto[];
}

export class CenterDashboardResponseDto {
  @ApiProperty({ type: CenterDashboardTrainerCompetencyDto })
  trainerCompetency!: CenterDashboardTrainerCompetencyDto;

  @ApiProperty({ type: CenterDashboardAlertsDto })
  alerts!: CenterDashboardAlertsDto;
}
