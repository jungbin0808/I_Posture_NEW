export enum CenterDashboardTier {
  LEADING = 'LEADING',
  MIDDLE = 'MIDDLE',
  TRAILING = 'TRAILING',
}
