export enum CenterDashboardMetricKey {
  REG_RENEW = 'REG_RENEW',
  REG_NEW = 'REG_NEW',
  TRIAL = 'TRIAL',
  TRIAL_CONVERSION = 'TRIAL_CONVERSION',
  NO_SALE = 'NO_SALE',
}
