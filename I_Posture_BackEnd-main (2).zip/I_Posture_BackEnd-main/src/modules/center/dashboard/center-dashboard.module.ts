import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CenterCommonModule } from '../common/center-common.module';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { CenterDashboardController } from './center-dashboard.controller';
import { CenterDashboardService } from './center-dashboard.service';
import { CenterDashboardAggregateService } from './center-dashboard-aggregate.service';

@Module({
  imports: [
    CenterCommonModule,
    TypeOrmModule.forFeature([CenterEntity, CenterTrainerEntity, UserEntity]),
  ],
  controllers: [CenterDashboardController],
  providers: [CenterDashboardService, CenterDashboardAggregateService],
})
export class CenterDashboardModule {}
