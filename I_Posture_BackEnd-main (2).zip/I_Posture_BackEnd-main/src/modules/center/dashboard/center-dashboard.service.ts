import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CenterEntity } from '../../../database/entities/center.entity';
import {
  CenterTrainerEntity,
  CenterTrainerStatus,
} from '../../../database/entities/center-trainer.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { CenterDashboardMetricKey } from './dto/center-dashboard-metric-key.enum';
import {
  CenterDashboardAlertsDto,
  CenterDashboardResponseDto,
  CenterDashboardTrainerCompetencyDto,
  CenterDashboardTrainerMetricDto,
} from './dto/center-dashboard-response.dto';
import {
  assignCompetitionRanks,
  calcRate,
  resolveCenterDashboardTier,
  toCenterDashboardTierLabel,
} from './helpers/center-dashboard-rank.helper';
import {
  CURRENT_MONTH_NO_SALE_ALERTS_SQL,
  findTrialConversionByTrainer,
  mapCurrentMonthAlertRow,
  mapMemberMonthStatusRow,
  mapTrialConversionRow,
  MEMBER_MONTH_STATUS_MONTHLY_SQL,
  MemberMonthStatusMonthlyRow,
  resolveKstCurrentMonthRange,
  sumMemberMonthStatusByTrainer,
  TRIAL_CONVERSION_SIX_MONTH_SQL,
  TrialConversionByTrainerRow,
} from './helpers/center-dashboard-heatmap.helper';

interface DashboardPeriod {
  startOfMonth: Date;
  nextMonth: Date;
  sixMonthsAgo: Date;
  fromMonth: string;
  toMonth: string;
}

interface CenterTrainerRow {
  trainerId: string;
  name: string;
}

const METRIC_DEFINITIONS = [
  { key: CenterDashboardMetricKey.REG_RENEW, label: '재등록률' },
  { key: CenterDashboardMetricKey.REG_NEW, label: '신규등록률' },
  { key: CenterDashboardMetricKey.TRIAL, label: '체험수업률' },
  { key: CenterDashboardMetricKey.TRIAL_CONVERSION, label: '체험 등록 전환율' },
  { key: CenterDashboardMetricKey.NO_SALE, label: '미등록률' },
] as const;

@Injectable()
export class CenterDashboardService {
  constructor(
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
  ) {}

  async getDashboard(ownerId: string): Promise<CenterDashboardResponseDto> {
    const center = await this.resolveCenter(ownerId);
    const period = this.resolvePeriod();
    const trainers = await this.findCenterTrainers(center.id);

    if (trainers.length === 0) {
      return {
        trainerCompetency: this.buildEmptyCompetency(period),
        alerts: { monthlyNoSaleRanking: [] },
      };
    }

    const trainerIds = trainers.map((trainer) => trainer.trainerId);
    const currentMonthRange = resolveKstCurrentMonthRange();
    const [memberMonthStatusMonthly, trialConversionSixMonth, currentMonthAlerts] = await Promise.all([
      this.fetchMemberMonthStatusMonthly(trainerIds, period.sixMonthsAgo),
      this.fetchTrialConversionSixMonth(trainerIds, period.sixMonthsAgo),
      this.fetchCurrentMonthNoSaleAlerts(
        trainerIds,
        currentMonthRange.startOfMonth,
        currentMonthRange.nextMonth,
      ),
    ]);

    const trainerMetrics = trainers.map((trainer) => {
      const sixMonthTotals = sumMemberMonthStatusByTrainer(
        memberMonthStatusMonthly,
        trainer.trainerId,
      );
      const trialConversion = findTrialConversionByTrainer(
        trialConversionSixMonth,
        trainer.trainerId,
      );
      const denominator = sixMonthTotals.total;

      return {
        trainerId: trainer.trainerId,
        name: trainer.name,
        values: {
          [CenterDashboardMetricKey.REG_RENEW]: {
            count: sixMonthTotals.regRenew,
            rate: calcRate(sixMonthTotals.regRenew, denominator),
          },
          [CenterDashboardMetricKey.REG_NEW]: {
            count: sixMonthTotals.regNew,
            rate: calcRate(sixMonthTotals.regNew, denominator),
          },
          [CenterDashboardMetricKey.TRIAL]: {
            count: sixMonthTotals.trial,
            rate: calcRate(sixMonthTotals.trial, denominator),
          },
          [CenterDashboardMetricKey.TRIAL_CONVERSION]: {
            count: trialConversion.trialConversionCount,
            rate: calcRate(
              trialConversion.trialConversionCount,
              trialConversion.trialMemberCount,
            ),
          },
          [CenterDashboardMetricKey.NO_SALE]: {
            count: sixMonthTotals.noSale,
            rate: calcRate(sixMonthTotals.noSale, denominator),
          },
        },
      };
    });

    const trainerCompetency: CenterDashboardTrainerCompetencyDto = {
      period: {
        fromMonth: period.fromMonth,
        toMonth: period.toMonth,
        months: 6,
      },
      metricDefinitions: [...METRIC_DEFINITIONS],
      trainers: trainerMetrics.map((trainer) => ({
        trainerId: trainer.trainerId,
        name: trainer.name,
        metrics: this.buildRankedMetrics(trainerMetrics, trainer.trainerId),
      })),
    };

    const alerts: CenterDashboardAlertsDto = {
      monthlyNoSaleRanking: this.buildMonthlyNoSaleRanking(
        trainers,
        currentMonthAlerts,
      ),
    };

    return { trainerCompetency, alerts };
  }

  private buildRankedMetrics(
    trainerMetrics: Array<{
      trainerId: string;
      values: Record<CenterDashboardMetricKey, { count: number; rate: number }>;
    }>,
    trainerId: string,
  ): CenterDashboardTrainerMetricDto[] {
    const total = trainerMetrics.length;
    const target = trainerMetrics.find((item) => item.trainerId === trainerId);

    if (!target) {
      return [];
    }

    return METRIC_DEFINITIONS.map((definition) => {
      const ranks = assignCompetitionRanks(
        trainerMetrics,
        (item) => item.values[definition.key].rate,
        definition.key !== CenterDashboardMetricKey.NO_SALE,
      );

      const metric = target.values[definition.key];
      const rank = ranks.get(target) ?? total;
      const tier = resolveCenterDashboardTier(rank, total);

      return {
        key: definition.key,
        rate: metric.rate,
        count: metric.count,
        rank,
        tier,
        tierLabel: toCenterDashboardTierLabel(tier),
      };
    });
  }

  private buildMonthlyNoSaleRanking(
    trainers: CenterTrainerRow[],
    currentMonthAlerts: Map<string, { total: number; noSale: number }>,
  ) {
    const rankingItems = trainers.map((trainer) => {
      const monthTotals = currentMonthAlerts.get(trainer.trainerId) ?? {
        total: 0,
        noSale: 0,
      };

      return {
        trainerId: trainer.trainerId,
        name: trainer.name,
        noSaleRate: calcRate(monthTotals.noSale, monthTotals.total),
        noSaleCount: monthTotals.noSale,
        totalConsultations: monthTotals.total,
      };
    });

    const ranks = assignCompetitionRanks(
      rankingItems,
      (item) => item.noSaleRate,
      true,
    );

    return [...rankingItems]
      .sort((left, right) => {
        if (right.noSaleRate !== left.noSaleRate) {
          return right.noSaleRate - left.noSaleRate;
        }

        return left.name.localeCompare(right.name, 'ko');
      })
      .map((item) => {
        const rank = ranks.get(item) ?? rankingItems.length;

        return {
          rank,
          trainerId: item.trainerId,
          name: item.name,
          noSaleRate: item.noSaleRate,
          noSaleCount: item.noSaleCount,
          totalConsultations: item.totalConsultations,
          isAlert: rank === 1,
        };
      });
  }

  private buildEmptyCompetency(period: DashboardPeriod): CenterDashboardTrainerCompetencyDto {
    return {
      period: {
        fromMonth: period.fromMonth,
        toMonth: period.toMonth,
        months: 6,
      },
      metricDefinitions: [...METRIC_DEFINITIONS],
      trainers: [],
    };
  }

  private resolvePeriod(): DashboardPeriod {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);

    return {
      startOfMonth,
      nextMonth,
      sixMonthsAgo,
      fromMonth: this.formatYearMonth(sixMonthsAgo),
      toMonth: this.formatYearMonth(startOfMonth),
    };
  }

  private formatYearMonth(date: Date): string {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    return `${year}-${month}`;
  }

  private async resolveCenter(ownerId: string): Promise<CenterEntity> {
    const center = await this.centerRepo.findOne({ where: { ownerId } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }

    return center;
  }

  private async findCenterTrainers(centerId: string): Promise<CenterTrainerRow[]> {
    const rows = await this.centerTrainerRepo.createQueryBuilder('ct')
      .innerJoin(UserEntity, 'trainer', 'trainer.id = ct.trainer_id')
      .where('ct.center_id = :centerId', { centerId })
      .andWhere('ct.deleted_at IS NULL')
      .andWhere('ct.status = :status', { status: CenterTrainerStatus.WORKING })
      .andWhere('ct.deactivated_at IS NULL')
      .select('trainer.id', 'trainerId')
      .addSelect('trainer.name', 'name')
      .orderBy('trainer.name', 'ASC')
      .addOrderBy('trainer.id', 'ASC')
      .getRawMany<CenterTrainerRow>();

    return rows;
  }

  private async fetchMemberMonthStatusMonthly(
    trainerIds: string[],
    sixMonthsAgo: Date,
  ): Promise<MemberMonthStatusMonthlyRow[]> {
    if (trainerIds.length === 0) {
      return [];
    }

    const rows = await this.userRepo.query(
      MEMBER_MONTH_STATUS_MONTHLY_SQL,
      [sixMonthsAgo, trainerIds, trainerIds, trainerIds],
    );

    return rows.map((row: Record<string, string>) => mapMemberMonthStatusRow(row));
  }

  private async fetchTrialConversionSixMonth(
    trainerIds: string[],
    sixMonthsAgo: Date,
  ): Promise<TrialConversionByTrainerRow[]> {
    if (trainerIds.length === 0) {
      return [];
    }

    const rows = await this.userRepo.query(
      TRIAL_CONVERSION_SIX_MONTH_SQL,
      [sixMonthsAgo, trainerIds, trainerIds, trainerIds, trainerIds],
    );

    return rows.map((row: Record<string, string>) => mapTrialConversionRow(row));
  }

  private async fetchCurrentMonthNoSaleAlerts(
    trainerIds: string[],
    startOfMonth: Date,
    nextMonth: Date,
  ): Promise<Map<string, { total: number; noSale: number }>> {
    if (trainerIds.length === 0) {
      return new Map();
    }

    const rows = await this.userRepo.query(
      CURRENT_MONTH_NO_SALE_ALERTS_SQL,
      [startOfMonth, nextMonth, trainerIds, trainerIds, trainerIds],
    );

    return new Map(
      rows.map((row: Record<string, string>) => {
        const mapped = mapCurrentMonthAlertRow(row);
        return [mapped.trainerId, { total: mapped.total, noSale: mapped.noSale }];
      }),
    );
  }
}
