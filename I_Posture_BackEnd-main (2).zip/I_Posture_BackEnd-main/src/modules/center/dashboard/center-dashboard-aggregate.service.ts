import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { CenterEntity } from '../../../database/entities/center.entity';
import {
  CenterTrainerEntity,
  CenterTrainerStatus,
} from '../../../database/entities/center-trainer.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { formatBytesDisplay } from '../../../common/utils/capacity.util';
import { CenterDashboardStorageResponseDto } from './dto/center-dashboard-storage-response.dto';
import {
  calcTrialConversionRatePercent,
  fetchTrialConversionMetrics,
} from '../../consultation-log/helpers/trial-conversion-metrics.helper';

interface CenterContext {
  centerId: string;
  trainerIds: string[];
}

@Injectable()
export class CenterDashboardAggregateService {
  constructor(
    @InjectDataSource()
    private readonly dataSource: DataSource,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
  ) {}

  async getMemberManagement(ownerId: string) {
    const { trainerIds } = await this.resolveContext(ownerId);
    if (trainerIds.length === 0) {
      return this.emptyMemberManagement();
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const threeDaysLater = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 3);

    const [lessonStat] = await this.dataSource.query(
      `
        SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN wl.attendance IN ('PRESENT','LATE') THEN 1 ELSE 0 END) AS attended,
          SUM(CASE WHEN wl.attendance = 'ABSENT' THEN 1 ELSE 0 END) AS absent
        FROM workout_logs wl
        WHERE wl.trainer_id IN (?)
          AND wl.workout_date >= ?
          AND wl.workout_date < ?
          AND wl.deleted_at IS NULL
      `,
      [trainerIds, startOfMonth, nextMonth],
    );

    const total = Number(lessonStat?.total) || 0;
    const attended = Number(lessonStat?.attended) || 0;
    const absent = Number(lessonStat?.absent) || 0;

    const lowLessonMembers = await this.dataSource.query(
      `
        SELECT
          u.id AS memberId,
          u.name AS memberName,
          trainer.id AS trainerId,
          COALESCE(wl.cnt, 0) + COALESCE(sb.cnt, 0) AS lessonCount
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        INNER JOIN users trainer ON trainer.id = tu.trainer_id
        LEFT JOIN (
          SELECT wl2.user_id AS uid, COUNT(*) AS cnt
          FROM workout_logs wl2
          WHERE wl2.trainer_id IN (?)
            AND wl2.workout_date >= ?
            AND wl2.workout_date < ?
            AND wl2.deleted_at IS NULL
          GROUP BY wl2.user_id
        ) wl ON wl.uid = u.id
        LEFT JOIN (
          SELECT sb2.user_id AS uid, COUNT(*) AS cnt
          FROM schedule_bookings sb2
          INNER JOIN schedules s2
            ON s2.id = sb2.schedule_id
            AND s2.trainer_id IN (?)
            AND s2.start_time >= ?
            AND s2.start_time < ?
            AND s2.deleted_at IS NULL
          WHERE sb2.deleted_at IS NULL
            AND sb2.status != 'CANCELED'
          GROUP BY sb2.user_id
        ) sb ON sb.uid = u.id
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
        ORDER BY lessonCount ASC
        LIMIT 5
      `,
      [
        trainerIds, startOfMonth, nextMonth,
        trainerIds, startOfMonth, nextMonth,
        trainerIds,
      ],
    );

    const lowMeasurementMembers = await this.dataSource.query(
      `
        SELECT
          u.id AS memberId,
          u.name AS memberName,
          trainer.id AS trainerId,
          COALESCE(mc.cnt, 0) AS measurementCount
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        INNER JOIN users trainer ON trainer.id = tu.trainer_id
        LEFT JOIN (
          SELECT uid, COUNT(*) AS cnt
          FROM (
            SELECT user_id AS uid FROM body_reports
            WHERE trainer_id IN (?) AND created_at >= ? AND deleted_at IS NULL
            UNION ALL
            SELECT user_id AS uid FROM precision_reports
            WHERE trainer_id IN (?) AND created_at >= ? AND deleted_at IS NULL
            UNION ALL
            SELECT user_id AS uid FROM inbody_data
            WHERE trainer_id IN (?) AND created_at >= ? AND deleted_at IS NULL
            UNION ALL
            SELECT user_id AS uid FROM motion_analyses
            WHERE trainer_id IN (?) AND created_at >= ? AND deleted_at IS NULL
          ) all_records
          GROUP BY uid
        ) mc ON mc.uid = u.id
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
        ORDER BY measurementCount ASC
        LIMIT 5
      `,
      [
        trainerIds, threeMonthsAgo,
        trainerIds, threeMonthsAgo,
        trainerIds, threeMonthsAgo,
        trainerIds, threeMonthsAgo,
        trainerIds,
      ],
    );

    const dormantMembers = await this.dataSource.query(
      `
        SELECT tu.member_id AS memberId, u.name AS memberName, tu.trainer_id AS trainerId
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        INNER JOIN users trainer ON trainer.id = tu.trainer_id
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
          AND tu.member_id NOT IN (
            SELECT DISTINCT br.user_id
            FROM body_reports br
            WHERE br.trainer_id IN (?)
              AND br.created_at >= ?
              AND br.deleted_at IS NULL
            UNION
            SELECT DISTINCT sb.user_id
            FROM schedule_bookings sb
            INNER JOIN schedules s
              ON s.id = sb.schedule_id
              AND s.trainer_id IN (?)
              AND s.start_time >= ?
              AND s.deleted_at IS NULL
            WHERE sb.status = 'APPLIED'
              AND sb.deleted_at IS NULL
          )
        ORDER BY u.name ASC
      `,
      [trainerIds, trainerIds, thirtyDaysAgo, trainerIds, thirtyDaysAgo],
    );

    const rawSchedules = await this.dataSource.query(
      `
        SELECT
          s.start_time AS startTime,
          u.id AS memberId,
          u.name AS memberName,
          trainer.id AS trainerId
        FROM schedules s
        INNER JOIN schedule_bookings sb
          ON sb.schedule_id = s.id
          AND sb.deleted_at IS NULL
          AND sb.status != 'CANCELED'
        INNER JOIN users u ON u.id = sb.user_id
        INNER JOIN users trainer ON trainer.id = s.trainer_id
        WHERE s.trainer_id IN (?)
          AND s.start_time >= ?
          AND s.start_time < ?
          AND s.deleted_at IS NULL
        ORDER BY s.start_time ASC
      `,
      [trainerIds, startOfToday, threeDaysLater],
    );

    const scheduleMap = new Map<string, Map<string, { id: string; name: string; trainerId: string }[]>>();
    for (const row of rawSchedules) {
      const dt = new Date(row.startTime);
      const kstOffset = 9 * 60 * 60 * 1000;
      const kstDt = new Date(dt.getTime() + kstOffset);
      const date = kstDt.toISOString().substring(0, 10);
      const time = kstDt.toISOString().substring(11, 16);
      if (!scheduleMap.has(date)) {
        scheduleMap.set(date, new Map());
      }
      const timeMap = scheduleMap.get(date)!;
      if (!timeMap.has(time)) {
        timeMap.set(time, []);
      }
      timeMap.get(time)!.push({
        id: row.memberId,
        name: row.memberName,
        trainerId: row.trainerId,
      });
    }

    const upcomingSchedules = Array.from(scheduleMap.entries()).map(([date, timeMap]) => ({
      date,
      slots: Array.from(timeMap.entries()).map(([time, members]) => ({ time, members })),
    }));

    return {
      lesson: {
        attendanceRate: total > 0 ? Math.round((attended / total) * 100) : 0,
        attendanceCount: attended,
        absenceRate: total > 0 ? 100 - Math.round((attended / total) * 100) : 0,
        absenceCount: absent,
      },
      retentionRisk: {
        lowLessonFrequency: lowLessonMembers.map((row: Record<string, string>) => ({
          memberId: row.memberId,
          memberName: row.memberName,
          trainerId: row.trainerId,
          count: Number(row.lessonCount) || 0,
        })),
        lowMeasurementFrequency: lowMeasurementMembers.map((row: Record<string, string>) => ({
          memberId: row.memberId,
          memberName: row.memberName,
          trainerId: row.trainerId,
          count: Number(row.measurementCount) || 0,
        })),
        dormantCount: dormantMembers.length,
        dormantMembers: dormantMembers.map((row: Record<string, string>) => ({
          memberId: row.memberId,
          memberName: row.memberName,
          trainerId: row.trainerId,
        })),
      },
      upcomingSchedules,
    };
  }

  async getPerformance(ownerId: string) {
    const { trainerIds } = await this.resolveContext(ownerId);
    if (trainerIds.length === 0) {
      return this.emptyPerformance();
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    // 이번 달 body_report 중 회원별 역대 최고(가장 낮은) 값 조회
    const bodyData = await this.dataSource.query(
      `
        SELECT
          u.id AS memberId,
          u.name AS memberName,
          trainer.id AS trainerId,
          MIN(br.neck_score) AS neckScore,
          MIN(br.pelvis_asymmetry_score) AS pelvisScore,
          MIN(br.shoulder_asymmetry_score) AS shoulderScore
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        INNER JOIN users trainer ON trainer.id = tu.trainer_id
        INNER JOIN body_reports br
          ON br.user_id = tu.member_id
          AND br.trainer_id IN (?)
          AND br.created_at >= ?
          AND br.created_at < ?
          AND br.deleted_at IS NULL
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
        GROUP BY u.id, u.name, trainer.id
      `,
      [trainerIds, startOfMonth, nextMonth, trainerIds],
    );

    const romRows = await this.dataSource.query(
      `
        SELECT
          u.id AS memberId,
          u.name AS memberName,
          trainer.id AS trainerId,
          MIN(pr.score) AS minScore
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        INNER JOIN users trainer ON trainer.id = tu.trainer_id
        INNER JOIN precision_reports pr
          ON pr.user_id = tu.member_id
          AND pr.trainer_id = tu.trainer_id
          AND pr.created_at >= ?
          AND pr.created_at < ?
          AND pr.deleted_at IS NULL
          AND pr.type NOT IN ('BODY','SPINAL_ALIGNMENT_TEST','OVERHEAD_SQUAT_TEST','BALANCE_TEST')
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
        GROUP BY u.id, u.name, tu.trainer_id
        ORDER BY minScore ASC
      `,
      [startOfMonth, nextMonth, trainerIds],
    );

    const sortBody = (key: string, asc: boolean) => {
      const sorted = [...bodyData].sort((left: Record<string, string>, right: Record<string, string>) => asc
        ? Number(left[key]) - Number(right[key])
        : Number(right[key]) - Number(left[key]));

      return sorted.slice(0, 3).map((row: Record<string, string>) => ({
        memberId: row.memberId,
        memberName: row.memberName,
        trainerId: row.trainerId,
        value: Number(row[key]) || 0,
      }));
    };

    return {
      turtleNeck: {
        top3: sortBody('neckScore', true),
        bottom3: sortBody('neckScore', false),
      },
      pelvisAsymmetry: {
        top3: sortBody('pelvisScore', true),
        bottom3: sortBody('pelvisScore', false),
      },
      shoulderAsymmetry: {
        top3: sortBody('shoulderScore', true),
        bottom3: sortBody('shoulderScore', false),
      },
      rom: {
        bottom3: romRows.slice(0, 3).map((row: Record<string, string>) => ({
          memberId: row.memberId,
          memberName: row.memberName,
          trainerId: row.trainerId,
          value: Math.round(Number(row.minScore)) || 0,
        })),
      },
    };
  }

  async getStorage(ownerId: string): Promise<CenterDashboardStorageResponseDto> {
    const { centerId } = await this.resolveContext(ownerId);

    const [pool] = await this.dataSource.query(
      `
        SELECT total_capacity AS totalCapacity,
               used_capacity AS usedCapacity,
               allocated_capacity AS allocatedCapacity
        FROM center_capacity_pool
        WHERE center_id = ?
      `,
      [centerId],
    );

    const [trainerMembers] = await this.dataSource.query(
      `
        SELECT
          COUNT(DISTINCT sa.member_id) AS memberCount,
          COALESCE(SUM(sa.allocated_capacity), 0) AS allocatedCapacity
        FROM storage_allocations sa
        INNER JOIN subscriptions s
          ON s.user_id = sa.member_id
          AND s.status = 'ACTIVE'
        INNER JOIN center_trainers ct
          ON ct.trainer_id = sa.owner_id
          AND ct.center_id = ?
          AND ct.deleted_at IS NULL
        WHERE sa.owner_type = 'TRAINER'
          AND sa.status = 'ACTIVE'
      `,
      [centerId],
    );

    const [generalMembers] = await this.dataSource.query(
      `
        SELECT
          COUNT(DISTINCT sa.member_id) AS memberCount,
          COALESCE(SUM(sa.allocated_capacity), 0) AS allocatedCapacity
        FROM storage_allocations sa
        INNER JOIN subscriptions s
          ON s.user_id = sa.member_id
          AND s.status = 'ACTIVE'
        WHERE sa.owner_type = 'CENTER'
          AND sa.owner_id = ?
          AND sa.status = 'ACTIVE'
      `,
      [centerId],
    );

    const totalCapacity = Number(pool?.totalCapacity ?? 0);
    const usedCapacity = Number(pool?.usedCapacity ?? 0);
    const allocatedCapacity = Number(pool?.allocatedCapacity ?? 0);
    const remainingCapacity = Math.max(0, totalCapacity - usedCapacity - allocatedCapacity);

    const remainingGb = this.toWholeGb(remainingCapacity);
    const totalGb = this.toWholeGb(totalCapacity);

    return {
      remainingSummary: `${remainingGb}/${totalGb}`,
      totalCapacity,
      usedCapacity,
      allocatedCapacity,
      remainingCapacity,
      totalCapacityLabel: formatBytesDisplay(totalCapacity),
      usedCapacityLabel: formatBytesDisplay(usedCapacity),
      remainingCapacityLabel: formatBytesDisplay(remainingCapacity),
      trainerSubscriptionMembers: {
        count: Number(trainerMembers?.memberCount) || 0,
        allocatedCapacity: String(trainerMembers?.allocatedCapacity ?? '0'),
        allocatedCapacityLabel: formatBytesDisplay(trainerMembers?.allocatedCapacity ?? '0'),
      },
      generalSubscriptionMembers: {
        count: Number(generalMembers?.memberCount) || 0,
        allocatedCapacity: String(generalMembers?.allocatedCapacity ?? '0'),
        allocatedCapacityLabel: formatBytesDisplay(generalMembers?.allocatedCapacity ?? '0'),
      },
    };
  }

  async getSalesFunnel(ownerId: string) {
    const { trainerIds } = await this.resolveContext(ownerId);
    if (trainerIds.length === 0) {
      return this.emptySalesFunnel();
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);

    const monthlyTrends = await this.dataSource.query(
      `
        SELECT
          DATE_FORMAT(cl.consult_at, '%Y-%m') AS month,
          COUNT(*) AS total,
          SUM(CASE WHEN cl.result_status = 'TRIAL' THEN 1 ELSE 0 END) AS trial,
          SUM(CASE WHEN cl.result_status = 'REG_NEW' THEN 1 ELSE 0 END) AS regNew,
          SUM(CASE WHEN cl.result_status = 'REG_RENEW' THEN 1 ELSE 0 END) AS regRenew,
          SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
        FROM consultation_logs cl
        WHERE cl.trainer_id IN (?)
          AND cl.consult_at >= ?
          AND cl.deleted_at IS NULL
        GROUP BY DATE_FORMAT(cl.consult_at, '%Y-%m')
        ORDER BY month ASC
      `,
      [trainerIds, sixMonthsAgo],
    );

    const [currentMonth] = await this.dataSource.query(
      `
        SELECT
          COUNT(*) AS total,
          SUM(CASE WHEN cl.result_status = 'TRIAL' THEN 1 ELSE 0 END) AS trial,
          SUM(CASE WHEN cl.result_status = 'REG_NEW' THEN 1 ELSE 0 END) AS regNew,
          SUM(CASE WHEN cl.result_status = 'REG_RENEW' THEN 1 ELSE 0 END) AS regRenew,
          SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
        FROM consultation_logs cl
        WHERE cl.trainer_id IN (?)
          AND cl.consult_at >= ?
          AND cl.consult_at < ?
          AND cl.deleted_at IS NULL
      `,
      [trainerIds, startOfMonth, nextMonth],
    );

    const [registeredCount] = await this.dataSource.query(
      `
        SELECT COUNT(*) AS cnt
        FROM trainer_users tu
        WHERE tu.trainer_id IN (?)
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
      `,
      [trainerIds],
    );

    const monthlyAppSignups = await this.dataSource.query(
      `
        SELECT
          DATE_FORMAT(tu.created_at, '%Y-%m') AS month,
          COUNT(*) AS count
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        WHERE tu.trainer_id IN (?)
          AND tu.created_at >= ?
          AND tu.deleted_at IS NULL
          AND tu.status = 'ACTIVE'
        GROUP BY DATE_FORMAT(tu.created_at, '%Y-%m')
        ORDER BY month ASC
      `,
      [trainerIds, sixMonthsAgo],
    );

    const [currentMonthSignup] = await this.dataSource.query(
      `
        SELECT COUNT(*) AS cnt
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        WHERE tu.trainer_id IN (?)
          AND tu.created_at >= ?
          AND tu.created_at < ?
          AND tu.deleted_at IS NULL
          AND tu.status = 'ACTIVE'
      `,
      [trainerIds, startOfMonth, nextMonth],
    );

    const totalConsult = Number(currentMonth?.total) || 0;
    const trialCount = Number(currentMonth?.trial) || 0;
    const regNew = Number(currentMonth?.regNew) || 0;
    const regRenew = Number(currentMonth?.regRenew) || 0;
    const noSale = Number(currentMonth?.noSale) || 0;

    const { trialMemberCount, trialConversionCount } = await fetchTrialConversionMetrics(
      this.dataSource,
      trainerIds,
      startOfMonth,
      nextMonth,
    );

    return {
      monthlyTrends: monthlyTrends.map((row: Record<string, string>) => {
        const tot = Number(row.total) || 0;
        const tr = Number(row.trial) || 0;
        const rn = Number(row.regNew) || 0;
        const rr = Number(row.regRenew) || 0;
        const ns = Number(row.noSale) || 0;

        return {
          month: row.month,
          total: tot,
          trial: tr,
          regNew: rn,
          regRenew: rr,
          noSale: ns,
          trialRate: tot > 0 ? Math.round((tr / tot) * 100) : 0,
          regNewRate: tot > 0 ? Math.round((rn / tot) * 100) : 0,
          regRenewRate: tot > 0 ? Math.round((rr / tot) * 100) : 0,
          noSaleRate: tot > 0 ? Math.round((ns / tot) * 100) : 0,
          conversionRate: tot > 0 ? Math.round(((tot - ns) / tot) * 100) : 0,
        };
      }),
      currentMonth: {
        totalConsultations: totalConsult,
        conversionRate: totalConsult > 0 ? Math.round(((totalConsult - noSale) / totalConsult) * 100) : 0,
        trial: trialCount,
        regNew,
        regRenew,
        noSale,
        trialRate: totalConsult > 0 ? Math.round((trialCount / totalConsult) * 100) : 0,
        regNewRate: totalConsult > 0 ? Math.round((regNew / totalConsult) * 100) : 0,
        regRenewRate: totalConsult > 0 ? Math.round((regRenew / totalConsult) * 100) : 0,
        noSaleRate: totalConsult > 0 ? Math.round((noSale / totalConsult) * 100) : 0,
      },
      monthlyAppSignups: monthlyAppSignups.map((row: Record<string, string>) => ({
        month: row.month,
        count: Number(row.count) || 0,
      })),
      currentMonthAppSignups: Number(currentMonthSignup?.cnt) || 0,
      totalRegisteredMembers: Number(registeredCount?.cnt) || 0,
      trialMemberCount,
      trialConversionCount,
      trialConversionRate: calcTrialConversionRatePercent(
        trialConversionCount,
        trialMemberCount,
      ),
      afterConsultNoPayRate: totalConsult > 0 ? Math.round((noSale / totalConsult) * 100) : 0,
      afterConsultNoRegCount: noSale,
    };
  }

  async getPerformanceRecordsByMember(
    ownerId: string,
    memberId: string,
    type: 'neck' | 'pelvis' | 'shoulder' | 'rom',
    direction: 'top' | 'bottom',
  ) {
    const { trainerIds } = await this.resolveContext(ownerId);
    if (trainerIds.length === 0) {
      return { memberName: null, records: [] };
    }

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    const [memberRow] = await this.dataSource.query(
      `
        SELECT u.name AS memberName, tu.trainer_id AS trainerId
        FROM trainer_users tu
        INNER JOIN users u ON u.id = tu.member_id AND u.deleted_at IS NULL
        WHERE tu.trainer_id IN (?)
          AND tu.member_id = ?
          AND tu.status = 'ACTIVE'
          AND tu.deleted_at IS NULL
        LIMIT 1
      `,
      [trainerIds, memberId],
    );

    if (!memberRow) {
      return { memberName: null, trainerId: null, records: [] };
    }

    const trainerId = memberRow.trainerId;

    if (type === 'rom') {
      const orderDir = direction === 'top' ? 'DESC' : 'ASC';
      const rows = await this.dataSource.query(
        `
          SELECT
            pr.id AS reportId,
            'PRECISION' AS reportType,
            pr.name AS itemName,
            pr.created_at AS measuredAt,
            ROUND(pr.analysis_data->>'$.romInfo.measuredAngle', 1) AS measuredAngle,
            pr.score AS score,
            pr.level AS level
          FROM precision_reports pr
          WHERE pr.trainer_id = ?
            AND pr.user_id = ?
            AND pr.created_at >= ?
            AND pr.created_at < ?
            AND pr.deleted_at IS NULL
            AND pr.type NOT IN ('BODY','SPINAL_ALIGNMENT_TEST','OVERHEAD_SQUAT_TEST','BALANCE_TEST')
          ORDER BY pr.score ${orderDir}
        `,
        [trainerId, memberId, startOfMonth, nextMonth],
      );

      return {
        memberName: memberRow.memberName,
        trainerId,
        records: rows.map((row: Record<string, string | null>) => ({
          reportId: row.reportId,
          reportType: row.reportType,
          itemName: row.itemName || '',
          measuredAt: row.measuredAt,
          value: Number(row.score) || 0,
          measuredAngle: row.measuredAngle !== null ? Number(row.measuredAngle) : null,
          score: Number(row.score) || 0,
          level: row.level || '',
        })),
      };
    }

    const scoreColMap: Record<string, string> = {
      neck: 'br.neck_score',
      pelvis: 'br.pelvis_asymmetry_score',
      shoulder: 'br.shoulder_asymmetry_score',
    };
    const labelMap: Record<string, string> = {
      neck: '거북목',
      pelvis: '골반 비대칭',
      shoulder: '어깨 비대칭',
    };
    const scoreCol = scoreColMap[type];
    const orderDir = direction === 'top' ? 'ASC' : 'DESC';

    const rows = await this.dataSource.query(
      `
        SELECT
          br.id AS reportId,
          'BODY' AS reportType,
          '${labelMap[type]}' AS itemName,
          br.created_at AS measuredAt,
          ${scoreCol} AS value
        FROM body_reports br
        WHERE br.trainer_id = ?
          AND br.user_id = ?
          AND br.created_at >= ?
          AND br.created_at < ?
          AND br.deleted_at IS NULL
        ORDER BY ${scoreCol} ${orderDir}
      `,
      [trainerId, memberId, startOfMonth, nextMonth],
    );

    return {
      memberName: memberRow.memberName,
      trainerId,
      records: rows.map((row: Record<string, string | null>) => ({
        reportId: row.reportId,
        reportType: row.reportType,
        itemName: row.itemName,
        measuredAt: row.measuredAt,
        value: row.value !== null ? Number(row.value) : null,
      })),
    };
  }

  private async resolveContext(ownerId: string): Promise<CenterContext> {
    const center = await this.centerRepo.findOne({ where: { ownerId } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }

    const trainers = await this.centerTrainerRepo.createQueryBuilder('ct')
      .where('ct.center_id = :centerId', { centerId: center.id })
      .andWhere('ct.deleted_at IS NULL')
      .andWhere('ct.status = :status', { status: CenterTrainerStatus.WORKING })
      .andWhere('ct.deactivated_at IS NULL')
      .select('ct.trainer_id', 'trainerId')
      .getRawMany<{ trainerId: string }>();

    return {
      centerId: center.id,
      trainerIds: trainers.map((trainer) => trainer.trainerId),
    };
  }

  private toWholeGb(bytes: number): number {
    const gb = bytes / (1024 ** 3);
    return Math.round(gb);
  }

  private emptyMemberManagement() {
    return {
      lesson: {
        attendanceRate: 0,
        attendanceCount: 0,
        absenceRate: 0,
        absenceCount: 0,
      },
      retentionRisk: {
        lowLessonFrequency: [],
        lowMeasurementFrequency: [],
        dormantCount: 0,
        dormantMembers: [],
      },
      upcomingSchedules: [],
    };
  }

  private emptyPerformance() {
    return {
      turtleNeck: { top3: [], bottom3: [] },
      pelvisAsymmetry: { top3: [], bottom3: [] },
      shoulderAsymmetry: { top3: [], bottom3: [] },
      rom: { bottom3: [] },
    };
  }

  private emptySalesFunnel() {
    return {
      monthlyTrends: [],
      currentMonth: {
        totalConsultations: 0,
        conversionRate: 0,
        trial: 0,
        regNew: 0,
        regRenew: 0,
        noSale: 0,
        trialRate: 0,
        regNewRate: 0,
        regRenewRate: 0,
        noSaleRate: 0,
      },
      monthlyAppSignups: [],
      currentMonthAppSignups: 0,
      totalRegisteredMembers: 0,
      trialMemberCount: 0,
      trialConversionCount: 0,
      trialConversionRate: 0,
      afterConsultNoPayRate: 0,
      afterConsultNoRegCount: 0,
    };
  }
}
