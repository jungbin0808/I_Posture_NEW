import { Controller, Get, Param, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CenterDashboardService } from './center-dashboard.service';
import { CenterDashboardAggregateService } from './center-dashboard-aggregate.service';
import { CenterDashboardResponseDto } from './dto/center-dashboard-response.dto';
import { CenterDashboardStorageResponseDto } from './dto/center-dashboard-storage-response.dto';

@ApiTags('Center Dashboard')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/dashboard')
export class CenterDashboardController {
  constructor(
    private readonly centerDashboardService: CenterDashboardService,
    private readonly centerDashboardAggregateService: CenterDashboardAggregateService,
  ) {}

  @ApiOperation({ summary: '센터 대시보드 (트레이너 역량 히트맵 + 경보/관리 알림)' })
  @Get()
  async getDashboard(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<CenterDashboardResponseDto>> {
    const data = await this.centerDashboardService.getDashboard(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 회원 운영 관리 (트레이너 대시보드 집계)' })
  @Get('member-management')
  async getMemberManagement(@Req() req: { user: UserEntity }) {
    const data = await this.centerDashboardAggregateService.getMemberManagement(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 성과 증명 (트레이너 대시보드 집계)' })
  @Get('performance')
  async getPerformance(@Req() req: { user: UserEntity }) {
    const data = await this.centerDashboardAggregateService.getPerformance(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 성과 증명 상세 — 회원별 기록 (최근 3개월)' })
  @Get('performance/records/:memberId/:type/:direction')
  async getPerformanceRecordsByMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('type') type: string,
    @Param('direction') direction: string,
  ) {
    const validTypes = ['neck', 'pelvis', 'shoulder', 'rom'] as const;
    const validDirs = ['top', 'bottom'] as const;
    const resolvedType = validTypes.includes(type as typeof validTypes[number])
      ? (type as typeof validTypes[number])
      : 'rom';
    const resolvedDir = validDirs.includes(direction as typeof validDirs[number])
      ? (direction as typeof validDirs[number])
      : 'bottom';

    const data = await this.centerDashboardAggregateService.getPerformanceRecordsByMember(
      req.user.id,
      memberId,
      resolvedType,
      resolvedDir,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 데이터 용량 (트레이너 대시보드 + 센터 전용 breakdown)' })
  @Get('storage')
  async getStorage(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<CenterDashboardStorageResponseDto>> {
    const data = await this.centerDashboardAggregateService.getStorage(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 등록/매출 퍼널 (트레이너 대시보드 집계)' })
  @Get('sales-funnel')
  async getSalesFunnel(@Req() req: { user: UserEntity }) {
    const data = await this.centerDashboardAggregateService.getSalesFunnel(req.user.id);
    return SuccessResponse(data);
  }
}
