import {
  buildAttributedTrainerIdExpr,
  buildSameOwnerAcrossTransferCondition,
  buildTransferAwareTrainerIdsCondition,
} from '../../../consultation-log/helpers/trainer-transfer-attribution.helper';

export interface MemberMonthStatusMonthlyRow {
  trainerId: string;
  month: string;
  total: number;
  trial: number;
  regNew: number;
  regRenew: number;
  noSale: number;
}

export interface MemberMonthStatusTotals {
  total: number;
  trial: number;
  regNew: number;
  regRenew: number;
  noSale: number;
}

export interface TrialConversionTotals {
  trialMemberCount: number;
  trialConversionCount: number;
}

export interface TrialConversionByTrainerRow extends TrialConversionTotals {
  trainerId: string;
}

export interface CurrentMonthAlertRow {
  trainerId: string;
  total: number;
  noSale: number;
}

const KST_OFFSET_MS = 9 * 60 * 60 * 1000;

/**
 * 히트맵은 트레이너 여러 명을 한 번에 GROUP BY 해야 해서, 트레이너 상세가 쓰는
 * buildTransferAwareTrainerIdsCondition(단순 필터)만으로는 부족하다 — 필터를 통과한
 * 레코드라도 GROUP BY cl.trainer_id를 그대로 쓰면, "이관 전에 A가 작성했지만 현재
 * trainer_id 컬럼은 B로 바뀐" 레코드가 B의 실적으로 잘못 집계된다.
 * 그래서 "실제로 귀속되어야 할 트레이너 ID"를 계산하는 buildAttributedTrainerIdExpr로
 * GROUP BY 한다. buildTransferAwareTrainerIdsCondition은 1차 후보 필터로만 쓰고,
 * 최종 귀속 결과가 trainerIds 안에 있는지는 호출부에서 HAVING(또는 conversions/
 * trial_members의 재필터)으로 한 번 더 확인한다.
 */
const ATTRIBUTED_TRAINER_ID_EXPR = buildAttributedTrainerIdExpr('cl', 'consult_at');
const TRANSFER_RELEVANT_FILTER = buildTransferAwareTrainerIdsCondition('cl', 'consult_at');
const SAME_OWNER_ACROSS_TRANSFER_CONDITION = buildSameOwnerAcrossTransferCondition('t', 'f');

/** KST 기준 당월 [시작, 다음달) 구간 */
export function resolveKstCurrentMonthRange(): {
  startOfMonth: Date;
  nextMonth: Date;
  yearMonth: string;
} {
  const nowKst = new Date(Date.now() + KST_OFFSET_MS);
  const year = nowKst.getUTCFullYear();
  const monthIndex = nowKst.getUTCMonth();
  const yearMonth = `${year}-${String(monthIndex + 1).padStart(2, '0')}`;

  return {
    startOfMonth: new Date(Date.UTC(year, monthIndex, 1) - KST_OFFSET_MS),
    nextMonth: new Date(Date.UTC(year, monthIndex + 1, 1) - KST_OFFSET_MS),
    yearMonth,
  };
}

/**
 * 당월 미등록 경보용 — KST 당월 구간 내 트레킹 노트 건수 집계.
 * 이관 보정(2026-09-17 적용): 파라미터 순서 [startOfMonth, nextMonth, trainerIds, trainerIds, trainerIds]
 */
export const CURRENT_MONTH_NO_SALE_ALERTS_SQL = `
  SELECT
    ${ATTRIBUTED_TRAINER_ID_EXPR} AS trainerId,
    COUNT(*) AS total,
    SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
  FROM consultation_logs cl
  WHERE cl.consult_at >= ?
    AND cl.consult_at < ?
    AND cl.deleted_at IS NULL
    AND ${TRANSFER_RELEVANT_FILTER}
  GROUP BY trainerId
  HAVING trainerId IN (?)
`;

/**
 * 상담일지(트래킹 노트) 건수 기준 월별 집계 — 트레이너 상세·대시보드와 동일하게
 * 회원 단위(명수)로 중복 제거하지 않고, 상담 건수 그대로 집계한다.
 * 6개월 히트맵: 각 달 분자·분모를 합산한 뒤 비율 계산.
 * 이관 보정(2026-09-17 적용): 파라미터 순서 [sixMonthsAgo, trainerIds, trainerIds, trainerIds]
 */
export const MEMBER_MONTH_STATUS_MONTHLY_SQL = `
  SELECT
    ${ATTRIBUTED_TRAINER_ID_EXPR} AS trainerId,
    DATE_FORMAT(cl.consult_at, '%Y-%m') AS month,
    COUNT(*) AS total,
    SUM(CASE WHEN cl.result_status = 'TRIAL' THEN 1 ELSE 0 END) AS trial,
    SUM(CASE WHEN cl.result_status = 'REG_NEW' THEN 1 ELSE 0 END) AS regNew,
    SUM(CASE WHEN cl.result_status = 'REG_RENEW' THEN 1 ELSE 0 END) AS regRenew,
    SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
  FROM consultation_logs cl
  WHERE cl.consult_at >= ?
    AND cl.deleted_at IS NULL
    AND ${TRANSFER_RELEVANT_FILTER}
  GROUP BY trainerId, month
  HAVING trainerId IN (?)
  ORDER BY trainerId ASC, month ASC
`;

/**
 * 체험수업 등록 전환율 — 6개월 전체를 하나의 기간으로 놓고 계산 (월별로 쪼개서 합산하지 않음).
 * 분자: 6개월 내 신규·재등록 전환 인원(체험이 그보다 먼저인 회원만 인정).
 * 분모: 6개월 내 체험 인원 ∪ 6개월 내 전환 인원(겹치면 1명으로만 셈).
 *
 * 2026-09-21 수정: 원래는 (trainer, month, user) 단위로 그룹핑해서 "월별 분모/분자를
 * 구한 뒤 6개월치를 sum"하는 방식이었는데, 체험과 전환이 서로 다른 달에 걸친 회원은
 * 체험한 달에 한 번, 전환한 달에 한 번 — 분모에 중복으로 잡히는 버그가 있었다
 * (예: 5월 체험 → 8월 전환 1명이 분모 2로 잡혀 전환율이 실제보다 낮게 나옴).
 * month로 그룹핑하지 않고 트레이너 단위로만 묶어서 이 문제를 없앴다.
 *
 * 이관 보정(트레이너 상세와 동일한 원리, trial-conversion-metrics.helper.ts 참고):
 * attributed_logs에서 한 번 귀속을 계산해두고, 그 위에서 체험→전환 순서를 판정한다.
 * 이관 이력이 없는 회원은 기존처럼 트레이너 무관하게 인정하고, 이관 이력이 있는
 * 회원만 귀속 트레이너 일치를 요구한다(buildSameOwnerAcrossTransferCondition 참고 —
 * 안 그러면 이관 전 체험이 이관 후 트레이너의 전환 실적으로 잘못 집계된다).
 * conversions/trial_members가 각자 trainerIds로 재필터링하므로 최종 결과는 항상 대상
 * 목록 안에 있다(HAVING 불필요). 파라미터 순서: [sixMonthsAgo, trainerIds, trainerIds, trainerIds, trainerIds]
 * (attributed_logs 안의 TRANSFER_RELEVANT_FILTER가 trainerIds를 2번 더 소비함)
 */
export const TRIAL_CONVERSION_SIX_MONTH_SQL = `
  WITH attributed_logs AS (
    SELECT
      cl.user_id,
      cl.result_status,
      cl.consult_at,
      ${ATTRIBUTED_TRAINER_ID_EXPR} AS trainer_id
    FROM consultation_logs cl
    WHERE cl.deleted_at IS NULL
      AND cl.consult_at >= ?
      AND ${TRANSFER_RELEVANT_FILTER}
  ),
  conversions AS (
    SELECT DISTINCT
      f.trainer_id,
      f.user_id
    FROM attributed_logs f
    WHERE f.trainer_id IN (?)
      AND f.result_status IN ('REG_NEW', 'REG_RENEW')
      AND EXISTS (
        SELECT 1
        FROM attributed_logs t
        WHERE t.user_id = f.user_id
          AND t.result_status = 'TRIAL'
          AND t.consult_at < f.consult_at
          AND ${SAME_OWNER_ACROSS_TRANSFER_CONDITION}
      )
  ),
  trial_members AS (
    SELECT DISTINCT
      t.trainer_id,
      t.user_id
    FROM attributed_logs t
    WHERE t.trainer_id IN (?)
      AND t.result_status = 'TRIAL'
  ),
  denominator_pool AS (
    SELECT trainer_id, user_id FROM trial_members
    UNION
    SELECT trainer_id, user_id FROM conversions
  )
  SELECT
    p.trainer_id AS trainerId,
    COUNT(DISTINCT p.user_id) AS trialMemberCount,
    COUNT(DISTINCT c.user_id) AS trialConversionCount
  FROM denominator_pool p
  LEFT JOIN conversions c
    ON c.trainer_id = p.trainer_id
    AND c.user_id = p.user_id
  GROUP BY p.trainer_id
  ORDER BY p.trainer_id ASC
`;

export function mapMemberMonthStatusRow(row: Record<string, string>): MemberMonthStatusMonthlyRow {
  return {
    trainerId: row.trainerId,
    month: row.month,
    total: Number(row.total) || 0,
    trial: Number(row.trial) || 0,
    regNew: Number(row.regNew) || 0,
    regRenew: Number(row.regRenew) || 0,
    noSale: Number(row.noSale) || 0,
  };
}

export function mapCurrentMonthAlertRow(row: Record<string, string>): CurrentMonthAlertRow {
  return {
    trainerId: row.trainerId,
    total: Number(row.total) || 0,
    noSale: Number(row.noSale) || 0,
  };
}

export function mapTrialConversionRow(row: Record<string, string>): TrialConversionByTrainerRow {
  return {
    trainerId: row.trainerId,
    trialMemberCount: Number(row.trialMemberCount) || 0,
    trialConversionCount: Number(row.trialConversionCount) || 0,
  };
}

export function emptyMemberMonthStatusTotals(): MemberMonthStatusTotals {
  return {
    total: 0,
    trial: 0,
    regNew: 0,
    regRenew: 0,
    noSale: 0,
  };
}

export function sumMemberMonthStatusByTrainer(
  rows: MemberMonthStatusMonthlyRow[],
  trainerId: string,
): MemberMonthStatusTotals {
  return rows
    .filter((row) => row.trainerId === trainerId)
    .reduce<MemberMonthStatusTotals>(
      (acc, row) => ({
        total: acc.total + row.total,
        trial: acc.trial + row.trial,
        regNew: acc.regNew + row.regNew,
        regRenew: acc.regRenew + row.regRenew,
        noSale: acc.noSale + row.noSale,
      }),
      emptyMemberMonthStatusTotals(),
    );
}

export function findMemberMonthStatusForMonth(
  rows: MemberMonthStatusMonthlyRow[],
  trainerId: string,
  month: string,
): MemberMonthStatusTotals {
  const row = rows.find((item) => item.trainerId === trainerId && item.month === month);
  if (!row) {
    return emptyMemberMonthStatusTotals();
  }

  return {
    total: row.total,
    trial: row.trial,
    regNew: row.regNew,
    regRenew: row.regRenew,
    noSale: row.noSale,
  };
}

/** 트레이너별로 이미 1행씩 집계된 결과에서 값을 찾아온다 (해당 트레이너에 체험/전환 기록이 없으면 0). */
export function findTrialConversionByTrainer(
  rows: TrialConversionByTrainerRow[],
  trainerId: string,
): TrialConversionTotals {
  const row = rows.find((item) => item.trainerId === trainerId);
  return {
    trialMemberCount: row?.trialMemberCount ?? 0,
    trialConversionCount: row?.trialConversionCount ?? 0,
  };
}
