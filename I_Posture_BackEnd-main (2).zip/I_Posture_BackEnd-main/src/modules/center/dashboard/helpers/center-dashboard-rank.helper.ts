import { CenterDashboardTier } from '../dto/center-dashboard-tier.enum';

export function assignCompetitionRanks<T>(
  items: T[],
  getValue: (item: T) => number,
  higherIsBetter: boolean,
): Map<T, number> {
  const sorted = [...items].sort((left, right) => {
    const leftValue = getValue(left);
    const rightValue = getValue(right);

    if (leftValue === rightValue) {
      return 0;
    }

    return higherIsBetter
      ? rightValue - leftValue
      : leftValue - rightValue;
  });

  const ranks = new Map<T, number>();
  let rank = 0;
  let previousValue: number | null = null;

  sorted.forEach((item, index) => {
    const value = getValue(item);
    if (previousValue === null || value !== previousValue) {
      rank = index + 1;
      previousValue = value;
    }

    ranks.set(item, rank);
  });

  return ranks;
}

export function resolveCenterDashboardTier(rank: number, total: number): CenterDashboardTier {
  if (total <= 1 || rank === 1) {
    return CenterDashboardTier.LEADING;
  }

  if (rank === total) {
    return CenterDashboardTier.TRAILING;
  }

  return CenterDashboardTier.MIDDLE;
}

export function toCenterDashboardTierLabel(tier: CenterDashboardTier): string {
  const labels: Record<CenterDashboardTier, string> = {
    [CenterDashboardTier.LEADING]: '선두권',
    [CenterDashboardTier.MIDDLE]: '중위권',
    [CenterDashboardTier.TRAILING]: '후발권',
  };

  return labels[tier];
}

export function calcRate(numerator: number, denominator: number): number {
  if (denominator <= 0) {
    return 0;
  }

  return Math.round((numerator / denominator) * 100);
}
