import { Module } from '@nestjs/common';
import { CenterAuthModule } from './auth/center-auth.module';
import { CenterProfileModule } from './profile/center-profile.module';
import { CenterFaqModule } from './faq/center-faq.module';
import { CenterQnaModule } from './qna/center-qna.module';
import { CenterSubscriptionModule } from './subscription/center-subscription.module';
import { CenterSequenceModule } from './sequence/center-sequence.module';
import { CenterScheduleModule } from './schedule/center-schedule.module';
import { CenterTransferModule } from './transfer/center-transfer.module';
import { CenterCapacityModule } from './capacity/center-capacity.module';
import { CenterTrainerModule } from './trainer/center-trainer.module';
import { CenterDashboardModule } from './dashboard/center-dashboard.module';
import { CenterNotificationModule } from './notification/center-notification.module';

/**
 * 센터 웹 전용 모듈
 *
 * - auth/          인증
 * - profile/       센터 정보
 * - faq/           FAQ
 * - qna/           질의응답
 * - subscription/  이용권·결제
 * - sequence/      시퀀스·시퀀스 그룹
 * - schedule/      일정·일정 그룹
 * - transfer/      이관 관리
 * - capacity/      용량
 * - trainer/       트레이너 관리
 * - dashboard/     센터 대시보드
 * - notification/  알림 목록
 */
@Module({
  imports: [
    CenterAuthModule,
    CenterProfileModule,
    CenterFaqModule,
    CenterQnaModule,
    CenterSubscriptionModule,
    CenterSequenceModule,
    CenterScheduleModule,
    CenterTransferModule,
    CenterCapacityModule,
    CenterTrainerModule,
    CenterDashboardModule,
    CenterNotificationModule,
  ],
})
export class CenterModule {}
