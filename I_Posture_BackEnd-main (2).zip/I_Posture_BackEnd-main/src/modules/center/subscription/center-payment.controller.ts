import { Body, Controller, Delete, Get, Param, Post, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { KpnPaymentService } from '../../kpn-payment/kpn-payment.service';
import {
  BillKeyRegistrationStatusDto,
  BillKeyResponseDto,
  BillRegisterUrlResponseDto,
  GetBillRegisterUrlDto,
} from '../../kpn-payment/dto/kpn-payment.dto';

@ApiTags('Center Payment')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/payment')
export class CenterPaymentController {
  constructor(private readonly kpnPaymentService: KpnPaymentService) {}

  @ApiOperation({ summary: '카드 등록 URL 발급 (센터 웹)' })
  @Post('bill-key/register-url')
  async getBillRegisterUrl(
    @Req() req: { user: UserEntity },
    @Body() dto: GetBillRegisterUrlDto,
  ): Promise<ISuccessResponse<BillRegisterUrlResponseDto>> {
    const result = await this.kpnPaymentService.getBillRegisterUrl(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '카드 등록 완료 여부 폴링 (센터 웹)' })
  @Get('bill-key/registration/:registrationId/status')
  async getRegistrationStatus(
    @Req() req: { user: UserEntity },
    @Param('registrationId') registrationId: string,
  ): Promise<ISuccessResponse<BillKeyRegistrationStatusDto>> {
    const result = await this.kpnPaymentService.getRegistrationStatus(registrationId, req.user.id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '등록된 카드 목록 (센터 웹)' })
  @Get('bill-keys')
  async getBillKeys(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<BillKeyResponseDto[]>> {
    const result = await this.kpnPaymentService.getBillKeys(req.user.id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '등록된 카드 삭제 (센터 웹)' })
  @Delete(['bill-keys/:id', 'bill-key/:id'])
  async deleteBillKey(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    await this.kpnPaymentService.deleteBillKey(req.user.id, id);
    return SuccessResponse({ success: true });
  }

  @ApiOperation({ summary: '카드 교체 URL 발급 (센터 웹)' })
  @Post('bill-key/replace-url')
  async replaceBillKey(
    @Req() req: { user: UserEntity },
    @Body() dto: GetBillRegisterUrlDto,
  ): Promise<ISuccessResponse<BillRegisterUrlResponseDto>> {
    const result = await this.kpnPaymentService.replaceBillKey(req.user.id, dto);
    return SuccessResponse(result);
  }
}
