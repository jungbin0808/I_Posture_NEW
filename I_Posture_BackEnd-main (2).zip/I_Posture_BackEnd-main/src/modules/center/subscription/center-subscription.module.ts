import { Module } from '@nestjs/common';
import { CenterCommonModule } from '../common/center-common.module';
import { SubscriptionModule } from '../../subscription/subscription.module';
import { KpnPaymentModule } from '../../kpn-payment/kpn-payment.module';
import { CenterSubscriptionController } from './center-subscription.controller';
import { CenterPaymentController } from './center-payment.controller';

@Module({
  imports: [CenterCommonModule, SubscriptionModule, KpnPaymentModule],
  controllers: [CenterSubscriptionController, CenterPaymentController],
})
export class CenterSubscriptionModule {}
