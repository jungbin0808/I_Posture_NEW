import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { SubscriptionService } from '../../subscription/subscription.service';
import { FindSubscriptionPlanDto } from '../../subscription/dto/find-subscription-plan.dto';
import { SubscriptionPlanItemResponseDto } from '../../subscription/dto/subscription-plan-item-response.dto';
import { ProcessPaymentDto } from '../../subscription/dto/process-payment.dto';
import { StartTrialDto } from '../../subscription/dto/start-trial.dto';
import { PaymentEntity } from '../../../database/entities/payment.entity';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';

@ApiTags('Center Subscription')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/subscriptions')
export class CenterSubscriptionController {
  constructor(private readonly subscriptionService: SubscriptionService) {}

  @ApiOperation({ summary: '이용권 상품 목록 (센터 웹)' })
  @Get('plans')
  async findAllPlans(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindSubscriptionPlanDto,
  ): Promise<IPageResponse<SubscriptionPlanItemResponseDto>> {
    const pageData = await this.subscriptionService.findAllPlans(req.user, findDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '이용권 결제 (센터 웹)' })
  @Post('payment')
  async processPayment(
    @Req() req: { user: UserEntity },
    @Body() paymentDto: ProcessPaymentDto,
  ): Promise<ISuccessResponse<{ payment: PaymentEntity | null; subscription: SubscriptionEntity }>> {
    const result = await this.subscriptionService.processPayment(req.user, paymentDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '이용권 해지 예약 (센터 웹)' })
  @Post('cancel')
  async cancelSubscription(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const result = await this.subscriptionService.cancelSubscription(req.user.id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '무료체험 시작 (센터 오너 전용, 14일, 1회만)' })
  @Post('trial')
  async startTrial(
    @Req() req: { user: UserEntity },
    @Body() body: StartTrialDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const result = await this.subscriptionService.startTrial(req.user, body.planId);
    return SuccessResponse(result);
  }
}
