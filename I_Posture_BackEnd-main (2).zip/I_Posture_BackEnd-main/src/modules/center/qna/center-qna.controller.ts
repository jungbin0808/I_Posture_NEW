import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { QnaService } from '../../qna/qna.service';
import { QnaMyStatsResponseDto } from '../../qna/dto/qna-my-stats-response.dto';
import { FindQnaListDto } from '../../qna/dto/find-qna-list.dto';
import { QnaListItemDto } from '../../qna/dto/qna-list-item.dto';
import { QnaDetailResponseDto } from '../../qna/dto/qna-detail-response.dto';
import { CreateQnaQuestionDto } from '../../qna/dto/create-qna-question.dto';
import { UpdateQnaQuestionDto } from '../../qna/dto/update-qna-question.dto';
import { CreateQnaAnswerDto } from '../../qna/dto/create-qna-answer.dto';
import { UpdateQnaAnswerDto } from '../../qna/dto/update-qna-answer.dto';
import { CreateQnaReportDto } from '../../qna/dto/create-qna-report.dto';
import { QnaQuestionEntity } from '../../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../../database/entities/qna-answer.entity';
import { QnaReportEntity } from '../../../database/entities/qna-report.entity';
import { AcceptQnaAnswerDto } from '../../qna/dto/accept-qna-answer.dto';
import { DeleteQnaQuestionsDto } from '../../qna/dto/delete-qna-questions.dto';

@ApiTags('Center Q&A')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/qna')
export class CenterQnaController {
  constructor(private readonly qnaService: QnaService) {}

  @ApiOperation({ summary: '나의 Q&A 활동 통계 (센터 웹)' })
  @Get('my-stats')
  async getMyStats(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<QnaMyStatsResponseDto>> {
    const stats = await this.qnaService.getMyStats(req.user);
    return SuccessResponse(stats);
  }

  @ApiOperation({ summary: 'Q&A 목록 (센터 웹)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindQnaListDto,
  ): Promise<IPageResponse<QnaListItemDto>> {
    const pageData = await this.qnaService.findAll(req.user, findDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Q&A 상세 (센터 웹)' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<QnaDetailResponseDto>> {
    const question = await this.qnaService.findOne(id);
    return SuccessResponse(question);
  }

  @ApiOperation({ summary: '질문 등록 (센터 웹)' })
  @Post()
  async createQuestion(
    @Req() req: { user: UserEntity },
    @Body() createDto: CreateQnaQuestionDto,
  ): Promise<ISuccessResponse<QnaQuestionEntity>> {
    const question = await this.qnaService.createQuestion(req.user, createDto);
    return SuccessResponse(question);
  }

  @ApiOperation({ summary: '질문 수정 (센터 웹)' })
  @Put(':id')
  async updateQuestion(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() updateDto: UpdateQnaQuestionDto,
  ): Promise<ISuccessResponse<QnaQuestionEntity>> {
    const question = await this.qnaService.updateQuestion(req.user.id, id, updateDto);
    return SuccessResponse(question);
  }

  @ApiOperation({ summary: '질문 일괄 삭제 (센터 웹)' })
  @Delete()
  async deleteQuestions(
    @Req() req: { user: UserEntity },
    @Body() deleteDto: DeleteQnaQuestionsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.qnaService.deleteQuestions(req.user.id, deleteDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '답변 등록 (센터 웹)' })
  @Post(':id/answers')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        content: { type: 'string' },
        files: { type: 'array', items: { type: 'string', format: 'binary' } },
      },
    },
  })
  async createAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') questionId: string,
    @Body() createDto: CreateQnaAnswerDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.createAnswer(req.user, questionId, createDto, files);
    return SuccessResponse(answer);
  }

  @ApiOperation({ summary: '답변 채택 (센터 웹)' })
  @Post('answers/:id/accept')
  async acceptAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') answerId: string,
    @Body() acceptDto: AcceptQnaAnswerDto,
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.acceptAnswer(req.user.id, answerId, acceptDto);
    return SuccessResponse(answer);
  }

  @ApiOperation({ summary: '답변 수정 (센터 웹)' })
  @Put('answers/:id')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        content: { type: 'string' },
        keepFileIds: { type: 'array', items: { type: 'string' } },
        files: { type: 'array', items: { type: 'string', format: 'binary' } },
      },
    },
  })
  async updateAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() updateDto: UpdateQnaAnswerDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.updateAnswer(req.user.id, id, updateDto, files);
    return SuccessResponse(answer);
  }

  @ApiOperation({ summary: '답변 삭제 (센터 웹)' })
  @Delete('answers/:id')
  async deleteAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.qnaService.deleteAnswer(req.user.id, id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '질문/답변 신고 (센터 웹)' })
  @Post('report')
  async report(
    @Req() req: { user: UserEntity },
    @Body() createDto: CreateQnaReportDto,
  ): Promise<ISuccessResponse<QnaReportEntity>> {
    const report = await this.qnaService.report(req.user, createDto);
    return SuccessResponse(report);
  }
}
