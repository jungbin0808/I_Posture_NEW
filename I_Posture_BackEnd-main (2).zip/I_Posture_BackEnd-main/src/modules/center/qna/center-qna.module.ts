import { Module } from '@nestjs/common';
import { CenterCommonModule } from '../common/center-common.module';
import { QnaModule } from '../../qna/qna.module';
import { CenterQnaController } from './center-qna.controller';

@Module({
  imports: [CenterCommonModule, QnaModule],
  controllers: [CenterQnaController],
})
export class CenterQnaModule {}
