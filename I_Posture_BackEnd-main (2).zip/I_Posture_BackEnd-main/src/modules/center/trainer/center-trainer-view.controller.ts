import {
  Controller,
  Delete,
  Get,
  Headers,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
  Body,
  UploadedFile,
  UploadedFiles,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor, FilesInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CenterTrainerViewService } from './center-trainer-view.service';
import { FindSchedulesDto, ScheduleListItemDto, BulkCompleteDto, BulkNoshowDto, AddSchedulesToGroupDto, RemoveSchedulesFromGroupDto, CreateScheduleDto, UpdateScheduleDto } from '../../schedule/schedule.dto';
import {
  DeleteScheduleGroupsDto,
  FindScheduleGroupsDto,
} from '../../schedule-group/schedule-group.dto';
import {
  FindSequenceDto,
  FindSequenceForScheduleDto,
  SequenceForScheduleResponseDto,
  SequenceListItemDto,
  UpdateSequenceStatusDto,
  AssignSequenceToScheduleDto,
} from '../../sequence/sequence.dto';
import {
  AddSequencesToGroupDto,
  DeleteSequenceGroupsDto,
  FindSequenceGroupsDto,
  RemoveSequencesFromGroupDto,
} from '../../sequence-group/sequence-group.dto';
import { ExerciseCategoryEntity } from '../../../database/entities/exercise-category.entity';
import { ExerciseEntity } from '../../../database/entities/exercise.entity';
import { SequenceGroupEntity } from '../../../database/entities/sequence-group.entity';
import { FindQnaListDto } from '../../qna/dto/find-qna-list.dto';
import { QnaListItemDto } from '../../qna/dto/qna-list-item.dto';
import { QnaMyStatsResponseDto } from '../../qna/dto/qna-my-stats-response.dto';
import { QnaDetailResponseDto } from '../../qna/dto/qna-detail-response.dto';
import { FindMyMembersDto } from '../../user/dto/find-my-members.dto';
import { MyMembersResponseDto } from '../../user/dto/my-members-response.dto';
import { UserDetailResponseDto } from '../../user/dto/user-detail-response.dto';
import { RegisterMemberDto } from '../../user/dto/register-member.dto';
import { FindBodyReportDto } from '../../body-report/dto/find-body-report.dto';
import { DeleteBodyReportsDto } from '../../body-report/dto/delete-body-reports.dto';
import { BodyReportResponseDto, BodyReportDetailResponseDto } from '../../body-report/dto/body-report-response.dto';
import { FindPrecisionReportDto } from '../../precision-report/dto/find-precision-report.dto';
import { DeletePrecisionReportsDto } from '../../precision-report/dto/delete-precision-reports.dto';
import {
  PrecisionReportResponseDto,
  PrecisionReportDetailResponseDto,
} from '../../precision-report/dto/precision-report-response.dto';
import { FindMotionAnalysisDto } from '../../motion-analysis/dto/find-motion-analysis.dto';
import { DeleteMotionAnalysesDto } from '../../motion-analysis/dto/delete-motion-analyses.dto';
import {
  MotionAnalysisResponseDto,
  MotionAnalysisDetailResponseDto,
} from '../../motion-analysis/dto/motion-analysis-response.dto';
import { FindInbodyDataDto } from '../../inbody/dto/find-inbody-data.dto';
import { DeleteInbodyDataDto } from '../../inbody/dto/delete-inbody-data.dto';
import { CreateInbodyDataDto } from '../../inbody/dto/create-inbody-data.dto';
import { UpdateInbodyDataDto } from '../../inbody/dto/update-inbody-data.dto';
import { InbodyDataResponseDto, InbodyDataDetailResponseDto } from '../../inbody/dto/inbody-data-response.dto';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { FindConsultationLogDto } from '../../consultation-log/dto/find-consultation-log.dto';
import { CreateConsultationLogDto } from '../../consultation-log/dto/create-consultation-log.dto';
import { UpdateConsultationLogDto } from '../../consultation-log/dto/update-consultation-log.dto';
import { DeleteConsultationLogsDto } from '../../consultation-log/dto/delete-consultation-logs.dto';
import { ConsultationLogEntity } from '../../../database/entities/consultation-log.entity';
import { ConsultationLogResponseDto } from '../../consultation-log/dto/consultation-log-response.dto';
import { ConsultationLogDetailResponseDto } from '../../consultation-log/dto/consultation-log-detail-response.dto';
import { FindWorkoutLogDto } from '../../workout-log/dto/find-workout-log.dto';
import { DeleteWorkoutLogsDto } from '../../workout-log/dto/delete-workout-logs.dto';
import { CreateWorkoutLogDto } from '../../workout-log/dto/create-workout-log.dto';
import { UpdateWorkoutLogDto } from '../../workout-log/dto/update-workout-log.dto';
import { WorkoutLogResponseDto } from '../../workout-log/dto/workout-log-response.dto';
import { WorkoutLogDetailResponseDto } from '../../workout-log/dto/workout-log-detail-response.dto';
import { WorkoutLogEntity } from '../../../database/entities/workout-log.entity';
import { FindFoodLogDto } from '../../food-log/dto/find-food-log.dto';
import { UpdateFoodLogCommentDto } from '../../food-log/dto/update-food-log-comment.dto';
import { FoodLogResponseDto } from '../../food-log/dto/food-log-response.dto';
import { FoodLogDetailResponseDto } from '../../food-log/dto/food-log-detail-response.dto';
import { FindReportComparisonDto } from '../../report-comparison/dto/find-report-comparison.dto';
import { CreateReportComparisonDto } from '../../report-comparison/dto/create-report-comparison.dto';
import {
  ReportComparisonResponseDto,
  ReportComparisonDetailResponseDto,
} from '../../report-comparison/dto/report-comparison-response.dto';
import { RomComparisonDetailResponseDto } from '../../report-comparison/dto/rom-comparison-response.dto';
import { FindMemberSubscriptionsDto } from '../../subscription/dto/find-member-subscriptions.dto';
import { MemberSubscriptionResponseDto } from '../../subscription/dto/member-subscription-response.dto';
import { GrantSubscriptionDto } from '../../subscription/dto/grant-subscription.dto';
import { UpdateCenterTrainerMemberSubscriptionStatusDto } from './dto/update-center-trainer-member-subscription-status.dto';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { ReportComparisonEntity } from '../../../database/entities/report-comparison.entity';
import { BulkCenterTrainerMemberIdsDto } from './dto/bulk-center-trainer-member-ids.dto';
import { RecommendedPrecisionPartsResponseDto } from '../../measurement-report/dto/recommended-precision-parts.dto';
import { BodyMeasurementReportResponseDto } from '../../measurement-report/dto/measurement-report-response.dto';
import { resolveReportDisplayLanguage } from '../../../common/helpers/resolve-report-display-language.helper';
import { SpineAlignmentReportResponseDto } from '../../measurement-report/dto/spine-alignment-report-response.dto';
import { BalanceSenseReportResponseDto } from '../../measurement-report/dto/balance-sense-report-response.dto';
import { JointRomReportResponseDto } from '../../measurement-report/dto/joint-rom-report-response.dto';
import { FullBodyFunctionReportResponseDto } from '../../measurement-report/dto/full-body-function-report-response.dto';
import { SequenceEntity } from '../../../database/entities/sequence.entity';
import { ScheduleEntity } from '../../../database/entities/schedule.entity';
import { ScheduleGroupEntity } from '../../../database/entities/schedule-group.entity';

@ApiTags('Center Trainer View')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/trainers')
export class CenterTrainerViewController {
  constructor(private readonly centerTrainerViewService: CenterTrainerViewService) {}

  // ── 일정 ──────────────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 일정 목록 (조회 전용)' })
  @Get(':trainerId/schedules')
  async findSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindSchedulesDto,
  ): Promise<IPageResponse<ScheduleListItemDto>> {
    const data = await this.centerTrainerViewService.findTrainerSchedules(req.user.id, trainerId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 등록용 일정 목록 (조회 전용)' })
  @Get(':trainerId/schedules/for-sequence')
  async findSchedulesForSequence(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
  ): Promise<ISuccessResponse<ScheduleListItemDto[]>> {
    const data = await this.centerTrainerViewService.findTrainerSchedulesForSequence(req.user.id, trainerId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 노쇼 처리 (취소/차감)' })
  @Put(':trainerId/schedules/noshow')
  async bulkNoshowSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: BulkNoshowDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.bulkNoshowTrainerSchedules(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 완료 처리' })
  @Put(':trainerId/schedules/complete')
  async bulkCompleteSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: BulkCompleteDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.bulkCompleteTrainerSchedules(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 일정 목록 (조회 전용)' })
  @Get(':trainerId/schedules/member/:memberId')
  async findMemberSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindSchedulesDto,
  ): Promise<IPageResponse<ScheduleListItemDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberSchedules(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 일정 상세 (조회 전용)' })
  @Get(':trainerId/schedules/member/:memberId/:scheduleId')
  async findMemberScheduleDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.findTrainerMemberScheduleDetail(
      req.user.id, trainerId, memberId, scheduleId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 일정 등록' })
  @Post(':trainerId/schedules/member/:memberId')
  async createMemberSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberSchedule(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 일정 수정' })
  @Put(':trainerId/schedules/member/:memberId/:scheduleId')
  async updateMemberSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberSchedule(
      req.user.id, trainerId, memberId, scheduleId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 일정 삭제' })
  @Delete(':trainerId/schedules/member/:memberId/:scheduleId')
  async deleteMemberSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberSchedule(
      req.user.id, trainerId, memberId, scheduleId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정에서 시퀀스 삭제' })
  @Delete(':trainerId/schedules/:scheduleId/sequence')
  async removeScheduleSequence(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.removeTrainerScheduleSequence(
      req.user.id, trainerId, scheduleId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 삭제' })
  @Delete(':trainerId/schedules/:scheduleId')
  async deleteSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerSchedule(
      req.user.id, trainerId, scheduleId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 상세 (조회 전용)' })
  @Get(':trainerId/schedules/:scheduleId')
  async findScheduleDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.findTrainerScheduleDetail(
      req.user.id, trainerId, scheduleId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 등록' })
  @Post(':trainerId/schedules')
  async createSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.createTrainerSchedule(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 수정' })
  @Put(':trainerId/schedules/:scheduleId')
  async updateSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<ScheduleEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerSchedule(
      req.user.id, trainerId, scheduleId, dto,
    );
    return SuccessResponse(data);
  }

  // ── 일정 그룹 ─────────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 일정 그룹 목록' })
  @Get(':trainerId/schedule-groups')
  async findScheduleGroups(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindScheduleGroupsDto,
  ): Promise<IPageResponse<ScheduleGroupEntity>> {
    const data = await this.centerTrainerViewService.findTrainerScheduleGroups(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 그룹 삭제 (다건)' })
  @Delete(':trainerId/schedule-groups')
  async deleteScheduleGroups(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: DeleteScheduleGroupsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerScheduleGroups(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 그룹에 일정 추가' })
  @Post(':trainerId/schedule-groups/:groupId/schedules')
  async addScheduleGroupSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
    @Body() dto: AddSchedulesToGroupDto,
  ): Promise<ISuccessResponse<{ success: boolean; addedCount: number }>> {
    const data = await this.centerTrainerViewService.addTrainerScheduleGroupSchedules(
      req.user.id, trainerId, groupId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 그룹에서 일정 삭제' })
  @Delete(':trainerId/schedule-groups/:groupId/schedules')
  async removeScheduleGroupSchedules(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
    @Body() dto: RemoveSchedulesFromGroupDto,
  ): Promise<ISuccessResponse<{ success: boolean; removedCount: number }>> {
    const data = await this.centerTrainerViewService.removeTrainerScheduleGroupSchedules(
      req.user.id, trainerId, groupId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 그룹 상세' })
  @Get(':trainerId/schedule-groups/:groupId')
  async findScheduleGroupDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
  ): Promise<ISuccessResponse<ScheduleGroupEntity>> {
    const data = await this.centerTrainerViewService.findTrainerScheduleGroupDetail(
      req.user.id, trainerId, groupId,
    );
    return SuccessResponse(data);
  }

  // ── 시퀀스 ────────────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 목록 (조회 전용)' })
  @Get(':trainerId/sequences')
  async findSequences(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindSequenceDto,
  ): Promise<IPageResponse<SequenceListItemDto>> {
    const data = await this.centerTrainerViewService.findTrainerSequences(req.user.id, trainerId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정 등록용 시퀀스 목록 (조회 전용)' })
  @Get(':trainerId/sequences/for-schedule')
  async findSequencesForSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindSequenceForScheduleDto,
  ): Promise<ISuccessResponse<SequenceForScheduleResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerSequencesForSchedule(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 활성/비활성 일괄 변경' })
  @Put(':trainerId/sequences/bulk/status')
  async updateSequenceStatus(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: UpdateSequenceStatusDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.updateTrainerSequenceStatus(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 일정에 시퀀스 등록/수정' })
  @Post(':trainerId/sequences/:sequenceId/assign-to-schedule')
  async assignSequenceToSchedule(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('sequenceId') sequenceId: string,
    @Body() dto: AssignSequenceToScheduleDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.assignTrainerSequenceToSchedule(
      req.user.id, trainerId, sequenceId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 상세 (조회 전용)' })
  @Get(':trainerId/sequences/:sequenceId')
  async findSequenceDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('sequenceId') sequenceId: string,
  ): Promise<ISuccessResponse<SequenceEntity>> {
    const data = await this.centerTrainerViewService.findTrainerSequenceDetail(
      req.user.id, trainerId, sequenceId,
    );
    return SuccessResponse(data);
  }

  // ── 운동 (시퀀스 편집용) ────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 운동 카테고리 목록' })
  @Get(':trainerId/exercises/categories')
  async findExerciseCategories(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
  ): Promise<ISuccessResponse<ExerciseCategoryEntity[]>> {
    const data = await this.centerTrainerViewService.findTrainerExerciseCategories(
      req.user.id, trainerId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({
    summary: '센터 트레이너 — 운동 카테고리 또는 운동 목록 조회',
    description: 'categoryId가 없으면 카테고리 목록, 있으면 해당 카테고리 운동 목록을 반환합니다.',
  })
  @Get(':trainerId/exercises')
  async findExercises(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query('categoryId') categoryId?: string,
  ): Promise<ISuccessResponse<ExerciseCategoryEntity[] | ExerciseEntity[]>> {
    if (categoryId) {
      const data = await this.centerTrainerViewService.findTrainerExercisesByCategory(
        req.user.id, trainerId, categoryId,
      );
      return SuccessResponse(data);
    }
    const data = await this.centerTrainerViewService.findTrainerExerciseCategories(
      req.user.id, trainerId,
    );
    return SuccessResponse(data);
  }

  // ── 시퀀스 그룹 ───────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 그룹 목록' })
  @Get(':trainerId/sequence-groups')
  async findSequenceGroups(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindSequenceGroupsDto,
  ): Promise<IPageResponse<SequenceGroupEntity>> {
    const data = await this.centerTrainerViewService.findTrainerSequenceGroups(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 그룹 삭제 (다건)' })
  @Delete(':trainerId/sequence-groups')
  async deleteSequenceGroups(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: DeleteSequenceGroupsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerSequenceGroups(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 그룹에 시퀀스 추가' })
  @Post(':trainerId/sequence-groups/:groupId/sequences')
  async addSequenceGroupSequences(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
    @Body() dto: AddSequencesToGroupDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.addTrainerSequenceGroupSequences(
      req.user.id, trainerId, groupId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 그룹에서 시퀀스 삭제' })
  @Delete(':trainerId/sequence-groups/:groupId/sequences')
  async removeSequenceGroupSequences(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
    @Body() dto: RemoveSequencesFromGroupDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.removeTrainerSequenceGroupSequences(
      req.user.id, trainerId, groupId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 시퀀스 그룹 상세' })
  @Get(':trainerId/sequence-groups/:groupId')
  async findSequenceGroupDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('groupId') groupId: string,
  ): Promise<ISuccessResponse<SequenceGroupEntity>> {
    const data = await this.centerTrainerViewService.findTrainerSequenceGroupDetail(
      req.user.id, trainerId, groupId,
    );
    return SuccessResponse(data);
  }

  // ── Q&A ───────────────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — Q&A 목록 (조회 전용)' })
  @Get(':trainerId/qna')
  async findQna(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindQnaListDto,
  ): Promise<IPageResponse<QnaListItemDto>> {
    const data = await this.centerTrainerViewService.findTrainerQna(req.user.id, trainerId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — Q&A 통계 (조회 전용)' })
  @Get(':trainerId/qna/my-stats')
  async findQnaStats(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
  ): Promise<ISuccessResponse<QnaMyStatsResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerQnaStats(req.user.id, trainerId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — Q&A 상세 (조회 전용)' })
  @Get(':trainerId/qna/:qnaId')
  async findQnaDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('qnaId') qnaId: string,
  ): Promise<ISuccessResponse<QnaDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerQnaDetail(req.user.id, trainerId, qnaId);
    return SuccessResponse(data);
  }

  // ── 회원 ──────────────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 보유회원 목록 (조회 전용)' })
  @Get(':trainerId/members')
  async findMembers(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Query() dto: FindMyMembersDto,
  ): Promise<ISuccessResponse<MyMembersResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMembers(req.user.id, trainerId, dto);
    return SuccessResponse<MyMembersResponseDto>(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 등록' })
  @Post(':trainerId/members')
  async registerMember(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: RegisterMemberDto,
  ): Promise<ISuccessResponse<UserEntity>> {
    const data = await this.centerTrainerViewService.registerTrainerMember(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 계정 삭제 (다건)' })
  @Delete(':trainerId/members/account')
  async deleteMembers(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: BulkCenterTrainerMemberIdsDto,
  ): Promise<ISuccessResponse<{ success: true; affected: number }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMembers(
      req.user.id, trainerId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 상세 (조회 전용)' })
  @Get(':trainerId/members/:memberId')
  async findMemberDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
  ): Promise<ISuccessResponse<UserDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberDetail(
      req.user.id, trainerId, memberId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 이용권 목록 (조회 전용)' })
  @Get(':trainerId/subscriptions/member/:memberId')
  async findMemberSubscriptions(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindMemberSubscriptionsDto,
  ): Promise<IPageResponse<MemberSubscriptionResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberSubscriptions(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 이용권 지급' })
  @Post(':trainerId/subscriptions/member/:memberId')
  async grantMemberSubscription(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: GrantSubscriptionDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const data = await this.centerTrainerViewService.grantTrainerMemberSubscription(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 이용권 상태 변경 (정지/활성화)' })
  @Put(':trainerId/subscriptions/member/:memberId/status')
  async updateMemberSubscriptionStatus(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: UpdateCenterTrainerMemberSubscriptionStatusDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberSubscriptionStatus(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  // ── 회원 측정: 체형 ───────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형 리포트 목록 (조회 전용)' })
  @Get(':trainerId/body-reports/member/:memberId')
  async findMemberBodyReports(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindBodyReportDto,
  ): Promise<IPageResponse<BodyReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBodyReports(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형 리포트 일괄 삭제' })
  @Delete(':trainerId/body-reports/member/:memberId')
  async deleteMemberBodyReports(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeleteBodyReportsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberBodyReports(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형 리포트 상세 (조회 전용)' })
  @Get(':trainerId/body-reports/member/:memberId/:id')
  async findMemberBodyReportDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<BodyReportDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBodyReportDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 체형리포트 맞춤운동 (조회 전용)' })
  @Get(':trainerId/body-reports/member/:memberId/:id/custom-exercises')
  async findMemberBodyReportCustomExercises(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBodyReportCustomExercises(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  // ── 회원 측정: 정밀 ───────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 정밀 리포트 목록 (조회 전용)' })
  @Get(':trainerId/precision-reports/member/:memberId')
  async findMemberPrecisionReports(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberPrecisionReports(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 정밀 리포트 일괄 삭제' })
  @Delete(':trainerId/precision-reports/member/:memberId')
  async deleteMemberPrecisionReports(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeletePrecisionReportsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberPrecisionReports(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 정밀 리포트 상세 (조회 전용)' })
  @Get(':trainerId/precision-reports/member/:memberId/:id')
  async findMemberPrecisionReportDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<PrecisionReportDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberPrecisionReportDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 정밀리포트 맞춤운동 (조회 전용)' })
  @Get(':trainerId/precision-reports/member/:memberId/:id/custom-exercises')
  async findMemberPrecisionReportCustomExercises(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.findTrainerMemberPrecisionReportCustomExercises(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  // ── 회원 측정: 모션 ───────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 모션 분석 목록 (조회 전용)' })
  @Get(':trainerId/motion-analyses/member/:memberId')
  async findMemberMotionAnalyses(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindMotionAnalysisDto,
  ): Promise<IPageResponse<MotionAnalysisResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberMotionAnalyses(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 모션 분석 일괄 삭제' })
  @Delete(':trainerId/motion-analyses/member/:memberId')
  async deleteMemberMotionAnalyses(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeleteMotionAnalysesDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberMotionAnalyses(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 모션 분석 상세 (조회 전용)' })
  @Get(':trainerId/motion-analyses/member/:memberId/:id')
  async findMemberMotionAnalysisDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<MotionAnalysisDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberMotionAnalysisDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  // ── 회원 측정: 인바디 ─────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 목록 (조회 전용)' })
  @Get(':trainerId/inbody/member/:memberId')
  async findMemberInbodyList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindInbodyDataDto,
  ): Promise<IPageResponse<InbodyDataResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberInbodyList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 일괄 삭제' })
  @Delete(':trainerId/inbody/member/:memberId')
  async deleteMemberInbodyData(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeleteInbodyDataDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberInbodyData(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 상세 (조회 전용)' })
  @Get(':trainerId/inbody/member/:memberId/:id')
  async findMemberInbodyDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<InbodyDataDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberInbodyDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 수동 등록' })
  @Post(':trainerId/inbody/member/:memberId/manual')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      required: ['measuredAt'],
      properties: {
        measuredAt: { type: 'string', format: 'date-time' },
        weight: { type: 'number' },
        skeletalMuscleMass: { type: 'number' },
        bodyFatMass: { type: 'number' },
        bmi: { type: 'number' },
        percentBodyFat: { type: 'number' },
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createMemberInbodyManual(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: CreateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberInbodyManual(
      req.user.id, trainerId, memberId, dto, file,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 OCR 등록' })
  @Post(':trainerId/inbody/member/:memberId/ocr')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createMemberInbodyOcr(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberInbodyOcr(
      req.user.id, trainerId, memberId, file,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 수정' })
  @Put(':trainerId/inbody/member/:memberId/:id')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        weight: { type: 'number' },
        skeletalMuscleMass: { type: 'number' },
        bodyFatMass: { type: 'number' },
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  async updateMemberInbody(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() dto: UpdateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberInbody(
      req.user.id, trainerId, memberId, id, dto, file,
    );
    return SuccessResponse(data);
  }

  // ── 회원: 상담일지 ────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 상담일지 목록 (조회 전용)' })
  @Get(':trainerId/consultation-logs/member/:memberId')
  async findMemberConsultationLogs(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindConsultationLogDto,
  ): Promise<IPageResponse<ConsultationLogResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberConsultationLogs(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 트레킹노트(상담일지) 등록 (트레이너 ID로 기록)' })
  @Post(':trainerId/consultation-logs/member/:memberId')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: CreateConsultationLogDto })
  async createMemberConsultationLog(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: CreateConsultationLogDto,
    @UploadedFiles() files?: Express.Multer.File[],
  ): Promise<ISuccessResponse<ConsultationLogEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberConsultationLog(
      req.user.id, trainerId, memberId, dto, files,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 트레킹노트(상담일지) 수정 (트레이너 ID로 기록)' })
  @Put(':trainerId/consultation-logs/member/:memberId/:logId')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: UpdateConsultationLogDto })
  async updateMemberConsultationLog(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
    @Body() dto: UpdateConsultationLogDto,
    @UploadedFiles() files?: Express.Multer.File[],
  ): Promise<ISuccessResponse<ConsultationLogEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberConsultationLog(
      req.user.id, trainerId, memberId, logId, dto, files,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 상담일지 일괄 삭제' })
  @Delete(':trainerId/consultation-logs/member/:memberId')
  async deleteMemberConsultationLogs(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeleteConsultationLogsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberConsultationLogs(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 상담 액션플랜 (조회 전용)' })
  @Get(':trainerId/consultation-logs/member/:memberId/action-plan')
  async findMemberConsultationLogActionPlan(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query('bodyReportId') bodyReportId?: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.findTrainerMemberConsultationLogActionPlan(
      req.user.id, trainerId, memberId, bodyReportId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 상담일지 상세 (조회 전용)' })
  @Get(':trainerId/consultation-logs/member/:memberId/:logId')
  async findMemberConsultationLogDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
  ): Promise<ISuccessResponse<ConsultationLogDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberConsultationLogDetail(
      req.user.id, trainerId, memberId, logId,
    );
    return SuccessResponse(data);
  }

  // ── 회원: 운동일지 ────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 운동일지 목록 (조회 전용)' })
  @Get(':trainerId/workout-logs/member/:memberId')
  async findMemberWorkoutLogs(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindWorkoutLogDto,
  ): Promise<IPageResponse<WorkoutLogResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberWorkoutLogs(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 운동일지 일괄 삭제' })
  @Delete(':trainerId/workout-logs/member/:memberId')
  async deleteMemberWorkoutLogs(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: DeleteWorkoutLogsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberWorkoutLogs(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 운동일지 상세 (조회 전용)' })
  @Get(':trainerId/workout-logs/member/:memberId/:logId')
  async findMemberWorkoutLogDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
  ): Promise<ISuccessResponse<WorkoutLogDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberWorkoutLogDetail(
      req.user.id, trainerId, memberId, logId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 운동일지 등록' })
  @Post(':trainerId/workout-logs/member/:memberId')
  async createMemberWorkoutLog(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: CreateWorkoutLogDto,
  ): Promise<ISuccessResponse<WorkoutLogEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberWorkoutLog(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 운동일지 수정' })
  @Put(':trainerId/workout-logs/member/:memberId/:logId')
  async updateMemberWorkoutLog(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
    @Body() dto: UpdateWorkoutLogDto,
  ): Promise<ISuccessResponse<WorkoutLogEntity>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberWorkoutLog(
      req.user.id, trainerId, memberId, logId, dto,
    );
    return SuccessResponse(data);
  }

  // ── 회원: 식단일지 ────────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 식단일지 목록 (조회 전용)' })
  @Get(':trainerId/food-logs/member/:memberId')
  async findMemberFoodLogs(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindFoodLogDto,
  ): Promise<IPageResponse<FoodLogResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberFoodLogs(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 식단일지 상세 (조회 전용)' })
  @Get(':trainerId/food-logs/member/:memberId/:id')
  async findMemberFoodLogDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FoodLogDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberFoodLogDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 식단일지 피드백 수정 (트레킹)' })
  @Put(':trainerId/food-logs/member/:memberId/:id/feedback')
  async updateMemberFoodLogFeedback(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() dto: UpdateFoodLogCommentDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.updateTrainerMemberFoodLogFeedback(
      req.user.id, trainerId, memberId, id, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 식단일지 피드백 삭제 (트레킹)' })
  @Delete(':trainerId/food-logs/member/:memberId/:id/feedback')
  async deleteMemberFoodLogFeedback(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberFoodLogFeedback(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  // ── 회원: 리포트 비교 ─────────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 리포트 비교 목록 (조회 전용)' })
  @Get(':trainerId/report-comparisons/member/:memberId')
  async findMemberReportComparisons(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindReportComparisonDto,
  ): Promise<IPageResponse<ReportComparisonResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisons(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 리포트 비교 생성' })
  @Post(':trainerId/report-comparisons/member/:memberId')
  async createMemberReportComparison(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Body() dto: CreateReportComparisonDto,
  ): Promise<ISuccessResponse<ReportComparisonEntity>> {
    const data = await this.centerTrainerViewService.createTrainerMemberReportComparison(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/body/member/:memberId/:id')
  async findMemberReportComparisonBody(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<ReportComparisonDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonBody(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 ROM 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/rom/member/:memberId/:id')
  async findMemberReportComparisonRom(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<RomComparisonDetailResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonRom(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 모션 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/motion/member/:memberId/:id')
  async findMemberReportComparisonMotion(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<Record<string, unknown>>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonMotion(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 인바디 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/inbody/member/:memberId/:id')
  async findMemberReportComparisonInbody(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<Record<string, unknown>>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonInbody(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 척추정렬 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/spinal-alignment/member/:memberId/:id')
  async findMemberReportComparisonSpinalAlignment(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<Record<string, unknown>>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonSpinalAlignment(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 균형감각 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/balance-test/member/:memberId/:id')
  async findMemberReportComparisonBalanceTest(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<Record<string, unknown>>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonBalanceTest(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 전신기능 비교 상세 (조회 전용)' })
  @Get(':trainerId/report-comparisons/overhead-squat/member/:memberId/:id')
  async findMemberReportComparisonOverheadSquat(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<Record<string, unknown>>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonOverheadSquat(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 리포트 비교 상세 (reportType 자동 분기)' })
  @Get(':trainerId/report-comparisons/member/:memberId/:id')
  async findMemberReportComparisonDetail(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.findTrainerMemberReportComparisonDetail(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 리포트 비교 삭제' })
  @Delete(':trainerId/report-comparisons/member/:memberId/:id')
  async deleteMemberReportComparison(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const data = await this.centerTrainerViewService.deleteTrainerMemberReportComparison(
      req.user.id, trainerId, memberId, id,
    );
    return SuccessResponse(data);
  }

  // ── 회원: 측정 리포트 뷰 ──────────────────────────────────────────

  @ApiOperation({ summary: '센터 트레이너 — 회원 정밀측정 추천 부위 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/recommended-precision-parts')
  async findMemberRecommendedPrecisionParts(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query('bodyReportId') bodyReportId?: string,
  ): Promise<ISuccessResponse<RecommendedPrecisionPartsResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberRecommendedPrecisionParts(
      req.user.id, trainerId, memberId, bodyReportId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형측정 리포트 목록 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/body-measurement')
  async findMemberBodyMeasurementReportList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindBodyReportDto,
  ): Promise<IPageResponse<BodyReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBodyMeasurementReportList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 척추정렬 리포트 목록 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/spinal-alignment')
  async findMemberSpinalAlignmentReportList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberSpinalAlignmentReportList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 전신기능 리포트 목록 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/overhead-squat')
  async findMemberOverheadSquatReportList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberOverheadSquatReportList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 관절 ROM 리포트 목록 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/joint-rom')
  async findMemberJointRomReportList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberJointRomReportList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 균형감각 리포트 목록 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/balance-test')
  async findMemberBalanceTestReportList(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Query() dto: FindPrecisionReportDto,
  ): Promise<IPageResponse<PrecisionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBalanceTestReportList(
      req.user.id, trainerId, memberId, dto,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 체형측정 리포트 뷰 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/body-measurement/:id')
  async findMemberBodyMeasurementReport(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<BodyMeasurementReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBodyMeasurementReport(
      req.user.id, trainerId, memberId, id, resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 척추정렬 리포트 뷰 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/spinal-alignment/:id')
  async findMemberSpinalAlignmentReport(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<SpineAlignmentReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberSpinalAlignmentReport(
      req.user.id, trainerId, memberId, id, resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 균형감각 리포트 뷰 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/balance-test/:id')
  async findMemberBalanceTestReport(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<BalanceSenseReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberBalanceTestReport(
      req.user.id, trainerId, memberId, id, resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 관절 ROM 리포트 뷰 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/joint-rom/:id')
  async findMemberJointRomReport(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<JointRomReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberJointRomReport(
      req.user.id, trainerId, memberId, id, resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 전신기능 리포트 뷰 (조회 전용)' })
  @Get(':trainerId/measurement-reports/member/:memberId/overhead-squat/:id')
  async findMemberOverheadSquatReport(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Headers('accept-language') acceptLanguage?: string,
  ): Promise<ISuccessResponse<FullBodyFunctionReportResponseDto>> {
    const data = await this.centerTrainerViewService.findTrainerMemberOverheadSquatReport(
      req.user.id, trainerId, memberId, id, resolveReportDisplayLanguage(acceptLanguage),
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 등록/매출 퍼널 (트레이너 대시보드와 동일)' })
  @Get(':trainerId/dashboard/sales-funnel')
  async findTrainerSalesFunnel(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.centerTrainerViewService.findTrainerSalesFunnel(
      req.user.id,
      trainerId,
    );
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너 — 회원 성과 기록 (조회 전용)' })
  @Get(':trainerId/dashboard/performance/records/:memberId/:type/:direction')
  async findMemberPerformanceRecords(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Param('memberId') memberId: string,
    @Param('type') type: string,
    @Param('direction') direction: string,
  ): Promise<ISuccessResponse<unknown>> {
    const validTypes = ['neck', 'pelvis', 'shoulder', 'rom'] as const;
    const validDirs = ['top', 'bottom'] as const;
    const resolvedType = validTypes.includes(type as typeof validTypes[number])
      ? (type as typeof validTypes[number])
      : 'rom';
    const resolvedDir = validDirs.includes(direction as typeof validDirs[number])
      ? (direction as typeof validDirs[number])
      : 'bottom';

    const data = await this.centerTrainerViewService.findTrainerMemberPerformanceRecords(
      req.user.id, trainerId, memberId, resolvedType, resolvedDir,
    );
    return SuccessResponse(data);
  }
}
