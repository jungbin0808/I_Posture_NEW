import { CenterTrainerStatus } from '../../../../database/entities/center-trainer.entity';
import { addDaysToDateString, diffDaysBetweenDateStrings, getKstDateString } from '../../../../common/utils/date.util';
import { CenterTrainerAccountStatus } from '../dto/center-trainer-account-status.enum';

/** 회원탈퇴(softDelete) 후 계정이 실제로 삭제되기까지의 유예 기간(일) */
export const ACCOUNT_DELETION_GRACE_DAYS = 90;

const CENTER_TRAINER_ACCOUNT_STATUS_LABEL: Record<CenterTrainerAccountStatus, string> = {
  [CenterTrainerAccountStatus.ACTIVE]: '활성화',
  [CenterTrainerAccountStatus.LOGIN_PENDING]: '로그인대기',
  [CenterTrainerAccountStatus.INACTIVE]: '비활성화',
  [CenterTrainerAccountStatus.RESIGNED]: '탈퇴',
};

export function resolveCenterTrainerAccountStatus(
  centerTrainerStatus: CenterTrainerStatus,
  deactivatedAt: string | Date | null | undefined,
  loginHistoryCount: number,
): CenterTrainerAccountStatus {
  // 트레이너 본인 회원탈퇴 시 center_trainers.status가 RESIGNED로 바뀌는데, 기존엔 이 상태를
  // 전혀 확인하지 않아 탈퇴한 트레이너가 "로그인대기"로 잘못 표시되고 있었음 - 최우선으로 체크
  if (centerTrainerStatus === CenterTrainerStatus.RESIGNED) {
    return CenterTrainerAccountStatus.RESIGNED;
  }

  if (deactivatedAt) {
    return CenterTrainerAccountStatus.INACTIVE;
  }

  // refresh_tokens row 존재 = 최초 로그인 완료 (비활성화 시 revoked만 설정, 삭제하지 않음)
  return loginHistoryCount > 0
    ? CenterTrainerAccountStatus.ACTIVE
    : CenterTrainerAccountStatus.LOGIN_PENDING;
}

export function toCenterTrainerAccountStatusLabel(status: CenterTrainerAccountStatus): string {
  return CENTER_TRAINER_ACCOUNT_STATUS_LABEL[status];
}

/**
 * 탈퇴(users.deleted_at) 시각 기준 ACCOUNT_DELETION_GRACE_DAYS일째 되는 KST 날짜(계정 완전
 * 삭제 예정일)와, 오늘(KST)부터 그날까지 남은 일수(D-day)를 계산한다. 탈퇴 상태가 아니면 null.
 * 실제 삭제 배치는 이 예정일의 KST 00:00에 실행되는 것으로 맞춤.
 */
export function calculateAccountDeletionInfo(
  userDeletedAt: string | Date | null | undefined,
): { deletionDate: string; daysUntilDeletion: number } | null {
  if (!userDeletedAt) return null;

  const deletedDate = typeof userDeletedAt === 'string' ? new Date(userDeletedAt) : userDeletedAt;
  const withdrawnKstDate = getKstDateString(deletedDate);
  const deletionDate = addDaysToDateString(withdrawnKstDate, ACCOUNT_DELETION_GRACE_DAYS);
  const daysUntilDeletion = diffDaysBetweenDateStrings(deletionDate, getKstDateString());

  return { deletionDate, daysUntilDeletion };
}
