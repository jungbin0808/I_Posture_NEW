import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { TrainerUserEntity, TrainerUserStatus } from '../../../database/entities/trainer-user.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageData } from '../../../common/response/response.interface';
import { CenterTrainerService } from './center-trainer.service';
import { ScheduleService } from '../../schedule/schedule.service';
import { ScheduleGroupService } from '../../schedule-group/schedule-group.service';
import { SequenceService } from '../../sequence/sequence.service';
import { SequenceGroupService } from '../../sequence-group/sequence-group.service';
import { ExerciseService } from '../../exercise/exercise.service';
import { QnaService } from '../../qna/qna.service';
import { UserService } from '../../user/user.service';
import { BodyReportService } from '../../body-report/body-report.service';
import { PrecisionReportService } from '../../precision-report/precision-report.service';
import { MotionAnalysisService } from '../../motion-analysis/motion-analysis.service';
import { InbodyService } from '../../inbody/inbody.service';
import { ConsultationLogService } from '../../consultation-log/consultation-log.service';
import { WorkoutLogService } from '../../workout-log/workout-log.service';
import { FoodLogService } from '../../food-log/food-log.service';
import { ReportComparisonService } from '../../report-comparison/report-comparison.service';
import { MeasurementReportService } from '../../measurement-report/measurement-report.service';
import { SubscriptionService } from '../../subscription/subscription.service';
import { TrainerDashboardService } from '../../dashboard/trainer-dashboard.service';
import { FindSchedulesDto, ScheduleListItemDto, BulkCompleteDto, BulkNoshowDto, AddSchedulesToGroupDto, RemoveSchedulesFromGroupDto, CreateScheduleDto, UpdateScheduleDto } from '../../schedule/schedule.dto';
import {
  DeleteScheduleGroupsDto,
  FindScheduleGroupsDto,
} from '../../schedule-group/schedule-group.dto';
import {
  FindSequenceDto,
  FindSequenceForScheduleDto,
  SequenceForScheduleResponseDto,
  SequenceListItemDto,
  UpdateSequenceStatusDto,
  AssignSequenceToScheduleDto,
} from '../../sequence/sequence.dto';
import {
  AddSequencesToGroupDto,
  DeleteSequenceGroupsDto,
  FindSequenceGroupsDto,
  RemoveSequencesFromGroupDto,
} from '../../sequence-group/sequence-group.dto';
import { ExerciseCategoryEntity } from '../../../database/entities/exercise-category.entity';
import { ExerciseEntity } from '../../../database/entities/exercise.entity';
import { SequenceGroupEntity } from '../../../database/entities/sequence-group.entity';
import { FindQnaListDto } from '../../qna/dto/find-qna-list.dto';
import { QnaListItemDto } from '../../qna/dto/qna-list-item.dto';
import { QnaMyStatsResponseDto } from '../../qna/dto/qna-my-stats-response.dto';
import { QnaDetailResponseDto } from '../../qna/dto/qna-detail-response.dto';
import { FindMyMembersDto } from '../../user/dto/find-my-members.dto';
import { MyMembersResponseDto } from '../../user/dto/my-members-response.dto';
import { UserDetailResponseDto } from '../../user/dto/user-detail-response.dto';
import { RegisterMemberDto } from '../../user/dto/register-member.dto';
import { FindBodyReportDto } from '../../body-report/dto/find-body-report.dto';
import { DeleteBodyReportsDto } from '../../body-report/dto/delete-body-reports.dto';
import { BodyReportResponseDto, BodyReportDetailResponseDto } from '../../body-report/dto/body-report-response.dto';
import { FindPrecisionReportDto } from '../../precision-report/dto/find-precision-report.dto';
import { DeletePrecisionReportsDto } from '../../precision-report/dto/delete-precision-reports.dto';
import {
  PrecisionReportResponseDto,
  PrecisionReportDetailResponseDto,
} from '../../precision-report/dto/precision-report-response.dto';
import { FindMotionAnalysisDto } from '../../motion-analysis/dto/find-motion-analysis.dto';
import { DeleteMotionAnalysesDto } from '../../motion-analysis/dto/delete-motion-analyses.dto';
import {
  MotionAnalysisResponseDto,
  MotionAnalysisDetailResponseDto,
} from '../../motion-analysis/dto/motion-analysis-response.dto';
import { FindInbodyDataDto } from '../../inbody/dto/find-inbody-data.dto';
import { DeleteInbodyDataDto } from '../../inbody/dto/delete-inbody-data.dto';
import { CreateInbodyDataDto } from '../../inbody/dto/create-inbody-data.dto';
import { UpdateInbodyDataDto } from '../../inbody/dto/update-inbody-data.dto';
import { InbodyDataResponseDto, InbodyDataDetailResponseDto } from '../../inbody/dto/inbody-data-response.dto';
import { InbodyDataEntity } from '../../../database/entities/inbody-data.entity';
import { FindConsultationLogDto } from '../../consultation-log/dto/find-consultation-log.dto';
import { CreateConsultationLogDto } from '../../consultation-log/dto/create-consultation-log.dto';
import { UpdateConsultationLogDto } from '../../consultation-log/dto/update-consultation-log.dto';
import { DeleteConsultationLogsDto } from '../../consultation-log/dto/delete-consultation-logs.dto';
import { ConsultationLogEntity } from '../../../database/entities/consultation-log.entity';
import { ConsultationLogResponseDto } from '../../consultation-log/dto/consultation-log-response.dto';
import { ConsultationLogDetailResponseDto } from '../../consultation-log/dto/consultation-log-detail-response.dto';
import { ActionPlanComponents } from '../../consultation-log/action-plan.helper';
import { FindWorkoutLogDto } from '../../workout-log/dto/find-workout-log.dto';
import { DeleteWorkoutLogsDto } from '../../workout-log/dto/delete-workout-logs.dto';
import { CreateWorkoutLogDto } from '../../workout-log/dto/create-workout-log.dto';
import { UpdateWorkoutLogDto } from '../../workout-log/dto/update-workout-log.dto';
import { WorkoutLogResponseDto } from '../../workout-log/dto/workout-log-response.dto';
import { WorkoutLogDetailResponseDto } from '../../workout-log/dto/workout-log-detail-response.dto';
import { WorkoutLogEntity } from '../../../database/entities/workout-log.entity';
import { FindFoodLogDto } from '../../food-log/dto/find-food-log.dto';
import { UpdateFoodLogCommentDto } from '../../food-log/dto/update-food-log-comment.dto';
import { FoodLogResponseDto } from '../../food-log/dto/food-log-response.dto';
import { FoodLogDetailResponseDto } from '../../food-log/dto/food-log-detail-response.dto';
import { FindReportComparisonDto } from '../../report-comparison/dto/find-report-comparison.dto';
import { CreateReportComparisonDto } from '../../report-comparison/dto/create-report-comparison.dto';
import {
  ReportComparisonResponseDto,
  ReportComparisonDetailResponseDto,
} from '../../report-comparison/dto/report-comparison-response.dto';
import { ReportComparisonEntity } from '../../../database/entities/report-comparison.entity';
import { RomComparisonDetailResponseDto } from '../../report-comparison/dto/rom-comparison-response.dto';
import { FindMemberSubscriptionsDto } from '../../subscription/dto/find-member-subscriptions.dto';
import { MemberSubscriptionResponseDto } from '../../subscription/dto/member-subscription-response.dto';
import { RecommendedPrecisionPartsResponseDto } from '../../measurement-report/dto/recommended-precision-parts.dto';
import { BodyMeasurementReportResponseDto } from '../../measurement-report/dto/measurement-report-response.dto';
import { SpineAlignmentReportResponseDto } from '../../measurement-report/dto/spine-alignment-report-response.dto';
import { BalanceSenseReportResponseDto } from '../../measurement-report/dto/balance-sense-report-response.dto';
import { JointRomReportResponseDto } from '../../measurement-report/dto/joint-rom-report-response.dto';
import { FullBodyFunctionReportResponseDto } from '../../measurement-report/dto/full-body-function-report-response.dto';
import { GrantSubscriptionDto } from '../../subscription/dto/grant-subscription.dto';
import { UpdateCenterTrainerMemberSubscriptionStatusDto } from './dto/update-center-trainer-member-subscription-status.dto';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { BulkCenterTrainerMemberIdsDto } from './dto/bulk-center-trainer-member-ids.dto';
import { MEASUREMENT_TYPE } from '../../../common/enums/measurement-type.enum';
import { CENTER_TRAINER_JOINT_ROM_TYPES } from './helpers/center-trainer-precision-report-types.helper';
import { CustomExerciseService } from '../../custom-exercise/custom-exercise.service';
import { SequenceEntity } from '../../../database/entities/sequence.entity';
import { ScheduleEntity } from '../../../database/entities/schedule.entity';
import { ScheduleGroupEntity } from '../../../database/entities/schedule-group.entity';

@Injectable()
export class CenterTrainerViewService {
  constructor(
    private readonly centerTrainerService: CenterTrainerService,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    private readonly scheduleService: ScheduleService,
    private readonly scheduleGroupService: ScheduleGroupService,
    private readonly sequenceService: SequenceService,
    private readonly sequenceGroupService: SequenceGroupService,
    private readonly exerciseService: ExerciseService,
    private readonly qnaService: QnaService,
    private readonly userService: UserService,
    private readonly bodyReportService: BodyReportService,
    private readonly precisionReportService: PrecisionReportService,
    private readonly motionAnalysisService: MotionAnalysisService,
    private readonly inbodyService: InbodyService,
    private readonly consultationLogService: ConsultationLogService,
    private readonly workoutLogService: WorkoutLogService,
    private readonly foodLogService: FoodLogService,
    private readonly reportComparisonService: ReportComparisonService,
    private readonly measurementReportService: MeasurementReportService,
    private readonly subscriptionService: SubscriptionService,
    private readonly trainerDashboardService: TrainerDashboardService,
    private readonly customExerciseService: CustomExerciseService,
  ) {}

  async findTrainerSchedules(
    ownerId: string,
    trainerId: string,
    dto: FindSchedulesDto,
  ): Promise<IPageData<ScheduleListItemDto>> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.findAll(trainerId, dto);
  }

  async findTrainerScheduleDetail(
    ownerId: string,
    trainerId: string,
    scheduleId: string,
  ): Promise<ScheduleEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.findOne(trainerId, scheduleId);
  }

  async createTrainerSchedule(
    ownerId: string,
    trainerId: string,
    dto: CreateScheduleDto,
  ): Promise<ScheduleEntity> {
    const trainer = await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.create(trainer.id, dto);
  }

  async updateTrainerSchedule(
    ownerId: string,
    trainerId: string,
    scheduleId: string,
    dto: UpdateScheduleDto,
  ): Promise<ScheduleEntity> {
    const trainer = await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.update(trainer.id, scheduleId, dto);
  }

  async findTrainerSchedulesForSequence(
    ownerId: string,
    trainerId: string,
  ): Promise<ScheduleListItemDto[]> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.findForSequenceRegistration(trainerId);
  }

  async findTrainerMemberSchedules(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindSchedulesDto,
  ): Promise<IPageData<ScheduleListItemDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.scheduleService.findAllByMember(trainerId, memberId, dto);
  }

  async findTrainerMemberScheduleDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    scheduleId: string,
  ): Promise<ScheduleEntity> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.scheduleService.findOneByMember(trainerId, memberId, scheduleId);
  }

  async createTrainerMemberSchedule(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: CreateScheduleDto,
  ): Promise<ScheduleEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.scheduleService.createForMember(trainer.id, memberId, dto);
  }

  async updateTrainerMemberSchedule(
    ownerId: string,
    trainerId: string,
    memberId: string,
    scheduleId: string,
    dto: UpdateScheduleDto,
  ): Promise<ScheduleEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.scheduleService.updateForMember(trainer.id, memberId, scheduleId, dto);
  }

  async deleteTrainerMemberSchedule(
    ownerId: string,
    trainerId: string,
    memberId: string,
    scheduleId: string,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.scheduleService.deleteForMember(trainerId, memberId, scheduleId);
  }

  async deleteTrainerSchedule(
    ownerId: string,
    trainerId: string,
    scheduleId: string,
  ): Promise<{ success: boolean }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.delete(trainerId, scheduleId);
  }

  async bulkNoshowTrainerSchedules(
    ownerId: string,
    trainerId: string,
    dto: BulkNoshowDto,
  ): Promise<unknown> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.bulkNoshow(trainerId, dto);
  }

  async bulkCompleteTrainerSchedules(
    ownerId: string,
    trainerId: string,
    dto: BulkCompleteDto,
  ): Promise<unknown> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.bulkComplete(trainerId, dto);
  }

  async removeTrainerScheduleSequence(
    ownerId: string,
    trainerId: string,
    scheduleId: string,
  ): Promise<ScheduleEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleService.update(trainerId, scheduleId, { sequenceId: null });
  }

  async findTrainerScheduleGroups(
    ownerId: string,
    trainerId: string,
    dto: FindScheduleGroupsDto,
  ): Promise<IPageData<ScheduleGroupEntity>> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleGroupService.findAll(trainerId, dto);
  }

  async findTrainerScheduleGroupDetail(
    ownerId: string,
    trainerId: string,
    groupId: string,
  ): Promise<ScheduleGroupEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleGroupService.findOne(trainerId, groupId);
  }

  async deleteTrainerScheduleGroups(
    ownerId: string,
    trainerId: string,
    dto: DeleteScheduleGroupsDto,
  ): Promise<{ success: boolean }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleGroupService.delete(trainerId, dto);
  }

  async addTrainerScheduleGroupSchedules(
    ownerId: string,
    trainerId: string,
    groupId: string,
    dto: AddSchedulesToGroupDto,
  ): Promise<{ success: boolean; addedCount: number }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleGroupService.addSchedulesToGroup(trainerId, groupId, dto);
  }

  async removeTrainerScheduleGroupSchedules(
    ownerId: string,
    trainerId: string,
    groupId: string,
    dto: RemoveSchedulesFromGroupDto,
  ): Promise<{ success: boolean; removedCount: number }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.scheduleGroupService.removeSchedulesFromGroup(trainerId, groupId, dto);
  }

  async findTrainerSequences(
    ownerId: string,
    trainerId: string,
    dto: FindSequenceDto,
  ): Promise<IPageData<SequenceListItemDto>> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceService.findAll(trainerId, dto);
  }

  async findTrainerSequenceDetail(
    ownerId: string,
    trainerId: string,
    sequenceId: string,
  ): Promise<SequenceEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceService.findOne(trainerId, sequenceId);
  }

  async findTrainerSequencesForSchedule(
    ownerId: string,
    trainerId: string,
    dto: FindSequenceForScheduleDto,
  ): Promise<SequenceForScheduleResponseDto> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceService.findForSchedule(trainerId, dto.search);
  }

  async updateTrainerSequenceStatus(
    ownerId: string,
    trainerId: string,
    dto: UpdateSequenceStatusDto,
  ): Promise<{ success: boolean }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceService.updateStatus(trainerId, dto);
  }

  async assignTrainerSequenceToSchedule(
    ownerId: string,
    trainerId: string,
    sequenceId: string,
    dto: AssignSequenceToScheduleDto,
  ): Promise<{ success: boolean }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceService.assignToSchedule(trainerId, sequenceId, dto.scheduleId);
  }

  async findTrainerExerciseCategories(
    ownerId: string,
    trainerId: string,
  ): Promise<ExerciseCategoryEntity[]> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.exerciseService.findAllCategories();
  }

  async findTrainerExercisesByCategory(
    ownerId: string,
    trainerId: string,
    categoryId: string,
  ): Promise<ExerciseEntity[]> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.exerciseService.findExercisesByCategory(categoryId);
  }

  async findTrainerSequenceGroups(
    ownerId: string,
    trainerId: string,
    dto: FindSequenceGroupsDto,
  ): Promise<IPageData<SequenceGroupEntity>> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceGroupService.findAll(trainerId, dto);
  }

  async findTrainerSequenceGroupDetail(
    ownerId: string,
    trainerId: string,
    groupId: string,
  ): Promise<SequenceGroupEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceGroupService.findOne(trainerId, groupId);
  }

  async deleteTrainerSequenceGroups(
    ownerId: string,
    trainerId: string,
    dto: DeleteSequenceGroupsDto,
  ): Promise<{ success: boolean }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceGroupService.delete(trainerId, dto);
  }

  async addTrainerSequenceGroupSequences(
    ownerId: string,
    trainerId: string,
    groupId: string,
    dto: AddSequencesToGroupDto,
  ): Promise<unknown> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceGroupService.addSequencesToGroup(trainerId, groupId, dto);
  }

  async removeTrainerSequenceGroupSequences(
    ownerId: string,
    trainerId: string,
    groupId: string,
    dto: RemoveSequencesFromGroupDto,
  ): Promise<unknown> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.sequenceGroupService.removeSequencesFromGroup(trainerId, groupId, dto);
  }

  async findTrainerQna(
    ownerId: string,
    trainerId: string,
    dto: FindQnaListDto,
  ): Promise<IPageData<QnaListItemDto>> {
    const trainer = await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.qnaService.findAllByUserActivity(trainer, dto);
  }

  async findTrainerQnaStats(
    ownerId: string,
    trainerId: string,
  ): Promise<QnaMyStatsResponseDto> {
    const trainer = await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.qnaService.getMyStats(trainer);
  }

  async findTrainerQnaDetail(
    ownerId: string,
    trainerId: string,
    qnaId: string,
  ): Promise<QnaDetailResponseDto> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.qnaService.findOne(qnaId);
  }

  async findTrainerMembers(
    ownerId: string,
    trainerId: string,
    dto: FindMyMembersDto,
  ): Promise<MyMembersResponseDto> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.userService.getMyMembers(trainerId, dto);
  }

  async registerTrainerMember(
    ownerId: string,
    trainerId: string,
    dto: RegisterMemberDto,
  ): Promise<UserEntity> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.userService.registerMember(trainerId, dto);
  }

  @Transactional()
  async deleteTrainerMembers(
    ownerId: string,
    trainerId: string,
    dto: BulkCenterTrainerMemberIdsDto,
  ): Promise<{ success: true; affected: number }> {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);

    const uniqueMemberIds = [...new Set(dto.memberIds)];
    for (const memberId of uniqueMemberIds) {
      await this.userService.deleteMember(trainerId, memberId);
    }

    return { success: true, affected: uniqueMemberIds.length };
  }

  async grantTrainerMemberSubscription(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: GrantSubscriptionDto,
  ): Promise<SubscriptionEntity> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.subscriptionService.grantSubscription(trainerId, memberId, dto);
  }

  async updateTrainerMemberSubscriptionStatus(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: UpdateCenterTrainerMemberSubscriptionStatusDto,
  ): Promise<SubscriptionEntity> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.subscriptionService.updateStatusForMember(
      trainerId,
      memberId,
      dto.subscriptionId,
      dto.status,
    );
  }

  async findTrainerMemberDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
  ): Promise<UserDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.userService.findOne(memberId);
  }

  async findTrainerMemberSubscriptions(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindMemberSubscriptionsDto,
  ): Promise<IPageData<MemberSubscriptionResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.subscriptionService.findAllByMember(trainerId, memberId, dto);
  }

  async findTrainerMemberBodyReports(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindBodyReportDto,
  ): Promise<IPageData<BodyReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.bodyReportService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberBodyReportDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<BodyReportDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.bodyReportService.findOne(trainerId, memberId, id);
  }

  async deleteTrainerMemberBodyReports(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeleteBodyReportsDto,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.bodyReportService.delete(trainerId, memberId, dto);
  }

  async findTrainerMemberPrecisionReports(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindPrecisionReportDto,
  ): Promise<IPageData<PrecisionReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberPrecisionReportDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<PrecisionReportDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findOne(trainerId, memberId, id);
  }

  async deleteTrainerMemberPrecisionReports(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeletePrecisionReportsDto,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.delete(trainerId, memberId, dto);
  }

  async findTrainerMemberMotionAnalyses(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindMotionAnalysisDto,
  ): Promise<IPageData<MotionAnalysisResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.motionAnalysisService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberMotionAnalysisDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<MotionAnalysisDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.motionAnalysisService.findOne(trainerId, memberId, id);
  }

  async deleteTrainerMemberMotionAnalyses(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeleteMotionAnalysesDto,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.motionAnalysisService.delete(trainerId, memberId, dto);
  }

  async findTrainerMemberInbodyList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindInbodyDataDto,
  ): Promise<IPageData<InbodyDataResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.inbodyService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberInbodyDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<InbodyDataDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.inbodyService.findOne(trainerId, memberId, id);
  }

  async createTrainerMemberInbodyManual(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: CreateInbodyDataDto,
    file?: Express.Multer.File,
  ): Promise<InbodyDataEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.inbodyService.createManual(trainer, memberId, dto, file);
  }

  async createTrainerMemberInbodyOcr(
    ownerId: string,
    trainerId: string,
    memberId: string,
    file: Express.Multer.File,
  ): Promise<InbodyDataEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.inbodyService.createFromOcr(trainer, memberId, file);
  }

  async updateTrainerMemberInbody(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    dto: UpdateInbodyDataDto,
    file?: Express.Multer.File,
  ): Promise<InbodyDataEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.inbodyService.update(trainer, memberId, id, dto, file);
  }

  async deleteTrainerMemberInbodyData(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeleteInbodyDataDto,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.inbodyService.delete(trainerId, memberId, dto);
  }

  async findTrainerMemberConsultationLogs(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindConsultationLogDto,
  ): Promise<IPageData<ConsultationLogResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.consultationLogService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberConsultationLogActionPlan(
    ownerId: string,
    trainerId: string,
    memberId: string,
    bodyReportId?: string,
  ): Promise<ActionPlanComponents> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.consultationLogService.generateActionPlan(trainerId, memberId, bodyReportId);
  }

  async findTrainerMemberConsultationLogDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    logId: string,
  ): Promise<ConsultationLogDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.consultationLogService.findOne(trainerId, memberId, logId);
  }

  async createTrainerMemberConsultationLog(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: CreateConsultationLogDto,
    files?: Express.Multer.File[],
  ): Promise<ConsultationLogEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.consultationLogService.create(trainer.id, memberId, dto, files);
  }

  async updateTrainerMemberConsultationLog(
    ownerId: string,
    trainerId: string,
    memberId: string,
    logId: string,
    dto: UpdateConsultationLogDto,
    files?: Express.Multer.File[],
  ): Promise<ConsultationLogEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.consultationLogService.update(trainer.id, memberId, logId, dto, files);
  }

  async deleteTrainerMemberConsultationLogs(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeleteConsultationLogsDto,
  ): Promise<{ success: boolean }> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.consultationLogService.delete(trainer.id, memberId, dto);
  }

  async findTrainerMemberWorkoutLogs(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindWorkoutLogDto,
  ): Promise<IPageData<WorkoutLogResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.workoutLogService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberWorkoutLogDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    logId: string,
  ): Promise<WorkoutLogDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.workoutLogService.findOne(trainerId, memberId, logId);
  }

  async createTrainerMemberWorkoutLog(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: CreateWorkoutLogDto,
  ): Promise<WorkoutLogEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.workoutLogService.create(trainer.id, memberId, dto);
  }

  async updateTrainerMemberWorkoutLog(
    ownerId: string,
    trainerId: string,
    memberId: string,
    logId: string,
    dto: UpdateWorkoutLogDto,
  ): Promise<WorkoutLogEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.workoutLogService.update(trainer.id, memberId, logId, dto);
  }

  async deleteTrainerMemberWorkoutLogs(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: DeleteWorkoutLogsDto,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.workoutLogService.delete(trainerId, memberId, dto);
  }

  async findTrainerMemberFoodLogs(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindFoodLogDto,
  ): Promise<IPageData<FoodLogResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.foodLogService.findAllByTrainer(trainerId, memberId, dto);
  }

  async findTrainerMemberFoodLogDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<FoodLogDetailResponseDto> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.foodLogService.findOne(trainer, memberId, id);
  }

  async updateTrainerMemberFoodLogFeedback(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    dto: UpdateFoodLogCommentDto,
  ): Promise<unknown> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.foodLogService.updateFeedback(trainer.id, memberId, id, dto);
  }

  async deleteTrainerMemberFoodLogFeedback(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<unknown> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.foodLogService.deleteFeedback(trainer.id, memberId, id);
  }

  async findTrainerMemberReportComparisons(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindReportComparisonDto,
  ): Promise<IPageData<ReportComparisonResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findAllByMemberId(trainerId, memberId, dto);
  }

  async createTrainerMemberReportComparison(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: CreateReportComparisonDto,
  ): Promise<ReportComparisonEntity> {
    const trainer = await this.ensureMemberAccess(ownerId, trainerId, memberId);
    return this.reportComparisonService.create(trainer.id, memberId, dto);
  }

  async findTrainerMemberReportComparisonDetail(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<unknown> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneForMember(trainerId, memberId, id);
  }

  async deleteTrainerMemberReportComparison(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<{ success: boolean }> {
    await this.ensureMember(ownerId, trainerId, memberId);
    await this.reportComparisonService.delete(trainerId, memberId, id);
    return { success: true };
  }

  async findTrainerMemberReportComparisonBody(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<ReportComparisonDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneBody(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonRom(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<RomComparisonDetailResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneRom(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonMotion(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<Record<string, unknown>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneMotion(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonInbody(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<Record<string, unknown>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneInbody(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonSpinalAlignment(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<Record<string, unknown>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneSpine(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonBalanceTest(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<Record<string, unknown>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneBalance(trainerId, memberId, id);
  }

  async findTrainerMemberReportComparisonOverheadSquat(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
  ): Promise<Record<string, unknown>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.reportComparisonService.findOneFullBody(trainerId, memberId, id);
  }

  async findTrainerMemberRecommendedPrecisionParts(
    ownerId: string,
    trainerId: string,
    memberId: string,
    bodyReportId?: string,
  ): Promise<RecommendedPrecisionPartsResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getRecommendedPrecisionParts(trainerId, memberId, bodyReportId);
  }

  async findTrainerMemberBodyMeasurementReportList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindBodyReportDto,
  ): Promise<IPageData<BodyReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.bodyReportService.findAllByMemberId(trainerId, memberId, dto);
  }

  async findTrainerMemberSpinalAlignmentReportList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindPrecisionReportDto,
  ): Promise<IPageData<PrecisionReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findAllByMemberId(trainerId, memberId, {
      ...dto,
      type: MEASUREMENT_TYPE.SPINAL_ALIGNMENT_TEST,
    });
  }

  async findTrainerMemberOverheadSquatReportList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindPrecisionReportDto,
  ): Promise<IPageData<PrecisionReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findAllByMemberId(trainerId, memberId, {
      ...dto,
      type: MEASUREMENT_TYPE.OVERHEAD_SQUAT_TEST,
    });
  }

  async findTrainerMemberBalanceTestReportList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindPrecisionReportDto,
  ): Promise<IPageData<PrecisionReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findAllByMemberId(trainerId, memberId, {
      ...dto,
      type: MEASUREMENT_TYPE.BALANCE_TEST,
    });
  }

  async findTrainerMemberJointRomReportList(
    ownerId: string,
    trainerId: string,
    memberId: string,
    dto: FindPrecisionReportDto,
  ): Promise<IPageData<PrecisionReportResponseDto>> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.precisionReportService.findAllByMemberId(trainerId, memberId, {
      ...dto,
      types: [...CENTER_TRAINER_JOINT_ROM_TYPES],
    });
  }

  async findTrainerMemberBodyReportCustomExercises(
    ownerId: string,
    trainerId: string,
    memberId: string,
    reportId: string,
  ) {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.customExerciseService.findByBodyReportId(reportId);
  }

  async findTrainerMemberPrecisionReportCustomExercises(
    ownerId: string,
    trainerId: string,
    memberId: string,
    reportId: string,
  ) {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.customExerciseService.findByPrecisionReportId(reportId);
  }

  async findTrainerMemberBodyMeasurementReport(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<BodyMeasurementReportResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getBodyMeasurementReport(memberId, id, lang);
  }

  async findTrainerMemberSpinalAlignmentReport(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<SpineAlignmentReportResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getSpineAlignmentReport(memberId, id, lang);
  }

  async findTrainerMemberBalanceTestReport(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<BalanceSenseReportResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getBalanceSenseReport(memberId, id, lang);
  }

  async findTrainerMemberJointRomReport(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<JointRomReportResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getJointRomReport(memberId, id, lang);
  }

  async findTrainerMemberOverheadSquatReport(
    ownerId: string,
    trainerId: string,
    memberId: string,
    id: string,
    lang?: 'ko' | 'en',
  ): Promise<FullBodyFunctionReportResponseDto> {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.measurementReportService.getFullBodyFunctionReport(memberId, id, lang);
  }

  async findTrainerMemberPerformanceRecords(
    ownerId: string,
    trainerId: string,
    memberId: string,
    type: 'neck' | 'pelvis' | 'shoulder' | 'rom',
    direction: 'top' | 'bottom',
  ) {
    await this.ensureMember(ownerId, trainerId, memberId);
    return this.trainerDashboardService.getPerformanceRecordsByMember(
      trainerId,
      memberId,
      type,
      direction,
    );
  }

  async findTrainerSalesFunnel(ownerId: string, trainerId: string) {
    await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    return this.trainerDashboardService.getSalesFunnel(trainerId);
  }

  /**
   * 센터 소속·회원 관계 검증 후 트레이너 UserEntity 반환.
   * 등록/수정 시 반드시 이 트레이너 ID로 기존 Service에 위임 (센터 오너 ID 사용 금지).
   */
  private async ensureMemberAccess(
    ownerId: string,
    trainerId: string,
    memberId: string,
  ): Promise<UserEntity> {
    const trainer = await this.centerTrainerService.ensureAffiliatedTrainer(ownerId, trainerId);
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId: trainer.id, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new NotFoundException('회원을 찾을 수 없습니다.');
    }
    return trainer;
  }

  /** 조회 전용 — 트레이너 액터 불필요 */
  private async ensureMember(
    ownerId: string,
    trainerId: string,
    memberId: string,
  ): Promise<void> {
    await this.ensureMemberAccess(ownerId, trainerId, memberId);
  }
}
