import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseUUIDPipe,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CenterTrainerService } from './center-trainer.service';
import { FindCenterTrainerDto } from './dto/find-center-trainer.dto';
import { CenterTrainerListItemDto } from './dto/center-trainer-list-item.dto';
import { CreateCenterTrainerDto } from './dto/create-center-trainer.dto';
import { FindCenterTrainerInvitationDto } from './dto/find-center-trainer-invitation.dto';
import { CenterTrainerInvitationListItemDto } from './dto/center-trainer-invitation-list-item.dto';
import { BulkCenterTrainerIdsDto } from './dto/bulk-center-trainer-ids.dto';
import { CenterTrainerDetailDto } from './dto/center-trainer-detail.dto';
import { UpdateCenterTrainerDto } from './dto/update-center-trainer.dto';

@ApiTags('Center Trainer')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/trainers')
export class CenterTrainerController {
  constructor(private readonly centerTrainerService: CenterTrainerService) {}

  @ApiOperation({ summary: '센터 트레이너 목록' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() dto: FindCenterTrainerDto,
  ): Promise<IPageResponse<CenterTrainerListItemDto>> {
    const pageData = await this.centerTrainerService.findTrainers(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '트레이너 계정 발급 내역 목록' })
  @Get('invitations')
  async findInvitations(
    @Req() req: { user: UserEntity },
    @Query() dto: FindCenterTrainerInvitationDto,
  ): Promise<IPageResponse<CenterTrainerInvitationListItemDto>> {
    const pageData = await this.centerTrainerService.findInvitations(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '트레이너 초대 메일 발송 (재발송)' })
  @Post('invitations/:invitationId/send-email')
  async sendInvitationEmail(
    @Req() req: { user: UserEntity },
    @Param('invitationId', ParseUUIDPipe) invitationId: string,
  ): Promise<ISuccessResponse<{ invitationId: string; invitedAt: string }>> {
    const result = await this.centerTrainerService.sendInvitationEmail(req.user.id, invitationId);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '트레이너 계정 발급 (초대 메일 발송)' })
  @Post()
  async create(
    @Req() req: { user: UserEntity },
    @Body() dto: CreateCenterTrainerDto,
  ): Promise<ISuccessResponse<{ trainerId: string; invitationId: string; invitedAt: string }>> {
    const result = await this.centerTrainerService.createTrainer(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '트레이너 계정 활성화 (다건)' })
  @Put('activate')
  async activate(
    @Req() req: { user: UserEntity },
    @Body() dto: BulkCenterTrainerIdsDto,
  ): Promise<ISuccessResponse<{ success: true; affected: number }>> {
    const result = await this.centerTrainerService.activateTrainers(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '트레이너 계정 비활성화 (다건)' })
  @Put('deactivate')
  async deactivate(
    @Req() req: { user: UserEntity },
    @Body() dto: BulkCenterTrainerIdsDto,
  ): Promise<ISuccessResponse<{ success: true; affected: number }>> {
    const result = await this.centerTrainerService.deactivateTrainers(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '트레이너 삭제 (센터 소속 해제, 다건)' })
  @Delete()
  async remove(
    @Req() req: { user: UserEntity },
    @Body() dto: BulkCenterTrainerIdsDto,
  ): Promise<ISuccessResponse<{ success: true; affected: number }>> {
    const result = await this.centerTrainerService.deleteTrainers(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '센터 트레이너 상세 요약' })
  @Get(':trainerId')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
  ): Promise<ISuccessResponse<CenterTrainerDetailDto>> {
    const data = await this.centerTrainerService.findTrainerDetail(req.user.id, trainerId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '센터 트레이너명 변경' })
  @Put(':trainerId')
  async update(
    @Req() req: { user: UserEntity },
    @Param('trainerId') trainerId: string,
    @Body() dto: UpdateCenterTrainerDto,
  ): Promise<ISuccessResponse<{ trainerId: string; name: string }>> {
    const result = await this.centerTrainerService.updateTrainerName(req.user.id, trainerId, dto);
    return SuccessResponse(result);
  }
}
