import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { CenterTrainerSortOrder } from './center-trainer-sort.enum';
import { CenterTrainerListFilter } from './center-trainer-list-filter.enum';

export class FindCenterTrainerDto extends PaginationDto {
  @ApiProperty({
    description: '탭 필터 (전체/활성화/로그인대기/비활성화)',
    enum: CenterTrainerListFilter,
    required: false,
    default: CenterTrainerListFilter.ALL,
  })
  @IsEnum(CenterTrainerListFilter)
  @IsOptional()
  filter?: CenterTrainerListFilter = CenterTrainerListFilter.ALL;

  @ApiProperty({
    description: '키워드 검색 (트레이너명, 아이디, 연락처)',
    required: false,
  })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiProperty({
    description: '정렬 (계정생성일 오름/내림차순)',
    enum: CenterTrainerSortOrder,
    required: false,
    default: CenterTrainerSortOrder.DATE_DESC,
  })
  @IsEnum(CenterTrainerSortOrder)
  @IsOptional()
  sort?: CenterTrainerSortOrder = CenterTrainerSortOrder.DATE_DESC;
}
