export enum CenterTrainerAccountStatus {
  ACTIVE = 'ACTIVE',
  LOGIN_PENDING = 'LOGIN_PENDING',
  INACTIVE = 'INACTIVE',
  /**
   * 트레이너 본인 회원탈퇴 - center_trainers.status가 RESIGNED인 경우.
   * 센터가 직접 소속 해제(deleteTrainers)한 경우는 center_trainers도 같이 softDelete되어
   * 목록 조회 자체에서 제외되므로, 이 상태로 노출되는 경우는 회원탈퇴뿐임.
   */
  RESIGNED = 'RESIGNED',
}
