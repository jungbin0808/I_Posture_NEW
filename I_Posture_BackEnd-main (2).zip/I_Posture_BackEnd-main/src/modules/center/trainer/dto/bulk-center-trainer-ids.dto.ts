import { ApiProperty } from '@nestjs/swagger';
import { ArrayMinSize, IsArray, IsUUID } from 'class-validator';

export class BulkCenterTrainerIdsDto {
  @ApiProperty({ description: '트레이너 ID 목록 (users.id UUID)', type: [String] })
  @IsArray()
  @ArrayMinSize(1)
  @IsUUID('all', { each: true })
  trainerIds!: string[];
}
