export enum CenterTrainerLoginStatus {
  LOGIN_PENDING = 'LOGIN_PENDING',
  LOGIN_COMPLETED = 'LOGIN_COMPLETED',
}
