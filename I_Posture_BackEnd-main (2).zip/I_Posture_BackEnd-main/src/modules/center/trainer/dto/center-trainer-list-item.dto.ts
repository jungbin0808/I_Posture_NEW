import { ApiProperty } from '@nestjs/swagger';
import { CenterTrainerAccountStatus } from './center-trainer-account-status.enum';

export class CenterTrainerListItemDto {
  @ApiProperty({ description: '목록 번호' })
  no!: number;

  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너명' })
  name!: string;

  @ApiProperty({ description: '연락처' })
  phone!: string;

  @ApiProperty({ description: '아이디' })
  userId!: string;

  @ApiProperty({ description: '보유 회원수' })
  memberCount!: number;

  @ApiProperty({ description: '별점 지수 (5점 만점)' })
  starRating!: number;

  @ApiProperty({ description: '계정생성일 (ISO8601)' })
  createdAt!: string;

  @ApiProperty({ description: '계정 비활성화일 (ISO8601)', nullable: true })
  deactivatedAt?: string | null;

  @ApiProperty({ description: '데이터 소모량 (센터 트레이너 용량 풀 기준, bytes)' })
  dataUsage!: string;

  @ApiProperty({ description: '데이터 소모량 표시용', example: '4.9GB' })
  dataUsageLabel!: string;

  @ApiProperty({ description: '상태', enum: CenterTrainerAccountStatus })
  status!: CenterTrainerAccountStatus;

  @ApiProperty({ description: '상태 (한글)', example: '활성화' })
  statusLabel!: string;

  @ApiProperty({ description: '계정 완전 삭제 예정일 (KST, YYYY-MM-DD). 탈퇴 상태가 아니면 null', nullable: true })
  accountDeletionDate?: string | null;

  @ApiProperty({ description: '계정 완전 삭제까지 남은 일수(D-day). 탈퇴 상태가 아니면 null', nullable: true })
  daysUntilAccountDeletion?: number | null;
}
