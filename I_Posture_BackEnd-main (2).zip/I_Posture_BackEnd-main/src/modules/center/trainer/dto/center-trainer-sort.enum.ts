export enum CenterTrainerSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}
