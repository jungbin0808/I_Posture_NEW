import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsString } from 'class-validator';
import { SubscriptionStatus } from '../../../../database/entities/subscription.entity';

export class UpdateCenterTrainerMemberSubscriptionStatusDto {
  @ApiProperty({ description: '이용권 ID' })
  @IsString()
  @IsNotEmpty()
  subscriptionId!: string;

  @ApiProperty({ description: '변경할 상태 (정지: PAUSED, 활성화: ACTIVE)', enum: SubscriptionStatus })
  @IsEnum(SubscriptionStatus)
  @IsNotEmpty()
  status!: SubscriptionStatus;
}
