export enum CenterTrainerListFilter {
  ALL = 'ALL',
  ACTIVE = 'ACTIVE',
  LOGIN_PENDING = 'LOGIN_PENDING',
  INACTIVE = 'INACTIVE',
}
