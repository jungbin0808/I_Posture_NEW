import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsString, Length, MinLength } from 'class-validator';

export class CreateCenterTrainerDto {
  @ApiProperty({ description: '트레이너명' })
  @IsString()
  @Length(1, 50)
  name!: string;

  @ApiProperty({ description: '연락처' })
  @IsString()
  @Length(1, 65)
  phone!: string;

  @ApiProperty({ description: '아이디' })
  @IsString()
  @Length(4, 50)
  userId!: string;

  @ApiProperty({ description: '임시 비밀번호' })
  @IsString()
  @MinLength(4)
  tempPassword!: string;

  @ApiProperty({ description: '초대 보낼 메일' })
  @IsEmail()
  inviteEmail!: string;
}
