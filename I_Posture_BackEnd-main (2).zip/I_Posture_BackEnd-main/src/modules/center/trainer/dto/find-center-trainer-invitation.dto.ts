import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { CenterTrainerInvitationSortOrder } from './center-trainer-invitation-sort.enum';

export class FindCenterTrainerInvitationDto extends PaginationDto {
  @ApiProperty({
    description: '정렬 (초대 보낸 날짜 오름/내림차순)',
    enum: CenterTrainerInvitationSortOrder,
    required: false,
    default: CenterTrainerInvitationSortOrder.DATE_DESC,
  })
  @IsEnum(CenterTrainerInvitationSortOrder)
  @IsOptional()
  sort?: CenterTrainerInvitationSortOrder = CenterTrainerInvitationSortOrder.DATE_DESC;
}
