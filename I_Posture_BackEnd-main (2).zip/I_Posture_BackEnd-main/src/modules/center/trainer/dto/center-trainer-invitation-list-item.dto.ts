import { ApiProperty } from '@nestjs/swagger';
import { CenterTrainerLoginStatus } from './center-trainer-login-status.enum';

export class CenterTrainerInvitationListItemDto {
  @ApiProperty({ description: '목록 번호' })
  no!: number;

  @ApiProperty({ description: '초대 이력 ID' })
  invitationId!: string;

  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너명' })
  trainerName!: string;

  @ApiProperty({ description: '아이디' })
  userId!: string;

  @ApiProperty({ description: '임시 비밀번호' })
  tempPassword!: string;

  @ApiProperty({ description: '초대 보낸 메일' })
  inviteEmail!: string;

  @ApiProperty({ description: '초대 보낸 날짜 (ISO8601)' })
  invitedAt!: string;

  @ApiProperty({
    description: '상태 (로그인 대기 / 로그인 완료)',
    enum: CenterTrainerLoginStatus,
  })
  status!: CenterTrainerLoginStatus;
}
