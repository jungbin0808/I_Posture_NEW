import { ApiProperty } from '@nestjs/swagger';
import { ArrayMinSize, IsArray, IsString } from 'class-validator';

export class BulkCenterTrainerMemberIdsDto {
  @ApiProperty({ description: '회원 ID 목록 (users.id)', type: [String] })
  @IsArray()
  @ArrayMinSize(1)
  @IsString({ each: true })
  memberIds!: string[];
}
