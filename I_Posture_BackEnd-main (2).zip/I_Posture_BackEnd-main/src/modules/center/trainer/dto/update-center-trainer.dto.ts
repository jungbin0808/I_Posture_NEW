import { ApiProperty } from '@nestjs/swagger';
import { IsString, Length } from 'class-validator';

export class UpdateCenterTrainerDto {
  @ApiProperty({ description: '트레이너명' })
  @IsString()
  @Length(1, 50)
  name!: string;
}
