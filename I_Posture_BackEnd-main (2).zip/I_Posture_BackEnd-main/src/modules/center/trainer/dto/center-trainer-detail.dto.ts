import { ApiProperty } from '@nestjs/swagger';
import { CenterTrainerAccountStatus } from './center-trainer-account-status.enum';

export class CenterTrainerMeasurementCountsDto {
  @ApiProperty({ description: '체형 측정 건수' })
  body!: number;

  @ApiProperty({ description: '정밀 측정 건수' })
  precision!: number;

  @ApiProperty({ description: '모션 측정 건수' })
  motion!: number;

  @ApiProperty({ description: '인바디 측정 건수' })
  inbody!: number;
}

export class CenterTrainerMonthlyMetricItemDto {
  @ApiProperty({ description: '건수' })
  count!: number;

  @ApiProperty({ description: '비율 (%)' })
  rate!: number;
}

export class CenterTrainerMonthlyManagementDto {
  @ApiProperty({ description: '당월 총 상담 건수' })
  totalConsultations!: number;

  @ApiProperty({ description: '재등록' })
  regRenew!: CenterTrainerMonthlyMetricItemDto;

  @ApiProperty({ description: '신규등록' })
  regNew!: CenterTrainerMonthlyMetricItemDto;

  @ApiProperty({ description: '미등록' })
  noSale!: CenterTrainerMonthlyMetricItemDto;

  @ApiProperty({ description: '체험수업 등록 전환 (전환 월 기준, 체험은 이전 달이어도 당월 전환 시 당월 집계)' })
  trialConversion!: CenterTrainerMonthlyMetricItemDto;
}

export class CenterTrainerDetailDto {
  @ApiProperty({ description: '트레이너 ID (UUID)' })
  trainerId!: string;

  @ApiProperty({ description: '트레이너명' })
  name!: string;

  @ApiProperty({ description: '상태', enum: CenterTrainerAccountStatus })
  status!: CenterTrainerAccountStatus;

  @ApiProperty({ description: '상태 (한글)', example: '활성화' })
  statusLabel!: string;

  @ApiProperty({ description: '계정 완전 삭제 예정일 (KST, YYYY-MM-DD). 탈퇴 상태가 아니면 null', nullable: true })
  accountDeletionDate?: string | null;

  @ApiProperty({ description: '계정 완전 삭제까지 남은 일수(D-day). 탈퇴 상태가 아니면 null', nullable: true })
  daysUntilAccountDeletion?: number | null;

  @ApiProperty({ description: '아이디' })
  userId!: string;

  @ApiProperty({ description: '연락처' })
  phone!: string;

  @ApiProperty({ description: '계정생성일 (ISO8601)' })
  createdAt!: string;

  @ApiProperty({ description: '보유 회원수' })
  memberCount!: number;

  @ApiProperty({ description: '데이터 소모량 (bytes)' })
  dataUsage!: string;

  @ApiProperty({ description: '데이터 소모량 표시용', example: '4.9GB' })
  dataUsageLabel!: string;

  @ApiProperty({ description: '누적 측정 건수 (회원 이관 시에도 실제로 측정을 수행한 트레이너 실적으로 귀속)' })
  measurementCounts!: CenterTrainerMeasurementCountsDto;

  @ApiProperty({ description: '당월 회원 관리 지표 (신규등록/재등록/미등록은 회원 이관 시에도 실제로 상담을 진행한 트레이너 실적으로 귀속 — 체험수업 등록 전환율만 예외적으로 현재 trainer_id 기준)' })
  monthlyManagement!: CenterTrainerMonthlyManagementDto;
}
