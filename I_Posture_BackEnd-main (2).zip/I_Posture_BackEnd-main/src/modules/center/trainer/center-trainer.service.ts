import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { Brackets, DataSource, In, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import * as bcrypt from 'bcrypt';
import { CenterEntity } from '../../../database/entities/center.entity';
import {
  CenterTrainerEntity,
  CenterTrainerStatus,
} from '../../../database/entities/center-trainer.entity';
import { CenterTrainerInvitationEntity } from '../../../database/entities/center-trainer-invitation.entity';
import { RefreshTokenEntity } from '../../../database/entities/refresh-token.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../../database/entities/trainer-user.entity';
import {
  AccountStatus,
  MemberType,
  PaymentStatus,
  UserEntity,
  UserType,
} from '../../../database/entities/user.entity';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { EmailService } from '../../email/email.service';
import { CapacityService } from '../../capacity/capacity.service';
import { ALL_NOTIFICATIONS_ON } from '../../user/helpers/notification-settings.helper';
import { FindCenterTrainerDto } from './dto/find-center-trainer.dto';
import { CenterTrainerListItemDto } from './dto/center-trainer-list-item.dto';
import { CreateCenterTrainerDto } from './dto/create-center-trainer.dto';
import { FindCenterTrainerInvitationDto } from './dto/find-center-trainer-invitation.dto';
import { CenterTrainerInvitationListItemDto } from './dto/center-trainer-invitation-list-item.dto';
import { BulkCenterTrainerIdsDto } from './dto/bulk-center-trainer-ids.dto';
import { CenterTrainerDetailDto } from './dto/center-trainer-detail.dto';
import { UpdateCenterTrainerDto } from './dto/update-center-trainer.dto';
import { CenterTrainerInvitationSortOrder } from './dto/center-trainer-invitation-sort.enum';
import { CenterTrainerLoginStatus } from './dto/center-trainer-login-status.enum';
import { CenterTrainerSortOrder } from './dto/center-trainer-sort.enum';
import { CenterTrainerListFilter } from './dto/center-trainer-list-filter.enum';
import {
  calculateAccountDeletionInfo,
  resolveCenterTrainerAccountStatus,
  toCenterTrainerAccountStatusLabel,
} from './helpers/center-trainer-account-status.helper';
import { CenterTrainerAccountStatus } from './dto/center-trainer-account-status.enum';
import { formatBytesDisplay } from '../../../common/utils/capacity.util';
import {
  calcTrialConversionRatePercent,
  fetchTrialConversionMetrics,
} from '../../consultation-log/helpers/trial-conversion-metrics.helper';
import {
  fetchTrainerConsultationStats,
  fetchTrainerMeasurementCountsWithTransferCredit,
} from '../../consultation-log/helpers/trainer-transfer-attribution.helper';

@Injectable()
export class CenterTrainerService {
  constructor(
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(CenterTrainerInvitationEntity)
    private readonly invitationRepo: Repository<CenterTrainerInvitationEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(RefreshTokenEntity)
    private readonly refreshTokenRepo: Repository<RefreshTokenEntity>,
    @InjectDataSource()
    private readonly dataSource: DataSource,
    private readonly emailService: EmailService,
    private readonly capacityService: CapacityService,
  ) {}

  async findTrainers(
    ownerId: string,
    dto: FindCenterTrainerDto,
  ): Promise<IPageData<CenterTrainerListItemDto>> {
    const {
      page = 1,
      limit = 10,
      search,
      sort = CenterTrainerSortOrder.DATE_DESC,
      filter = CenterTrainerListFilter.ALL,
    } = dto;
    const center = await this.resolveCenter(ownerId);

    const queryBuilder = this.centerTrainerRepo.createQueryBuilder('ct')
      // innerJoin(UserEntity, ...)는 TypeORM이 trainer.deleted_at IS NULL을 자동으로 붙여서,
      // withDeleted() 없이는 회원탈퇴(소프트삭제)한 트레이너가 목록에서 통째로 사라짐
      .withDeleted()
      .innerJoin(UserEntity, 'trainer', 'trainer.id = ct.trainer_id')
      .where('ct.center_id = :centerId', { centerId: center.id })
      .andWhere('ct.deleted_at IS NULL')
      .select('trainer.id', 'trainerId')
      .addSelect('trainer.name', 'name')
      .addSelect('trainer.phone', 'phone')
      .addSelect('trainer.user_id', 'userId')
      .addSelect('trainer.created_at', 'createdAt')
      .addSelect('trainer.deleted_at', 'trainerDeletedAt')
      .addSelect('ct.deactivated_at', 'deactivatedAt')
      .addSelect('ct.status', 'centerTrainerStatus')
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from(TrainerUserEntity, 'tu')
          .where('tu.trainer_id = trainer.id')
          .andWhere('tu.status = :tuStatus')
          .andWhere('tu.deleted_at IS NULL'),
        'memberCount',
      )
      .addSelect((subQuery) =>
        subQuery
          .select('COALESCE(ROUND(AVG(a.rating), 1), 0)')
          .from('qna_answers', 'a')
          .where('a.author_id = trainer.id')
          .andWhere('a.is_accepted = true')
          .andWhere('a.rating IS NOT NULL'),
        'starRating',
      )
      .addSelect((subQuery) =>
        subQuery
          .select('COALESCE(ctp.used_capacity, 0)')
          .from('center_trainer_capacity_pools', 'ctp')
          .where('ctp.trainer_id = ct.trainer_id')
          .andWhere('ctp.center_id = ct.center_id'),
        'dataUsage',
      )
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from(RefreshTokenEntity, 'rt')
          .where('rt.user_id = trainer.id'),
        'loginCount',
      )
      .setParameter('tuStatus', TrainerUserStatus.ACTIVE);

    if (search) {
      const keyword = `%${search}%`;
      queryBuilder.andWhere(new Brackets((qb) => {
        qb.where('trainer.name LIKE :keyword', { keyword })
          .orWhere('trainer.user_id LIKE :keyword', { keyword })
          .orWhere('trainer.phone LIKE :keyword', { keyword });
      }));
    }

    if (filter === CenterTrainerListFilter.ACTIVE) {
      queryBuilder
        .andWhere('ct.deactivated_at IS NULL')
        .andWhere('EXISTS (SELECT 1 FROM refresh_tokens rt_filter WHERE rt_filter.user_id = trainer.id)');
    } else if (filter === CenterTrainerListFilter.LOGIN_PENDING) {
      queryBuilder
        .andWhere('ct.deactivated_at IS NULL')
        .andWhere('NOT EXISTS (SELECT 1 FROM refresh_tokens rt_filter WHERE rt_filter.user_id = trainer.id)');
    } else if (filter === CenterTrainerListFilter.INACTIVE) {
      queryBuilder.andWhere('ct.deactivated_at IS NOT NULL');
    }

    const sortDirection = sort === CenterTrainerSortOrder.DATE_ASC ? 'ASC' : 'DESC';
    queryBuilder.orderBy('trainer.created_at', sortDirection);
    queryBuilder.addOrderBy('trainer.id', sortDirection);

    const total = await queryBuilder.getCount();
    const rows = await queryBuilder
      .offset((page - 1) * limit)
      .limit(limit)
      .getRawMany<{
        trainerId: string;
        name: string;
        phone: string;
        userId: string;
        createdAt: string;
        trainerDeletedAt: string | null;
        deactivatedAt: string | null;
        centerTrainerStatus: CenterTrainerStatus;
        memberCount: string;
        starRating: string;
        dataUsage: string;
        loginCount: string;
      }>();

    const items: CenterTrainerListItemDto[] = rows.map((row, index) => {
      const accountStatus = resolveCenterTrainerAccountStatus(
        row.centerTrainerStatus,
        row.deactivatedAt,
        Number(row.loginCount),
      );
      const deletionInfo = accountStatus === CenterTrainerAccountStatus.RESIGNED
        ? calculateAccountDeletionInfo(row.trainerDeletedAt)
        : null;

      return {
        no: (page - 1) * limit + index + 1,
        trainerId: row.trainerId,
        name: row.name,
        phone: row.phone,
        userId: row.userId,
        memberCount: Number(row.memberCount),
        starRating: Number(row.starRating),
        createdAt: new Date(row.createdAt).toISOString(),
        deactivatedAt: row.deactivatedAt ? new Date(row.deactivatedAt).toISOString() : null,
        dataUsage: row.dataUsage ?? '0',
        dataUsageLabel: formatBytesDisplay(row.dataUsage ?? '0'),
        status: accountStatus,
        statusLabel: toCenterTrainerAccountStatusLabel(accountStatus),
        accountDeletionDate: deletionInfo?.deletionDate ?? null,
        daysUntilAccountDeletion: deletionInfo?.daysUntilDeletion ?? null,
      };
    });

    return { items, paging: buildPaging(total, limit, page) };
  }

  async findTrainerDetail(
    ownerId: string,
    trainerId: string,
  ): Promise<CenterTrainerDetailDto> {
    const center = await this.resolveCenter(ownerId);
    await this.resolveAffiliations(ownerId, [trainerId]);

    const [row] = await this.centerTrainerRepo.createQueryBuilder('ct')
      .withDeleted()
      .innerJoin(UserEntity, 'trainer', 'trainer.id = ct.trainer_id')
      .where('ct.center_id = :centerId', { centerId: center.id })
      .andWhere('ct.trainer_id = :trainerId', { trainerId })
      .andWhere('ct.deleted_at IS NULL')
      .select('trainer.id', 'trainerId')
      .addSelect('trainer.name', 'name')
      .addSelect('trainer.phone', 'phone')
      .addSelect('trainer.user_id', 'userId')
      .addSelect('trainer.created_at', 'createdAt')
      .addSelect('trainer.deleted_at', 'trainerDeletedAt')
      .addSelect('ct.deactivated_at', 'deactivatedAt')
      .addSelect('ct.status', 'centerTrainerStatus')
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from(TrainerUserEntity, 'tu')
          .where('tu.trainer_id = trainer.id')
          .andWhere('tu.status = :tuStatus')
          .andWhere('tu.deleted_at IS NULL'),
        'memberCount',
      )
      .addSelect((subQuery) =>
        subQuery
          .select('COALESCE(ctp.used_capacity, 0)')
          .from('center_trainer_capacity_pools', 'ctp')
          .where('ctp.trainer_id = ct.trainer_id')
          .andWhere('ctp.center_id = ct.center_id'),
        'dataUsage',
      )
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from(RefreshTokenEntity, 'rt')
          .where('rt.user_id = trainer.id'),
        'loginCount',
      )
      .setParameter('tuStatus', TrainerUserStatus.ACTIVE)
      .getRawMany<{
        trainerId: string;
        name: string;
        phone: string;
        userId: string;
        createdAt: string;
        trainerDeletedAt: string | null;
        deactivatedAt: string | null;
        centerTrainerStatus: CenterTrainerStatus;
        memberCount: string;
        dataUsage: string;
        loginCount: string;
      }>();

    if (!row) {
      throw new NotFoundException('센터 소속 트레이너를 찾을 수 없습니다.');
    }

    const accountStatus = resolveCenterTrainerAccountStatus(
      row.centerTrainerStatus,
      row.deactivatedAt,
      Number(row.loginCount),
    );
    const deletionInfo = accountStatus === CenterTrainerAccountStatus.RESIGNED
      ? calculateAccountDeletionInfo(row.trainerDeletedAt)
      : null;
    const measurementCounts = await this.fetchMeasurementCounts(trainerId);
    const monthlyManagement = await this.fetchMonthlyManagement(trainerId);

    return {
      trainerId: row.trainerId,
      name: row.name,
      phone: row.phone,
      userId: row.userId,
      createdAt: new Date(row.createdAt).toISOString(),
      memberCount: Number(row.memberCount),
      dataUsage: row.dataUsage ?? '0',
      dataUsageLabel: formatBytesDisplay(row.dataUsage ?? '0'),
      status: accountStatus,
      statusLabel: toCenterTrainerAccountStatusLabel(accountStatus),
      accountDeletionDate: deletionInfo?.deletionDate ?? null,
      daysUntilAccountDeletion: deletionInfo?.daysUntilDeletion ?? null,
      measurementCounts,
      monthlyManagement,
    };
  }

  @Transactional()
  async updateTrainerName(
    ownerId: string,
    trainerId: string,
    dto: UpdateCenterTrainerDto,
  ): Promise<{ trainerId: string; name: string }> {
    const center = await this.resolveCenter(ownerId);
    await this.resolveAffiliations(ownerId, [trainerId]);

    const trainer = await this.userRepo.findOne({
      where: { id: trainerId, userType: UserType.C_TRAINER },
    });
    if (!trainer) {
      throw new NotFoundException('트레이너를 찾을 수 없습니다.');
    }

    trainer.name = dto.name;
    await this.userRepo.save(trainer);

    await this.invitationRepo
      .createQueryBuilder()
      .update(CenterTrainerInvitationEntity)
      .set({ trainerName: dto.name })
      .where('center_id = :centerId', { centerId: center.id })
      .andWhere('trainer_id = :trainerId', { trainerId })
      .execute();

    return { trainerId, name: trainer.name };
  }

  async ensureAffiliatedTrainer(ownerId: string, trainerId: string): Promise<UserEntity> {
    return this.resolveAffiliatedTrainer(ownerId, trainerId);
  }

  async findInvitations(
    ownerId: string,
    dto: FindCenterTrainerInvitationDto,
  ): Promise<IPageData<CenterTrainerInvitationListItemDto>> {
    const {
      page = 1,
      limit = 10,
      sort = CenterTrainerInvitationSortOrder.DATE_DESC,
    } = dto;
    const center = await this.resolveCenter(ownerId);

    const queryBuilder = this.invitationRepo.createQueryBuilder('invitation')
      .where('invitation.center_id = :centerId', { centerId: center.id })
      .select('invitation.id', 'invitationId')
      .addSelect('invitation.trainer_id', 'trainerId')
      .addSelect('invitation.trainer_name', 'trainerName')
      .addSelect('invitation.login_user_id', 'userId')
      .addSelect('invitation.temp_password', 'tempPassword')
      .addSelect('invitation.invite_email', 'inviteEmail')
      .addSelect('invitation.invited_at', 'invitedAt')
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from(RefreshTokenEntity, 'rt')
          .where('rt.user_id = invitation.trainer_id'),
        'loginCount',
      );

    const sortDirection = sort === CenterTrainerInvitationSortOrder.DATE_ASC ? 'ASC' : 'DESC';
    queryBuilder.orderBy('invitation.invited_at', sortDirection);
    queryBuilder.addOrderBy('invitation.id', sortDirection);

    const total = await queryBuilder.getCount();
    const rows = await queryBuilder
      .offset((page - 1) * limit)
      .limit(limit)
      .getRawMany<{
        invitationId: string;
        trainerId: string;
        trainerName: string;
        userId: string;
        tempPassword: string;
        inviteEmail: string;
        invitedAt: string;
        loginCount: string;
      }>();

    const items: CenterTrainerInvitationListItemDto[] = rows.map((row, index) => ({
      no: (page - 1) * limit + index + 1,
      invitationId: row.invitationId,
      trainerId: row.trainerId,
      trainerName: row.trainerName,
      userId: row.userId,
      tempPassword: row.tempPassword,
      inviteEmail: row.inviteEmail,
      invitedAt: new Date(row.invitedAt).toISOString(),
      status: Number(row.loginCount) > 0
        ? CenterTrainerLoginStatus.LOGIN_COMPLETED
        : CenterTrainerLoginStatus.LOGIN_PENDING,
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  @Transactional()
  async createTrainer(
    ownerId: string,
    dto: CreateCenterTrainerDto,
  ): Promise<{ trainerId: string; invitationId: string; invitedAt: string }> {
    const center = await this.resolveCenter(ownerId);

    const existingById = await this.userRepo.findOne({
      where: { userId: dto.userId },
      withDeleted: true,
    });
    if (existingById) {
      throw new ConflictException('이미 사용 중인 아이디입니다.');
    }

    const existingByEmail = await this.userRepo.findOne({
      where: { email: dto.inviteEmail },
      withDeleted: true,
    });
    if (existingByEmail) {
      throw new ConflictException('이미 사용 중인 이메일입니다.');
    }

    const hashed = await bcrypt.hash(dto.tempPassword.toLowerCase(), 10);
    const hiredAt = new Date().toISOString().slice(0, 10);

    const savedTrainer = await this.userRepo.save(
      this.userRepo.create({
        userId: dto.userId,
        email: dto.inviteEmail,
        password: hashed,
        name: dto.name,
        phone: dto.phone,
        affiliationName: center.name,
        userType: UserType.C_TRAINER,
        memberType: MemberType.APP,
        accountStatus: AccountStatus.ACTIVE,
        paymentStatus: PaymentStatus.UNPAID,
        ...ALL_NOTIFICATIONS_ON,
      }),
    );

    await this.centerTrainerRepo.save(
      this.centerTrainerRepo.create({
        centerId: center.id,
        trainerId: savedTrainer.id,
        status: CenterTrainerStatus.WORKING,
        hiredAt,
      }),
    );
    await this.capacityService.ensureCenterTrainerCapacityPool(center.id, savedTrainer.id);

    const invitedAt = new Date();
    const invitation = await this.invitationRepo.save(
      this.invitationRepo.create({
        centerId: center.id,
        trainerId: savedTrainer.id,
        trainerName: dto.name,
        loginUserId: dto.userId,
        tempPassword: dto.tempPassword,
        inviteEmail: dto.inviteEmail,
        invitedAt,
      }),
    );

    await this.emailService.sendTrainerInviteEmail({
      to: dto.inviteEmail,
      trainerName: dto.name,
      centerName: center.name,
      userId: dto.userId,
      tempPassword: dto.tempPassword,
    });

    return {
      trainerId: savedTrainer.id,
      invitationId: invitation.id,
      invitedAt: invitation.invitedAt.toISOString(),
    };
  }

  async sendInvitationEmail(
    ownerId: string,
    invitationId: string,
  ): Promise<{ invitationId: string; invitedAt: string }> {
    const center = await this.resolveCenter(ownerId);

    const invitation = await this.invitationRepo.findOne({
      where: { id: invitationId, centerId: center.id },
    });
    if (!invitation) {
      throw new NotFoundException('초대 내역을 찾을 수 없습니다.');
    }

    const affiliation = await this.centerTrainerRepo.findOne({
      where: { centerId: center.id, trainerId: invitation.trainerId },
    });
    if (!affiliation) {
      throw new BadRequestException('삭제되었거나 소속이 해제된 트레이너입니다.');
    }

    const loginCount = await this.refreshTokenRepo.count({
      where: { userId: invitation.trainerId },
    });
    if (loginCount > 0) {
      throw new BadRequestException('이미 로그인한 트레이너에게는 초대 메일을 다시 보낼 수 없습니다.');
    }

    await this.emailService.sendTrainerInviteEmail({
      to: invitation.inviteEmail,
      trainerName: invitation.trainerName,
      centerName: center.name,
      userId: invitation.loginUserId,
      tempPassword: invitation.tempPassword,
    });

    invitation.invitedAt = new Date();
    await this.invitationRepo.save(invitation);

    return {
      invitationId: invitation.id,
      invitedAt: invitation.invitedAt.toISOString(),
    };
  }

  @Transactional()
  async deactivateTrainers(
    ownerId: string,
    dto: BulkCenterTrainerIdsDto,
  ): Promise<{ success: true; affected: number }> {
    const affiliations = await this.resolveAffiliations(ownerId, dto.trainerIds);
    const alreadyInactive = affiliations.filter((affiliation) => affiliation.deactivatedAt);

    if (alreadyInactive.length > 0) {
      throw new BadRequestException('이미 비활성화 상태인 트레이너가 포함되어 있습니다.');
    }

    const affiliationIds = affiliations.map((affiliation) => affiliation.id);
    const trainerIds = affiliations.map((affiliation) => affiliation.trainerId);
    const deactivatedAt = new Date();

    await this.centerTrainerRepo
      .createQueryBuilder()
      .update(CenterTrainerEntity)
      .set({ deactivatedAt })
      .where('id IN (:...affiliationIds)', { affiliationIds })
      .execute();

    await this.revokeTrainerTokens(trainerIds);

    return { success: true, affected: affiliations.length };
  }

  @Transactional()
  async activateTrainers(
    ownerId: string,
    dto: BulkCenterTrainerIdsDto,
  ): Promise<{ success: true; affected: number }> {
    const affiliations = await this.resolveAffiliations(ownerId, dto.trainerIds);
    const alreadyActive = affiliations.filter((affiliation) => !affiliation.deactivatedAt);

    if (alreadyActive.length > 0) {
      throw new BadRequestException('이미 활성화 상태인 트레이너가 포함되어 있습니다.');
    }

    const affiliationIds = affiliations.map((affiliation) => affiliation.id);

    await this.centerTrainerRepo
      .createQueryBuilder()
      .update(CenterTrainerEntity)
      .set({ deactivatedAt: () => 'NULL' })
      .where('id IN (:...affiliationIds)', { affiliationIds })
      .execute();

    return { success: true, affected: affiliations.length };
  }

  @Transactional()
  async deleteTrainers(
    ownerId: string,
    dto: BulkCenterTrainerIdsDto,
  ): Promise<{ success: true; affected: number }> {
    const affiliations = await this.resolveAffiliations(ownerId, dto.trainerIds);
    const affiliationIds = affiliations.map((affiliation) => affiliation.id);
    const trainerIds = affiliations.map((affiliation) => affiliation.trainerId);
    const resignedAt = new Date().toISOString().slice(0, 10);

    await this.revokeTrainerTokens(trainerIds);

    await this.centerTrainerRepo
      .createQueryBuilder()
      .update(CenterTrainerEntity)
      .set({
        status: CenterTrainerStatus.RESIGNED,
        resignedAt,
      })
      .where('id IN (:...affiliationIds)', { affiliationIds })
      .execute();

    await this.centerTrainerRepo.softDelete(affiliationIds);

    return { success: true, affected: affiliations.length };
  }

  private async resolveAffiliatedTrainer(
    ownerId: string,
    trainerId: string,
  ): Promise<UserEntity> {
    await this.resolveAffiliations(ownerId, [trainerId]);

    const trainer = await this.userRepo.findOne({
      where: { id: trainerId, userType: UserType.C_TRAINER },
    });
    if (!trainer) {
      throw new NotFoundException('트레이너를 찾을 수 없습니다.');
    }

    return trainer;
  }

  private async resolveAffiliations(
    ownerId: string,
    trainerIds: string[],
  ): Promise<CenterTrainerEntity[]> {
    const center = await this.resolveCenter(ownerId);
    const uniqueTrainerIds = [...new Set(trainerIds)];

    const affiliations = await this.centerTrainerRepo.find({
      where: { centerId: center.id, trainerId: In(uniqueTrainerIds) },
    });

    if (affiliations.length !== uniqueTrainerIds.length) {
      throw new NotFoundException('센터 소속 트레이너를 찾을 수 없습니다.');
    }

    return affiliations;
  }

  private async revokeTrainerTokens(trainerIds: string | string[]): Promise<void> {
    const ids = Array.isArray(trainerIds) ? trainerIds : [trainerIds];

    if (ids.length === 0) {
      return;
    }

    await this.refreshTokenRepo.update(
      { userId: In(ids), revoked: false },
      { revoked: true },
    );
  }

  private async resolveCenter(ownerId: string): Promise<CenterEntity> {
    const center = await this.centerRepo.findOne({ where: { ownerId } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }

    return center;
  }

  private async fetchMeasurementCounts(trainerId: string): Promise<{
    body: number;
    precision: number;
    motion: number;
    inbody: number;
  }> {
    return fetchTrainerMeasurementCountsWithTransferCredit(this.dataSource, trainerId);
  }

  private async fetchMonthlyManagement(
    trainerId: string,
  ): Promise<CenterTrainerDetailDto['monthlyManagement']> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 1);

    // 이관 시 담당이 바뀐 상담일지도 있어, 실제 상담을 진행한 트레이너 기준으로 보정된 통계를 사용
    const currentMonth = await fetchTrainerConsultationStats(
      this.dataSource,
      trainerId,
      startOfMonth,
      nextMonth,
    );

    const { trialMemberCount, trialConversionCount } = await fetchTrialConversionMetrics(
      this.dataSource,
      [trainerId],
      startOfMonth,
      nextMonth,
    );

    const totalConsultations = currentMonth.total;
    const regNew = currentMonth.regNew;
    const regRenew = currentMonth.regRenew;
    const noSale = currentMonth.noSale;

    const calcRate = (count: number): number =>
      totalConsultations > 0 ? Math.round((count / totalConsultations) * 1000) / 10 : 0;

    return {
      totalConsultations,
      regRenew: { count: regRenew, rate: calcRate(regRenew) },
      regNew: { count: regNew, rate: calcRate(regNew) },
      noSale: { count: noSale, rate: calcRate(noSale) },
      trialConversion: {
        count: trialConversionCount,
        rate: calcTrialConversionRatePercent(
          trialConversionCount,
          trialMemberCount,
          1,
        ),
      },
    };
  }
}
