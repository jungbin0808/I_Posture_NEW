import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CenterCommonModule } from '../common/center-common.module';
import { CapacityModule } from '../../capacity/capacity.module';
import { EmailModule } from '../../email/email.module';
import { ScheduleModule } from '../../schedule/schedule.module';
import { ScheduleGroupModule } from '../../schedule-group/schedule-group.module';
import { SequenceModule } from '../../sequence/sequence.module';
import { SequenceGroupModule } from '../../sequence-group/sequence-group.module';
import { ExerciseModule } from '../../exercise/exercise.module';
import { QnaModule } from '../../qna/qna.module';
import { UserModule } from '../../user/user.module';
import { BodyReportModule } from '../../body-report/body-report.module';
import { PrecisionReportModule } from '../../precision-report/precision-report.module';
import { MotionAnalysisModule } from '../../motion-analysis/motion-analysis.module';
import { InbodyModule } from '../../inbody/inbody.module';
import { ConsultationLogModule } from '../../consultation-log/consultation-log.module';
import { WorkoutLogModule } from '../../workout-log/workout-log.module';
import { FoodLogModule } from '../../food-log/food-log.module';
import { ReportComparisonModule } from '../../report-comparison/report-comparison.module';
import { MeasurementReportModule } from '../../measurement-report/measurement-report.module';
import { SubscriptionModule } from '../../subscription/subscription.module';
import { DashboardModule } from '../../dashboard/dashboard.module';
import { CustomExerciseModule } from '../../custom-exercise/custom-exercise.module';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { CenterTrainerInvitationEntity } from '../../../database/entities/center-trainer-invitation.entity';
import { RefreshTokenEntity } from '../../../database/entities/refresh-token.entity';
import { TrainerUserEntity } from '../../../database/entities/trainer-user.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { CenterTrainerController } from './center-trainer.controller';
import { CenterTrainerViewController } from './center-trainer-view.controller';
import { CenterTrainerService } from './center-trainer.service';
import { CenterTrainerViewService } from './center-trainer-view.service';

@Module({
  imports: [
    CenterCommonModule,
    CapacityModule,
    EmailModule,
    ScheduleModule,
    ScheduleGroupModule,
    SequenceModule,
    SequenceGroupModule,
    ExerciseModule,
    QnaModule,
    UserModule,
    BodyReportModule,
    PrecisionReportModule,
    MotionAnalysisModule,
    InbodyModule,
    ConsultationLogModule,
    WorkoutLogModule,
    FoodLogModule,
    ReportComparisonModule,
    MeasurementReportModule,
    SubscriptionModule,
    DashboardModule,
    CustomExerciseModule,
    TypeOrmModule.forFeature([
      CenterEntity,
      CenterTrainerEntity,
      CenterTrainerInvitationEntity,
      RefreshTokenEntity,
      TrainerUserEntity,
      UserEntity,
    ]),
  ],
  controllers: [CenterTrainerController, CenterTrainerViewController],
  providers: [CenterTrainerService, CenterTrainerViewService],
})
export class CenterTrainerModule {}
