import { Module } from '@nestjs/common';
import { CenterCommonModule } from '../common/center-common.module';
import { CapacityModule } from '../../capacity/capacity.module';
import { CenterCapacityController } from './center-capacity.controller';

@Module({
  imports: [CenterCommonModule, CapacityModule],
  controllers: [CenterCapacityController],
})
export class CenterCapacityModule {}
