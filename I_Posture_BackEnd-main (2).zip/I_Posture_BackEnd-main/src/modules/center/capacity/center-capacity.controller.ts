import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CapacityService } from '../../capacity/capacity.service';
import { CenterCapacityResponseDto } from '../../capacity/dto/center-capacity-response.dto';

@ApiTags('Center Capacity')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/capacity')
export class CenterCapacityController {
  constructor(private readonly capacityService: CapacityService) {}

  @ApiOperation({ summary: '센터 용량 정보 조회 (센터 웹)' })
  @Get()
  async getCenterCapacity(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<CenterCapacityResponseDto>> {
    const capacityInfo = await this.capacityService.getCenterCapacity(req.user);
    return SuccessResponse(capacityInfo);
  }
}
