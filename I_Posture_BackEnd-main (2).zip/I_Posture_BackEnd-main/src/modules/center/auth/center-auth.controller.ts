import { Body, Controller, Post, Req, Res, UseGuards } from '@nestjs/common';
import { ApiBody, ApiOperation, ApiTags } from '@nestjs/swagger';
import { Request, Response } from 'express';
import { CenterAuthService } from './center-auth.service';
import { ResetPasswordDto, SendOtpDto, TokenResponseDto, VerifyOtpDto } from '../../auth/auth.dto';
import { RegisterCenterDto } from './dto/register-center.dto';
import { CenterLoginDto } from './dto/center-login.dto';
import { CheckCenterEmailDto } from './dto/check-center-email.dto';
import { CheckCenterEmailResponseDto } from './dto/check-center-email-response.dto';
import { RefreshTokenGuard } from '../../auth/refresh-token.guard';

const CENTER_AUTH_COOKIE_PATH = '/api/v1/center/auth';

@ApiTags('Center Auth')
@Controller('center/auth')
export class CenterAuthController {
  constructor(private readonly centerAuthService: CenterAuthService) {}

  @ApiOperation({ summary: '센터 웹 로그인 (센터 오너 CENTER 전용, 아이디 또는 이메일)' })
  @ApiBody({ type: CenterLoginDto })
  @Post('login')
  async login(
    @Body() dto: CenterLoginDto,
    @Res({ passthrough: true }) res: Response,
  ): Promise<Omit<TokenResponseDto, 'refreshToken'>> {
    const tokens = await this.centerAuthService.login(dto);
    res.cookie('refreshToken', tokens.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: CENTER_AUTH_COOKIE_PATH,
    });
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  @ApiOperation({ summary: '센터 오너 회원가입' })
  @Post('register')
  async register(
    @Body() dto: RegisterCenterDto,
    @Res({ passthrough: true }) res: Response,
  ): Promise<Omit<TokenResponseDto, 'refreshToken'>> {
    const tokens = await this.centerAuthService.register(dto);
    res.cookie('refreshToken', tokens.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: CENTER_AUTH_COOKIE_PATH,
    });
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  @ApiOperation({ summary: '센터 웹 토큰 갱신' })
  @UseGuards(RefreshTokenGuard)
  @Post('refresh')
  async refresh(
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const user = req.user as {
      userId: string;
      jti: string;
      refreshToken: string;
      iat: number;
      exp: number;
    };

    const tokens = await this.centerAuthService.refreshTokens(
      user.userId,
      user.jti,
      user.refreshToken,
      user.iat,
      user.exp,
    );

    res.cookie('refreshToken', tokens.refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'lax',
      path: CENTER_AUTH_COOKIE_PATH,
    });

    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
    };
  }

  @ApiOperation({ summary: '센터 웹 로그아웃' })
  @UseGuards(RefreshTokenGuard)
  @Post('logout')
  async logout(
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const user = req.user as {
      userId: string;
      jti: string;
      refreshToken: string;
      iat: number;
      exp: number;
    };

    await this.centerAuthService.logout(user.userId, user.jti);
    res.clearCookie('refreshToken', { path: CENTER_AUTH_COOKIE_PATH });

    return { success: true };
  }

  @ApiOperation({ summary: '센터 웹 회원가입 전 이메일 중복 확인 (탈퇴 계정 포함 사용 불가)' })
  @Post('email/check')
  async checkEmail(@Body() dto: CheckCenterEmailDto): Promise<CheckCenterEmailResponseDto> {
    return this.centerAuthService.checkEmailAvailability(dto.email);
  }

  @ApiOperation({ summary: '센터 웹 이메일 인증 코드 발송' })
  @Post('email/send-otp')
  async sendOtp(@Body() dto: SendOtpDto): Promise<{ success: boolean; code?: string }> {
    const result = await this.centerAuthService.sendOtp(dto);
    return { success: true, ...result };
  }

  @ApiOperation({ summary: '센터 웹 이메일 인증 코드 확인' })
  @Post('email/verify-otp')
  async verifyOtp(@Body() dto: VerifyOtpDto) {
    return this.centerAuthService.verifyOtp(dto);
  }

  @ApiOperation({ summary: '센터 웹 아이디 찾기' })
  @Post('find-id')
  async findId(@Body() body: { verifiedToken: string }) {
    return this.centerAuthService.findId(body.verifiedToken);
  }

  @ApiOperation({ summary: '센터 웹 비밀번호 재설정' })
  @Post('reset-password')
  async resetPassword(@Body() dto: ResetPasswordDto): Promise<{ success: boolean }> {
    await this.centerAuthService.resetPassword(dto);
    return { success: true };
  }
}
