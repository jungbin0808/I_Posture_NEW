import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AuthModule } from '../../auth/auth.module';
import { UserEntity } from '../../../database/entities/user.entity';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterCapacityPoolEntity } from '../../../database/entities/center-capacity-pool.entity';
import { CenterAuthController } from './center-auth.controller';
import { CenterAuthService } from './center-auth.service';

@Module({
  imports: [
    AuthModule,
    TypeOrmModule.forFeature([UserEntity, CenterEntity, CenterCapacityPoolEntity]),
  ],
  controllers: [CenterAuthController],
  providers: [CenterAuthService],
})
export class CenterAuthModule {}
