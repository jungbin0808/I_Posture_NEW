import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, MinLength } from 'class-validator';

export class CenterLoginDto {
  @ApiProperty({ description: '로그인 아이디', required: false, example: 'center01' })
  @IsString()
  @IsOptional()
  userId?: string;

  @ApiProperty({ description: '이메일 (아이디 대신 사용 가능)', required: false, example: 'center@example.com' })
  @IsString()
  @IsOptional()
  email?: string;

  @ApiProperty({ description: '비밀번호', minLength: 4 })
  @IsString()
  @MinLength(4)
  password!: string;

  @ApiProperty({ description: 'FCM 토큰', required: false })
  @IsOptional()
  @IsString()
  fcmToken?: string;
}
