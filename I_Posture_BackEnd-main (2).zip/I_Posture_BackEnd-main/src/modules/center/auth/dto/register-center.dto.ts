import { IsEmail, IsOptional, IsString, Length, MinLength } from 'class-validator';

export class RegisterCenterDto {
  @IsString()
  @Length(4, 50)
  userId!: string;

  @IsString()
  @Length(1, 50)
  name!: string;

  @IsString()
  @Length(1, 100)
  centerName!: string;

  @IsOptional()
  @IsString()
  @Length(1, 255)
  centerAddress?: string;

  @IsString()
  @MinLength(4)
  password!: string;

  @IsString()
  @Length(1, 65)
  phone!: string;

  @IsEmail()
  email!: string;

  @IsString()
  verifiedToken!: string;
}
