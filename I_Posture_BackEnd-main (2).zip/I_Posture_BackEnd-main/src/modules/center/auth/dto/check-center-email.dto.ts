import { ApiProperty } from '@nestjs/swagger';
import { IsEmail } from 'class-validator';

export class CheckCenterEmailDto {
  @ApiProperty({ description: '가입 예정 이메일', example: 'center@example.com' })
  @IsEmail()
  email!: string;
}
