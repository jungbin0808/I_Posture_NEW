import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CheckCenterEmailResponseDto {
  @ApiProperty({ description: '가입 가능 여부' })
  available!: boolean;

  @ApiPropertyOptional({
    description: '사용 불가 사유 (available=false일 때)',
    example: '이미 사용 중인 이메일입니다.',
  })
  message?: string;
}
