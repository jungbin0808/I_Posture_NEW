import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { Transactional } from 'typeorm-transactional';
import { AuthService, CENTER_WEB_ACCOUNT_USER_TYPES } from '../../auth/auth.service';
import { ResetPasswordDto, SendOtpDto, TokenResponseDto, VerifyOtpDto } from '../../auth/auth.dto';
import { RegisterCenterDto } from './dto/register-center.dto';
import { CenterLoginDto } from './dto/center-login.dto';
import {
  AccountStatus,
  MemberType,
  PaymentStatus,
  UserEntity,
  UserType,
} from '../../../database/entities/user.entity';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterCapacityPoolEntity } from '../../../database/entities/center-capacity-pool.entity';
import { EmailVerificationPurpose } from '../../../database/entities/email-verification.entity';
import { ALL_NOTIFICATIONS_ON } from '../../user/helpers/notification-settings.helper';

@Injectable()
export class CenterAuthService {
  constructor(
    private readonly authService: AuthService,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterCapacityPoolEntity)
    private readonly centerCapacityPoolRepo: Repository<CenterCapacityPoolEntity>,
  ) {}

  async login(dto: CenterLoginDto): Promise<TokenResponseDto> {
    const loginId = dto.userId ?? dto.email;
    if (!loginId) {
      throw new BadRequestException('아이디 또는 이메일을 입력해주세요.');
    }

    const user = await this.authService.validateCredentials(loginId, dto.password, {
      allowEmailLogin: true,
    });
    this.assertCenterOwner(user);

    if (dto.fcmToken) {
      await this.userRepo.update({ id: user.id }, { fcmToken: dto.fcmToken });
    }

    return this.authService.issueAuthTokens(user);
  }

  @Transactional()
  async register(dto: RegisterCenterDto): Promise<TokenResponseDto> {
    const payload = await this.authService.consumeVerifiedEmailToken(
      dto.verifiedToken,
      EmailVerificationPurpose.REGISTER,
    );

    if (payload.email !== dto.email) {
      throw new BadRequestException('이메일 인증 정보와 입력한 이메일이 일치하지 않습니다.');
    }

    await this.authService.assertLoginIdAvailable(dto.userId);
    await this.authService.assertEmailAvailableForRegistration(dto.email, UserType.CENTER);

    const hashed = await bcrypt.hash(dto.password.toLowerCase(), 10);

    let savedUser: UserEntity;
    try {
      savedUser = await this.userRepo.save(
        this.userRepo.create({
          userId: dto.userId,
          email: dto.email,
          password: hashed,
          name: dto.name,
          phone: dto.phone,
          affiliationName: dto.centerName,
          userType: UserType.CENTER,
          memberType: MemberType.APP,
          accountStatus: AccountStatus.ACTIVE,
          paymentStatus: PaymentStatus.UNPAID,
          ...ALL_NOTIFICATIONS_ON,
        }),
      );
    } catch (error) {
      if (error instanceof ConflictException) {
        throw error;
      }
      this.authService.assertNoDuplicateUserEntry(error);
      throw error;
    }

    const savedCenter = await this.centerRepo.save(
      this.centerRepo.create({
        ownerId: savedUser.id,
        name: dto.centerName,
        address: dto.centerAddress,
      }),
    );

    await this.centerCapacityPoolRepo.save(
      this.centerCapacityPoolRepo.create({
        centerId: savedCenter.id,
        totalCapacity: '0',
        usedCapacity: '0',
        allocatedCapacity: '0',
      }),
    );

    return this.authService.issueAuthTokens(savedUser);
  }

  async sendOtp(dto: SendOtpDto): Promise<{ code?: string }> {
    return this.authService.sendOtp(dto, {
      allowedUserTypes: CENTER_WEB_ACCOUNT_USER_TYPES,
    });
  }

  async verifyOtp(dto: VerifyOtpDto) {
    return this.authService.verifyOtp(dto);
  }

  async findId(verifiedToken: string): Promise<{ userId: string }> {
    return this.authService.findIdByVerifiedToken(verifiedToken, {
      allowedUserTypes: CENTER_WEB_ACCOUNT_USER_TYPES,
    });
  }

  async resetPassword(dto: ResetPasswordDto): Promise<void> {
    await this.authService.resetPassword(dto, {
      allowedUserTypes: CENTER_WEB_ACCOUNT_USER_TYPES,
    });
  }

  async checkEmailAvailability(email: string) {
    return this.authService.checkEmailRegistrationAvailability(email, UserType.CENTER);
  }

  async refreshTokens(
    userId: string,
    jti: string,
    token: string,
    iat: number,
    exp: number,
  ) {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user || user.userType !== UserType.CENTER) {
      throw new ForbiddenException('센터 오너 계정만 센터 웹을 이용할 수 있습니다.');
    }
    return this.authService.refreshTokens(userId, jti, token, iat, exp);
  }

  async logout(userId: string, jti: string) {
    return this.authService.logout(userId, jti);
  }

  private assertCenterOwner(user: UserEntity): void {
    if (user.userType !== UserType.CENTER) {
      throw new ForbiddenException('센터 오너 계정만 센터 웹에 로그인할 수 있습니다. 트레이너는 트레이너 앱/웹을 이용해주세요.');
    }
  }
}
