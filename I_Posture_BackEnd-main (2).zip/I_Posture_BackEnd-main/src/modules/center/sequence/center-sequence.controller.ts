import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { SubscriptionGuard } from '../../../common/guards/subscription.guard';
import { RequiresSubscription } from '../../../common/decorators/requires-subscription.decorator';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { SequenceService } from '../../sequence/sequence.service';
import {
  AssignSequenceToScheduleDto,
  CreateSequenceDto,
  FindSequenceDto,
  SequenceListItemDto,
  UpdateSequenceDto,
  UpdateSequenceStatusDto,
} from '../../sequence/sequence.dto';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { SequenceEntity } from '../../../database/entities/sequence.entity';
import { UserEntity } from '../../../database/entities/user.entity';

@ApiTags('Center Sequence')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/sequences')
export class CenterSequenceController {
  constructor(private readonly sequenceService: SequenceService) {}

  @ApiOperation({ summary: '시퀀스 목록 (센터 웹)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() dto: FindSequenceDto,
  ): Promise<IPageResponse<SequenceListItemDto>> {
    const pageData = await this.sequenceService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '시퀀스 상세 (센터 웹)' })
  @Get(':id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<SequenceEntity>> {
    const sequence = await this.sequenceService.findOne(req.user.id, id);
    return SuccessResponse(sequence);
  }

  @ApiOperation({ summary: '시퀀스 생성 (센터 웹)' })
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post()
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'detailImages', maxCount: 50 },
  ]))
  async create(
    @Req() req: { user: UserEntity },
    @Body('data') data: string,
    @UploadedFiles() files: { thumbnail?: Express.Multer.File[]; detailImages?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<SequenceEntity>> {
    const dto: CreateSequenceDto = JSON.parse(data);
    const sequence = await this.sequenceService.create(
      req.user,
      dto,
      files.thumbnail?.[0],
      files.detailImages,
    );
    return SuccessResponse(sequence);
  }

  @ApiOperation({ summary: '시퀀스 상태 일괄 변경 (센터 웹)' })
  @Put('bulk/status')
  async updateStatus(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateSequenceStatusDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.sequenceService.updateStatus(req.user.id, dto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '시퀀스 수정 (센터 웹)' })
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put(':id')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'detailImages', maxCount: 50 },
  ]))
  async update(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body('data') data: string,
    @UploadedFiles() files: { thumbnail?: Express.Multer.File[]; detailImages?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<SequenceEntity>> {
    const dto: UpdateSequenceDto = JSON.parse(data);
    const sequence = await this.sequenceService.update(
      req.user,
      id,
      dto,
      files.thumbnail?.[0],
      files.detailImages,
    );
    return SuccessResponse(sequence);
  }

  @ApiOperation({ summary: '일정에 시퀀스 배정 (센터 웹)' })
  @Post(':id/assign-to-schedule')
  async assignToSchedule(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: AssignSequenceToScheduleDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.sequenceService.assignToSchedule(req.user.id, id, dto.scheduleId);
    return SuccessResponse(result);
  }
}
