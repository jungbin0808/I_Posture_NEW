import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { SuccessResponse } from '../../../common/response/response.helper';
import { SequenceGroupService } from '../../sequence-group/sequence-group.service';
import {
  AddSequencesToGroupDto,
  CreateSequenceGroupDto,
  DeleteSequenceGroupsDto,
  FindSequenceGroupsDto,
  RemoveSequencesFromGroupDto,
  UpdateSequenceGroupDto,
} from '../../sequence-group/sequence-group.dto';

@ApiTags('Center Sequence Group')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/sequence-groups')
export class CenterSequenceGroupController {
  constructor(private readonly sequenceGroupService: SequenceGroupService) {}

  @ApiOperation({ summary: '시퀀스 그룹 생성 (센터 웹)' })
  @Post()
  async create(@Req() req: { user: UserEntity }, @Body() dto: CreateSequenceGroupDto) {
    const data = await this.sequenceGroupService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '시퀀스 그룹 목록 (센터 웹)' })
  @Get()
  async findAll(@Req() req: { user: UserEntity }, @Query() dto: FindSequenceGroupsDto) {
    const pageData = await this.sequenceGroupService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '시퀀스 그룹 상세 (센터 웹)' })
  @Get(':id')
  async findOne(@Req() req: { user: UserEntity }, @Param('id') id: string) {
    const data = await this.sequenceGroupService.findOne(req.user.id, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '시퀀스 그룹 수정 (센터 웹)' })
  @Put(':id')
  async update(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: UpdateSequenceGroupDto,
  ) {
    const data = await this.sequenceGroupService.update(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '시퀀스 그룹에 시퀀스 추가 (센터 웹)' })
  @Post(':id/sequences')
  async addSequencesToGroup(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: AddSequencesToGroupDto,
  ) {
    const data = await this.sequenceGroupService.addSequencesToGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '시퀀스 그룹에서 시퀀스 제거 (센터 웹)' })
  @Delete(':id/sequences')
  async removeSequencesFromGroup(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: RemoveSequencesFromGroupDto,
  ) {
    const data = await this.sequenceGroupService.removeSequencesFromGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '시퀀스 그룹 삭제 (센터 웹)' })
  @Delete()
  async delete(@Req() req: { user: UserEntity }, @Body() dto: DeleteSequenceGroupsDto) {
    const data = await this.sequenceGroupService.delete(req.user.id, dto);
    return SuccessResponse(data);
  }
}
