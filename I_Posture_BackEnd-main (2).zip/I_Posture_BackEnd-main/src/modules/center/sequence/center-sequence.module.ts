import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CenterCommonModule } from '../common/center-common.module';
import { SequenceModule } from '../../sequence/sequence.module';
import { SequenceGroupModule } from '../../sequence-group/sequence-group.module';
import { CenterSequenceController } from './center-sequence.controller';
import { CenterSequenceGroupController } from './center-sequence-group.controller';
import { SubscriptionGuard } from '../../../common/guards/subscription.guard';
import { CapacityModule } from '../../capacity/capacity.module';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../../database/entities/center.entity';

@Module({
  imports: [
    CenterCommonModule,
    SequenceModule,
    SequenceGroupModule,
    CapacityModule,
    TypeOrmModule.forFeature([SubscriptionEntity, CenterTrainerEntity, CenterEntity]),
  ],
  controllers: [CenterSequenceController, CenterSequenceGroupController],
  providers: [SubscriptionGuard],
})
export class CenterSequenceModule {}