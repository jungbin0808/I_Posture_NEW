import { Module } from '@nestjs/common';
import { CenterCommonModule } from '../common/center-common.module';
import { FaqModule } from '../../faq/faq.module';
import { CenterFaqController } from './center-faq.controller';

@Module({
  imports: [CenterCommonModule, FaqModule],
  controllers: [CenterFaqController],
})
export class CenterFaqModule {}
