import { Controller, Get, Param, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { FaqService } from '../../faq/faq.service';
import { FindFaqDto } from '../../faq/dto/find-faq.dto';
import { IPageData, IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { FaqEntity } from '../../../database/entities/faq.entity';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { SuccessResponse } from '../../../common/response/response.helper';

@ApiTags('Center FAQ')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/faqs')
export class CenterFaqController {
  constructor(private readonly faqService: FaqService) {}

  @ApiOperation({ summary: 'FAQ 카테고리 목록 (센터 웹)' })
  @Get('categories')
  async getCategories(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<FaqCategoryEntity[]>> {
    const categories = await this.faqService.findAllCategories(req.user);
    return SuccessResponse(categories);
  }

  @ApiOperation({ summary: 'FAQ 목록 (센터 웹)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() findFaqDto: FindFaqDto,
  ): Promise<IPageResponse<FaqEntity>> {
    const pageData: IPageData<FaqEntity> = await this.faqService.findAll(req.user, findFaqDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'FAQ 상세 (센터 웹)' })
  @Get(':id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<FaqEntity>> {
    const faq = await this.faqService.findOne(req.user, id);
    return SuccessResponse(faq);
  }
}
