import { Module } from '@nestjs/common';
import { CenterNotificationController } from './center-notification.controller';

@Module({
  controllers: [CenterNotificationController],
})
export class CenterNotificationModule {}
