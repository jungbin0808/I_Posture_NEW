import { Controller, Get, Param, Put, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageData, IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { UserNotificationService } from '../../notification/user-notification.service';
import { FindCenterNotificationDto } from './dto/find-center-notification.dto';
import { CenterNotificationListItemDto } from './dto/center-notification-list-item.dto';

@ApiTags('Center Notification')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/notifications')
export class CenterNotificationController {
  constructor(private readonly userNotificationService: UserNotificationService) {}

  @ApiOperation({ summary: '알림 목록 (전체/공지/이벤트/앱 알림 필터)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() query: FindCenterNotificationDto,
  ): Promise<IPageResponse<CenterNotificationListItemDto>> {
    const pageData = await this.userNotificationService.findAllForUser(req.user.id, {
      page: query.page,
      limit: query.limit,
      type: query.type,
    });

    const items = pageData.items.map((item) => this.userNotificationService.toListItem(item));
    const data: IPageData<CenterNotificationListItemDto> = {
      items,
      paging: pageData.paging,
    };

    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '알림 읽음 처리' })
  @Put(':id/read')
  async markAsRead(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<CenterNotificationListItemDto>> {
    const notification = await this.userNotificationService.markAsRead(req.user.id, id);
    return SuccessResponse(this.userNotificationService.toListItem(notification));
  }
}
