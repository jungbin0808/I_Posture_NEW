import { IsEnum, IsOptional } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { UserNotificationType } from '../../../../database/entities/user-notification.entity';

export class FindCenterNotificationDto extends PaginationDto {
  @ApiProperty({
    description: '알림 유형 필터 (미입력 시 전체)',
    enum: UserNotificationType,
    required: false,
  })
  @IsOptional()
  @IsEnum(UserNotificationType)
  type?: UserNotificationType;
}
