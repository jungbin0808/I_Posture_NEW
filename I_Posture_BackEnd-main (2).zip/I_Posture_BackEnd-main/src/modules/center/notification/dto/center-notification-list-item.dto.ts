import { ApiProperty } from '@nestjs/swagger';
import { UserNotificationType } from '../../../../database/entities/user-notification.entity';

export class CenterNotificationListItemDto {
  @ApiProperty({ description: '알림 ID' })
  id!: string;

  @ApiProperty({ description: '알림 유형', enum: UserNotificationType })
  type!: UserNotificationType;

  @ApiProperty({ description: '알림 제목' })
  title!: string;

  @ApiProperty({ description: '알림 본문' })
  body!: string;

  @ApiProperty({ description: '읽음 여부' })
  isRead!: boolean;

  @ApiProperty({ description: '생성일시 (ISO8601)' })
  createdAt!: string;

  @ApiProperty({ description: '추가 데이터 (딥링크 등)', required: false })
  data?: Record<string, string>;
}
