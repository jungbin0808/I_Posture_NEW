import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { ScheduleService } from '../../schedule/schedule.service';
import {
  BulkCompleteDto,
  BulkNoshowDto,
  CreateScheduleDto,
  FindSchedulesDto,
  ScheduleListItemDto,
  UpdateScheduleDto,
} from '../../schedule/schedule.dto';

@ApiTags('Center Schedule')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/schedules')
export class CenterScheduleController {
  constructor(private readonly scheduleService: ScheduleService) {}

  @ApiOperation({ summary: '나의 전체 일정 목록 (센터 웹)' })
  @Get()
  async findMySchedules(
    @Req() req: { user: UserEntity },
    @Query() dto: FindSchedulesDto,
  ): Promise<IPageResponse<ScheduleListItemDto>> {
    const pageData = await this.scheduleService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '시퀀스 등록용 일정 목록 (센터 웹)' })
  @Get('for-sequence')
  async findForSequenceRegistration(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<ScheduleListItemDto[]>> {
    const data = await this.scheduleService.findForSequenceRegistration(req.user.id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 노쇼 처리 (센터 웹)' })
  @Put('noshow')
  async bulkNoshow(
    @Req() req: { user: UserEntity },
    @Body() dto: BulkNoshowDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.bulkNoshow(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 완료 처리 (센터 웹)' })
  @Put('complete')
  async bulkComplete(
    @Req() req: { user: UserEntity },
    @Body() dto: BulkCompleteDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.bulkComplete(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원 일정 목록 (센터 웹)' })
  @Get('member/:memberId')
  async findAllByMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() dto: FindSchedulesDto,
  ): Promise<IPageResponse<ScheduleListItemDto>> {
    const pageData = await this.scheduleService.findAllByMember(req.user.id, memberId, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '특정 회원 일정 상세 (센터 웹)' })
  @Get('member/:memberId/:scheduleId')
  async findOneByMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.findOneByMember(req.user.id, memberId, scheduleId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원 일정 등록 (센터 웹)' })
  @Post('member/:memberId')
  async createForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.createForMember(req.user.id, memberId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원 일정 수정 (센터 웹)' })
  @Put('member/:memberId/:scheduleId')
  async updateForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.updateForMember(req.user.id, memberId, scheduleId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '특정 회원 일정 삭제 (센터 웹)' })
  @Delete('member/:memberId/:scheduleId')
  async deleteForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.deleteForMember(req.user.id, memberId, scheduleId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 상세 (센터 웹)' })
  @Get(':scheduleId')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.findOne(req.user.id, scheduleId);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 등록 (센터 웹)' })
  @Post()
  async create(
    @Req() req: { user: UserEntity },
    @Body() dto: CreateScheduleDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 수정 (센터 웹)' })
  @Put(':scheduleId')
  async update(
    @Req() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
    @Body() dto: UpdateScheduleDto,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.update(req.user.id, scheduleId, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 삭제 (센터 웹)' })
  @Delete(':scheduleId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('scheduleId') scheduleId: string,
  ): Promise<ISuccessResponse<unknown>> {
    const data = await this.scheduleService.delete(req.user.id, scheduleId);
    return SuccessResponse(data);
  }
}
