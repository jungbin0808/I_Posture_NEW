import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { SuccessResponse } from '../../../common/response/response.helper';
import { ScheduleGroupService } from '../../schedule-group/schedule-group.service';
import {
  CreateScheduleGroupDto,
  DeleteScheduleGroupsDto,
  FindScheduleGroupsDto,
  UpdateScheduleGroupDto,
} from '../../schedule-group/schedule-group.dto';
import { AddSchedulesToGroupDto, RemoveSchedulesFromGroupDto } from '../../schedule/schedule.dto';

@ApiTags('Center Schedule Group')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/schedule-groups')
export class CenterScheduleGroupController {
  constructor(private readonly groupService: ScheduleGroupService) {}

  @ApiOperation({ summary: '일정 그룹 생성 (센터 웹)' })
  @Post()
  async create(
    @Req() req: { user: UserEntity },
    @Body() dto: CreateScheduleGroupDto,
  ) {
    const data = await this.groupService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹 목록 (센터 웹)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() dto: FindScheduleGroupsDto,
  ) {
    const pageData = await this.groupService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '일정 그룹 삭제 (센터 웹, 다건)' })
  @Delete()
  async delete(
    @Req() req: { user: UserEntity },
    @Body() dto: DeleteScheduleGroupsDto,
  ) {
    const data = await this.groupService.delete(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹에 일정 추가 (센터 웹)' })
  @Post(':id/schedules')
  async addSchedulesToGroup(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: AddSchedulesToGroupDto,
  ) {
    const data = await this.groupService.addSchedulesToGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹에서 일정 삭제 (센터 웹)' })
  @Delete(':id/schedules')
  async removeSchedulesFromGroup(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: RemoveSchedulesFromGroupDto,
  ) {
    const data = await this.groupService.removeSchedulesFromGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹 상세 (센터 웹)' })
  @Get(':id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ) {
    const data = await this.groupService.findOne(req.user.id, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹 수정 (센터 웹)' })
  @Put(':id')
  async update(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: UpdateScheduleGroupDto,
  ) {
    const data = await this.groupService.update(req.user.id, id, dto);
    return SuccessResponse(data);
  }
}
