import { Module } from '@nestjs/common';
import { CenterCommonModule } from '../common/center-common.module';
import { ScheduleModule } from '../../schedule/schedule.module';
import { ScheduleGroupModule } from '../../schedule-group/schedule-group.module';
import { CenterScheduleController } from './center-schedule.controller';
import { CenterScheduleGroupController } from './center-schedule-group.controller';

@Module({
  imports: [CenterCommonModule, ScheduleModule, ScheduleGroupModule],
  controllers: [CenterScheduleController, CenterScheduleGroupController],
})
export class CenterScheduleModule {}
