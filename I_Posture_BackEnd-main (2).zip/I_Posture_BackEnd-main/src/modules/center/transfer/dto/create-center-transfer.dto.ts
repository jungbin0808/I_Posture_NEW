import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateCenterTransferDto {
  @ApiProperty({ description: '이관 대상 회원 ID' })
  @IsString()
  @IsNotEmpty()
  memberId!: string;

  @ApiProperty({ description: '이관 전 담당 트레이너 ID' })
  @IsString()
  @IsNotEmpty()
  fromTrainerId!: string;

  @ApiProperty({ description: '이관 후 담당 트레이너 ID' })
  @IsString()
  @IsNotEmpty()
  toTrainerId!: string;
}
