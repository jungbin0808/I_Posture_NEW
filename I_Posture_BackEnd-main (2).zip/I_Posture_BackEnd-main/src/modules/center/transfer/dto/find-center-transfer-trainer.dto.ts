import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class FindCenterTransferTrainerDto {
  @ApiProperty({ description: '제외할 현재 담당 트레이너 (users.id UUID 또는 로그인 아이디)' })
  @IsString()
  @IsNotEmpty()
  excludeTrainerId!: string;
}
