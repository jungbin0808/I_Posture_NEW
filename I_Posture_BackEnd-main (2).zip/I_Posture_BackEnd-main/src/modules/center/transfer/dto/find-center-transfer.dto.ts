import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { CenterTransferSortOrder } from './center-transfer-sort.enum';

export class FindCenterTransferDto extends PaginationDto {
  @ApiProperty({
    description: '키워드 검색 (담당 트레이너명, 회원명, 이메일, 연락처)',
    required: false,
  })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiProperty({
    description: '정렬 (회원명 가나다순/역순, 등록일 오름/내림차순)',
    enum: CenterTransferSortOrder,
    required: false,
    default: CenterTransferSortOrder.NAME_ASC,
  })
  @IsEnum(CenterTransferSortOrder)
  @IsOptional()
  sort?: CenterTransferSortOrder = CenterTransferSortOrder.NAME_ASC;
}
