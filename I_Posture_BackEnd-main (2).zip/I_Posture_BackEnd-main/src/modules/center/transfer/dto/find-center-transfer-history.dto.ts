import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { CenterTransferHistorySortOrder } from './center-transfer-history-sort.enum';

export class FindCenterTransferHistoryDto extends PaginationDto {
  @ApiProperty({
    description: '키워드 검색 (담당 트레이너명, 회원명, 이메일, 연락처)',
    required: false,
  })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiProperty({
    description: '정렬 (이관날짜 오름/내림차순)',
    enum: CenterTransferHistorySortOrder,
    required: false,
    default: CenterTransferHistorySortOrder.DATE_DESC,
  })
  @IsEnum(CenterTransferHistorySortOrder)
  @IsOptional()
  sort?: CenterTransferHistorySortOrder = CenterTransferHistorySortOrder.DATE_DESC;
}
