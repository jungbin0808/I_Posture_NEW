import { ApiProperty } from '@nestjs/swagger';

export class CenterTransferHistoryListItemDto {
  @ApiProperty({ description: '목록 번호' })
  no!: number;

  @ApiProperty({ description: '회원 ID' })
  memberId!: string;

  @ApiProperty({ description: '회원명' })
  memberName!: string;

  @ApiProperty({ description: '연락처', nullable: true })
  phone?: string;

  @ApiProperty({ description: '이메일', nullable: true })
  email?: string;

  @ApiProperty({ description: '담당 트레이너 ID (이관 후)' })
  trainerId!: string;

  @ApiProperty({ description: '담당 트레이너명 (이관 후)' })
  trainerName!: string;

  @ApiProperty({ description: '누적 이관횟수' })
  transferCount!: number;

  @ApiProperty({ description: '이관날짜 (ISO8601)', example: '2026-07-14T12:00:00.000Z' })
  transferredAt!: string;

  @ApiProperty({
    description: '앱 연동 만료일 (이관 시점 이용권 만료 예정일, ISO8601)',
    nullable: true,
    example: '2026-07-10T00:00:00.000Z',
  })
  appLinkExpiresAt?: string | null;
}
