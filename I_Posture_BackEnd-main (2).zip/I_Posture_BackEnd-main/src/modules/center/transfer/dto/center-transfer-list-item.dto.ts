import { ApiProperty } from '@nestjs/swagger';

export class CenterTransferListItemDto {
  @ApiProperty({ description: '목록 번호' })
  no!: number;

  @ApiProperty({ description: '회원 ID' })
  memberId!: string;

  @ApiProperty({ description: '회원명' })
  memberName!: string;

  @ApiProperty({ description: '연락처', nullable: true })
  phone?: string;

  @ApiProperty({ description: '이메일', nullable: true })
  email?: string;

  @ApiProperty({ description: '담당 트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '담당 트레이너명' })
  trainerName!: string;

  @ApiProperty({
    description: '앱 연동 만료일 (활성 이용권 만료 예정일, ISO8601)',
    nullable: true,
    example: '2026-07-10T00:00:00.000Z',
  })
  appLinkExpiresAt?: string | null;
}
