import { ApiProperty } from '@nestjs/swagger';

export class CenterTransferTrainerItemDto {
  @ApiProperty({ description: '트레이너명' })
  name!: string;

  @ApiProperty({ description: '트레이너 아이디 (로그인)' })
  userId!: string;

  @ApiProperty({ description: '연락처' })
  phone!: string;
}
