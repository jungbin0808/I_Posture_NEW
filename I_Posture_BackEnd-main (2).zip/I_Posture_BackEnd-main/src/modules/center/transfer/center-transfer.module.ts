import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CenterCommonModule } from '../common/center-common.module';
import { CapacityModule } from '../../capacity/capacity.module';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { MemberTransferHistoryEntity } from '../../../database/entities/member-transfer-history.entity';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { TrainerUserEntity } from '../../../database/entities/trainer-user.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { CenterTransferController } from './center-transfer.controller';
import { CenterTransferService } from './center-transfer.service';

@Module({
  imports: [
    CenterCommonModule,
    CapacityModule,
    TypeOrmModule.forFeature([
      CenterEntity,
      CenterTrainerEntity,
      UserEntity,
      TrainerUserEntity,
      SubscriptionEntity,
      MemberTransferHistoryEntity,
    ]),
  ],
  controllers: [CenterTransferController],
  providers: [CenterTransferService],
})
export class CenterTransferModule {}
