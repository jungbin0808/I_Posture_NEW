import { Body, Controller, Get, Post, Query, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CenterTransferService } from './center-transfer.service';
import { FindCenterTransferDto } from './dto/find-center-transfer.dto';
import { CenterTransferListItemDto } from './dto/center-transfer-list-item.dto';
import { FindCenterTransferHistoryDto } from './dto/find-center-transfer-history.dto';
import { CenterTransferHistoryListItemDto } from './dto/center-transfer-history-list-item.dto';
import { CreateCenterTransferDto } from './dto/create-center-transfer.dto';
import { FindCenterTransferTrainerDto } from './dto/find-center-transfer-trainer.dto';
import { CenterTransferTrainerItemDto } from './dto/center-transfer-trainer-item.dto';

@ApiTags('Center Transfer')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/transfers')
export class CenterTransferController {
  constructor(private readonly centerTransferService: CenterTransferService) {}

  @ApiOperation({ summary: '이관하기 목록 (센터 소속 회원)' })
  @Get()
  async findAll(
    @Req() req: { user: UserEntity },
    @Query() dto: FindCenterTransferDto,
  ): Promise<IPageResponse<CenterTransferListItemDto>> {
    const pageData = await this.centerTransferService.findTransferTargets(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '이관 대상 트레이너 목록 (현재 담당 트레이너 제외)' })
  @Get('trainers')
  async findTrainers(
    @Req() req: { user: UserEntity },
    @Query() dto: FindCenterTransferTrainerDto,
  ): Promise<ISuccessResponse<CenterTransferTrainerItemDto[]>> {
    const items = await this.centerTransferService.findTransferTrainers(req.user.id, dto);
    return SuccessResponse(items);
  }

  @ApiOperation({ summary: '이관 히스토리 목록' })
  @Get('history')
  async findHistories(
    @Req() req: { user: UserEntity },
    @Query() dto: FindCenterTransferHistoryDto,
  ): Promise<IPageResponse<CenterTransferHistoryListItemDto>> {
    const pageData = await this.centerTransferService.findTransferHistories(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '회원 이관 (트레이너 A → B)' })
  @Post()
  async transfer(
    @Req() req: { user: UserEntity },
    @Body() dto: CreateCenterTransferDto,
  ): Promise<ISuccessResponse<{ id: string; transferredAt: string }>> {
    const result = await this.centerTransferService.transferMember(req.user.id, dto);
    return SuccessResponse(result);
  }
}
