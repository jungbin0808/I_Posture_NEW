import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, DataSource, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { CenterEntity } from '../../../database/entities/center.entity';
import {
  CenterTrainerEntity,
  CenterTrainerStatus,
} from '../../../database/entities/center-trainer.entity';
import { MemberTransferHistoryEntity } from '../../../database/entities/member-transfer-history.entity';
import {
  SubscriptionEntity,
  SubscriptionStatus,
} from '../../../database/entities/subscription.entity';
import {
  TrainerUserEntity,
  TrainerUserStatus,
} from '../../../database/entities/trainer-user.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { CapacityService } from '../../capacity/capacity.service';
import { FindCenterTransferDto } from './dto/find-center-transfer.dto';
import { CenterTransferListItemDto } from './dto/center-transfer-list-item.dto';
import { CenterTransferSortOrder } from './dto/center-transfer-sort.enum';
import { FindCenterTransferHistoryDto } from './dto/find-center-transfer-history.dto';
import { CenterTransferHistoryListItemDto } from './dto/center-transfer-history-list-item.dto';
import { CenterTransferHistorySortOrder } from './dto/center-transfer-history-sort.enum';
import { CreateCenterTransferDto } from './dto/create-center-transfer.dto';
import { FindCenterTransferTrainerDto } from './dto/find-center-transfer-trainer.dto';
import { CenterTransferTrainerItemDto } from './dto/center-transfer-trainer-item.dto';
import { ACCOUNT_DELETION_GRACE_DAYS } from '../trainer/helpers/center-trainer-account-status.helper';

@Injectable()
export class CenterTransferService {
  constructor(
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    @InjectRepository(MemberTransferHistoryEntity)
    private readonly transferHistoryRepo: Repository<MemberTransferHistoryEntity>,
    private readonly dataSource: DataSource,
    private readonly capacityService: CapacityService,
  ) {}

  async findTransferTargets(
    ownerId: string,
    dto: FindCenterTransferDto,
  ): Promise<IPageData<CenterTransferListItemDto>> {
    const { page = 1, limit = 10, search, sort = CenterTransferSortOrder.NAME_ASC } = dto;
    // 회원탈퇴 후 계정 완전삭제 유예기간(90일) 이내인 트레이너 소속 회원도 이관 대상에 포함
    const trainerIds = await this.resolveTransferableSourceTrainerIds(ownerId);

    if (trainerIds.length === 0) {
      return { items: [], paging: buildPaging(0, limit, page) };
    }

    const queryBuilder = this.userRepo.createQueryBuilder('member')
      // innerJoin(UserEntity, 'trainer', ...)는 TypeORM이 trainer.deleted_at IS NULL을 자동으로
      // 붙여서, withDeleted() 없이는 탈퇴(소프트삭제)한 트레이너 소속 회원이 결과에서 통째로 빠짐
      .withDeleted()
      .innerJoin(
        TrainerUserEntity,
        'tu',
        'tu.member_id = member.id AND tu.status = :tuStatus AND tu.deleted_at IS NULL',
        { tuStatus: TrainerUserStatus.ACTIVE },
      )
      .innerJoin(UserEntity, 'trainer', 'trainer.id = tu.trainer_id')
      .where('tu.trainer_id IN (:...trainerIds)', { trainerIds })
      .select('member.id', 'memberId')
      .addSelect('member.name', 'memberName')
      .addSelect('member.phone', 'phone')
      .addSelect('member.email', 'email')
      .addSelect('trainer.id', 'trainerId')
      .addSelect('trainer.name', 'trainerName')
      .addSelect((subQuery) =>
        subQuery
          .select('MAX(s.next_billing_date)')
          .from(SubscriptionEntity, 's')
          .where('s.user_id = member.id')
          .andWhere('s.status = :subStatus'),
        'subscriptionExpiresAt',
      )
      .setParameter('subStatus', SubscriptionStatus.ACTIVE);

    if (search) {
      const keyword = `%${search}%`;
      queryBuilder.andWhere(new Brackets((qb) => {
        qb.where('member.name LIKE :keyword', { keyword })
          .orWhere('member.phone LIKE :keyword', { keyword })
          .orWhere('member.email LIKE :keyword', { keyword })
          .orWhere('trainer.name LIKE :keyword', { keyword });
      }));
    }

    const sortColumn = sort === CenterTransferSortOrder.NAME_ASC || sort === CenterTransferSortOrder.NAME_DESC
      ? 'member.name'
      : 'member.created_at';
    const sortDirection = sort === CenterTransferSortOrder.NAME_DESC || sort === CenterTransferSortOrder.DATE_DESC
      ? 'DESC'
      : 'ASC';

    queryBuilder.orderBy(sortColumn, sortDirection);

    const total = await queryBuilder.getCount();
    const rows = await queryBuilder
      .offset((page - 1) * limit)
      .limit(limit)
      .getRawMany<{
        memberId: string;
        memberName: string;
        phone: string | null;
        email: string | null;
        trainerId: string;
        trainerName: string;
        subscriptionExpiresAt: string | null;
      }>();

    const items: CenterTransferListItemDto[] = rows.map((row, index) => ({
      no: (page - 1) * limit + index + 1,
      memberId: row.memberId,
      memberName: row.memberName,
      phone: row.phone ?? undefined,
      email: row.email ?? undefined,
      trainerId: row.trainerId,
      trainerName: row.trainerName,
      appLinkExpiresAt: this.formatSubscriptionExpiresAt(row.subscriptionExpiresAt),
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  async findTransferTrainers(
    ownerId: string,
    dto: FindCenterTransferTrainerDto,
  ): Promise<CenterTransferTrainerItemDto[]> {
    const center = await this.resolveCenter(ownerId);

    const rows = await this.centerTrainerRepo.createQueryBuilder('ct')
      .innerJoin(UserEntity, 'trainer', 'trainer.id = ct.trainer_id')
      .where('ct.center_id = :centerId', { centerId: center.id })
      .andWhere('ct.deleted_at IS NULL')
      .andWhere('ct.status = :status', { status: CenterTrainerStatus.WORKING })
      .andWhere('ct.deactivated_at IS NULL')
      .select('trainer.id', 'id')
      .addSelect('trainer.name', 'name')
      .addSelect('trainer.user_id', 'userId')
      .addSelect('trainer.phone', 'phone')
      .orderBy('trainer.name', 'ASC')
      .addOrderBy('trainer.id', 'ASC')
      .getRawMany<{
        id: string;
        name: string;
        userId: string;
        phone: string;
      }>();

    return rows
      .filter((row) => row.id !== dto.excludeTrainerId && row.userId !== dto.excludeTrainerId)
      .map((row) => ({
        name: row.name,
        userId: row.userId,
        phone: row.phone,
      }));
  }

  async findTransferHistories(
    ownerId: string,
    dto: FindCenterTransferHistoryDto,
  ): Promise<IPageData<CenterTransferHistoryListItemDto>> {
    const {
      page = 1,
      limit = 10,
      search,
      sort = CenterTransferHistorySortOrder.DATE_DESC,
    } = dto;
    const center = await this.resolveCenter(ownerId);

    const countBuilder = this.transferHistoryRepo.createQueryBuilder('history')
      .innerJoin(UserEntity, 'member', 'member.id = history.member_id')
      .innerJoin(UserEntity, 'trainer', 'trainer.id = history.to_trainer_id')
      .where('history.center_id = :centerId', { centerId: center.id });

    if (search) {
      const keyword = `%${search}%`;
      countBuilder.andWhere(new Brackets((qb) => {
        qb.where('member.name LIKE :keyword', { keyword })
          .orWhere('member.phone LIKE :keyword', { keyword })
          .orWhere('member.email LIKE :keyword', { keyword })
          .orWhere('trainer.name LIKE :keyword', { keyword });
      }));
    }

    const total = await countBuilder.getCount();

    const queryBuilder = this.transferHistoryRepo.createQueryBuilder('history')
      .innerJoin(UserEntity, 'member', 'member.id = history.member_id')
      .innerJoin(UserEntity, 'trainer', 'trainer.id = history.to_trainer_id')
      .where('history.center_id = :centerId', { centerId: center.id })
      .select('history.id', 'historyId')
      .addSelect('history.member_id', 'memberId')
      .addSelect('member.name', 'memberName')
      .addSelect('member.phone', 'phone')
      .addSelect('member.email', 'email')
      .addSelect('trainer.id', 'trainerId')
      .addSelect('trainer.name', 'trainerName')
      .addSelect('history.transferred_at', 'transferredAt')
      .addSelect('history.app_link_unlinked_at', 'appLinkUnlinkedAt')
      .addSelect((subQuery) =>
        subQuery
          .select('COUNT(*)')
          .from('member_transfer_histories', 'countHistory')
          .where('countHistory.center_id = history.center_id')
          .andWhere('countHistory.member_id = history.member_id')
          .andWhere('countHistory.transferred_at <= history.transferred_at'),
        'transferCount',
      );

    if (search) {
      const keyword = `%${search}%`;
      queryBuilder.andWhere(new Brackets((qb) => {
        qb.where('member.name LIKE :keyword', { keyword })
          .orWhere('member.phone LIKE :keyword', { keyword })
          .orWhere('member.email LIKE :keyword', { keyword })
          .orWhere('trainer.name LIKE :keyword', { keyword });
      }));
    }

    const sortDirection = sort === CenterTransferHistorySortOrder.DATE_ASC ? 'ASC' : 'DESC';
    queryBuilder.orderBy('history.transferred_at', sortDirection);
    queryBuilder.addOrderBy('history.id', sortDirection);

    const rows = await queryBuilder
      .offset((page - 1) * limit)
      .limit(limit)
      .getRawMany<{
        historyId: string;
        memberId: string;
        memberName: string;
        phone: string | null;
        email: string | null;
        trainerId: string;
        trainerName: string;
        transferredAt: string;
        appLinkUnlinkedAt: string | null;
        transferCount: string;
      }>();

    const items: CenterTransferHistoryListItemDto[] = rows.map((row, index) => ({
      no: (page - 1) * limit + index + 1,
      memberId: row.memberId,
      memberName: row.memberName,
      phone: row.phone ?? undefined,
      email: row.email ?? undefined,
      trainerId: row.trainerId,
      trainerName: row.trainerName,
      transferCount: Number(row.transferCount),
      transferredAt: new Date(row.transferredAt).toISOString(),
      appLinkExpiresAt: this.formatSubscriptionExpiresAt(row.appLinkUnlinkedAt),
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  @Transactional()
  async transferMember(
    ownerId: string,
    dto: CreateCenterTransferDto,
  ): Promise<{ id: string; transferredAt: string }> {
    const { memberId, fromTrainerId, toTrainerId } = dto;

    if (fromTrainerId === toTrainerId) {
      throw new BadRequestException('이관 전·후 트레이너가 동일합니다.');
    }

    const center = await this.resolveCenter(ownerId);
    // 이관을 받는 쪽(toTrainerId)은 현재 근무 중인 트레이너여야 하고, 보내는 쪽(fromTrainerId)은
    // 탈퇴 후 계정 완전삭제 유예기간(90일) 이내라면 허용 - 탈퇴한 트레이너 소속 회원도 그 전까지는
    // 다른 트레이너로 이관할 수 있어야 함
    const workingTrainerIds = await this.resolveCenterTrainerIds(ownerId);
    const transferableSourceTrainerIds = await this.resolveTransferableSourceTrainerIds(ownerId);

    if (!transferableSourceTrainerIds.includes(fromTrainerId)) {
      throw new BadRequestException('센터 소속 트레이너만 이관할 수 있습니다.');
    }
    if (!workingTrainerIds.includes(toTrainerId)) {
      throw new BadRequestException('현재 근무 중인 센터 소속 트레이너에게만 이관할 수 있습니다.');
    }

    const trainerUser = await this.trainerUserRepo.findOne({
      where: {
        memberId,
        trainerId: fromTrainerId,
        status: TrainerUserStatus.ACTIVE,
      },
    });

    if (!trainerUser) {
      throw new NotFoundException('이관 대상 회원을 찾을 수 없습니다.');
    }

    const subscriptionExpiresAt = await this.resolveMemberSubscriptionExpiresAt(memberId);

    trainerUser.trainerId = toTrainerId;
    await this.trainerUserRepo.save(trainerUser);

    await this.reassignMemberTrainerData(center.id, memberId, fromTrainerId, toTrainerId);

    const transferredAt = new Date();
    const history = this.transferHistoryRepo.create({
      centerId: center.id,
      memberId,
      fromTrainerId,
      toTrainerId,
      appLinkUnlinkedAt: subscriptionExpiresAt ? new Date(subscriptionExpiresAt) : undefined,
      transferredAt,
    });
    const savedHistory = await this.transferHistoryRepo.save(history);

    return {
      id: savedHistory.id,
      transferredAt: savedHistory.transferredAt.toISOString(),
    };
  }

  /**
   * A 트레이너가 담당하던 회원 데이터를 B 트레이너로 이관합니다.
   * (퇴사·삭제 등으로 담당이 바뀔 때 회원 관련 이력·일정을 새 담당자에게 넘김)
   */
  private async reassignMemberTrainerData(
    centerId: string,
    memberId: string,
    fromTrainerId: string,
    toTrainerId: string,
  ): Promise<void> {
    const memberContentTables = [
      'body_reports',
      'precision_reports',
      'consultation_logs',
      'motion_analyses',
      'workout_logs',
      'inbody_data',
      'food_logs',
    ] as const;

    for (const table of memberContentTables) {
      await this.dataSource.query(
        `UPDATE ${table} SET trainer_id = ? WHERE user_id = ? AND trainer_id = ?`,
        [toTrainerId, memberId, fromTrainerId],
      );
    }

    // 회원 예약 일정 → 새 담당 트레이너 (이전 트레이너 시퀀스 참조는 해제)
    await this.dataSource.query(
      `UPDATE schedules s
       INNER JOIN schedule_bookings sb
         ON sb.schedule_id = s.id
         AND sb.user_id = ?
         AND sb.deleted_at IS NULL
       LEFT JOIN sequences seq ON seq.id = s.sequence_id
       SET s.trainer_id = ?,
           s.sequence_id = CASE WHEN seq.trainer_id = ? THEN NULL ELSE s.sequence_id END
       WHERE s.trainer_id = ?
         AND s.deleted_at IS NULL`,
      [memberId, toTrainerId, fromTrainerId, fromTrainerId],
    );

    await this.capacityService.transferCenterTrainerUsage(
      centerId,
      fromTrainerId,
      toTrainerId,
      memberId,
    );

    // 회원 파일 업로드·용량 차감 주체
    await this.dataSource.query(
      `UPDATE files
       SET uploader_id = ?,
           owner_id = CASE WHEN owner_type = 'TRAINER' THEN ? ELSE owner_id END
       WHERE member_id = ? AND uploader_id = ?`,
      [toTrainerId, toTrainerId, memberId, fromTrainerId],
    );

    // 개인 트레이너 용량 할당(센터 풀 할당은 owner_id가 center_id라 제외)
    await this.dataSource.query(
      `UPDATE storage_allocations
       SET owner_id = ?
       WHERE member_id = ?
         AND owner_type = 'TRAINER'
         AND owner_id = ?
         AND status = 'ACTIVE'`,
      [toTrainerId, memberId, fromTrainerId],
    );

    // 앱 연동 요청
    await this.dataSource.query(
      `UPDATE trainer_link_requests
       SET trainer_id = ?
       WHERE member_id = ? AND trainer_id = ?`,
      [toTrainerId, memberId, fromTrainerId],
    );

    // 이전 트레이너 일정 그룹에서 회원 제거 (새 담당자 그룹은 별도 등록)
    await this.dataSource.query(
      `DELETE sgm FROM schedule_group_members sgm
       INNER JOIN schedule_groups sg ON sg.id = sgm.group_id
       WHERE sgm.user_id = ?
         AND sg.trainer_id = ?
         AND sg.deleted_at IS NULL`,
      [memberId, fromTrainerId],
    );
  }

  private async resolveMemberSubscriptionExpiresAt(memberId: string): Promise<string | null> {
    const subscriptions = await this.subscriptionRepo.find({
      where: { userId: memberId, status: SubscriptionStatus.ACTIVE },
      select: ['nextBillingDate'],
    });

    if (subscriptions.length === 0) {
      return null;
    }

    const latest = subscriptions
      .map((subscription) => subscription.nextBillingDate)
      .filter((date): date is string => Boolean(date))
      .sort((a, b) => new Date(b).getTime() - new Date(a).getTime())[0];

    return latest ?? null;
  }

  private formatSubscriptionExpiresAt(expiresAt: string | Date | null | undefined): string | null {
    if (!expiresAt) {
      return null;
    }

    return new Date(expiresAt).toISOString();
  }

  private async resolveCenter(ownerId: string): Promise<CenterEntity> {
    const center = await this.centerRepo.findOne({ where: { ownerId } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }

    return center;
  }

  private async resolveCenterTrainerIds(ownerId: string): Promise<string[]> {
    const center = await this.resolveCenter(ownerId);

    const centerTrainers = await this.centerTrainerRepo.find({
      where: { centerId: center.id, status: CenterTrainerStatus.WORKING },
      select: ['trainerId'],
    });

    return [...new Set([ownerId, ...centerTrainers.map((ct) => ct.trainerId)])];
  }

  /**
   * 이관을 "보낼 수 있는" 트레이너 ID 목록 - 현재 근무 중인 트레이너 + 회원탈퇴 후 계정 완전삭제
   * 유예기간(90일) 이내인 트레이너. 90일이 지나 계정이 삭제되면 더 이상 포함되지 않는다.
   * 이관을 "받는" 쪽(toTrainerId) 검증에는 쓰면 안 됨 - 그쪽은 반드시 WORKING이어야 하므로
   * resolveCenterTrainerIds를 그대로 사용할 것.
   */
  private async resolveTransferableSourceTrainerIds(ownerId: string): Promise<string[]> {
    const center = await this.resolveCenter(ownerId);
    const workingTrainerIds = await this.resolveCenterTrainerIds(ownerId);

    const deletionCutoff = new Date(Date.now() - ACCOUNT_DELETION_GRACE_DAYS * 24 * 60 * 60 * 1000);
    const recentlyResignedTrainers = await this.centerTrainerRepo.createQueryBuilder('ct')
      .withDeleted()
      .innerJoin(UserEntity, 'trainer', 'trainer.id = ct.trainer_id')
      .where('ct.center_id = :centerId', { centerId: center.id })
      .andWhere('ct.deleted_at IS NULL')
      .andWhere('ct.status = :status', { status: CenterTrainerStatus.RESIGNED })
      .andWhere('trainer.deleted_at IS NOT NULL')
      .andWhere('trainer.deleted_at >= :deletionCutoff', { deletionCutoff })
      .select('ct.trainer_id', 'trainerId')
      .getRawMany<{ trainerId: string }>();

    return [...new Set([...workingTrainerIds, ...recentlyResignedTrainers.map((row) => row.trainerId)])];
  }
}
