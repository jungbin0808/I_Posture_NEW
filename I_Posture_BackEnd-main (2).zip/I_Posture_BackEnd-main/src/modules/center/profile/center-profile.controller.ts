import {
  Body,
  Controller,
  Delete,
  Get,
  Put,
  Req,
  UploadedFile,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
  BadRequestException,
} from '@nestjs/common';
import { FileFieldsInterceptor, FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { CenterOwnerGuard } from '../common/guards/center-owner.guard';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { CenterProfileService } from './center-profile.service';
import { CenterProfileResponseDto } from './dto/center-profile-response.dto';
import { UpdateCenterAccountDto } from './dto/update-center-account.dto';
import { UpdateCenterInfoDto } from './dto/update-center-info.dto';
import { UpdateCenterNotificationsDto } from './dto/update-center-notifications.dto';
import { UpdateCenterLogoDto } from './dto/update-center-logo.dto';
import { RegisterFcmTokenDto } from '../../user/dto/register-fcm-token.dto';

@ApiTags('Center Profile')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, CenterOwnerGuard)
@Controller('center/profile')
export class CenterProfileController {
  constructor(private readonly centerProfileService: CenterProfileService) {}

  @ApiOperation({ summary: '내정보 조회' })
  @Get('me')
  async getMyProfile(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    const profile = await this.centerProfileService.getMyProfile(req.user.id);
    return SuccessResponse(profile);
  }

  @ApiOperation({ summary: '센터 로고 삭제' })
  @Delete('me/logo')
  async deleteLogo(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    const profile = await this.centerProfileService.deleteLogo(req.user);
    return SuccessResponse(profile);
  }

  @ApiOperation({
    summary: '센터 로고 등록/수정 (multipart/form-data, 1개만 유지)',
    description: 'logo 파일 업로드 시 기존 로고 삭제 후 교체. 삭제만 필요하면 DELETE /me/logo 사용.',
  })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        logo: { type: 'string', format: 'binary', description: '센터 로고 이미지 (1개)' },
        removeLogo: { type: 'boolean', description: 'true 시 기존 로고 삭제 (DELETE 권장)' },
      },
    },
  })
  @Put('me/logo')
  @UseInterceptors(FileInterceptor('logo'))
  async updateLogo(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateCenterLogoDto,
    @UploadedFile() logo?: Express.Multer.File,
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    if (logo) {
      const profile = await this.centerProfileService.upsertLogo(req.user, logo);
      return SuccessResponse(profile);
    }
    if (dto.removeLogo === true) {
      const profile = await this.centerProfileService.deleteLogo(req.user);
      return SuccessResponse(profile);
    }
    throw new BadRequestException('logo 파일 또는 removeLogo=true가 필요합니다.');
  }

  @ApiOperation({ summary: '가입정보 수정 - 휴대폰·이메일·비밀번호 (application/json)' })
  @ApiBody({ type: UpdateCenterAccountDto })
  @Put('me/account')
  async updateAccount(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateCenterAccountDto,
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    const profile = await this.centerProfileService.updateAccount(req.user.id, dto);
    return SuccessResponse(profile);
  }

  @ApiOperation({ summary: '센터정보 수정 - 센터명·주소·대표번호·소개·이미지 (multipart/form-data)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        centerName: { type: 'string' },
        centerAddress: { type: 'string' },
        centerPhone: { type: 'string' },
        description: { type: 'string', description: '센터 소개' },
        keepImageFileIds: { type: 'string', description: '유지할 이미지 ID JSON 배열' },
        centerImages: {
          type: 'array',
          items: { type: 'string', format: 'binary' },
          description: '추가할 센터 이미지 (최대 10장)',
        },
      },
    },
  })
  @Put('me/center')
  @UseInterceptors(FileFieldsInterceptor([{ name: 'centerImages', maxCount: 10 }]))
  async updateCenterInfo(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateCenterInfoDto,
    @UploadedFiles() files: { centerImages?: Express.Multer.File[] },
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    const profile = await this.centerProfileService.updateCenterInfo(
      req.user,
      dto,
      files.centerImages,
    );
    return SuccessResponse(profile);
  }

  @ApiOperation({ summary: '알림정보 수정 - 항목별 토글 (application/json)' })
  @ApiBody({ type: UpdateCenterNotificationsDto })
  @Put('me/notifications')
  async updateNotifications(
    @Req() req: { user: UserEntity },
    @Body() dto: UpdateCenterNotificationsDto,
  ): Promise<ISuccessResponse<CenterProfileResponseDto>> {
    const profile = await this.centerProfileService.updateNotifications(req.user.id, dto);
    return SuccessResponse(profile);
  }

  @ApiOperation({ summary: 'FCM 디바이스 토큰 등록/갱신 (센터 웹)' })
  @Put('me/fcm-token')
  async registerFcmToken(
    @Req() req: { user: UserEntity },
    @Body() dto: RegisterFcmTokenDto,
  ): Promise<ISuccessResponse<null>> {
    await this.centerProfileService.registerFcmToken(req.user.id, dto.fcmToken);
    return SuccessResponse(null);
  }

  @ApiOperation({ summary: '회원 탈퇴' })
  @Delete('me/withdraw')
  async withdrawAccount(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.centerProfileService.withdrawAccount(req.user.id);
    return SuccessResponse(result);
  }
}
