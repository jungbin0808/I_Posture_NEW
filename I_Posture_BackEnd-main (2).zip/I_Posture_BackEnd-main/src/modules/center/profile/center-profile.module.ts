import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CenterEntity } from '../../../database/entities/center.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { FileEntity } from '../../../database/entities/file.entity';
import { CenterTrainerEntity } from '../../../database/entities/center-trainer.entity';
import { SubscriptionEntity } from '../../../database/entities/subscription.entity';
import { CenterProfileController } from './center-profile.controller';
import { CenterProfileService } from './center-profile.service';
import { CenterCommonModule } from '../common/center-common.module';
import { AuthModule } from '../../auth/auth.module';
import { UserModule } from '../../user/user.module';
import { S3Module } from '../../../s3/s3.module';
import { CapacityModule } from '../../capacity/capacity.module';
import { QnaModule } from '../../qna/qna.module';

@Module({
  imports: [
    CenterCommonModule,
    AuthModule,
    UserModule,
    QnaModule,
    S3Module,
    CapacityModule,
    TypeOrmModule.forFeature([
      CenterEntity,
      UserEntity,
      FileEntity,
      CenterTrainerEntity,
      SubscriptionEntity,
    ]),
  ],
  controllers: [CenterProfileController],
  providers: [CenterProfileService],
  exports: [CenterProfileService],
})
export class CenterProfileModule {}
