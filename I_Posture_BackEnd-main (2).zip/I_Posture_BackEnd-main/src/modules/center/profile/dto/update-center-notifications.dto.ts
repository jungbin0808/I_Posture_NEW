import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsOptional } from 'class-validator';

const toBoolean = (value: unknown): boolean | undefined => {
  if (value === undefined || value === null || value === '') return undefined;
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value as boolean;
};

export class UpdateCenterNotificationsDto {
  @ApiProperty({ description: '이벤트/프로모션 마케팅 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  eventMarketing?: boolean;

  @ApiProperty({ description: '내가 올린 질문 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  myQuestion?: boolean;

  @ApiProperty({ description: '챌린지 신청 결과 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  challengeResult?: boolean;

  @ApiProperty({ description: '이용권 사용량 완료 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  subscriptionUsage?: boolean;

  @ApiProperty({ description: '내가 올린 답변 채택 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  myAnswerAccepted?: boolean;

  @ApiProperty({ description: '적립금 정산 알림', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  pointSettlement?: boolean;
}
