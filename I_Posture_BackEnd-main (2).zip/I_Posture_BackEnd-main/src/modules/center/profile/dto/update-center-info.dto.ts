import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsOptional, IsString, IsUUID } from 'class-validator';

const toStringArray = (value: unknown): string[] | undefined => {
  if (value === undefined || value === null || value === '') return undefined;
  if (Array.isArray(value)) return value as string[];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [value];
    } catch {
      return value.split(',').map((item) => item.trim()).filter(Boolean);
    }
  }
  return undefined;
};

export class UpdateCenterInfoDto {
  @ApiProperty({ description: '센터명', required: false })
  @IsString()
  @IsOptional()
  centerName?: string;

  @ApiProperty({ description: '센터 주소', required: false })
  @IsString()
  @IsOptional()
  centerAddress?: string;

  @ApiProperty({ description: '센터 대표번호', required: false })
  @IsString()
  @IsOptional()
  centerPhone?: string;

  @ApiProperty({ description: '센터 소개', required: false })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({
    description: '유지할 센터 이미지 ID (JSON 배열 또는 콤마 구분)',
    required: false,
    example: '["uuid-1","uuid-2"]',
  })
  @Transform(({ value }) => toStringArray(value))
  @IsArray()
  @IsUUID('all', { each: true })
  @IsOptional()
  keepImageFileIds?: string[];
}
