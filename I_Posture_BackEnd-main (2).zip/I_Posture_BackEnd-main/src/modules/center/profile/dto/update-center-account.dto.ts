import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsOptional, IsString, Length, MinLength } from 'class-validator';

export class UpdateCenterAccountDto {
  @ApiProperty({ description: '휴대폰 번호', required: false })
  @IsString()
  @Length(1, 65)
  @IsOptional()
  phone?: string;

  @ApiProperty({ description: '변경할 이메일 (변경 시 verifiedToken 필수)', required: false })
  @IsEmail()
  @IsOptional()
  email?: string;

  @ApiProperty({ description: '이메일 인증 verifiedToken (email 변경 시 필수)', required: false })
  @IsString()
  @IsOptional()
  verifiedToken?: string;

  @ApiProperty({ description: '새 비밀번호 (변경 시, 최소 8자)', required: false })
  @IsString()
  @MinLength(8)
  @IsOptional()
  newPassword?: string;
}
