import { ApiProperty } from '@nestjs/swagger';

export class CenterProfileImageDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '이미지 URL' })
  fileUrl!: string;
}

export class AccountInfoDto {
  @ApiProperty({ description: '로그인 아이디' })
  userId!: string;

  @ApiProperty({ description: '이메일' })
  email!: string;

  @ApiProperty({ description: '휴대폰 번호' })
  phone!: string;
}

export class LogoInfoDto {
  @ApiProperty({ description: '센터 로고 URL', nullable: true })
  logoUrl?: string | null;
}

export class CenterInfoDto {
  @ApiProperty({ description: '센터 ID' })
  id!: string;

  @ApiProperty({ description: '센터명' })
  name!: string;

  @ApiProperty({ description: '센터 주소', nullable: true })
  address?: string;

  @ApiProperty({ description: '센터 대표번호', nullable: true })
  phone?: string;

  @ApiProperty({ description: '센터 소개', nullable: true })
  description?: string;

  @ApiProperty({ description: '센터 이미지', type: [CenterProfileImageDto] })
  images!: CenterProfileImageDto[];
}

export class NotificationSettingsDto {
  @ApiProperty({ description: '이벤트/프로모션 마케팅 푸시알림' })
  eventMarketing!: boolean;

  @ApiProperty({ description: '내가 올린 질문 알림' })
  myQuestion!: boolean;

  @ApiProperty({ description: '챌린지 신청 결과 알림' })
  challengeResult!: boolean;

  @ApiProperty({ description: '이용권 사용량 완료 알림' })
  subscriptionUsage!: boolean;

  @ApiProperty({ description: '내가 올린 답변 채택 알림' })
  myAnswerAccepted!: boolean;

  @ApiProperty({ description: '적립금 정산알림' })
  pointSettlement!: boolean;
}

export class CenterProfileResponseDto {
  @ApiProperty({ description: '유저 ID' })
  id!: string;

  @ApiProperty({ description: '센터 트레이너 수 (근무 중)' })
  centerTrainerCount!: number;

  @ApiProperty({ description: '나의 별점 지수 (5점 만점)' })
  myStarRating!: number;

  @ApiProperty({ description: '나의 질문 수' })
  myQuestionCount!: number;

  @ApiProperty({ description: '나의 답변 수' })
  myAnswerCount!: number;

  @ApiProperty({ description: '나의 챌린지 적립금' })
  myChallengePoints!: number;

  @ApiProperty({ description: '센터 이용권 사용 여부' })
  hasSubscription!: boolean;

  @ApiProperty({
    description: '센터 이용권 표시 문구 (예: 100GB 이용 중)',
    nullable: true,
  })
  subscriptionLabel!: string | null;

  @ApiProperty({ description: '가입 정보', type: AccountInfoDto })
  account!: AccountInfoDto;

  @ApiProperty({ description: '센터 로고', type: LogoInfoDto })
  logo!: LogoInfoDto;

  @ApiProperty({ description: '센터 정보', type: CenterInfoDto })
  center!: CenterInfoDto;

  @ApiProperty({ description: '알림 설정', type: NotificationSettingsDto })
  notifications!: NotificationSettingsDto;
}
