import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsOptional } from 'class-validator';

const toBoolean = (value: unknown): boolean | undefined => {
  if (value === undefined || value === null || value === '') return undefined;
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value as boolean;
};

export class UpdateCenterLogoDto {
  @ApiProperty({
    description: 'true 시 기존 로고 삭제 (logo 파일 없이 호출 가능)',
    required: false,
    example: false,
  })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  removeLogo?: boolean;
}
