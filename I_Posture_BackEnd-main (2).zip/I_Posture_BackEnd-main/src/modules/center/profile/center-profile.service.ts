import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import * as bcrypt from 'bcrypt';
import { CenterEntity } from '../../../database/entities/center.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../../database/entities/center-trainer.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { FileEntity, FileOwnerType, FileRelatedType } from '../../../database/entities/file.entity';
import { SubscriptionEntity, SubscriptionStatus } from '../../../database/entities/subscription.entity';
import { formatBytesDisplay } from '../../../common/utils/capacity.util';
import { QnaService } from '../../qna/qna.service';
import { EmailVerificationPurpose } from '../../../database/entities/email-verification.entity';
import { UserService } from '../../user/user.service';
import { AuthService } from '../../auth/auth.service';
import { S3Service } from '../../../s3/s3.service';
import { CapacityService } from '../../capacity/capacity.service';
import { CenterProfileResponseDto } from './dto/center-profile-response.dto';
import { UpdateCenterAccountDto } from './dto/update-center-account.dto';
import { UpdateCenterInfoDto } from './dto/update-center-info.dto';
import { UpdateCenterNotificationsDto } from './dto/update-center-notifications.dto';

const MAX_CENTER_IMAGES = 10;

@Injectable()
export class CenterProfileService {
  constructor(
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    private readonly userService: UserService,
    private readonly authService: AuthService,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    private readonly qnaService: QnaService,
  ) {}

  async findByOwnerId(ownerId: string): Promise<CenterEntity> {
    const center = await this.centerRepo.findOne({ where: { ownerId } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }
    return center;
  }

  async getMyProfile(ownerId: string): Promise<CenterProfileResponseDto> {
    const user = await this.userRepo.findOne({ where: { id: ownerId } });
    if (!user) {
      throw new NotFoundException('사용자 정보를 찾을 수 없습니다.');
    }

    const center = await this.findByOwnerId(ownerId);
    const imageFiles = await this.fileRepo.find({
      where: { relatedType: FileRelatedType.CENTER_GALLERY, relatedId: center.id },
      order: { createdAt: 'ASC' },
    });

    const [centerTrainerCount, qnaStats, activeSubscription] = await Promise.all([
      this.centerTrainerRepo.count({
        where: { centerId: center.id, status: CenterTrainerStatus.WORKING },
      }),
      this.qnaService.getMyStats(user),
      this.subscriptionRepo.findOne({
        where: { userId: ownerId, status: SubscriptionStatus.ACTIVE },
        relations: ['plan'],
      }),
    ]);

    const hasSubscription = !!activeSubscription;
    const subscriptionLabel = activeSubscription?.plan
      ? `${formatBytesDisplay(activeSubscription.plan.storageLimit)} 이용 중`
      : null;

    return {
      id: user.id,
      centerTrainerCount,
      myStarRating: qnaStats.starRating,
      myQuestionCount: qnaStats.myQuestionCount,
      myAnswerCount: qnaStats.myAnswerCount,
      myChallengePoints: user.totalPoints,
      hasSubscription,
      subscriptionLabel,
      account: {
        userId: user.userId,
        email: user.email,
        phone: user.phone ?? '',
      },
      logo: {
        logoUrl: center.logoUrl,
      },
      center: {
        id: center.id,
        name: center.name,
        address: center.address,
        phone: center.phone,
        description: center.description,
        images: imageFiles.map((file) => ({ id: file.id, fileUrl: file.fileUrl })),
      },
      notifications: {
        eventMarketing: user.notificationEventMarketing,
        myQuestion: user.notificationMyQuestion,
        challengeResult: user.notificationChallengeResult,
        subscriptionUsage: user.notificationSubscriptionUsage,
        myAnswerAccepted: user.notificationMyAnswerAccepted,
        pointSettlement: user.notificationPointSettlement,
      },
    };
  }

  @Transactional()
  async upsertLogo(user: UserEntity, logo: Express.Multer.File): Promise<CenterProfileResponseDto> {
    if (!logo) {
      throw new BadRequestException('로고 이미지(logo) 파일이 필요합니다.');
    }
    const center = await this.findByOwnerId(user.id);
    await this.removeLogoFiles(center, user, true);

    const uploaded = await this.s3Service.uploadFile(logo, {
      memberId: user.id,
      uploaderId: user.id,
      ownerType: FileOwnerType.CENTER,
      ownerId: center.id,
      relatedType: FileRelatedType.CENTER_LOGO,
      relatedId: center.id,
    });
    await this.capacityService.updateCenterCapacity(user, uploaded.size);

    center.logoUrl = uploaded.fileUrl;
    await this.centerRepo.save(center);

    return this.getMyProfile(user.id);
  }

  @Transactional()
  async deleteLogo(user: UserEntity): Promise<CenterProfileResponseDto> {
    const center = await this.findByOwnerId(user.id);
    await this.removeLogoFiles(center, user, true);
    return this.getMyProfile(user.id);
  }

  @Transactional()
  async updateAccount(userId: string, dto: UpdateCenterAccountDto): Promise<CenterProfileResponseDto> {
    if (dto.phone === undefined && dto.email === undefined && dto.newPassword === undefined) {
      throw new BadRequestException('수정할 항목이 없습니다.');
    }

    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('사용자 정보를 찾을 수 없습니다.');
    }

    if (dto.phone !== undefined) {
      user.phone = dto.phone;
    }

    if (dto.email !== undefined && dto.email !== user.email) {
      if (!dto.verifiedToken) {
        throw new BadRequestException('이메일 변경 시 이메일 인증(verifiedToken)이 필요합니다.');
      }

      const payload = await this.authService.consumeVerifiedEmailToken(
        dto.verifiedToken,
        EmailVerificationPurpose.REGISTER,
      );
      if (payload.email !== dto.email) {
        throw new BadRequestException('이메일 인증 정보와 입력한 이메일이 일치하지 않습니다.');
      }

      await this.authService.assertEmailAvailableForChange(dto.email, userId, user.userType);

      user.email = dto.email;
    }

    if (dto.newPassword !== undefined) {
      user.password = await bcrypt.hash(dto.newPassword.toLowerCase(), 10);
    }

    await this.userRepo.save(user);
    return this.getMyProfile(userId);
  }

  @Transactional()
  async updateCenterInfo(
    user: UserEntity,
    dto: UpdateCenterInfoDto,
    centerImages?: Express.Multer.File[],
  ): Promise<CenterProfileResponseDto> {
    const hasTextUpdate = dto.centerName !== undefined
      || dto.centerAddress !== undefined
      || dto.centerPhone !== undefined
      || dto.description !== undefined;
    const hasImageUpdate = dto.keepImageFileIds !== undefined
      || (centerImages !== undefined && centerImages.length > 0);

    if (!hasTextUpdate && !hasImageUpdate) {
      throw new BadRequestException('수정할 항목이 없습니다.');
    }

    const center = await this.findByOwnerId(user.id);

    if (dto.centerName !== undefined) center.name = dto.centerName;
    if (dto.centerAddress !== undefined) center.address = dto.centerAddress;
    if (dto.centerPhone !== undefined) center.phone = dto.centerPhone;
    if (dto.description !== undefined) center.description = dto.description;
    if (hasTextUpdate) {
      await this.centerRepo.save(center);
    }

    if (hasImageUpdate) {
      await this.syncCenterImages(user, center, dto.keepImageFileIds, centerImages);
    }

    return this.getMyProfile(user.id);
  }

  async updateNotifications(
    userId: string,
    dto: UpdateCenterNotificationsDto,
  ): Promise<CenterProfileResponseDto> {
    const hasUpdate = dto.eventMarketing !== undefined
      || dto.myQuestion !== undefined
      || dto.challengeResult !== undefined
      || dto.subscriptionUsage !== undefined
      || dto.myAnswerAccepted !== undefined
      || dto.pointSettlement !== undefined;

    if (!hasUpdate) {
      throw new BadRequestException('수정할 알림 항목이 없습니다.');
    }

    await this.userService.updateMyProfile(userId, { notifications: dto });
    return this.getMyProfile(userId);
  }

  async withdrawAccount(userId: string): Promise<{ success: boolean }> {
    return this.userService.withdrawAccount(userId);
  }

  async registerFcmToken(userId: string, fcmToken: string): Promise<void> {
    await this.userService.registerFcmToken(userId, fcmToken);
  }

  private async removeLogoFiles(
    center: CenterEntity,
    user: UserEntity,
    clearUrl: boolean,
  ): Promise<void> {
    const logoFiles = await this.fileRepo.find({
      where: { relatedType: FileRelatedType.CENTER_LOGO, relatedId: center.id },
    });

    for (const file of logoFiles) {
      await this.deleteFile(file, user);
    }

    if (clearUrl) {
      await this.centerRepo.update({ id: center.id }, { logoUrl: null });
      center.logoUrl = null;
    }
  }

  private async syncCenterImages(
    user: UserEntity,
    center: CenterEntity,
    keepImageFileIds: string[] | undefined,
    centerImages: Express.Multer.File[] | undefined,
  ): Promise<void> {
    const existingImages = await this.fileRepo.find({
      where: { relatedType: FileRelatedType.CENTER_GALLERY, relatedId: center.id },
    });

    if (keepImageFileIds !== undefined) {
      for (const file of existingImages) {
        if (!keepImageFileIds.includes(file.id)) {
          await this.deleteFile(file, user);
        }
      }
    }

    const newImageCount = centerImages?.length ?? 0;
    const remainingCount = keepImageFileIds !== undefined
      ? keepImageFileIds.length
      : existingImages.length;

    if (remainingCount + newImageCount > MAX_CENTER_IMAGES) {
      throw new BadRequestException(`센터 이미지는 최대 ${MAX_CENTER_IMAGES}장까지 등록할 수 있습니다.`);
    }

    if (centerImages && centerImages.length > 0) {
      for (const image of centerImages) {
        const uploaded = await this.s3Service.uploadFile(image, {
          memberId: user.id,
          uploaderId: user.id,
          ownerType: FileOwnerType.CENTER,
          ownerId: center.id,
          relatedType: FileRelatedType.CENTER_GALLERY,
          relatedId: center.id,
        });
        await this.capacityService.updateCenterCapacity(user, uploaded.size);
      }
    }
  }

  private async deleteFile(file: FileEntity, user: UserEntity): Promise<void> {
    await this.s3Service.deleteFile(file.s3Key);
    await this.capacityService.updateCenterCapacity(user, `-${file.size}`);
    await this.fileRepo.delete(file.id);
  }
}
