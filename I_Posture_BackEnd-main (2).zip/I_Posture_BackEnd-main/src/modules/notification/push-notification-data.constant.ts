/**
 * 푸시 알림의 FCM data payload에 담는 type 값.
 * 앱은 이 값으로 알림 클릭 시 이동할 화면을 분기한다.
 * FCM data는 전부 문자열(Record<string, string>)만 허용됨.
 */
export const PUSH_DATA_TYPE = {
  /** 체형측정 리포트 도착 - data: { reportId } → GET /body-reports/me/:reportId */
  TRAINER_REPORT_BODY: 'TRAINER_REPORT_BODY',
  /**
   * 정밀측정 리포트 도착 - data: { reportId, measurementType }
   * measurementType이 관절별(NECK/SHOULDER/ELBOW/TORSO/HIP/KNEE/ANKLE)이면 상세(GET /precision-reports/me/:reportId)로,
   * 척추/균형/전신(SPINAL_ALIGNMENT_TEST/BALANCE_TEST/OVERHEAD_SQUAT_TEST)이면 리포트(GET /precision-reports/me/:reportId/report)로 분기
   */
  TRAINER_REPORT_PRECISION: 'TRAINER_REPORT_PRECISION',
  /** 인바디 등록 - data: { reportId } → GET /inbody/me/:reportId */
  TRAINER_REPORT_INBODY: 'TRAINER_REPORT_INBODY',
  /** 식단 피드백 도착 - data: { logId } → 식단일지 상세 */
  DIET_FEEDBACK: 'DIET_FEEDBACK',
  /** 새 질문 등록 (트레이너 대상) - data: { questionId } → 질문 상세 */
  QNA_NEW_QUESTION: 'QNA_NEW_QUESTION',
  /** 답변 등록 (질문 작성자 대상) - data: { questionId } → 질문 상세 */
  QNA_ANSWER: 'QNA_ANSWER',
  /** 답변 채택/별점 (답변 작성자 대상) - data: { questionId, answerId } → 질문 상세 */
  QNA_ANSWER_ACCEPTED: 'QNA_ANSWER_ACCEPTED',
  /** 포인트 지급 - 특정 리소스 없음 → 포인트 내역 화면 */
  POINT_SETTLEMENT: 'POINT_SETTLEMENT',
  /** 체형·인바디 측정 주기 리마인드 (배치) - 특정 리소스 없음 → 측정 메인 화면 */
  BODY_MEASUREMENT_CYCLE: 'BODY_MEASUREMENT_CYCLE',
  /** 운동 루틴 리마인드 (배치) - 특정 리소스 없음 → 오늘의 운동 화면 */
  WORKOUT_ROUTINE: 'WORKOUT_ROUTINE',
} as const;

export type PushDataType = (typeof PUSH_DATA_TYPE)[keyof typeof PUSH_DATA_TYPE];
