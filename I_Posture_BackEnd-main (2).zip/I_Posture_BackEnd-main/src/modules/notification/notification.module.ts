import { Global, Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PushNotificationLogEntity } from '../../database/entities/push-notification-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { UserNotificationEntity } from '../../database/entities/user-notification.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { AppMeasurementModule } from '../app/measurement/app-measurement.module';
import { FcmService } from './fcm.service';
import { UserNotificationService } from './user-notification.service';
import { MemberNotificationService } from './member-notification.service';
import { ScheduledPushScheduler } from './scheduled-push.scheduler';

@Global()
@Module({
  imports: [
    TypeOrmModule.forFeature([
      UserEntity,
      PushNotificationLogEntity,
      UserNotificationEntity,
      MemberIdentityLinkEntity,
      BodyReportEntity,
      InbodyDataEntity,
    ]),
    AppMeasurementModule,
  ],
  providers: [FcmService, UserNotificationService, MemberNotificationService, ScheduledPushScheduler],
  exports: [FcmService, UserNotificationService, MemberNotificationService],
})
export class NotificationModule {}
