import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { MEASUREMENT_TYPE } from '../../common/enums/measurement-type.enum';
import { FcmService } from './fcm.service';
import { PUSH_DATA_TYPE } from './push-notification-data.constant';

/**
 * 트레이너가 관리회원(C) 기준으로 등록하는 데이터(체형측정/정밀측정/인바디 등)의 실제 알림 수신자는
 * 연동된 앱회원(A)이므로, 발송 전에 항상 이 매핑을 거쳐야 함. 연동된 앱회원이 없으면(트레이너 자체 관리용
 * 회원이라 USER APP 계정이 없는 경우) 조용히 건너뜀.
 */
@Injectable()
export class MemberNotificationService {
  private readonly logger = new Logger(MemberNotificationService.name);

  constructor(
    private readonly fcmService: FcmService,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
  ) {}

  private dispatchAfterCommit(task: () => Promise<unknown>, errorLabel: string): void {
    setImmediate(() => {
      task().catch((error) => this.logger.error(errorLabel, error));
    });
  }

  private async resolveAppMemberId(managedMemberId: string): Promise<string | null> {
    const link = await this.identityLinkRepo.findOne({
      where: { managedMemberId, status: IdentityLinkStatus.LINKED },
    });
    return link?.appMemberId ?? null;
  }

  /** 트레이너가 체형측정/정밀측정을 등록·분석 완료했을 때 */
  notifyTrainerReport(managedMemberId: string, reportId: string, measurementType: MEASUREMENT_TYPE | 'BODY'): void {
    this.dispatchAfterCommit(async () => {
      const appMemberId = await this.resolveAppMemberId(managedMemberId);
      if (!appMemberId) return;

      const data: Record<string, string> = measurementType === 'BODY'
        ? { type: PUSH_DATA_TYPE.TRAINER_REPORT_BODY, reportId }
        : { type: PUSH_DATA_TYPE.TRAINER_REPORT_PRECISION, reportId, measurementType };

      await this.fcmService.sendToUser(
        appMemberId,
        {
          title: '트레이너 분석 리포트가 도착했어요',
          body: '트레이너가 직접 분석한 맞춤 리포트가 도착했어요! 내 몸의 상태와 변화를 분석한 결과를 확인해보세요.',
          data,
        },
        'notificationTrainerReport',
      );
    }, '트레이너 분석 리포트 알림 발송 실패');
  }

  /** 트레이너가 인바디를 등록했을 때 */
  notifyInbodyReport(managedMemberId: string, reportId: string): void {
    this.dispatchAfterCommit(async () => {
      const appMemberId = await this.resolveAppMemberId(managedMemberId);
      if (!appMemberId) return;

      await this.fcmService.sendToUser(
        appMemberId,
        {
          title: '트레이너 분석 리포트가 도착했어요',
          body: '트레이너가 직접 분석한 맞춤 리포트가 도착했어요! 내 몸의 상태와 변화를 분석한 결과를 확인해보세요.',
          data: { type: PUSH_DATA_TYPE.TRAINER_REPORT_INBODY, reportId },
        },
        'notificationTrainerReport',
      );
    }, '인바디 리포트 알림 발송 실패');
  }

  /** 트레이너가 식단일지에 피드백을 작성·수정했을 때 (food_logs는 앱회원 ID 기준이라 변환 불필요) */
  notifyDietFeedback(appMemberId: string, logId: string): void {
    this.dispatchAfterCommit(
      () => this.fcmService.sendToUser(
        appMemberId,
        {
          title: '식단 피드백이 도착했어요',
          body: '담당 트레이너가 보낸 1:1 맞춤 피드백이 업데이트되었습니다. 오늘 식단의 방향을 꼼꼼히 점검해 보세요.',
          data: { type: PUSH_DATA_TYPE.DIET_FEEDBACK, logId },
        },
        'notificationDietFeedback',
      ),
      '식단 피드백 알림 발송 실패',
    );
  }
}
