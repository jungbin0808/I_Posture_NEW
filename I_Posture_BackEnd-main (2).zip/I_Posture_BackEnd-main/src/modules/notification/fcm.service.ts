import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import * as admin from 'firebase-admin';
import * as fs from 'fs';
import * as path from 'path';
import { Repository } from 'typeorm';
import { PushNotificationLogEntity } from '../../database/entities/push-notification-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { UserNotificationType } from '../../database/entities/user-notification.entity';
import { UserNotificationService } from './user-notification.service';

export interface PushPayload {
  title: string;
  body: string;
  data?: Record<string, string>;
}

@Injectable()
export class FcmService implements OnModuleInit {
  private readonly logger = new Logger(FcmService.name);
  private app: admin.app.App | null = null;

  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(PushNotificationLogEntity)
    private readonly pushLogRepo: Repository<PushNotificationLogEntity>,
    private readonly userNotificationService: UserNotificationService,
  ) {}

  onModuleInit() {
    if (admin.apps.length > 0) {
      this.app = admin.apps[0]!;
      return;
    }
    try {
      const serviceAccount = this.loadServiceAccount();
      this.app = admin.initializeApp({
        credential: admin.credential.cert(serviceAccount),
      });
      this.logger.log('Firebase Admin SDK 초기화 완료');
    } catch (e) {
      this.logger.error(
        'Firebase Admin SDK 초기화 실패 (certs/firebase/firebase-certification.json 또는 FIREBASE_SERVICE_ACCOUNT_JSON 확인)',
        e,
      );
    }
  }

  /**
   * 특정 유저에게 푸시 발송
   * @param notificationField 확인할 알림 설정 필드 (없으면 설정 무관 항상 발송)
   */
  async sendToUser(
    userId: string,
    payload: PushPayload,
    notificationField?: keyof UserEntity,
    options?: { skipInbox?: boolean },
  ): Promise<boolean> {
    if (!options?.skipInbox) {
      await this.userNotificationService.createForUser(userId, {
        type: UserNotificationType.APP,
        title: payload.title,
        body: payload.body,
        data: payload.data,
      });
    }

    const qb = this.userRepo
      .createQueryBuilder('u')
      .select(['u.id', 'u.fcmToken'])
      .where('u.id = :userId', { userId })
      .andWhere('u.fcmToken IS NOT NULL');

    if (notificationField) {
      qb.addSelect(`u.${notificationField as string}`);
      qb.andWhere(`u.${notificationField as string} = :enabled`, { enabled: true });
      // 전체 알림 받기(마스터 토글)가 꺼져 있으면 카테고리 설정과 무관하게 발송 안 함
      if (notificationField !== 'notificationAll') {
        qb.andWhere('u.notificationAll = :notificationAllEnabled', { notificationAllEnabled: true });
      }
    }

    const user = await qb.getOne();
    if (!user?.fcmToken) {
      const reason = notificationField
        ? `FCM 토큰 없음 또는 알림 설정(${notificationField}) OFF`
        : 'FCM 토큰 없음';
      this.logger.debug(`유저 ${userId} 푸시 건너뜀: ${reason}`);
      return false;
    }

    return this.sendToToken(user.fcmToken, payload, userId);
  }

  /**
   * 여러 유저에게 푸시 발송
   * @param notificationField 확인할 알림 설정 필드 (없으면 설정 무관 항상 발송)
   */
  async sendToUsers(
    userIds: string[],
    payload: PushPayload,
    notificationField?: keyof UserEntity,
    options?: { skipInbox?: boolean },
  ): Promise<void> {
    if (!userIds.length) return;

    if (!options?.skipInbox) {
      await this.userNotificationService.createForUsers(userIds, {
        type: UserNotificationType.APP,
        title: payload.title,
        body: payload.body,
        data: payload.data,
      });
    }

    const qb = this.userRepo
      .createQueryBuilder('u')
      .select(['u.id', 'u.fcmToken'])
      .where('u.id IN (:...ids)', { ids: userIds })
      .andWhere('u.fcmToken IS NOT NULL');
    if (notificationField) {
      qb.addSelect(`u.${notificationField as string}`).andWhere(`u.${notificationField as string} = true`);
      // 전체 알림 받기(마스터 토글)가 꺼져 있으면 카테고리 설정과 무관하게 발송 안 함
      if (notificationField !== 'notificationAll') {
        qb.andWhere('u.notificationAll = true');
      }
    }
    const users = await qb.getMany();

    await Promise.all(users.map((u) => this.sendToToken(u.fcmToken!, payload, u.id)));
  }

  /**
   * FCM 토큰으로 직접 발송 + 이력 저장
   */
  private async sendToToken(token: string, payload: PushPayload, userId: string): Promise<boolean> {
    if (!this.app) {
      this.logger.warn('Firebase가 초기화되지 않아 푸시를 발송할 수 없습니다.');
      return false;
    }

    let status: 'SUCCESS' | 'FAILED' = 'SUCCESS';
    let errorMsg: string | undefined;

    try {
      await this.app.messaging().send({
        token,
        notification: { title: payload.title, body: payload.body },
        data: payload.data,
        apns: { payload: { aps: { sound: 'default' } } },
        android: { notification: { sound: 'default' } },
      });
    } catch (e: any) {
      status = 'FAILED';
      errorMsg = e?.message ?? String(e);
      this.logger.error(`FCM 발송 실패 (userId: ${userId}): ${errorMsg}`);

      // 토큰 만료/무효 시 DB에서 제거
      const invalidCodes = [
        'messaging/registration-token-not-registered',
        'messaging/invalid-registration-token',
      ];
      if (invalidCodes.includes(e?.errorInfo?.code)) {
        await this.userRepo.update({ id: userId }, { fcmToken: undefined });
        this.logger.log(`만료된 FCM 토큰 제거 (userId: ${userId})`);
      }
    }

    await this.pushLogRepo.save(
      this.pushLogRepo.create({
        userId,
        title: payload.title,
        body: payload.body,
        data: payload.data,
        fcmToken: token,
        status,
        errorMsg,
      }),
    );

    return status === 'SUCCESS';
  }

  private loadServiceAccount(): admin.ServiceAccount {
    const jsonFromEnv = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
    if (jsonFromEnv) {
      return JSON.parse(jsonFromEnv) as admin.ServiceAccount;
    }

    const certPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH
      ?? path.resolve(process.cwd(), 'certs/firebase/firebase-certification.json');

    return JSON.parse(fs.readFileSync(certPath, 'utf-8')) as admin.ServiceAccount;
  }
}
