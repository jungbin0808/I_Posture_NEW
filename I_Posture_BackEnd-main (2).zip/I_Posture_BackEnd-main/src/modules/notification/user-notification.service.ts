import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, IsNull, Repository } from 'typeorm';
import {
  AccountStatus,
  UserEntity,
  UserType,
} from '../../database/entities/user.entity';
import {
  UserNotificationEntity,
  UserNotificationType,
} from '../../database/entities/user-notification.entity';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';

export interface CreateUserNotificationInput {
  type: UserNotificationType;
  title: string;
  body: string;
  data?: Record<string, string>;
}

export interface FindUserNotificationsOptions {
  page?: number;
  limit?: number;
  type?: UserNotificationType;
}

@Injectable()
export class UserNotificationService {
  constructor(
    @InjectRepository(UserNotificationEntity)
    private readonly notificationRepo: Repository<UserNotificationEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
  ) {}

  async createForUser(userId: string, input: CreateUserNotificationInput): Promise<UserNotificationEntity> {
    return this.notificationRepo.save(
      this.notificationRepo.create({
        userId,
        type: input.type,
        title: input.title,
        body: input.body,
        data: input.data,
      }),
    );
  }

  async createForUsers(userIds: string[], input: CreateUserNotificationInput): Promise<void> {
    if (!userIds.length) {
      return;
    }

    const uniqueUserIds = [...new Set(userIds)];
    const chunkSize = 500;

    for (let i = 0; i < uniqueUserIds.length; i += chunkSize) {
      const chunk = uniqueUserIds.slice(i, i + chunkSize);
      await this.notificationRepo.save(
        chunk.map((userId) =>
          this.notificationRepo.create({
            userId,
            type: input.type,
            title: input.title,
            body: input.body,
            data: input.data,
          }),
        ),
      );
    }
  }

  async broadcastToUserTypes(
    targetUserTypes: UserType[],
    input: CreateUserNotificationInput,
  ): Promise<{ userIds: string[]; createdCount: number }> {
    if (!targetUserTypes.length) {
      return { userIds: [], createdCount: 0 };
    }

    const users = await this.userRepo.find({
      where: {
        userType: In(targetUserTypes),
        accountStatus: AccountStatus.ACTIVE,
      },
      select: ['id'],
    });
    const userIds = users.map((user) => user.id);
    await this.createForUsers(userIds, input);

    return { userIds, createdCount: userIds.length };
  }

  async findAllForUser(
    userId: string,
    options: FindUserNotificationsOptions = {},
  ): Promise<IPageData<UserNotificationEntity>> {
    const page = options.page ?? 1;
    const limit = options.limit ?? 10;

    const qb = this.notificationRepo
      .createQueryBuilder('notification')
      .where('notification.user_id = :userId', { userId })
      .orderBy('notification.created_at', 'DESC')
      .addOrderBy('notification.id', 'ASC')
      .skip((page - 1) * limit)
      .take(limit);

    if (options.type) {
      qb.andWhere('notification.type = :type', { type: options.type });
    }

    const [items, total] = await qb.getManyAndCount();
    return { items, paging: buildPaging(total, limit, page) };
  }

  async markAsRead(userId: string, notificationId: string): Promise<UserNotificationEntity> {
    const notification = await this.notificationRepo.findOne({
      where: { id: notificationId, userId },
    });
    if (!notification) {
      throw new NotFoundException('알림을 찾을 수 없습니다.');
    }

    if (!notification.readAt) {
      notification.readAt = new Date();
      return this.notificationRepo.save(notification);
    }

    return notification;
  }

  async hasUnread(userId: string): Promise<boolean> {
    const count = await this.notificationRepo.count({
      where: { userId, readAt: IsNull() },
    });
    return count > 0;
  }

  toListItem(notification: UserNotificationEntity) {
    return {
      id: notification.id,
      type: notification.type,
      title: notification.title,
      body: notification.body,
      isRead: notification.readAt != null,
      createdAt: notification.createdAt.toISOString(),
      data: notification.data,
    };
  }
}
