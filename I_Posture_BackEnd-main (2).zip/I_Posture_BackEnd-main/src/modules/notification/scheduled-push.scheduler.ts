import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { Between, Repository } from 'typeorm';
import { AccountStatus, MemberType, UserEntity } from '../../database/entities/user.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { addMonthsClamp, getUtcDateString } from '../../common/utils/date.util';
import { AppMeasurementService } from '../app/measurement/app-measurement.service';
import { FcmService } from './fcm.service';
import { PUSH_DATA_TYPE } from './push-notification-data.constant';

/**
 * 알림 설정 세분화(6-5)의 배치성 카테고리 2종.
 * - 체형·인바디 측정 주기: "1개월 전 그날 측정하고 그 뒤로 재측정이 없는" 회원에게 리마인더. KST 09:00(UTC 00:00)
 * - 운동 루틴: 매일 활성 회원 전체에게 "오늘의 맞춤 운동 확인" 유도 (5그룹 추천 결과는 앱에서 직접 확인). KST 13:00(UTC 04:00) - 기획 스펙: 오후 1시~1시 20분
 * env NOTIFICATION_SCHEDULER_ENABLED=true일 때만 동작.
 */
@Injectable()
export class ScheduledPushScheduler {
  private readonly logger = new Logger(ScheduledPushScheduler.name);
  private readonly enabled: boolean;

  constructor(
    private readonly configService: ConfigService,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly appMeasurementService: AppMeasurementService,
    private readonly fcmService: FcmService,
  ) {
    this.enabled = this.configService.get<string>('NOTIFICATION_SCHEDULER_ENABLED') === 'true';
  }

  private async resolveAppMemberId(candidateId: string): Promise<string | null> {
    const asManaged = await this.identityLinkRepo.findOne({
      where: { managedMemberId: candidateId, status: IdentityLinkStatus.LINKED },
    });
    if (asManaged) return asManaged.appMemberId;

    // identity_links에 관리회원으로 없으면 그 자체가 셀프측정 앱회원 ID
    const asAppMember = await this.userRepo.findOne({ where: { id: candidateId, memberType: MemberType.APP } });
    return asAppMember ? asAppMember.id : null;
  }

  // 매일 UTC 00:00 (KST 09:00)
  @Cron('0 0 * * *')
  async handleBodyMeasurementCycleReminder(): Promise<void> {
    if (!this.enabled) {
      this.logger.log('알림 스케줄러 비활성화 상태 (NOTIFICATION_SCHEDULER_ENABLED=false)');
      return;
    }
    this.logger.log('체형·인바디 측정 주기 알림 배치 시작');

    const targetDate = addMonthsClamp(new Date(), -1);
    const dayStart = new Date(Date.UTC(targetDate.getUTCFullYear(), targetDate.getUTCMonth(), targetDate.getUTCDate(), 0, 0, 0));
    const dayEnd = new Date(Date.UTC(targetDate.getUTCFullYear(), targetDate.getUTCMonth(), targetDate.getUTCDate(), 23, 59, 59, 999));
    const targetDateStr = getUtcDateString(targetDate);

    const [bodyCandidates, inbodyCandidates] = await Promise.all([
      this.bodyReportRepo.find({ where: { createdAt: Between(dayStart, dayEnd) }, select: ['userId'] }),
      this.inbodyDataRepo.find({ where: { measuredAt: Between(dayStart, dayEnd) }, select: ['userId'] }),
    ]);
    const candidateIds = [...new Set([...bodyCandidates.map((r) => r.userId), ...inbodyCandidates.map((r) => r.userId)])];

    let sentCount = 0;
    for (const candidateId of candidateIds) {
      const appMemberId = await this.resolveAppMemberId(candidateId);
      if (!appMemberId) continue;

      // 그 이후 재측정이 없어야 발송 (최신 측정일이 여전히 1개월 전 그날인 경우만)
      const latest = await this.appMeasurementService.getLatestMeasurementDate(appMemberId);
      if (!latest || getUtcDateString(latest) !== targetDateStr) continue;

      const sent = await this.fcmService.sendToUser(
        appMemberId,
        {
          title: '한 달 전과 비교해 내 몸은 얼마나 달라졌을까요?',
          body: '지금 체형 측정과 인바디 결과를 등록하고, 눈에 보이는 변화를 확인해보세요.',
          data: { type: PUSH_DATA_TYPE.BODY_MEASUREMENT_CYCLE },
        },
        'notificationBodyMeasurementCycle',
      );
      if (sent) sentCount += 1;
    }

    this.logger.log(`체형·인바디 측정 주기 알림 배치 완료 (후보 ${candidateIds.length}명 중 ${sentCount}명 발송)`);
  }

  // 매일 UTC 04:00 (KST 13:00) - 기획 스펙: 오후 1시~1시 20분 자동발송
  @Cron('0 4 * * *')
  async handleWorkoutRoutineReminder(): Promise<void> {
    if (!this.enabled) return;
    this.logger.log('운동 루틴 알림 배치 시작');

    const members = await this.userRepo.find({
      where: { memberType: MemberType.APP, accountStatus: AccountStatus.ACTIVE },
      select: ['id'],
    });

    await this.fcmService.sendToUsers(
      members.map((m) => m.id),
      {
        title: '오늘의 맞춤 운동이 도착했어요',
        body: '나의 상황에 딱 맞는 1:1 맞춤 코칭 운동이 도착했습니다. 지금 바로 내 몸에 최적화된 오늘의 맞춤 운동을 확인해보세요.',
        data: { type: PUSH_DATA_TYPE.WORKOUT_ROUTINE },
      },
      'notificationWorkoutRoutine',
    );

    this.logger.log(`운동 루틴 알림 배치 완료 (대상 후보 ${members.length}명)`);
  }
}
