import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsDateString, IsEnum, IsInt, IsJSON, IsNotEmpty, IsOptional, IsString, IsUUID, Max, Min } from 'class-validator';
import { AttendanceStatus } from '../../../database/entities/workout-log.entity';

export class CreateWorkoutLogDto {
  @ApiProperty({ description: '연동된 스케줄 ID', required: false })
  @IsUUID()
  @IsOptional()
  scheduleId?: string;

  @ApiProperty({ description: '출석 상태', enum: AttendanceStatus, default: AttendanceStatus.PRESENT })
  @IsEnum(AttendanceStatus)
  @IsOptional()
  attendance?: AttendanceStatus;

  @ApiProperty({ description: '운동 진행 일시' })
  @IsDateString()
  @IsNotEmpty()
  workoutDate!: string;

  @ApiProperty({ description: '운동 주제', required: false })
  @IsString()
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '타겟 부위 코드 목록 (JSON)', required: false })
  @IsOptional()
  targetParts?: any;

  @ApiProperty({ description: '운동 세트 구성 목록 (JSON)', required: false })
  @IsOptional()
  exercises?: any;

  @ApiProperty({ description: '연동할 모션 분석 ID', required: false })
  @IsUUID()
  @IsOptional()
  motionAnalysisId?: string;

  @ApiProperty({ description: '개선사항', required: false })
  @IsString()
  @IsOptional()
  feedbackImprove?: string;

  @ApiProperty({ description: '주의사항', required: false })
  @IsString()
  @IsOptional()
  feedbackCaution?: string;

  @ApiProperty({ description: '불편한 부위 태그 목록 (JSON)', required: false })
  @IsOptional()
  uncomfortableParts?: any;

  @ApiProperty({ description: '불편한 부위 직접입력', required: false })
  @IsString()
  @IsOptional()
  uncomfortableText?: string;

  @ApiProperty({ description: '운동 단기 목표명', required: false })
  @IsString()
  @IsOptional()
  goalTitle?: string;

  @ApiProperty({ description: '달성률 퍼센트 (0~100)', required: false })
  @IsInt()
  @Min(0)
  @Max(100)
  @IsOptional()
  goalPercent?: number;
}
