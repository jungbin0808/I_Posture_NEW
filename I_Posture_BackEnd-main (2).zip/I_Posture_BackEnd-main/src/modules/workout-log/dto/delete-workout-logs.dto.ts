import { ApiProperty } from '@nestjs/swagger';
import { ArrayNotEmpty, IsArray, IsUUID } from 'class-validator';

export class DeleteWorkoutLogsDto {
  @ApiProperty({ description: '삭제할 운동 일지 ID 목록', type: [String] })
  @IsArray()
  @ArrayNotEmpty()
  @IsUUID('all', { each: true })
  logIds!: string[];
}
