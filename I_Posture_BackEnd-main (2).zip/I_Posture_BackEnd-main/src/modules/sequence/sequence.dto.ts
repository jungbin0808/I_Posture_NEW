import { IsArray, IsBoolean, IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, Min, ValidateNested, IsIn } from "class-validator";
import { Transform, Type } from "class-transformer";
import { SequenceCategoryType } from "../../database/entities/sequence-detail.entity";

export enum SortOrder {
  ASC = 'ASC',
  DESC = 'DESC',
}

export class FindSequenceDto {
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page: number = 1;

  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit: number = 10;

  @IsOptional()
  @IsString()
  search?: string;

  @IsOptional()
  @IsEnum(SortOrder)
  sort: SortOrder = SortOrder.DESC;

  @IsOptional()
  @IsString()
  groupId?: string;

  @IsOptional()
  @Transform(({ value }) => {
    if (value === 'true') return true;
    if (value === 'false') return false;
    return undefined;
  })
  @IsBoolean()
  isActive?: boolean;
}

export class SequenceListItemDto {
  id!: string;
  thumbnailUrl?: string;
  title!: string;
  exerciseCount!: number;
  duration!: number;
  scheduleCount!: number;
  createdAt!: Date;
  isActive!: boolean;
  groups?: { id: string; name: string }[];
}

export class FindSequenceForScheduleDto {
  @IsOptional()
  @IsString()
  search?: string;
}

export class SequenceForScheduleItemDto {
  id!: string;
  title!: string;
  thumbnailUrl?: string;
  duration!: number;
  exerciseCount!: number;
}

export class SequenceGroupForScheduleDto {
  id!: string;
  name!: string;
  sequences!: SequenceForScheduleItemDto[];
}

export class SequenceForScheduleResponseDto {
  groups!: SequenceGroupForScheduleDto[];
  ungroupedSequences!: SequenceForScheduleItemDto[];
}

export class CreateSequenceDetailDto {
  @IsOptional()
  @IsString()
  exerciseId?: string; // 원본 운동 ID

  @IsOptional()
  @IsString()
  existingDetailId?: string; // 수정 시 기존 이미지 유지를 위한 기존 detail ID

  @IsBoolean()
  isCustom!: boolean;

  @IsInt()
  stepOrder!: number;

  @IsEnum(SequenceCategoryType)
  categoryType!: SequenceCategoryType;

  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsInt()
  @Type(() => Number)
  detailImageIndex?: number;
}

export class CreateSequenceDto {
  @IsString()
  @IsNotEmpty()
  title!: string;

  @IsOptional()
  @IsString()
  note?: string;

  @IsInt()
  @Type(() => Number)
  duration!: number;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  sequenceGroupIds?: string[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateSequenceDetailDto)
  details!: CreateSequenceDetailDto[];
}

export class UpdateSequenceDto extends CreateSequenceDto {}

export class UpdateSequenceStatusDto {
  @IsArray()
  @IsString({ each: true })
  @IsNotEmpty({ each: true })
  ids!: string[];

  @IsBoolean()
  isActive!: boolean;
}

export class AssignSequenceToScheduleDto {
  @IsString()
  @IsNotEmpty()
  scheduleId!: string;
}

