import { ForbiddenException, Injectable, NotFoundException, BadRequestException, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { DataSource, In, Repository } from "typeorm";
import { Transactional } from "typeorm-transactional";
import { SequenceEntity } from "../../database/entities/sequence.entity";
import { SequenceDetailEntity } from "../../database/entities/sequence-detail.entity";
import { AssignSequenceToScheduleDto, CreateSequenceDetailDto, CreateSequenceDto, FindSequenceDto, SequenceForScheduleItemDto, SequenceForScheduleResponseDto, SequenceGroupForScheduleDto, SequenceListItemDto, UpdateSequenceDto, UpdateSequenceStatusDto } from "./sequence.dto";
import { IPageData } from "../../common/response/response.interface";
import { buildPaging } from "../../common/response/response.helper";
import { ScheduleEntity } from "../../database/entities/schedule.entity";
import { FileEntity, FileOwnerType, FileRelatedType } from "../../database/entities/file.entity";
import { S3Service } from "../../s3/s3.service";
import { UserEntity } from "../../database/entities/user.entity";
import { ExerciseEntity } from "../../database/entities/exercise.entity";
import { SequenceGroupMappingEntity } from "../../database/entities/sequence-group-mapping.entity";
import { SequenceGroupEntity } from "../../database/entities/sequence-group.entity";
import { CapacityService } from "../capacity/capacity.service";

@Injectable()
export class SequenceService {
  private readonly logger = new Logger(SequenceService.name);

  constructor(
    @InjectRepository(SequenceEntity)
    private readonly sequenceRepo: Repository<SequenceEntity>,
    @InjectRepository(SequenceDetailEntity)
    private readonly detailRepo: Repository<SequenceDetailEntity>,
    @InjectRepository(ExerciseEntity)
    private readonly exerciseRepo: Repository<ExerciseEntity>,
    @InjectRepository(SequenceGroupMappingEntity)
    private readonly mappingRepo: Repository<SequenceGroupMappingEntity>,
    @InjectRepository(ScheduleEntity)
    private readonly scheduleRepo: Repository<ScheduleEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    private readonly dataSource: DataSource,
  ) {}

  /**
   * 일정 등록용 시퀀스 목록 조회 (그룹 → 그룹없는 순, 페이징 없음)
   */
  async findForSchedule(trainerId: string, search?: string): Promise<SequenceForScheduleResponseDto> {
    // 1. 모든 그룹 조회
    const groupRepo = this.mappingRepo.manager.getRepository(SequenceGroupEntity);
    const groups = await groupRepo.find({ where: { trainerId }, order: { createdAt: 'DESC' } });
    const groupIds = groups.map(g => g.id);

    // 2. 그룹-시퀀스 매핑 전체 조회
    const mappings = groupIds.length > 0
      ? await this.mappingRepo.find({ where: { sequenceGroupId: In(groupIds) } })
      : [];

    // 3. 시퀀스 원시 데이터 조회 (검색 필터 포함)
    const seqQuery = this.sequenceRepo.createQueryBuilder('seq')
      .select('seq.id', 'id')
      .addSelect('seq.title', 'title')
      .addSelect('seq.duration', 'duration')
      .addSelect(
        sub => sub.select('COUNT(d.id)').from(SequenceDetailEntity, 'd').where('d.sequenceId = seq.id'),
        'exerciseCount',
      )
      .addSelect(
        sub => sub.select('f.fileUrl').from(FileEntity, 'f')
          .where('f.relatedId = seq.id')
          .andWhere('f.relatedType = :rt', { rt: FileRelatedType.SEQUENCE_THUMBNAIL }),
        'thumbnailUrl',
      )
      .where('seq.trainerId = :trainerId', { trainerId });

    if (search) seqQuery.andWhere('seq.title LIKE :search', { search: `%${search}%` });

    const rawSeqs = await seqQuery.orderBy('seq.createdAt', 'DESC').getRawMany();

    // 4. seqId → DTO 맵
    const seqMap = new Map<string, SequenceForScheduleItemDto>();
    for (const raw of rawSeqs) {
      seqMap.set(raw.id, {
        id: raw.id,
        title: raw.title,
        duration: Number(raw.duration),
        exerciseCount: parseInt(raw.exerciseCount, 10) || 0,
        thumbnailUrl: raw.thumbnailUrl ?? undefined,
      });
    }

    // 5. groupId → sequenceId[] 맵
    const groupSeqMap = new Map<string, string[]>();
    for (const m of mappings) {
      if (!groupSeqMap.has(m.sequenceGroupId)) groupSeqMap.set(m.sequenceGroupId, []);
      groupSeqMap.get(m.sequenceGroupId)!.push(m.sequenceId);
    }

    // 6. 그룹 DTO 조합 (검색 결과에 매핑되는 시퀀스가 있는 그룹만)
    const groupDtos: SequenceGroupForScheduleDto[] = [];
    for (const g of groups) {
      const seqIds = groupSeqMap.get(g.id) ?? [];
      const sequences = seqIds.map(id => seqMap.get(id)).filter((s): s is SequenceForScheduleItemDto => !!s);
      if (sequences.length > 0) {
        groupDtos.push({ id: g.id, name: g.name, sequences });
      }
    }

    // 7. 그룹 없는 시퀀스
    const groupedSeqIds = new Set(mappings.map(m => m.sequenceId));
    const ungroupedSequences = rawSeqs
      .filter(raw => !groupedSeqIds.has(raw.id))
      .map(raw => seqMap.get(raw.id)!)
      .filter(Boolean);

    return { groups: groupDtos, ungroupedSequences };
  }

  async findAll(trainerId: string, dto: FindSequenceDto): Promise<IPageData<SequenceListItemDto>> {
    const query = this.sequenceRepo.createQueryBuilder('seq')
      .select([
        'seq.id as id',
        'seq.title as title',
        'seq.duration as duration',
        'seq.createdAt as createdAt',
        'seq.isActive as isActive',
      ])
      .addSelect(subQuery => {
        return subQuery.select('COUNT(detail.id)').from(SequenceDetailEntity, 'detail').where('detail.sequenceId = seq.id');
      }, 'exerciseCount')
      .addSelect(subQuery => {
        return subQuery.select('COUNT(sch.id)').from(ScheduleEntity, 'sch').where('sch.sequenceId = seq.id');
      }, 'scheduleCount')
      .addSelect(subQuery => {
        return subQuery.select('file.fileUrl').from(FileEntity, 'file').where('file.relatedId = seq.id').andWhere('file.relatedType = :relatedType', { relatedType: FileRelatedType.SEQUENCE_THUMBNAIL });
      }, 'thumbnailUrl')
      .addSelect(subQuery => {
        return subQuery
          .select("IFNULL(JSON_ARRAYAGG(JSON_OBJECT('id', `group`.`id`, 'name', `group`.`name`)), '[]')")
          .from(SequenceGroupMappingEntity, 'map')
          .innerJoin(SequenceGroupEntity, 'group', 'map.sequenceGroupId = `group`.id')
          .where('map.sequenceId = seq.id');
      }, 'groups')
      .where('seq.trainerId = :trainerId', { trainerId });

    if (dto.isActive !== undefined) {
      query.andWhere('seq.isActive = :isActive', { isActive: dto.isActive });
    }

    if (dto.search) {
      query.andWhere('seq.title LIKE :search', { search: `%${dto.search}%` });
    }

    if (dto.groupId) {
      query.innerJoin('seq.sequenceGroupMappings', 'mapping_filter', 'mapping_filter.sequenceGroupId = :groupId', { groupId: dto.groupId });
    }

    query.orderBy('seq.createdAt', dto.sort);

    const page = dto.page || 1;
    const limit = dto.limit || 10;
    const skip = (page - 1) * limit;

    const total = await query.getCount();
    const rawData = await query.offset(skip).limit(limit).getRawMany();

    const items: SequenceListItemDto[] = rawData.map(item => ({
      id: item.id,
      thumbnailUrl: item.thumbnailUrl,
      title: item.title,
      duration: item.duration,
      createdAt: item.createdAt,
      exerciseCount: parseInt(item.exerciseCount, 10) || 0,
      scheduleCount: parseInt(item.scheduleCount, 10) || 0,
      isActive: item.isActive === 1 || item.isActive === true,
      groups: JSON.parse(item.groups), // IFNULL을 사용했으므로 항상 유효한 JSON 배열 문자열
    }));

    return {
      items,
      paging: buildPaging(total, limit, page),
    };
  }

  async findOne(trainerId: string, id: string): Promise<any> {
    const sequence = await this.sequenceRepo.createQueryBuilder('seq')
      .leftJoinAndMapOne('seq.thumbnail', FileEntity, 'thumbnail', 'thumbnail.relatedId = seq.id AND thumbnail.relatedType = :thumbnailType', { thumbnailType: FileRelatedType.SEQUENCE_THUMBNAIL })
      .leftJoinAndSelect('seq.details', 'detail')
      .leftJoinAndSelect('detail.exercise', 'exercise')
      .leftJoinAndMapOne('detail.file', FileEntity, 'customFile', 'customFile.relatedId = detail.id AND customFile.relatedType = :exerciseType', { exerciseType: FileRelatedType.EXERCISE })
      .leftJoinAndMapOne('exercise.file', FileEntity, 'exerciseFile', 'exerciseFile.relatedId = exercise.id AND exerciseFile.relatedType = :exerciseType', { exerciseType: FileRelatedType.EXERCISE })
      .leftJoinAndSelect('seq.sequenceGroupMappings', 'mapping')
      .leftJoinAndSelect('mapping.sequenceGroup', 'group')
      .where('seq.id = :id', { id })
      .orderBy('detail.stepOrder', 'ASC')
      .getOne();

    if (!sequence) {
      throw new NotFoundException('시퀀스를 찾을 수 없습니다.');
    }
    if (sequence.trainerId !== trainerId) {
      throw new ForbiddenException('해당 시퀀스를 조회할 권한이 없습니다.');
    }
    
    // 프론트엔드가 사용하기 쉽게 이미지 URL을 통합
    const sequenceAsAny = sequence as any;
    sequenceAsAny.thumbnailUrl = sequenceAsAny.thumbnail?.fileUrl || null;
    delete sequenceAsAny.thumbnail;

    sequence.details.forEach(detail => {
      const detailAsAny = detail as any;
      if (detailAsAny.file) {
        detailAsAny.imageUrl = detailAsAny.file.fileUrl;
      } else if (detailAsAny.exercise?.file) {
        detailAsAny.imageUrl = detailAsAny.exercise.file.fileUrl;
      } else {
        detailAsAny.imageUrl = null;
      }
      delete detailAsAny.file;
      if (detailAsAny.exercise) {
        delete detailAsAny.exercise.file;
      }
    });

    // 그룹 정보 가공
    sequenceAsAny.groups = sequence.sequenceGroupMappings.map(m => m.sequenceGroup);
    delete sequenceAsAny.sequenceGroupMappings;

    return sequence;
  }

  @Transactional()
  async create(
    user: UserEntity, 
    dto: CreateSequenceDto, 
    thumbnail?: Express.Multer.File,
    detailImages?: Express.Multer.File[]
  ): Promise<SequenceEntity> {
    // 1. 시퀀스 생성
    const sequence = this.sequenceRepo.create({
      trainerId: user.id,
      title: dto.title,
      note: dto.note,
      duration: dto.duration,
    });
    const savedSequence = await this.sequenceRepo.save(sequence);

    // 2. 시퀀스 그룹 매핑 생성
    if (dto.sequenceGroupIds && dto.sequenceGroupIds.length > 0) {
      const mappings = dto.sequenceGroupIds.map(groupId => 
        this.mappingRepo.create({
          sequenceId: savedSequence.id,
          sequenceGroupId: groupId,
        })
      );
      await this.mappingRepo.save(mappings);
    }

    // 3. 대표 이미지 업로드
    if (thumbnail) {
      const uploadedFile = await this.s3Service.uploadFile(thumbnail, {
        memberId: user.id,
        uploaderId: user.id,
        ownerType: FileOwnerType.TRAINER,
        ownerId: user.id,
        relatedType: FileRelatedType.SEQUENCE_THUMBNAIL,
        relatedId: savedSequence.id,
      });
      
      // 센터 용량 업데이트
      await this.capacityService.updateCenterCapacity(user, uploadedFile.size);
    }

    // 4. 시퀀스 상세 생성
    if (dto.details && dto.details.length > 0) {
      const originalExerciseIds = dto.details
        .filter(d => !d.isCustom && d.exerciseId)
        .map(d => d.exerciseId as string);
      
      const originalExercises = await this.exerciseRepo.find({ where: { id: In(originalExerciseIds) } });
      const originalExercisesMap = new Map(originalExercises.map(ex => [ex.id, ex]));

      for (const detailDto of dto.details) {
        let detailToCreate: Partial<SequenceDetailEntity>;

        if (detailDto.isCustom) {
          detailToCreate = { ...detailDto };
        } else {
          if (!detailDto.exerciseId) throw new BadRequestException('exerciseId is required for non-custom exercises.');
          const original = originalExercisesMap.get(detailDto.exerciseId);
          if (!original) throw new BadRequestException(`Exercise not found: ${detailDto.exerciseId}`);
          
          detailToCreate = {
            ...detailDto,
            name: detailDto.name ?? original.name,
            description: detailDto.description ?? original.description,
          };
        }

        const detail = this.detailRepo.create({
          ...detailToCreate,
          sequenceId: savedSequence.id,
        });
        const savedDetail = await this.detailRepo.save(detail);

        if (detailDto.isCustom && detailDto.detailImageIndex !== undefined && detailImages && detailImages[detailDto.detailImageIndex]) {
          const imageFile = detailImages[detailDto.detailImageIndex];
          const uploadedFile = await this.s3Service.uploadFile(imageFile, {
            memberId: user.id,
            uploaderId: user.id,
            ownerType: FileOwnerType.TRAINER,
            ownerId: user.id,
            relatedType: FileRelatedType.EXERCISE,
            relatedId: savedDetail.id,
          });

          // 센터 용량 업데이트
          await this.capacityService.updateCenterCapacity(user, uploadedFile.size);
        }
      }
    }

    return savedSequence;
  }

  @Transactional()
  async update(
    user: UserEntity, 
    id: string,
    dto: UpdateSequenceDto, 
    thumbnail?: Express.Multer.File,
    detailImages?: Express.Multer.File[]
  ): Promise<SequenceEntity> {
    const sequence = await this.sequenceRepo.findOne({ where: { id } });
    if (!sequence) throw new NotFoundException('Sequence not found');
    if (sequence.trainerId !== user.id) throw new ForbiddenException('Access denied');

    // 1. 시퀀스 기본 정보 수정
    sequence.title = dto.title;
    sequence.note = dto.note;
    sequence.duration = dto.duration;
    await this.sequenceRepo.save(sequence);

    // 2. 시퀀스 그룹 매핑 수정 (Delete-Insert)
    // sequenceGroupIds가 undefined면 그룹 매핑을 건드리지 않음
    // sequenceGroupIds가 [] 이상으로 명시적으로 전달된 경우에만 처리
    if (dto.sequenceGroupIds !== undefined) {
      await this.mappingRepo.delete({ sequenceId: id });
      if (dto.sequenceGroupIds.length > 0) {
        const mappings = dto.sequenceGroupIds.map(groupId => 
          this.mappingRepo.create({
            sequenceId: id,
            sequenceGroupId: groupId,
          })
        );
        await this.mappingRepo.save(mappings);
      }
    }

    // 3. 대표 이미지 수정
    if (thumbnail) {
      const existingThumbnail = await this.fileRepo.findOne({
        where: { relatedId: sequence.id, relatedType: FileRelatedType.SEQUENCE_THUMBNAIL },
      });
      if (existingThumbnail) {
        await this.s3Service.deleteFile(existingThumbnail.s3Key);
        // 기존 파일 용량만큼 차감 (음수 업데이트)
        await this.capacityService.updateCenterCapacity(user, `-${existingThumbnail.size}`);
        await this.fileRepo.delete(existingThumbnail.id);
      }

      const uploadedFile = await this.s3Service.uploadFile(thumbnail, {
        memberId: user.id,
        uploaderId: user.id,
        ownerType: FileOwnerType.TRAINER,
        ownerId: user.id,
        relatedType: FileRelatedType.SEQUENCE_THUMBNAIL,
        relatedId: sequence.id,
      });
      
      // 새 파일 용량 추가
      await this.capacityService.updateCenterCapacity(user, uploadedFile.size);
    }

    // 4. 시퀀스 상세 수정
    if (dto.details) {
      const existingDetails = await this.detailRepo.find({ where: { sequenceId: id } });
      const existingDetailIds = existingDetails.map(d => d.id);

      // 이미지를 유지할 기존 detail ID 목록 (existingDetailId 있고 detailImageIndex 없는 경우)
      const keptDetailIds = dto.details
        .filter(d => d.existingDetailId && d.detailImageIndex === undefined)
        .map(d => d.existingDetailId as string);

      // 이미지를 유지하지 않는 detail ID의 이미지만 삭제
      const detailIdsToDeleteImage = existingDetailIds.filter(eid => !keptDetailIds.includes(eid));
      if (detailIdsToDeleteImage.length > 0) {
        const imagesToDelete = await this.fileRepo.find({
          where: { relatedId: In(detailIdsToDeleteImage), relatedType: FileRelatedType.EXERCISE },
        });
        for (const file of imagesToDelete) {
          await this.s3Service.deleteFile(file.s3Key);
          await this.capacityService.updateCenterCapacity(user, `-${file.size}`);
          await this.fileRepo.delete(file.id);
        }
      }

      await this.detailRepo.delete({ sequenceId: id });

      const originalExerciseIds = dto.details
        .filter(d => !d.isCustom && d.exerciseId)
        .map(d => d.exerciseId as string);
      
      const originalExercises = await this.exerciseRepo.find({ where: { id: In(originalExerciseIds) } });
      const originalExercisesMap = new Map(originalExercises.map(ex => [ex.id, ex]));

      for (const detailDto of dto.details) {
        let detailToCreate: Partial<SequenceDetailEntity>;

        if (detailDto.isCustom) {
          detailToCreate = { ...detailDto };
        } else {
          if (!detailDto.exerciseId) throw new BadRequestException('exerciseId is required for non-custom exercises.');
          const original = originalExercisesMap.get(detailDto.exerciseId);
          if (!original) throw new BadRequestException(`Exercise not found: ${detailDto.exerciseId}`);
          
          detailToCreate = {
            ...detailDto,
            name: detailDto.name ?? original.name,
            description: detailDto.description ?? original.description,
          };
        }

        const detail = this.detailRepo.create({
          ...detailToCreate,
          sequenceId: sequence.id,
        });
        const savedDetail = await this.detailRepo.save(detail);

        if (detailDto.isCustom && detailDto.detailImageIndex !== undefined && detailImages && detailImages[detailDto.detailImageIndex]) {
          // 새 이미지 업로드
          const imageFile = detailImages[detailDto.detailImageIndex];
          const uploadedFile = await this.s3Service.uploadFile(imageFile, {
            memberId: user.id,
            uploaderId: user.id,
            ownerType: FileOwnerType.TRAINER,
            ownerId: user.id,
            relatedType: FileRelatedType.EXERCISE,
            relatedId: savedDetail.id,
          });
          await this.capacityService.updateCenterCapacity(user, uploadedFile.size);
        } else if (detailDto.isCustom && detailDto.existingDetailId && detailDto.detailImageIndex === undefined) {
          // 기존 이미지 유지: 파일 레코드의 relatedId를 새 detail ID로 업데이트
          await this.fileRepo.update(
            { relatedId: detailDto.existingDetailId, relatedType: FileRelatedType.EXERCISE },
            { relatedId: savedDetail.id },
          );
        }
      }
    }

    return this.findOne(user.id, id);
  }

  @Transactional()
  async updateStatus(trainerId: string, dto: UpdateSequenceStatusDto): Promise<{ success: boolean }> {
    const count = await this.sequenceRepo.count({
      where: {
        id: In(dto.ids),
        trainerId: trainerId,
      },
    });

    if (count !== dto.ids.length) {
      throw new ForbiddenException('권한이 없거나 존재하지 않는 시퀀스가 포함되어 있습니다.');
    }

    await this.sequenceRepo.update(dto.ids, { isActive: dto.isActive });

    return { success: true };
  }

  @Transactional()
  async removeSequenceFromGroup(trainerId: string, sequenceId: string): Promise<{ success: boolean }> {
    return { success: true };
  }

  /**
   * 일정에 시퀀스 등록/수정 (기존 시퀀스 덮어쓰기)
   */
  @Transactional()
  async assignToSchedule(trainerId: string, sequenceId: string, scheduleId: string): Promise<{ success: boolean }> {
    // 1. 시퀀스 존재 및 권한 확인 (활성화된 시퀀스만)
    const sequence = await this.sequenceRepo.findOne({
      where: { id: sequenceId, trainerId, isActive: true },
    });
    if (!sequence) {
      throw new NotFoundException('시퀀스를 찾을 수 없거나 비활성화 상태이거나 권한이 없습니다.');
    }

    // 2. 일정 존재 및 권한 확인
    const schedule = await this.scheduleRepo.findOne({
      where: { id: scheduleId, trainerId },
    });
    if (!schedule) {
      throw new NotFoundException('일정을 찾을 수 없거나 권한이 없습니다.');
    }

    // 3. 일정의 시퀀스 업데이트 (기존 시퀀스가 있어도 덮어쓰기)
    await this.scheduleRepo.update(scheduleId, { sequenceId });

    return { success: true };
  }
}
