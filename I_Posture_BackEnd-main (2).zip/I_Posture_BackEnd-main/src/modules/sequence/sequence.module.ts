import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SequenceEntity } from '../../database/entities/sequence.entity';
import { SequenceDetailEntity } from '../../database/entities/sequence-detail.entity';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { SequenceService } from './sequence.service';
import { SequenceController } from './sequence.controller';
import { S3Module } from '../../s3/s3.module';
import { ExerciseEntity } from '../../database/entities/exercise.entity';
import { SequenceGroupMappingEntity } from '../../database/entities/sequence-group-mapping.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { CapacityModule } from '../capacity/capacity.module';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SequenceEntity, 
      SequenceDetailEntity,
      ScheduleEntity,
      ExerciseEntity,
      SequenceGroupMappingEntity,
      FileEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
    ]),
    S3Module,
    CapacityModule,
  ],
  controllers: [SequenceController],
  providers: [SequenceService, SubscriptionGuard],
  exports: [SequenceService],
})
export class SequenceModule {}
