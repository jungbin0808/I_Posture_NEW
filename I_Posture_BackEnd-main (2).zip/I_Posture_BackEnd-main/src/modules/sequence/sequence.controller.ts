import { Controller, Get, Query, Request, UseGuards, Post, Body, UseInterceptors, UploadedFile, UploadedFiles, ParseFilePipe, MaxFileSizeValidator, FileTypeValidator, Param, Patch, Put, Delete } from "@nestjs/common";
import { FileFieldsInterceptor, FileInterceptor } from "@nestjs/platform-express";
import { SequenceService } from "./sequence.service";
import { AccessTokenGuard } from "../auth/access-token.guard";
import { RolesGuard } from "../../common/guards/roles.guard";
import { SubscriptionGuard } from "../../common/guards/subscription.guard";
import { Roles } from "../../common/decorators/roles.decorator";
import { RequiresSubscription } from "../../common/decorators/requires-subscription.decorator";
import { Role } from "../../common/enums/role.enum";
import { AssignSequenceToScheduleDto, CreateSequenceDto, FindSequenceDto, FindSequenceForScheduleDto, SequenceForScheduleResponseDto, SequenceListItemDto, UpdateSequenceDto, UpdateSequenceStatusDto } from "./sequence.dto";
import { IPageResponse, ISuccessResponse } from "../../common/response/response.interface";
import { SuccessResponse } from "../../common/response/response.helper";
import { SequenceEntity } from "../../database/entities/sequence.entity";

@Controller("sequences")
export class SequenceController {
  constructor(private readonly sequenceService: SequenceService) {}

  /**
   * @summary 일정 등록용 시퀀스 목록 조회 (그룹 → 그룹없는 순, 페이징 없음)
   */
  @Get('for-schedule')
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  async findForSchedule(
    @Request() req: any,
    @Query() dto: FindSequenceForScheduleDto,
  ): Promise<ISuccessResponse<SequenceForScheduleResponseDto>> {
    const data = await this.sequenceService.findForSchedule(req.user.id, dto.search);
    return SuccessResponse(data);
  }

  /**
   * @summary 시퀀스 목록 조회 (페이징, 검색, 정렬)
   */
  @Get()
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  async findAll(@Request() req: any, @Query() dto: FindSequenceDto): Promise<IPageResponse<SequenceListItemDto>> {
    const pageData = await this.sequenceService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 시퀀스 상세 조회
   */
  @Get(":id")
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  async findOne(@Request() req: any, @Param("id") id: string): Promise<ISuccessResponse<SequenceEntity>> {
    const sequence = await this.sequenceService.findOne(req.user.id, id);
    return SuccessResponse(sequence);
  }

  /**
   * @summary 시퀀스 생성 (대표 이미지, 상세 이미지 포함)
   */
  @Post()
  @UseGuards(AccessTokenGuard, RolesGuard, SubscriptionGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @RequiresSubscription()
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'thumbnail', maxCount: 1 },
    { name: 'detailImages', maxCount: 50 }, // 최대 50개로 제한
  ]))
  async create(
    @Request() req: any,
    @Body('data') data: string,
    @UploadedFiles() files: { thumbnail?: Express.Multer.File[], detailImages?: Express.Multer.File[] }
  ): Promise<ISuccessResponse<SequenceEntity>> {
    const dto: CreateSequenceDto = JSON.parse(data);
    const sequence = await this.sequenceService.create(req.user, dto, files.thumbnail?.[0], files.detailImages);
    return SuccessResponse(sequence);
  }

  /**
   * @summary 시퀀스 상태 일괄 변경 (활성화/비활성화)
   */
  @Put("bulk/status")
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  async updateStatus(@Request() req: any, @Body() dto: UpdateSequenceStatusDto): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.sequenceService.updateStatus(req.user.id, dto);
    return SuccessResponse(result);
  }

  /**
   * @summary 시퀀스 수정 (전체 정보 및 상세 동작 일괄 수정)
   */
  @Put(':id')
  @UseGuards(AccessTokenGuard, RolesGuard, SubscriptionGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @RequiresSubscription()
  @UseInterceptors(FileFieldsInterceptor([{ name: 'thumbnail', maxCount: 1 }, { name: 'detailImages', maxCount: 50 },]))
  async update(@Request() req: any, @Param('id') id: string, @Body('data') data: string, @UploadedFiles() files: { thumbnail?: Express.Multer.File[], detailImages?: Express.Multer.File[] }): Promise<ISuccessResponse<SequenceEntity>> {
    const dto: UpdateSequenceDto = JSON.parse(data);
    const sequence = await this.sequenceService.update(req.user, id, dto, files.thumbnail?.[0], files.detailImages);
    return SuccessResponse(sequence);
  }

  /**
   * @summary 일정에 시퀀스 등록/수정 (기존 시퀀스 덮어쓰기)
   */
  @Post(':id/assign-to-schedule')
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  async assignToSchedule(
    @Request() req: any,
    @Param('id') id: string,
    @Body() dto: AssignSequenceToScheduleDto
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.sequenceService.assignToSchedule(req.user.id, id, dto.scheduleId);
    return SuccessResponse(result);
  }
}
