/**
 * DB에 저장된 체형 키 → 액션플랜 내부 정규화 키 매핑
 * body-diseases.enum.ts 기준 실제 DB 키와 action-plan 내부 키명이 다른 경우 여기서 통일합니다.
 */
export const DISEASE_KEY_NORMALIZATION: Record<string, string> = {
  HUNCHED_BACK: 'ROUNDED_BACK',
  FLAT_BACK: 'EXTENDED_BACK',
  LEGS_TURNED_OUTWARD: 'LEG_EXTERNAL_ROTATION',
  LEGS_TURNED_INWARD: 'LEG_INTERNAL_ROTATION',
  RAISED_NECK: 'CHIN_POKE',
  STRAIGHT_SHOULDER: 'EXTENDED_SHOULDER',
  TORSO_TILTED_RIGHT: 'TORSO_TILT_RIGHT',
  TORSO_TILTED_LEFT: 'TORSO_TILT_LEFT',
  PELVIS_MOVE_RIGHT: 'PELVIS_SHIFT_RIGHT',
  PELVIS_MOVE_LEFT: 'PELVIS_SHIFT_LEFT',
  ARMS_TURNED_IN: 'ARM_INTERNAL_ROTATION',
  ARMS_TURNED_OUT: 'ARM_EXTERNAL_ROTATION',
  ARCHED_FEET: 'HIGH_ARCH_FEET',
  // 방향 접미사가 붙은 변형 키 정규화 (DB에 _RIGHT_UP/_LEFT_UP 형태로 저장됨)
  SHOULDER_HEIGHT_ASYMMETRY_RIGHT_UP: 'SHOULDER_HEIGHT_ASYMMETRY',
  SHOULDER_HEIGHT_ASYMMETRY_LEFT_UP: 'SHOULDER_HEIGHT_ASYMMETRY',
  PELVIS_ASYMMETRY_RIGHT_UP: 'PELVIS_ASYMMETRY',
  PELVIS_ASYMMETRY_LEFT_UP: 'PELVIS_ASYMMETRY',
};

/** DB 체형 키를 액션플랜 정규화 키로 변환합니다. 매핑이 없으면 원본 키를 반환합니다. */
function normalizeKey(key: string): string {
  return DISEASE_KEY_NORMALIZATION[key] ?? key;
}

/**
 * 체형 우선순위 (숫자가 낮을수록 더 중요한 정렬 문제)
 * Sheet 2 기준 - 가장 안 좋은 체형이 2개 이상일 때 적용되는 우선순위
 */
export const BODY_TYPE_PRIORITY: Record<string, number> = {
  // 1순위: 허리 과전만 & 골반 전방경사 / 일자허리 & 골반 후방경사
  PELVIS_TILTS_FORWARD: 1,
  PELVIS_TILTS_BACKWARD: 1,
  // 2순위: 스웨이백
  SWAY_BACK: 2,
  // 3순위: 굽은등 / 펴진등
  ROUNDED_BACK: 3,
  EXTENDED_BACK: 3,
  // 4순위: 골반 높이 비대칭
  PELVIS_ASYMMETRY: 4,
  // 5순위: 몸통 가쪽굽힘
  TORSO_TILT_RIGHT: 5,
  TORSO_TILT_LEFT: 5,
  // 6순위: 라운드숄더 / 과도하게 펴진 어깨
  ROUNDED_SHOULDER: 6,
  EXTENDED_SHOULDER: 6,
  // 7순위: 이동된 골반
  PELVIS_SHIFT_RIGHT: 7,
  PELVIS_SHIFT_LEFT: 7,
  // 8순위: 어깨높이 비대칭
  SHOULDER_HEIGHT_ASYMMETRY: 8,
  // 9순위: 넙다리 바깥돌림 / 넙다리 안쪽돌림
  LEG_EXTERNAL_ROTATION: 9,
  LEG_INTERNAL_ROTATION: 9,
  // 10순위: 오다리 / 엑스다리
  BOW_LEGS: 10,
  KNOCK_LEGS: 10,
  // 11순위: 과하게 펴진 무릎 / 굽혀진 무릎
  BACK_KNEES: 11,
  BENT_KNEES: 11,
  // 12순위: 거북목 / 일자목
  TURTLE_NECK: 12,
  STRAIGHT_NECK: 12,
  // 13순위: 목 가쪽굽힘
  NECK_TILT: 13,
  // 14순위: 올라간 어깨 / 처진어깨
  RAISED_SHOULDER: 14,
  DROPPED_SHOULDER: 14,
  // 15순위: 안으로 돌아간 팔 / 바깥으로 돌아간 팔
  ARM_INTERNAL_ROTATION: 15,
  ARM_EXTERNAL_ROTATION: 15,
  // 16순위: 회전된 몸통
  TORSO_ROTATION_LEFT: 16,
  TORSO_ROTATION_RIGHT: 16,
  // 17순위: 골반 회전
  PELVIS_ROTATION_LEFT: 17,
  PELVIS_ROTATION_RIGHT: 17,
  // 18순위: 굽혀진 팔꿈치 / 과하게 펴진 팔꿈치
  BENT_ELBOW: 18,
  EXTENDED_ELBOW: 18,
  // 19순위: 목회전
  NECK_ROTATION: 19,
  // 20순위: 들임목
  CHIN_POKE: 20,
  // 21순위: 평발 / 오목발
  FLAT_FEET: 21,
  HIGH_ARCH_FEET: 21,
  // 22순위: 발목 가쪽번짐 / 발목 안쪽번짐
  ANKLE_MOVE_OUTWARD: 22,
  ANKLE_MOVE_INWARD: 22,
};

/**
 * 체형 키 → 표시 명칭 (액션플랜용 한국어 명칭)
 * 좌/우 구분 없이 동일한 명칭으로 표시
 */
export const BODY_TYPE_LABEL: Record<string, string> = {
  TURTLE_NECK: '거북목',
  STRAIGHT_NECK: '일자목',
  CHIN_POKE: '들임목',
  NECK_TILT: '목 가쪽굽힘',
  NECK_ROTATION: '목 회전',
  RAISED_SHOULDER: '올라간 어깨',
  DROPPED_SHOULDER: '처진 어깨',
  SHOULDER_HEIGHT_ASYMMETRY: '어깨높이 비대칭',
  ROUNDED_SHOULDER: '라운드숄더',
  EXTENDED_SHOULDER: '과도하게 펴진 어깨',
  ARM_INTERNAL_ROTATION: '위팔 안쪽돌림',
  ARM_EXTERNAL_ROTATION: '위팔 가쪽돌림',
  BENT_ELBOW: '굽혀진 팔꿈치',
  EXTENDED_ELBOW: '과하게 펴진팔꿈치',
  ROUNDED_BACK: '굽은등',
  EXTENDED_BACK: '펴진등',
  PELVIS_TILTS_FORWARD: '허리 과전만 & 골반 전방경사',
  PELVIS_TILTS_BACKWARD: '일자허리 & 골반 후방경사',
  TORSO_TILT_RIGHT: '몸통 오른쪽 가쪽굽힘',
  TORSO_TILT_LEFT: '몸통 왼쪽 가쪽굽힘',
  TORSO_ROTATION_LEFT: '회전된 몸통(왼쪽)',
  TORSO_ROTATION_RIGHT: '회전된 몸통(오른쪽)',
  SWAY_BACK: '스웨이백',
  PELVIS_ASYMMETRY: '골반 비대칭',
  PELVIS_ROTATION_LEFT: '골반 왼쪽 회전',
  PELVIS_ROTATION_RIGHT: '골반 오른쪽 회전',
  PELVIS_SHIFT_RIGHT: '오른쪽으로 이동된 골반',
  PELVIS_SHIFT_LEFT: '왼쪽으로 이동된 골반',
  LEG_EXTERNAL_ROTATION: '넙다리 가쪽돌림',
  LEG_INTERNAL_ROTATION: '넙다리 안쪽돌림',
  BOW_LEGS: '오다리',
  KNOCK_LEGS: '엑스다리',
  BACK_KNEES: '과하게 펴진 무릎',
  BENT_KNEES: '굽혀진 무릎',
  FLAT_FEET: '평발',
  HIGH_ARCH_FEET: '오목발',
  ANKLE_MOVE_OUTWARD: '발목 가쪽번짐',
  ANKLE_MOVE_INWARD: '발목 안쪽번짐',
};

/**
 * 동시에 나타날 경우 하나만 표시해야 하는 상호 배타적 체형 그룹 (정규화 키 기준)
 * 같은 그룹 내에서 score/priority 기준으로 가장 심각한 항목 하나만 결과에 포함됩니다.
 */
const MUTUAL_EXCLUSION_GROUPS: readonly string[][] = [
  ['TURTLE_NECK', 'STRAIGHT_NECK'], // 거북목 vs 일자목: 경추 만곡 방향 반대 — 동시 표시 불가
];

/**
 * 체형 키(정규화) → 신체 부위 그룹
 * 동일 부위 체형이 상위 목록을 독점하지 않도록 다양성 제어에 사용됩니다.
 */
const BODY_REGION_GROUP: Record<string, string> = {
  // 목
  TURTLE_NECK: 'neck', STRAIGHT_NECK: 'neck', CHIN_POKE: 'neck', NECK_TILT: 'neck', NECK_ROTATION: 'neck',
  // 어깨/팔
  ROUNDED_SHOULDER: 'shoulder_arm', EXTENDED_SHOULDER: 'shoulder_arm',
  RAISED_SHOULDER: 'shoulder_arm', DROPPED_SHOULDER: 'shoulder_arm',
  SHOULDER_HEIGHT_ASYMMETRY: 'shoulder_arm',
  ARM_INTERNAL_ROTATION: 'shoulder_arm', ARM_EXTERNAL_ROTATION: 'shoulder_arm',
  BENT_ELBOW: 'shoulder_arm', EXTENDED_ELBOW: 'shoulder_arm',
  // 등/몸통
  ROUNDED_BACK: 'back_torso', EXTENDED_BACK: 'back_torso',
  TORSO_TILT_RIGHT: 'back_torso', TORSO_TILT_LEFT: 'back_torso',
  TORSO_ROTATION_LEFT: 'back_torso', TORSO_ROTATION_RIGHT: 'back_torso',
  SWAY_BACK: 'back_torso',
  // 골반
  PELVIS_TILTS_FORWARD: 'pelvis', PELVIS_TILTS_BACKWARD: 'pelvis',
  PELVIS_ASYMMETRY: 'pelvis',
  PELVIS_ROTATION_LEFT: 'pelvis', PELVIS_ROTATION_RIGHT: 'pelvis',
  PELVIS_SHIFT_RIGHT: 'pelvis', PELVIS_SHIFT_LEFT: 'pelvis',
  // 하지
  LEG_EXTERNAL_ROTATION: 'legs', LEG_INTERNAL_ROTATION: 'legs',
  BOW_LEGS: 'legs', KNOCK_LEGS: 'legs',
  // 무릎/발
  BACK_KNEES: 'knee_feet', BENT_KNEES: 'knee_feet',
  FLAT_FEET: 'knee_feet', HIGH_ARCH_FEET: 'knee_feet',
  ANKLE_MOVE_OUTWARD: 'knee_feet', ANKLE_MOVE_INWARD: 'knee_feet',
};

/**
 * 체형 disease 배열에서 순위가 매겨진 체형 목록을 반환합니다.
 *
 * - NORMAL 필터링
 * - 정렬: 1차 score 오름차순(낮을수록 심각), 2차 BODY_TYPE_PRIORITY 오름차순
 * - 상호 배타적 그룹 처리 (예: 거북목/일자목 동시 출현 → 더 심각한 것만)
 * - 부위 다양성 보장: 각 신체 부위에서 1개 우선 선택 후, 동일 부위 추가 항목은 뒤에 배치
 * - 좌/우 동일 체형명 중복 제거
 * - DB 키명(예: HUNCHED_BACK)과 내부 키명(ROUNDED_BACK) 자동 정규화
 *
 * 각 화면에서 `.slice(0, N)`으로 필요한 개수만 사용하세요.
 * (체형분석리포트: 5개, 체형측정 상세: 3개, 액션플랜: 2개)
 *
 * 원본 disease 객체의 모든 필드(direction, level 등)를 보존하며 `label` 필드를 추가합니다.
 */
export interface RankedBodyDisease {
  /** 원본 DB 키 (이미지 조회 등 기존 코드 호환용) */
  key: string;
  /** 한국어 표시 레이블 */
  label: string;
  /** 심각도 점수 */
  score: number;
  /** 원본 disease 객체의 나머지 필드 (direction, level 등) */
  [key: string]: any;
}

export function rankBodyDiseases(diseases: any[]): RankedBodyDisease[] {
  const filtered = (diseases ?? []).filter(
    (d: any) => d?.key && d.key !== 'NORMAL',
  );

  const sorted = [...filtered].sort((a, b) => {
    const scoreDiff = (a.score ?? 0) - (b.score ?? 0);
    if (scoreDiff !== 0) return scoreDiff;
    const pa = BODY_TYPE_PRIORITY[normalizeKey(a.key)] ?? 999;
    const pb = BODY_TYPE_PRIORITY[normalizeKey(b.key)] ?? 999;
    return pa - pb;
  });

  // 상호 배타적 그룹 처리: 동일 그룹 내 첫 번째(가장 심각한) 항목 외 제외
  const excludedByMutualExclusion = new Set<string>();
  for (const group of MUTUAL_EXCLUSION_GROUPS) {
    let foundFirst = false;
    for (const d of sorted) {
      if (group.includes(normalizeKey(d.key))) {
        if (foundFirst) excludedByMutualExclusion.add(d.key);
        else foundFirst = true;
      }
    }
  }
  const afterExclusion = sorted.filter(d => !excludedByMutualExclusion.has(d.key));

  // 부위 다양성 보장: 각 신체 부위에서 1개씩 우선 선택(firstPass), 나머지는 overflow
  // slice(0, N) 시 목/어깨 편중 없이 여러 부위가 고루 포함됩니다.
  const seenLabels = new Set<string>();
  const seenRegions = new Set<string>();
  const firstPass: RankedBodyDisease[] = [];
  const overflow: RankedBodyDisease[] = [];

  for (const d of afterExclusion) {
    const nk = normalizeKey(d.key);
    const label = BODY_TYPE_LABEL[nk] ?? BODY_TYPE_LABEL[d.key] ?? d.key;
    if (seenLabels.has(label)) continue;
    seenLabels.add(label);

    const region = BODY_REGION_GROUP[nk] ?? BODY_REGION_GROUP[d.key] ?? 'other';
    if (!seenRegions.has(region)) {
      seenRegions.add(region);
      firstPass.push({ ...d, label });
    } else {
      overflow.push({ ...d, label });
    }
  }

  // 최종 결과: 각 부위 대표 항목(firstPass) 먼저, 이후 동일 부위 추가 항목(overflow) 순
  return [...firstPass, ...overflow];
}

/**
 * 체형 키 → 운동 목적
 * Sheet 2의 "운동 목적" 열 기준
 */
export const BODY_TYPE_EXERCISE_PURPOSE: Record<string, string> = {
  NECK_TILT: '목 좌우 균형 회복',
  NECK_ROTATION: '목 회전 움직임 범위 회복',
  TURTLE_NECK: '목 정렬 개선',
  STRAIGHT_NECK: '목 정렬 개선',
  CHIN_POKE: '목 정렬 개선',
  SHOULDER_HEIGHT_ASYMMETRY: '어깨 좌우 균형 회복',
  RAISED_SHOULDER: '어깨 긴장 완화 및 균형 회복',
  DROPPED_SHOULDER: '어깨 정렬 개선',
  ROUNDED_SHOULDER: '어깨 정렬 개선',
  EXTENDED_SHOULDER: '어깨 정렬 개선',
  ARM_INTERNAL_ROTATION: '어깨 정렬 개선 및 상체 균형 회복',
  ARM_EXTERNAL_ROTATION: '어깨 정렬 개선 및 상체 균형 회복',
  BENT_ELBOW: '팔 정렬 개선 및 상체 균형 회복',
  EXTENDED_ELBOW: '팔 정렬 개선 및 상체 균형 회복',
  ROUNDED_BACK: '상체 정렬 개선 및 등 지지 근력 강화',
  EXTENDED_BACK: '등 만곡 회복',
  PELVIS_TILTS_FORWARD: '몸통 안정성 강화 및 골반 균형 회복',
  PELVIS_TILTS_BACKWARD: '몸통 안정성 강화 및 골반 균형 회복',
  TORSO_TILT_RIGHT: '몸통 좌우 균형 안정화',
  TORSO_TILT_LEFT: '몸통 좌우 균형 안정화',
  TORSO_ROTATION_LEFT: '몸통 좌우 균형 안정화',
  TORSO_ROTATION_RIGHT: '몸통 좌우 균형 안정화',
  SWAY_BACK: '코어 안정성 강화',
  PELVIS_ASYMMETRY: '좌우 골반 균형 안정화',
  PELVIS_ROTATION_LEFT: '골반 회전 균형 회복',
  PELVIS_ROTATION_RIGHT: '골반 회전 균형 회복',
  PELVIS_SHIFT_RIGHT: '골반 중심 지지 기능 강화',
  PELVIS_SHIFT_LEFT: '골반 중심 지지 기능 강화',
  LEG_EXTERNAL_ROTATION: '다리 정렬 안정화',
  LEG_INTERNAL_ROTATION: '다리 정렬 안정화',
  BOW_LEGS: '다리 정렬 안정화',
  KNOCK_LEGS: '무릎 정렬 안정화',
  BACK_KNEES: '무릎 지지 근력 강화',
  BENT_KNEES: '무릎 가동범위 회복',
  FLAT_FEET: '발목·발 정렬 균형 개선',
  HIGH_ARCH_FEET: '발목·발 정렬 균형 개선',
};

/**
 * 체형 키 → 중점 적용 운동 (Sheet 2 중점 적용 운동)
 * 운동목적과 동일한 1순위 체형 기준으로 적용
 */
export const BODY_TYPE_FOCUS_EXERCISE: Record<string, string> = {
  NECK_TILT: '목 좌우 균형 스트레칭 + 목 안정화 루틴',
  NECK_ROTATION: '목 회전 가동 + 상부 목 안정화 루틴',
  TURTLE_NECK: '목 정렬 + 상부 등 가동 루틴',
  STRAIGHT_NECK: '목 정렬 + 상부 등 가동 루틴',
  CHIN_POKE: '목 앞쪽 안정화 + 목 정렬 루틴',
  SHOULDER_HEIGHT_ASYMMETRY: '어깨 좌우 균형 + 어깨뼈 안정화 루틴',
  RAISED_SHOULDER: '위등세모근 긴장 완화 + 어깨뼈 하강 안정화 루틴',
  DROPPED_SHOULDER: '어깨뼈 안정화 + 어깨 올림 지지근 활성 루틴',
  ROUNDED_SHOULDER: '가슴 열림 + 등 가동성 루틴',
  EXTENDED_SHOULDER: '어깨뼈 안정화 + 등 가동성 루틴',
  ARM_INTERNAL_ROTATION: '가슴 열림 + 등 근육 활성 루틴',
  ARM_EXTERNAL_ROTATION: '어깨뼈 안정화 + 등 가동성 루틴',
  BENT_ELBOW: '팔 앞쪽 이완 + 가슴 열림 루틴',
  EXTENDED_ELBOW: '팔꿈치 안정 루틴',
  ROUNDED_BACK: '등 근육 활성 + 등 가동성 루틴',
  EXTENDED_BACK: '등 가동성 + 코어 안정화 루틴',
  PELVIS_TILTS_FORWARD: '코어 안정화 + 둔근 활성화 루틴',
  PELVIS_TILTS_BACKWARD: '골반 가동성 + 코어 안정화 루틴',
  TORSO_TILT_RIGHT: '몸통 옆쪽 이완 + 코어 안정화 루틴',
  TORSO_TILT_LEFT: '몸통 옆쪽 이완 + 코어 안정화 루틴',
  TORSO_ROTATION_LEFT: '몸통 사선라인 활성 + 코어 안정화 루틴',
  TORSO_ROTATION_RIGHT: '몸통 사선라인 활성 + 코어 안정화 루틴',
  SWAY_BACK: '골반·다리 뒤쪽 이완 + 코어 활성화 루틴',
  PELVIS_ASYMMETRY: '골반·몸통 측면 이완 + 중간볼기근 활성화 루틴',
  PELVIS_ROTATION_LEFT: '골반 가동성 + 코어 안정화 루틴',
  PELVIS_ROTATION_RIGHT: '골반 가동성 + 코어 안정화 루틴',
  PELVIS_SHIFT_RIGHT: '중간볼기근 활성화 + 엉덩관절 주변 근육 이완 루틴',
  PELVIS_SHIFT_LEFT: '중간볼기근 활성화 + 엉덩관절 주변 근육 이완 루틴',
  LEG_EXTERNAL_ROTATION: '뒤허벅지 이완 + 둔부 안정화 루틴',
  LEG_INTERNAL_ROTATION: '둔근 활성 + 코어 안정화 루틴',
  // 바깥쪽으로 돌아간 다리 + 오다리 기본값; LEG_INTERNAL_ROTATION 동반 시 함수 내에서 별도 처리
  BOW_LEGS: '넙다리 안쪽돌림 가동성 + 둔부 안정화 루틴',
  KNOCK_LEGS: '무릎 정렬 + 둔부 안정화 루틴',
  BACK_KNEES: '다리 뒤쪽 라인 활성 + 코어 활성화 루틴',
  BENT_KNEES: '다리 뒤쪽 이완 + 골반 가동 루틴',
  FLAT_FEET: '발 아치 활성 + 발가락 활성 루틴',
  HIGH_ARCH_FEET: '발 가동성 루틴 + 발가락 조절 루틴',
};

/**
 * 체형 키 → 외형 인상 기대 기능적 변화 (Sheet 3)
 * 가장 심각한 체형 상위 2개 각각 1개씩 적용
 */
export const BODY_TYPE_APPEARANCE_FUNCTIONAL_CHANGE: Record<string, string> = {
  NECK_TILT: '얼굴 좌우 균형 회복',
  NECK_ROTATION: '턱선 좌우 두께 균형 개선',
  TURTLE_NECK: '얼굴 사이즈 슬림화',
  STRAIGHT_NECK: '얼굴 사이즈 슬림화',
  CHIN_POKE: '이중턱 완화',
  SHOULDER_HEIGHT_ASYMMETRY: '승모근 좌우 균형 개선',
  RAISED_SHOULDER: '목 길이 개선 및 슬림화',
  DROPPED_SHOULDER: '어깨 라인 정돈',
  ROUNDED_SHOULDER: '직각어깨 형성',
  EXTENDED_SHOULDER: '갈비뼈 돌출 완화',
  ARM_INTERNAL_ROTATION: '겨드랑이 라인 정리',
  ARM_EXTERNAL_ROTATION: '상체 긴장도 완화',
  BENT_ELBOW: '팔 길이 비율 균형 개선',
  EXTENDED_ELBOW: '팔 라인 실루엣 정리',
  ROUNDED_BACK: '등 라인 얇아짐',
  EXTENDED_BACK: '몸통 라인 얇아짐',
  PELVIS_TILTS_FORWARD: '아랫배 라인 정리됨',
  PELVIS_TILTS_BACKWARD: '힙 라인 리프팅',
  TORSO_TILT_RIGHT: '옆구리 지방 균형 개선',
  TORSO_TILT_LEFT: '옆구리 지방 균형 개선',
  TORSO_ROTATION_RIGHT: '갈비 라인 정리로 상체 실루엣 정돈',
  TORSO_ROTATION_LEFT: '갈비 라인 정리로 상체 실루엣 정돈',
  SWAY_BACK: '전신 탄력 회복',
  PELVIS_ASYMMETRY: '셀룰라이트 완화',
  PELVIS_ROTATION_RIGHT: '하지 부종 완화',
  PELVIS_ROTATION_LEFT: '하지 부종 완화',
  PELVIS_SHIFT_RIGHT: '다리 굵기 좌우 균형 회복',
  PELVIS_SHIFT_LEFT: '다리 굵기 좌우 균형 회복',
  LEG_EXTERNAL_ROTATION: '하체 비율 개선',
  LEG_INTERNAL_ROTATION: '힙 옆라인 볼륨 개선',
  // 바깥쪽으로 돌아간 다리 + 오다리 기본값; LEG_INTERNAL_ROTATION 동반 시 함수 내에서 별도 처리
  BOW_LEGS: '전체 다리 라인 정돈',
  KNOCK_LEGS: '허벅지 외측 라인 정리',
  BACK_KNEES: '허벅지 전면 슬림화',
  BENT_KNEES: '하체 라인 탄력 개선',
  FLAT_FEET: '종아리 내측 라인 정리',
  HIGH_ARCH_FEET: '발목 외측 라인 정리',
};

/**
 * 체형 키 → 신체적 불편감 대표 기능적 변화 (Sheet 4)
 * 각 체형에 가장 전형적인 증상 1개를 기준으로 매핑
 */
export const BODY_TYPE_DISCOMFORT_FUNCTIONAL_CHANGE: Record<string, string> = {
  NECK_TILT: '목 옆 뻐근함 완화',
  NECK_ROTATION: '목 회전 원활해짐',
  TURTLE_NECK: '목 젖힐 때 압박감 완화',
  STRAIGHT_NECK: '뒷목 압박 완화',
  CHIN_POKE: '목 뒤 답답함 완화',
  SHOULDER_HEIGHT_ASYMMETRY: '어깨 위 뻐근함 완화',
  RAISED_SHOULDER: '목어깨 묵직함 완화',
  DROPPED_SHOULDER: '어깨 뒤 뻐근함 완화',
  ROUNDED_SHOULDER: '어깨 걸림 완화',
  EXTENDED_SHOULDER: '가슴 앞 답답함 완화',
  ARM_INTERNAL_ROTATION: '어깨 앞 당김 완화',
  ARM_EXTERNAL_ROTATION: '상체 긴장 완화',
  BENT_ELBOW: '팔꿈치 안쪽 당김 완화',
  EXTENDED_ELBOW: '팔 펴는 동작 편해짐',
  ROUNDED_BACK: '등 중앙 압박 완화',
  EXTENDED_BACK: '등 불편 완화',
  PELVIS_TILTS_FORWARD: '허리 젖힘 편해짐',
  PELVIS_TILTS_BACKWARD: '숙일 때 허리 압박 완화',
  TORSO_TILT_RIGHT: '옆구리 당김 완화',
  TORSO_TILT_LEFT: '옆구리 당김 완화',
  TORSO_ROTATION_RIGHT: '허리 회전 부담 완화',
  TORSO_ROTATION_LEFT: '허리 회전 부담 완화',
  SWAY_BACK: '허리 안정감 회복',
  PELVIS_ASYMMETRY: '골반 묵직함 완화',
  PELVIS_ROTATION_RIGHT: '엉덩관절 걸림 완화',
  PELVIS_ROTATION_LEFT: '엉덩관절 걸림 완화',
  PELVIS_SHIFT_RIGHT: '허리·다리 묵직함 완화',
  PELVIS_SHIFT_LEFT: '허리·다리 묵직함 완화',
  LEG_EXTERNAL_ROTATION: '엉덩관절 바깥회전 걸림 완화',
  LEG_INTERNAL_ROTATION: '엉덩관절 안쪽회전 시 서혜부 압박감 완화',
  BOW_LEGS: '허벅지 뒤 묵직함 완화',
  KNOCK_LEGS: '무릎 안정감 회복',
  BACK_KNEES: '다리 펴기 편해짐',
  BENT_KNEES: '무릎 굽힘 부드러워짐',
  FLAT_FEET: '발목 안정감 회복',
  HIGH_ARCH_FEET: '발목 움직임 부드러워짐',
};

/**
 * 체형 키(정규화) → 관련 신체적 불편감 목록
 * 상담 시 체형별 연관 증상 선택지를 제공하거나 표시할 때 사용합니다.
 * 좌/우 구분이 있는 체형은 동일한 불편감 목록을 공유합니다.
 */
export const BODY_TYPE_DISCOMFORT_LIST: Record<string, string[]> = {
  // 목
  NECK_TILT: ['뒷목 압박', '회전 시 걸림', '뒷머리 욱신', '어깨 바깥쪽 관절 찌르는 느낌', '한쪽 머리 욱신', '눈이 흐릿함', '머리가 어지러움', '잠들기 어렵거나 자주 깸', '목 전반 뻐근함', '눈 주변 뻐근함', '아래턱 통증', '턱에서 소리 남', '턱이 잘 안 벌어짐', '얼굴 좌우 비대칭'],
  NECK_ROTATION: ['젖힐 때 압박', '목 옆 뻐근함', '목 뻣뻣함', '뒷목 압박', '회전 시 걸림', '뒷머리 욱신', '어깨 바깥쪽 관절 찌르는 느낌', '한쪽 머리 욱신', '눈이 흐릿함', '머리가 어지러움', '잠들기 어렵거나 자주 깸', '목 전반 뻐근함', '눈 주변 뻐근함'],
  TURTLE_NECK: ['목 옆 뻐근함', '어깨 주변 저릿함', '팔 안쪽 저림', '등 중앙·견갑 사이 압박', '젖힐 때 압박', '목 뻣뻣함', '머리 무거움', '관자 조임', '속이 울렁거림', '아래턱 통증', '턱에서 소리 남', '턱이 잘 안 벌어짐', '얼굴 좌우 비대칭'],
  CHIN_POKE: ['목 옆 뻐근함', '어깨 주변 저릿함', '팔 안쪽 저림', '손바닥 저림', '뒷머리 욱신', '목 전반 뻐근함', '회전 시 걸림', '눈 주변 뻐근함'],
  STRAIGHT_NECK: ['목 옆 뻐근함', '어깨 주변 저릿함', '팔 안쪽 저림', '손바닥 저림', '뒷머리 욱신', '뒷목 압박', '회전 시 걸림', '어깨 바깥쪽 관절 찌르는 느낌', '목 전반 뻐근함', '눈 주변 뻐근함'],
  // 어깨·팔
  RAISED_SHOULDER: ['목 전반 뻐근함', '끝까지 펼 때 뻣뻣함', '어깨 주변 저릿함', '팔 안쪽 저림', '목 옆 뻐근함', '손바닥 저림', '등 중앙·견갑 사이 압박', '머리 무거움', '관자 조임', '속이 울렁거림', '젖힐 때 압박', '목 뻣뻣함'],
  DROPPED_SHOULDER: ['팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '어깨 바깥쪽 관절 찌르는 느낌', '팔로 퍼지는 묵직함', '어깨 관절 안쪽 무거움', '팔 안쪽 저림', '발가락 저림', '팔꿈치 바깥 당김', '어깨 앞쪽 근육 당김', '어깨 앞쪽 압박'],
  ROUNDED_SHOULDER: ['발가락 저림', '가슴 앞 답답', '팔꿈치 뻣뻣함', '어깨 앞쪽 근육 당김', '팔로 퍼지는 묵직함', '어깨 관절 깊은 피로', '팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '어깨 관절 안쪽 무거움'],
  EXTENDED_SHOULDER: ['어깨 바깥쪽 관절 찌르는 느낌', '팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '팔로 퍼지는 묵직함', '어깨 앞쪽 근육 당김', '어깨 앞쪽 압박'],
  SHOULDER_HEIGHT_ASYMMETRY: ['목 전반 뻐근함', '끝까지 펼 때 뻣뻣함', '어깨 주변 저릿함', '팔 안쪽 저림', '팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림'],
  ARM_INTERNAL_ROTATION: ['팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '팔꿈치 뻣뻣함', '어깨 앞쪽 근육 당김', '팔로 퍼지는 묵직함', '어깨 관절 깊은 피로', '발가락 저림', '가슴 앞 답답', '어깨 관절 안쪽 무거움', '어깨 바깥쪽 관절 찌르는 느낌'],
  ARM_EXTERNAL_ROTATION: ['어깨 바깥쪽 관절 찌르는 느낌', '팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '팔로 퍼지는 묵직함', '어깨 앞쪽 근육 당김', '어깨 앞쪽 압박'],
  // 팔꿈치
  BENT_ELBOW: ['팔꿈치 안쪽 당김', '발가락 저림', '손 저림·피로', '팔꿈치 바깥 당김', '팔꿈치 뒤쪽→어깨 뒤 당김', '팔 들 때 통증', '팔꿈치 안쪽 저림', '손가락 저림', '팔 앞쪽 통증'],
  EXTENDED_ELBOW: ['팔꿈치 바깥 당김', '팔꿈치 뒤쪽→어깨 뒤 당김', '팔 들 때 통증', '손 저림·피로', '팔꿈치 안쪽 저림', '팔꿈치 뻣뻣함', '팔 앞쪽 통증'],
  // 등·몸통
  ROUNDED_BACK: ['팔로 퍼지는 묵직함', '팔 안쪽 저림', '손바닥 저림', '손·발 피부색 변화', '팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '가슴 앞 답답', '등 중앙·견갑 사이 압박', '목 옆 뻐근함', '옆구리 근육 당김'],
  EXTENDED_BACK: ['팔 들 때 어깨 전체 무거움', '어깨 바깥쪽 걸림', '어깨 관절 깊은 둔함', '어깨 움직일 때 소리', '어깨 관절 깊은 피로'],
  TORSO_TILT_RIGHT: ['전신 피로감 큼', '숨이 깊게 안 쉬어짐', '허리 옆쪽 뻐근함', '어깨 뒤 근육 뻐근함', '엉덩이→다리 묵직함', '허리 깊은 압박', '뒤로 젖힐 때 균형 불편', '다리 들 때 깊은 압박', '허리 근육 피로', '발목 안쪽 불안'],
  TORSO_TILT_LEFT: ['전신 피로감 큼', '숨이 깊게 안 쉬어짐', '허리 옆쪽 뻐근함', '어깨 뒤 근육 뻐근함', '엉덩이→다리 묵직함', '허리 깊은 압박', '뒤로 젖힐 때 균형 불편', '다리 들 때 깊은 압박', '허리 근육 피로', '발목 안쪽 불안'],
  TORSO_ROTATION_RIGHT: ['엉덩이→다리 묵직함', '허리 옆쪽 뻐근함', '허리 깊은 압박', '뒤로 젖힐 때 균형 불편', '다리 들 때 깊은 압박', '허리 근육 피로', '전신 피로감 큼', '숨이 깊게 안 쉬어짐', '어깨 뒤 근육 뻐근함'],
  TORSO_ROTATION_LEFT: ['엉덩이→다리 묵직함', '허리 옆쪽 뻐근함', '허리 깊은 압박', '뒤로 젖힐 때 균형 불편', '다리 들 때 깊은 압박', '허리 근육 피로', '전신 피로감 큼', '숨이 깊게 안 쉬어짐', '어깨 뒤 근육 뻐근함'],
  // 골반
  SWAY_BACK: ['엉덩이→다리 묵직함', '발 안쪽 저림', '다리 들 때 깊은 압박', '발목 안쪽 불안', '허리 옆쪽 뻐근함', '허리 좌우 비대칭 뻐근함', '회전 마지막 구간에서 허리 부담감', '골반 한쪽 묵직함', '허리 불안정 묵직함'],
  PELVIS_TILTS_FORWARD: ['엉덩이→다리 묵직함', '발바닥 중앙 피로', '허리 좌우 비대칭 뻐근함', '회전 마지막 구간에서 허리 부담감', '골반 한쪽 묵직함', '허리 불안정 묵직함', '허리 옆쪽 뻐근함', '허리 깊은 압박', '다리가 차갑게 느낌'],
  PELVIS_TILTS_BACKWARD: ['엉덩이→다리 묵직함', '허리 옆쪽 뻐근함', '허리 깊은 압박', '뒤로 젖힐 때 균형 불편', '다리 들 때 깊은 압박', '허리 근육 피로', '발목 안쪽 불안'],
  PELVIS_ASYMMETRY: ['엉덩이 바깥쪽 당김', '골반 뒤 가운데가 눌리는 느낌', '허벅지 옆 당김', '계단 이용 불편', '전신 피로감 큼', '숨이 깊게 안 쉬어짐', '허리 옆쪽 뻐근함', '어깨 뒤 근육 뻐근함', '엉덩관절 회전 중 딸깍 느낌', '엉덩관절이 딱딱 걸림', '엉덩이→다리 묵직함'],
  PELVIS_ROTATION_RIGHT: ['바깥 회전 시 깊은 걸림', '엉덩관절 깊은 압박', '엉덩회전 시 둔한 불편', '회전 범위 감소', '엉덩이 바깥쪽 당김', '골반 뒤 가운데가 눌리는 느낌', '허벅지 옆 당김', '계단 이용 불편', '허리 옆쪽 뻐근함', '걸을 때 절뚝거림', '엉덩관절 회전 중 딸깍 느낌', '엉덩관절이 딱딱 걸림', '엉덩이→다리 묵직함'],
  PELVIS_ROTATION_LEFT: ['바깥 회전 시 깊은 걸림', '엉덩관절 깊은 압박', '엉덩회전 시 둔한 불편', '회전 범위 감소', '엉덩이 바깥쪽 당김', '골반 뒤 가운데가 눌리는 느낌', '허벅지 옆 당김', '계단 이용 불편', '허리 옆쪽 뻐근함', '걸을 때 절뚝거림', '엉덩관절 회전 중 딸깍 느낌', '엉덩관절이 딱딱 걸림', '엉덩이→다리 묵직함'],
  PELVIS_SHIFT_RIGHT: ['무릎 안쪽 걸림', '무릎 펴는 중 걸림', '엉덩이 바깥쪽 당김', '바깥 회전 시 깊은 걸림', '엉덩관절 깊은 압박', '엉덩회전 시 둔한 불편', '회전 범위 감소', '골반 뒤 가운데가 눌리는 느낌', '허벅지 옆 당김', '계단 이용 불편', '허리 옆쪽 뻐근함', '걸을 때 절뚝거림'],
  PELVIS_SHIFT_LEFT: ['무릎 안쪽 걸림', '무릎 펴는 중 걸림', '엉덩이 바깥쪽 당김', '바깥 회전 시 깊은 걸림', '엉덩관절 깊은 압박', '엉덩회전 시 둔한 불편', '회전 범위 감소', '골반 뒤 가운데가 눌리는 느낌', '허벅지 옆 당김', '계단 이용 불편', '허리 옆쪽 뻐근함', '걸을 때 절뚝거림'],
  // 하지
  LEG_EXTERNAL_ROTATION: ['엉덩이→다리 묵직함', '발 안쪽 저림', '다리 들 때 깊은 압박', '무릎 앞 둔함', '걸을 때 절뚝거림', '무릎 굽힘 경직', '무릎에 물 참', '무릎에 부종'],
  LEG_INTERNAL_ROTATION: ['무릎 아래 당김', '무릎 안쪽 걸림', '무릎에 부종', '무릎 앞 둔함', '걸을 때 절뚝거림', '무릎 굽힘 경직', '무릎에 물 참'],
  BOW_LEGS: ['무릎 앞 둔함', '걸을 때 절뚝거림', '무릎 굽힘 경직', '무릎에 물 참', '무릎 안쪽 걸림', '무릎에 힘 빠짐', '무릎 펴는 중 걸림', '무릎에 부종'],
  KNOCK_LEGS: ['무릎 앞 둔함', '걸을 때 절뚝거림', '무릎 굽힘 경직', '무릎에 물 참', '무릎 안쪽 걸림', '무릎 안쪽 불안정', '무릎에 부종'],
  // 무릎·발
  BENT_KNEES: ['무릎 앞 둔함', '걸을 때 절뚝거림', '무릎 굽힘 경직', '무릎에 물 참', '계단 이용 불편', '무릎 펴는 중 걸림', '무릎에 부종'],
  BACK_KNEES: ['무릎 아래 당김', '무릎 안쪽 걸림', '무릎 굽힘 경직', '무릎에 부종', '무릎 앞 둔함', '계단 이용 불편', '무릎 펴는 중 걸림', '걸을 때 절뚝거림', '무릎에 물 참'],
  FLAT_FEET: ['뒤꿈치 당김', '발바닥 중앙 피로', '종아리 아래 당김', '발목 안쪽 불안', '발 안쪽 저림', '발가락 사이 찌릿', '엄지 안쪽 압박', '발목 앞 압박'],
  HIGH_ARCH_FEET: ['발목 바깥 불안', '발목이 뻑뻑한 느낌', '발목이 뜨거운 느낌', '보행 시 발바닥 피로', '발가락 사이 찌릿', '발바닥 중앙 피로', '뒤꿈치 당김'],
};

/**
 * 신체적 불편감 텍스트 → 기대되는 기능적 변화 텍스트 (Sheet 4 직접 매핑)
 * 상담 시 회원이 선택한 불편감 항목에 대응하는 기대 변화를 표시할 때 사용합니다.
 */
export const DISCOMFORT_TO_FUNCTIONAL_CHANGE: Record<string, string> = {
  // 목
  '목 옆 뻐근함': '목 옆 뻐근함 완화',
  '뒷목 압박': '뒷목 압박 완화',
  '관자 조임': '관자 조임 완화',
  '귀 옆 묵직함': '귀 옆 묵직함 완화',
  '회전 시 걸림': '목 회전 원활해짐',
  '팔로 퍼지는 묵직함': '팔로 퍼지는 묵직함 완화',
  '상체 긴장': '상체 긴장 완화',
  '한쪽 머리 욱신': '머리 욱신거림 완화',
  '숙일 때 압박': '고개 숙일 때 머리 압박감 완화',
  '목 전반 뻐근함': '목 전반 뻐근함 완화',
  '뒷목 당김': '뒷목 당김 완화',
  '머리 무거움': '머리 무거움 완화',
  '젖힐 때 압박': '목 젖힐 때 압박감 완화',
  '목 뒤 중심부 답답함': '목 뒤 답답함 완화',
  '목 뻣뻣함': '목 움직임 부드러워짐',
  '뒷머리 욱신': '뒷머리 욱신거림 완화',
  // 어깨
  '어깨 바깥쪽 걸림': '어깨 걸림 완화',
  '어깨 관절 안쪽 무거움': '어깨 무거움 완화',
  '어깨 바깥쪽 관절 찌르는 느낌': '어깨 찌르는 느낌 완화',
  '어깨 위 뻐근': '어깨 위 뻐근함 완화',
  '가슴 앞 답답': '가슴 앞 답답함 완화',
  '어깨 안쪽 뻐근': '어깨 안쪽 뻐근함 완화',
  '팔 안쪽 저림': '팔 안쪽 저림 완화',
  '목어깨 묵직': '목어깨 묵직함 완화',
  '어깨 앞쪽 관절 걸림': '어깨 앞 걸림 완화',
  '어깨 앞쪽 근육 당김': '어깨 앞 당김 완화',
  '어깨 관절 깊은 피로': '어깨 깊은 피로 완화',
  '팔 들 때 어깨 전체 무거움': '팔 들 때 어깨 무거움 완화',
  '팔꿈치 뒤쪽→어깨 뒤 당김': '팔·어깨 뒤 당김 완화',
  '어깨 관절 깊은 둔함': '어깨 둔한 느낌 완화',
  '등 중앙·견갑 사이 압박': '등 중앙 압박 완화',
  '어깨 뒤 근육 뻐근함': '어깨 뒤 뻐근함 완화',
  '어깨 깊은 조임·둔함': '어깨 조임 완화',
  '어깨 앞·위 찌르는 불편': '어깨 찌르는 느낌 완화',
  '어깨 깊은 둔한 불편': '어깨 둔한 불편 완화',
  '어깨 앞쪽 압박': '어깨 앞 압박 완화',
  '어깨 바깥 깊은 무거움': '어깨 바깥쪽 무거움 완화',
  '어깨 바깥 걸림': '어깨 걸림 완화',
  '목-어깨 경계 묵직함': '목어깨 묵직함 완화',
  // 팔꿈치·손
  '팔꿈치 안쪽 당김': '팔꿈치 안쪽 당김 완화',
  '팔꿈치 안쪽 저림': '팔꿈치 저림 완화',
  '손바닥 저림': '손바닥 저림 완화',
  '팔꿈치 뻣뻣함': '팔꿈치 움직임 부드러워짐',
  '팔꿈치 바깥 당김': '팔꿈치 바깥 당김 완화',
  '팔꿈치 뒤쪽 당김': '팔꿈치 뒤 당김 완화',
  '끝까지 펼 때 뻣뻣함': '팔 펴는 동작 편해짐',
  '손 저림·피로': '손 저림·피로 완화',
  // 허리
  '허리 좌우 비대칭 뻐근함': '허리 좌우 뻐근함 완화',
  '옆구리 근육 당김': '옆구리 당김 완화',
  '골반 한쪽 묵직함': '골반 묵직함 완화',
  '허리 옆쪽 뻐근함': '허리 옆 뻐근함 완화',
  '회전 마지막 구간에서 허리 부담감': '허리 회전 부담 완화',
  '허리 불안정 묵직함': '허리 안정감 회복',
  '엉덩이→다리 묵직함': '엉덩이·다리 묵직함 완화',
  '허리 근육 피로': '허리 피로 완화',
  '허리 깊은 압박': '허리 압박 완화',
  '앞으로 숙일 때 허리 눌리는 느낌': '숙일 때 허리 압박 완화',
  '허리 뒤쪽 뻐근함': '허리 뒤 뻐근함 완화',
  '허리 뒤 근육 당김': '허리 뒤 당김 완화',
  '허리 젖힐 때 답답한 느낌': '허리 젖힘 편해짐',
  '뒤로 젖힐 때 압박': '젖힐 때 압박 완화',
  '허리 전반 경직': '허리 움직임 부드러워짐',
  '뒤로 젖힐 때 균형 불편': '허리 균형 안정',
  // 엉덩관절·골반
  '엉덩관절이 딱딱 걸림': '엉덩관절 걸림 완화',
  '엉덩이 바깥쪽 당김': '골반 바깥쪽 당김 완화',
  '엉덩관절 깊은 압박': '엉덩관절 압박 완화',
  '골반 옆 묵직함': '골반 묵직함 완화',
  '골반 뒤 가운데가 눌리는 느낌': '골반 뒤 압박 완화',
  '엉덩관절 안쪽 걸림 느낌': '엉덩관절 걸림 완화',
  '허리 동반 불편': '허리 불편 완화',
  '엉덩관절 깊은 둔함': '엉덩관절 둔한 느낌 완화',
  '바깥 회전 시 깊은 걸림': '엉덩관절 바깥회전 걸림 완화',
  '엉덩관절 회전 중 딸깍 느낌': '엉덩관절 회전 시 딸깍 느낌 감소',
  '엉덩회전 시 둔한 불편': '엉덩관절 회전 편해짐',
  '허벅지 옆 당김': '허벅지 바깥쪽 당김 완화',
  '안쪽 회전 시 압박감': '엉덩관절 안쪽회전 시 서혜부 압박감 완화',
  '회전 범위 감소': '엉덩관절 회전 원활해짐',
  '골반 안쪽 불편': '골반 안쪽 불편감 완화',
  '허리-다리 묵직함': '허리·다리 묵직함 완화',
  '다리 들 때 깊은 압박': '다리 들기 편해짐',
  '엉덩관절 앞쪽 깊은 부위의 묵직한 불편감': '엉덩관절 묵직함 완화',
  '다리 뒤쪽 묵직함': '다리 뒤 묵직함 완화',
  '굽힘 시 허리 부담': '허리 굽힘 시 부담 완화',
  '골반 뒤쪽 불편': '골반 뒤 불편 완화',
  '허벅지 뒤 묵직함': '허벅지 뒤 묵직함 완화',
  '끝까지 폈을 때 눌리는 느낌': '다리 펴기 편해짐',
  '펴는 동작 전반이 뻣뻣함': '다리 움직임 부드러워짐',
  // 무릎
  '무릎 안쪽 걸림': '무릎 걸림 완화',
  '무릎 앞 둔함': '무릎 둔한 느낌 완화',
  '무릎 굽힘 경직': '무릎 굽힘 부드러워짐',
  '무릎 아래 당김': '무릎 아래 당김 완화',
  '무릎 앞 당김': '무릎 앞 당김 완화',
  '무릎 안쪽 불안정': '무릎 안정감 회복',
  '무릎 펴는 중 걸림': '무릎 펴기 편해짐',
  // 발목·발
  '발목 안쪽 불안': '발목 안정감 회복',
  '발 안쪽 저림': '발 저림 완화',
  '엄지 안쪽 압박': '발 엄지 압박감 완화',
  '발바닥 중앙 피로': '발바닥 피로 완화',
  '발목 바깥 불안': '발목 안정감 회복',
  '발가락 사이 찌릿': '발가락 찌릿함 완화',
  '발목이 뻑뻑한 느낌': '발목 움직임 부드러워짐',
  '보행 시 발바닥 피로': '보행 시 발바닥 피로 완화',
  '발목 앞 압박': '발목 앞 압박 완화',
  '종아리 아래 당김': '종아리 당김 완화',
  '발목 전반 경직': '발목 움직임 부드러워짐',
  '발 저림': '발 저림 완화',
  '발바닥 중앙 뻐근함': '발바닥 뻐근함 완화',
  '뒤꿈치 당김': '뒤꿈치 당김 완화',
  '발가락 저림': '발가락 저림 완화',
  '발목 깊은 곳의 둔한 불편감': '발목 둔한 불편감 완화',
  // 기타 전신
  '눈이 흐릿함': '눈 또렷해짐',
  '머리가 어지러움': '머리 어지러움 완화',
  '잠들기 어렵거나 자주 깸': '수면 편안해짐',
  '눈 주변 뻐근함': '눈 주변 뻐근함 완화',
  '아래턱 통증': '턱 불편 완화',
  '턱에서 소리 남': '턱 소리 감소',
  '턱이 잘 안 벌어짐': '턱 움직임 편해짐',
  '얼굴 좌우 비대칭': '얼굴 균형 개선',
  '어깨 주변 저릿함': '어깨 저릿함 완화',
  '등 라인 통증': '등 불편 완화',
  '등이 저릿함': '등 저림 완화',
  '어깨 저릿함': '어깨 저림 완화',
  '어깨 움직일 때 소리': '어깨 소리 감소',
  '어깨 힘줄 부기': '어깨 붓기 완화',
  '전신 피로감 큼': '전신 피로 완화',
  '숨이 깊게 안 쉬어짐': '숨 쉬기 편해짐',
  '숨쉬기 답답함': '호흡 편안해짐',
  '속이 울렁거림': '속 불편 완화',
  '다리가 차갑게 느낌': '다리 온기 회복',
  '걸을 때 절뚝거림': '보행 안정',
  '무릎에 물 참': '무릎 붓기 완화',
  '무릎에 힘 빠짐': '무릎 힘 회복',
  '발목이 뜨거운 느낌': '발목 열감 완화',
  '손·발 피부색 변화': '손발 색 균형 회복',
  // 체형별 불편감 목록에 추가된 항목
  '계단 이용 불편': '계단 이용 편해짐',
  '무릎에 부종': '무릎 붓기 완화',
  '팔 앞쪽 통증': '팔 앞 통증 완화',
  '팔 들 때 통증': '팔 들기 편해짐',
  '손가락 저림': '손가락 저림 완화',
};

/** 배열에서 중복 없이 n개를 랜덤 선택합니다 (Fisher-Yates 샘플링) */
export function pickRandom<T>(arr: T[], n: number): T[] {
  const shuffled = [...arr];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled.slice(0, Math.min(n, shuffled.length));
}

export interface ActionPlanComponents {
  /** 운동 목적 (1순위 체형 기준) */
  exercisePurpose: string;
  /** 가장 심각한 체형 상위 2개 레이블 */
  topBodyTypes: string[];
  /** 중점 적용 운동 루틴 (1순위 체형 기준) */
  focusExercise: string;
  /** 주 권장 운동 횟수 (기본값 2, 수정 가능) */
  weeklyFrequency: number;
  /** 기대 변화 목록: 상위 2개 체형 각각 외형 변화 1개 + 신체적 불편감 3개 */
  expectedChanges: string[];
  /** 완성된 액션플랜 텍스트 (저장 용도) */
  generatedText: string;
}

/**
 * 체형 리포트 analysisData로부터 액션플랜 구성 요소를 생성합니다.
 *
 * 정렬 기준:
 * 1차: disease score 오름차순 (낮을수록 더 심각)
 * 2차: Sheet 2 우선순위 오름차순 (동점일 때 tiebreaker)
 *
 * 좌/우 구분 없이 동일 체형명으로 중복 제거 후 상위 2개를 표시합니다.
 * BOW_LEGS + LEG_INTERNAL_ROTATION(또는 LEGS_TURNED_INWARD) 동반 시 "안으로 돌아간 다리 + 오다리" 기준으로 처리합니다.
 */
export function generateActionPlanComponents(
  analysisData: any,
  weeklyFrequency: number = 2,
): ActionPlanComponents {
  const diseases: Array<{ key: string; score: number }> = (analysisData?.disease ?? []).filter(
    (d: any) => d?.key && d.key !== 'NORMAL',
  );

  const ranked = rankBodyDiseases(diseases);
  const allDiseaseKeys = new Set(diseases.map((d) => d.key));

  const topDiseases = ranked.slice(0, 2);
  const topBodyTypes = topDiseases.map((d) => d.label);
  const primaryKey = topDiseases[0]?.key;
  const primaryNk = primaryKey ? normalizeKey(primaryKey) : undefined;

  // BOW_LEGS + LEG_INTERNAL_ROTATION(또는 LEGS_TURNED_INWARD) 동반 여부 확인
  const isBowLegsInward =
    allDiseaseKeys.has('BOW_LEGS') &&
    (allDiseaseKeys.has('LEG_INTERNAL_ROTATION') || allDiseaseKeys.has('LEGS_TURNED_INWARD'));

  const exercisePurpose = primaryNk ? (BODY_TYPE_EXERCISE_PURPOSE[primaryNk] ?? '') : '';

  const focusExercise =
    primaryNk === 'BOW_LEGS' && isBowLegsInward
      ? '넙다리 바깥돌림 활성화 + 둔부 안정화 루틴'
      : (primaryNk ? (BODY_TYPE_FOCUS_EXERCISE[primaryNk] ?? '') : '');

  // 기대 변화: 상위 2개 체형 각각 외형 변화 1개 + 신체적 불편감 3개 = 최대 8개
  const expectedChanges: string[] = [];
  for (const { key } of topDiseases) {
    const nk = normalizeKey(key);
    const appearanceChange =
      nk === 'BOW_LEGS' && isBowLegsInward
        ? '허벅지 앞라인 정리'
        : (BODY_TYPE_APPEARANCE_FUNCTIONAL_CHANGE[nk] ?? '');

    // 신체적 불편감: 체형별 목록에서 3개 랜덤 선택 → 직접 사용
    const discomfortList = BODY_TYPE_DISCOMFORT_LIST[nk] ?? [];
    const selectedDiscomforts = pickRandom(discomfortList, 3);

    if (appearanceChange) expectedChanges.push(appearanceChange);
    selectedDiscomforts.forEach(d => expectedChanges.push(d));
  }

  const topBodyTypesText = topBodyTypes.join(', ');
  const expectedChangesText = expectedChanges.join(', ');

  const generatedText =
    `이번 상담을 통해 설정된 운동 목적은 ${exercisePurpose}입니다.\n\n` +
    `현재 분석 결과 ${topBodyTypesText} 패턴이 확인되었습니다.\n\n` +
    `따라서 향후 트레이닝은 ${focusExercise}을 중심으로 진행하며\n\n` +
    `전체 프로그램은 주 ${weeklyFrequency}회 참여 기준으로 설계되었습니다.\n\n` +
    `해당 정렬이 완화될 경우 ${expectedChangesText}이 기대됩니다.`;

  return {
    exercisePurpose,
    topBodyTypes,
    focusExercise,
    weeklyFrequency,
    expectedChanges,
    generatedText,
  };
}
