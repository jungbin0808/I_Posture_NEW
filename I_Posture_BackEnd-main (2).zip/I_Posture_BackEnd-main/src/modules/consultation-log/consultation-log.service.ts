import { BadRequestException, Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { ConsultationLogEntity } from '../../database/entities/consultation-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { CapacityService } from '../capacity/capacity.service';
import { FindConsultationLogDto } from './dto/find-consultation-log.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { ConsultationLogResponseDto } from './dto/consultation-log-response.dto';
import { CreateConsultationLogDto } from './dto/create-consultation-log.dto';
import { S3Service } from '../../s3/s3.service';
import { FileEntity, FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { UpdateConsultationLogDto } from './dto/update-consultation-log.dto';
import { DeleteConsultationLogsDto } from './dto/delete-consultation-logs.dto';
import { ConsultationLogDetailResponseDto } from './dto/consultation-log-detail-response.dto';
import { ActionPlanComponents, generateActionPlanComponents } from './action-plan.helper';

const PRECISION_REPORT_CATEGORY_MAP: Record<string, string> = {
  BODY:                  'rom',
  NECK:                  'rom',
  SHOULDER:              'rom',
  ELBOW:                 'rom',
  TORSO:                 'rom',
  HIP:                   'rom',
  KNEE:                  'rom',
  ANKLE:                 'rom',
  SPINAL_ALIGNMENT_TEST: 'spinalAlignmentTest',
  OVERHEAD_SQUAT_TEST:   'overheadSquatTest',
  BALANCE_TEST:          'balanceTest',
};
function getPrecisionReportCategory(type: string | null | undefined): string | null {
  if (!type) return null;
  return PRECISION_REPORT_CATEGORY_MAP[type] ?? null;
}

@Injectable()
export class ConsultationLogService {
  constructor(
    @InjectRepository(ConsultationLogEntity)
    private readonly consultationLogRepo: Repository<ConsultationLogEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(BodyReportEntity)
    private readonly bodyReportRepo: Repository<BodyReportEntity>,
    @InjectRepository(PrecisionReportEntity)
    private readonly precisionReportRepo: Repository<PrecisionReportEntity>,
    @InjectRepository(MotionAnalysisEntity)
    private readonly motionAnalysisRepo: Repository<MotionAnalysisEntity>,
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
  ) {}

  private async assertTrainerMemberAccess(trainerId: string, memberId: string): Promise<void> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원에 대한 권한이 없습니다.');
    }
  }

  private async getTrainerOrThrow(trainerId: string): Promise<UserEntity> {
    const trainer = await this.userRepo.findOne({ where: { id: trainerId } });
    if (!trainer) {
      throw new NotFoundException('트레이너를 찾을 수 없습니다.');
    }
    return trainer;
  }

  private async validateLinkedResources(
    memberId: string,
    linked: {
      bodyReportId?: string | null;
      precisionReportId?: string | null;
      motionAnalysisId?: string | null;
      inbodyDataId?: string | null;
    },
  ): Promise<void> {
    if (linked.bodyReportId) {
      const exists = await this.bodyReportRepo.findOne({ where: { id: linked.bodyReportId, userId: memberId } });
      if (!exists) throw new BadRequestException('유효하지 않은 체형 리포트입니다.');
    }
    if (linked.precisionReportId) {
      const exists = await this.precisionReportRepo.findOne({ where: { id: linked.precisionReportId, userId: memberId } });
      if (!exists) throw new BadRequestException('유효하지 않은 정밀 리포트입니다.');
    }
    if (linked.motionAnalysisId) {
      const exists = await this.motionAnalysisRepo.findOne({ where: { id: linked.motionAnalysisId, userId: memberId } });
      if (!exists) throw new BadRequestException('유효하지 않은 모션 분석 데이터입니다.');
    }
    if (linked.inbodyDataId) {
      const exists = await this.inbodyDataRepo.findOne({ where: { id: linked.inbodyDataId, userId: memberId } });
      if (!exists) throw new BadRequestException('유효하지 않은 인바디 데이터입니다.');
    }
  }

  private async removeConsultationFiles(trainer: UserEntity, files: FileEntity[]): Promise<void> {
    for (const file of files) {
      await this.s3Service.deleteFile(file.s3Key);
      await this.fileRepo.delete(file.id);
      await this.capacityService.updateCenterCapacity(trainer, `-${file.size}`);
    }
  }

  async generateActionPlan(
    trainerId: string,
    memberId: string,
    bodyReportId?: string,
  ): Promise<ActionPlanComponents> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 정보를 조회할 권한이 없습니다.');

    const bodyReport = bodyReportId
      ? await this.bodyReportRepo.findOne({ where: { id: bodyReportId, userId: memberId } })
      : await this.bodyReportRepo.findOne({ where: { userId: memberId }, order: { createdAt: 'DESC' } });

    if (!bodyReport) throw new NotFoundException('체형 리포트를 찾을 수 없습니다.');

    return generateActionPlanComponents(bodyReport.analysisData);
  }

  async findAllByMemberId(trainerId: string, memberId: string, dto: FindConsultationLogDto): Promise<IPageData<ConsultationLogResponseDto>> {
    const member = await this.userRepo.findOne({ where: { id: memberId } });
    if (!member) throw new NotFoundException('회원을 찾을 수 없습니다.');

    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 상담 일지를 조회할 권한이 없습니다.');

    const { page = 1, limit = 10, startDate, endDate, sort } = dto;
    const query = this.consultationLogRepo.createQueryBuilder('log')
      .leftJoinAndSelect('log.bodyReport', 'bodyReport')
      .leftJoinAndSelect('log.precisionReport', 'precisionReport')
      .leftJoinAndSelect('log.motionAnalysis', 'motionAnalysis')
      .leftJoinAndSelect('log.inbodyData', 'inbodyData')
      .where('log.userId = :userId', { userId: memberId })
      .andWhere('log.trainerId = :trainerId', { trainerId });

    if (startDate) query.andWhere('log.consultAt >= :startDate', { startDate });
    if (endDate) query.andWhere('log.consultAt <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('log.consultAt', sortDirection);

    const total = await query.getCount();
    const logs = await query.offset((page - 1) * limit).limit(limit).getMany();

    const items: ConsultationLogResponseDto[] = logs.map(log => ({
      id: log.id,
      consultationDate: log.consultAt,
      consultationType: log.consultType,
      memo: log.actionPlan || null,
      bodyReportDate: log.bodyReport?.createdAt || null,
      precisionReportDate: log.precisionReport?.createdAt || null,
      motionAnalysisDate: log.motionAnalysis?.createdAt || null,
      inbodyDataDate: log.inbodyData?.createdAt || null,
      // ID는 연관 엔티티가 삭제(soft-delete)되어 JOIN이 null이면 함께 null 처리
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 상담 일지 상세 조회 (퍼블릭 - 인증 불필요)
   */
  async findOnePublic(logId: string, memberId?: string): Promise<ConsultationLogDetailResponseDto> {
    const qb = this.consultationLogRepo.createQueryBuilder('log')
      .leftJoinAndSelect('log.bodyReport', 'bodyReport')
      .leftJoinAndSelect('log.precisionReport', 'precisionReport')
      .leftJoinAndSelect('log.motionAnalysis', 'motionAnalysis')
      .leftJoinAndSelect('log.inbodyData', 'inbodyData')
      .where('log.id = :logId', { logId });
    if (memberId) {
      qb.andWhere('log.user_id = :memberId', { memberId });
    }
    const log = await qb.getOne();
    if (!log) throw new NotFoundException('상담 일지를 찾을 수 없습니다.');

    const member = await this.userRepo.findOne({ where: { id: log.userId } });
    const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.CONSULTATION_LOG, relatedId: logId } });

    return {
      id: log.id,
      member: { id: member?.id ?? '', name: member?.name ?? '' },
      consultAt: log.consultAt,
      consultType: log.consultType,
      bodyReportId: log.bodyReport ? log.bodyReportId : null,
      bodyReportDate: log.bodyReport?.createdAt ?? null,
      precisionReportId: log.precisionReport ? log.precisionReportId : null,
      precisionReportDate: log.precisionReport?.createdAt ?? null,
      precisionReportType: log.precisionReport?.type ?? null,
      precisionReportName: log.precisionReport?.name ?? null,
      precisionReportCategory: getPrecisionReportCategory(log.precisionReport?.type),
      motionAnalysisId: log.motionAnalysis ? log.motionAnalysisId : null,
      motionAnalysisDate: log.motionAnalysis?.createdAt ?? null,
      inbodyDataId: log.inbodyData?.measuredAt ? log.inbodyDataId : null,
      inbodyDataDate: log.inbodyData?.measuredAt ?? null,
      shortGoalTags: log.shortGoalTags,
      shortGoalText: log.shortGoalText,
      longGoalTags: log.longGoalTags,
      longGoalText: log.longGoalText,
      actionPlan: log.actionPlan,
      recommendation: log.recommendation,
      resultStatus: log.resultStatus,
      files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, size: f.size, s3Key: f.s3Key })),
      createdAt: log.createdAt,
    };
  }

  async findOne(trainerId: string, memberId: string, logId: string): Promise<ConsultationLogDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({
      where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE },
    });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 상담 일지를 조회할 권한이 없습니다.');

    const member = await this.userRepo.findOne({ where: { id: memberId } });
    if (!member) throw new NotFoundException('회원을 찾을 수 없습니다.');

    const log = await this.consultationLogRepo.createQueryBuilder('log')
      .leftJoinAndSelect('log.bodyReport', 'bodyReport')
      .leftJoinAndSelect('log.precisionReport', 'precisionReport')
      .leftJoinAndSelect('log.motionAnalysis', 'motionAnalysis')
      .leftJoinAndSelect('log.inbodyData', 'inbodyData')
      .where('log.id = :logId', { logId })
      .getOne();
    if (!log) throw new NotFoundException('상담 일지를 찾을 수 없습니다.');

    if (log.userId !== memberId) {
      throw new NotFoundException('해당 회원의 상담 일지가 아닙니다.');
    }

    const files = await this.fileRepo.find({ where: { relatedType: FileRelatedType.CONSULTATION_LOG, relatedId: logId } });

    return {
      id: log.id,
      member: { id: member.id, name: member.name },
      consultAt: log.consultAt,
      consultType: log.consultType,
      bodyReportId: log.bodyReport ? log.bodyReportId : null,
      bodyReportDate: log.bodyReport?.createdAt ?? null,
      precisionReportId: log.precisionReport ? log.precisionReportId : null,
      precisionReportDate: log.precisionReport?.createdAt ?? null,
      precisionReportType: log.precisionReport?.type ?? null,
      precisionReportName: log.precisionReport?.name ?? null,
      precisionReportCategory: getPrecisionReportCategory(log.precisionReport?.type),
      motionAnalysisId: log.motionAnalysis ? log.motionAnalysisId : null,
      motionAnalysisDate: log.motionAnalysis?.createdAt ?? null,
      inbodyDataId: log.inbodyData?.measuredAt ? log.inbodyDataId : null,
      inbodyDataDate: log.inbodyData?.measuredAt ?? null,
      shortGoalTags: log.shortGoalTags,
      shortGoalText: log.shortGoalText,
      longGoalTags: log.longGoalTags,
      longGoalText: log.longGoalText,
      actionPlan: log.actionPlan,
      recommendation: log.recommendation,
      resultStatus: log.resultStatus,
      files: files.map(f => ({ id: f.id, fileUrl: f.fileUrl, size: f.size, s3Key: f.s3Key })),
      createdAt: log.createdAt,
    };
  }

  @Transactional()
  async create(trainerId: string, memberId: string, dto: CreateConsultationLogDto, files?: Express.Multer.File[]): Promise<ConsultationLogEntity> {
    await this.assertTrainerMemberAccess(trainerId, memberId);
    await this.validateLinkedResources(memberId, dto);

    const trainer = await this.getTrainerOrThrow(trainerId);
    const consultationLog = this.consultationLogRepo.create({
      ...dto,
      trainerId,
      userId: memberId,
    });
    const savedLog = await this.consultationLogRepo.save(consultationLog);

    if (files && files.length > 0) {
      for (const file of files) {
        const uploadedFile = await this.s3Service.uploadFile(file, {
          memberId: memberId,
          uploaderId: trainerId,
          ownerType: FileOwnerType.MEMBER,
          ownerId: memberId,
          relatedType: FileRelatedType.CONSULTATION_LOG,
          relatedId: savedLog.id,
        });
        await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      }
    }

    return savedLog;
  }

  @Transactional()
  async update(trainerId: string, memberId: string, logId: string, dto: UpdateConsultationLogDto, files?: Express.Multer.File[]): Promise<ConsultationLogEntity> {
    await this.assertTrainerMemberAccess(trainerId, memberId);

    const log = await this.consultationLogRepo.findOne({ where: { id: logId } });
    if (!log) throw new NotFoundException('상담 일지를 찾을 수 없습니다.');

    if (log.userId !== memberId) throw new NotFoundException('해당 회원의 상담 일지가 아닙니다.');
    if (log.trainerId !== trainerId) throw new ForbiddenException('본인이 작성한 상담 일지만 수정할 수 있습니다.');

    await this.validateLinkedResources(memberId, dto);

    const trainer = await this.getTrainerOrThrow(trainerId);
    Object.assign(log, dto);

    if (files && files.length > 0) {
      const existingFiles = await this.fileRepo.find({ where: { relatedId: logId, relatedType: FileRelatedType.CONSULTATION_LOG } });
      const keepIds = dto.existingFileIds ?? [];
      const filesToRemove = existingFiles.filter((file) => !keepIds.includes(file.id));
      await this.removeConsultationFiles(trainer, filesToRemove);

      for (const file of files) {
        const uploadedFile = await this.s3Service.uploadFile(file, {
          memberId: memberId,
          uploaderId: trainerId,
          ownerType: FileOwnerType.MEMBER,
          ownerId: memberId,
          relatedType: FileRelatedType.CONSULTATION_LOG,
          relatedId: log.id,
        });
        await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      }
    } else if (dto.existingFileIds !== undefined) {
      const existingFiles = await this.fileRepo.find({ where: { relatedId: logId, relatedType: FileRelatedType.CONSULTATION_LOG } });
      const keepIds = dto.existingFileIds;
      const filesToRemove = existingFiles.filter((file) => !keepIds.includes(file.id));
      await this.removeConsultationFiles(trainer, filesToRemove);
    }

    return this.consultationLogRepo.save(log);
  }

  @Transactional()
  async delete(trainerId: string, memberId: string, dto: DeleteConsultationLogsDto): Promise<{ success: boolean }> {
    await this.assertTrainerMemberAccess(trainerId, memberId);

    const logs = await this.consultationLogRepo.find({ where: { id: In(dto.logIds) } });
    if (logs.length !== dto.logIds.length) {
      throw new NotFoundException('일부 상담 일지를 찾을 수 없습니다.');
    }

    for (const log of logs) {
      if (log.userId !== memberId) throw new ForbiddenException(`일지 ${log.id}는 해당 회원의 것이 아닙니다.`);
      if (log.trainerId !== trainerId) throw new ForbiddenException(`일지 ${log.id}를 삭제할 권한이 없습니다.`);
    }

    const trainer = await this.getTrainerOrThrow(trainerId);
    for (const logId of dto.logIds) {
      const files = await this.fileRepo.find({
        where: { relatedId: logId, relatedType: FileRelatedType.CONSULTATION_LOG },
      });
      await this.removeConsultationFiles(trainer, files);
    }

    await this.consultationLogRepo.softDelete(dto.logIds);
    return { success: true };
  }
}
