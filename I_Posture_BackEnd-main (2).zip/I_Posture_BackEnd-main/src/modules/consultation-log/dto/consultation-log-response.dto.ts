import { ApiProperty } from '@nestjs/swagger';
import { ConsultType } from '../../../database/entities/consultation-log.entity';

export class ConsultationLogResponseDto {
  @ApiProperty({ description: '상담일지 ID' })
  id!: string;

  @ApiProperty({ description: '상담 날짜' })
  consultationDate!: Date;

  @ApiProperty({ description: '상담 유형', enum: ConsultType })
  consultationType!: ConsultType;

  @ApiProperty({ description: '메모 (액션 플랜)', nullable: true })
  memo?: string | null;

  @ApiProperty({ description: '측정 데이터 날짜', nullable: true })
  bodyReportDate?: Date | null;

  @ApiProperty({ description: '리포트 데이터 날짜', nullable: true })
  precisionReportDate?: Date | null;

  @ApiProperty({ description: '모션 분석 데이터 날짜', nullable: true })
  motionAnalysisDate?: Date | null;

  @ApiProperty({ description: '인바디 데이터 날짜', nullable: true })
  inbodyDataDate?: Date | null;
}
