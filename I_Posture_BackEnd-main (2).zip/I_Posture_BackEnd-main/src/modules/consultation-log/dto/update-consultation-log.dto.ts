import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsArray, IsDateString, IsEnum, IsOptional, IsString, IsUUID } from 'class-validator';
import { ConsultType, ConsultResultStatus } from '../../../database/entities/consultation-log.entity';

export class UpdateConsultationLogDto {
  @ApiProperty({ description: '상담 유형', enum: ConsultType, required: false })
  @IsEnum(ConsultType)
  @IsOptional()
  consultType?: ConsultType;

  @ApiProperty({ description: '상담 진행 일시', required: false })
  @IsDateString()
  @IsOptional()
  consultAt?: string;

  @ApiProperty({ description: '연동할 체형 리포트 ID', required: false })
  @IsOptional()
  @Transform(({ value }) => (value === '' || value === 'null' ? null : value))
  @IsUUID()
  bodyReportId?: string;

  @ApiProperty({ description: '연동할 정밀 리포트 ID', required: false })
  @IsOptional()
  @Transform(({ value }) => (value === '' || value === 'null' ? null : value))
  @IsUUID()
  precisionReportId?: string;

  @ApiProperty({ description: '연동할 모션 분석 ID', required: false })
  @IsOptional()
  @Transform(({ value }) => (value === '' || value === 'null' ? null : value))
  @IsUUID()
  motionAnalysisId?: string;

  @ApiProperty({ description: '연동할 인바디 데이터 ID', required: false })
  @IsOptional()
  @Transform(({ value }) => (value === '' || value === 'null' ? null : value))
  @IsUUID()
  inbodyDataId?: string;

  @ApiProperty({ description: '단기 목표 태그 (콤마 구분)', required: false })
  @IsString()
  @IsOptional()
  shortGoalTags?: string;

  @ApiProperty({ description: '단기 목표 직접 입력', required: false })
  @IsString()
  @IsOptional()
  shortGoalText?: string;

  @ApiProperty({ description: '중장기 목표 태그 (콤마 구분)', required: false })
  @IsString()
  @IsOptional()
  longGoalTags?: string;

  @ApiProperty({ description: '중장기 목표 직접 입력', required: false })
  @IsString()
  @IsOptional()
  longGoalText?: string;

  @ApiProperty({ description: '액션 플랜', required: false })
  @IsString()
  @IsOptional()
  actionPlan?: string;

  @ApiProperty({ description: '맞춤 운동 프로그램', required: false })
  @IsString()
  @IsOptional()
  recommendation?: string;

  @ApiProperty({ description: '상담 결과', enum: ConsultResultStatus, required: false })
  @IsEnum(ConsultResultStatus)
  @IsOptional()
  resultStatus?: ConsultResultStatus;

  @ApiProperty({ description: '유지할 기존 이미지 파일 ID 목록', type: [String], required: false })
  @IsOptional()
  @Transform(({ value }) => {
    if (!value) return undefined;
    if (Array.isArray(value)) return value;
    if (typeof value === 'string') {
      try { return JSON.parse(value); } catch { return [value]; }
    }
    return value;
  })
  @IsArray()
  @IsUUID('all', { each: true })
  existingFileIds?: string[];
}
