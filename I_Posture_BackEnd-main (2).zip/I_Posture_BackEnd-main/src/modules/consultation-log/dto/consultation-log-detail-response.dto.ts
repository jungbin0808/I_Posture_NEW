import { ApiProperty } from '@nestjs/swagger';
import { ConsultType, ConsultResultStatus } from '../../../database/entities/consultation-log.entity';

class MemberInfo {
  @ApiProperty()
  id!: string;
  @ApiProperty()
  name!: string;
}

class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '파일 크기' })
  size!: string;

  @ApiProperty({ description: '원본 파일명 (S3 Key 등)' })
  s3Key!: string;
}

export class ConsultationLogDetailResponseDto {
  @ApiProperty({ description: '상담일지 ID' })
  id!: string;

  @ApiProperty({ description: '회원 정보' })
  member!: MemberInfo;

  @ApiProperty({ description: '상담 날짜' })
  consultAt!: Date;

  @ApiProperty({ description: '상담 유형', enum: ConsultType })
  consultType!: ConsultType;

  @ApiProperty({ description: '연동된 체형 리포트 ID', nullable: true })
  bodyReportId?: string | null;

  @ApiProperty({ description: '체형 리포트 측정일시', nullable: true })
  bodyReportDate?: Date | null;

  @ApiProperty({ description: '연동된 정밀 리포트 ID', nullable: true })
  precisionReportId?: string | null;

  @ApiProperty({ description: '정밀 리포트 측정일시', nullable: true })
  precisionReportDate?: Date | null;

  @ApiProperty({ description: '정밀 리포트 분석 유형 (BODY, NECK, SHOULDER 등)', nullable: true })
  precisionReportType?: string | null;

  @ApiProperty({ description: '정밀 리포트 동작명 (예: 목 굽힘, 왼쪽 엉덩이 굽힘 등)', nullable: true })
  precisionReportName?: string | null;

  @ApiProperty({ description: '정밀 리포트 검사 카테고리 (rom | spinal | functional | balance)', nullable: true })
  precisionReportCategory?: string | null;

  @ApiProperty({ description: '연동된 모션 분석 ID', nullable: true })
  motionAnalysisId?: string | null;

  @ApiProperty({ description: '모션 분석 측정일시', nullable: true })
  motionAnalysisDate?: Date | null;

  @ApiProperty({ description: '연동된 인바디 데이터 ID', nullable: true })
  inbodyDataId?: string | null;

  @ApiProperty({ description: '인바디 측정일시', nullable: true })
  inbodyDataDate?: Date | null;

  @ApiProperty({ description: '단기 목표 태그', nullable: true })
  shortGoalTags?: string;

  @ApiProperty({ description: '단기 목표 직접 입력', nullable: true })
  shortGoalText?: string;

  @ApiProperty({ description: '중장기 목표 태그', nullable: true })
  longGoalTags?: string;

  @ApiProperty({ description: '중장기 목표 직접 입력', nullable: true })
  longGoalText?: string;

  @ApiProperty({ description: '액션 플랜', nullable: true })
  actionPlan?: string;

  @ApiProperty({ description: '맞춤 운동 프로그램', nullable: true })
  recommendation?: string;

  @ApiProperty({ description: '상담 결과', enum: ConsultResultStatus })
  resultStatus!: ConsultResultStatus;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto] })
  files!: FileDto[];

  @ApiProperty({ description: '작성일시' })
  createdAt!: Date;
}
