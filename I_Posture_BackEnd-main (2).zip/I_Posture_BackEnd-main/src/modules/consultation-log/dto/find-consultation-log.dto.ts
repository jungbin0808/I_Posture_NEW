import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export enum ConsultationLogSortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindConsultationLogDto extends PaginationDto {
  @ApiProperty({ description: '조회 시작 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '조회 종료 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({ description: '정렬 순서', enum: ConsultationLogSortOrder, required: false, default: ConsultationLogSortOrder.DATE_DESC })
  @IsEnum(ConsultationLogSortOrder)
  @IsOptional()
  sort?: ConsultationLogSortOrder = ConsultationLogSortOrder.DATE_DESC;
}
