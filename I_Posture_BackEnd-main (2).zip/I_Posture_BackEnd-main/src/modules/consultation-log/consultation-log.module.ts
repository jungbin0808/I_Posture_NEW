import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ConsultationLogEntity } from '../../database/entities/consultation-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { BodyReportEntity } from '../../database/entities/body-report.entity';
import { PrecisionReportEntity } from '../../database/entities/precision-report.entity';
import { MotionAnalysisEntity } from '../../database/entities/motion-analysis.entity';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import {
  ConsultationLogController,
  PublicConsultationLogController,
  CenterConsultationLogPublicController,
} from './consultation-log.controller';
import { ConsultationLogService } from './consultation-log.service';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { S3Module } from '../../s3/s3.module';
import { CapacityModule } from '../capacity/capacity.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ConsultationLogEntity,
      UserEntity,
      TrainerUserEntity,
      FileEntity,
      BodyReportEntity,
      PrecisionReportEntity,
      MotionAnalysisEntity,
      InbodyDataEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
    ]),
    S3Module,
    CapacityModule,
  ],
  controllers: [
    ConsultationLogController,
    PublicConsultationLogController,
    CenterConsultationLogPublicController,
  ],
  providers: [ConsultationLogService, SubscriptionGuard],
  exports: [ConsultationLogService],
})
export class ConsultationLogModule {}
