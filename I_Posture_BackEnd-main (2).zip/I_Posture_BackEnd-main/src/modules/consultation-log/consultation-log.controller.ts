import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UploadedFiles, UseGuards, UseInterceptors } from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { ConsultationLogService } from './consultation-log.service';
import { FindConsultationLogDto } from './dto/find-consultation-log.dto';
import { ConsultationLogResponseDto } from './dto/consultation-log-response.dto';
import { CreateConsultationLogDto } from './dto/create-consultation-log.dto';
import { ConsultationLogEntity } from '../../database/entities/consultation-log.entity';
import { ConsultationLogDetailResponseDto } from './dto/consultation-log-detail-response.dto';
import { UpdateConsultationLogDto } from './dto/update-consultation-log.dto';
import { DeleteConsultationLogsDto } from './dto/delete-consultation-logs.dto';
import { ActionPlanComponents } from './action-plan.helper';

@ApiTags('Consultation Log')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('consultation-logs')
export class ConsultationLogController {
  constructor(private readonly consultationLogService: ConsultationLogService) {}

  /**
   * @summary 체형 리포트 기반 액션플랜 자동 생성
   */
  @ApiOperation({ summary: 'Generate Action Plan from Body Report (Trainer Only)' })
  @ApiQuery({ name: 'bodyReportId', description: '체형 리포트 ID (미입력 시 가장 최근 리포트 사용)', required: false })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/action-plan')
  async generateActionPlan(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query('bodyReportId') bodyReportId?: string,
  ): Promise<ISuccessResponse<ActionPlanComponents>> {
    const result = await this.consultationLogService.generateActionPlan(req.user.id, memberId, bodyReportId);
    return SuccessResponse(result);
  }

  /**
   * @summary 트레이너가 관리 회원의 상담 일지 목록 조회
   */
  @ApiOperation({ summary: 'Get Member Consultation Logs (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() findDto: FindConsultationLogDto,
  ): Promise<IPageResponse<ConsultationLogResponseDto>> {
    const pageData = await this.consultationLogService.findAllByMemberId(req.user.id, memberId, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 상담 일지 상세 조회 (트레이너용)
   */
  @ApiOperation({ summary: 'Get Consultation Log Detail (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/:logId')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
  ): Promise<ISuccessResponse<ConsultationLogDetailResponseDto>> {
    const log = await this.consultationLogService.findOne(req.user.id, memberId, logId);
    return SuccessResponse(log);
  }

  /**
   * @summary 상담 일지 등록 (트레이너용)
   */
  @ApiOperation({ summary: 'Create Consultation Log (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: CreateConsultationLogDto })
  async create(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() createDto: CreateConsultationLogDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<ConsultationLogEntity>> {
    const log = await this.consultationLogService.create(req.user.id, memberId, createDto, files);
    return SuccessResponse(log);
  }

  /**
   * @summary 상담 일지 수정 (트레이너용)
   */
  @ApiOperation({ summary: 'Update Consultation Log (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put('member/:memberId/:logId')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: UpdateConsultationLogDto })
  async update(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
    @Body() updateDto: UpdateConsultationLogDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<ConsultationLogEntity>> {
    const log = await this.consultationLogService.update(req.user.id, memberId, logId, updateDto, files);
    return SuccessResponse(log);
  }

  /**
   * @summary 상담 일지 일괄 삭제 (트레이너용)
   */
  @ApiOperation({ summary: 'Delete Consultation Logs (Trainer Only)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() deleteDto: DeleteConsultationLogsDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.consultationLogService.delete(req.user.id, memberId, deleteDto);
    return SuccessResponse(result);
  }
}

/**
 * 상담일지 퍼블릭 API (인증 불필요)
 */
@ApiTags('Consultation Log')
@Controller('consultation-logs')
export class PublicConsultationLogController {
  constructor(private readonly consultationLogService: ConsultationLogService) {}

  /**
   * @summary 상담일지 상세 조회 (공유 링크 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Consultation Log Detail (Public Share)' })
  @Get(':logId/public')
  async findOnePublic(
    @Param('logId') logId: string,
  ): Promise<ISuccessResponse<ConsultationLogDetailResponseDto>> {
    const log = await this.consultationLogService.findOnePublic(logId);
    return SuccessResponse(log);
  }
}

/**
 * 센터용 상담일지 퍼블릭 API (인증 불필요, 공유 링크)
 */
@ApiTags('Center Consultation Log Public')
@Controller('center/consultation-logs/public')
export class CenterConsultationLogPublicController {
  constructor(private readonly consultationLogService: ConsultationLogService) {}

  @ApiOperation({ summary: 'Get Consultation Log Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/:logId')
  async findOnePublic(
    @Param('memberId') memberId: string,
    @Param('logId') logId: string,
  ): Promise<ISuccessResponse<ConsultationLogDetailResponseDto>> {
    const log = await this.consultationLogService.findOnePublic(logId, memberId);
    return SuccessResponse(log);
  }
}
