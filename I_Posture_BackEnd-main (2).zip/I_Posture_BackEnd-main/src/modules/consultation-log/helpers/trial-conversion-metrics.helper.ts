import { DataSource } from 'typeorm';
import {
  buildAttributedTrainerIdExpr,
  buildSameOwnerAcrossTransferCondition,
  buildTransferAwareTrainerIdsCondition,
} from './trainer-transfer-attribution.helper';

export interface TrialConversionMetrics {
  trialMemberCount: number;
  trialConversionCount: number;
}

/**
 * [체험수업 등록 전환율 — 개발자가 아니어도 이해할 수 있는 설명]
 *
 * "체험수업을 받았던 회원 중에서, 실제로 결제(신규등록·재등록)까지 이어진
 * 회원이 몇 %나 되는가"를 나타내는 지표입니다.
 *
 * - 전체 대상 인원(분모): 이번 달에 체험수업을 받은 회원 + 이번 달에 결제로
 *   전환된 회원을 합친 인원. 같은 회원이 둘 다 해당해도 1명으로만 셈.
 * - 전환된 인원(분자): 그중에서 "체험수업을 먼저 받고 → 그 이후에 결제"한
 *   순서로 이어진 회원 수만 인정. 체험 없이 바로 결제한 회원은 제외됨.
 * - 체험수업은 지난달에 받았어도 상관없고, 결제(전환)가 이번 달에
 *   이루어졌으면 이번 달 실적으로 인정됨.
 * - 계산 기준 월은 "결제(전환)가 일어난 달"입니다.
 *
 * 체험과 전환은 각각 독립적으로 실적이 귀속됩니다 — 체험을 A가 진행했더라도
 * 이후 전환(등록) 상담일지를 B가 작성했다면, 체험은 A의 실적으로, 전환은
 * B의 실적으로 각각 남습니다. 단, **회원 이관이 있었던 경우** "체험 존재 여부"는
 * 같은 담당(귀속 트레이너 기준)일 때만 인정합니다 — 트레이너 일치를 아예 안 따지면,
 * 이관 전 다른 트레이너 시절의 오래된 체험 기록이 이관 후 트레이너가 새로 작성한
 * 등록 건과 엮여서 전환 실적으로 중복 집계되는 문제가 있었습니다(2026-09-17 수정).
 * buildAttributedTrainerIdExpr로 "실제 귀속 트레이너"를 계산해 그 기준으로만
 * 체험→전환 순서를 판정합니다 — 이관이 없던 레코드는 귀속 트레이너가 곧 현재
 * trainer_id라서 기존 동작과 동일하고, 이관이 있었던 레코드만 이관 시점 기준으로
 * 정확히 갈립니다(트레이너 상세는 물론, 히트맵의 체험전환율 계산과 동일한 원리).
 *
 * "체험이 먼저인지"는 consult_at(상담일시)으로 판단하되, 같은 날 몰아서
 * 작성해 consult_at이 완전히 같아지는 경우(입력 단위가 분 단위까지라 흔함)를
 * 대비해 consult_at이 같으면 created_at(저장 시각, ms 단위)으로 순서를 가른다.
 */
export async function fetchTrialConversionMetrics(
  dataSource: DataSource,
  trainerIds: string[],
  startOfMonth: Date,
  nextMonth: Date,
): Promise<TrialConversionMetrics> {
  if (trainerIds.length === 0) {
    return { trialMemberCount: 0, trialConversionCount: 0 };
  }

  const attributedTrainerIdExpr = buildAttributedTrainerIdExpr('cl', 'consult_at');
  const relevantFilter = buildTransferAwareTrainerIdsCondition('cl', 'consult_at');
  const sameOwnerCondition = buildSameOwnerAcrossTransferCondition('t', 'f');

  const attributedLogsCte = `
    WITH attributed_logs AS (
      SELECT
        cl.user_id,
        cl.result_status,
        cl.consult_at,
        cl.created_at,
        ${attributedTrainerIdExpr} AS trainer_id
      FROM consultation_logs cl
      WHERE cl.deleted_at IS NULL
        AND ${relevantFilter}
    )
  `;

  const [trialMemberRow] = await dataSource.query(
    `
      ${attributedLogsCte}
      SELECT COUNT(DISTINCT pool.user_id) AS cnt
      FROM (
        SELECT user_id
        FROM attributed_logs
        WHERE result_status = 'TRIAL'
          AND trainer_id IN (?)
          AND consult_at >= ?
          AND consult_at < ?
        UNION
        SELECT f.user_id
        FROM attributed_logs f
        WHERE f.result_status IN ('REG_NEW', 'REG_RENEW')
          AND f.trainer_id IN (?)
          AND f.consult_at >= ?
          AND f.consult_at < ?
          AND EXISTS (
            SELECT 1
            FROM attributed_logs t
            WHERE t.user_id = f.user_id
              AND t.result_status = 'TRIAL'
              AND (
                t.consult_at < f.consult_at
                OR (t.consult_at = f.consult_at AND t.created_at < f.created_at)
              )
              AND ${sameOwnerCondition}
          )
      ) pool
    `,
    [
      trainerIds,
      trainerIds,
      trainerIds,
      startOfMonth,
      nextMonth,
      trainerIds,
      startOfMonth,
      nextMonth,
    ],
  );

  const [trialConversionRow] = await dataSource.query(
    `
      ${attributedLogsCte}
      SELECT COUNT(DISTINCT f.user_id) AS cnt
      FROM attributed_logs f
      WHERE f.result_status IN ('REG_NEW', 'REG_RENEW')
        AND f.trainer_id IN (?)
        AND f.consult_at >= ?
        AND f.consult_at < ?
        AND EXISTS (
          SELECT 1
          FROM attributed_logs t
          WHERE t.user_id = f.user_id
            AND t.result_status = 'TRIAL'
            AND (
              t.consult_at < f.consult_at
              OR (t.consult_at = f.consult_at AND t.created_at < f.created_at)
            )
            AND ${sameOwnerCondition}
        )
    `,
    [trainerIds, trainerIds, trainerIds, startOfMonth, nextMonth],
  );

  return {
    trialMemberCount: Number(trialMemberRow?.cnt) || 0,
    trialConversionCount: Number(trialConversionRow?.cnt) || 0,
  };
}

export function calcTrialConversionRatePercent(
  trialConversionCount: number,
  trialMemberCount: number,
  decimals: 0 | 1 = 0,
): number {
  if (trialMemberCount <= 0) {
    return 0;
  }

  const rate = (trialConversionCount / trialMemberCount) * 100;
  if (decimals === 1) {
    return Math.round(rate * 10) / 10;
  }

  return Math.round(rate);
}
