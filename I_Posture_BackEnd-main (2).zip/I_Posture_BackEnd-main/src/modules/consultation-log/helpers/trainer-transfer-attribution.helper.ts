import { DataSource } from 'typeorm';

export interface TrainerConsultationStats {
  total: number;
  trial: number;
  regNew: number;
  regRenew: number;
  noSale: number;
}

export interface TrainerMeasurementCounts {
  body: number;
  precision: number;
  motion: number;
  inbody: number;
}

/**
 * 회원 이관 후에도 실적이 실제로 그 일을 수행한 트레이너에게 남도록 하는 조건.
 * - (현재 이 트레이너 소속 AND 이관으로 넘어온 것 중 이관 시점 이전 건이 아님) — 진짜 자기 실적
 * - OR (다른 트레이너에게 넘어갔지만, 이관 시점 이전에 이 트레이너가 만든 기록) — 이관 전 실적 유지
 * 두 조건 다 member_transfer_histories를 참조하며, trainerId 파라미터를 2번 필요로 한다.
 */
function buildTransferAwareCondition(tableAlias: string, dateColumn: string): string {
  return `
    (
      (
        ${tableAlias}.trainer_id = ?
        AND NOT EXISTS (
          SELECT 1 FROM member_transfer_histories mth
          WHERE mth.member_id = ${tableAlias}.user_id
            AND mth.to_trainer_id = ${tableAlias}.trainer_id
            AND ${tableAlias}.${dateColumn} <= mth.transferred_at
        )
      )
      OR EXISTS (
        SELECT 1 FROM member_transfer_histories mth
        WHERE mth.member_id = ${tableAlias}.user_id
          AND mth.from_trainer_id = ?
          AND mth.to_trainer_id = ${tableAlias}.trainer_id
          AND ${tableAlias}.${dateColumn} <= mth.transferred_at
      )
    )
  `;
}

/**
 * 이 레코드가 "실제로 귀속되어야 할 트레이너 ID"를 계산하는 스칼라 서브쿼리 표현식.
 * - 이 회원이 현재 trainer_id로 이관되어 왔고, 그 이관 시점 이전 기록이면 → 이관 전 담당자(from_trainer_id)
 * - 그 외(이관 이력이 없거나, 이관 이후 기록)엔 → 현재 trainer_id 그대로
 *
 * buildTransferAwareCondition/buildTransferAwareTrainerIdsCondition은 "이 레코드가 특정
 * 트레이너(들)의 실적으로 인정되는지"만 필터링할 뿐 GROUP BY 키로 쓸 수 없다 — 여러 트레이너를
 * 한 번에 GROUP BY 하거나(히트맵), "체험→전환처럼 서로 다른 레코드 두 개가 같은 트레이너
 * 소속인지"를 비교해야 할 때(체험전환율)는 이 표현식으로 계산한 값을 직접 비교/그룹핑해야
 * 이관 전후 실적이 섞이지 않는다.
 */
export function buildAttributedTrainerIdExpr(tableAlias: string, dateColumn: string): string {
  return `
    COALESCE(
      (
        SELECT mth.from_trainer_id
        FROM member_transfer_histories mth
        WHERE mth.member_id = ${tableAlias}.user_id
          AND mth.to_trainer_id = ${tableAlias}.trainer_id
          AND ${tableAlias}.${dateColumn} <= mth.transferred_at
        ORDER BY mth.transferred_at ASC
        LIMIT 1
      ),
      ${tableAlias}.trainer_id
    )
  `;
}

/**
 * 체험(TRIAL)→전환(REG_NEW/REG_RENEW) 매칭 시 "같은 담당자인지" 판정 조건.
 * - 이 회원에게 이관 이력이 전혀 없으면: 트레이너가 달라도 인정한다(기존 정책 유지 —
 *   체험을 A가, 전환을 B가 작성해도 전환으로 인정. 이관과 무관하게 원래도 트레이너
 *   일치를 따지지 않던 케이스라 그대로 둬야 한다).
 * - 이관 이력이 있으면: 귀속 트레이너(buildAttributedTrainerIdExpr로 계산한 값)가 같은
 *   경우에만 인정한다 — 안 그러면 이관 전 트레이너 시절의 체험이 이관 후 트레이너가
 *   새로 작성한 등록과 엮여서 중복 집계된다(2026-09-17, Lee 님 리포트로 발견).
 * trialAlias/conversionAlias는 trainer_id 컬럼에 buildAttributedTrainerIdExpr 결과를
 * 담고 있는 두 로우(체험 쪽, 전환 쪽)의 별칭이어야 한다.
 */
export function buildSameOwnerAcrossTransferCondition(trialAlias: string, conversionAlias: string): string {
  return `
    (
      ${trialAlias}.trainer_id = ${conversionAlias}.trainer_id
      OR NOT EXISTS (
        SELECT 1 FROM member_transfer_histories mth
        WHERE mth.member_id = ${conversionAlias}.user_id
      )
    )
  `;
}

/**
 * buildTransferAwareCondition의 여러 트레이너(trainerIds) 버전 — 센터 집계처럼
 * 트레이너 여러 명을 한 번에 대상으로 할 때 사용. trainerIds 배열을 2번 필요로 한다.
 */
export function buildTransferAwareTrainerIdsCondition(tableAlias: string, dateColumn: string): string {
  return `
    (
      (
        ${tableAlias}.trainer_id IN (?)
        AND NOT EXISTS (
          SELECT 1 FROM member_transfer_histories mth
          WHERE mth.member_id = ${tableAlias}.user_id
            AND mth.to_trainer_id = ${tableAlias}.trainer_id
            AND ${tableAlias}.${dateColumn} <= mth.transferred_at
        )
      )
      OR EXISTS (
        SELECT 1 FROM member_transfer_histories mth
        WHERE mth.member_id = ${tableAlias}.user_id
          AND mth.from_trainer_id IN (?)
          AND mth.to_trainer_id = ${tableAlias}.trainer_id
          AND ${tableAlias}.${dateColumn} <= mth.transferred_at
      )
    )
  `;
}

/**
 * 특정 기간의 상담 결과 통계 (신규등록/재등록/체험수업/미등록), 이관 실적 보정 적용.
 */
export async function fetchTrainerConsultationStats(
  dataSource: DataSource,
  trainerId: string,
  from: Date,
  to: Date,
): Promise<TrainerConsultationStats> {
  const condition = buildTransferAwareCondition('cl', 'consult_at');
  const [row] = await dataSource.query(
    `
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN cl.result_status = 'TRIAL' THEN 1 ELSE 0 END) AS trial,
        SUM(CASE WHEN cl.result_status = 'REG_NEW' THEN 1 ELSE 0 END) AS regNew,
        SUM(CASE WHEN cl.result_status = 'REG_RENEW' THEN 1 ELSE 0 END) AS regRenew,
        SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
      FROM consultation_logs cl
      WHERE cl.deleted_at IS NULL
        AND cl.consult_at >= ?
        AND cl.consult_at < ?
        AND ${condition}
    `,
    [from, to, trainerId, trainerId],
  );

  return {
    total: Number(row?.total) || 0,
    trial: Number(row?.trial) || 0,
    regNew: Number(row?.regNew) || 0,
    regRenew: Number(row?.regRenew) || 0,
    noSale: Number(row?.noSale) || 0,
  };
}

/**
 * 최근 N개월 상담 결과 월별 추이, 이관 실적 보정 적용.
 */
export async function fetchTrainerConsultationStatsTrend(
  dataSource: DataSource,
  trainerId: string,
  from: Date,
): Promise<Array<{ month: string } & TrainerConsultationStats>> {
  const condition = buildTransferAwareCondition('cl', 'consult_at');
  const rows = await dataSource.query(
    `
      SELECT
        DATE_FORMAT(cl.consult_at, '%Y-%m') AS month,
        COUNT(*) AS total,
        SUM(CASE WHEN cl.result_status = 'TRIAL' THEN 1 ELSE 0 END) AS trial,
        SUM(CASE WHEN cl.result_status = 'REG_NEW' THEN 1 ELSE 0 END) AS regNew,
        SUM(CASE WHEN cl.result_status = 'REG_RENEW' THEN 1 ELSE 0 END) AS regRenew,
        SUM(CASE WHEN cl.result_status = 'NO_SALE' THEN 1 ELSE 0 END) AS noSale
      FROM consultation_logs cl
      WHERE cl.deleted_at IS NULL
        AND cl.consult_at >= ?
        AND ${condition}
      GROUP BY DATE_FORMAT(cl.consult_at, '%Y-%m')
      ORDER BY month ASC
    `,
    [from, trainerId, trainerId],
  );

  return rows.map((r: Record<string, string>) => ({
    month: r.month,
    total: Number(r.total) || 0,
    trial: Number(r.trial) || 0,
    regNew: Number(r.regNew) || 0,
    regRenew: Number(r.regRenew) || 0,
    noSale: Number(r.noSale) || 0,
  }));
}

/**
 * 누적 측정 건수(체형/정밀/모션/인바디), 이관 실적 보정 적용.
 */
export async function fetchTrainerMeasurementCountsWithTransferCredit(
  dataSource: DataSource,
  trainerId: string,
): Promise<TrainerMeasurementCounts> {
  const bodyCondition = buildTransferAwareCondition('br', 'created_at');
  const precisionCondition = buildTransferAwareCondition('pr', 'created_at');
  const motionCondition = buildTransferAwareCondition('ma', 'created_at');
  const inbodyCondition = buildTransferAwareCondition('idata', 'measured_at');

  const [row] = await dataSource.query(
    `
      SELECT
        (
          SELECT COUNT(*) FROM body_reports br
          WHERE br.deleted_at IS NULL AND ${bodyCondition}
        ) AS body,
        (
          SELECT COUNT(*) FROM precision_reports pr
          WHERE pr.deleted_at IS NULL AND ${precisionCondition}
        ) AS precisionCount,
        (
          SELECT COUNT(*) FROM motion_analyses ma
          WHERE ma.deleted_at IS NULL AND ${motionCondition}
        ) AS motion,
        (
          SELECT COUNT(*) FROM inbody_data idata
          WHERE idata.deleted_at IS NULL AND ${inbodyCondition}
        ) AS inbody
    `,
    [trainerId, trainerId, trainerId, trainerId, trainerId, trainerId, trainerId, trainerId],
  );

  return {
    body: Number(row?.body) || 0,
    precision: Number(row?.precisionCount) || 0,
    motion: Number(row?.motion) || 0,
    inbody: Number(row?.inbody) || 0,
  };
}
