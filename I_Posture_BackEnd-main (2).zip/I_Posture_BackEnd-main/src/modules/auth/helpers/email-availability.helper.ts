import { AccountStatus, MemberType, UserEntity, UserType } from '../../../database/entities/user.entity';

export const WITHDRAWN_ACCOUNT_RECOVERY_MESSAGE =
  '탈퇴한 계정입니다. 해당 이메일로는 재가입이 불가합니다.';

export const EMAIL_ALREADY_IN_USE_MESSAGE = '이미 사용 중인 이메일입니다.';

/**
 * 센터/트레이너(운영 측) 그룹. auth.service.ts의 TRAINER_APP_ACCOUNT_USER_TYPES + CENTER_WEB_ACCOUNT_USER_TYPES와 동일한 묶음.
 * 이메일 유일성은 이 그룹 내부(센터↔트레이너)에서만 강제하고, 회원(MEMBER)과는 서로 겹쳐도 된다 (2026-10-02 정책 변경).
 */
export const STAFF_USER_TYPES: UserType[] = [UserType.CENTER, UserType.C_TRAINER, UserType.F_TRAINER];

export interface EmailAvailabilityResult {
  available: boolean;
  message?: string;
}

export function isActiveUserAccount(user: UserEntity): boolean {
  return !user.deletedAt && user.accountStatus !== AccountStatus.WITHDRAWAL;
}

/**
 * 동일 이메일을 가진 계정 목록으로, targetUserType으로 가입/변경하려는 요청이 사용 가능한지 판단합니다.
 * - 관리회원(MemberType.MANAGED)은 트레이너가 자기 회원 관리용으로 만든 그림자 계정이라
 *   로그인 자체가 불가능함(auth.service.ts의 validateUser도 명시적으로 차단) — 실제 계정이
 *   아니므로 이메일 중복 판정에서 제외한다. 이걸 제외하지 않으면, 트레이너가 먼저 관리회원으로
 *   등록해둔 이메일을 가진 실제 사용자가 USER APP에 영원히 가입할 수 없게 되는 문제가 있었다
 *   (이메일로 앱회원↔관리회원을 연동하는 기획과 정면으로 충돌 — 2026-09-17 수정).
 * - 이메일 유일성은 "센터/트레이너(STAFF_USER_TYPES)" 그룹과 "회원(MEMBER)" 그룹, 두 네임스페이스로 나뉜다.
 *   같은 그룹 내 활성 계정만 중복으로 본다 — 예: 트레이너로 이미 가입된 이메일이어도 회원 가입은 허용 (2026-10-02 정책 변경)
 * - (제외 대상을 뺀 뒤) 같은 그룹의 활성 계정이 하나라도 있으면 사용 불가 (이미 사용 중)
 * - 같은 그룹에 계정이 있지만 전부 탈퇴/삭제 상태면 탈퇴 계정 안내
 */
export function resolveEmailAvailability(
  users: UserEntity[],
  targetUserType: UserType,
  options?: { excludeUserId?: string },
): EmailAvailabilityResult {
  const isTargetStaff = STAFF_USER_TYPES.includes(targetUserType);

  const relevant = users
    .filter((user) => user.memberType !== MemberType.MANAGED)
    .filter((user) => !options?.excludeUserId || user.id !== options.excludeUserId)
    .filter((user) => STAFF_USER_TYPES.includes(user.userType) === isTargetStaff);

  if (relevant.length === 0) {
    return { available: true };
  }

  if (relevant.some(isActiveUserAccount)) {
    return { available: false, message: EMAIL_ALREADY_IN_USE_MESSAGE };
  }

  return { available: false, message: WITHDRAWN_ACCOUNT_RECOVERY_MESSAGE };
}
