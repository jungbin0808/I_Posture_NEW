import { Body, Controller, Post, Req, Res, UseGuards } from "@nestjs/common";
import { Response, Request } from "express";
import { AuthService, TRAINER_APP_ACCOUNT_USER_TYPES } from "./auth.service";
import { FindIdResponseDto, LoginDto, RegisterFreelancerTrainerDto, ResetPasswordDto, SendOtpDto, SocialLoginDto, SocialRegisterDto, TokenResponseDto, VerifyOtpDto, VerifyOtpResponseDto } from "./auth.dto";
import { RefreshTokenGuard } from "./refresh-token.guard";

@Controller("auth")
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post("login")
  async login(@Body() dto: LoginDto, @Res({ passthrough: true }) res: Response) {
    const tokens = await this.authService.login(dto);
    res.cookie("refreshToken", tokens.refreshToken, {httpOnly: true, secure: true, sameSite: "lax", path: "/api/v1/auth",});
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  @Post("social-login")
  async socialLogin(@Body() dto: SocialLoginDto, @Res({ passthrough: true }) res: Response) {
    const tokens = await this.authService.socialLogin(dto);
    res.cookie("refreshToken", tokens.refreshToken, {httpOnly: true, secure: true, sameSite: "lax", path: "/api/v1/auth",});
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  @Post("social-register")
  async socialRegister(@Body() dto: SocialRegisterDto, @Res({ passthrough: true }) res: Response) {
    const tokens = await this.authService.socialRegister(dto);
    res.cookie("refreshToken", tokens.refreshToken, {httpOnly: true, secure: true, sameSite: "lax", path: "/api/v1/auth",});
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  @UseGuards(RefreshTokenGuard)
  @Post("refresh")
  async refresh(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const user = req.user as { userId: string; jti: string; refreshToken: string; iat: number; exp: number; };

    const tokens = await this.authService.refreshTokens(user.userId, user.jti, user.refreshToken, user.iat, user.exp,);
    res.cookie("refreshToken", tokens.refreshToken, {httpOnly: true, secure: true, sameSite: "lax", path: "/api/v1/auth",});

    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
    };
  }

  @UseGuards(RefreshTokenGuard)
  @Post("logout")
  async logout(@Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const user = req.user as {
      userId: string;
      jti: string;
      refreshToken: string;
      iat: number;
      exp: number;
    };
    await this.authService.logout(user.userId, user.jti);

    res.clearCookie("refreshToken", { path: "/api/v1/auth" });

    return { success: true };
  }

  // ── 개인 트레이너 회원가입 ─────────────────────────────────────

  @Post("register/freelancer-trainer")
  async registerFreelancerTrainer(
    @Body() dto: RegisterFreelancerTrainerDto,
    @Res({ passthrough: true }) res: Response,
  ): Promise<Omit<TokenResponseDto, 'refreshToken'>> {
    const tokens = await this.authService.registerFreelancerTrainer(dto);
    res.cookie("refreshToken", tokens.refreshToken, { httpOnly: true, secure: true, sameSite: "lax", path: "/api/v1/auth" });
    return {
      accessToken: tokens.accessToken,
      accessTokenExpiresIn: tokens.accessTokenExpiresIn,
      refreshTokenExpiresIn: tokens.refreshTokenExpiresIn,
      user: tokens.user,
    };
  }

  // ── 이메일 인증 ────────────────────────────────────────────────

  @Post("email/send-otp")
  async sendOtp(@Body() dto: SendOtpDto): Promise<{ success: boolean; code?: string }> {
    const result = await this.authService.sendOtp(dto, {
      allowedUserTypes: TRAINER_APP_ACCOUNT_USER_TYPES,
    });
    return { success: true, ...result };
  }

  @Post("email/verify-otp")
  async verifyOtp(@Body() dto: VerifyOtpDto): Promise<VerifyOtpResponseDto> {
    return this.authService.verifyOtp(dto);
  }

  @Post("find-id")
  async findId(@Body() body: { verifiedToken: string }): Promise<FindIdResponseDto> {
    return this.authService.findIdByVerifiedToken(body.verifiedToken, {
      allowedUserTypes: TRAINER_APP_ACCOUNT_USER_TYPES,
    });
  }

  @Post("reset-password")
  async resetPassword(@Body() dto: ResetPasswordDto): Promise<{ success: boolean }> {
    await this.authService.resetPassword(dto, {
      allowedUserTypes: TRAINER_APP_ACCOUNT_USER_TYPES,
    });
    return { success: true };
  }
}
