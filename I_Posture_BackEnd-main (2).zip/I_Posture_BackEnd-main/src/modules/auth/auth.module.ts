import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { JwtModule } from '@nestjs/jwt';
import { ConfigModule } from '@nestjs/config';
import { UserEntity } from '../../database/entities/user.entity';
import { RefreshTokenEntity } from '../../database/entities/refresh-token.entity';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtAccessStrategy } from './jwt-access.strategy';
import { JwtRefreshStrategy } from './jwt-refresh.strategy';
import { AccessTokenGuard } from './access-token.guard';
import { RefreshTokenGuard } from './refresh-token.guard';
import { SnsAccountEntity } from '../../database/entities/sns-account.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { EmailVerificationEntity } from '../../database/entities/email-verification.entity';
import { EmailModule } from '../email/email.module';
import { TermEntity } from '../../database/entities/term.entity';
import { UserAgreementEntity } from '../../database/entities/user-agreement.entity';

@Module({
  imports: [
    ConfigModule,
    TypeOrmModule.forFeature([
      UserEntity,
      RefreshTokenEntity,
      SnsAccountEntity,
      CenterEntity,
      CenterTrainerEntity,
      EmailVerificationEntity,
      TermEntity,
      UserAgreementEntity,
    ]),
    JwtModule.register({}),
    EmailModule,
  ],
  controllers: [AuthController],
  providers: [AuthService, JwtAccessStrategy, JwtRefreshStrategy, AccessTokenGuard, RefreshTokenGuard],
  exports: [AccessTokenGuard, AuthService],
})
export class AuthModule {}
