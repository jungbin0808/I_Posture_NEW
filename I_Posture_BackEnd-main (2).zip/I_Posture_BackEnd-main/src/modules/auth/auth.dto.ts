import { ArrayNotEmpty, IsArray, IsEmail, IsEnum, IsNumber, IsOptional, IsString, Length, MinLength } from 'class-validator';
import { CenterEntity } from '../../database/entities/center.entity';
import { SnsProvider } from '../../database/entities/sns-account.entity';
import { Gender, UserType } from '../../database/entities/user.entity';
import { EmailVerificationPurpose } from '../../database/entities/email-verification.entity';
import { TermType } from '../../database/entities/term.entity';

export class LoginDto {
  @IsString()
  userId!: string;

  @IsString()
  @MinLength(4)
  password!: string;

  @IsOptional()
  @IsString()
  fcmToken?: string;
}

export class TokenResponseDto {
  accessToken!: string;
  refreshToken!: string;
  accessTokenExpiresIn!: number;
  refreshTokenExpiresIn!: number;
  user!: {
    id: string;
    userId: string;
    email: string;
    name: string;
    userType: UserType;
    affiliationName?: string;
    createdAt: Date;
    updatedAt: Date;
    center?: CenterEntity;
  };
}

export class RefreshTokenResponseDto {
  accessToken!: string;
  refreshToken!: string;
  accessTokenExpiresIn!: number;
  refreshTokenExpiresIn!: number;
}

export class SocialLoginDto {
  @IsEnum(SnsProvider)
  provider!: SnsProvider;

  @IsString()
  providerUserId!: string;

  @IsOptional()
  @IsEmail()
  email?: string;

  @IsOptional()
  @IsString()
  name?: string;

  @IsOptional()
  @IsString()
  snsEmail?: string;

  @IsOptional()
  @IsString()
  accessToken?: string;

  @IsOptional()
  @IsString()
  refreshToken?: string;

  @IsOptional()
  @IsString()
  fcmToken?: string;
}

export class SocialRegisterDto {
  @IsEnum(SnsProvider)
  provider!: SnsProvider;

  @IsString()
  providerUserId!: string;

  @IsEmail()
  email!: string;

  @IsString()
  @Length(1, 50)
  name!: string;

  @IsOptional()
  @IsString()
  @Length(1, 65)
  phone?: string;

  @IsOptional()
  @IsString()
  birthDate?: string;

  @IsOptional()
  @IsEnum(Gender)
  gender?: Gender;

  @IsOptional()
  @IsNumber()
  height?: number;

  @IsOptional()
  @IsNumber()
  weight?: number;

  @IsArray()
  @ArrayNotEmpty()
  @IsEnum(TermType, { each: true })
  agreedTermTypes!: TermType[];

  @IsOptional()
  @IsString()
  accessToken?: string;

  @IsOptional()
  @IsString()
  refreshToken?: string;
}

// ── 이메일 인증 ────────────────────────────────────────────────

export class SendOtpDto {
  @IsEmail()
  email!: string;

  @IsEnum(EmailVerificationPurpose)
  purpose!: EmailVerificationPurpose;
}

export class VerifyOtpDto {
  @IsEmail()
  email!: string;

  @IsEnum(EmailVerificationPurpose)
  purpose!: EmailVerificationPurpose;

  @IsString()
  @Length(6, 6)
  code!: string;
}

export class VerifyOtpResponseDto {
  /** 다음 단계 진행을 위한 단기 토큰 (10분 유효) */
  verifiedToken!: string;
}

// ── 아이디 찾기 응답 ────────────────────────────────────────────

export class FindIdResponseDto {
  userId!: string;
}

// ── 개인 트레이너 회원가입 ────────────────────────────────────────

export class RegisterFreelancerTrainerDto {
  /** 로그인 아이디 */
  @IsString()
  @Length(4, 50)
  userId!: string;

  /** 실명 */
  @IsString()
  @Length(1, 50)
  name!: string;

  /** 센터명 (수동 입력) */
  @IsString()
  @Length(1, 100)
  affiliationName!: string;

  /** 비밀번호 */
  @IsString()
  @MinLength(4)
  password!: string;

  /** 핸드폰 번호 */
  @IsString()
  @Length(1, 65)
  phone!: string;

  /** 이메일 (이메일 인증에서 사용한 이메일과 일치해야 함) */
  @IsEmail()
  email!: string;

  /** send-otp(REGISTER) → verify-otp 로 받은 verifiedToken */
  @IsString()
  verifiedToken!: string;
}

// ── 비밀번호 재설정 ─────────────────────────────────────────────

export class ResetPasswordDto {
  /** verifyOtp 응답으로 받은 verifiedToken */
  @IsString()
  verifiedToken!: string;

  @IsString()
  @MinLength(4)
  newPassword!: string;
}
