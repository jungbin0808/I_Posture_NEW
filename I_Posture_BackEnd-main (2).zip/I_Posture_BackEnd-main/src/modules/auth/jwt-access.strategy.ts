import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { AuthService } from './auth.service';
import { UserEntity } from '../../database/entities/user.entity';

export interface AccessTokenPayload {
  sub: string;
  parent_jti: string;
  iat: number;
  exp: number;
}

@Injectable()
export class JwtAccessStrategy extends PassportStrategy(Strategy, 'jwt-access') {
  constructor(
    configService: ConfigService,
    private readonly authService: AuthService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
    });
  }

  async validate(payload: AccessTokenPayload): Promise<UserEntity> {
    const user = await this.authService.findUserById(payload.sub);
    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    // parent_jti에 해당하는 refresh 토큰이 활성화되어 있는지 확인
    // (로그아웃 또는 새로운 로그인으로 무효화된 경우 access 토큰을 거부하기 위함)
    const parentJti = payload.parent_jti;
    const isActive = await this.authService.isRefreshJtiActive(payload.sub, parentJti);
    if (!isActive) {
      throw new UnauthorizedException('Access token revoked or session expired');
    }

    await this.authService.validateActiveCenterTrainerSession(user);

    // request.user 로 들어감
    return user;
  }
}
