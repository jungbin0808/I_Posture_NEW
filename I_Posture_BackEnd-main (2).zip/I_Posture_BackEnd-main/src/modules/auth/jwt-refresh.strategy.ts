import { Injectable, UnauthorizedException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { Request } from "express";

export interface RefreshTokenPayload {
  sub: string;
  jti: string;
  iat: number;
  exp: number;
}

@Injectable()
export class JwtRefreshStrategy extends PassportStrategy(Strategy, "jwt-refresh") {
  constructor(configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromExtractors([
        (req: Request) => {
          // 1순위: 쿠키
          const fromCookie = req.cookies?.refreshToken;
          if (fromCookie) return fromCookie;
          // 2순위: Authorization 헤더(옵션)
          const auth = req.headers.authorization;
          if (auth?.startsWith("Bearer ")) return auth.split(" ")[1];
          return null;
        },
      ]),
      ignoreExpiration: false,
      secretOrKey: configService.getOrThrow<string>("JWT_REFRESH_TOKEN_SECRET"),
      passReqToCallback: true,
    });
  }

  validate(req: Request, payload: RefreshTokenPayload) {
    const token = req.cookies?.refreshToken;
    if (!token) {
      throw new UnauthorizedException("Refresh token not found");
    }

    return {
      userId: payload.sub,
      jti: payload.jti,
      refreshToken: token,
      iat: payload.iat,
      exp: payload.exp,
    };
  }
}
