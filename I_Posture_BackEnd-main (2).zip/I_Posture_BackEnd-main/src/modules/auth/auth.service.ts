import { Injectable, UnauthorizedException, NotFoundException, BadRequestException, ConflictException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, In, QueryFailedError, Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import { randomUUID } from 'crypto';
import { UserEntity, UserType, MemberType, AccountStatus, PaymentStatus, Gender } from '../../database/entities/user.entity';
import { RefreshTokenEntity } from '../../database/entities/refresh-token.entity';
import { LoginDto, RefreshTokenResponseDto, RegisterFreelancerTrainerDto, ResetPasswordDto, SendOtpDto, SocialLoginDto, SocialRegisterDto, TokenResponseDto, VerifyOtpDto, VerifyOtpResponseDto } from './auth.dto';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../database/entities/center-trainer.entity';
import { SnsAccountEntity } from '../../database/entities/sns-account.entity';
import { Transactional } from 'typeorm-transactional';
import { EmailVerificationEntity, EmailVerificationPurpose } from '../../database/entities/email-verification.entity';
import { EmailService } from '../email/email.service';
import { ALL_NOTIFICATIONS_ON } from '../user/helpers/notification-settings.helper';
import {
  EMAIL_ALREADY_IN_USE_MESSAGE,
  resolveEmailAvailability,
  WITHDRAWN_ACCOUNT_RECOVERY_MESSAGE,
} from './helpers/email-availability.helper';
import { TermEntity, TermType } from '../../database/entities/term.entity';
import { UserAgreementEntity } from '../../database/entities/user-agreement.entity';

/** 트레이너 앱 (/auth) — 개인·센터 소속 트레이너 */
export const TRAINER_APP_ACCOUNT_USER_TYPES: UserType[] = [UserType.F_TRAINER, UserType.C_TRAINER];

/** 센터 웹 (/center/auth) — 센터 오너 */
export const CENTER_WEB_ACCOUNT_USER_TYPES: UserType[] = [UserType.CENTER];

export interface AccountRecoveryOptions {
  allowedUserTypes: UserType[];
}

export interface EmailRegistrationAvailabilityResult {
  available: boolean;
  message?: string;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private accessTokenExpSeconds: number;
  private refreshTokenExpSeconds: number;

  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(RefreshTokenEntity)
    private readonly refreshTokenRepo: Repository<RefreshTokenEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(SnsAccountEntity)
    private readonly snsAccountRepo: Repository<SnsAccountEntity>,
    @InjectRepository(EmailVerificationEntity)
    private readonly emailVerificationRepo: Repository<EmailVerificationEntity>,
    @InjectRepository(TermEntity)
    private readonly termRepo: Repository<TermEntity>,
    @InjectRepository(UserAgreementEntity)
    private readonly userAgreementRepo: Repository<UserAgreementEntity>,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
    private readonly dataSource: DataSource,
    private readonly emailService: EmailService,
  ) {
    this.accessTokenExpSeconds = Number(this.configService.get<string>('JWT_ACCESS_TOKEN_EXPIRES_IN')) || 2 * 60 * 60;
    this.refreshTokenExpSeconds = Number(this.configService.get<string>('JWT_REFRESH_TOKEN_EXPIRES_IN')) || 180 * 24 * 60 * 60;
  }

  async findUserById(id: string): Promise<UserEntity | null> {
    return this.userRepo.findOne({ where: { id: id } });
  }

  async assertLoginIdAvailable(userId: string): Promise<void> {
    const existing = await this.userRepo.findOne({
      where: { userId },
      withDeleted: true,
    });
    if (existing) {
      throw new ConflictException('이미 사용 중인 아이디입니다.');
    }
  }

  async assertEmailAvailableForRegistration(email: string, targetUserType: UserType): Promise<void> {
    const availability = await this.checkEmailRegistrationAvailability(email, targetUserType);
    if (!availability.available) {
      throw new ConflictException(availability.message ?? EMAIL_ALREADY_IN_USE_MESSAGE);
    }
  }

  async assertEmailAvailableForChange(email: string, excludeUserId: string, targetUserType: UserType): Promise<void> {
    const availability = await this.checkEmailChangeAvailability(email, excludeUserId, targetUserType);
    if (!availability.available) {
      throw new ConflictException(availability.message ?? EMAIL_ALREADY_IN_USE_MESSAGE);
    }
  }

  async checkEmailRegistrationAvailability(
    email: string,
    targetUserType: UserType,
  ): Promise<EmailRegistrationAvailabilityResult> {
    const users = await this.userRepo.find({
      where: { email },
      withDeleted: true,
    });
    return resolveEmailAvailability(users, targetUserType);
  }

  async checkEmailChangeAvailability(
    email: string,
    excludeUserId: string,
    targetUserType: UserType,
  ): Promise<EmailRegistrationAvailabilityResult> {
    const users = await this.userRepo.find({
      where: { email },
      withDeleted: true,
    });
    return resolveEmailAvailability(users, targetUserType, { excludeUserId });
  }

  assertNoDuplicateUserEntry(error: unknown): void {
    if (error instanceof QueryFailedError && (error.driverError as { code?: string })?.code === 'ER_DUP_ENTRY') {
      throw new ConflictException('이미 사용 중인 아이디입니다.');
    }
  }

  async validateUser(
    userId: string,
    password: string,
    options?: { allowEmailLogin?: boolean },
  ): Promise<UserEntity> {
    let user = await this.userRepo.findOne({ where: { userId } });
    if (!user && options?.allowEmailLogin) {
      user = await this.userRepo.findOne({ where: { email: userId } });
    }
    if (!user || !user.password) {
      throw new UnauthorizedException('Invalid credentials');
    }
    if (user.memberType === MemberType.MANAGED) {
      throw new UnauthorizedException('Invalid credentials');
    }
    const ok = await bcrypt.compare(password.toLowerCase(), user.password);
    if (!ok) {
      throw new UnauthorizedException('Invalid credentials');
    }

    if (user.userType === UserType.C_TRAINER) {
      await this.assertCenterTrainerCanLogin(user.id);
    }

    return user;
  }

  async validateActiveCenterTrainerSession(user: UserEntity): Promise<void> {
    if (user.userType !== UserType.C_TRAINER) {
      return;
    }

    await this.assertCenterTrainerCanLogin(user.id);
  }

  private async assertCenterTrainerCanLogin(trainerId: string): Promise<void> {
    const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId } });

    if (!affiliation) {
      throw new UnauthorizedException('센터 소속이 해제된 계정입니다.');
    }

    if (affiliation.status === CenterTrainerStatus.RESIGNED) {
      throw new UnauthorizedException('삭제(퇴사)된 계정입니다.');
    }

    if (affiliation.deactivatedAt) {
      throw new UnauthorizedException('비활성화된 계정입니다.');
    }
  }

  async login(dto: LoginDto): Promise<TokenResponseDto> {
    const user = await this.validateUser(dto.userId, dto.password);
    if (dto.fcmToken) {
      await this.userRepo.update({ id: user.id }, { fcmToken: dto.fcmToken });
    }
    return this.generateTokens(user);
  }

  async socialLogin(dto: SocialLoginDto): Promise<TokenResponseDto> {
    this.logger.log(`Starting socialLogin for provider: ${dto.provider}, providerUserId: ${dto.providerUserId}`);
    try {
      // 1. SNS 계정 존재 여부 확인
      // relations: ['user'] 제거하고 userId로 따로 조회 시도
      let snsAccount = await this.snsAccountRepo.findOne({
        where: { provider: dto.provider, providerUserId: dto.providerUserId },
      });

      if (snsAccount) {
        this.logger.log(`SNS account found. userId: ${snsAccount.userId}`);
        
        // User 조회
        const user = await this.userRepo.findOne({ where: { id: snsAccount.userId } });
        if (!user) {
            this.logger.error(`User not found for snsAccount: ${snsAccount.id}`);
            throw new NotFoundException('User not found');
        }

        // 토큰 업데이트 (있는 경우에만)
        if (dto.accessToken || dto.refreshToken) {
          snsAccount.accessToken = dto.accessToken || snsAccount.accessToken;
          snsAccount.refreshToken = dto.refreshToken || snsAccount.refreshToken;
          await this.snsAccountRepo.save(snsAccount);
        }
        if (dto.fcmToken) {
          await this.userRepo.update({ id: user.id }, { fcmToken: dto.fcmToken });
        }
        return this.generateTokens(user);
      } else {
        this.logger.warn('SNS account not found. User not registered.');
        // 연동된 계정이 없는 경우 -> 무조건 회원가입 필요
        throw new UnauthorizedException('User not registered');
      }
    } catch (err) {
      this.logger.error(`Error during socialLogin: ${err}`);
      throw err;
    }
  }

  @Transactional()
  async socialRegister(dto: SocialRegisterDto): Promise<TokenResponseDto> {
    this.logger.log(`Starting socialRegister for email: ${dto.email}`);

    this.logger.log('Checking for existing user...');
    await this.assertEmailAvailableForRegistration(dto.email, UserType.MEMBER);

    // 1-1. 필수 약관 전체 동의 여부 서버 검증 (클라이언트 값만 믿지 않음)
    const activeTerms = await this.termRepo.find({ where: { isActive: true } });
    const missingRequired = activeTerms
      .filter((term) => term.isRequired && !dto.agreedTermTypes.includes(term.type))
      .map((term) => term.type);
    if (missingRequired.length > 0) {
      throw new BadRequestException(`필수 약관에 동의해야 합니다: ${missingRequired.join(', ')}`);
    }

    // 2. 회원 생성 (users 테이블)
    // MEMBER는 로그인 아이디 개념이 없고(소셜로그인 전용) user_id는 unique 제약 충족용 내부 식별값일 뿐이라
    // email을 그대로 쓰면 안 됨 — 이메일 변경 시 user_id가 갱신 안 돼 "유령 user_id"로 남아 다음 가입자와 충돌하는 버그가 있었음.
    // provider+providerUserId는 변하지 않는 값이라 이 문제가 생기지 않음.
    this.logger.log('Creating new user entity...');
    const newUser = this.userRepo.create({
      userId: `${dto.provider}_${dto.providerUserId}`,
      email: dto.email,
      password: undefined, // 비밀번호 없음
      name: dto.name,
      phone: dto.phone,
      birthDate: dto.birthDate,
      gender: dto.gender || Gender.NONE,
      height: dto.height,
      weight: dto.weight,
      memberType: MemberType.APP, // 앱 회원
      userType: UserType.MEMBER, // 일반 회원 권한
      accountStatus: AccountStatus.ACTIVE,
      paymentStatus: PaymentStatus.UNPAID,
      ...ALL_NOTIFICATIONS_ON,
      // 마케팅성 알림은 약관 동의 화면에서 실제로 동의한 경우에만 ON - 나머지(서비스 이용 알림)와 달리
      // 무조건 켜면 안 됨(정보통신망법상 마케팅 수신은 별도의 명시적 동의가 필요)
      notificationEventMarketing: dto.agreedTermTypes.includes(TermType.MARKETING),
    });
    this.logger.log('Saving new user...');
    let savedUser: UserEntity;
    try {
      savedUser = await this.userRepo.save(newUser);
    } catch (err) {
      if (err instanceof QueryFailedError && (err as any).code === 'ER_DUP_ENTRY') {
        throw new ConflictException('이미 가입된 계정입니다.');
      }
      throw err;
    }
    this.logger.log(`User saved: ${savedUser.id}`);

    // 3. SNS 계정 생성 (sns_accounts 테이블)
    // snsEmail은 별도로 받지 않고, 회원가입 시 사용된 email(소셜 이메일)을 그대로 사용
    this.logger.log('Creating SNS account entity...');
    const newSnsAccount = this.snsAccountRepo.create({
      user: savedUser, // 관계 객체 할당
      provider: dto.provider,
      providerUserId: dto.providerUserId,
      snsEmail: dto.email, // snsEmail 대신 email 사용
      accessToken: dto.accessToken,
      refreshToken: dto.refreshToken,
    });
    this.logger.log('Saving SNS account...');
    await this.snsAccountRepo.save(newSnsAccount);
    this.logger.log('SNS account saved.');

    // 3-1. 약관 동의 이력 저장 (동의한 타입별로 현재 활성 버전 연결)
    const agreedTerms = activeTerms.filter((term) => dto.agreedTermTypes.includes(term.type));
    if (agreedTerms.length > 0) {
      await this.userAgreementRepo.save(
        agreedTerms.map((term) =>
          this.userAgreementRepo.create({ user: savedUser, term }),
        ),
      );
    }

    this.logger.log('Transaction committed.');
    
    // 4. 토큰 발급 및 로그인 처리
    return this.generateTokens(savedUser);
  }

  private async generateTokens(user: UserEntity): Promise<TokenResponseDto> {
    const jti = randomUUID();
    const now = Math.floor(Date.now() / 1000);
    const refreshExp = now + this.refreshTokenExpSeconds;

    const refreshPayload = { sub: user.id, jti: jti };
    const accessPayload = { sub: user.id, parent_jti: jti };

    const accessToken = await this.jwtService.signAsync(accessPayload, {
      secret: this.configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
      expiresIn: this.accessTokenExpSeconds,
    });

    const refreshToken = await this.jwtService.signAsync(refreshPayload, {
      secret: this.configService.getOrThrow<string>('JWT_REFRESH_TOKEN_SECRET'),
      expiresIn: this.refreshTokenExpSeconds,
    });

    // **변경 시작**: 멀티 로그인 차단 정책 적용 범위
    // - 정책: '마지막 로그인한 기기만 로그인 가능'하도록 함
    // - 적용 대상: 개인 트레이너(F_TRAINER) 및 일반 회원(MEMBER) 중 소셜(SNS) 가입자(비밀번호가 없는 계정)
    // - 제외 대상: ADMIN, CENTER, 그리고 비밀번호 기반 가입자(아이디+비밀번호 로그인) 및 센터 트레이너는 멀티 로그인 허용
    try {
      // 개인 트레이너(F_TRAINER)와 일반 회원(MEMBER)은 소셜 구현 여부와 관계없이
      // 멀티로그인을 허용하지 않으므로 기존 활성 refresh 토큰을 모두 무효화합니다.
      if (user.userType === UserType.F_TRAINER || user.userType === UserType.MEMBER) {
        await this.refreshTokenRepo.update({ userId: user.id, revoked: false }, { revoked: true });
      }
    } catch (e) {
      this.logger.warn(`Failed to revoke existing refresh tokens for user ${user.id}: ${e}`);
      // 실패해도 새 토큰 발급은 진행합니다.
    }
    // **변경 끝**

    const entity = this.refreshTokenRepo.create({
      userId: user.id,
      jti: jti,
      token: refreshToken,
      expiresAt: new Date(refreshExp * 1000),
    });
    await this.refreshTokenRepo.save(entity);

    const responseUser: TokenResponseDto['user'] = {
      id: user.id,
      // MEMBER는 소셜로그인 전용이라 로그인 아이디 개념이 없고, user_id 컬럼은 unique 제약 충족용 내부 식별값일 뿐이라 화면에 노출하면 안 됨
      userId: user.userType === UserType.MEMBER ? user.email : user.userId,
      email: user.email,
      name: user.name,
      userType: user.userType,
      affiliationName: user.affiliationName,
      createdAt: user.createdAt,
      updatedAt: user.updatedAt,
    };

    if (user.userType === UserType.CENTER) {
      // 센터 정보는 DB 스키마와 불일치 가능성이 있으므로 필요한 컬럼만 선택
      const center = await this.centerRepo.findOne({
        where: { ownerId: user.id },
        select: ['id', 'ownerId', 'name', 'address'],
      });
      if (center) responseUser.center = center;
    } else if (user.userType === UserType.C_TRAINER) {
      // 트레이너의 소속 센터를 안전하게 조회: affiliation에서 centerId만 가져온 뒤 center를 선택 조회
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id }, select: ['centerId'] });
      if (affiliation && affiliation.centerId) {
        const center = await this.centerRepo.findOne({
          where: { id: affiliation.centerId },
          select: ['id', 'ownerId', 'name', 'address'],
        });
        if (center) responseUser.center = center;
      }
    }

    return {
      accessToken: accessToken,
      refreshToken: refreshToken,
      accessTokenExpiresIn: this.accessTokenExpSeconds,
      refreshTokenExpiresIn: this.refreshTokenExpSeconds,
      user: responseUser,
    };
  }

  async refreshTokens(userId: string, jti: string, token: string, iat: number, exp: number): Promise<RefreshTokenResponseDto> {
    const record = await this.refreshTokenRepo.findOne({ where: { userId: userId, jti: jti, revoked: false } });
    if (!record || record.token !== token) {
      throw new UnauthorizedException('Invalid refresh token');
    }

    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    await this.validateActiveCenterTrainerSession(user);

    const now = Math.floor(Date.now() / 1000);
    if (now >= exp) {
      throw new UnauthorizedException('Refresh token expired');
    }

    const lifetime = exp - iat;
    const elapsed = now - iat;
    const halfLife = lifetime / 2;

    let newJti = jti;
    let newRefreshToken = token;
    let newRefreshExp = exp;

    if (elapsed >= halfLife) {
      newJti = randomUUID();
      newRefreshExp = now + this.refreshTokenExpSeconds;
      const refreshPayload = { sub: userId, jti: newJti };
      newRefreshToken = await this.jwtService.signAsync(refreshPayload, {
        secret: this.configService.getOrThrow<string>('JWT_REFRESH_TOKEN_SECRET'),
        expiresIn: this.refreshTokenExpSeconds,
      });
      record.jti = newJti;
      record.token = newRefreshToken;
      record.expiresAt = new Date(newRefreshExp * 1000);
      await this.refreshTokenRepo.save(record);
    }

    const accessPayload = { sub: userId, parent_jti: newJti };
    const newAccessToken = await this.jwtService.signAsync(accessPayload, {
      secret: this.configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
      expiresIn: this.accessTokenExpSeconds,
    });

    return {
      accessToken: newAccessToken,
      refreshToken: newRefreshToken,
      accessTokenExpiresIn: this.accessTokenExpSeconds,
      refreshTokenExpiresIn: newRefreshExp - now,
    };
  }

  async logout(userId: string, jti: string) {
    await this.refreshTokenRepo.update({ userId: userId, jti: jti }, { revoked: true });
    return { success: true };
  }

  /** 센터 웹 등 외부 모듈에서 자격 증명 검증 시 사용 (기존 login 로직 재사용) */
  async validateCredentials(
    userId: string,
    password: string,
    options?: { allowEmailLogin?: boolean },
  ): Promise<UserEntity> {
    return this.validateUser(userId, password, options);
  }

  /** 센터 웹 등 외부 모듈에서 토큰 발급 시 사용 */
  async issueAuthTokens(user: UserEntity): Promise<TokenResponseDto> {
    return this.generateTokens(user);
  }

  /** 이메일 인증 verifiedToken 1회성 소비 (센터 회원가입 등) */
  async consumeVerifiedEmailToken(
    verifiedToken: string,
    expectedPurpose: EmailVerificationPurpose,
  ): Promise<{ verificationId: string; email: string; purpose: EmailVerificationPurpose }> {
    return this.decodeVerifiedToken(verifiedToken, expectedPurpose);
  }

  /** verifiedToken 검증만 수행 (레코드 삭제 없음) */
  async peekVerifiedEmailToken(
    verifiedToken: string,
    expectedPurpose: EmailVerificationPurpose,
  ): Promise<{ email: string }> {
    let payload: { verificationId: string; email: string; purpose: EmailVerificationPurpose };
    try {
      payload = await this.jwtService.verifyAsync(verifiedToken, {
        secret: this.configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
      });
    } catch {
      throw new UnauthorizedException('인증 토큰이 유효하지 않거나 만료되었습니다.');
    }

    if (payload.purpose !== expectedPurpose) {
      throw new BadRequestException('잘못된 인증 목적입니다.');
    }

    const record = await this.emailVerificationRepo.findOne({
      where: { id: payload.verificationId, isVerified: true },
    });
    if (!record) {
      throw new UnauthorizedException('이메일 인증이 완료되지 않았거나 이미 사용된 토큰입니다.');
    }

    return { email: payload.email };
  }

  // 새 메서드: 주어진 userId와 jti(parent_jti)가 활성화(리프레시 토큰 레코드가 존재하고 revoked=false)되어 있는지 확인합니다.
  async isRefreshJtiActive(userId: string, jti: string): Promise<boolean> {
    if (!userId || !jti) return false;
    try {
      const record = await this.refreshTokenRepo.findOne({ where: { userId: userId, jti: jti, revoked: false } });
      return !!record;
    } catch (e) {
      this.logger.warn(`Failed to check refresh jti active status for user ${userId}, jti ${jti}: ${e}`);
      return false;
    }
  }

  // ── 이메일 OTP ──────────────────────────────────────────────────

  private generateOtpCode(): string {
    return String(Math.floor(100000 + Math.random() * 900000));
  }

  async sendOtp(dto: SendOtpDto, options?: AccountRecoveryOptions): Promise<{ code?: string }> {
    const OTP_RESEND_COOLDOWN_SEC = 60;
    const OTP_EXPIRES_MIN = 5;

    // 60초 이내 재발송 방지
    const recent = await this.emailVerificationRepo.findOne({
      where: { email: dto.email, purpose: dto.purpose, isVerified: false },
      order: { createdAt: 'DESC' },
    });
    if (recent) {
      const secondsElapsed = (Date.now() - recent.createdAt.getTime()) / 1000;
      if (secondsElapsed < OTP_RESEND_COOLDOWN_SEC) {
        throw new BadRequestException(`${Math.ceil(OTP_RESEND_COOLDOWN_SEC - secondsElapsed)}초 후에 재발송할 수 있습니다.`);
      }
    }

    // 아이디/비밀번호 찾기: 이메일 + 허용 userType으로 계정 존재 확인
    if (dto.purpose === EmailVerificationPurpose.FIND_ID || dto.purpose === EmailVerificationPurpose.FIND_PASSWORD) {
      if (!options?.allowedUserTypes?.length) {
        throw new BadRequestException('계정 유형이 지정되지 않았습니다.');
      }
      await this.resolveUserForAccountRecovery(dto.email, options.allowedUserTypes);
    }

    if (dto.purpose === EmailVerificationPurpose.REGISTER) {
      const targetUserType = options?.allowedUserTypes?.[0] ?? UserType.MEMBER;
      await this.assertEmailAvailableForRegistration(dto.email, targetUserType);
    }

    const code = this.generateOtpCode();
    const expiresAt = new Date(Date.now() + OTP_EXPIRES_MIN * 60 * 1000);

    const verification = this.emailVerificationRepo.create({
      email: dto.email,
      purpose: dto.purpose,
      code,
      expiresAt,
      isVerified: false,
      attempts: 0,
    });
    await this.emailVerificationRepo.save(verification);

    await this.emailService.sendVerificationCode(dto.email, code, dto.purpose);

    // TODO: 임시 — 회원가입 테스트용 인증번호 응답 포함 (운영 배포 전 제거)
    if (dto.purpose === EmailVerificationPurpose.REGISTER) {
      return { code };
    }

    return {};
  }

  async verifyOtp(dto: VerifyOtpDto): Promise<VerifyOtpResponseDto> {
    const MAX_ATTEMPTS = 5;
    const VERIFIED_TOKEN_EXPIRES_SEC = 10 * 60; // 10분

    const verification = await this.emailVerificationRepo.findOne({
      where: { email: dto.email, purpose: dto.purpose, isVerified: false },
      order: { createdAt: 'DESC' },
    });

    if (!verification) {
      throw new BadRequestException('인증 코드를 먼저 발송해 주세요.');
    }

    if (new Date() > verification.expiresAt) {
      throw new BadRequestException('인증 코드가 만료되었습니다. 다시 발송해 주세요.');
    }

    if (verification.attempts >= MAX_ATTEMPTS) {
      throw new BadRequestException('인증 시도 횟수를 초과하였습니다. 다시 발송해 주세요.');
    }

    verification.attempts += 1;

    if (verification.code !== dto.code) {
      await this.emailVerificationRepo.save(verification);
      const remaining = MAX_ATTEMPTS - verification.attempts;
      throw new BadRequestException(`인증 코드가 올바르지 않습니다. (남은 시도: ${remaining}회)`);
    }

    verification.isVerified = true;
    verification.verifiedAt = new Date();
    await this.emailVerificationRepo.save(verification);

    const verifiedToken = await this.jwtService.signAsync(
      { verificationId: verification.id, email: dto.email, purpose: dto.purpose },
      {
        secret: this.configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
        expiresIn: VERIFIED_TOKEN_EXPIRES_SEC,
      },
    );

    return { verifiedToken };
  }

  @Transactional()
  async registerFreelancerTrainer(dto: RegisterFreelancerTrainerDto): Promise<TokenResponseDto> {
    // 1. verifiedToken 검증 (purpose: REGISTER, 레코드 삭제로 재사용 방지)
    const payload = await this.decodeVerifiedToken(dto.verifiedToken, EmailVerificationPurpose.REGISTER);

    // 2. 토큰의 이메일과 요청 이메일 일치 확인
    if (payload.email !== dto.email) {
      throw new BadRequestException('이메일 인증 정보와 입력한 이메일이 일치하지 않습니다.');
    }

    // 3. 아이디/이메일 중복 확인 (탈퇴 계정 포함)
    await this.assertLoginIdAvailable(dto.userId);
    await this.assertEmailAvailableForRegistration(dto.email, UserType.F_TRAINER);

    // 4. 비밀번호 해시 (대소문자 구분 없이 처리)
    const hashed = await bcrypt.hash(dto.password.toLowerCase(), 10);

    // 5. 유저 생성
    const newUser = this.userRepo.create({
      userId: dto.userId,
      email: dto.email,
      password: hashed,
      name: dto.name,
      phone: dto.phone,
      affiliationName: dto.affiliationName,
      userType: UserType.F_TRAINER,
      memberType: MemberType.APP,
      accountStatus: AccountStatus.ACTIVE,
      paymentStatus: PaymentStatus.UNPAID,
      ...ALL_NOTIFICATIONS_ON,
    });
    let savedUser: UserEntity;
    try {
      savedUser = await this.userRepo.save(newUser);
    } catch (error) {
      this.assertNoDuplicateUserEntry(error);
      throw error;
    }

    // 6. 토큰 발급 (가입 즉시 로그인)
    return this.generateTokens(savedUser);
  }

  async findIdByVerifiedToken(
    verifiedToken: string,
    options: AccountRecoveryOptions,
  ): Promise<{ userId: string }> {
    const payload = await this.decodeVerifiedToken(verifiedToken, EmailVerificationPurpose.FIND_ID);

    const user = await this.resolveUserForAccountRecovery(payload.email, options.allowedUserTypes);

    return { userId: user.userId };
  }

  async resetPassword(dto: ResetPasswordDto, options: AccountRecoveryOptions): Promise<void> {
    const payload = await this.decodeVerifiedToken(dto.verifiedToken, EmailVerificationPurpose.FIND_PASSWORD);

    const user = await this.resolveUserForAccountRecovery(payload.email, options.allowedUserTypes);

    const hashed = await bcrypt.hash(dto.newPassword.toLowerCase(), 10);
    await this.userRepo.update({ id: user.id }, { password: hashed });

    // 기존 리프레시 토큰 전체 무효화 (비밀번호 변경 후 재로그인 강제)
    await this.refreshTokenRepo.update({ userId: user.id, revoked: false }, { revoked: true });
  }

  private async resolveUserForAccountRecovery(
    email: string,
    userTypes: UserType[],
  ): Promise<UserEntity> {
    const user = await this.userRepo.findOne({
      where: { email, userType: In(userTypes) },
      withDeleted: true,
      order: { createdAt: 'ASC' },
    });

    if (!user) {
      throw new NotFoundException('해당 이메일로 가입된 계정이 없습니다.');
    }

    if (user.deletedAt || user.accountStatus === AccountStatus.WITHDRAWAL) {
      throw new BadRequestException(WITHDRAWN_ACCOUNT_RECOVERY_MESSAGE);
    }

    return user;
  }

  private async decodeVerifiedToken(token: string, expectedPurpose: EmailVerificationPurpose): Promise<{ verificationId: string; email: string; purpose: EmailVerificationPurpose }> {
    let payload: { verificationId: string; email: string; purpose: EmailVerificationPurpose };
    try {
      payload = await this.jwtService.verifyAsync(token, {
        secret: this.configService.getOrThrow<string>('JWT_ACCESS_TOKEN_SECRET'),
      });
    } catch {
      throw new UnauthorizedException('인증 토큰이 유효하지 않거나 만료되었습니다.');
    }

    if (payload.purpose !== expectedPurpose) {
      throw new BadRequestException('잘못된 인증 목적입니다.');
    }

    const record = await this.emailVerificationRepo.findOne({ where: { id: payload.verificationId, isVerified: true } });
    if (!record) {
      throw new UnauthorizedException('이메일 인증이 완료되지 않았거나 이미 사용된 토큰입니다.');
    }

    // 단일 사용 보장: 조회 즉시 레코드 삭제하여 동일 토큰 재사용 방지
    await this.emailVerificationRepo.delete({ id: record.id });

    return payload;
  }
}
