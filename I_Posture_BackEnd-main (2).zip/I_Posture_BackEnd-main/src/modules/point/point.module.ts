import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import { PointHistoryEntity } from "../../database/entities/point-history.entity";
import { AdminPointLogEntity } from "../../database/entities/admin-point-log.entity";
import { PointController } from "./point.controller";
import { PointService } from "./point.service";

@Module({
  imports: [TypeOrmModule.forFeature([PointHistoryEntity, AdminPointLogEntity])],
  controllers: [PointController],
  providers: [PointService],
})
export class PointModule {}
