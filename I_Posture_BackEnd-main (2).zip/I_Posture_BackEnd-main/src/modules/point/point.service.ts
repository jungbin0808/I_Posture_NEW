import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { PointHistoryEntity } from "../../database/entities/point-history.entity";
import { AdminPointLogEntity } from "../../database/entities/admin-point-log.entity";

@Injectable()
export class PointService {
  constructor(
    @InjectRepository(PointHistoryEntity)
    private readonly pointHistoryRepo: Repository<PointHistoryEntity>,
    @InjectRepository(AdminPointLogEntity)
    private readonly adminPointLogRepo: Repository<AdminPointLogEntity>,
  ) {}

  // 여기에 포인트 관련 비즈니스 로직 추가
}
