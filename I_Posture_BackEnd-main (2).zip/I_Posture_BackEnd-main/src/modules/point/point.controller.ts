import { Controller } from "@nestjs/common";
import { PointService } from "./point.service";

@Controller("points")
export class PointController {
  constructor(private readonly pointService: PointService) {}

  // 여기에 포인트 관련 API 엔드포인트 추가
}
