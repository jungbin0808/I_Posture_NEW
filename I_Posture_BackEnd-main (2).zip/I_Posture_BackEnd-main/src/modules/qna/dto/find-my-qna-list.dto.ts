import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';
import { QnaListSort } from './find-qna-list.dto';
import { QnaQuestionStatus } from './qna-list-item.dto';

export class FindMyQnaListDto extends PaginationDto {
  @ApiProperty({
    description: '상태 필터 (답변 대기/채택 대기/채택 완료), 미지정 시 전체',
    enum: QnaQuestionStatus,
    required: false,
  })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsEnum(QnaQuestionStatus)
  @IsOptional()
  status?: QnaQuestionStatus;

  @ApiProperty({
    description: '정렬 순서 (LATEST: 등록일 내림차순, OLDEST: 등록일 오름차순)',
    enum: QnaListSort,
    default: QnaListSort.LATEST,
    required: false,
  })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsEnum(QnaListSort)
  @IsOptional()
  sort: QnaListSort = QnaListSort.LATEST;

  @ApiProperty({ description: '검색어 (제목/질문 내용/답변 내용)', required: false })
  @Transform(({ value }) => {
    if (typeof value !== 'string') {
      return value;
    }
    const trimmed = value.trim();
    return trimmed === '' ? undefined : trimmed;
  })
  @IsString()
  @IsOptional()
  searchWord?: string;
}
