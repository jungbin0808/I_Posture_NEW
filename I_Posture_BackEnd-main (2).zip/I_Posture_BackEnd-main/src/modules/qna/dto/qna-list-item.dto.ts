import { ApiProperty } from '@nestjs/swagger';

export enum QnaQuestionStatus {
  /** 답변이 하나도 없음 */
  UNANSWERED = 'UNANSWERED',
  /** 답변은 있지만 채택된 답변이 없음 */
  PENDING_ACCEPTANCE = 'PENDING_ACCEPTANCE',
  /** 채택된 답변이 있음 */
  ACCEPTED = 'ACCEPTED',
}

export class QnaListItemDto {
  @ApiProperty({ description: '질문 ID' })
  id!: string;

  @ApiProperty({ description: '질문 제목' })
  title!: string;

  @ApiProperty({ description: '작성자 ID' })
  authorId!: string;

  @ApiProperty({ description: '작성자 이름' })
  authorName!: string;

  @ApiProperty({ description: '작성자 권한 (한글) - 회원 유형 뱃지용' })
  authorRole!: string;

  @ApiProperty({ enum: QnaQuestionStatus, description: '답변 대기/채택 대기/채택 완료 상태 - 카드 상태 뱃지용' })
  status!: QnaQuestionStatus;

  @ApiProperty({ description: '답변 수' })
  answerCount!: number;

  @ApiProperty({ description: '조회수' })
  viewCount!: number;

  @ApiProperty({ description: '작성일시' })
  createdAt!: Date;
}
