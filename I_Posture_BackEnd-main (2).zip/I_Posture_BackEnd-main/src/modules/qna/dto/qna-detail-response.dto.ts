import { ApiProperty } from '@nestjs/swagger';

export class FileDto {
  @ApiProperty({ description: '파일 ID' })
  id!: string;

  @ApiProperty({ description: '파일 URL' })
  fileUrl!: string;

  @ApiProperty({ description: '파일 크기' })
  size!: string;

  @ApiProperty({ description: '원본 파일명 (S3 Key 등)' })
  s3Key!: string;
}

export class AuthorDto {
  @ApiProperty({ description: '작성자 ID' })
  id!: string;

  @ApiProperty({ description: '작성자 이름' })
  name!: string;

  @ApiProperty({ description: '작성자 별점 지수' })
  starRating!: number;

  @ApiProperty({ description: '작성자 권한 (한글)' })
  role!: string;
}

export class QnaAnswerResponseDto {
  @ApiProperty({ description: '답변 ID' })
  id!: string;

  @ApiProperty({ description: '답변 내용' })
  content!: string;

  @ApiProperty({ description: '작성자 정보' })
  author!: AuthorDto;

  @ApiProperty({ description: '채택 여부' })
  isAccepted!: boolean;

  @ApiProperty({ description: '별점 (채택된 경우)', nullable: true })
  rating?: number;

  @ApiProperty({ description: '작성일시' })
  createdAt!: Date;

  @ApiProperty({ description: '첨부 파일 목록', type: [FileDto], required: false })
  files?: FileDto[];
}

export class QnaDetailResponseDto {
  @ApiProperty({ description: '질문 ID' })
  id!: string;

  @ApiProperty({ description: '질문 제목' })
  title!: string;

  @ApiProperty({ description: '질문 내용' })
  content!: string;

  @ApiProperty({ description: '작성자 정보' })
  author!: AuthorDto;

  @ApiProperty({ description: '조회수' })
  viewCount!: number;

  @ApiProperty({ description: '작성일시' })
  createdAt!: Date;

  @ApiProperty({ description: '답변 목록', type: [QnaAnswerResponseDto] })
  answers!: QnaAnswerResponseDto[];
}
