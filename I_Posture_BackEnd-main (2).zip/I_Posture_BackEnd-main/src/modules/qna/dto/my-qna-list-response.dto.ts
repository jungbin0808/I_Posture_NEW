import { ApiProperty } from '@nestjs/swagger';
import { IPage } from '../../../common/response/response.interface';
import { QnaListItemDto } from './qna-list-item.dto';

export class MyQnaListCountsDto {
  @ApiProperty({ description: '전체 건수 (검색어 필터만 반영, 상태 무관)' })
  all!: number;

  @ApiProperty({ description: '답변 대기 건수' })
  unanswered!: number;

  @ApiProperty({ description: '채택 대기 건수' })
  pendingAcceptance!: number;

  @ApiProperty({ description: '채택 완료 건수' })
  accepted!: number;
}

export class MyQnaListResponseDto {
  @ApiProperty({ type: [QnaListItemDto], description: '현재 status 필터가 적용된 목록' })
  items!: QnaListItemDto[];

  @ApiProperty({ description: '페이징 정보 (현재 status 필터 기준)' })
  paging!: IPage;

  @ApiProperty({ type: MyQnaListCountsDto, description: '탭별 건수 (검색어만 반영, status 필터와 무관하게 항상 4개 전부 계산)' })
  counts!: MyQnaListCountsDto;
}
