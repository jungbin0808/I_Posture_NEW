import { ApiProperty } from '@nestjs/swagger';
import { IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateQnaQuestionDto {
  @ApiProperty({ description: '질문 제목 (최대 50자)', required: false })
  @IsString()
  @MaxLength(50)
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '질문 내용 (최대 2000자)', required: false })
  @IsString()
  @MaxLength(2000)
  @IsOptional()
  content?: string;
}
