import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString } from 'class-validator';
import { Transform } from 'class-transformer';

export class UpdateQnaAnswerDto {
  @ApiProperty({ description: '답변 내용', required: false })
  @IsString()
  @IsOptional()
  content?: string;

  @ApiProperty({ description: '유지할 기존 파일 ID 목록 (생략 시 기존 파일 전체 유지)', required: false, type: [String] })
  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  @Transform(({ value }) => {
    if (value === undefined || value === null) return undefined;
    // 배열인 경우: 각 원소가 JSON 문자열일 수 있으므로 펼치기
    if (Array.isArray(value)) {
      const flat: string[] = [];
      for (const v of value) {
        if (typeof v === 'string') {
          try {
            const parsed = JSON.parse(v);
            if (Array.isArray(parsed)) { flat.push(...parsed); continue; }
          } catch {}
        }
        flat.push(v);
      }
      return flat;
    }
    // 단일 문자열인 경우: JSON 배열 파싱 시도
    if (typeof value === 'string') {
      try {
        const parsed = JSON.parse(value);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
      return [value];
    }
    return undefined;
  })
  keepFileIds?: string[];
}
