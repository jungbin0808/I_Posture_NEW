import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsString, IsUUID } from 'class-validator';
import { QnaReportTarget } from '../../../database/entities/qna-report.entity';

export class CreateQnaReportDto {
  @ApiProperty({ description: '신고 대상 유형 (질문/답변)', enum: QnaReportTarget })
  @IsEnum(QnaReportTarget)
  @IsNotEmpty()
  targetType!: QnaReportTarget;

  @ApiProperty({ description: '신고 대상 ID (질문 ID 또는 답변 ID)' })
  @IsUUID()
  @IsNotEmpty()
  targetId!: string;

  @ApiProperty({ description: '신고 사유' })
  @IsString()
  @IsNotEmpty()
  reason!: string;
}
