import { ApiProperty } from '@nestjs/swagger';

export class QnaMyStatsResponseDto {
  @ApiProperty({ description: '나의 별점 지수 (5점 만점)' })
  starRating!: number;

  @ApiProperty({ description: '나의 질문 수' })
  myQuestionCount!: number;

  @ApiProperty({ description: '나의 답변 수' })
  myAnswerCount!: number;
}
