import { ApiProperty } from '@nestjs/swagger';

class QnaAuthorCenterImageDto {
  @ApiProperty({ description: '이미지 파일 ID' })
  id!: string;

  @ApiProperty({ description: '이미지 URL' })
  fileUrl!: string;
}

class QnaAuthorCenterDto {
  @ApiProperty({ description: '센터 ID' })
  id!: string;

  @ApiProperty({ description: '센터명' })
  name!: string;

  @ApiProperty({ description: '한줄소개', required: false, nullable: true })
  description?: string;

  @ApiProperty({ description: '주소', required: false, nullable: true })
  address?: string;

  @ApiProperty({ description: '대표 연락처', required: false, nullable: true })
  phone?: string;

  @ApiProperty({ description: '로고 이미지 URL', required: false, nullable: true })
  logoUrl?: string | null;

  @ApiProperty({ description: '이미지 캐러셀', type: [QnaAuthorCenterImageDto] })
  images!: QnaAuthorCenterImageDto[];
}

export class QnaAuthorProfileResponseDto {
  @ApiProperty({ description: '작성자 유저 PK (UUID)' })
  id!: string;

  @ApiProperty({ description: '작성자 아이디 (userid 표기용 — 로그인 아이디, UserEntity.userId. USER APP 회원은 이메일, 트레이너/센터는 자체 아이디 문자열)' })
  userId!: string;

  @ApiProperty({ description: '작성자 유형 뱃지 (센터/트레이너/사용자/관리자)' })
  role!: string;

  @ApiProperty({ description: '이름' })
  name!: string;

  @ApiProperty({ description: '평점 (채택된 답변 rating 평균)' })
  starRating!: number;

  @ApiProperty({ description: '답변 수' })
  answerCount!: number;

  @ApiProperty({ description: '개인 활동명 (개인 트레이너 전용, 소속 센터 없을 때)', required: false, nullable: true })
  affiliationName?: string;

  @ApiProperty({
    description: '프로필 이미지 URL (개인 트레이너 전용) — 업로드 기능이 아직 없어 항상 null',
    required: false,
    nullable: true,
  })
  profileImageUrl?: string | null;

  @ApiProperty({ description: '소속 센터 정보 (센터 본인 또는 센터소속 트레이너일 때만)', required: false, nullable: true })
  center?: QnaAuthorCenterDto;
}
