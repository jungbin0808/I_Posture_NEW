import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, Max, Min } from 'class-validator';

export class AcceptQnaAnswerDto {
  @ApiProperty({ description: '답변 별점 (1~5점)' })
  @IsInt()
  @Min(1)
  @Max(5)
  @IsNotEmpty()
  rating!: number;
}
