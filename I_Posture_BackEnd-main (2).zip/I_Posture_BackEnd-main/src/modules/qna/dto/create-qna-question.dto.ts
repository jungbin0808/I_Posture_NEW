import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, MaxLength } from 'class-validator';

export class CreateQnaQuestionDto {
  @ApiProperty({ description: '질문 제목 (최대 50자)' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(50)
  title!: string;

  @ApiProperty({ description: '질문 내용 (최대 2000자)' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(2000)
  content!: string;
}
