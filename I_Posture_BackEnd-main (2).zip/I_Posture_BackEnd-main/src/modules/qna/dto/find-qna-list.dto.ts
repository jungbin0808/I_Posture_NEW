import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export enum QnaListFilter {
  MY_QUESTIONS = 'MY_QUESTIONS',
  MY_ANSWERS = 'MY_ANSWERS',
  /** 답변이 하나도 없는 질문 (USER APP "답변 대기" 탭) */
  UNANSWERED = 'UNANSWERED',
  /** 답변은 있지만 채택된 답변이 없는 질문 (USER APP "채택 대기" 탭) */
  PENDING_ACCEPTANCE = 'PENDING_ACCEPTANCE',
  /** 채택된 답변이 있는 질문 (USER APP "채택 완료" 탭) */
  ACCEPTED = 'ACCEPTED',
}

export enum QnaListSort {
  LATEST = 'LATEST',
  OLDEST = 'OLDEST',
}

export class FindQnaListDto extends PaginationDto {
  @ApiProperty({
    description: '목록 필터 (내가 올린 질문 / 내가 답변한 질문)',
    enum: QnaListFilter,
    required: false,
  })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsEnum(QnaListFilter)
  @IsOptional()
  filter?: QnaListFilter;

  @ApiProperty({
    description: '정렬 순서 (LATEST: 등록일 내림차순, OLDEST: 등록일 오름차순)',
    enum: QnaListSort,
    default: QnaListSort.LATEST,
    required: false,
  })
  @Transform(({ value }) => (value === '' ? undefined : value))
  @IsEnum(QnaListSort)
  @IsOptional()
  sort: QnaListSort = QnaListSort.LATEST;

  @ApiProperty({ description: '검색어 (제목/질문 내용/답변 내용)', required: false })
  @Transform(({ value }) => {
    if (typeof value !== 'string') {
      return value;
    }
    const trimmed = value.trim();
    return trimmed === '' ? undefined : trimmed;
  })
  @IsString()
  @IsOptional()
  searchWord?: string;
}
