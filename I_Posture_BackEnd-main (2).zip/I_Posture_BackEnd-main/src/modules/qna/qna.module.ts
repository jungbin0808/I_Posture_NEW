import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { QnaQuestionEntity } from '../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../database/entities/qna-answer.entity';
import { QnaReportEntity } from '../../database/entities/qna-report.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { QnaController } from './qna.controller';
import { QnaService } from './qna.service';
import { S3Module } from '../../s3/s3.module';
import { UserEntity } from '../../database/entities/user.entity';
import { PointHistoryEntity } from '../../database/entities/point-history.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      QnaQuestionEntity,
      QnaAnswerEntity,
      QnaReportEntity,
      FileEntity,
      UserEntity,
      PointHistoryEntity,
      CenterEntity,
      CenterTrainerEntity,
    ]),
    S3Module,
  ],
  controllers: [QnaController],
  providers: [QnaService],
  exports: [QnaService],
})
export class QnaModule {}
