import { ForbiddenException, Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Brackets, DataSource, In, Repository, SelectQueryBuilder } from 'typeorm';
import { QnaQuestionEntity } from '../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../database/entities/qna-answer.entity';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { QnaMyStatsResponseDto } from './dto/qna-my-stats-response.dto';
import { FindQnaListDto, QnaListFilter, QnaListSort } from './dto/find-qna-list.dto';
import { FindMyQnaListDto } from './dto/find-my-qna-list.dto';
import { MyQnaListResponseDto } from './dto/my-qna-list-response.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { QnaListItemDto, QnaQuestionStatus } from './dto/qna-list-item.dto';
import { CreateQnaQuestionDto } from './dto/create-qna-question.dto';
import { UpdateQnaQuestionDto } from './dto/update-qna-question.dto';
import { CreateQnaAnswerDto } from './dto/create-qna-answer.dto';
import { UpdateQnaAnswerDto } from './dto/update-qna-answer.dto';
import { CreateQnaReportDto } from './dto/create-qna-report.dto';
import { QnaReportEntity } from '../../database/entities/qna-report.entity';
import { QnaDetailResponseDto, FileDto, AuthorDto } from './dto/qna-detail-response.dto';
import { S3Service } from '../../s3/s3.service';
import { FileEntity, FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { AcceptQnaAnswerDto } from './dto/accept-qna-answer.dto';
import { DeleteQnaQuestionsDto } from './dto/delete-qna-questions.dto';
import { PointHistoryEntity, PointHistoryType, PointSource } from '../../database/entities/point-history.entity';
import { Transactional } from 'typeorm-transactional';
import { ConfigService } from '@nestjs/config';
import { FcmService } from '../notification/fcm.service';
import { PUSH_DATA_TYPE } from '../notification/push-notification-data.constant';
import { CenterEntity } from '../../database/entities/center.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../database/entities/center-trainer.entity';
import { QnaAuthorProfileResponseDto } from './dto/qna-author-profile-response.dto';

@Injectable()
export class QnaService {
  private readonly logger = new Logger(QnaService.name);

  constructor(
    @InjectRepository(QnaQuestionEntity)
    private readonly questionRepo: Repository<QnaQuestionEntity>,
    @InjectRepository(QnaAnswerEntity)
    private readonly answerRepo: Repository<QnaAnswerEntity>,
    @InjectRepository(QnaReportEntity)
    private readonly reportRepo: Repository<QnaReportEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(PointHistoryEntity)
    private readonly pointHistoryRepo: Repository<PointHistoryEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    private readonly s3Service: S3Service,
    private readonly dataSource: DataSource,
    private readonly configService: ConfigService,
    private readonly fcmService: FcmService,
  ) {}

  async getMyStats(user: UserEntity): Promise<QnaMyStatsResponseDto> {
    const myQuestionCount = await this.questionRepo.count({ where: { authorId: user.id } });
    const myAnswerCount = await this.answerRepo.count({ where: { authorId: user.id } });
    const ratingResult = await this.answerRepo
      .createQueryBuilder('a')
      .select('AVG(a.rating)', 'avg')
      .where('a.authorId = :userId AND a.isAccepted = true AND a.rating IS NOT NULL', { userId: user.id })
      .getRawOne();
    const starRating = ratingResult?.avg != null ? parseFloat(parseFloat(ratingResult.avg).toFixed(1)) : 0;

    return {
      myQuestionCount,
      myAnswerCount,
      starRating,
    };
  }

  /**
   * 작성자 프로필 바텀시트 (userid 뱃지 터치 시) - 센터/센터소속 트레이너/개인 트레이너/일반회원 4갈래.
   * 센터·센터소속 트레이너는 소속 센터의 이미지 캐러셀(CENTER_GALLERY)을 그대로 노출.
   * 개인 트레이너 프로필 이미지는 업로드 기능 자체가 아직 없어 항상 null.
   */
  async getAuthorProfile(userId: string): Promise<QnaAuthorProfileResponseDto> {
    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('사용자를 찾을 수 없습니다.');

    const stats = await this.getMyStats(user);
    const base: QnaAuthorProfileResponseDto = {
      id: user.id,
      // MEMBER는 소셜로그인 전용이라 로그인 아이디 개념이 없고, user_id 컬럼은 unique 제약 충족용 내부 식별값일 뿐이라 화면에 노출하면 안 됨
      userId: user.userType === UserType.MEMBER ? user.email : user.userId,
      role: this.getUserRoleName(user.userType),
      name: user.name,
      starRating: stats.starRating,
      answerCount: stats.myAnswerCount,
    };

    let center: CenterEntity | null = null;
    if (user.userType === UserType.CENTER) {
      center = await this.centerRepo.findOne({ where: { ownerId: user.id } });
    } else if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({
        where: { trainerId: user.id, status: CenterTrainerStatus.WORKING },
        relations: ['center'],
      });
      center = affiliation?.center ?? null;
    }

    if (center) {
      const images = await this.fileRepo.find({
        where: { relatedType: FileRelatedType.CENTER_GALLERY, relatedId: center.id },
        order: { createdAt: 'ASC' },
      });
      return {
        ...base,
        center: {
          id: center.id,
          name: center.name,
          description: center.description,
          address: center.address,
          phone: center.phone,
          logoUrl: center.logoUrl,
          images: images.map((f) => ({ id: f.id, fileUrl: f.fileUrl })),
        },
      };
    }

    if (user.userType === UserType.F_TRAINER) {
      return {
        ...base,
        affiliationName: user.affiliationName,
        profileImageUrl: null,
      };
    }

    return base;
  }

  async findAll(user: UserEntity, dto: FindQnaListDto): Promise<IPageData<QnaListItemDto>> {
    const { page = 1, limit = 10, filter, sort } = dto;
    const searchWord = this.resolveSearchWord(dto);

    const baseQuery = this.questionRepo.createQueryBuilder('q')
      .innerJoin('q.author', 'author');

    this.applyQnaSearchFilter(baseQuery, searchWord);

    if (filter === QnaListFilter.MY_QUESTIONS) {
      baseQuery.andWhere('q.authorId = :userId', { userId: user.id });
    } else if (filter === QnaListFilter.MY_ANSWERS) {
      baseQuery.andWhere(
        'EXISTS (SELECT 1 FROM qna_answers my_ans WHERE my_ans.question_id = q.id AND my_ans.author_id = :userId)',
        { userId: user.id },
      );
    } else if (filter === QnaListFilter.UNANSWERED) {
      // USER APP "답변 대기" 탭 - 내가 작성한 질문 중 상태 필터링 (전체 게시판 대상이 아님)
      baseQuery.andWhere('q.authorId = :userId', { userId: user.id });
      this.applyQuestionStatusFilter(baseQuery, QnaQuestionStatus.UNANSWERED);
    } else if (filter === QnaListFilter.PENDING_ACCEPTANCE) {
      // USER APP "채택 대기" 탭 - 내가 작성한 질문 중 상태 필터링 (전체 게시판 대상이 아님)
      baseQuery.andWhere('q.authorId = :userId', { userId: user.id });
      this.applyQuestionStatusFilter(baseQuery, QnaQuestionStatus.PENDING_ACCEPTANCE);
    } else if (filter === QnaListFilter.ACCEPTED) {
      // USER APP "채택 완료" 탭 - 내가 작성한 질문 중 상태 필터링 (전체 게시판 대상이 아님)
      baseQuery.andWhere('q.authorId = :userId', { userId: user.id });
      this.applyQuestionStatusFilter(baseQuery, QnaQuestionStatus.ACCEPTED);
    }

    const total = await baseQuery.getCount();

    const listQuery = this.addQnaListSelectFields(baseQuery.clone())
      .orderBy('q.createdAt', sort === QnaListSort.OLDEST ? 'ASC' : 'DESC')
      .offset((page - 1) * limit)
      .limit(limit);

    const rawData = await listQuery.getRawMany();
    const items: QnaListItemDto[] = rawData.map(item => this.mapRawToListItem(item));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 마이페이지 "내가 작성한 질문" 목록 - 항상 본인 질문만, 상태(status)로 탭 필터링 + 탭별 건수(counts) 동시 반환.
   * counts는 검색어만 반영하고 status와 무관하게 매번 4개 전부 계산 (탭 UI가 항상 최신 건수를 보여줘야 하므로).
   */
  async findMyQuestions(user: UserEntity, dto: FindMyQnaListDto): Promise<MyQnaListResponseDto> {
    const { page = 1, limit = 10, status, sort } = dto;
    const searchWord = this.resolveSearchWord(dto);

    const baseQuery = this.questionRepo.createQueryBuilder('q')
      .innerJoin('q.author', 'author')
      .where('q.authorId = :userId', { userId: user.id });

    this.applyQnaSearchFilter(baseQuery, searchWord);

    const [all, unanswered, pendingAcceptance, accepted] = await Promise.all([
      baseQuery.clone().getCount(),
      this.applyQuestionStatusFilter(baseQuery.clone(), QnaQuestionStatus.UNANSWERED).getCount(),
      this.applyQuestionStatusFilter(baseQuery.clone(), QnaQuestionStatus.PENDING_ACCEPTANCE).getCount(),
      this.applyQuestionStatusFilter(baseQuery.clone(), QnaQuestionStatus.ACCEPTED).getCount(),
    ]);

    const filteredQuery = this.applyQuestionStatusFilter(baseQuery.clone(), status);
    const total = await filteredQuery.getCount();

    const listQuery = this.addQnaListSelectFields(filteredQuery.clone())
      .orderBy('q.createdAt', sort === QnaListSort.OLDEST ? 'ASC' : 'DESC')
      .offset((page - 1) * limit)
      .limit(limit);

    const rawData = await listQuery.getRawMany();
    const items: QnaListItemDto[] = rawData.map(item => this.mapRawToListItem(item));

    return {
      items,
      paging: buildPaging(total, limit, page),
      counts: { all, unanswered, pendingAcceptance, accepted },
    };
  }

  /**
   * 특정 사용자가 작성하거나 답변한 Q&A만 조회 (센터 트레이너 상세 뷰용)
   * - filter 미지정: 작성 질문 + 답변한 질문
   * - MY_QUESTIONS / MY_ANSWERS: findAll과 동일
   */
  async findAllByUserActivity(user: UserEntity, dto: FindQnaListDto): Promise<IPageData<QnaListItemDto>> {
    const { page = 1, limit = 10, filter, sort } = dto;
    const searchWord = this.resolveSearchWord(dto);

    const baseQuery = this.questionRepo.createQueryBuilder('q')
      .innerJoin('q.author', 'author');

    this.applyQnaSearchFilter(baseQuery, searchWord);

    if (filter === QnaListFilter.MY_QUESTIONS) {
      baseQuery.andWhere('q.authorId = :userId', { userId: user.id });
    } else if (filter === QnaListFilter.MY_ANSWERS) {
      baseQuery.andWhere(
        'EXISTS (SELECT 1 FROM qna_answers my_ans WHERE my_ans.question_id = q.id AND my_ans.author_id = :userId)',
        { userId: user.id },
      );
    } else {
      baseQuery.andWhere(new Brackets((qb) => {
        qb.where('q.authorId = :userId', { userId: user.id })
          .orWhere(
            'EXISTS (SELECT 1 FROM qna_answers my_ans WHERE my_ans.question_id = q.id AND my_ans.author_id = :userId)',
          );
      }));
    }

    const total = await baseQuery.getCount();

    const listQuery = this.addQnaListSelectFields(baseQuery.clone())
      .orderBy('q.createdAt', sort === QnaListSort.OLDEST ? 'ASC' : 'DESC')
      .offset((page - 1) * limit)
      .limit(limit);

    const rawData = await listQuery.getRawMany();
    const items: QnaListItemDto[] = rawData.map(item => this.mapRawToListItem(item));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 질문 상태(답변 대기/채택 대기/채택 완료) 필터 - status 미지정 시 조건 없이 그대로 반환(전체).
   * clone된 서로 다른 쿼리에서 각각 호출되는 용도라 alias는 고정값이어도 무방(쿼리별로 독립적으로 SQL화됨).
   */
  private applyQuestionStatusFilter(
    query: SelectQueryBuilder<QnaQuestionEntity>,
    status: QnaQuestionStatus | undefined,
  ): SelectQueryBuilder<QnaQuestionEntity> {
    if (status === QnaQuestionStatus.UNANSWERED) {
      query.andWhere(
        'NOT EXISTS (SELECT 1 FROM qna_answers status_unanswered WHERE status_unanswered.question_id = q.id)',
      );
    } else if (status === QnaQuestionStatus.PENDING_ACCEPTANCE) {
      query
        .andWhere('EXISTS (SELECT 1 FROM qna_answers status_pending WHERE status_pending.question_id = q.id)')
        .andWhere(
          'NOT EXISTS (SELECT 1 FROM qna_answers status_pending_accepted WHERE status_pending_accepted.question_id = q.id AND status_pending_accepted.is_accepted = true)',
        );
    } else if (status === QnaQuestionStatus.ACCEPTED) {
      query.andWhere(
        'EXISTS (SELECT 1 FROM qna_answers status_accepted WHERE status_accepted.question_id = q.id AND status_accepted.is_accepted = true)',
      );
    }

    return query;
  }

  /**
   * Q&A 목록 조회용 select 필드(작성자 유형, 답변 수, 채택 여부 등) 공통 추가
   */
  private addQnaListSelectFields(query: SelectQueryBuilder<QnaQuestionEntity>): SelectQueryBuilder<QnaQuestionEntity> {
    return query
      .select([
        'q.id as id',
        'q.title as title',
        'author.id as authorId',
        'author.name as authorName',
        'author.userType as authorUserType',
        'q.viewCount as viewCount',
        'q.createdAt as createdAt',
      ])
      .addSelect(subQuery => subQuery.select('COUNT(ans.id)').from(QnaAnswerEntity, 'ans').where('ans.questionId = q.id'), 'answerCount')
      .addSelect(
        subQuery => subQuery.select('COUNT(acceptedAns.id)').from(QnaAnswerEntity, 'acceptedAns').where('acceptedAns.questionId = q.id AND acceptedAns.isAccepted = true'),
        'acceptedCount',
      );
  }

  private mapRawToListItem(item: any): QnaListItemDto {
    const answerCount = parseInt(item.answerCount, 10) || 0;
    const acceptedCount = parseInt(item.acceptedCount, 10) || 0;
    const status = answerCount === 0
      ? QnaQuestionStatus.UNANSWERED
      : acceptedCount > 0
        ? QnaQuestionStatus.ACCEPTED
        : QnaQuestionStatus.PENDING_ACCEPTANCE;

    return {
      id: item.id,
      title: item.title,
      authorId: item.authorId,
      authorName: item.authorName,
      authorRole: this.getUserRoleName(item.authorUserType),
      status,
      answerCount,
      viewCount: item.viewCount,
      createdAt: item.createdAt,
    };
  }

  async findOne(id: string): Promise<QnaDetailResponseDto> {
    await this.questionRepo.increment({ id }, 'viewCount', 1);

    const question = await this.questionRepo.createQueryBuilder('question')
      .leftJoinAndSelect('question.author', 'author')
      .where('question.id = :id', { id })
      .getOne();

    if (!question) {
      throw new NotFoundException('Question not found');
    }

    const answers = await this.answerRepo.createQueryBuilder('answer')
      .leftJoinAndSelect('answer.author', 'answerAuthor')
      .where('answer.questionId = :id', { id })
      .orderBy('answer.isAccepted', 'DESC')
      .addOrderBy('answer.createdAt', 'DESC')
      .getMany();

    const answerIds = answers.map(ans => ans.id);
    const files = answerIds.length > 0 ? await this.fileRepo.find({ where: { relatedType: FileRelatedType.QNA_ANSWER, relatedId: In(answerIds) } }) : [];

    const filesByAnswerId = new Map<string, FileDto[]>();
    files.forEach(file => {
      const fileDtos = filesByAnswerId.get(file.relatedId!) || [];
      fileDtos.push({
        id: file.id,
        fileUrl: file.fileUrl,
        size: file.size,
        s3Key: file.s3Key,
      });
      filesByAnswerId.set(file.relatedId!, fileDtos);
    });

    // 작성자들의 별점 지수 계산을 위해 ID 수집
    const authorIds = new Set<string>();
    authorIds.add(question.authorId);
    answers.forEach(ans => authorIds.add(ans.authorId));

    // 각 작성자의 별점 지수 계산 (한 번에 쿼리하지 않고 반복문에서 처리하면 N+1 문제 발생 가능하지만, 여기서는 간단하게 구현)
    // 최적화를 위해 별도 쿼리로 통계를 가져오는 것이 좋음
    const authorStats = new Map<string, { starRating: number, role: string }>();
    
    for (const authorId of authorIds) {
      const ratingResult = await this.answerRepo
        .createQueryBuilder('a')
        .select('AVG(a.rating)', 'avg')
        .where('a.authorId = :authorId AND a.isAccepted = true AND a.rating IS NOT NULL', { authorId })
        .getRawOne();
      const starRating = ratingResult?.avg != null ? parseFloat(parseFloat(ratingResult.avg).toFixed(1)) : 0;

      // UserType 한글 변환을 위해 UserEntity 조회 필요하지만, 이미 question.author, answer.author에 정보가 있음
      // 여기서는 author 객체에서 userType을 가져와 변환
      let userType = UserType.MEMBER;
      if (authorId === question.authorId) userType = question.author.userType;
      else {
        const answer = answers.find(a => a.authorId === authorId);
        if (answer) userType = answer.author.userType;
      }

      authorStats.set(authorId, {
        starRating: parseFloat(starRating.toFixed(1)),
        role: this.getUserRoleName(userType),
      });
    }

    const questionAuthorStat = authorStats.get(question.authorId)!;
    const questionAuthor: AuthorDto = {
      id: question.author.id,
      name: question.author.name,
      starRating: questionAuthorStat.starRating,
      role: questionAuthorStat.role,
    };

    return {
      ...question,
      author: questionAuthor,
      answers: answers.map(ans => {
        const stat = authorStats.get(ans.authorId)!;
        return {
          ...ans,
          author: {
            id: ans.author.id,
            name: ans.author.name,
            starRating: stat.starRating,
            role: stat.role,
          },
          files: filesByAnswerId.get(ans.id) || [],
        };
      }),
    };
  }

  /**
   * 트랜잭션 커밋 이후 푸시를 실행합니다.
   * @Transactional 내부에서 FCM(별도 DB 쿼리)을 즉시 호출하면 QueryRunnerAlreadyReleasedError가 발생할 수 있습니다.
   */
  private dispatchPushAfterCommit(task: () => Promise<unknown>, errorLabel: string): void {
    setImmediate(() => {
      task().catch((error) => this.logger.error(errorLabel, error));
    });
  }

  private async assertQuestionHasNoAcceptedAnswer(questionId: string): Promise<void> {
    const acceptedAnswer = await this.answerRepo.findOne({
      where: { questionId, isAccepted: true },
      select: ['id'],
    });
    if (acceptedAnswer) {
      throw new BadRequestException('채택된 질문은 수정할 수 없습니다.');
    }
  }

  private async preserveAcceptedAnswersForDeletedQuestions(questionIds: string[]): Promise<void> {
    const acceptedAnswers = await this.answerRepo.find({
      where: { questionId: In(questionIds), isAccepted: true },
    });

    for (const answer of acceptedAnswers) {
      await this.deleteAnswerFiles([answer.id]);
      answer.content = '';
      await this.answerRepo.save(answer);
    }
  }

  private async deleteNonAcceptedAnswersOnQuestions(questionIds: string[]): Promise<void> {
    const answers = await this.answerRepo.find({
      where: { questionId: In(questionIds), isAccepted: false },
      select: ['id'],
    });
    const answerIds = answers.map((answer) => answer.id);

    await this.deleteAnswerFiles(answerIds);

    if (answerIds.length > 0) {
      await this.answerRepo.delete({ id: In(answerIds) });
    }
  }

  private async deleteAnswerFiles(answerIds: string[]): Promise<void> {
    if (answerIds.length === 0) return;

    const files = await this.fileRepo.find({
      where: { relatedId: In(answerIds), relatedType: FileRelatedType.QNA_ANSWER },
    });

    for (const file of files) {
      await this.s3Service.deleteFile(file.s3Key);
      await this.fileRepo.delete(file.id);
    }
  }

  private resolveSearchWord(dto: FindQnaListDto): string | undefined {
    const resolved = dto.searchWord?.trim();
    return resolved || undefined;
  }

  private applyQnaSearchFilter(
    query: SelectQueryBuilder<QnaQuestionEntity>,
    searchWord?: string,
  ): void {
    if (!searchWord) {
      return;
    }

    const pattern = `%${searchWord}%`;
    query.andWhere(
      new Brackets((qb) => {
        qb.where('q.title LIKE :qnaSearchPattern', { qnaSearchPattern: pattern })
          .orWhere('q.content LIKE :qnaSearchPattern')
          .orWhere(
            `EXISTS (
              SELECT 1
              FROM qna_answers search_ans
              WHERE search_ans.question_id = q.id
                AND search_ans.content LIKE :qnaSearchPattern
            )`,
          );
      }),
    );
  }

  private getUserRoleName(userType: UserType): string {
    switch (userType) {
      case UserType.CENTER:
        return '센터';
      case UserType.C_TRAINER:
      case UserType.F_TRAINER:
        return '트레이너';
      case UserType.MEMBER:
        return '사용자';
      case UserType.ADMIN:
        return '관리자';
      default:
        return '사용자';
    }
  }

  async createQuestion(user: UserEntity, dto: CreateQnaQuestionDto): Promise<QnaQuestionEntity> {
    const question = this.questionRepo.create({ ...dto, authorId: user.id });
    const savedQuestion = await this.questionRepo.save(question);

    // 새 질문 등록 시 트레이너 전체에게 푸시
    const trainers = await this.userRepo.find({
      where: [{ userType: UserType.C_TRAINER }, { userType: UserType.F_TRAINER }],
      select: ['id'],
    });
    const trainerIds = trainers.map(t => t.id).filter(id => id !== user.id);
    if (trainerIds.length > 0) {
      this.dispatchPushAfterCommit(
        () => this.fcmService.sendToUsers(trainerIds, {
          title: '새 질문이 등록됐어요.',
          body: '👉 답변하고 포인트 받으세요.',
          data: { type: PUSH_DATA_TYPE.QNA_NEW_QUESTION, questionId: savedQuestion.id },
        }, 'notificationMyQuestion'),
        '새 질문 푸시 발송 실패',
      );
    }

    return savedQuestion;
  }

  async updateQuestion(userId: string, id: string, dto: UpdateQnaQuestionDto): Promise<QnaQuestionEntity> {
    const question = await this.questionRepo.findOneBy({ id });
    if (!question) throw new NotFoundException('Question not found');
    if (question.authorId !== userId) throw new ForbiddenException('Access denied');
    await this.assertQuestionHasNoAcceptedAnswer(id);
    Object.assign(question, dto);
    return this.questionRepo.save(question);
  }

  @Transactional()
  async deleteQuestions(userId: string, dto: DeleteQnaQuestionsDto): Promise<{ success: boolean }> {
    const { ids } = dto;
    const questions = await this.questionRepo.find({ where: { id: In(ids) } });

    if (questions.length !== ids.length) {
      throw new NotFoundException('Some questions were not found.');
    }

    for (const question of questions) {
      if (question.authorId !== userId) {
        throw new ForbiddenException(`Access denied to delete question ID: ${question.id}`);
      }
    }

    await this.preserveAcceptedAnswersForDeletedQuestions(ids);
    await this.deleteNonAcceptedAnswersOnQuestions(ids);

    await this.questionRepo.delete(ids);
    return { success: true };
  }

  @Transactional()
  async createAnswer(user: UserEntity, questionId: string, dto: CreateQnaAnswerDto, files?: Express.Multer.File[]): Promise<QnaAnswerEntity> {
    const question = await this.questionRepo.findOneBy({ id: questionId });
    if (!question) throw new NotFoundException('Question not found');

    const existingAnswer = await this.answerRepo.findOne({
      where: { questionId, authorId: user.id },
    });
    if (existingAnswer) {
      throw new BadRequestException('이미 해당 질문에 답변을 작성했습니다.');
    }

    const answer = this.answerRepo.create({ ...dto, authorId: user.id, questionId });
    const savedAnswer = await this.answerRepo.save(answer);

    // 답변 등록 시 질문 작성자에게 푸시 (본인 질문에 본인 답변 제외)
    if (question.authorId !== user.id) {
      this.dispatchPushAfterCommit(
        () => this.fcmService.sendToUser(question.authorId, {
          title: '질문에 답변이 도착했어요.',
          body: '전문가가 내 질문에 답변했어요.\n👉 지금 확인하고 정확한 솔루션 받아보세요',
          data: { type: PUSH_DATA_TYPE.QNA_ANSWER, questionId: question.id },
        }, 'notificationMyQuestion'),
        '답변 푸시 발송 실패',
      );
    }

    if (files && files.length > 0) {
      for (const file of files) {
        await this.s3Service.uploadFile(file, {
          memberId: user.id,
          uploaderId: user.id,
          ownerType: FileOwnerType.MEMBER, // Or TRAINER, based on user role
          ownerId: user.id,
          relatedType: FileRelatedType.QNA_ANSWER,
          relatedId: savedAnswer.id,
        });
      }
    }
    return savedAnswer;
  }

  @Transactional()
  async updateAnswer(userId: string, id: string, dto: UpdateQnaAnswerDto, files?: Express.Multer.File[]): Promise<QnaAnswerEntity> {
    const answer = await this.answerRepo.findOneBy({ id });
    if (!answer) throw new NotFoundException('Answer not found');
    if (answer.authorId !== userId) throw new ForbiddenException('Access denied');
    if (answer.isAccepted) {
      throw new BadRequestException('채택된 답변은 수정할 수 없습니다.');
    }

    if (dto.content !== undefined) {
      answer.content = dto.content;
    }

    // keepFileIds가 명시된 경우: 목록에 없는 기존 파일 삭제 / 미명시 시 기존 파일 그대로 유지
    const existingFiles = await this.fileRepo.find({ where: { relatedId: id, relatedType: FileRelatedType.QNA_ANSWER } });
    if (dto.keepFileIds !== undefined) {
      for (const existingFile of existingFiles) {
        if (!dto.keepFileIds.includes(existingFile.id)) {
          await this.s3Service.deleteFile(existingFile.s3Key);
          await this.fileRepo.delete(existingFile.id);
        }
      }
    }
    // 새 파일 업로드
    if (files && files.length > 0) {
      for (const file of files) {
        await this.s3Service.uploadFile(file, {
          memberId: userId,
          uploaderId: userId,
          ownerType: FileOwnerType.MEMBER,
          ownerId: userId,
          relatedType: FileRelatedType.QNA_ANSWER,
          relatedId: answer.id,
        });
      }
    }
    return this.answerRepo.save(answer);
  }

  @Transactional()
  async deleteAnswer(userId: string, id: string): Promise<{ success: boolean }> {
    const answer = await this.answerRepo.findOneBy({ id });
    if (!answer) throw new NotFoundException('Answer not found');
    if (answer.authorId !== userId) throw new ForbiddenException('Access denied');
    if (answer.isAccepted) {
      throw new BadRequestException('채택된 답변은 삭제할 수 없습니다.');
    }

    await this.deleteAnswerFiles([id]);
    await this.answerRepo.delete(id);
    return { success: true };
  }

  @Transactional()
  async acceptAnswer(userId: string, answerId: string, dto: AcceptQnaAnswerDto): Promise<QnaAnswerEntity> {
    this.logger.log(`Accepting answer: ${answerId} by user: ${userId}`);
    try {
      // 1. 답변 조회 (질문 정보 포함하지 않음)
      const answer = await this.answerRepo.findOne({ where: { id: answerId } });
      if (!answer) throw new NotFoundException('Answer not found');

      // 2. 질문 조회 (수동 조회)
      const question = await this.questionRepo.findOne({ where: { id: answer.questionId } });
      if (!question) throw new NotFoundException('Question not found');

      if (question.authorId !== userId) throw new ForbiddenException('Only the question author can accept an answer.');
      if (answer.authorId === question.authorId) {
        throw new BadRequestException('본인이 작성한 답변은 채택할 수 없습니다.');
      }

      // 3. 이미 채택된 답변 확인
      const alreadyAccepted = await this.answerRepo.findOne({ where: { questionId: question.id, isAccepted: true } });
      if (alreadyAccepted) {
        throw new BadRequestException('An answer has already been accepted for this question.');
      }

      // 4. 답변 채택 처리
      answer.isAccepted = true;
      answer.rating = dto.rating;
      const savedAnswer = await this.answerRepo.save(answer);

      // 5. 포인트 지급 (답변 작성자에게)
      const answerAuthor = await this.userRepo.findOne({ where: { id: answer.authorId } });
      if (answerAuthor) {
        const points = Number(this.configService.get<string>('QNA_ACCEPTANCE_POINTS')) || 100;
        
        // 포인트 이력 생성
        const pointHistory = this.pointHistoryRepo.create({
          userId: answerAuthor.id,
          type: PointHistoryType.EARN,
          source: PointSource.ADOPT,
          amount: points,
          balanceAfter: answerAuthor.totalPoints + points,
          description: 'Q&A 답변 채택',
        });
        await this.pointHistoryRepo.save(pointHistory);

        // 사용자 총 포인트 업데이트
        answerAuthor.totalPoints += points;
        await this.userRepo.save(answerAuthor);
      }

      // 별점 채택 시 답변 작성자에게 푸시
      this.dispatchPushAfterCommit(
        () => this.fcmService.sendToUser(answer.authorId, {
          title: '내 답변에 별점이 달렸어요.',
          body: `${dto.rating}점 평가를 받았습니다. 마이페이지에서 확인해보세요.`,
          data: { type: PUSH_DATA_TYPE.QNA_ANSWER_ACCEPTED, questionId: answer.questionId, answerId: answer.id },
        }, 'notificationMyAnswerAccepted'),
        '별점 푸시 발송 실패',
      );

      return savedAnswer;
    } catch (error) {
      if (error instanceof Error) {
        this.logger.error(`Error in acceptAnswer:`, error.stack);
      } else {
        this.logger.error(`Error in acceptAnswer:`, String(error));
      }
      throw error;
    }
  }

  async report(user: UserEntity, dto: CreateQnaReportDto): Promise<QnaReportEntity> {
    const report = this.reportRepo.create({ ...dto, reporterId: user.id });
    return this.reportRepo.save(report);
  }

  /**
   * 탈퇴 등: 작성자 Q&A 데이터 전체 삭제 (답변 첨부 파일 포함)
   */
  @Transactional()
  async deleteAllDataForAuthor(authorId: string): Promise<void> {
    const questions = await this.questionRepo.find({
      where: { authorId },
      select: ['id'],
    });
    const questionIds = questions.map((question) => question.id);

    if (questionIds.length > 0) {
      await this.preserveAcceptedAnswersForDeletedQuestions(questionIds);
      await this.deleteNonAcceptedAnswersOnQuestions(questionIds);
    }

    const ownAnswers = await this.answerRepo.find({
      where: { authorId },
      select: ['id'],
    });
    const ownAnswerIds = ownAnswers.map((answer) => answer.id);

    await this.deleteAnswerFiles(ownAnswerIds);

    if (ownAnswerIds.length > 0) {
      await this.answerRepo.delete({ authorId });
    }

    if (questionIds.length > 0) {
      await this.questionRepo.delete({ authorId });
    }
  }
}
