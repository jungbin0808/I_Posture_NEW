import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UploadedFiles, UseGuards, UseInterceptors } from '@nestjs/common';
import { FilesInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { QnaService } from './qna.service';
import { QnaMyStatsResponseDto } from './dto/qna-my-stats-response.dto';
import { QnaAuthorProfileResponseDto } from './dto/qna-author-profile-response.dto';
import { FindQnaListDto } from './dto/find-qna-list.dto';
import { FindMyQnaListDto } from './dto/find-my-qna-list.dto';
import { MyQnaListResponseDto } from './dto/my-qna-list-response.dto';
import { QnaListItemDto } from './dto/qna-list-item.dto';
import { QnaDetailResponseDto } from './dto/qna-detail-response.dto';
import { CreateQnaQuestionDto } from './dto/create-qna-question.dto';
import { UpdateQnaQuestionDto } from './dto/update-qna-question.dto';
import { CreateQnaAnswerDto } from './dto/create-qna-answer.dto';
import { UpdateQnaAnswerDto } from './dto/update-qna-answer.dto';
import { CreateQnaReportDto } from './dto/create-qna-report.dto';
import { QnaQuestionEntity } from '../../database/entities/qna-question.entity';
import { QnaAnswerEntity } from '../../database/entities/qna-answer.entity';
import { QnaReportEntity } from '../../database/entities/qna-report.entity';
import { AcceptQnaAnswerDto } from './dto/accept-qna-answer.dto';
import { DeleteQnaQuestionsDto } from './dto/delete-qna-questions.dto';

@ApiTags('Q&A')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('qna')
export class QnaController {
  constructor(private readonly qnaService: QnaService) {}

  /**
   * @summary 나의 Q&A 활동 통계 조회 (별점, 질문/답변 수)
   */
  @ApiOperation({ summary: 'Get My Q&A Stats' })
  @Get('my-stats')
  async getMyStats(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<QnaMyStatsResponseDto>> {
    const stats = await this.qnaService.getMyStats(req.user);
    return SuccessResponse(stats);
  }

  /**
   * @summary 작성자 프로필 바텀시트 조회 (질문/답변 작성자 뱃지 터치 시)
   */
  @ApiOperation({ summary: 'Get Q&A Author Profile (bottom sheet)' })
  @Get('authors/:userId/profile')
  async getAuthorProfile(@Param('userId') userId: string): Promise<ISuccessResponse<QnaAuthorProfileResponseDto>> {
    const profile = await this.qnaService.getAuthorProfile(userId);
    return SuccessResponse(profile);
  }

  /**
   * @summary 마이페이지 "내가 작성한 질문" 목록 (상태별 탭 필터 + 탭별 건수)
   */
  @ApiOperation({ summary: 'Get My Questions (Mypage, status tabs + counts)' })
  @Get('my-questions')
  async findMyQuestions(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindMyQnaListDto,
  ): Promise<ISuccessResponse<MyQnaListResponseDto>> {
    const result = await this.qnaService.findMyQuestions(req.user, findDto);
    return SuccessResponse<MyQnaListResponseDto>(result);
  }

  /**
   * @summary Q&A 목록 조회 (필터, 정렬, 검색)
   */
  @ApiOperation({ summary: 'Get Q&A List' })
  @Get()
  async findAll(@Req() req: { user: UserEntity }, @Query() findDto: FindQnaListDto): Promise<IPageResponse<QnaListItemDto>> {
    const pageData = await this.qnaService.findAll(req.user, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary Q&A 상세 조회
   */
  @ApiOperation({ summary: 'Get Q&A Detail' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<QnaDetailResponseDto>> {
    const question = await this.qnaService.findOne(id);
    return SuccessResponse(question);
  }

  /**
   * @summary 질문 등록
   */
  @ApiOperation({ summary: 'Create Q&A Question' })
  @Post()
  async createQuestion(@Req() req: { user: UserEntity }, @Body() createDto: CreateQnaQuestionDto): Promise<ISuccessResponse<QnaQuestionEntity>> {
    const question = await this.qnaService.createQuestion(req.user, createDto);
    return SuccessResponse(question);
  }

  /**
   * @summary 질문 수정
   */
  @ApiOperation({ summary: 'Update Q&A Question' })
  @Put(':id')
  async updateQuestion(@Req() req: { user: UserEntity }, @Param('id') id: string, @Body() updateDto: UpdateQnaQuestionDto): Promise<ISuccessResponse<QnaQuestionEntity>> {
    const question = await this.qnaService.updateQuestion(req.user.id, id, updateDto);
    return SuccessResponse(question);
  }

  /**
   * @summary 질문 일괄 삭제
   */
  @ApiOperation({ summary: 'Delete Q&A Questions (Batch)' })
  @Delete()
  async deleteQuestions(@Req() req: { user: UserEntity }, @Body() deleteDto: DeleteQnaQuestionsDto): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.qnaService.deleteQuestions(req.user.id, deleteDto);
    return SuccessResponse(result);
  }

  /**
   * @summary 답변 등록 (파일 첨부 가능)
   */
  @ApiOperation({ summary: 'Create Q&A Answer' })
  @Post(':id/answers')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        content: { type: 'string' },
        files: { type: 'array', items: { type: 'string', format: 'binary' } },
      },
    },
  })
  async createAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') questionId: string,
    @Body() createDto: CreateQnaAnswerDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.createAnswer(req.user, questionId, createDto, files);
    return SuccessResponse(answer);
  }

  /**
   * @summary 답변 채택 및 별점 부여
   */
  @ApiOperation({ summary: 'Accept Q&A Answer' })
  @Post('answers/:id/accept')
  async acceptAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') answerId: string,
    @Body() acceptDto: AcceptQnaAnswerDto,
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.acceptAnswer(req.user.id, answerId, acceptDto);
    return SuccessResponse(answer);
  }

  /**
   * @summary 답변 수정 (파일 수정 가능)
   */
  @ApiOperation({ summary: 'Update Q&A Answer' })
  @Put('answers/:id')
  @UseInterceptors(FilesInterceptor('files', 5))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        content: { type: 'string' },
        keepFileIds: { type: 'array', items: { type: 'string' }, description: '유지할 기존 파일 ID 목록' },
        files: { type: 'array', items: { type: 'string', format: 'binary' } },
      },
    },
  })
  async updateAnswer(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() updateDto: UpdateQnaAnswerDto,
    @UploadedFiles() files: Express.Multer.File[],
  ): Promise<ISuccessResponse<QnaAnswerEntity>> {
    const answer = await this.qnaService.updateAnswer(req.user.id, id, updateDto, files);
    return SuccessResponse(answer);
  }

  /**
   * @summary 답변 삭제
   */
  @ApiOperation({ summary: 'Delete Q&A Answer' })
  @Delete('answers/:id')
  async deleteAnswer(@Req() req: { user: UserEntity }, @Param('id') id: string): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.qnaService.deleteAnswer(req.user.id, id);
    return SuccessResponse(result);
  }

  /**
   * @summary 질문 또는 답변 신고
   */
  @ApiOperation({ summary: 'Report Q&A Question or Answer' })
  @Post('report')
  async report(@Req() req: { user: UserEntity }, @Body() createDto: CreateQnaReportDto): Promise<ISuccessResponse<QnaReportEntity>> {
    const report = await this.qnaService.report(req.user, createDto);
    return SuccessResponse(report);
  }
}
