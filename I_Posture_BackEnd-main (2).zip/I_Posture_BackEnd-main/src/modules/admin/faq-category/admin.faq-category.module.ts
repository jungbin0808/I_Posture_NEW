import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';
import { AdminFaqCategoryController } from './admin.faq-category.controller';
import { AdminFaqCategoryService } from './admin.faq-category.service';

@Module({
  imports: [TypeOrmModule.forFeature([FaqCategoryEntity])],
  controllers: [AdminFaqCategoryController],
  providers: [AdminFaqCategoryService],
})
export class AdminFaqCategoryModule {}
