import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, Min } from 'class-validator';
import { FaqTargetRole } from '../../../../database/entities/faq.entity';

export class CreateFaqCategoryDto {
  @IsNotEmpty()
  @IsString()
  name!: string;

  @IsOptional()
  @IsInt()
  @Min(0)
  sortOrder?: number; // 기본값 = 0 제거

  @IsOptional()
  @IsBoolean()
  isActive?: boolean = true;

  @ApiProperty({ enum: FaqTargetRole, required: false, description: '노출 대상 (기본값 ALL)' })
  @IsOptional()
  @IsEnum(FaqTargetRole)
  targetRole?: FaqTargetRole;
}
