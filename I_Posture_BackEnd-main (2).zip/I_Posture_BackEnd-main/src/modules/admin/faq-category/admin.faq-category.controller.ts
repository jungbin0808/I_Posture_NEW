import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common'; // Put 추가
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { IPageData, IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { AdminFaqCategoryService } from './admin.faq-category.service';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';
import { CreateFaqCategoryDto } from './dto/create-faq-category.dto';
import { UpdateFaqCategoryDto } from './dto/update-faq-category.dto';
import { FindFaqCategoryDto } from './dto/find-faq-category.dto';

@ApiTags('Admin - FaqCategory')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/faq-categories')
export class AdminFaqCategoryController {
  constructor(private readonly service: AdminFaqCategoryService) {}

  @ApiOperation({ summary: 'Get All FAQ Categories' })
  @Get()
  async findAll(@Query() findDto: FindFaqCategoryDto): Promise<IPageResponse<FaqCategoryEntity>> {
    const pageData: IPageData<FaqCategoryEntity> = await this.service.findAll(findDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Get FAQ Category Detail' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<FaqCategoryEntity>> {
    const category = await this.service.findOne(id);
    return SuccessResponse(category);
  }

  @ApiOperation({ summary: 'Create FAQ Category' })
  @Post()
  async create(@Body() createDto: CreateFaqCategoryDto): Promise<ISuccessResponse<FaqCategoryEntity>> {
    const category = await this.service.create(createDto);
    return SuccessResponse(category);
  }

  @ApiOperation({ summary: 'Update FAQ Category' })
  @Put(':id') // @Patch -> @Put 변경
  async update(@Param('id') id: string, @Body() updateDto: UpdateFaqCategoryDto): Promise<ISuccessResponse<FaqCategoryEntity>> {
    const category = await this.service.update(id, updateDto);
    return SuccessResponse(category);
  }

  @ApiOperation({ summary: 'Delete FAQ Category' })
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ISuccessResponse<{ success: boolean }>> {
    const success = await this.service.remove(id);
    return SuccessResponse({ success: success });
  }
}
