import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';
import { CreateFaqCategoryDto } from './dto/create-faq-category.dto';
import { UpdateFaqCategoryDto } from './dto/update-faq-category.dto';
import { FindFaqCategoryDto } from './dto/find-faq-category.dto';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';

@Injectable()
export class AdminFaqCategoryService {
  constructor(
    @InjectRepository(FaqCategoryEntity)
    private readonly faqCategoryRepo: Repository<FaqCategoryEntity>,
  ) {}

  async findAll(findDto: FindFaqCategoryDto): Promise<IPageData<FaqCategoryEntity>> {
    const { page = 1, limit = 10, search } = findDto;
    const queryBuilder: SelectQueryBuilder<FaqCategoryEntity> = this.faqCategoryRepo.createQueryBuilder('category');

    queryBuilder.orderBy('category.sortOrder', 'ASC').skip((page - 1) * limit).take(limit);

    if (search) {
      queryBuilder.andWhere('category.name LIKE :search', { search: `%${search}%` });
    }

    const [categories, total] = await queryBuilder.getManyAndCount();
    return { items: categories, paging: buildPaging(total, limit, page) };
  }

  async findOne(id: string): Promise<FaqCategoryEntity> {
    const category = await this.faqCategoryRepo.findOne({ where: { id: id } });
    if (!category) {
      throw new NotFoundException(`FaqCategory with ID "${id}" not found`);
    }
    return category;
  }

  async create(createDto: CreateFaqCategoryDto): Promise<FaqCategoryEntity> {
    // sortOrder가 입력되지 않았을 경우, 자동으로 Max + 1 값 할당
    if (createDto.sortOrder === undefined || createDto.sortOrder === null) {
      const maxOrderResult = await this.faqCategoryRepo
        .createQueryBuilder('category')
        .select('MAX(category.sortOrder)', 'max')
        .getRawOne();

      const maxOrder = maxOrderResult && maxOrderResult.max !== null ? parseInt(maxOrderResult.max, 10) : 0;
      createDto.sortOrder = maxOrder + 1;
    }

    const newCategory = this.faqCategoryRepo.create(createDto);
    return this.faqCategoryRepo.save(newCategory);
  }

  async update(id: string, updateDto: UpdateFaqCategoryDto): Promise<FaqCategoryEntity> {
    const category = await this.findOne(id);
    Object.assign(category, updateDto);
    return this.faqCategoryRepo.save(category);
  }

  async remove(id: string): Promise<boolean> {
    const result = await this.faqCategoryRepo.softDelete({ id: id });
    return result.affected ? result.affected > 0 : false;
  }
}
