import { Controller, Param, ParseUUIDPipe, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiQuery, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { SubscriptionScheduler } from '../../subscription/subscription.scheduler';

@ApiTags('Admin - Subscription')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/subscriptions')
export class AdminSubscriptionController {
  constructor(private readonly subscriptionScheduler: SubscriptionScheduler) {}

  @ApiOperation({ summary: '구독 자동갱신 1건 수동 실행 (스케줄러 테스트)' })
  @ApiQuery({ name: 'force', required: false, description: 'true면 next_billing_date 무시하고 즉시 실행' })
  @Post(':id/renewal')
  async triggerRenewal(
    @Param('id', ParseUUIDPipe) id: string,
    @Query('force') force?: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    await this.subscriptionScheduler.renewSubscriptionById(id, { force: force === 'true' });
    return SuccessResponse({ success: true });
  }
}
