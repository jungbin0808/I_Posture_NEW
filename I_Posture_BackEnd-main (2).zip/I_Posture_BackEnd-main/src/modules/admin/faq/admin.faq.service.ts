import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';
import { FaqEntity } from '../../../database/entities/faq.entity';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';
import { FindFaqDto } from '../../faq/dto/find-faq.dto';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';

@Injectable()
export class AdminFaqService {
  constructor(
    @InjectRepository(FaqCategoryEntity)
    private readonly faqCategoryRepo: Repository<FaqCategoryEntity>,
    @InjectRepository(FaqEntity)
    private readonly faqRepo: Repository<FaqEntity>,
  ) {}

  async findAll(findFaqDto: FindFaqDto): Promise<IPageData<FaqEntity>> {
    const { page = 1, limit = 10, search, targetRole, faqCategory } = findFaqDto;
    const queryBuilder: SelectQueryBuilder<FaqEntity> = this.faqRepo.createQueryBuilder('faq');

    queryBuilder
      .leftJoinAndSelect('faq.category', 'category')
      .orderBy('faq.createdAt', 'DESC')
      .skip((page - 1) * limit)
      .take(limit);

    if (search) {
      queryBuilder.andWhere('faq.title LIKE :search', { search: `%${search}%` });
    }
    if (targetRole) {
      queryBuilder.andWhere('faq.targetRole = :targetRole', { targetRole: targetRole });
    }
    if (faqCategory) {
      queryBuilder.andWhere('category.id = :faqCategory', { faqCategory: faqCategory });
    }

    const [faqs, total] = await queryBuilder.getManyAndCount();
    return { items: faqs, paging: buildPaging(total, limit, page) };
  }

  async findOne(id: string): Promise<FaqEntity> {
    const faq = await this.faqRepo.findOne({ where: { id: id }, relations: ['category'] });
    if (!faq) {
      throw new NotFoundException(`FAQ with ID "${id}" not found`);
    }
    return faq;
  }

  async create(createFaqDto: CreateFaqDto): Promise<FaqEntity> {
    const category = await this.faqCategoryRepo.findOne({ where: { id: createFaqDto.categoryId } });
    if (!category) {
      throw new NotFoundException(`FaqCategory with ID "${createFaqDto.categoryId}" not found`);
    }
    const newFaq = this.faqRepo.create(createFaqDto);
    return this.faqRepo.save(newFaq);
  }

  async update(id: string, updateFaqDto: UpdateFaqDto): Promise<FaqEntity> {
    const faq = await this.findOne(id);

    if (updateFaqDto.categoryId !== undefined) {
      const category = await this.faqCategoryRepo.findOne({ where: { id: updateFaqDto.categoryId } });
      if (!category) {
        throw new NotFoundException(`FaqCategory with ID "${updateFaqDto.categoryId}" not found`);
      }
    }

    Object.assign(faq, updateFaqDto);
    return this.faqRepo.save(faq);
  }

  async remove(id: string): Promise<boolean> {
    const result = await this.faqRepo.softDelete({ id: id });
    return result.affected ? result.affected > 0 : false;
  }
}
