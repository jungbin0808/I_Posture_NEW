import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common'; // Put 추가
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { IPageData, IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { FaqEntity } from '../../../database/entities/faq.entity';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { CreateFaqDto } from './dto/create-faq.dto';
import { UpdateFaqDto } from './dto/update-faq.dto';
import { AdminFaqService } from './admin.faq.service';
import { FindFaqDto } from '../../faq/dto/find-faq.dto';

@ApiTags('Admin - Faq')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/faqs')
export class AdminFaqController {
  constructor(private readonly adminFaqService: AdminFaqService) {}

  @ApiOperation({ summary: 'Get FAQ List' })
  @Get()
  async findAll(@Query() findFaqDto: FindFaqDto): Promise<IPageResponse<FaqEntity>> {
    const pageData: IPageData<FaqEntity> = await this.adminFaqService.findAll(findFaqDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Get FAQ Detail' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<FaqEntity>> {
    const faq = await this.adminFaqService.findOne(id);
    return SuccessResponse(faq);
  }

  @ApiOperation({ summary: 'Create FAQ' })
  @Post()
  async create(@Body() createFaqDto: CreateFaqDto): Promise<ISuccessResponse<FaqEntity>> {
    const faq = await this.adminFaqService.create(createFaqDto);
    return SuccessResponse(faq);
  }

  @ApiOperation({ summary: 'Update FAQ' })
  @Put(':id') // @Patch -> @Put 변경
  async update(@Param('id') id: string, @Body() updateFaqDto: UpdateFaqDto): Promise<ISuccessResponse<FaqEntity>> {
    const faq = await this.adminFaqService.update(id, updateFaqDto);
    return SuccessResponse(faq);
  }

  @ApiOperation({ summary: 'Delete FAQ' })
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ISuccessResponse<{ success: boolean }>> {
    const success = await this.adminFaqService.remove(id);
    return SuccessResponse({ success: success });
  }
}
