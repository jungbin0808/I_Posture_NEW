import { IsBoolean, IsEnum, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';
import { FaqTargetRole } from '../../../../database/entities/faq.entity';

export class CreateFaqDto {
  @IsNotEmpty()
  @IsUUID()
  categoryId!: string; // ! 추가

  @IsNotEmpty()
  @IsEnum(FaqTargetRole)
  targetRole!: FaqTargetRole; // ! 추가

  @IsNotEmpty()
  @IsString()
  title!: string; // ! 추가

  @IsNotEmpty()
  @IsString()
  content!: string; // ! 추가

  @IsOptional()
  @IsBoolean()
  isVisible?: boolean = true;
}
