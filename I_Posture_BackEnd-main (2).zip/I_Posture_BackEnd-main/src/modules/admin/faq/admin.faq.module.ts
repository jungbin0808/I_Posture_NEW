import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AdminFaqController } from './admin.faq.controller';
import { AdminFaqService } from './admin.faq.service';
import { FaqEntity } from '../../../database/entities/faq.entity';
import { FaqCategoryEntity } from '../../../database/entities/faq-category.entity';

@Module({
  imports: [TypeOrmModule.forFeature([FaqEntity, FaqCategoryEntity])],
  controllers: [AdminFaqController],
  providers: [AdminFaqService],
})
export class AdminFaqModule {}
