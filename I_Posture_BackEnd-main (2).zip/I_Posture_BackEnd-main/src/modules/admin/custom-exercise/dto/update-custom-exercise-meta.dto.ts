import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsInt, IsOptional, IsString, Min } from 'class-validator';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

/**
 * category/mainCat/subCat/detailCat/level/youtubeUrl은 체형유형 매칭에 쓰이는 값이라
 * 이 API에서는 다루지 않음 - 제목/썸네일/재생시간/NEW뱃지 메타데이터만 보완.
 */
export class UpdateCustomExerciseMetaDto {
  @ApiProperty({ description: '영상 제목, 빈 문자열 전달 시 제거', required: false, maxLength: 200 })
  @IsString()
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '영상 길이(초)', required: false, example: 90 })
  @Transform(({ value }) => (value === undefined || value === '' ? value : Number(value)))
  @IsInt()
  @Min(0)
  @IsOptional()
  durationSeconds?: number;

  @ApiProperty({ description: 'NEW 뱃지 노출 여부', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  isNew?: boolean;
}
