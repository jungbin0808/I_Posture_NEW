import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsEnum, IsOptional, IsString } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

export enum CustomExerciseCategoryFilter {
  BODY_BALANCE = 'BODY_BALANCE',
  INBODY_DIET = 'INBODY_DIET',
  LINE_DIET = 'LINE_DIET',
  FACE_CARE = 'FACE_CARE',
}

export class FindCustomExerciseDto extends PaginationDto {
  @ApiProperty({ enum: CustomExerciseCategoryFilter, required: false, description: '미전달 시 전체 카테고리' })
  @IsEnum(CustomExerciseCategoryFilter)
  @IsOptional()
  category?: CustomExerciseCategoryFilter;

  @ApiProperty({ description: 'mainCat/subCat/detailCat/title LIKE 검색', required: false })
  @IsString()
  @IsOptional()
  search?: string;

  @ApiProperty({ description: '제목/썸네일/재생시간이 전부 비어있는(보완 안 된) 항목만 조회', required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  onlyIncomplete?: boolean;
}
