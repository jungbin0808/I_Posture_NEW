import { Body, Controller, Get, Param, Put, Query, Req, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { CustomExerciseEntity } from '../../../database/entities/custom-exercise.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AdminCustomExerciseService } from './admin-custom-exercise.service';
import { FindCustomExerciseDto } from './dto/find-custom-exercise.dto';
import { UpdateCustomExerciseMetaDto } from './dto/update-custom-exercise-meta.dto';

/**
 * 맞춤운동(체형/인바디 매칭 엔진) 자체는 docs/맞춤운동_파싱.md 표를 시딩해서 관리 -
 * 이 컨트롤러는 category/mainCat/subCat/detailCat/level/youtubeUrl(매칭용 데이터)은 건드리지 않고,
 * 제목/썸네일/재생시간/NEW뱃지 메타데이터만 보완하는 용도.
 */
@ApiTags('Admin - Custom Exercise')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/custom-exercises')
export class AdminCustomExerciseController {
  constructor(private readonly service: AdminCustomExerciseService) {}

  @ApiOperation({ summary: '맞춤운동 목록 조회 (카테고리 필터 + 검색 + 보완 필요 항목만 조회)' })
  @Get()
  async findAll(@Query() dto: FindCustomExerciseDto): Promise<IPageResponse<CustomExerciseEntity>> {
    const pageData = await this.service.findAll(dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '맞춤운동 상세 조회' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<CustomExerciseEntity>> {
    const exercise = await this.service.findOne(id);
    return SuccessResponse(exercise);
  }

  @ApiOperation({ summary: '맞춤운동 메타데이터 보완 (제목/썸네일/재생시간/NEW뱃지만 수정, 매칭 데이터는 변경 불가)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        thumbnail: { type: 'string', format: 'binary', description: '썸네일 이미지 (선택)' },
        title: { type: 'string' },
        durationSeconds: { type: 'number' },
        isNew: { type: 'boolean' },
      },
    },
  })
  @Put(':id')
  @UseInterceptors(FileInterceptor('thumbnail'))
  async updateMeta(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: UpdateCustomExerciseMetaDto,
    @UploadedFile() thumbnail?: Express.Multer.File,
  ): Promise<ISuccessResponse<CustomExerciseEntity>> {
    const exercise = await this.service.updateMeta(req.user, id, dto, thumbnail);
    return SuccessResponse(exercise);
  }
}
