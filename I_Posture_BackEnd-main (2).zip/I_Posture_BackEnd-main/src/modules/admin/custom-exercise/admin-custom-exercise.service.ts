import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, SelectQueryBuilder } from 'typeorm';
import { CustomExerciseEntity } from '../../../database/entities/custom-exercise.entity';
import { FileOwnerType, FileRelatedType } from '../../../database/entities/file.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { S3Service } from '../../../s3/s3.service';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { FindCustomExerciseDto } from './dto/find-custom-exercise.dto';
import { UpdateCustomExerciseMetaDto } from './dto/update-custom-exercise-meta.dto';

@Injectable()
export class AdminCustomExerciseService {
  constructor(
    @InjectRepository(CustomExerciseEntity)
    private readonly exerciseRepo: Repository<CustomExerciseEntity>,
    private readonly s3Service: S3Service,
  ) {}

  async findAll(dto: FindCustomExerciseDto): Promise<IPageData<CustomExerciseEntity>> {
    const { page = 1, limit = 10, category, search, onlyIncomplete } = dto;
    const qb: SelectQueryBuilder<CustomExerciseEntity> = this.exerciseRepo
      .createQueryBuilder('e')
      .orderBy('e.category', 'ASC')
      .addOrderBy('e.sortOrder', 'ASC')
      .skip((page - 1) * limit)
      .take(limit);

    if (category) {
      qb.andWhere('e.category = :category', { category });
    }
    if (search) {
      qb.andWhere(
        '(e.mainCat LIKE :search OR e.subCat LIKE :search OR e.detailCat LIKE :search OR e.title LIKE :search)',
        { search: `%${search}%` },
      );
    }
    if (onlyIncomplete) {
      qb.andWhere('e.title IS NULL AND e.thumbnailUrl IS NULL AND e.durationSeconds IS NULL');
    }

    const [items, total] = await qb.getManyAndCount();
    return { items, paging: buildPaging(total, limit, page) };
  }

  async findOne(id: string): Promise<CustomExerciseEntity> {
    const exercise = await this.exerciseRepo.findOne({ where: { id } });
    if (!exercise) throw new NotFoundException('맞춤운동을 찾을 수 없습니다.');
    return exercise;
  }

  async updateMeta(
    admin: UserEntity,
    id: string,
    dto: UpdateCustomExerciseMetaDto,
    thumbnail?: Express.Multer.File,
  ): Promise<CustomExerciseEntity> {
    const exercise = await this.findOne(id);

    if (thumbnail) {
      const uploaded = await this.s3Service.uploadFile(thumbnail, {
        memberId: admin.id,
        uploaderId: admin.id,
        ownerType: FileOwnerType.ADMIN,
        ownerId: admin.id,
        relatedType: FileRelatedType.EXERCISE,
      });
      exercise.thumbnailUrl = uploaded.fileUrl;
    }

    if (dto.title !== undefined) exercise.title = dto.title || null;
    if (dto.durationSeconds !== undefined) exercise.durationSeconds = dto.durationSeconds;
    if (dto.isNew !== undefined) exercise.isNew = dto.isNew;

    return this.exerciseRepo.save(exercise);
  }
}
