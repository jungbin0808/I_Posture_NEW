import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CustomExerciseEntity } from '../../../database/entities/custom-exercise.entity';
import { S3Module } from '../../../s3/s3.module';
import { AdminCustomExerciseController } from './admin-custom-exercise.controller';
import { AdminCustomExerciseService } from './admin-custom-exercise.service';

@Module({
  imports: [TypeOrmModule.forFeature([CustomExerciseEntity]), S3Module],
  controllers: [AdminCustomExerciseController],
  providers: [AdminCustomExerciseService],
})
export class AdminCustomExerciseModule {}
