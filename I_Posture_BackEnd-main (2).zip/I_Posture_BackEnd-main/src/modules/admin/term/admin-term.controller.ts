import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { TermEntity } from '../../../database/entities/term.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AdminTermService } from './admin-term.service';
import { CreateTermDto } from './dto/create-term.dto';
import { UpdateTermDto } from './dto/update-term.dto';
import { FindTermDto } from './dto/find-term.dto';

@ApiTags('Admin - Term')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/terms')
export class AdminTermController {
  constructor(private readonly adminTermService: AdminTermService) {}

  @ApiOperation({ summary: '약관 목록 조회' })
  @Get()
  async findAll(@Query() dto: FindTermDto): Promise<IPageResponse<TermEntity>> {
    const pageData = await this.adminTermService.findAll(dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '약관 상세 조회' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<TermEntity>> {
    const term = await this.adminTermService.findOne(id);
    return SuccessResponse(term);
  }

  @ApiOperation({ summary: '약관 등록 (새 버전 생성 시 isActive:true면 같은 type 기존 활성 약관 자동 비활성화)' })
  @Post()
  async create(@Body() dto: CreateTermDto): Promise<ISuccessResponse<TermEntity>> {
    const term = await this.adminTermService.create(dto);
    return SuccessResponse(term);
  }

  @ApiOperation({ summary: '약관 수정' })
  @Put(':id')
  async update(@Param('id') id: string, @Body() dto: UpdateTermDto): Promise<ISuccessResponse<TermEntity>> {
    const term = await this.adminTermService.update(id, dto);
    return SuccessResponse(term);
  }

  @ApiOperation({ summary: '약관 삭제 (실제로는 비활성화 처리 — 과거 동의 이력 보존)' })
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.adminTermService.remove(id);
    return SuccessResponse(result);
  }
}
