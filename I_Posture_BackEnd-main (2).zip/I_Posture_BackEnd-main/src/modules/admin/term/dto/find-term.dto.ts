import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { TermType } from '../../../../database/entities/term.entity';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

export class FindTermDto extends PaginationDto {
  @ApiProperty({ enum: TermType, required: false, description: '미전달 시 전체 타입' })
  @IsEnum(TermType)
  @IsOptional()
  type?: TermType;

  @ApiProperty({ required: false, description: '미전달 시 활성/비활성 전부' })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
