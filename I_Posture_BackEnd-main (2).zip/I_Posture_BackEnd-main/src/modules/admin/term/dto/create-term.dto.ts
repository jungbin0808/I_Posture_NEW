import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsEnum, IsNotEmpty, IsOptional, IsString, MaxLength } from 'class-validator';
import { TermType } from '../../../../database/entities/term.entity';

export class CreateTermDto {
  @ApiProperty({ enum: TermType, description: '약관 구분 코드' })
  @IsEnum(TermType)
  type!: TermType;

  @ApiProperty({ description: '약관명 (화면 표시용)', maxLength: 100 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  title!: string;

  @ApiProperty({ description: '약관 내용 (HTML)' })
  @IsString()
  @IsNotEmpty()
  content!: string;

  @ApiProperty({ description: '약관 버전 문자열', required: false, example: '1.0' })
  @IsString()
  @IsOptional()
  version?: string;

  @ApiProperty({ description: '필수 동의 여부', required: false, example: true })
  @IsBoolean()
  @IsOptional()
  isRequired?: boolean;

  @ApiProperty({ description: '현재 사용 여부 (true면 같은 type의 기존 활성 약관은 자동 비활성화)', required: false, example: true })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
