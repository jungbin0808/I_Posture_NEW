import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsOptional, IsString, MaxLength } from 'class-validator';

export class UpdateTermDto {
  @ApiProperty({ description: '약관명 (화면 표시용)', required: false, maxLength: 100 })
  @IsString()
  @MaxLength(100)
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '약관 내용 (HTML)', required: false })
  @IsString()
  @IsOptional()
  content?: string;

  @ApiProperty({ description: '약관 버전 문자열', required: false })
  @IsString()
  @IsOptional()
  version?: string;

  @ApiProperty({ description: '필수 동의 여부', required: false })
  @IsBoolean()
  @IsOptional()
  isRequired?: boolean;

  @ApiProperty({ description: '현재 사용 여부 (true로 바꾸면 같은 type의 기존 활성 약관은 자동 비활성화)', required: false })
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
