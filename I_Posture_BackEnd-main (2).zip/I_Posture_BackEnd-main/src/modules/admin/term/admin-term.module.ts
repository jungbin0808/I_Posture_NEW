import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TermEntity } from '../../../database/entities/term.entity';
import { AdminTermController } from './admin-term.controller';
import { AdminTermService } from './admin-term.service';

@Module({
  imports: [TypeOrmModule.forFeature([TermEntity])],
  controllers: [AdminTermController],
  providers: [AdminTermService],
})
export class AdminTermModule {}
