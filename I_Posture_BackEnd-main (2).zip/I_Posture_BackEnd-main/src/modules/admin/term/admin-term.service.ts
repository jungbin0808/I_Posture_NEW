import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { TermEntity } from '../../../database/entities/term.entity';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { CreateTermDto } from './dto/create-term.dto';
import { UpdateTermDto } from './dto/update-term.dto';
import { FindTermDto } from './dto/find-term.dto';

@Injectable()
export class AdminTermService {
  constructor(
    @InjectRepository(TermEntity)
    private readonly termRepo: Repository<TermEntity>,
  ) {}

  async findAll(dto: FindTermDto): Promise<IPageData<TermEntity>> {
    const { page = 1, limit = 10, type, isActive } = dto;
    const where: Record<string, unknown> = {};
    if (type) where.type = type;
    if (isActive !== undefined) where.isActive = isActive;

    const [items, total] = await this.termRepo.findAndCount({
      where,
      order: { type: 'ASC', createdAt: 'DESC' },
      skip: (page - 1) * limit,
      take: limit,
    });
    return { items, paging: buildPaging(total, limit, page) };
  }

  async findOne(id: string): Promise<TermEntity> {
    const term = await this.termRepo.findOne({ where: { id } });
    if (!term) throw new NotFoundException('약관을 찾을 수 없습니다.');
    return term;
  }

  @Transactional()
  async create(dto: CreateTermDto): Promise<TermEntity> {
    const isActive = dto.isActive ?? true;
    if (isActive) {
      await this.termRepo.update({ type: dto.type, isActive: true }, { isActive: false });
    }

    const term = this.termRepo.create({
      type: dto.type,
      title: dto.title,
      content: dto.content,
      version: dto.version,
      isRequired: dto.isRequired ?? true,
      isActive,
    });
    return this.termRepo.save(term);
  }

  @Transactional()
  async update(id: string, dto: UpdateTermDto): Promise<TermEntity> {
    const term = await this.findOne(id);

    if (dto.isActive === true && !term.isActive) {
      await this.termRepo.update({ type: term.type, isActive: true }, { isActive: false });
    }

    if (dto.title !== undefined) term.title = dto.title;
    if (dto.content !== undefined) term.content = dto.content;
    if (dto.version !== undefined) term.version = dto.version;
    if (dto.isRequired !== undefined) term.isRequired = dto.isRequired;
    if (dto.isActive !== undefined) term.isActive = dto.isActive;

    return this.termRepo.save(term);
  }

  /** TermEntity에는 소프트삭제 컬럼이 없어 실제 삭제 대신 비활성화로 처리 (과거 user_agreements 이력 보존) */
  async remove(id: string): Promise<{ success: boolean }> {
    const term = await this.findOne(id);
    term.isActive = false;
    await this.termRepo.save(term);
    return { success: true };
  }
}
