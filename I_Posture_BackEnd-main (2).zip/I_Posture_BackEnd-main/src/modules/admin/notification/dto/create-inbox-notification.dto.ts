import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import {
  IsArray,
  IsBoolean,
  IsEnum,
  IsIn,
  IsObject,
  IsOptional,
  IsString,
  ArrayNotEmpty,
} from 'class-validator';
import { UserType } from '../../../../database/entities/user.entity';
import { UserNotificationType } from '../../../../database/entities/user-notification.entity';

export class CreateInboxNotificationDto {
  @ApiProperty({ description: '알림 유형', enum: [UserNotificationType.NOTICE, UserNotificationType.EVENT] })
  @IsIn([UserNotificationType.NOTICE, UserNotificationType.EVENT])
  type!: UserNotificationType.NOTICE | UserNotificationType.EVENT;

  @ApiProperty({ description: '알림 제목' })
  @IsString()
  title!: string;

  @ApiProperty({ description: '알림 본문' })
  @IsString()
  body!: string;

  @ApiProperty({ description: '추가 데이터 (딥링크 등)', required: false })
  @IsOptional()
  @IsObject()
  data?: Record<string, string>;

  @ApiProperty({
    description: '발송 대상 유저 유형',
    enum: UserType,
    isArray: true,
    example: [UserType.CENTER],
  })
  @IsArray()
  @ArrayNotEmpty()
  @IsEnum(UserType, { each: true })
  targetUserTypes!: UserType[];

  @ApiProperty({ description: '푸시 알림 동시 발송 여부', required: false, default: false })
  @IsOptional()
  @Type(() => Boolean)
  @IsBoolean()
  sendPush?: boolean;
}
