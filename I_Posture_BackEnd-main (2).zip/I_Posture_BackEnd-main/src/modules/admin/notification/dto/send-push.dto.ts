import { IsOptional, IsString } from 'class-validator';

export class SendPushDto {
  @IsString()
  userId!: string;

  @IsString()
  title!: string;

  @IsString()
  body!: string;

  @IsOptional()
  data?: Record<string, string>;
}
