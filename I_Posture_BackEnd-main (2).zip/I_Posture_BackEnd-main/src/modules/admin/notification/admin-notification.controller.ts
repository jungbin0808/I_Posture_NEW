import { Body, Controller, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { FcmService } from '../../notification/fcm.service';
import { UserNotificationService } from '../../notification/user-notification.service';
import { UserNotificationType } from '../../../database/entities/user-notification.entity';
import { SendPushDto } from './dto/send-push.dto';
import { CreateInboxNotificationDto } from './dto/create-inbox-notification.dto';

@ApiTags('Admin - Notification')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/notifications')
export class AdminNotificationController {
  constructor(
    private readonly fcmService: FcmService,
    private readonly userNotificationService: UserNotificationService,
  ) {}

  @ApiOperation({ summary: '공지/이벤트 알림 inbox 등록 (대상 유저 유형 일괄)' })
  @Post('inbox')
  async createInbox(
    @Body() dto: CreateInboxNotificationDto,
  ): Promise<ISuccessResponse<{ createdCount: number }>> {
    const result = await this.userNotificationService.broadcastToUserTypes(dto.targetUserTypes, {
      type: dto.type,
      title: dto.title,
      body: dto.body,
      data: dto.data,
    });

    if (dto.sendPush && result.userIds.length > 0) {
      const notificationField =
        dto.type === UserNotificationType.EVENT ? 'notificationEventMarketing'
          : dto.type === UserNotificationType.NOTICE ? 'notificationNotice'
          : undefined;
      await this.fcmService.sendToUsers(
        result.userIds,
        { title: dto.title, body: dto.body, data: dto.data },
        notificationField,
        { skipInbox: true },
      );
    }

    return SuccessResponse({ createdCount: result.createdCount });
  }

  @ApiOperation({ summary: '특정 유저에게 푸시 알림 발송' })
  @Post('push')
  async sendPush(@Body() dto: SendPushDto): Promise<ISuccessResponse<{ sent: boolean }>> {
    const sent = await this.fcmService.sendToUser(dto.userId, {
      title: dto.title,
      body: dto.body,
      data: dto.data,
    });
    return SuccessResponse({ sent });
  }
}
