import { Module } from '@nestjs/common';
import { AdminNotificationController } from './admin-notification.controller';

@Module({
  controllers: [AdminNotificationController],
})
export class AdminNotificationModule {}
