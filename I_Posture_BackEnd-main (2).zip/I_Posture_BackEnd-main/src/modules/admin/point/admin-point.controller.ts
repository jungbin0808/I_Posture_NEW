import { Body, Controller, Post, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AdminPointService } from './admin-point.service';
import { AdjustPointDto } from './dto/adjust-point.dto';
import { PointHistoryEntity } from '../../../database/entities/point-history.entity';

@ApiTags('Admin - Point')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/points')
export class AdminPointController {
  constructor(private readonly adminPointService: AdminPointService) {}

  /**
   * @summary 관리자가 사용자 포인트 조정 (지급/차감)
   */
  @ApiOperation({ summary: 'Adjust user points (Give/Deduct)' })
  @Post('adjust')
  async adjustPoint(
    @Req() req: { user: UserEntity },
    @Body() adjustDto: AdjustPointDto,
  ): Promise<ISuccessResponse<PointHistoryEntity>> {
    const result = await this.adminPointService.adjustPoint(req.user.id, adjustDto);
    return SuccessResponse(result);
  }
}
