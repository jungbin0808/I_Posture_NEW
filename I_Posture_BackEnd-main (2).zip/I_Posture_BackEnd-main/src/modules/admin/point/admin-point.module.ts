import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { PointHistoryEntity } from '../../../database/entities/point-history.entity';
import { AdminPointLogEntity } from '../../../database/entities/admin-point-log.entity';
import { AdminPointController } from './admin-point.controller';
import { AdminPointService } from './admin-point.service';

@Module({
  imports: [TypeOrmModule.forFeature([UserEntity, PointHistoryEntity, AdminPointLogEntity])],
  controllers: [AdminPointController],
  providers: [AdminPointService],
})
export class AdminPointModule {}
