import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { PointHistoryEntity, PointHistoryType, PointSource } from '../../../database/entities/point-history.entity';
import { AdminPointLogEntity, AdminPointActionType } from '../../../database/entities/admin-point-log.entity';
import { FcmService } from '../../notification/fcm.service';
import { PUSH_DATA_TYPE } from '../../notification/push-notification-data.constant';
import { AdjustPointDto, PointAdjustmentType } from './dto/adjust-point.dto';
import { Transactional } from 'typeorm-transactional';

@Injectable()
export class AdminPointService {
  private readonly logger = new Logger(AdminPointService.name);

  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(PointHistoryEntity)
    private readonly pointHistoryRepo: Repository<PointHistoryEntity>,
    @InjectRepository(AdminPointLogEntity)
    private readonly adminPointLogRepo: Repository<AdminPointLogEntity>,
    private readonly fcmService: FcmService,
  ) {}

  @Transactional()
  async adjustPoint(adminId: string, dto: AdjustPointDto): Promise<PointHistoryEntity> {
    const { userId, type, amount, description } = dto;

    if (amount <= 0) {
      throw new BadRequestException('Amount must be greater than 0.');
    }

    const user = await this.userRepo.findOne({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException('User not found.');
    }

    const currentPoints = user.totalPoints || 0;
    let balanceAfter = currentPoints;
    let historyType: PointHistoryType;
    let actionType: AdminPointActionType;

    if (type === PointAdjustmentType.GIVE) {
      balanceAfter += amount;
      historyType = PointHistoryType.EARN;
      actionType = AdminPointActionType.GIVE;
    } else {
      if (currentPoints < amount) {
        throw new BadRequestException('Insufficient points to deduct.');
      }
      balanceAfter -= amount;
      historyType = PointHistoryType.USE;
      actionType = AdminPointActionType.DEDUCT;
    }

    // 1. 포인트 이력 생성 (point_history)
    const pointHistory = this.pointHistoryRepo.create({
      userId: user.id,
      type: historyType,
      source: PointSource.ADMIN,
      amount: amount,
      balanceAfter: balanceAfter,
      description: description || 'Admin adjustment',
    });
    const savedHistory = await this.pointHistoryRepo.save(pointHistory);

    // 2. 관리자 포인트 조정 로그 생성 (admin_point_logs)
    const adminLog = this.adminPointLogRepo.create({
      adminId: adminId,
      targetUserId: user.id,
      actionType: actionType,
      amount: amount,
      reason: description,
      pointHistoryId: savedHistory.id,
    });
    await this.adminPointLogRepo.save(adminLog);

    // 3. 사용자 총 포인트 업데이트
    user.totalPoints = balanceAfter;
    await this.userRepo.save(user);

    if (type === PointAdjustmentType.GIVE) {
      setImmediate(() => {
        this.fcmService.sendToUser(
          user.id,
          {
            title: '리워드가 도착했어요',
            body: '회원님의 리워드가 정상 지급되었습니다. 스토어에서 바로 사용해 보세요.',
            data: { type: PUSH_DATA_TYPE.POINT_SETTLEMENT },
          },
          'notificationPointSettlement',
        ).catch((error) => this.logger.error('리워드 지급 알림 발송 실패', error));
      });
    }

    return savedHistory;
  }
}
