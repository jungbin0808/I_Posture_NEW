import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, IsUUID } from 'class-validator';

export enum PointAdjustmentType {
  GIVE = 'GIVE',   // 지급 (적립)
  DEDUCT = 'DEDUCT', // 차감
}

export class AdjustPointDto {
  @ApiProperty({ description: '대상 회원 ID' })
  @IsUUID()
  @IsNotEmpty()
  userId!: string;

  @ApiProperty({ description: '조정 유형 (GIVE: 지급, DEDUCT: 차감)', enum: PointAdjustmentType })
  @IsEnum(PointAdjustmentType)
  @IsNotEmpty()
  type!: PointAdjustmentType;

  @ApiProperty({ description: '포인트 양 (양수)' })
  @IsInt()
  @IsNotEmpty()
  amount!: number;

  @ApiProperty({ description: '사유/메모', required: false })
  @IsString()
  @IsOptional()
  description?: string;
}
