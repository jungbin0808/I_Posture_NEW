import { Controller, Get, Param, ParseUUIDPipe, Patch, Req, Res, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiProduces, ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { UserEntity } from '../../../database/entities/user.entity';
import { UserService } from '../../user/user.service';
import { AdminUserExportService } from './admin-user-export.service';

@ApiTags('Admin - User')
@ApiBearerAuth()
@Controller('admin/users')
export class AdminUserController {
  constructor(
    private readonly userService: UserService,
    private readonly adminUserExportService: AdminUserExportService,
  ) {}

  /**
   * @summary 활성 트레이너(센터/개인) 목록 엑셀 다운로드 (비밀번호 보호)
   * SAC 어드민 미구축 — 로그인한 트레이너 계정에서 호출 (역할 가드 없음, 추후 Admin 전용으로 전환 예정)
   */
  @ApiOperation({ summary: 'Download active trainer list as password-protected Excel' })
  @ApiProduces('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
  @UseGuards(AccessTokenGuard)
  @Get('trainers/excel')
  async downloadActiveTrainerListExcel(
    @Req() req: { user: UserEntity },
    @Res() res: Response,
  ): Promise<void> {
    const { buffer, filename } = await this.adminUserExportService.buildActiveTrainerListExcel(req.user);

    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Content-Length': buffer.length,
    });
    res.send(buffer);
  }

  /**
   * @summary 탈퇴 계정 복구 (SAC)
   * - 계정 soft-delete 해제 및 ACTIVE 상태로 전환
   * - 센터/트레이너 관계, 회원 데이터, 식단일지는 복구하지 않음
   */
  @ApiOperation({ summary: 'Restore withdrawn user account' })
  @UseGuards(AccessTokenGuard, RolesGuard)
  @Roles(Role.Admin)
  @Patch(':id/restore-account')
  async restoreAccount(
    @Param('id', ParseUUIDPipe) id: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.userService.restoreAccountByAdmin(id);
    return SuccessResponse(result);
  }
}
