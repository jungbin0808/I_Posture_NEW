/**
 * 엑셀 export용 생성일 (DB UTC → KST, YYYY-MM-DD)
 */
export function formatTrainerExportCreatedAt(date: Date): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

/**
 * 엑셀 export용 전화번호 — 국내 형식(0으로 시작) 숫자만 통일 (+82 제거)
 */
export function normalizeTrainerExportPhone(phone: string): string {
  const digits = phone.replace(/\D/g, '');
  if (!digits) {
    return '';
  }

  if (digits.startsWith('82') && digits.length >= 10) {
    return `0${digits.slice(2)}`;
  }

  return digits;
}

/**
 * env CSV(로그인 user_id 목록) 파싱
 */
export function parseAllowedLoginUserIds(raw?: string): string[] {
  if (!raw?.trim()) {
    return [];
  }

  return [...new Set(raw.split(',').map((id) => id.trim()).filter(Boolean))];
}
