import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UserEntity } from '../../../database/entities/user.entity';
import { UserModule } from '../../user/user.module';
import { AdminUserController } from './admin-user.controller';
import { AdminUserExportService } from './admin-user-export.service';

@Module({
  imports: [TypeOrmModule.forFeature([UserEntity]), UserModule],
  controllers: [AdminUserController],
  providers: [AdminUserExportService],
})
export class AdminUserModule {}
