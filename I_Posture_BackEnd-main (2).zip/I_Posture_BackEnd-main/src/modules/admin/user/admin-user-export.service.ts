import { ForbiddenException, Injectable, InternalServerErrorException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import XlsxPopulate = require('xlsx-populate');
import { UserEntity, AccountStatus, UserType } from '../../../database/entities/user.entity';
import { CenterTrainerEntity, CenterTrainerStatus } from '../../../database/entities/center-trainer.entity';
import {
  formatTrainerExportCreatedAt,
  normalizeTrainerExportPhone,
  parseAllowedLoginUserIds,
} from './helpers/trainer-export-format.helper';

interface TrainerExportRow {
  loginUserId: string;
  createdAt: string;
  email: string;
  name: string;
  phone: string;
  centerName: string;
  trainerTypeLabel: string;
}

const EXPORT_HEADERS = [
  '유저아이디',
  '생성일',
  '이메일',
  '이름',
  '핸드폰번호',
  '센터명',
  '구분',
] as const;

@Injectable()
export class AdminUserExportService {
  constructor(
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    private readonly configService: ConfigService,
  ) {}

  async buildActiveTrainerListExcel(requester: UserEntity): Promise<{ buffer: Buffer; filename: string }> {
    this.assertAllowedExporter(requester);

    const password = this.configService.get<string>('ADMIN_TRAINER_LIST_EXCEL_PASSWORD');
    if (!password?.trim()) {
      throw new InternalServerErrorException('ADMIN_TRAINER_LIST_EXCEL_PASSWORD is not configured');
    }

    const trainers = await this.userRepo.find({
      where: {
        userType: In([UserType.C_TRAINER, UserType.F_TRAINER]),
        accountStatus: AccountStatus.ACTIVE,
      },
      relations: ['centerAffiliations', 'centerAffiliations.center'],
      order: { createdAt: 'DESC' },
    });

    const rows = trainers.map((trainer) => this.toExportRow(trainer));
    const workbook = await this.buildWorkbook(rows);
    const buffer = await workbook.outputAsync({
      type: 'nodebuffer',
      password,
    });

    const filename = `trainer-list-${this.formatExportDate(new Date())}.xlsx`;
    return { buffer: buffer as Buffer, filename };
  }

  private assertAllowedExporter(requester: UserEntity): void {
    const allowedUserIds = parseAllowedLoginUserIds(
      this.configService.get<string>('ADMIN_TRAINER_LIST_EXCEL_ALLOWED_USER_IDS'),
    );
    if (allowedUserIds.length === 0) {
      throw new InternalServerErrorException('ADMIN_TRAINER_LIST_EXCEL_ALLOWED_USER_IDS is not configured');
    }
    if (!allowedUserIds.includes(requester.userId)) {
      throw new ForbiddenException('엑셀 다운로드 권한이 없습니다.');
    }
  }

  private toExportRow(trainer: UserEntity): TrainerExportRow {
    return {
      loginUserId: trainer.userId,
      createdAt: formatTrainerExportCreatedAt(trainer.createdAt),
      email: trainer.email,
      name: trainer.name,
      phone: normalizeTrainerExportPhone(trainer.phone ?? ''),
      centerName: this.resolveCenterName(trainer),
      trainerTypeLabel: trainer.userType === UserType.C_TRAINER ? '센터트레이너' : '개인트레이너',
    };
  }

  private resolveCenterName(trainer: UserEntity): string {
    if (trainer.userType !== UserType.C_TRAINER) {
      return '';
    }

    const affiliations = (trainer.centerAffiliations ?? []).filter(
      (affiliation: CenterTrainerEntity) =>
        affiliation.status === CenterTrainerStatus.WORKING && !affiliation.deletedAt,
    );

    const centerNames = affiliations
      .map((affiliation) => affiliation.center?.name)
      .filter((name): name is string => Boolean(name));

    return [...new Set(centerNames)].join(', ');
  }

  private async buildWorkbook(rows: TrainerExportRow[]) {
    const workbook = await XlsxPopulate.fromBlankAsync();
    const sheet = workbook.sheet(0);
    sheet.name('트레이너 목록');

    EXPORT_HEADERS.forEach((header, columnIndex) => {
      sheet.cell(1, columnIndex + 1).value(header).style('bold', true);
    });

    rows.forEach((row, rowIndex) => {
      const excelRow = rowIndex + 2;
      sheet.cell(excelRow, 1).value(row.loginUserId);
      sheet.cell(excelRow, 2).value(row.createdAt);
      sheet.cell(excelRow, 3).value(row.email);
      sheet.cell(excelRow, 4).value(row.name);
      sheet.cell(excelRow, 5).value(row.phone);
      sheet.cell(excelRow, 6).value(row.centerName);
      sheet.cell(excelRow, 7).value(row.trainerTypeLabel);
    });

    return workbook;
  }

  private formatExportDate(date: Date): string {
    return date.toISOString().slice(0, 10).replace(/-/g, '');
  }
}
