import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { BannerEntity } from '../../../database/entities/banner.entity';
import { FileOwnerType, FileRelatedType } from '../../../database/entities/file.entity';
import { UserEntity } from '../../../database/entities/user.entity';
import { S3Service } from '../../../s3/s3.service';
import { IPageData } from '../../../common/response/response.interface';
import { buildPaging } from '../../../common/response/response.helper';
import { CreateBannerDto } from './dto/create-banner.dto';
import { UpdateBannerDto } from './dto/update-banner.dto';
import { FindBannerDto } from './dto/find-banner.dto';

@Injectable()
export class AdminBannerService {
  constructor(
    @InjectRepository(BannerEntity)
    private readonly bannerRepo: Repository<BannerEntity>,
    private readonly s3Service: S3Service,
  ) {}

  async findAll(dto: FindBannerDto): Promise<IPageData<BannerEntity>> {
    const { page = 1, limit = 10, position } = dto;
    const [items, total] = await this.bannerRepo.findAndCount({
      where: position ? { position } : {},
      order: { position: 'ASC', sortOrder: 'ASC' },
      skip: (page - 1) * limit,
      take: limit,
    });
    return { items, paging: buildPaging(total, limit, page) };
  }

  async findOne(id: string): Promise<BannerEntity> {
    const banner = await this.bannerRepo.findOne({ where: { id } });
    if (!banner) throw new NotFoundException('배너를 찾을 수 없습니다.');
    return banner;
  }

  async create(admin: UserEntity, dto: CreateBannerDto, image: Express.Multer.File): Promise<BannerEntity> {
    if (!image) throw new BadRequestException('배너 이미지(image) 파일이 필요합니다.');

    const uploaded = await this.s3Service.uploadFile(image, {
      memberId: admin.id,
      uploaderId: admin.id,
      ownerType: FileOwnerType.ADMIN,
      ownerId: admin.id,
      relatedType: FileRelatedType.BANNER,
    });

    const banner = this.bannerRepo.create({
      position: dto.position,
      title: dto.title,
      imageUrl: uploaded.fileUrl,
      linkUrl: dto.linkUrl,
      sortOrder: dto.sortOrder ?? 0,
      isActive: dto.isActive ?? true,
    });
    return this.bannerRepo.save(banner);
  }

  async update(admin: UserEntity, id: string, dto: UpdateBannerDto, image?: Express.Multer.File): Promise<BannerEntity> {
    const banner = await this.findOne(id);

    if (image) {
      const uploaded = await this.s3Service.uploadFile(image, {
        memberId: admin.id,
        uploaderId: admin.id,
        ownerType: FileOwnerType.ADMIN,
        ownerId: admin.id,
        relatedType: FileRelatedType.BANNER,
      });
      banner.imageUrl = uploaded.fileUrl;
    }

    if (dto.position !== undefined) banner.position = dto.position;
    if (dto.title !== undefined) banner.title = dto.title;
    if (dto.linkUrl !== undefined) banner.linkUrl = dto.linkUrl || undefined;
    if (dto.sortOrder !== undefined) banner.sortOrder = dto.sortOrder;
    if (dto.isActive !== undefined) banner.isActive = dto.isActive;

    return this.bannerRepo.save(banner);
  }

  async remove(id: string): Promise<{ success: boolean }> {
    const result = await this.bannerRepo.softDelete({ id });
    return { success: (result.affected ?? 0) > 0 };
  }
}
