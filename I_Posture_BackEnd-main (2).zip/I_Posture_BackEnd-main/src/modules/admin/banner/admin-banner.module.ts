import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { BannerEntity } from '../../../database/entities/banner.entity';
import { S3Module } from '../../../s3/s3.module';
import { AdminBannerController } from './admin-banner.controller';
import { AdminBannerService } from './admin-banner.service';

@Module({
  imports: [TypeOrmModule.forFeature([BannerEntity]), S3Module],
  controllers: [AdminBannerController],
  providers: [AdminBannerService],
})
export class AdminBannerModule {}
