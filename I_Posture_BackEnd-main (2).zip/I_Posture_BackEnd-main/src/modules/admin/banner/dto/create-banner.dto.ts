import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, IsUrl, MaxLength } from 'class-validator';
import { BannerPosition } from '../../../../database/entities/banner.entity';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

export class CreateBannerDto {
  @ApiProperty({ enum: BannerPosition, description: '노출 위치 (HOME: 홈 화면, POINT: 포인트 화면)' })
  @IsEnum(BannerPosition)
  position!: BannerPosition;

  @ApiProperty({ description: '관리용 배너 이름 (화면 비노출)', maxLength: 100 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  title!: string;

  @ApiProperty({ description: '탭 시 이동할 링크 URL', required: false })
  @IsUrl()
  @IsOptional()
  linkUrl?: string;

  @ApiProperty({ description: '노출 순서 (오름차순, 미입력 시 0)', required: false, example: 0 })
  @Transform(({ value }) => (value === undefined || value === '' ? value : Number(value)))
  @IsInt()
  @IsOptional()
  sortOrder?: number;

  @ApiProperty({ description: '노출 여부 (미입력 시 true)', required: false, example: true })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
