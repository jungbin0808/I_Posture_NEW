import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsBoolean, IsEnum, IsInt, IsNotEmpty, IsOptional, IsString, IsUrl, MaxLength } from 'class-validator';
import { BannerPosition } from '../../../../database/entities/banner.entity';

const toBoolean = (value: unknown): boolean | unknown => {
  if (value === true || value === 'true' || value === 1 || value === '1') return true;
  if (value === false || value === 'false' || value === 0 || value === '0') return false;
  return value;
};

export class UpdateBannerDto {
  @ApiProperty({ enum: BannerPosition, required: false })
  @IsEnum(BannerPosition)
  @IsOptional()
  position?: BannerPosition;

  @ApiProperty({ required: false, maxLength: 100 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  @IsOptional()
  title?: string;

  @ApiProperty({ description: '탭 시 이동할 링크 URL, 빈 문자열 전달 시 제거', required: false })
  @IsString()
  @IsOptional()
  linkUrl?: string;

  @ApiProperty({ required: false })
  @Transform(({ value }) => (value === undefined || value === '' ? value : Number(value)))
  @IsInt()
  @IsOptional()
  sortOrder?: number;

  @ApiProperty({ required: false })
  @Transform(({ value }) => toBoolean(value))
  @IsBoolean()
  @IsOptional()
  isActive?: boolean;
}
