import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../../common/dto/pagination.dto';
import { BannerPosition } from '../../../../database/entities/banner.entity';

export class FindBannerDto extends PaginationDto {
  @ApiProperty({ enum: BannerPosition, required: false, description: '미전달 시 전체 위치' })
  @IsEnum(BannerPosition)
  @IsOptional()
  position?: BannerPosition;
}
