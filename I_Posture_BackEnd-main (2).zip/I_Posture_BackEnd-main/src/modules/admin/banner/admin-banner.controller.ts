import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../../auth/access-token.guard';
import { RolesGuard } from '../../../common/guards/roles.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { Role } from '../../../common/enums/role.enum';
import { UserEntity } from '../../../database/entities/user.entity';
import { BannerEntity } from '../../../database/entities/banner.entity';
import { IPageResponse, ISuccessResponse } from '../../../common/response/response.interface';
import { SuccessResponse } from '../../../common/response/response.helper';
import { AdminBannerService } from './admin-banner.service';
import { CreateBannerDto } from './dto/create-banner.dto';
import { UpdateBannerDto } from './dto/update-banner.dto';
import { FindBannerDto } from './dto/find-banner.dto';

@ApiTags('Admin - Banner')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.Admin)
@Controller('admin/banners')
export class AdminBannerController {
  constructor(private readonly adminBannerService: AdminBannerService) {}

  @ApiOperation({ summary: '배너 목록 조회 (위치별 필터)' })
  @Get()
  async findAll(@Query() dto: FindBannerDto): Promise<IPageResponse<BannerEntity>> {
    const pageData = await this.adminBannerService.findAll(dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '배너 상세 조회' })
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<ISuccessResponse<BannerEntity>> {
    const banner = await this.adminBannerService.findOne(id);
    return SuccessResponse(banner);
  }

  @ApiOperation({ summary: '배너 등록' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        image: { type: 'string', format: 'binary', description: '배너 이미지 (필수)' },
        position: { type: 'string', enum: ['HOME', 'POINT'] },
        title: { type: 'string' },
        linkUrl: { type: 'string' },
        sortOrder: { type: 'number' },
        isActive: { type: 'boolean' },
      },
      required: ['image', 'position', 'title'],
    },
  })
  @Post()
  @UseInterceptors(FileInterceptor('image'))
  async create(
    @Req() req: { user: UserEntity },
    @Body() dto: CreateBannerDto,
    @UploadedFile() image?: Express.Multer.File,
  ): Promise<ISuccessResponse<BannerEntity>> {
    if (!image) throw new BadRequestException('배너 이미지(image) 파일이 필요합니다.');
    const banner = await this.adminBannerService.create(req.user, dto, image);
    return SuccessResponse(banner);
  }

  @ApiOperation({ summary: '배너 수정 (이미지 교체는 선택)' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        image: { type: 'string', format: 'binary', description: '교체할 배너 이미지 (선택)' },
        position: { type: 'string', enum: ['HOME', 'POINT'] },
        title: { type: 'string' },
        linkUrl: { type: 'string' },
        sortOrder: { type: 'number' },
        isActive: { type: 'boolean' },
      },
    },
  })
  @Put(':id')
  @UseInterceptors(FileInterceptor('image'))
  async update(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() dto: UpdateBannerDto,
    @UploadedFile() image?: Express.Multer.File,
  ): Promise<ISuccessResponse<BannerEntity>> {
    const banner = await this.adminBannerService.update(req.user, id, dto, image);
    return SuccessResponse(banner);
  }

  @ApiOperation({ summary: '배너 삭제' })
  @Delete(':id')
  async remove(@Param('id') id: string): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.adminBannerService.remove(id);
    return SuccessResponse(result);
  }
}
