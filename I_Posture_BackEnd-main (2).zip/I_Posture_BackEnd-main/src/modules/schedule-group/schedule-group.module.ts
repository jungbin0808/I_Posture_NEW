import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ScheduleGroupEntity } from '../../database/entities/schedule-group.entity';
import { ScheduleGroupMemberEntity } from '../../database/entities/schedule-group-member.entity';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { ScheduleGroupController } from './schedule-group.controller';
import { ScheduleGroupService } from './schedule-group.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      ScheduleGroupEntity,
      ScheduleGroupMemberEntity,
      ScheduleEntity,
      UserEntity,
      TrainerUserEntity,
    ]),
  ],
  controllers: [ScheduleGroupController],
  providers: [ScheduleGroupService],
  exports: [ScheduleGroupService],
})
export class ScheduleGroupModule {}
