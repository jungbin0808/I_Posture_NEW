import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository, DataSource } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { ScheduleGroupEntity } from '../../database/entities/schedule-group.entity';
import { ScheduleGroupMemberEntity } from '../../database/entities/schedule-group-member.entity';
import { ScheduleEntity } from '../../database/entities/schedule.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { CreateScheduleGroupDto, DeleteScheduleGroupsDto, FindScheduleGroupsDto, UpdateScheduleGroupDto } from './schedule-group.dto';
import { AddSchedulesToGroupDto, RemoveSchedulesFromGroupDto } from '../schedule/schedule.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';

@Injectable()
export class ScheduleGroupService {
  constructor(
    @InjectRepository(ScheduleGroupEntity)
    private readonly groupRepo: Repository<ScheduleGroupEntity>,
    @InjectRepository(ScheduleGroupMemberEntity)
    private readonly groupMemberRepo: Repository<ScheduleGroupMemberEntity>,
    @InjectRepository(ScheduleEntity)
    private readonly scheduleRepo: Repository<ScheduleEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    private readonly dataSource: DataSource,
  ) {}

  async create(trainerId: string, dto: CreateScheduleGroupDto): Promise<ScheduleGroupEntity> {
    if (dto.memberIds?.length) {
      await this.assertTrainerMembers(trainerId, dto.memberIds);
    }

    return this.dataSource.transaction(async (manager) => {
      const group = manager.create(ScheduleGroupEntity, {
        trainerId,
        name: dto.name,
        memo: dto.memo,
      });
      const savedGroup = await manager.save(group);

      if (dto.memberIds && dto.memberIds.length > 0) {
        const members = dto.memberIds.map((userId) =>
          manager.create(ScheduleGroupMemberEntity, {
            groupId: savedGroup.id,
            userId,
          }),
        );
        await manager.save(members);
      }

      // 트랜잭션 내에서 조회 (manager 사용)
      const result = await manager.findOne(ScheduleGroupEntity, {
        where: { id: savedGroup.id },
        relations: ['members', 'members.user'],
      });

      if (!result) throw new NotFoundException('그룹 생성 중 오류가 발생했습니다.');
      return result;
    });
  }

  async findAll(trainerId: string, dto: FindScheduleGroupsDto): Promise<IPageData<ScheduleGroupEntity>> {
    const { page = 1, limit = 10, search } = dto;
    const query = this.groupRepo.createQueryBuilder('group')
      .leftJoinAndSelect('group.members', 'members')
      .leftJoinAndSelect('members.user', 'user')
      .where('group.trainerId = :trainerId', { trainerId });

    if (search) {
      query.andWhere('group.name LIKE :search', { search: `%${search}%` });
    }

    query.orderBy('group.createdAt', 'DESC');

    const total = await query.getCount();
    const items = await query.offset((page - 1) * limit).limit(limit).getMany();

    return { items, paging: buildPaging(total, limit, page) };
  }

  async findOne(trainerId: string, id: string): Promise<ScheduleGroupEntity> {
    const group = await this.groupRepo.findOne({
      where: { id },
      relations: ['members', 'members.user'],
    });

    if (!group) throw new NotFoundException('그룹을 찾을 수 없습니다.');
    if (group.trainerId !== trainerId) throw new ForbiddenException('접근 권한이 없습니다.');

    return group;
  }

  async update(trainerId: string, id: string, dto: UpdateScheduleGroupDto): Promise<ScheduleGroupEntity> {
    const group = await this.findOne(trainerId, id);

    if (dto.memberIds) {
      await this.assertTrainerMembers(trainerId, dto.memberIds);
    }

    return this.dataSource.transaction(async (manager) => {
      // 기본 정보 수정
      if (dto.name) group.name = dto.name;
      if (dto.memo) group.memo = dto.memo;
      await manager.save(group);

      // 멤버 수정 (전체 교체 방식)
      if (dto.memberIds) {
        await manager.delete(ScheduleGroupMemberEntity, { groupId: id });
        if (dto.memberIds.length > 0) {
          const members = dto.memberIds.map((userId) =>
            manager.create(ScheduleGroupMemberEntity, {
              groupId: id,
              userId,
            }),
          );
          await manager.save(members);
        }
      }

      // 트랜잭션 내에서 조회 (manager 사용)
      const result = await manager.findOne(ScheduleGroupEntity, {
        where: { id },
        relations: ['members', 'members.user'],
      });
      
      if (!result) throw new NotFoundException('그룹 수정 중 오류가 발생했습니다.');
      return result;
    });
  }

  @Transactional()
  async delete(trainerId: string, dto: DeleteScheduleGroupsDto): Promise<{ success: boolean }> {
    const groups = await this.groupRepo.find({ where: { id: In(dto.ids) } });
    
    for (const group of groups) {
      if (group.trainerId !== trainerId) {
        throw new ForbiddenException(`그룹 ${group.name}에 대한 삭제 권한이 없습니다.`);
      }
    }

    await this.scheduleRepo.update(
      { groupId: In(dto.ids), trainerId },
      { groupId: null as unknown as string },
    );
    await this.groupRepo.softDelete(dto.ids);
    return { success: true };
  }

  /**
   * 일정 그룹에 일정들 추가
   */
  async addSchedulesToGroup(trainerId: string, groupId: string, dto: AddSchedulesToGroupDto): Promise<{ success: boolean; addedCount: number }> {
    // 1. 그룹 존재 및 권한 확인
    const group = await this.groupRepo.findOne({ where: { id: groupId } });
    if (!group) throw new NotFoundException('일정 그룹을 찾을 수 없습니다.');
    if (group.trainerId !== trainerId) throw new ForbiddenException('해당 그룹에 대한 권한이 없습니다.');

    // 2. 일정 존재 및 권한 확인
    const schedules = await this.scheduleRepo.find({
      where: { id: In(dto.scheduleIds), trainerId },
    });
    if (schedules.length !== dto.scheduleIds.length) {
      throw new ForbiddenException('일부 일정을 찾을 수 없거나 권한이 없습니다.');
    }

    // 3. groupId 업데이트
    await this.scheduleRepo.update(dto.scheduleIds, { groupId });

    return { success: true, addedCount: dto.scheduleIds.length };
  }

  /**
   * 일정 그룹에서 일정들 삭제
   */
  async removeSchedulesFromGroup(trainerId: string, groupId: string, dto: RemoveSchedulesFromGroupDto): Promise<{ success: boolean; removedCount: number }> {
    // 1. 그룹 존재 및 권한 확인
    const group = await this.groupRepo.findOne({ where: { id: groupId } });
    if (!group) throw new NotFoundException('일정 그룹을 찾을 수 없습니다.');
    if (group.trainerId !== trainerId) throw new ForbiddenException('해당 그룹에 대한 권한이 없습니다.');

    // 2. 해당 그룹에 속한 일정만 삭제 (groupId를 null로 설정)
    const result = await this.scheduleRepo.update(
      {
        id: In(dto.scheduleIds),
        groupId: groupId,
        trainerId, // 권한 체크
      },
      { groupId: null as any }
    );

    return { success: true, removedCount: result.affected || 0 };
  }

  private async assertTrainerMembers(trainerId: string, memberIds: string[]): Promise<void> {
    const uniqueIds = [...new Set(memberIds)];
    const activeMembers = await this.trainerUserRepo.find({
      where: { trainerId, memberId: In(uniqueIds), status: TrainerUserStatus.ACTIVE },
    });
    if (activeMembers.length !== uniqueIds.length) {
      throw new BadRequestException('해당 트레이너의 활성 회원만 그룹에 추가할 수 있습니다.');
    }
  }
}
