import { ApiProperty } from '@nestjs/swagger';
import { IsArray, IsOptional, IsString, IsUUID } from 'class-validator';
import { PaginationDto } from '../../common/dto/pagination.dto';

export class CreateScheduleGroupDto {
  @ApiProperty({ description: '그룹명' })
  @IsString()
  name!: string;

  @ApiProperty({ description: '메모', required: false })
  @IsString()
  @IsOptional()
  memo?: string;

  @ApiProperty({ description: '그룹 멤버 ID 목록', type: [String], required: false })
  @IsArray()
  @IsUUID('all', { each: true })
  @IsOptional()
  memberIds?: string[];
}

export class UpdateScheduleGroupDto {
  @ApiProperty({ description: '그룹명', required: false })
  @IsString()
  @IsOptional()
  name?: string;

  @ApiProperty({ description: '메모', required: false })
  @IsString()
  @IsOptional()
  memo?: string;

  @ApiProperty({ description: '그룹 멤버 ID 목록 (전체 교체)', type: [String], required: false })
  @IsArray()
  @IsUUID('all', { each: true })
  @IsOptional()
  memberIds?: string[];
}

export class FindScheduleGroupsDto extends PaginationDto {
  @ApiProperty({ description: '검색어 (그룹명)', required: false })
  @IsString()
  @IsOptional()
  search?: string;
}

export class DeleteScheduleGroupsDto {
  @ApiProperty({ description: '삭제할 그룹 ID 목록', type: [String] })
  @IsArray()
  @IsUUID('all', { each: true })
  ids!: string[]; // groupIds -> ids 변경
}
