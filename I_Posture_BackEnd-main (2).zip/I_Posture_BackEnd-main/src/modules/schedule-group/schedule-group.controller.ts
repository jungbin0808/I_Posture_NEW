import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, Request } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { ScheduleGroupService } from './schedule-group.service';
import { CreateScheduleGroupDto, DeleteScheduleGroupsDto, FindScheduleGroupsDto, UpdateScheduleGroupDto } from './schedule-group.dto';
import { AddSchedulesToGroupDto, RemoveSchedulesFromGroupDto } from '../schedule/schedule.dto';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { SuccessResponse } from '../../common/response/response.helper';

@ApiTags('Schedule Group')
@ApiBearerAuth()
@Controller('schedule-groups')
@UseGuards(AccessTokenGuard, RolesGuard)
@Roles(Role.CenterTrainer, Role.FreelancerTrainer)
export class ScheduleGroupController {
  constructor(private readonly groupService: ScheduleGroupService) {}

  @ApiOperation({ summary: 'Create Schedule Group' })
  @Post()
  async create(@Request() req: any, @Body() dto: CreateScheduleGroupDto) {
    const data = await this.groupService.create(req.user.id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Get Schedule Group List' })
  @Get()
  async findAll(@Request() req: any, @Query() dto: FindScheduleGroupsDto) {
    const pageData = await this.groupService.findAll(req.user.id, dto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: 'Get Schedule Group Detail' })
  @Get(':id')
  async findOne(@Request() req: any, @Param('id') id: string) {
    const data = await this.groupService.findOne(req.user.id, id);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Update Schedule Group' })
  @Put(':id')
  async update(@Request() req: any, @Param('id') id: string, @Body() dto: UpdateScheduleGroupDto) {
    const data = await this.groupService.update(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹에 일정 추가 (다중 처리)' })
  @Post(':id/schedules')
  async addSchedulesToGroup(@Request() req: any, @Param('id') id: string, @Body() dto: AddSchedulesToGroupDto) {
    const data = await this.groupService.addSchedulesToGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: '일정 그룹에서 일정 삭제 (다중 처리)' })
  @Delete(':id/schedules')
  async removeSchedulesFromGroup(@Request() req: any, @Param('id') id: string, @Body() dto: RemoveSchedulesFromGroupDto) {
    const data = await this.groupService.removeSchedulesFromGroup(req.user.id, id, dto);
    return SuccessResponse(data);
  }

  @ApiOperation({ summary: 'Delete Schedule Groups' })
  @Delete()
  async delete(@Request() req: any, @Body() dto: DeleteScheduleGroupsDto) {
    const data = await this.groupService.delete(req.user.id, dto);
    return SuccessResponse(data);
  }
}
