import { BadRequestException, NotFoundException } from '@nestjs/common';
import { CenterCapacityPoolEntity } from '../../database/entities/center-capacity-pool.entity';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { StorageOwnerType } from '../../database/entities/storage-allocation.entity';

export interface GrantPoolContext {
  ownerType: StorageOwnerType;
  ownerId: string;
  centerPool?: CenterCapacityPoolEntity;
  trainerPool?: TrainerCapacityPoolEntity;
}

/** 풀 잔여 지급 가능 용량(bytes) = total - used - allocated */
export function getPoolRemainingBytes(pool: {
  totalCapacity: string;
  usedCapacity: string;
  allocatedCapacity: string;
}): bigint {
  const total = BigInt(pool.totalCapacity);
  const used = BigInt(pool.usedCapacity);
  const allocated = BigInt(pool.allocatedCapacity);
  const remaining = total - used - allocated;
  return remaining < 0n ? 0n : remaining;
}

/**
 * 지급 주체(센터 / 센터트레이너 / 개인트레이너)가 사용하는 용량 풀 컨텍스트
 * — 추후 어드민·앱 API에서도 동일 헬퍼로 풀을 resolve
 */
export async function resolveGrantPoolContext(
  grantActor: UserEntity,
  deps: {
    centerTrainerRepo: { findOne: (opts: object) => Promise<CenterTrainerEntity | null> };
    centerRepo: { findOne: (opts: object) => Promise<CenterEntity | null> };
    centerCapacityPoolRepo: { findOne: (opts: object) => Promise<CenterCapacityPoolEntity | null> };
    trainerCapacityPoolRepo: { findOne: (opts: object) => Promise<TrainerCapacityPoolEntity | null> };
  },
): Promise<GrantPoolContext> {
  if (grantActor.userType === UserType.C_TRAINER) {
    const affiliation = await deps.centerTrainerRepo.findOne({ where: { trainerId: grantActor.id } });
    if (!affiliation) {
      throw new BadRequestException('소속 센터 정보를 찾을 수 없어 용량을 지급할 수 없습니다.');
    }
    const centerPool = await deps.centerCapacityPoolRepo.findOne({ where: { centerId: affiliation.centerId } });
    if (!centerPool) {
      throw new BadRequestException('센터 용량 풀이 없습니다. 이용권 구매 후 다시 시도해주세요.');
    }
    return {
      ownerType: StorageOwnerType.CENTER,
      ownerId: affiliation.centerId,
      centerPool,
    };
  }

  if (grantActor.userType === UserType.CENTER) {
    const center = await deps.centerRepo.findOne({ where: { ownerId: grantActor.id } });
    if (!center) {
      throw new NotFoundException('센터 정보를 찾을 수 없습니다.');
    }
    const centerPool = await deps.centerCapacityPoolRepo.findOne({ where: { centerId: center.id } });
    if (!centerPool) {
      throw new BadRequestException('센터 용량 풀이 없습니다. 이용권 구매 후 다시 시도해주세요.');
    }
    return {
      ownerType: StorageOwnerType.CENTER,
      ownerId: center.id,
      centerPool,
    };
  }

  if (grantActor.userType === UserType.F_TRAINER) {
    const trainerPool = await deps.trainerCapacityPoolRepo.findOne({ where: { trainerId: grantActor.id } });
    if (!trainerPool) {
      throw new BadRequestException('트레이너 용량 풀이 없습니다. 이용권 구매 후 다시 시도해주세요.');
    }
    return {
      ownerType: StorageOwnerType.TRAINER,
      ownerId: grantActor.id,
      trainerPool,
    };
  }

  throw new BadRequestException('용량 지급 권한이 없는 계정 유형입니다.');
}
