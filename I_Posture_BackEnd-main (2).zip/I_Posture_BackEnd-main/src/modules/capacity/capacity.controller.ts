import { Controller, Get, Req, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { CapacityService } from './capacity.service';
import { CenterCapacityResponseDto } from './dto/center-capacity-response.dto';
import { MemberCapacityResponseDto } from './dto/member-capacity-response.dto';
import { TrainerCapacityResponseDto } from './dto/trainer-capacity-response.dto';

@ApiTags('Capacity')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('capacity')
export class CapacityController {
  constructor(private readonly capacityService: CapacityService) {}

  /**
   * @summary 센터 용량 정보 조회
   */
  @ApiOperation({ summary: 'Get Center Capacity Info' })
  @Roles(Role.Center, Role.CenterTrainer) // CenterTrainer 추가
  @Get('center')
  async getCenterCapacity(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<CenterCapacityResponseDto>> {
    const user = req.user;
    const capacityInfo = await this.capacityService.getCenterCapacity(user);
    return SuccessResponse(capacityInfo);
  }

  /**
   * @summary 일반 회원 용량 정보 조회
   */
  @ApiOperation({ summary: 'Get Member Capacity Info' })
  @Roles(Role.Member)
  @Get('member')
  async getMemberCapacity(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<MemberCapacityResponseDto>> {
    const user = req.user;
    const capacityInfo = await this.capacityService.getMemberCapacity(user);
    return SuccessResponse(capacityInfo);
  }

  /**
   * @summary 트레이너 용량 정보 조회
   */
  @ApiOperation({ summary: 'Get Trainer Capacity Info' })
  @Roles(Role.FreelancerTrainer, Role.CenterTrainer)
  @Get('trainer')
  async getTrainerCapacity(@Req() req: { user: UserEntity }): Promise<ISuccessResponse<TrainerCapacityResponseDto>> {
    const user = req.user;
    const capacityInfo = await this.capacityService.getTrainerCapacity(user);
    return SuccessResponse(capacityInfo);
  }
}
