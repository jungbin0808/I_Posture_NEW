import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { InjectDataSource, InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Transactional } from 'typeorm-transactional';
import { CenterCapacityPoolEntity } from '../../database/entities/center-capacity-pool.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberStorageEntity } from '../../database/entities/member-storage.entity';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { CenterTrainerCapacityPoolEntity } from '../../database/entities/center-trainer-capacity-pool.entity';
import { CenterCapacityResponseDto } from './dto/center-capacity-response.dto';
import { MemberCapacityResponseDto } from './dto/member-capacity-response.dto';
import { TrainerCapacityResponseDto } from './dto/trainer-capacity-response.dto';
import { StorageAllocationEntity, StorageAllocationStatus, StorageOwnerType } from '../../database/entities/storage-allocation.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { getPoolRemainingBytes, resolveGrantPoolContext } from './capacity-pool.helper';

const MEMBER_ALLOCATED_BYTES = 1 * 1024 * 1024 * 1024; // 1GB (fallback only)

@Injectable()
export class CapacityService {
  private readonly logger = new Logger(CapacityService.name);

  constructor(
    @InjectRepository(CenterCapacityPoolEntity)
    private readonly centerCapacityPoolRepo: Repository<CenterCapacityPoolEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    @InjectRepository(MemberStorageEntity)
    private readonly memberStorageRepo: Repository<MemberStorageEntity>,
    @InjectRepository(TrainerCapacityPoolEntity)
    private readonly trainerCapacityPoolRepo: Repository<TrainerCapacityPoolEntity>,
    @InjectRepository(CenterTrainerCapacityPoolEntity)
    private readonly centerTrainerCapacityPoolRepo: Repository<CenterTrainerCapacityPoolEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(StorageAllocationEntity)
    private readonly storageAllocationRepo: Repository<StorageAllocationEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    @InjectDataSource()
    private readonly dataSource: DataSource,
  ) {}

  /**
   * 트레이너 지급 흐름은 관리회원(C) ID를 넘겨주지만, member_storage/storage_allocations는 항상 앱 회원(A) ID로 저장해야
   * getMemberCapacity(앱 회원 본인 조회)와 맞아떨어짐. 관리회원 ID가 들어오면 연동된 앱 회원 ID로 변환하고,
   * 이미 앱 회원 ID이거나 아직 앱 연동이 안 된 관리회원이면 받은 값을 그대로 사용(그 경우 회원 앱에서는 아직 안 보임).
   */
  private async resolveAppMemberId(candidateId: string): Promise<string> {
    const link = await this.identityLinkRepo.findOne({ where: { managedMemberId: candidateId, status: IdentityLinkStatus.LINKED } });
    return link?.appMemberId ?? candidateId;
  }

  // 센터 용량 조회
  async getCenterCapacity(user: UserEntity): Promise<CenterCapacityResponseDto> {
    let center: CenterEntity | null = null;

    if (user.userType === UserType.CENTER) {
      center = await this.centerRepo.findOne({ where: { ownerId: user.id } });
    } else if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id } });
      if (affiliation && affiliation.centerId) {
        center = await this.centerRepo.findOne({ where: { id: affiliation.centerId } });
      }
    }

    if (!center) {
      throw new NotFoundException('Center not found for this user.');
    }

    const capacityPool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: center.id } });

    if (!capacityPool) {
      return {
        centerId: center.id,
        totalCapacity: '0',
        usedCapacity: '0',
        allocatedCapacity: '0',
        usagePercentage: 0,
      };
    }

    const total = BigInt(capacityPool.totalCapacity);
    const used = BigInt(capacityPool.usedCapacity);
    const usagePercentage = total > 0n ? Number((used * 10000n) / total) / 100 : 0;

    return {
      centerId: center.id,
      totalCapacity: capacityPool.totalCapacity,
      usedCapacity: capacityPool.usedCapacity,
      allocatedCapacity: capacityPool.allocatedCapacity,
      usagePercentage,
    };
  }

  // 멤버 개인 용량 조회. member_storage는 항상 앱 회원(A) 본인 ID로 저장되므로(트레이너 지급분도 allocateCapacity에서 앱 회원 ID로 변환해 기록) 그대로 조회.
  async getMemberCapacity(user: UserEntity): Promise<MemberCapacityResponseDto> {
    const storage = await this.memberStorageRepo.findOne({ where: { memberId: user.id } });

    if (!storage) {
      return {
        memberId: user.id,
        allocatedFromCenter: '0',
        allocatedFromPersonal: '0',
        totalCapacity: '0',
        usedCapacity: '0',
        usagePercentage: 0,
      };
    }

    const total = BigInt(storage.allocatedFromCenter) + BigInt(storage.allocatedFromPersonal);
    const used = BigInt(storage.usedCapacity);
    const usagePercentage = total > 0n ? Number((used * 10000n) / total) / 100 : 0;

    return {
      memberId: user.id,
      allocatedFromCenter: storage.allocatedFromCenter,
      allocatedFromPersonal: storage.allocatedFromPersonal,
      totalCapacity: total.toString(),
      usedCapacity: storage.usedCapacity,
      usagePercentage,
    };
  }

  // 트레이너 용량 조회
  async getTrainerCapacity(user: UserEntity): Promise<TrainerCapacityResponseDto> {
    const capacityPool = await this.trainerCapacityPoolRepo.findOne({ where: { trainerId: user.id } });

    if (!capacityPool) {
      return {
        trainerId: user.id,
        totalCapacity: '0',
        usedCapacity: '0',
        allocatedCapacity: '0',
        usagePercentage: 0,
      };
    }

    const total = BigInt(capacityPool.totalCapacity);
    const used = BigInt(capacityPool.usedCapacity);
    const usagePercentage = total > 0n ? Number((used * 10000n) / total) / 100 : 0;

    return {
      trainerId: user.id,
      totalCapacity: capacityPool.totalCapacity,
      usedCapacity: capacityPool.usedCapacity,
      allocatedCapacity: capacityPool.allocatedCapacity,
      usagePercentage,
    };
  }

  /**
   * 회원에게 용량 지급 (트레이너/센터 → 회원)
   * — 추후 어드민·앱 API도 동일 메서드 사용
   */
  @Transactional()
  async allocateCapacity(grantActorId: string, memberId: string, storageLimit?: string): Promise<void> {
    const appMemberId = await this.resolveAppMemberId(memberId);
    const allocBytes = storageLimit ? BigInt(storageLimit) : BigInt(MEMBER_ALLOCATED_BYTES);
    const grantActor = await this.userRepo.findOne({ where: { id: grantActorId } });
    if (!grantActor) {
      throw new NotFoundException('지급 주체 계정을 찾을 수 없습니다.');
    }

    const ctx = await resolveGrantPoolContext(grantActor, {
      centerTrainerRepo: this.centerTrainerRepo,
      centerRepo: this.centerRepo,
      centerCapacityPoolRepo: this.centerCapacityPoolRepo,
      trainerCapacityPoolRepo: this.trainerCapacityPoolRepo,
    });

    const existing = await this.storageAllocationRepo.findOne({
      where: { memberId: appMemberId, ownerId: ctx.ownerId, status: StorageAllocationStatus.ACTIVE },
    });
    if (existing) {
      throw new BadRequestException('이미 활성 용량 할당이 존재하는 회원입니다.');
    }

    const pool = ctx.centerPool ?? ctx.trainerPool!;
    const remaining = getPoolRemainingBytes(pool);
    if (allocBytes > remaining) {
      throw new BadRequestException('할당 가능한 용량이 부족합니다. 이용권 업그레이드 또는 회원 용량 회수 후 다시 시도해주세요.');
    }

    pool.allocatedCapacity = (BigInt(pool.allocatedCapacity) + allocBytes).toString();
    if (ctx.centerPool) {
      await this.centerCapacityPoolRepo.save(ctx.centerPool);
    } else {
      await this.trainerCapacityPoolRepo.save(ctx.trainerPool!);
    }

    await this.storageAllocationRepo.save(
      this.storageAllocationRepo.create({
        ownerType: ctx.ownerType,
        ownerId: ctx.ownerId,
        memberId: appMemberId,
        allocatedCapacity: allocBytes.toString(),
        status: StorageAllocationStatus.ACTIVE,
      }),
    );

    await this.adjustMemberStorageAllocatedFromCenter(appMemberId, allocBytes);
  }

  /**
   * 회원 용량 회수 (지급 주체 검증 후 회수)
   */
  @Transactional()
  async deallocateCapacity(grantActorId: string, memberId: string, _storageLimit?: string): Promise<void> {
    const appMemberId = await this.resolveAppMemberId(memberId);
    const grantActor = await this.userRepo.findOne({ where: { id: grantActorId } });
    if (!grantActor) {
      throw new NotFoundException('지급 주체 계정을 찾을 수 없습니다.');
    }

    const ctx = await resolveGrantPoolContext(grantActor, {
      centerTrainerRepo: this.centerTrainerRepo,
      centerRepo: this.centerRepo,
      centerCapacityPoolRepo: this.centerCapacityPoolRepo,
      trainerCapacityPoolRepo: this.trainerCapacityPoolRepo,
    });

    const alloc = await this.storageAllocationRepo.findOne({
      where: { memberId: appMemberId, ownerId: ctx.ownerId, status: StorageAllocationStatus.ACTIVE },
    });
    if (!alloc) {
      this.logger.warn(`회수할 ACTIVE 용량 할당 없음: memberId=${appMemberId} ownerId=${ctx.ownerId}`);
      return;
    }

    await this._releaseAllocation(alloc);
  }

  /**
   * 회원 기준 용량 회수 (스케줄러·탈퇴 등 — 지급 주체 ID 없이 ACTIVE 할당 record 기준)
   */
  @Transactional()
  async deallocateCapacityForMember(memberId: string, _storageLimit?: string): Promise<void> {
    const appMemberId = await this.resolveAppMemberId(memberId);
    const alloc = await this.storageAllocationRepo.findOne({
      where: { memberId: appMemberId, status: StorageAllocationStatus.ACTIVE },
    });
    if (!alloc) {
      this.logger.warn(`회수할 ACTIVE 용량 할당 없음: memberId=${appMemberId}`);
      return;
    }

    await this._releaseAllocation(alloc);
  }

  private async adjustMemberStorageAllocatedFromCenter(appMemberId: string, deltaBytes: bigint): Promise<void> {
    let storage = await this.memberStorageRepo.findOne({ where: { memberId: appMemberId } });
    if (!storage) {
      storage = this.memberStorageRepo.create({
        memberId: appMemberId,
        allocatedFromCenter: '0',
        allocatedFromPersonal: '0',
        usedCapacity: '0',
      });
    }
    const next = BigInt(storage.allocatedFromCenter) + deltaBytes;
    storage.allocatedFromCenter = (next < 0n ? 0n : next).toString();
    await this.memberStorageRepo.save(storage);
  }

  private async _releaseAllocation(alloc: StorageAllocationEntity): Promise<void> {
    const deallocBytes = BigInt(alloc.allocatedCapacity);

    if (alloc.ownerType === StorageOwnerType.CENTER) {
      const pool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: alloc.ownerId } });
      if (!pool) {
        throw new NotFoundException('센터 용량 풀을 찾을 수 없어 회수할 수 없습니다.');
      }
      const newVal = BigInt(pool.allocatedCapacity) - deallocBytes;
      pool.allocatedCapacity = (newVal < 0n ? 0n : newVal).toString();
      await this.centerCapacityPoolRepo.save(pool);
    } else {
      const pool = await this.trainerCapacityPoolRepo.findOne({ where: { trainerId: alloc.ownerId } });
      if (!pool) {
        throw new NotFoundException('트레이너 용량 풀을 찾을 수 없어 회수할 수 없습니다.');
      }
      const newVal = BigInt(pool.allocatedCapacity) - deallocBytes;
      pool.allocatedCapacity = (newVal < 0n ? 0n : newVal).toString();
      await this.trainerCapacityPoolRepo.save(pool);
    }

    await this.storageAllocationRepo.update(
      { id: alloc.id, status: StorageAllocationStatus.ACTIVE },
      { status: StorageAllocationStatus.REVOKED },
    );

    await this.adjustMemberStorageAllocatedFromCenter(alloc.memberId, -deallocBytes);
  }

  /**
   * 용량 업데이트 (파일 업로드/삭제 시)
   */
  async updateCenterCapacity(user: UserEntity, sizeBytes: string | number | bigint): Promise<void> {
    this.logger.log(`Updating capacity for user ${user.id} (${user.userType}), sizeBytes: ${sizeBytes}`);

    let changeInBytes: bigint;
    try {
      changeInBytes = BigInt(sizeBytes);
    } catch (e) {
      this.logger.warn(`Invalid sizeBytes provided: ${sizeBytes}. Skipping update.`, e);
      return;
    }

    if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id } });
      if (!affiliation) return;
      const capacityPool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: affiliation.centerId } });
      if (!capacityPool) return;
      capacityPool.usedCapacity = (BigInt(capacityPool.usedCapacity) + changeInBytes).toString();
      await this.centerCapacityPoolRepo.save(capacityPool);
      await this.applyCenterTrainerUsageChange(affiliation.centerId, user.id, changeInBytes);

    } else if (user.userType === UserType.F_TRAINER) {
      let capacityPool = await this.trainerCapacityPoolRepo.findOne({ where: { trainerId: user.id } });
      if (!capacityPool) {
        capacityPool = await this.trainerCapacityPoolRepo.save(this.trainerCapacityPoolRepo.create({ trainerId: user.id }));
      }
      capacityPool.usedCapacity = (BigInt(capacityPool.usedCapacity) + changeInBytes).toString();
      await this.trainerCapacityPoolRepo.save(capacityPool);

    } else if (user.userType === UserType.CENTER) {
        const center = await this.centerRepo.findOne({ where: { ownerId: user.id } });
        if (!center) return;
        const capacityPool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: center.id } });
        if (!capacityPool) return;
        capacityPool.usedCapacity = (BigInt(capacityPool.usedCapacity) + changeInBytes).toString();
        await this.centerCapacityPoolRepo.save(capacityPool);
    }
  }

  /**
   * 이용권 결제/갱신 시 totalCapacity 설정
   * - CENTER / C_TRAINER → center_capacity_pool.totalCapacity
   * - F_TRAINER → trainer_capacity_pool.totalCapacity
   */
  async applySubscriptionCapacity(user: UserEntity, storageLimit: string): Promise<void> {
    const bytes = BigInt(storageLimit);

    if (user.userType === UserType.CENTER) {
      const center = await this.centerRepo.findOne({ where: { ownerId: user.id } });
      if (!center) return;
      let pool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: center.id } });
      if (!pool) {
        pool = this.centerCapacityPoolRepo.create({ centerId: center.id, totalCapacity: '0', usedCapacity: '0', allocatedCapacity: '0' });
      }
      pool.totalCapacity = bytes.toString();
      await this.centerCapacityPoolRepo.save(pool);

    } else if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id } });
      if (!affiliation) return;
      let pool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: affiliation.centerId } });
      if (!pool) {
        pool = this.centerCapacityPoolRepo.create({ centerId: affiliation.centerId, totalCapacity: '0', usedCapacity: '0', allocatedCapacity: '0' });
      }
      pool.totalCapacity = bytes.toString();
      await this.centerCapacityPoolRepo.save(pool);

    } else if (user.userType === UserType.F_TRAINER) {
      let pool = await this.trainerCapacityPoolRepo.findOne({ where: { trainerId: user.id } });
      if (!pool) {
        pool = this.trainerCapacityPoolRepo.create({ trainerId: user.id, totalCapacity: '0', usedCapacity: '0', allocatedCapacity: '0' });
      }
      pool.totalCapacity = bytes.toString();
      await this.trainerCapacityPoolRepo.save(pool);
    }
  }

  /**
   * 용량 초과 여부 확인 (Guard에서 사용)
   * totalCapacity가 0이면 아직 이용권 없음으로 간주 → 초과로 처리
   */
  async isQuotaExceeded(user: UserEntity): Promise<boolean> {
    if (user.userType === UserType.CENTER) {
      const center = await this.centerRepo.findOne({ where: { ownerId: user.id } });
      if (!center) return true;
      const pool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: center.id } });
      if (!pool || BigInt(pool.totalCapacity) === 0n) return true;
      return BigInt(pool.usedCapacity) >= BigInt(pool.totalCapacity);

    } else if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id } });
      if (!affiliation) return true;
      const pool = await this.centerCapacityPoolRepo.findOne({ where: { centerId: affiliation.centerId } });
      if (!pool || BigInt(pool.totalCapacity) === 0n) return true;
      return BigInt(pool.usedCapacity) >= BigInt(pool.totalCapacity);

    } else if (user.userType === UserType.F_TRAINER) {
      const pool = await this.trainerCapacityPoolRepo.findOne({ where: { trainerId: user.id } });
      if (!pool || BigInt(pool.totalCapacity) === 0n) return true;
      return BigInt(pool.usedCapacity) >= BigInt(pool.totalCapacity);
    }

    return false;
  }

  async getCenterTrainerUsedCapacity(centerId: string, trainerId: string): Promise<string> {
    const pool = await this.centerTrainerCapacityPoolRepo.findOne({
      where: { centerId, trainerId },
    });

    return pool?.usedCapacity ?? '0';
  }

  @Transactional()
  async transferCenterTrainerUsage(
    centerId: string,
    fromTrainerId: string,
    toTrainerId: string,
    memberId: string,
  ): Promise<void> {
    const [row] = await this.dataSource.query<Array<{ bytes: string }>>(
      `SELECT COALESCE(SUM(size), 0) AS bytes
       FROM files
       WHERE member_id = ? AND uploader_id = ?`,
      [memberId, fromTrainerId],
    );
    const bytes = BigInt(row?.bytes ?? 0);
    if (bytes <= 0n) {
      return;
    }

    await this.applyCenterTrainerUsageChange(centerId, fromTrainerId, -bytes);
    await this.applyCenterTrainerUsageChange(centerId, toTrainerId, bytes);
  }

  async ensureCenterTrainerCapacityPool(centerId: string, trainerId: string): Promise<void> {
    const existing = await this.centerTrainerCapacityPoolRepo.findOne({
      where: { centerId, trainerId },
    });
    if (existing) {
      return;
    }

    await this.centerTrainerCapacityPoolRepo.save(
      this.centerTrainerCapacityPoolRepo.create({
        centerId,
        trainerId,
        usedCapacity: '0',
      }),
    );
  }

  private async applyCenterTrainerUsageChange(
    centerId: string,
    trainerId: string,
    changeInBytes: bigint,
  ): Promise<void> {
    if (changeInBytes === 0n) {
      return;
    }

    let pool = await this.centerTrainerCapacityPoolRepo.findOne({
      where: { centerId, trainerId },
    });
    if (!pool) {
      pool = this.centerTrainerCapacityPoolRepo.create({
        centerId,
        trainerId,
        usedCapacity: '0',
      });
    }

    const next = BigInt(pool.usedCapacity) + changeInBytes;
    pool.usedCapacity = (next < 0n ? 0n : next).toString();
    await this.centerTrainerCapacityPoolRepo.save(pool);
  }
}
