import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { CapacityService } from './capacity.service';
import { StoredFileReleaseService } from './stored-file-release.service';
import { CapacityController } from './capacity.controller';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { CenterTrainerCapacityPoolEntity } from '../../database/entities/center-trainer-capacity-pool.entity';
import { CenterCapacityPoolEntity } from '../../database/entities/center-capacity-pool.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberStorageEntity } from '../../database/entities/member-storage.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { StorageAllocationEntity } from '../../database/entities/storage-allocation.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { S3Module } from '../../s3/s3.module';

@Module({
  imports: [
    S3Module,
    TypeOrmModule.forFeature([
      TrainerCapacityPoolEntity,
      CenterTrainerCapacityPoolEntity,
      CenterCapacityPoolEntity,
      CenterTrainerEntity,
      CenterEntity,
      MemberStorageEntity,
      UserEntity,
      StorageAllocationEntity,
      FileEntity,
      MemberIdentityLinkEntity,
    ]),
  ],
  controllers: [CapacityController],
  providers: [CapacityService, StoredFileReleaseService],
  exports: [CapacityService, StoredFileReleaseService],
})
export class CapacityModule {}
