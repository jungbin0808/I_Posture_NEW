import { ApiProperty } from '@nestjs/swagger';

export class CenterCapacityResponseDto {
  @ApiProperty({ description: '센터 ID' })
  centerId!: string;

  @ApiProperty({ description: '총 확보 용량 (bytes)' })
  totalCapacity!: string;

  @ApiProperty({ description: '사용 중인 용량 (bytes)' })
  usedCapacity!: string;

  @ApiProperty({ description: '할당된 용량 (bytes) - 트레이너 등에게 배분된 용량' })
  allocatedCapacity!: string;

  @ApiProperty({ description: '사용률 (%)' })
  usagePercentage!: number;
}
