import { ApiProperty } from '@nestjs/swagger';

export class MemberCapacityResponseDto {
  @ApiProperty({ description: '회원 ID' })
  memberId!: string;

  @ApiProperty({ description: '센터/트레이너로부터 할당받은 용량 (bytes)' })
  allocatedFromCenter!: string;

  @ApiProperty({ description: '개인 구독으로 확보한 용량 (bytes)' })
  allocatedFromPersonal!: string;

  @ApiProperty({ description: '총 사용 가능한 용량 (bytes)' })
  totalCapacity!: string;

  @ApiProperty({ description: '사용 중인 용량 (bytes)' })
  usedCapacity!: string;

  @ApiProperty({ description: '사용률 (%)' })
  usagePercentage!: number;
}
