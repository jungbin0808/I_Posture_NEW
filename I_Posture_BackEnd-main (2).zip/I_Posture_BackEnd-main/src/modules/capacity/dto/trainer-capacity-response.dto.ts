import { ApiProperty } from '@nestjs/swagger';

export class TrainerCapacityResponseDto {
  @ApiProperty({ description: '트레이너 ID' })
  trainerId!: string;

  @ApiProperty({ description: '총 확보 용량 (bytes)' })
  totalCapacity!: string;

  @ApiProperty({ description: '사용 중인 용량 (bytes)' })
  usedCapacity!: string;

  @ApiProperty({ description: '회원에게 할당한 용량 (bytes)' })
  allocatedCapacity!: string;

  @ApiProperty({ description: '사용률 (%)' })
  usagePercentage!: number;
}
