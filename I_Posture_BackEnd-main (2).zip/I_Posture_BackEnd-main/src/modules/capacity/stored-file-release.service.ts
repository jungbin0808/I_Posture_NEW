import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { FileEntity } from '../../database/entities/file.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { S3Service } from '../../s3/s3.service';
import { CapacityService } from './capacity.service';

@Injectable()
export class StoredFileReleaseService {
  constructor(
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
  ) {}

  async releaseFiles(capacityOwner: UserEntity, files: FileEntity[]): Promise<void> {
    for (const file of files) {
      // TODO: S3 삭제 비활성화 — 로컬/개발 환경에서 BucketNotEmpty 오류 방지
      // await this.s3Service.deleteFile(file.s3Key);
      await this.fileRepo.delete(file.id);
      await this.capacityService.updateCenterCapacity(capacityOwner, `-${file.size}`);
    }
  }

  async releaseForTrainer(trainerId: string, relatedIds: string[]): Promise<void> {
    if (relatedIds.length === 0) return;

    const trainer = await this.userRepo.findOne({ where: { id: trainerId } });
    if (!trainer) return;

    const files = await this.fileRepo.find({ where: { relatedId: In(relatedIds) } });
    await this.releaseFiles(trainer, files);
  }
}
