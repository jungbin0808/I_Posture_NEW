import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import {
  InbodyController,
  PublicInbodyController,
  CenterInbodyPublicController,
} from './inbody.controller';
import { InbodyService } from './inbody.service';
import { CapacityModule } from '../capacity/capacity.module';
import { S3Module } from '../../s3/s3.module';
import { FileEntity } from '../../database/entities/file.entity';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      InbodyDataEntity, 
      UserEntity, 
      TrainerUserEntity,
      FileEntity,
      SubscriptionEntity,
      CenterTrainerEntity,
      CenterEntity,
      MemberIdentityLinkEntity,
    ]),
    CapacityModule,
    S3Module,
  ],
  controllers: [InbodyController, PublicInbodyController, CenterInbodyPublicController],
  providers: [InbodyService, SubscriptionGuard],
  exports: [InbodyService],
})
export class InbodyModule {}
