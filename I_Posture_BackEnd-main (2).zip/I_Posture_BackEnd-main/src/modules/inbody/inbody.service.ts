import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { FindInbodyDataDto } from './dto/find-inbody-data.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { InbodyDataResponseDto, InbodyDataDetailResponseDto } from './dto/inbody-data-response.dto';
import { UpdateInbodyDataDto } from './dto/update-inbody-data.dto';
import { DeleteInbodyDataDto } from './dto/delete-inbody-data.dto';
import { CreateInbodyDataDto } from './dto/create-inbody-data.dto';
import { S3Service } from '../../s3/s3.service';
import { CapacityService } from '../capacity/capacity.service';
import { StoredFileReleaseService } from '../capacity/stored-file-release.service';
import { FileOwnerType, FileRelatedType } from '../../database/entities/file.entity';
import { Transactional } from 'typeorm-transactional';
import { MemberNotificationService } from '../notification/member-notification.service';

@Injectable()
export class InbodyService {
  constructor(
    @InjectRepository(InbodyDataEntity)
    private readonly inbodyDataRepo: Repository<InbodyDataEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly s3Service: S3Service,
    private readonly capacityService: CapacityService,
    private readonly storedFileReleaseService: StoredFileReleaseService,
    private readonly memberNotificationService: MemberNotificationService,
  ) {}

  /**
   * 회원의 인바디 데이터 목록을 조회합니다.
   */
  async findAllByMemberId(trainerId: string, memberId: string, dto: FindInbodyDataDto): Promise<IPageData<InbodyDataResponseDto>> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 인바디 정보를 조회할 권한이 없습니다.');

    const { page = 1, limit = 10, startDate, endDate, sort } = dto;
    const query = this.inbodyDataRepo.createQueryBuilder('inbody')
      .where('inbody.userId = :userId', { userId: memberId });

    if (startDate) query.andWhere('inbody.measuredAt >= :startDate', { startDate });
    if (endDate) query.andWhere('inbody.measuredAt <= :endDate', { endDate });

    const sortDirection = sort === 'DATE_ASC' ? 'ASC' : 'DESC';
    query.orderBy('inbody.measuredAt', sortDirection);

    const total = await query.getCount();
    const logs = await query.offset((page - 1) * limit).limit(limit).getMany();

    const items: InbodyDataResponseDto[] = logs.map(log => ({
      id: log.id,
      measuredAt: log.measuredAt,
      score: log.keyStats?.score,
      bmi: log.keyStats?.bmi,
      percentBodyFat: log.keyStats?.percentBodyFat,
      weight: log.keyStats?.weight,
      skeletalMuscleMass: log.keyStats?.skeletalMuscleMass,
      bodyFatMass: log.keyStats?.bodyFatMass,
      basalMetabolicRate: log.keyStats?.basalMetabolicRate,
    }));

    return { items, paging: buildPaging(total, limit, page) };
  }

  /**
   * 인바디 데이터 상세 정보를 조회합니다.
   */
  async findOne(trainerId: string, memberId: string, id: string): Promise<InbodyDataDetailResponseDto> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 인바디 정보를 조회할 권한이 없습니다.');

    const log = await this.inbodyDataRepo.findOne({ where: { id, userId: memberId } });
    if (!log) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

    return this.buildDetail(log);
  }

  /**
   * 내 인바디 데이터 상세 조회 (회원 본인용) - 셀프 등록 본인 소유이거나, 연동된 트레이너가 등록한 것만 허용
   */
  async findOneForOwnMember(appMemberId: string, id: string): Promise<InbodyDataDetailResponseDto> {
    const log = await this.inbodyDataRepo.findOne({ where: { id } });
    if (!log) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

    const isSelfOwned = log.userId === appMemberId && !log.trainerId;
    let isOwnedByLinkedTrainer = false;
    if (!isSelfOwned && log.trainerId) {
      const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
      isOwnedByLinkedTrainer = !!link && log.userId === link.managedMemberId;
    }

    if (!isSelfOwned && !isOwnedByLinkedTrainer) {
      throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');
    }

    return this.buildDetail(log);
  }

  private buildDetail(log: InbodyDataEntity): InbodyDataDetailResponseDto {
    return {
      id: log.id,
      measuredAt: log.measuredAt,
      score: log.keyStats?.score,
      bmi: log.keyStats?.bmi,
      percentBodyFat: log.keyStats?.percentBodyFat,
      weight: log.keyStats?.weight,
      basalMetabolicRate: log.keyStats?.basalMetabolicRate,
      keyStats: log.keyStats,
      detailData: log.detailData,
    };
  }

  async findOnePublic(id: string, memberId?: string): Promise<InbodyDataDetailResponseDto> {
    const log = await this.inbodyDataRepo.findOne({
      where: memberId ? { id, userId: memberId } : { id },
    });
    if (!log) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

    return {
      id: log.id,
      measuredAt: log.measuredAt,
      score: log.keyStats?.score,
      bmi: log.keyStats?.bmi,
      percentBodyFat: log.keyStats?.percentBodyFat,
      weight: log.keyStats?.weight,
      basalMetabolicRate: log.keyStats?.basalMetabolicRate,
      keyStats: log.keyStats,
      detailData: log.detailData,
    };
  }

  /**
   * 회원 셀프 인바디 등록 - OCR 미구현이라 트레이너용 수동 등록과 동일하게 값을 직접 입력받음.
   * trainerId 없이(본인 소유), 사진은 무료 무제한 정책이라 용량 체크/차감 없이 저장.
   */
  async createSelfManual(member: UserEntity, dto: CreateInbodyDataDto, file?: Express.Multer.File): Promise<InbodyDataEntity> {
    const keyStats = {
      weight: dto.weight,
      skeletalMuscleMass: dto.skeletalMuscleMass,
      bodyFatMass: dto.bodyFatMass,
      bmi: dto.bmi,
      percentBodyFat: dto.percentBodyFat,
      abdominalFatRatio: dto.abdominalFatRatio,
      visceralFatLevel: dto.visceralFatLevel,
      basalMetabolicRate: dto.basalMetabolicRate,
    };

    const detailData = {
      bodyWater: dto.bodyWater,
      protein: dto.protein,
      minerals: dto.minerals,
      idealWeight: dto.idealWeight,
      weightControl: dto.weightControl,
      fatControl: dto.fatControl,
      muscleControl: dto.muscleControl,
      bmiEvaluation: dto.bmiEvaluation,
      bodyFatEvaluation: dto.bodyFatEvaluation,
    };

    const inbodyData = this.inbodyDataRepo.create({
      trainerId: undefined,
      userId: member.id,
      measuredAt: new Date(dto.measuredAt),
      keyStats,
      detailData,
    });
    const savedInbody = await this.inbodyDataRepo.save(inbodyData);

    if (file) {
      const uploadedFile = await this.s3Service.uploadFile(file, {
        memberId: member.id,
        uploaderId: member.id,
        ownerType: FileOwnerType.MEMBER,
        ownerId: member.id,
        relatedType: FileRelatedType.INBODY,
        relatedId: savedInbody.id,
      });

      savedInbody.detailData = { ...savedInbody.detailData, inbodyImageUrl: uploadedFile.fileUrl };
      await this.inbodyDataRepo.save(savedInbody);
    }

    return savedInbody;
  }

  /**
   * 인바디 데이터를 수동으로 등록합니다.
   */
  async createManual(trainer: UserEntity, memberId: string, dto: CreateInbodyDataDto, file?: Express.Multer.File): Promise<InbodyDataEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId: trainer.id, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원에게 인바디를 등록할 권한이 없습니다.');

    const keyStats = {
      weight: dto.weight,
      skeletalMuscleMass: dto.skeletalMuscleMass,
      bodyFatMass: dto.bodyFatMass,
      bmi: dto.bmi,
      percentBodyFat: dto.percentBodyFat,
      abdominalFatRatio: dto.abdominalFatRatio,
      visceralFatLevel: dto.visceralFatLevel,
      basalMetabolicRate: dto.basalMetabolicRate,
    };

    const detailData = {
      bodyWater: dto.bodyWater,
      protein: dto.protein,
      minerals: dto.minerals,
      idealWeight: dto.idealWeight,
      weightControl: dto.weightControl,
      fatControl: dto.fatControl,
      muscleControl: dto.muscleControl,
      bmiEvaluation: dto.bmiEvaluation,
      bodyFatEvaluation: dto.bodyFatEvaluation,
    };

    const inbodyData = this.inbodyDataRepo.create({
      trainerId: trainer.id,
      userId: memberId,
      measuredAt: new Date(dto.measuredAt),
      keyStats,
      detailData,
    });
    const savedInbody = await this.inbodyDataRepo.save(inbodyData);

    if (file) {
      const uploadedFile = await this.s3Service.uploadFile(file, {
        memberId,
        uploaderId: trainer.id,
        ownerType: FileOwnerType.TRAINER,
        ownerId: trainer.id,
        relatedType: FileRelatedType.INBODY,
        relatedId: savedInbody.id,
      });
      await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);

      savedInbody.detailData = { ...savedInbody.detailData, inbodyImageUrl: uploadedFile.fileUrl };
      await this.inbodyDataRepo.save(savedInbody);
    }

    this.memberNotificationService.notifyInbodyReport(memberId, savedInbody.id);
    return savedInbody;
  }

  /**
   * 인바디 결과지 OCR을 통해 데이터를 생성합니다.
   */
  async createFromOcr(trainer: UserEntity, memberId: string, file: Express.Multer.File): Promise<InbodyDataEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId: trainer.id, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원에게 인바디를 등록할 권한이 없습니다.');

    // TODO: 실제 OCR API 호출 로직
    // const ocrResult = await this.ocrService.analyze(file);

    // 임시 OCR 결과 데이터 생성
    const ocrResult = {
      measuredAt: new Date(),
      keyStats: {
        score: Math.floor(Math.random() * 30) + 70, // 70~99
        bmi: parseFloat((Math.random() * 10 + 18).toFixed(1)), // 18.0 ~ 27.9
        percentBodyFat: parseFloat((Math.random() * 20 + 15).toFixed(1)), // 15.0 ~ 34.9
        weight: parseFloat((Math.random() * 30 + 50).toFixed(1)), // 50.0 ~ 79.9
        basalMetabolicRate: Math.floor(Math.random() * 500) + 1200, // 1200 ~ 1699
      },
      detailData: { rawText: 'OCR 분석 결과 텍스트...', originalFileName: file.originalname },
    };

    const inbodyData = this.inbodyDataRepo.create({
      trainerId: trainer.id,
      userId: memberId,
      measuredAt: ocrResult.measuredAt,
      keyStats: ocrResult.keyStats,
      detailData: ocrResult.detailData,
    });
    const savedInbody = await this.inbodyDataRepo.save(inbodyData);

    // 파일 업로드 및 용량 차감
    const uploadedFile = await this.s3Service.uploadFile(file, {
      memberId: memberId,
      uploaderId: trainer.id,
      ownerType: FileOwnerType.TRAINER, // 용량 차감 주체: 트레이너
      ownerId: trainer.id,
      relatedType: FileRelatedType.INBODY,
      relatedId: savedInbody.id,
    });

    // 트레이너 용량 차감
    await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);

    this.memberNotificationService.notifyInbodyReport(memberId, savedInbody.id);
    return savedInbody;
  }

  /**
   * 인바디 데이터를 수정합니다.
   */
  @Transactional()
  async update(trainer: UserEntity, memberId: string, id: string, dto: UpdateInbodyDataDto, file?: Express.Multer.File): Promise<InbodyDataEntity> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId: trainer.id, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 인바디 정보를 수정할 권한이 없습니다.');

    const log = await this.inbodyDataRepo.findOne({ where: { id, userId: memberId } });
    if (!log) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');

    const keyStatsFields = ['weight', 'skeletalMuscleMass', 'bodyFatMass', 'bmi', 'percentBodyFat', 'abdominalFatRatio', 'visceralFatLevel', 'basalMetabolicRate'];
    const detailDataFields = ['bodyWater', 'protein', 'minerals', 'idealWeight', 'weightControl', 'fatControl', 'muscleControl', 'bmiEvaluation', 'bodyFatEvaluation'];

    const updatedKeyStats = { ...(log.keyStats ?? {}) };
    for (const field of keyStatsFields) {
      if ((dto as any)[field] !== undefined) updatedKeyStats[field] = (dto as any)[field];
    }

    const updatedDetailData = { ...(log.detailData ?? {}) };
    for (const field of detailDataFields) {
      if ((dto as any)[field] !== undefined) updatedDetailData[field] = (dto as any)[field];
    }

    if (file) {
      await this.storedFileReleaseService.releaseForTrainer(trainer.id, [log.id]);

      const uploadedFile = await this.s3Service.uploadFile(file, {
        memberId,
        uploaderId: trainer.id,
        ownerType: FileOwnerType.TRAINER,
        ownerId: trainer.id,
        relatedType: FileRelatedType.INBODY,
        relatedId: log.id,
      });
      await this.capacityService.updateCenterCapacity(trainer, uploadedFile.size);
      updatedDetailData.inbodyImageUrl = uploadedFile.fileUrl;
    }

    log.keyStats = updatedKeyStats;
    log.detailData = updatedDetailData;
    return this.inbodyDataRepo.save(log);
  }

  /**
   * 내 인바디 데이터 수정 (회원 본인용) - 셀프 등록분만 수정 가능. 트레이너가 등록한 기록은
   * 회원이 임의로 수정할 수 없게 막는다(트레이너 업무 기록 보호). 사진은 무료 무제한 정책이라
   * 용량 체크/차감 없이 저장.
   */
  @Transactional()
  async updateSelf(member: UserEntity, id: string, dto: UpdateInbodyDataDto, file?: Express.Multer.File): Promise<InbodyDataEntity> {
    const log = await this.inbodyDataRepo.findOne({ where: { id, userId: member.id } });
    if (!log) throw new NotFoundException('인바디 데이터를 찾을 수 없습니다.');
    if (log.trainerId) throw new ForbiddenException('트레이너가 등록한 인바디 데이터는 직접 수정할 수 없습니다.');

    const keyStatsFields = ['weight', 'skeletalMuscleMass', 'bodyFatMass', 'bmi', 'percentBodyFat', 'abdominalFatRatio', 'visceralFatLevel', 'basalMetabolicRate'];
    const detailDataFields = ['bodyWater', 'protein', 'minerals', 'idealWeight', 'weightControl', 'fatControl', 'muscleControl', 'bmiEvaluation', 'bodyFatEvaluation'];

    const updatedKeyStats = { ...(log.keyStats ?? {}) };
    for (const field of keyStatsFields) {
      if ((dto as any)[field] !== undefined) updatedKeyStats[field] = (dto as any)[field];
    }

    const updatedDetailData = { ...(log.detailData ?? {}) };
    for (const field of detailDataFields) {
      if ((dto as any)[field] !== undefined) updatedDetailData[field] = (dto as any)[field];
    }

    if (file) {
      const uploadedFile = await this.s3Service.uploadFile(file, {
        memberId: member.id,
        uploaderId: member.id,
        ownerType: FileOwnerType.MEMBER,
        ownerId: member.id,
        relatedType: FileRelatedType.INBODY,
        relatedId: log.id,
      });
      updatedDetailData.inbodyImageUrl = uploadedFile.fileUrl;
    }

    if (dto.measuredAt !== undefined) {
      log.measuredAt = new Date(dto.measuredAt);
    }
    log.keyStats = updatedKeyStats;
    log.detailData = updatedDetailData;
    return this.inbodyDataRepo.save(log);
  }

  /**
   * 인바디 데이터를 일괄 삭제합니다. (논리적 삭제)
   */
  @Transactional()
  async delete(trainerId: string, memberId: string, dto: DeleteInbodyDataDto): Promise<{ success: boolean }> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) throw new ForbiddenException('해당 회원의 인바디 정보를 삭제할 권한이 없습니다.');

    const logs = await this.inbodyDataRepo.find({ where: { id: In(dto.ids), userId: memberId } });
    if (logs.length !== dto.ids.length) {
      throw new NotFoundException('일부 인바디 데이터를 찾을 수 없습니다.');
    }

    await this.storedFileReleaseService.releaseForTrainer(trainerId, dto.ids);
    await this.inbodyDataRepo.softDelete(dto.ids);
    return { success: true };
  }

  /**
   * 내 인바디 데이터 삭제 (회원 본인용) - 셀프 등록분만 삭제 가능. 트레이너가 등록한 기록은
   * 회원이 임의로 지울 수 없게 막는다(트레이너 업무 기록 보호).
   */
  @Transactional()
  async deleteSelf(appMemberId: string, dto: DeleteInbodyDataDto): Promise<{ success: boolean }> {
    const logs = await this.inbodyDataRepo.find({ where: { id: In(dto.ids), userId: appMemberId } });
    if (logs.length !== dto.ids.length) {
      throw new NotFoundException('일부 인바디 데이터를 찾을 수 없습니다.');
    }
    if (logs.some((log) => log.trainerId)) {
      throw new ForbiddenException('트레이너가 등록한 인바디 데이터는 직접 삭제할 수 없습니다.');
    }

    await this.inbodyDataRepo.softDelete(dto.ids);
    return { success: true };
  }
}
