import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UploadedFile, UseGuards, UseInterceptors } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiBody, ApiConsumes, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { SubscriptionGuard } from '../../common/guards/subscription.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { RequiresSubscription } from '../../common/decorators/requires-subscription.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { InbodyService } from './inbody.service';
import { FindInbodyDataDto } from './dto/find-inbody-data.dto';
import { InbodyDataResponseDto, InbodyDataDetailResponseDto } from './dto/inbody-data-response.dto';
import { InbodyDataEntity } from '../../database/entities/inbody-data.entity';
import { UpdateInbodyDataDto } from './dto/update-inbody-data.dto';
import { DeleteInbodyDataDto } from './dto/delete-inbody-data.dto';
import { CreateInbodyDataDto } from './dto/create-inbody-data.dto';

@ApiTags('Inbody')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('inbody')
export class InbodyController {
  constructor(private readonly inbodyService: InbodyService) {}

  /**
   * @summary 내 인바디 데이터 상세 조회 (회원 본인, 셀프등록/트레이너등록 모두 포함)
   */
  @ApiOperation({ summary: 'Get My Inbody Data Detail' })
  @Roles(Role.Member)
  @Get('me/:id')
  async findOneForOwnMember(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
  ): Promise<ISuccessResponse<InbodyDataDetailResponseDto>> {
    const data = await this.inbodyService.findOneForOwnMember(req.user.id, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 회원의 인바디 데이터 목록 조회
   */
  @ApiOperation({ summary: 'Get Member Inbody Data List' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Get('member/:memberId')
  async findAllByMemberId(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() findDto: FindInbodyDataDto,
  ): Promise<IPageResponse<InbodyDataResponseDto>> {
    const pageData = await this.inbodyService.findAllByMemberId(req.user.id, memberId, findDto);
    return SuccessResponse(pageData);
  }

  /**
   * @summary 인바디 데이터 상세 조회
   */
  @ApiOperation({ summary: 'Get Inbody Data Detail' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Get('member/:memberId/:id')
  async findOne(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<InbodyDataDetailResponseDto>> {
    const data = await this.inbodyService.findOne(req.user.id, memberId, id);
    return SuccessResponse(data);
  }

  /**
   * @summary 내 인바디 데이터 셀프 등록 (Role.Member) - OCR 미구현이라 수동 입력 + 사진 첨부만
   */
  @ApiOperation({ summary: 'Create My Inbody Data (Self, Manual)' })
  @Roles(Role.Member)
  @Post('me/manual')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      required: ['measuredAt'],
      properties: {
        measuredAt: { type: 'string', format: 'date-time', example: '2026-03-14T10:00:00.000Z' },
        weight: { type: 'number', example: 75.5 },
        skeletalMuscleMass: { type: 'number', example: 33.2 },
        bodyFatMass: { type: 'number', example: 15.1 },
        bmi: { type: 'number', example: 24.1 },
        percentBodyFat: { type: 'number', example: 20.0 },
        abdominalFatRatio: { type: 'number', example: 0.85 },
        visceralFatLevel: { type: 'number', example: 8 },
        basalMetabolicRate: { type: 'number', example: 1720 },
        bodyWater: { type: 'number', example: 42.1 },
        protein: { type: 'number', example: 11.2 },
        minerals: { type: 'number', example: 3.5 },
        idealWeight: { type: 'number', example: 70.0 },
        weightControl: { type: 'number', example: -5.5 },
        fatControl: { type: 'number', example: -7.0 },
        muscleControl: { type: 'number', example: 1.5 },
        bmiEvaluation: { type: 'string', example: '표준' },
        bodyFatEvaluation: { type: 'string', example: '경도비만' },
        file: { type: 'string', format: 'binary', description: '인바디 결과지 이미지 (선택)' },
      },
    },
  })
  async createSelfManual(
    @Req() req: { user: UserEntity },
    @Body() createDto: CreateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.inbodyService.createSelfManual(req.user, createDto, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 인바디 데이터 수동 등록
   */
  @ApiOperation({ summary: 'Create Inbody Data Manually' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/manual')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      required: ['measuredAt'],
      properties: {
        measuredAt: { type: 'string', format: 'date-time', example: '2026-03-14T10:00:00.000Z' },
        weight: { type: 'number', example: 75.5 },
        skeletalMuscleMass: { type: 'number', example: 33.2 },
        bodyFatMass: { type: 'number', example: 15.1 },
        bmi: { type: 'number', example: 24.1 },
        percentBodyFat: { type: 'number', example: 20.0 },
        abdominalFatRatio: { type: 'number', example: 0.85 },
        visceralFatLevel: { type: 'number', example: 8 },
        basalMetabolicRate: { type: 'number', example: 1720 },
        bodyWater: { type: 'number', example: 42.1 },
        protein: { type: 'number', example: 11.2 },
        minerals: { type: 'number', example: 3.5 },
        idealWeight: { type: 'number', example: 70.0 },
        weightControl: { type: 'number', example: -5.5 },
        fatControl: { type: 'number', example: -7.0 },
        muscleControl: { type: 'number', example: 1.5 },
        bmiEvaluation: { type: 'string', example: '표준' },
        bodyFatEvaluation: { type: 'string', example: '경도비만' },
        file: { type: 'string', format: 'binary', description: '인바디 결과지 이미지 (선택)' },
      },
    },
  })
  async createManual(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() createDto: CreateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.inbodyService.createManual(req.user, memberId, createDto, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 인바디 결과지 OCR 등록
   */
  @ApiOperation({ summary: 'Create Inbody Data from OCR' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Post('member/:memberId/ocr')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        file: { type: 'string', format: 'binary' },
      },
    },
  })
  async createFromOcr(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @UploadedFile() file: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.inbodyService.createFromOcr(req.user, memberId, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 인바디 데이터 수정
   */
  @ApiOperation({ summary: 'Update Inbody Data' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Put('member/:memberId/:id')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        weight: { type: 'number', example: 75.5 },
        skeletalMuscleMass: { type: 'number', example: 33.2 },
        bodyFatMass: { type: 'number', example: 15.1 },
        bmi: { type: 'number', example: 24.1 },
        percentBodyFat: { type: 'number', example: 20.0 },
        abdominalFatRatio: { type: 'number', example: 0.85 },
        visceralFatLevel: { type: 'number', example: 8 },
        basalMetabolicRate: { type: 'number', example: 1720 },
        bodyWater: { type: 'number', example: 42.1 },
        protein: { type: 'number', example: 11.2 },
        minerals: { type: 'number', example: 3.5 },
        idealWeight: { type: 'number', example: 70.0 },
        weightControl: { type: 'number', example: -5.5 },
        fatControl: { type: 'number', example: -7.0 },
        muscleControl: { type: 'number', example: 1.5 },
        bmiEvaluation: { type: 'string', example: '표준' },
        bodyFatEvaluation: { type: 'string', example: '경도비만' },
        file: { type: 'string', format: 'binary', description: '인바디 결과지 이미지 (선택)' },
      },
    },
  })
  async update(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('id') id: string,
    @Body() updateDto: UpdateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.inbodyService.update(req.user, memberId, id, updateDto, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 내 인바디 데이터 수정 (회원 본인, 셀프등록분만 가능)
   */
  @ApiOperation({ summary: 'Update My Inbody Data (Self)' })
  @Roles(Role.Member)
  @Put('me/:id')
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    schema: {
      type: 'object',
      properties: {
        measuredAt: { type: 'string', format: 'date-time', example: '2026-03-14T10:00:00.000Z' },
        weight: { type: 'number', example: 75.5 },
        skeletalMuscleMass: { type: 'number', example: 33.2 },
        bodyFatMass: { type: 'number', example: 15.1 },
        bmi: { type: 'number', example: 24.1 },
        percentBodyFat: { type: 'number', example: 20.0 },
        abdominalFatRatio: { type: 'number', example: 0.85 },
        visceralFatLevel: { type: 'number', example: 8 },
        basalMetabolicRate: { type: 'number', example: 1720 },
        bodyWater: { type: 'number', example: 42.1 },
        protein: { type: 'number', example: 11.2 },
        minerals: { type: 'number', example: 3.5 },
        idealWeight: { type: 'number', example: 70.0 },
        weightControl: { type: 'number', example: -5.5 },
        fatControl: { type: 'number', example: -7.0 },
        muscleControl: { type: 'number', example: 1.5 },
        bmiEvaluation: { type: 'string', example: '표준' },
        bodyFatEvaluation: { type: 'string', example: '경도비만' },
        file: { type: 'string', format: 'binary', description: '인바디 결과지 이미지 (선택)' },
      },
    },
  })
  async updateSelf(
    @Req() req: { user: UserEntity },
    @Param('id') id: string,
    @Body() updateDto: UpdateInbodyDataDto,
    @UploadedFile() file?: Express.Multer.File,
  ): Promise<ISuccessResponse<InbodyDataEntity>> {
    const data = await this.inbodyService.updateSelf(req.user, id, updateDto, file);
    return SuccessResponse(data);
  }

  /**
   * @summary 인바디 데이터 일괄 삭제
   */
  @ApiOperation({ summary: 'Delete Inbody Data' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @UseGuards(SubscriptionGuard)
  @RequiresSubscription()
  @Delete('member/:memberId')
  async delete(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Body() deleteDto: DeleteInbodyDataDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.inbodyService.delete(req.user.id, memberId, deleteDto);
    return SuccessResponse(result);
  }

  /**
   * @summary 내 인바디 데이터 일괄 삭제 (회원 본인, 셀프등록분만 가능)
   */
  @ApiOperation({ summary: 'Delete My Inbody Data (Self)' })
  @Roles(Role.Member)
  @Delete('me')
  async deleteSelf(
    @Req() req: { user: UserEntity },
    @Body() deleteDto: DeleteInbodyDataDto,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    const result = await this.inbodyService.deleteSelf(req.user.id, deleteDto);
    return SuccessResponse(result);
  }
}

/**
 * 인바디 퍼블릭 API (인증 불필요)
 */
@ApiTags('Inbody')
@Controller('inbody')
export class PublicInbodyController {
  constructor(private readonly inbodyService: InbodyService) {}

  /**
   * @summary 인바디 상세 조회 (공유 링크 - 인증 불필요)
   */
  @ApiOperation({ summary: 'Get Inbody Data Detail (Public Share)' })
  @Get(':id/public')
  async findOnePublic(
    @Param('id') id: string,
  ): Promise<ISuccessResponse<InbodyDataDetailResponseDto>> {
    const data = await this.inbodyService.findOnePublic(id);
    return SuccessResponse(data);
  }
}

/**
 * 센터용 인바디 퍼블릭 API (인증 불필요, 공유 링크)
 */
@ApiTags('Center Inbody Public')
@Controller('center/inbody/public')
export class CenterInbodyPublicController {
  constructor(private readonly inbodyService: InbodyService) {}

  @ApiOperation({ summary: 'Get Inbody Data Detail (Center / Public / Share Link)' })
  @Get('member/:memberId/:id')
  async findOnePublic(
    @Param('memberId') memberId: string,
    @Param('id') id: string,
  ): Promise<ISuccessResponse<InbodyDataDetailResponseDto>> {
    const data = await this.inbodyService.findOnePublic(id, memberId);
    return SuccessResponse(data);
  }
}
