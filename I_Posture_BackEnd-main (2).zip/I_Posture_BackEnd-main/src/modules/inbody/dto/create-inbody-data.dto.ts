import { ApiProperty } from '@nestjs/swagger';
import { Transform } from 'class-transformer';
import { IsDateString, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateInbodyDataDto {
  @ApiProperty({ description: '측정일시', example: '2026-03-14T10:00:00.000Z' })
  @IsDateString()
  @IsNotEmpty()
  measuredAt!: string;

  // --- 골격근/지방분석 ---
  @ApiProperty({ description: '체중(kg)', required: false, example: 75.5 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  weight?: number;

  @ApiProperty({ description: '골격근량(kg)', required: false, example: 33.2 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  skeletalMuscleMass?: number;

  @ApiProperty({ description: '체지방량(kg)', required: false, example: 15.1 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  bodyFatMass?: number;

  // --- 비만분석 ---
  @ApiProperty({ description: 'BMI', required: false, example: 24.1 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  bmi?: number;

  @ApiProperty({ description: '체지방률(%)', required: false, example: 20.0 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  percentBodyFat?: number;

  @ApiProperty({ description: '복부지방률', required: false, example: 0.85 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  abdominalFatRatio?: number;

  @ApiProperty({ description: '내장지방레벨', required: false, example: 8 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  visceralFatLevel?: number;

  @ApiProperty({ description: '기초대사량(kcal)', required: false, example: 1720 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  basalMetabolicRate?: number;

  // --- 체성분분석 ---
  @ApiProperty({ description: '체수분(L)', required: false, example: 42.1 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  bodyWater?: number;

  @ApiProperty({ description: '단백질(kg)', required: false, example: 11.2 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  protein?: number;

  @ApiProperty({ description: '무기질(kg)', required: false, example: 3.5 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  minerals?: number;

  // --- 체중조절 ---
  @ApiProperty({ description: '적정체중(kg)', required: false, example: 70.0 })
  @IsOptional()
  @Transform(({ value }) => value !== undefined ? parseFloat(value) : undefined)
  @IsNumber()
  idealWeight?: number;

  @ApiProperty({ description: '체중조절(kg)', required: false, example: '-5.5' })
  @IsOptional()
  @IsString()
  weightControl?: string;

  @ApiProperty({ description: '지방조절(kg)', required: false, example: '-7.0' })
  @IsOptional()
  @IsString()
  fatControl?: string;

  @ApiProperty({ description: '근육조절(kg)', required: false, example: '+1.5' })
  @IsOptional()
  @IsString()
  muscleControl?: string;

  // --- 비만평가 ---
  @ApiProperty({ description: 'BMI 평가 텍스트', required: false, example: '표준' })
  @IsOptional()
  @IsString()
  bmiEvaluation?: string;

  @ApiProperty({ description: '체지방률 평가 텍스트', required: false, example: '경도비만' })
  @IsOptional()
  @IsString()
  bodyFatEvaluation?: string;
}
