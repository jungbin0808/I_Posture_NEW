import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsEnum, IsOptional } from 'class-validator';
import { PaginationDto } from '../../../common/dto/pagination.dto';

export enum InbodySortOrder {
  DATE_ASC = 'DATE_ASC',
  DATE_DESC = 'DATE_DESC',
}

export class FindInbodyDataDto extends PaginationDto {
  @ApiProperty({ description: '조회 시작 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '조회 종료 날짜 (YYYY-MM-DD)', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({ description: '정렬 순서', enum: InbodySortOrder, required: false, default: InbodySortOrder.DATE_DESC })
  @IsEnum(InbodySortOrder)
  @IsOptional()
  sort?: InbodySortOrder = InbodySortOrder.DATE_DESC;
}
