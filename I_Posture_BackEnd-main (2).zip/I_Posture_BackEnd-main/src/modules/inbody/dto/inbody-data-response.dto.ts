import { ApiProperty } from '@nestjs/swagger';

// 목록용 DTO
export class InbodyDataResponseDto {
  @ApiProperty({ description: '데이터 ID' })
  id!: string;

  @ApiProperty({ description: '측정 날짜' })
  measuredAt!: Date;

  @ApiProperty({ description: '인바디 종합 점수', nullable: true })
  score?: number;

  @ApiProperty({ description: 'BMI', nullable: true })
  bmi?: number;

  @ApiProperty({ description: '체지방률 (%)', nullable: true })
  percentBodyFat?: number;

  @ApiProperty({ description: '체중 (kg)', nullable: true })
  weight?: number;

  @ApiProperty({ description: '골격근량 (kg)', nullable: true })
  skeletalMuscleMass?: number;

  @ApiProperty({ description: '체지방량 (kg)', nullable: true })
  bodyFatMass?: number;

  @ApiProperty({ description: '기초대사량 (kcal)', nullable: true })
  basalMetabolicRate?: number;
}

// 상세용 DTO
export class InbodyDataDetailResponseDto extends InbodyDataResponseDto {
  @ApiProperty({ description: '주요 수치 (JSON)', nullable: true })
  keyStats?: any;

  @ApiProperty({ description: '상세 분석 데이터 (JSON)', nullable: true })
  detailData?: any;
}
