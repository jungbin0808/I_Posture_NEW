import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { InjectRepository } from '@nestjs/typeorm';
import { LessThanOrEqual, Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { addMonthsClamp, addYearsClamp, getUtcDateString } from '../../common/utils/date.util';
import { SubscriptionEntity, SubscriptionStatus, BillingCycle } from '../../database/entities/subscription.entity';
import { PaymentEntity, PaymentChannel, PaymentStatus, PaymentType } from '../../database/entities/payment.entity';
import { SubscriptionRenewalLogEntity, RenewalStatus } from '../../database/entities/subscription-renewal-log.entity';
import { UserEntity, PaymentStatus as UserPaymentStatus } from '../../database/entities/user.entity';
import { KpnPaymentService } from '../kpn-payment/kpn-payment.service';
import { CapacityService } from '../capacity/capacity.service';
import { runInTransaction } from 'typeorm-transactional';
import { SubscriptionService } from './subscription.service';

@Injectable()
export class SubscriptionScheduler {
  private readonly logger = new Logger(SubscriptionScheduler.name);
  private readonly enabled: boolean;
  private readonly heartbeatEnabled: boolean;

  constructor(
    private readonly configService: ConfigService,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    @InjectRepository(PaymentEntity)
    private readonly paymentRepo: Repository<PaymentEntity>,
    @InjectRepository(SubscriptionRenewalLogEntity)
    private readonly renewalLogRepo: Repository<SubscriptionRenewalLogEntity>,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    private readonly kpnPaymentService: KpnPaymentService,
    private readonly capacityService: CapacityService,
    private readonly subscriptionService: SubscriptionService,
  ) {
    this.enabled = this.configService.get<string>('SUBSCRIPTION_SCHEDULER_ENABLED') === 'true';
    this.heartbeatEnabled = this.configService.get<string>('SUBSCRIPTION_SCHEDULER_HEARTBEAT') === 'true';
  }

  // 매일 KST 00:00 (= UTC 15:00). 날짜 비교는 UTC 기준(getUtcDateString).
  @Cron('0 15 * * *')
  async handleRenewal(): Promise<void> {
    if (!this.enabled) {
      this.logger.log('구독 자동갱신 스케줄러 비활성화 상태 (SUBSCRIPTION_SCHEDULER_ENABLED=false)');
      return;
    }

    this.logger.log('구독 자동갱신 스케줄러 시작');

    const today = getUtcDateString();

    // 오늘 만료되는 ACTIVE 구독 전체 조회
    const subscriptions = await this.subscriptionRepo.find({
      where: {
        status: SubscriptionStatus.ACTIVE,
        nextBillingDate: LessThanOrEqual(today),
      },
      relations: ['plan'],
    });

    this.logger.log(`처리 대상 구독 수: ${subscriptions.length}`);

    for (const subscription of subscriptions) {
      try {
        await this._processOne(subscription);
      } catch (err) {
        this.logger.error(`구독 ${subscription.id} 처리 실패: ${err}`);
      }
    }

    this.logger.log('구독 자동갱신 스케줄러 완료');
  }

  // 서버 스케줄러 동작 확인용 (SUBSCRIPTION_SCHEDULER_HEARTBEAT=true 시 1분마다 로그)
  @Cron('*/1 * * * *')
  async handleSchedulerHeartbeat(): Promise<void> {
    if (!this.heartbeatEnabled) {
      return;
    }

    const nowUtc = new Date().toISOString();
    this.logger.log(
      `구독 스케줄러 heartbeat | at=${nowUtc} | SUBSCRIPTION_SCHEDULER_ENABLED=${this.enabled} | renewalCron=0 15 * * * UTC (KST 00:00)`,
    );
  }

  /**
   * 구독 1건 자동갱신 (스케줄러 테스트용).
   * force=false(기본)이면 운영 스케줄러와 동일하게 ACTIVE + next_billing_date <= UTC 오늘만 처리.
   */
  async renewSubscriptionById(
    subscriptionId: string,
    options?: { force?: boolean },
  ): Promise<void> {
    const subscription = await this.subscriptionRepo.findOne({
      where: { id: subscriptionId },
      relations: ['plan'],
    });

    if (!subscription) {
      throw new NotFoundException(`구독을 찾을 수 없습니다: ${subscriptionId}`);
    }

    if (!options?.force) {
      const today = getUtcDateString();

      if (subscription.status !== SubscriptionStatus.ACTIVE) {
        throw new BadRequestException(`ACTIVE 구독만 처리할 수 있습니다 (현재: ${subscription.status})`);
      }

      if (!subscription.nextBillingDate || subscription.nextBillingDate > today) {
        throw new BadRequestException(
          `next_billing_date가 UTC 오늘(${today}) 이전이 아닙니다: ${subscription.nextBillingDate ?? 'null'}`,
        );
      }
    }

    await this._processOne(subscription);
  }

  private async _processOne(subscription: SubscriptionEntity): Promise<void> {
    // 트레이너 지급(ONE_TIME): 갱신 없이 만료 + 용량 회수
    if (subscription.billingCycle === BillingCycle.ONE_TIME) {
      await this._expireOneTimeSubscription(subscription);
      return;
    }

    // 해지 예약 상태 → EXPIRED 처리
    if (subscription.cancelAtPeriodEnd) {
      await runInTransaction(async () => {
        subscription.status = SubscriptionStatus.EXPIRED;
        await this.subscriptionRepo.save(subscription);
        await this.userRepo.update(subscription.userId, { paymentStatus: UserPaymentStatus.UNPAID });
        await this.renewalLogRepo.save(
          this.renewalLogRepo.create({
            subscriptionId: subscription.id,
            userId: subscription.userId,
            planId: subscription.planId,
            status: RenewalStatus.EXPIRED,
          }),
        );
      });
      this.logger.log(`구독 만료 처리 (해지 예약): subscriptionId=${subscription.id}`);
      return;
    }

    // 자동 갱신할 빌키 조회
    // - 일반 구독: 가장 최근 성공 결제에서 사용한 빌키
    // - 체험 구독: 결제 내역이 없으므로 사용자의 활성 빌키로 폴백
    const lastPayment = await this.paymentRepo.findOne({
      where: { subscriptionId: subscription.id, status: PaymentStatus.SUCCESS },
      order: { paidAt: 'DESC' },
    });

    let billKeyId: string | undefined = lastPayment?.billKeyId;

    if (!billKeyId && subscription.isTrial) {
      const activeBillKey = await this.kpnPaymentService.getActiveBillKey(subscription.userId);
      billKeyId = activeBillKey?.id;
    }

    if (!billKeyId) {
      const reason = '자동갱신 실패 - 등록된 빌키 없음';
      this.logger.warn(`${reason}: subscriptionId=${subscription.id}`);
      await runInTransaction(async () => {
        subscription.status = SubscriptionStatus.EXPIRED;
        await this.subscriptionRepo.save(subscription);
        await this.userRepo.update(subscription.userId, { paymentStatus: UserPaymentStatus.UNPAID });
        await this.renewalLogRepo.save(
          this.renewalLogRepo.create({
            subscriptionId: subscription.id,
            userId: subscription.userId,
            planId: subscription.planId,
            status: RenewalStatus.FAILED,
            failReason: reason,
          }),
        );
      });
      return;
    }

    const plan = subscription.plan;
    const amount = subscription.billingCycle === BillingCycle.YEARLY ? plan.price * 12 : plan.price;

    const now = new Date();
    const datePart = now.getFullYear().toString()
      + String(now.getMonth() + 1).padStart(2, '0')
      + String(now.getDate()).padStart(2, '0')
      + String(now.getHours()).padStart(2, '0')
      + String(now.getMinutes()).padStart(2, '0')
      + String(now.getSeconds()).padStart(2, '0');
    const mxIssueNo = `${datePart}${Math.random().toString(36).slice(2, 8).padEnd(6, '0')}`;

    let approvalResult: { tid: string; authNo: string; payMethod: string; mxIssueNo: string; mxIssueDate: string };
    try {
      // KPN 빌키 결제 승인
      approvalResult = await this.kpnPaymentService.approveBillPayment({
        userId: subscription.userId,
        billKeyId,
        mxIssueNo,
        mxIssueDate: datePart,
        amount,
        goodsName: plan.name,
      });
    } catch (err) {
      const reason = err instanceof Error ? err.message : String(err);
      this.logger.error(`KPN 결제 실패: subscriptionId=${subscription.id} reason=${reason}`);
      await runInTransaction(async () => {
        subscription.status = SubscriptionStatus.EXPIRED;
        await this.subscriptionRepo.save(subscription);
        await this.userRepo.update(subscription.userId, { paymentStatus: UserPaymentStatus.UNPAID });
        await this.renewalLogRepo.save(
          this.renewalLogRepo.create({
            subscriptionId: subscription.id,
            userId: subscription.userId,
            planId: subscription.planId,
            status: RenewalStatus.FAILED,
            amount,
            billKeyId,
            failReason: reason,
          }),
        );
      });
      return;
    }

    // nextBillingDate 연장 (말일 처리)
    const currentNextBillingDate = new Date(subscription.nextBillingDate!);
    const nextBillingDate = subscription.billingCycle === BillingCycle.YEARLY
      ? addYearsClamp(currentNextBillingDate, 1)
      : addMonthsClamp(currentNextBillingDate, 1);
    subscription.nextBillingDate = getUtcDateString(nextBillingDate);

    // 체험 구독이 결제 성공 시 정규 구독으로 전환
    if (subscription.isTrial) {
      subscription.isTrial = false;
      this.logger.log(`체험→정규 구독 전환: subscriptionId=${subscription.id}`);
    }

    await runInTransaction(async () => {
      await this.subscriptionRepo.save(subscription);

      await this.paymentRepo.save(
        this.paymentRepo.create({
          userId: subscription.userId,
          subscriptionId: subscription.id,
          amount,
          status: PaymentStatus.SUCCESS,
          paymentChannel: PaymentChannel.KPN,
          paymentType: PaymentType.SUBSCRIPTION,
          pgProvider: 'KPN',
          billKeyId,
          tid: approvalResult.tid,
          authNo: approvalResult.authNo,
          payMethod: approvalResult.payMethod,
          mxIssueNo: approvalResult.mxIssueNo,
          mxIssueDate: approvalResult.mxIssueDate,
          replyCode: '0000',
        }),
      );

      await this.renewalLogRepo.save(
        this.renewalLogRepo.create({
          subscriptionId: subscription.id,
          userId: subscription.userId,
          planId: subscription.planId,
          status: RenewalStatus.SUCCESS,
          amount,
          billKeyId,
          tid: approvalResult.tid,
        }),
      );
    });

    this.logger.log(`자동갱신 성공: subscriptionId=${subscription.id} amount=${amount} tid=${approvalResult.tid}`);
  }

  /** 트레이너 지급 ONE_TIME 이용권 만료 — 갱신 없이 EXPIRED + 용량 회수 */
  private async _expireOneTimeSubscription(subscription: SubscriptionEntity): Promise<void> {
    await runInTransaction(async () => {
      subscription.status = SubscriptionStatus.EXPIRED;
      await this.subscriptionRepo.save(subscription);

      await this.capacityService.deallocateCapacityForMember(
        subscription.userId,
        subscription.plan?.storageLimit,
      );
      await this.subscriptionService.syncPaymentStatus(subscription.userId);

      await this.renewalLogRepo.save(
        this.renewalLogRepo.create({
          subscriptionId: subscription.id,
          userId: subscription.userId,
          planId: subscription.planId,
          status: RenewalStatus.EXPIRED,
        }),
      );
    });

    this.logger.log(
      `ONE_TIME 이용권 만료 처리: subscriptionId=${subscription.id} memberId=${subscription.userId}`,
    );
  }
}
