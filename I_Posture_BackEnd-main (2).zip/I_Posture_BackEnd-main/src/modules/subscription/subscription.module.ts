import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SubscriptionService } from './subscription.service';
import { SubscriptionController } from './subscription.controller';
import { SubscriptionScheduler } from './subscription.scheduler';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { SubscriptionPlanEntity } from '../../database/entities/subscription-plan.entity';
import { TrainerUserEntity } from '../../database/entities/trainer-user.entity';
import { PaymentEntity } from '../../database/entities/payment.entity';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { MemberIdentityLinkEntity } from '../../database/entities/member-identity-link.entity';
import { SubscriptionRenewalLogEntity } from '../../database/entities/subscription-renewal-log.entity';
import { SubscriptionCancellationLogEntity } from '../../database/entities/subscription-cancellation-log.entity';
import { UserEntity } from '../../database/entities/user.entity';
import { CapacityModule } from '../capacity/capacity.module';
import { KpnPaymentModule } from '../kpn-payment/kpn-payment.module';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      SubscriptionEntity,
      SubscriptionPlanEntity,
      TrainerUserEntity,
      PaymentEntity,
      TrainerCapacityPoolEntity,
      FileEntity,
      MemberIdentityLinkEntity,
      SubscriptionRenewalLogEntity,
      SubscriptionCancellationLogEntity,
      UserEntity,
    ]),
    CapacityModule,
    KpnPaymentModule,
  ],
  controllers: [SubscriptionController],
  providers: [SubscriptionService, SubscriptionScheduler],
  exports: [SubscriptionService, SubscriptionScheduler],
})
export class SubscriptionModule {}
