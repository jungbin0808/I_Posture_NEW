import { Injectable, NotFoundException, ForbiddenException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindManyOptions, In } from 'typeorm';
import { addMonthsClamp, addYearsClamp } from '../../common/utils/date.util';
import { SubscriptionEntity, SubscriptionStatus, BillingCycle } from '../../database/entities/subscription.entity';
import { SubscriptionPlanEntity } from '../../database/entities/subscription-plan.entity';
import { UserEntity, PaymentStatus as UserPaymentStatus } from '../../database/entities/user.entity';
import { TrainerUserEntity, TrainerUserStatus } from '../../database/entities/trainer-user.entity';
import { PaymentEntity, PaymentStatus, PaymentChannel, PaymentType } from '../../database/entities/payment.entity';
import { FileEntity } from '../../database/entities/file.entity';
import { GrantSubscriptionDto } from './dto/grant-subscription.dto';
import { FindSubscriptionPlanDto } from './dto/find-subscription-plan.dto';
import { ProcessPaymentDto } from './dto/process-payment.dto';
import { IPageData } from '../../common/response/response.interface';
import { buildPaging } from '../../common/response/response.helper';
import { UpdateSubscriptionDto } from './dto/update-subscription.dto';
import { MemberSubscriptionResponseDto } from './dto/member-subscription-response.dto';
import { TrainerCapacityPoolEntity } from '../../database/entities/trainer-capacity-pool.entity';
import { CapacityService } from '../capacity/capacity.service';
import { FindMemberSubscriptionsDto } from './dto/find-member-subscriptions.dto';
import { SubscriptionPlanItemResponseDto } from './dto/subscription-plan-item-response.dto';
import { MemberIdentityLinkEntity, IdentityLinkStatus } from '../../database/entities/member-identity-link.entity';
import { KpnPaymentService } from '../kpn-payment/kpn-payment.service';
import { UserType } from '../../database/entities/user.entity';
import { SubscriptionScope } from '../../common/enums/subscription.enum';
import { Transactional, runInTransaction } from 'typeorm-transactional';
import {
  SubscriptionCancellationLogEntity,
  CancellationAction,
  CancellationReason,
} from '../../database/entities/subscription-cancellation-log.entity';

@Injectable()
export class SubscriptionService {
  constructor(
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    @InjectRepository(SubscriptionPlanEntity)
    private readonly planRepo: Repository<SubscriptionPlanEntity>,
    @InjectRepository(TrainerUserEntity)
    private readonly trainerUserRepo: Repository<TrainerUserEntity>,
    @InjectRepository(PaymentEntity)
    private readonly paymentRepo: Repository<PaymentEntity>,
    @InjectRepository(FileEntity)
    private readonly fileRepo: Repository<FileEntity>,
    @InjectRepository(MemberIdentityLinkEntity)
    private readonly identityLinkRepo: Repository<MemberIdentityLinkEntity>,
    private readonly capacityService: CapacityService,
    private readonly kpnPaymentService: KpnPaymentService,
    @InjectRepository(UserEntity)
    private readonly userRepo: Repository<UserEntity>,
    @InjectRepository(SubscriptionCancellationLogEntity)
    private readonly cancellationLogRepo: Repository<SubscriptionCancellationLogEntity>,
  ) {}

  private async logCancellationChange(
    subscription: SubscriptionEntity,
    action: CancellationAction,
    reason: CancellationReason,
  ): Promise<void> {
    await this.cancellationLogRepo.save(
      this.cancellationLogRepo.create({
        subscriptionId: subscription.id,
        userId: subscription.userId,
        action,
        reason,
        nextBillingDate: subscription.nextBillingDate,
      }),
    );
  }

  async findAllPlans(user: UserEntity, findDto: FindSubscriptionPlanDto): Promise<IPageData<SubscriptionPlanItemResponseDto>> {
    const { page = 1, limit = 10 } = findDto;
    const planScope = this.resolvePlanScopeForUser(user);

    const [plans, total] = await this.planRepo.findAndCount({
      where: { isPublic: true, scope: planScope },
      order: { price: 'ASC' },
      skip: (page - 1) * limit,
      take: limit,
    });

    // 현재 유저의 활성 구독 planId 조회
    const activeSub = await this.subscriptionRepo.findOne({
      where: { userId: user.id, status: SubscriptionStatus.ACTIVE },
    });

    // 무료체험 이용 이력 (만료/취소 포함 — 한 번이라도 했으면 true)
    const trialUsed = await this.subscriptionRepo.findOne({
      where: { userId: user.id, isTrial: true },
    });

    const items: SubscriptionPlanItemResponseDto[] = plans.map((plan) => {
      const isSubscribed = activeSub?.planId === plan.id;
      const item: SubscriptionPlanItemResponseDto = {
        ...plan,
        isSubscribed,
        isTrial: trialUsed?.planId === plan.id,
      };

      if (isSubscribed && activeSub?.nextBillingDate) {
        const [, , day] = activeSub.nextBillingDate.split('-');
        item.nextBillingDate = activeSub.nextBillingDate;
        item.billingDayOfMonth = Number(day);
        item.billingCycle = activeSub.billingCycle;
      }

      return item;
    });

    return { items, paging: buildPaging(total, limit, page) };
  }

  @Transactional()
  async grantSubscription(trainerId: string, memberId: string, grantDto: GrantSubscriptionDto): Promise<SubscriptionEntity> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);

    // 앱 연동 여부 확인
    const identityLink = await this.identityLinkRepo.findOne({
      where: { managedMemberId: memberId, status: IdentityLinkStatus.LINKED },
    });
    if (!identityLink) {
      throw new BadRequestException('앱 연동이 되어있지 않은 회원에게는 이용권을 지급할 수 없습니다.');
    }

    // 이미 활성화된 이용권이 있는지 확인
    const existingActiveSubscription = await this.subscriptionRepo.findOne({
      where: { userId: memberId, status: SubscriptionStatus.ACTIVE },
    });

    if (existingActiveSubscription) {
      throw new BadRequestException('이미 이용중인 이용권이 있습니다. 기존 이용권이 만료된 후 지급해주세요.');
    }

    const plan = await this.planRepo.findOne({ where: { id: grantDto.planId } });
    if (!plan) {
      throw new NotFoundException('이용권 상품을 찾을 수 없습니다.');
    }

    const subscription = this.subscriptionRepo.create({
      userId: memberId,
      planId: grantDto.planId,
      status: SubscriptionStatus.ACTIVE,
      scope: plan.scope,
      billingCycle: BillingCycle.ONE_TIME,
      nextBillingDate: grantDto.endDate.slice(0, 10),
    });
    
    const savedSubscription = await this.subscriptionRepo.save(subscription);

    // 용량 예약 (실패 시 트랜잭션 롤백)
    await this.capacityService.allocateCapacity(trainerId, memberId, plan.storageLimit);
    await this.syncPaymentStatus(memberId);

    return savedSubscription;
  }

  async processPayment(user: UserEntity, paymentDto: ProcessPaymentDto): Promise<{ payment: PaymentEntity | null; subscription: SubscriptionEntity }> {
    // 1. 새 플랜 조회
    const newPlan = await this.planRepo.findOne({ where: { id: paymentDto.planId } });
    if (!newPlan) {
      throw new NotFoundException('이용권 상품을 찾을 수 없습니다.');
    }

    const expectedScope = this.resolvePlanScopeForUser(user);
    if (newPlan.scope !== expectedScope) {
      throw new BadRequestException('해당 이용권은 구매할 수 없습니다.');
    }

    const billingCycle = paymentDto.billingCycle ?? BillingCycle.MONTHLY;
    const now = new Date();

    // 기존 ACTIVE 구독 확인
    const existingSubscription = await this.subscriptionRepo.findOne({
      where: { userId: user.id, status: SubscriptionStatus.ACTIVE },
      relations: ['plan'],
    });

    // ── 신규 구독 ────────────────────────────────────────────────────
    if (!existingSubscription) {
      const activeBillKey = await this.kpnPaymentService.getActiveBillKey(user.id);
      if (!activeBillKey) {
        throw new BadRequestException('등록된 카드가 없습니다. 카드를 먼저 등록해 주세요.');
      }
      return this._createNewSubscription(user, newPlan, billingCycle, activeBillKey.id, now);
    }

    const currentPlan = existingSubscription.plan;
    if (!currentPlan) {
      throw new BadRequestException('현재 구독 플랜 정보를 불러올 수 없습니다.');
    }

    // ── 동일 플랜: 자동결제 유지, 변경 없음 ───────────────────────────
    if (existingSubscription.planId === newPlan.id) {
      return { payment: null, subscription: existingSubscription };
    }

    const currentStorage = BigInt(currentPlan.storageLimit);
    const newStorage = BigInt(newPlan.storageLimit);

    // ── 다운그레이드(용량 축소): 해지 예약 ─────────────────────────────
    if (newStorage < currentStorage) {
      existingSubscription.cancelAtPeriodEnd = true;
      const updated = await this.subscriptionRepo.save(existingSubscription);
      await this.logCancellationChange(updated, CancellationAction.REQUESTED, CancellationReason.DOWNGRADE);
      return { payment: null, subscription: updated };
    }

    // ── 동일 용량: 결제·플랜 변경 없음 ─────────────────────────────────
    if (newStorage === currentStorage) {
      return { payment: null, subscription: existingSubscription };
    }

    // ── 업그레이드(용량 확대): 잔여 크레딧 차감 후 차액 결제 ─────────
    const activeBillKey = await this.kpnPaymentService.getActiveBillKey(user.id);
    if (!activeBillKey) {
      throw new BadRequestException('등록된 카드가 없습니다. 카드를 먼저 등록해 주세요.');
    }
    const billKeyId = activeBillKey.id;

    const nextBillingDate = billingCycle === BillingCycle.YEARLY
      ? addYearsClamp(now, 1)
      : addMonthsClamp(now, 1);

    let amount = billingCycle === BillingCycle.YEARLY ? newPlan.price * 12 : newPlan.price;

    // 업그레이드 시 잔여 크레딧 계산 (iCloud A방식, 금액은 결제 계산에만 사용)
    if (existingSubscription.nextBillingDate) {
      const periodEnd = new Date(existingSubscription.nextBillingDate);
      const periodStart = new Date(periodEnd);
      if (existingSubscription.billingCycle === BillingCycle.YEARLY) {
        periodStart.setFullYear(periodStart.getFullYear() - 1);
      } else {
        periodStart.setMonth(periodStart.getMonth() - 1);
      }
      const totalDays = Math.round((periodEnd.getTime() - periodStart.getTime()) / 86400000);
      const remainDays = Math.max(0, Math.round((periodEnd.getTime() - now.getTime()) / 86400000));
      const currentPeriodPrice = existingSubscription.billingCycle === BillingCycle.YEARLY
        ? currentPlan.price * 12
        : currentPlan.price;
      const dailyRate = Math.round(currentPeriodPrice / totalDays);
      const credit = dailyRate * remainDays;
      amount = Math.max(0, amount - credit);
    }

    // 결제 (amount=0이면 KPN 호출 생략)
    let approvalResult: { tid: string; authNo: string; payMethod: string; mxIssueNo: string; mxIssueDate: string } | null = null;
    if (amount > 0) {
      const datePart = now.getFullYear().toString()
        + String(now.getMonth() + 1).padStart(2, '0')
        + String(now.getDate()).padStart(2, '0')
        + String(now.getHours()).padStart(2, '0')
        + String(now.getMinutes()).padStart(2, '0')
        + String(now.getSeconds()).padStart(2, '0');
      const mxIssueNo = `${datePart}${Math.random().toString(36).slice(2, 8).padEnd(6, '0')}`;

      approvalResult = await this.kpnPaymentService.approveBillPayment({
        userId: user.id,
        billKeyId,
        mxIssueNo,
        mxIssueDate: datePart,
        amount,
        goodsName: newPlan.name,
      });
    }

    // 구독 갱신 (plan relation이 로드된 상태에서 planId만 바꾸면 save 시 이전 plan으로 되돌아갈 수 있음)
    const hadCancelReserved = existingSubscription.cancelAtPeriodEnd;
    existingSubscription.planId = newPlan.id;
    existingSubscription.plan = newPlan;
    existingSubscription.billingCycle = billingCycle;
    existingSubscription.nextBillingDate = nextBillingDate.toISOString().split('T')[0];
    existingSubscription.scope = newPlan.scope;
    existingSubscription.cancelAtPeriodEnd = false;

    return runInTransaction(async () => {
      const updatedSubscription = await this.subscriptionRepo.save(existingSubscription);
      if (hadCancelReserved) {
        await this.logCancellationChange(updatedSubscription, CancellationAction.REVOKED, CancellationReason.UPGRADE);
      }

      let savedPayment: PaymentEntity | null = null;
      if (approvalResult) {
        const payment = this.paymentRepo.create({
          userId: user.id,
          subscriptionId: updatedSubscription.id,
          amount,
          status: PaymentStatus.SUCCESS,
          paymentChannel: PaymentChannel.KPN,
          paymentType: PaymentType.SUBSCRIPTION,
          pgProvider: 'KPN',
          billKeyId,
          tid: approvalResult.tid,
          authNo: approvalResult.authNo,
          payMethod: approvalResult.payMethod,
          mxIssueNo: approvalResult.mxIssueNo,
          mxIssueDate: approvalResult.mxIssueDate,
          replyCode: '0000',
        });
        savedPayment = await this.paymentRepo.save(payment);
      }

      await this.capacityService.applySubscriptionCapacity(user, newPlan.storageLimit);
      await this.syncPaymentStatus(user.id);

      return { payment: savedPayment, subscription: updatedSubscription };
    });
  }

  async cancelSubscription(userId: string): Promise<SubscriptionEntity> {
    const subscription = await this.subscriptionRepo.findOne({
      where: { userId, status: SubscriptionStatus.ACTIVE },
    });
    if (!subscription) {
      throw new NotFoundException('활성화된 이용권이 없습니다.');
    }
    subscription.cancelAtPeriodEnd = true;
    const updated = await this.subscriptionRepo.save(subscription);
    await this.logCancellationChange(updated, CancellationAction.REQUESTED, CancellationReason.USER_REQUEST);
    return updated;
  }

  @Transactional()
  async startTrial(user: UserEntity, planId: string): Promise<SubscriptionEntity> {
    if (user.userType !== UserType.F_TRAINER && user.userType !== UserType.CENTER) {
      throw new BadRequestException('무료체험은 개인 트레이너 또는 센터 오너만 이용 가능합니다.');
    }

    // 이미 체험 이용 이력 확인 (만료/취소 포함)
    const trialUsed = await this.subscriptionRepo.findOne({
      where: { userId: user.id, isTrial: true },
    });
    if (trialUsed) {
      throw new BadRequestException('무료체험은 1회만 이용 가능합니다.');
    }

    // 카드(빌키) 등록 여부 확인 — 무료체험도 반드시 카드 등록 필요
    const billKey = await this.kpnPaymentService.getActiveBillKey(user.id);
    if (!billKey) {
      throw new BadRequestException('카드를 먼저 등록해주세요.');
    }

    // 이미 활성 구독 확인
    const activeSubscription = await this.subscriptionRepo.findOne({
      where: { userId: user.id, status: SubscriptionStatus.ACTIVE },
    });
    if (activeSubscription) {
      throw new BadRequestException('이미 이용 중인 이용권이 있습니다.');
    }

    const plan = await this.planRepo.findOne({ where: { id: planId } });
    if (!plan) {
      throw new NotFoundException('이용권 상품을 찾을 수 없습니다.');
    }
    const expectedScope = this.resolvePlanScopeForUser(user);
    if (plan.scope !== expectedScope) {
      throw new BadRequestException('해당 이용권은 무료체험할 수 없습니다.');
    }
    if (!plan.isTrialAvailable) {
      throw new BadRequestException('해당 이용권은 무료체험이 불가능합니다.');
    }

    const now = new Date();
    const trialEndDate = new Date(now);
    trialEndDate.setDate(trialEndDate.getDate() + 14);

    const subscription = this.subscriptionRepo.create({
      userId: user.id,
      planId: plan.id,
      status: SubscriptionStatus.ACTIVE,
      scope: plan.scope,
      billingCycle: BillingCycle.MONTHLY,
      nextBillingDate: trialEndDate.toISOString().split('T')[0],
      cancelAtPeriodEnd: false,
      isTrial: true,
    });

    const saved = await this.subscriptionRepo.save(subscription);
    await this.capacityService.applySubscriptionCapacity(user, plan.storageLimit);
    await this.syncPaymentStatus(user.id);
    return saved;
  }

  private async _createNewSubscription(
    user: UserEntity,
    plan: SubscriptionPlanEntity,
    billingCycle: BillingCycle,
    billKeyId: string,
    now: Date,
  ): Promise<{ payment: PaymentEntity; subscription: SubscriptionEntity }> {
    const amount = billingCycle === BillingCycle.YEARLY ? plan.price * 12 : plan.price;

    const datePart = now.getFullYear().toString()
      + String(now.getMonth() + 1).padStart(2, '0')
      + String(now.getDate()).padStart(2, '0')
      + String(now.getHours()).padStart(2, '0')
      + String(now.getMinutes()).padStart(2, '0')
      + String(now.getSeconds()).padStart(2, '0');
    const mxIssueNo = `${datePart}${Math.random().toString(36).slice(2, 8).padEnd(6, '0')}`;

    const approvalResult = await this.kpnPaymentService.approveBillPayment({
      userId: user.id,
      billKeyId,
      mxIssueNo,
      mxIssueDate: datePart,
      amount,
      goodsName: plan.name,
    });

    const nextBillingDate = billingCycle === BillingCycle.YEARLY
      ? addYearsClamp(now, 1)
      : addMonthsClamp(now, 1);

    return runInTransaction(async () => {
      const subscription = await this.subscriptionRepo.save(
        this.subscriptionRepo.create({
          userId: user.id,
          planId: plan.id,
          status: SubscriptionStatus.ACTIVE,
          scope: plan.scope,
          billingCycle,
          nextBillingDate: nextBillingDate.toISOString().split('T')[0],
          cancelAtPeriodEnd: false,
        }),
      );

      const payment = await this.paymentRepo.save(
        this.paymentRepo.create({
          userId: user.id,
          subscriptionId: subscription.id,
          amount,
          status: PaymentStatus.SUCCESS,
          paymentChannel: PaymentChannel.KPN,
          paymentType: PaymentType.SUBSCRIPTION,
          pgProvider: 'KPN',
          billKeyId,
          tid: approvalResult.tid,
          authNo: approvalResult.authNo,
          payMethod: approvalResult.payMethod,
          mxIssueNo: approvalResult.mxIssueNo,
          mxIssueDate: approvalResult.mxIssueDate,
          replyCode: '0000',
        }),
      );

      await this.capacityService.applySubscriptionCapacity(user, plan.storageLimit);
      await this.syncPaymentStatus(user.id);

      return { payment, subscription };
    });
  }

  // --- 회원 상세용 CRUD ---

  async findAllByMember(trainerId: string, memberId: string, findDto: FindMemberSubscriptionsDto): Promise<IPageData<MemberSubscriptionResponseDto>> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);
    return this.fetchMemberSubscriptions(memberId, findDto);
  }

  /**
   * 회원 본인 기준 이용권(멤버십) 이력 조회. 앱 회원은 관리회원 ID로 연동돼야 이용권이 조회됨 - 연동 안 돼있으면 빈 목록.
   */
  async findAllByOwnMember(appMemberId: string, findDto: FindMemberSubscriptionsDto): Promise<IPageData<MemberSubscriptionResponseDto>> {
    const link = await this.identityLinkRepo.findOne({ where: { appMemberId, status: IdentityLinkStatus.LINKED } });
    if (!link) {
      const { page = 1, limit = 10 } = findDto;
      return { items: [], paging: buildPaging(0, limit, page) };
    }
    return this.fetchMemberSubscriptions(link.managedMemberId, findDto);
  }

  private async fetchMemberSubscriptions(memberId: string, findDto: FindMemberSubscriptionsDto): Promise<IPageData<MemberSubscriptionResponseDto>> {
    const { page = 1, limit = 10, sort } = findDto;

    const [subscriptions, total] = await this.subscriptionRepo.findAndCount({
      where: { userId: memberId },
      order: { createdAt: sort },
      relations: ['plan'],
      skip: (page - 1) * limit,
      take: limit,
    });

    const resultPromises = subscriptions.map(async (sub) => {
      const startDate = sub.createdAt;
      const endDate = sub.nextBillingDate ? new Date(sub.nextBillingDate) : new Date();

      const { totalUsage } = await this.fileRepo.createQueryBuilder("file")
        .select("SUM(file.size)", "totalUsage")
        .where("file.ownerId = :memberId", { memberId })
        .andWhere("file.createdAt BETWEEN :startDate AND :endDate", { startDate, endDate })
        .getRawOne();

      const memberUsage = totalUsage || '0';
      const memberCapacity = sub.plan?.storageLimit ?? '0';
      const remaining = BigInt(memberCapacity) - BigInt(memberUsage);
      const memberRemaining = (remaining < 0n ? 0n : remaining).toString();

      return this.mapToMemberSubscriptionDto(
        sub,
        memberUsage,
        memberRemaining
      );
    });

    const items = await Promise.all(resultPromises);
    return { items, paging: buildPaging(total, limit, page) };
  }

  async updateForMember(trainerId: string, memberId: string, subscriptionId: string, updateDto: UpdateSubscriptionDto): Promise<SubscriptionEntity> {
    const subscription = await this.findOneByMember(trainerId, memberId, subscriptionId);
    Object.assign(subscription, updateDto);
    return this.subscriptionRepo.save(subscription);
  }

  @Transactional()
  async updateStatusForMember(trainerId: string, memberId: string, subscriptionId: string, status: SubscriptionStatus): Promise<SubscriptionEntity> {
    const subscription = await this.findOneByMember(trainerId, memberId, subscriptionId);
    if (!Object.values(SubscriptionStatus).includes(status)) {
      throw new BadRequestException('유효하지 않은 이용권 상태입니다.');
    }

    const oldStatus = subscription.status;
    subscription.status = status;
    const updatedSubscription = await this.subscriptionRepo.save(subscription);

    // 상태 변경에 따른 용량 처리
    if (oldStatus === SubscriptionStatus.ACTIVE && (status === SubscriptionStatus.PAUSED || status === SubscriptionStatus.CANCELED || status === SubscriptionStatus.EXPIRED)) {
      await this.capacityService.deallocateCapacity(trainerId, memberId, subscription.plan?.storageLimit);
    } else if (oldStatus !== SubscriptionStatus.ACTIVE && status === SubscriptionStatus.ACTIVE) {
      await this.capacityService.allocateCapacity(trainerId, memberId, subscription.plan?.storageLimit);
    }

    await this.syncPaymentStatus(memberId);
    return updatedSubscription;
  }

  @Transactional()
  async deleteForMember(trainerId: string, memberId: string, subscriptionId: string): Promise<void> {
    const subscription = await this.findOneByMember(trainerId, memberId, subscriptionId);
    
    // 활성 상태의 이용권을 삭제할 때만 용량 반환
    if (subscription.status === SubscriptionStatus.ACTIVE) {
      await this.capacityService.deallocateCapacity(trainerId, memberId, subscription.plan?.storageLimit);
    }

    await this.subscriptionRepo.softDelete(subscription.id);
    await this.syncPaymentStatus(memberId);
  }

  private async findOneByMember(trainerId: string, memberId: string, subscriptionId: string): Promise<SubscriptionEntity> {
    await this.checkTrainerMemberRelationship(trainerId, memberId);
    const subscription = await this.subscriptionRepo.findOne({ where: { id: subscriptionId, userId: memberId }, relations: ['plan'] });
    if (!subscription) {
      throw new NotFoundException('이용권을 찾을 수 없습니다.');
    }
    return subscription;
  }

  private async checkTrainerMemberRelationship(trainerId: string, memberId: string): Promise<void> {
    const trainerUser = await this.trainerUserRepo.findOne({ where: { trainerId, memberId, status: TrainerUserStatus.ACTIVE } });
    if (!trainerUser) {
      throw new ForbiddenException('해당 회원에 대한 권한이 없습니다.');
    }
  }

  /** 로그인 권한에 따른 이용권 상품 scope (F_TRAINER → PERSONAL, CENTER → CENTER) */
  private resolvePlanScopeForUser(user: UserEntity): SubscriptionScope {
    switch (user.userType) {
      case UserType.F_TRAINER:
        return SubscriptionScope.PERSONAL;
      case UserType.CENTER:
        return SubscriptionScope.CENTER;
      default:
        throw new ForbiddenException('이용권 목록을 조회할 수 없는 권한입니다.');
    }
  }

  /** users.paymentStatus를 subscriptions 활성 여부에 맞게 동기화 */
  async syncPaymentStatus(userId: string): Promise<void> {
    const activeSub = await this.subscriptionRepo.findOne({
      where: { userId, status: SubscriptionStatus.ACTIVE },
    });
    await this.userRepo.update(userId, {
      paymentStatus: activeSub ? UserPaymentStatus.PAID : UserPaymentStatus.UNPAID,
    });
  }

  private mapToMemberSubscriptionDto(
    subscription: SubscriptionEntity,
    currentUsage: string,
    remainingUsage: string
  ): MemberSubscriptionResponseDto {
    const plan = subscription.plan;
    if (!plan) {
      throw new Error(`Subscription ${subscription.id} has no plan associated.`);
    }

    const startDate = subscription.createdAt;
    const now = new Date();
    const monthsInUse = (now.getFullYear() - startDate.getFullYear()) * 12 + (now.getMonth() - startDate.getMonth()) + 1;

    let statusText = '';
    switch (subscription.status) {
      case SubscriptionStatus.ACTIVE:
        statusText = `이용중 (${monthsInUse}개월차)`;
        break;
      case SubscriptionStatus.PAUSED:
        statusText = '일시정지';
        break;
      case SubscriptionStatus.CANCELED:
        statusText = '취소됨';
        break;
      case SubscriptionStatus.EXPIRED:
        statusText = '만료';
        break;
      default:
        statusText = subscription.status;
    }

    return {
      id: subscription.id,
      planName: plan.name,
      startDate: startDate.toISOString().split('T')[0],
      endDate: subscription.nextBillingDate,
      currentUsage: currentUsage,
      remainingUsage: remainingUsage,
      status: statusText,
    };
  }
}
