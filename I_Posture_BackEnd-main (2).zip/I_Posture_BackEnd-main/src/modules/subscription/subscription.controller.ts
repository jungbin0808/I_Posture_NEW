import { Body, Controller, Get, Post, Put, Param, Req, UseGuards, Query, Delete } from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { AccessTokenGuard } from '../auth/access-token.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { Role } from '../../common/enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';
import { IPageResponse, ISuccessResponse } from '../../common/response/response.interface';
import { SuccessResponse } from '../../common/response/response.helper';
import { SubscriptionService } from './subscription.service';
import { GrantSubscriptionDto } from './dto/grant-subscription.dto';
import { SubscriptionEntity } from '../../database/entities/subscription.entity';
import { FindSubscriptionPlanDto } from './dto/find-subscription-plan.dto';
import { SubscriptionPlanItemResponseDto } from './dto/subscription-plan-item-response.dto';
import { CreateSubscriptionDto } from './dto/create-subscription.dto';
import { ProcessPaymentDto } from './dto/process-payment.dto';
import { PaymentEntity } from '../../database/entities/payment.entity';
import { UpdateSubscriptionDto } from './dto/update-subscription.dto';
import { UpdateSubscriptionStatusDto } from './dto/update-subscription-status.dto';
import { MemberSubscriptionResponseDto } from './dto/member-subscription-response.dto';
import { FindMemberSubscriptionsDto } from './dto/find-member-subscriptions.dto';
import { StartTrialDto } from './dto/start-trial.dto';

@ApiTags('Subscription')
@ApiBearerAuth()
@UseGuards(AccessTokenGuard, RolesGuard)
@Controller('subscriptions')
export class SubscriptionController {
  constructor(private readonly subscriptionService: SubscriptionService) {}

  // --- 이용권 상품 관련 ---
  @ApiOperation({ summary: '이용권 상품 목록 조회' })
  @Roles(Role.Center, Role.FreelancerTrainer)
  @Get('plans')
  async findAllPlans(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindSubscriptionPlanDto,
  ): Promise<IPageResponse<SubscriptionPlanItemResponseDto>> {
    const user = req.user;
    const pageData = await this.subscriptionService.findAllPlans(user, findDto);
    return SuccessResponse(pageData);
  }

  // --- 회원 본인 이용권 조회 ---

  @ApiOperation({ summary: '내 이용권(멤버십) 이력 조회' })
  @Roles(Role.Member)
  @Get('me')
  async findAllByOwnMember(
    @Req() req: { user: UserEntity },
    @Query() findDto: FindMemberSubscriptionsDto,
  ): Promise<IPageResponse<MemberSubscriptionResponseDto>> {
    const pageData = await this.subscriptionService.findAllByOwnMember(req.user.id, findDto);
    return SuccessResponse(pageData);
  }

  // --- 특정 회원 이용권 관리 (트레이너용) ---

  @ApiOperation({ summary: '특정 회원의 이용권 목록 조회' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer)
  @Get('member/:memberId')
  async findAllByMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Query() findDto: FindMemberSubscriptionsDto,
  ): Promise<IPageResponse<MemberSubscriptionResponseDto>> {
    const pageData = await this.subscriptionService.findAllByMember(req.user.id, memberId, findDto);
    return SuccessResponse(pageData);
  }

  @ApiOperation({ summary: '특정 회원의 이용권 수정' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Put('member/:memberId/:subscriptionId')
  async updateForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('subscriptionId') subscriptionId: string,
    @Body() updateDto: UpdateSubscriptionDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const subscription = await this.subscriptionService.updateForMember(req.user.id, memberId, subscriptionId, updateDto);
    return SuccessResponse(subscription);
  }

  @ApiOperation({ summary: '특정 회원의 이용권 상태 변경 (정지/활성화)' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Put('member/:memberId/:subscriptionId/status')
  async updateStatusForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('subscriptionId') subscriptionId: string,
    @Body() statusDto: UpdateSubscriptionStatusDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const subscription = await this.subscriptionService.updateStatusForMember(req.user.id, memberId, subscriptionId, statusDto.status);
    return SuccessResponse(subscription);
  }

  @ApiOperation({ summary: '특정 회원의 이용권 삭제' })
  @Roles(Role.CenterTrainer, Role.FreelancerTrainer, Role.Center)
  @Delete('member/:memberId/:subscriptionId')
  async deleteForMember(
    @Req() req: { user: UserEntity },
    @Param('memberId') memberId: string,
    @Param('subscriptionId') subscriptionId: string,
  ): Promise<ISuccessResponse<{ success: boolean }>> {
    await this.subscriptionService.deleteForMember(req.user.id, memberId, subscriptionId);
    return SuccessResponse({ success: true });
  }


  // --- 기존 결제 관련 API (참고용) ---
  @ApiOperation({ summary: '결제 처리 및 이용권 업데이트 (KPN 빌키 결제)' })
  @Roles(Role.Center, Role.FreelancerTrainer)
  @Post('payment')
  async processPayment(
    @Req() req: { user: UserEntity },
    @Body() paymentDto: ProcessPaymentDto,
  ): Promise<ISuccessResponse<{ payment: PaymentEntity | null; subscription: SubscriptionEntity }>> {
    const user = req.user;
    const result = await this.subscriptionService.processPayment(user, paymentDto);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '이용권 해지 예약 (현재 주기 종료 시 만료)' })
  @Roles(Role.Center, Role.FreelancerTrainer)
  @Post('cancel')
  async cancelSubscription(
    @Req() req: { user: UserEntity },
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const result = await this.subscriptionService.cancelSubscription(req.user.id);
    return SuccessResponse(result);
  }

  @ApiOperation({ summary: '무료체험 시작 (개인 트레이너 전용, 14일, 1회만)' })
  @Roles(Role.FreelancerTrainer)
  @Post('trial')
  async startTrial(
    @Req() req: { user: UserEntity },
    @Body() body: StartTrialDto,
  ): Promise<ISuccessResponse<SubscriptionEntity>> {
    const result = await this.subscriptionService.startTrial(req.user, body.planId);
    return SuccessResponse(result);
  }
}
