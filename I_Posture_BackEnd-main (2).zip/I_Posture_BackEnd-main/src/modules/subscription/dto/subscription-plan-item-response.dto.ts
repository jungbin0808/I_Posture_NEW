import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { BillingCycle } from '../../../database/entities/subscription.entity';
import { SubscriptionScope, SubscriptionTier } from '../../../common/enums/subscription.enum';

export class SubscriptionPlanItemResponseDto {
  @ApiProperty({ description: '상품 고유 ID' })
  id!: string;

  @ApiProperty({ description: '상품명' })
  name!: string;

  @ApiProperty({ description: '구독 등급', enum: SubscriptionTier })
  tier!: SubscriptionTier;

  @ApiProperty({ description: '월 가격 (KRW)' })
  price!: number;

  @ApiProperty({ description: '제공 용량 (bytes)' })
  storageLimit!: string;

  @ApiProperty({ description: '플랜 사용 범위', enum: SubscriptionScope })
  scope!: SubscriptionScope;

  @ApiPropertyOptional({ description: '인앱 결제용 상품 ID' })
  storeProductId?: string;

  @ApiProperty({ description: '판매중 여부' })
  isPublic!: boolean;

  @ApiPropertyOptional({ description: '상품 설명' })
  description?: string;

  @ApiPropertyOptional({ description: '할인 판매가 (KRW)' })
  salePrice?: number | null;

  @ApiProperty({ description: '무료체험 가능 여부' })
  isTrialAvailable!: boolean;

  @ApiProperty({ description: '현재 구독 중인 플랜 여부' })
  isSubscribed!: boolean;

  @ApiProperty({ description: '해당 플랜으로 무료체험 이용 이력 여부' })
  isTrial!: boolean;

  @ApiPropertyOptional({ description: '다음 결제 예정일 (ISO8601 date, 구독 중인 플랜만)' })
  nextBillingDate?: string;

  @ApiPropertyOptional({ description: '매월 자동 결제 일자 (1~31, 구독 중인 플랜만)' })
  billingDayOfMonth?: number;

  @ApiPropertyOptional({ description: '결제 주기 (구독 중인 플랜만)', enum: BillingCycle })
  billingCycle?: BillingCycle;
}
