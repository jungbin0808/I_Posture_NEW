import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsString } from 'class-validator';

export class GrantSubscriptionDto {
  @ApiProperty({ description: '지급할 이용권 상품 ID' })
  @IsString()
  @IsNotEmpty()
  planId!: string;

  @ApiProperty({ description: '이용권 만료일' })
  @IsDateString()
  @IsNotEmpty()
  endDate!: string;
}
