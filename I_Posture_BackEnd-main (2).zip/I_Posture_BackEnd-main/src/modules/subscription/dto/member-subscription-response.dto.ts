import { ApiProperty } from '@nestjs/swagger';

export class MemberSubscriptionResponseDto {
  @ApiProperty({ description: '구독 ID' })
  id!: string;

  @ApiProperty({ description: '이용권 이름' })
  planName!: string;

  @ApiProperty({ description: '이용권 시작일' })
  startDate!: string;

  @ApiProperty({ description: '이용권 종료일 (또는 다음 결제일)', nullable: true })
  endDate?: string;

  @ApiProperty({ description: '누적 사용 데이터 (Byte)' })
  currentUsage!: string;

  @ApiProperty({ description: '데이터 잔량 (Byte)' })
  remainingUsage!: string;

  @ApiProperty({ description: '상태 (예: 이용중 (1개월차), 일시정지, 만료)' })
  status!: string;
}
