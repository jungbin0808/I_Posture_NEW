import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsOptional, IsUUID } from 'class-validator';
import { BillingCycle } from '../../../common/enums/subscription.enum';

export class ProcessPaymentDto {
  @ApiProperty({ description: '구독할 플랜 ID', example: 'uuid-string' })
  @IsUUID()
  @IsNotEmpty()
  planId!: string;

  @ApiProperty({ description: '결제 주기', enum: BillingCycle, default: BillingCycle.MONTHLY })
  @IsEnum(BillingCycle)
  @IsOptional()
  billingCycle: BillingCycle = BillingCycle.MONTHLY;
}
