import { ApiProperty } from '@nestjs/swagger';
import { IsUUID } from 'class-validator';

export class StartTrialDto {
  @ApiProperty({ description: '무료체험할 이용권 상품 ID' })
  @IsUUID('all')
  planId!: string;
}
