import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsEnum, IsOptional, Min } from 'class-validator';

export enum SubscriptionSortOrder {
  ASC = 'ASC',
  DESC = 'DESC',
}

export class FindMemberSubscriptionsDto {
  @ApiProperty({ description: '페이지 번호', required: false, default: 1 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  page?: number = 1;

  @ApiProperty({ description: '페이지당 항목 수', required: false, default: 10 })
  @IsOptional()
  @Type(() => Number)
  @Min(1)
  limit?: number = 10;

  @ApiProperty({
    description: '정렬 순서 (등록일 기준)',
    enum: SubscriptionSortOrder,
    required: false,
    default: SubscriptionSortOrder.DESC,
  })
  @IsEnum(SubscriptionSortOrder)
  @IsOptional()
  sort?: SubscriptionSortOrder = SubscriptionSortOrder.DESC;
}
