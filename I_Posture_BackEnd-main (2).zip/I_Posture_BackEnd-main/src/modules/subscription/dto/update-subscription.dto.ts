import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsInt, IsOptional, Min } from 'class-validator';

export class UpdateSubscriptionDto {
  @ApiProperty({ description: '시작일', required: false })
  @IsDateString()
  @IsOptional()
  startDate?: string;

  @ApiProperty({ description: '종료일', required: false })
  @IsDateString()
  @IsOptional()
  endDate?: string;

  @ApiProperty({ description: '총 세션 수', required: false })
  @IsInt()
  @Min(0)
  @IsOptional()
  totalSessions?: number;

  @ApiProperty({ description: '남은 세션 수', required: false })
  @IsInt()
  @Min(0)
  @IsOptional()
  remainingSessions?: number;
}
