import { IsEnum, IsNotEmpty, IsOptional, IsUUID } from 'class-validator';
import { BillingCycle } from '../../../common/enums/subscription.enum';

export class CreateSubscriptionDto {
  @IsNotEmpty()
  @IsUUID()
  planId!: string;

  @IsOptional()
  @IsEnum(BillingCycle)
  billingCycle?: BillingCycle;
}
