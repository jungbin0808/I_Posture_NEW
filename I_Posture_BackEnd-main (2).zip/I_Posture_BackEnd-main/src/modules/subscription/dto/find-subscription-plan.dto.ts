import { PaginationDto } from '../../../common/dto/pagination.dto';

export class FindSubscriptionPlanDto extends PaginationDto {}
