import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty } from 'class-validator';
import { SubscriptionStatus } from '../../../database/entities/subscription.entity';

export class UpdateSubscriptionStatusDto {
  @ApiProperty({ description: '변경할 상태', enum: SubscriptionStatus })
  @IsEnum(SubscriptionStatus)
  @IsNotEmpty()
  status!: SubscriptionStatus;
}
