import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import appConfig from './config/app.config';
import databaseConfig, { databaseConnectionFactory, dataSourceFactory } from './config/database.config';
import { UserModule } from './modules/user/user.module';
import { AuthModule } from './modules/auth/auth.module';
import { CenterModule } from './modules/center/center.module';
import { FaqModule } from './modules/faq/faq.module';
import { TermModule } from './modules/term/term.module';
import { ExerciseModule } from './modules/exercise/exercise.module';
import { SequenceModule } from './modules/sequence/sequence.module';
import { ScheduleModule } from './modules/schedule/schedule.module';
import { SubscriptionModule } from './modules/subscription/subscription.module';
import { AnalysisModule } from './modules/analysis/analysis.module';
import { PointModule } from './modules/point/point.module';
import { S3Module } from './s3/s3.module';
import { AdminFaqModule } from './modules/admin/faq/admin.faq.module';
import { AdminFaqCategoryModule } from './modules/admin/faq-category/admin.faq-category.module';
import { ScheduleGroupModule } from './modules/schedule-group/schedule-group.module';
import { SequenceGroupModule } from './modules/sequence-group/sequence-group.module';
import { CapacityModule } from './modules/capacity/capacity.module';
import { QnaModule } from './modules/qna/qna.module';
import { AdminPointModule } from './modules/admin/point/admin-point.module';
import { AdminNotificationModule } from './modules/admin/notification/admin-notification.module';
import { AdminUserModule } from './modules/admin/user/admin-user.module';
import { AdminSubscriptionModule } from './modules/admin/subscription/admin-subscription.module';
import { FoodLogModule } from './modules/food-log/food-log.module';
import { WorkoutLogModule } from './modules/workout-log/workout-log.module';
import { ConsultationLogModule } from './modules/consultation-log/consultation-log.module';
import { InbodyModule } from './modules/inbody/inbody.module';
import { ScheduleModule as NestScheduleModule } from '@nestjs/schedule';
import { MotionAnalysisModule } from './modules/motion-analysis/motion-analysis.module';
import { BodyReportModule } from './modules/body-report/body-report.module';
import { PrecisionReportModule } from './modules/precision-report/precision-report.module';
import { ReportComparisonModule } from './modules/report-comparison/report-comparison.module';
import { MeasurementReportModule } from './modules/measurement-report/measurement-report.module';
import { EmailModule } from './modules/email/email.module';
import { KpnPaymentModule } from './modules/kpn-payment/kpn-payment.module';
import { DashboardModule } from './modules/dashboard/dashboard.module';
import { NotificationModule } from './modules/notification/notification.module';
import { CustomExerciseModule } from './modules/custom-exercise/custom-exercise.module';
import { AppHomeModule } from './modules/app/home/app-home.module';
import { AppMypageModule } from './modules/app/mypage/app-mypage.module';
import { AppMeasurementModule } from './modules/app/measurement/app-measurement.module';
import { AppExerciseRecommendationModule } from './modules/app/exercise-recommendation/app-exercise-recommendation.module';
import { AppPointModule } from './modules/app/point/app-point.module';
import { AppNotificationModule } from './modules/app/notification/app-notification.module';
import { BannerModule } from './modules/banner/banner.module';
import { AdminBannerModule } from './modules/admin/banner/admin-banner.module';
import { AdminCustomExerciseModule } from './modules/admin/custom-exercise/admin-custom-exercise.module';
import { AdminTermModule } from './modules/admin/term/admin-term.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: [
        `.env.${process.env.NODE_ENV || 'local'}`,
        '.env',
      ],
      load: [appConfig, databaseConfig],
    }),
    TypeOrmModule.forRootAsync({
      useFactory: databaseConnectionFactory,
      dataSourceFactory: dataSourceFactory,
      inject: [],
    }),
    UserModule,
    AuthModule,
    CenterModule,
    FaqModule,
    TermModule,
    ExerciseModule,
    SequenceModule,
    ScheduleModule,
    SubscriptionModule,
    AnalysisModule,
    PointModule,
    S3Module,
    AdminFaqModule,
    AdminFaqCategoryModule,
    ScheduleGroupModule,
    SequenceGroupModule,
    CapacityModule,
    QnaModule,
    AdminPointModule,
    AdminNotificationModule,
    AdminUserModule,
    AdminSubscriptionModule,
    FoodLogModule,
    WorkoutLogModule,
    ConsultationLogModule,
    InbodyModule,
    MotionAnalysisModule,
    BodyReportModule,
    PrecisionReportModule,
    ReportComparisonModule,
    MeasurementReportModule,
    EmailModule,
    KpnPaymentModule,
    DashboardModule,
    NotificationModule,
    CustomExerciseModule,
    AppHomeModule,
    AppMypageModule,
    AppMeasurementModule,
    AppExerciseRecommendationModule,
    AppPointModule,
    AppNotificationModule,
    BannerModule,
    AdminBannerModule,
    AdminCustomExerciseModule,
    AdminTermModule,
    NestScheduleModule.forRoot(),
  ],
})
export class AppModule {}
