import { SetMetadata } from '@nestjs/common';

export const REQUIRES_SUBSCRIPTION_KEY = 'requiresSubscription';

/**
 * 이용권 활성 + 용량 미초과 상태일 때만 허용하는 엔드포인트에 붙임.
 * - 이용권 없음 → 403 SUBSCRIPTION_REQUIRED
 * - 용량 초과   → 403 STORAGE_QUOTA_EXCEEDED
 *
 * 사용 가능 메뉴(식단일지/일정/QnA/FAQ)에는 붙이지 않음.
 * 사용 불가 메뉴(측정/트래킹노트/운동일지/비교데이터/인바디)의
 * 상세보기·공유·등록·수정 엔드포인트에만 붙임.
 */
export const RequiresSubscription = () => SetMetadata(REQUIRES_SUBSCRIPTION_KEY, true);
