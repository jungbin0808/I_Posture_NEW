import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { Role } from '../enums/role.enum';
import { UserEntity } from '../../database/entities/user.entity';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<Role[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!requiredRoles) {
      return true;
    }
    const { user } = context.switchToHttp().getRequest<{ user: UserEntity }>();

    if (!user) {
      console.log('RolesGuard: User object is missing in request');
      return false;
    }

    console.log(
      `RolesGuard Check: UserType=[${user.userType}], Required=[${requiredRoles}]`,
    );

    // user.userType (UserType enum) 과 role (Role enum)을 비교
    return requiredRoles.some((role) => user.userType === (role as string));
  }
}
