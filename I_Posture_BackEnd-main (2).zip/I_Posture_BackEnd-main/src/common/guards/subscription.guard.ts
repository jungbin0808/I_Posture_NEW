import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { REQUIRES_SUBSCRIPTION_KEY } from '../decorators/requires-subscription.decorator';
import { SubscriptionEntity, SubscriptionStatus } from '../../database/entities/subscription.entity';
import { UserEntity, UserType } from '../../database/entities/user.entity';
import { CenterTrainerEntity } from '../../database/entities/center-trainer.entity';
import { CenterEntity } from '../../database/entities/center.entity';
import { CapacityService } from '../../modules/capacity/capacity.service';

@Injectable()
export class SubscriptionGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    @InjectRepository(SubscriptionEntity)
    private readonly subscriptionRepo: Repository<SubscriptionEntity>,
    @InjectRepository(CenterTrainerEntity)
    private readonly centerTrainerRepo: Repository<CenterTrainerEntity>,
    @InjectRepository(CenterEntity)
    private readonly centerRepo: Repository<CenterEntity>,
    private readonly capacityService: CapacityService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const required = this.reflector.getAllAndOverride<boolean>(REQUIRES_SUBSCRIPTION_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    // 데코레이터가 없으면 통과
    if (!required) return true;

    const { user } = context.switchToHttp().getRequest<{ user: UserEntity }>();
    if (!user) return false;

    // 구독 체크 대상 userId 결정
    // C_TRAINER → 소속 센터 owner의 구독 확인
    // F_TRAINER / CENTER → 본인 구독 확인
    let subscriptionUserId = user.id;
    if (user.userType === UserType.C_TRAINER) {
      const affiliation = await this.centerTrainerRepo.findOne({ where: { trainerId: user.id } });
      if (!affiliation) {
        throw new HttpException({ code: 'SUBSCRIPTION_REQUIRED', message: '소속 센터 정보를 찾을 수 없습니다.' }, HttpStatus.FORBIDDEN);
      }
      const center = await this.centerRepo.findOne({ where: { id: affiliation.centerId } });
      if (!center) {
        throw new HttpException({ code: 'SUBSCRIPTION_REQUIRED', message: '소속 센터 정보를 찾을 수 없습니다.' }, HttpStatus.FORBIDDEN);
      }
      subscriptionUserId = center.ownerId;
    }

    // 1. 활성 구독 확인
    const activeSub = await this.subscriptionRepo.findOne({
      where: { userId: subscriptionUserId, status: SubscriptionStatus.ACTIVE },
    });

    if (!activeSub) {
      throw new HttpException({ code: 'SUBSCRIPTION_REQUIRED', message: '이용권이 없습니다. 이용권 구매 메뉴로 이동해주세요.' }, HttpStatus.FORBIDDEN);
    }

    // 2. 용량 초과 확인
    const exceeded = await this.capacityService.isQuotaExceeded(user);
    if (exceeded) {
      throw new HttpException({ code: 'STORAGE_QUOTA_EXCEEDED', message: '사용 가능한 데이터 용량을 초과했습니다. 이용권을 업그레이드하면 사용할 수 있습니다.' }, HttpStatus.FORBIDDEN);
    }

    return true;
  }
}
