export type ReportDisplayLanguage = 'ko' | 'en';

/**
 * Accept-Language 헤더를 리포트 표시 언어로 변환.
 * en / en-US 등 영어 계열이면 en, 그 외(미지정 포함)는 ko.
 */
export function resolveReportDisplayLanguage(acceptLanguage?: string): ReportDisplayLanguage {
  if (!acceptLanguage?.trim()) {
    return 'ko';
  }

  const primary = acceptLanguage
    .split(',')[0]
    ?.trim()
    .split(';')[0]
    ?.trim()
    .toLowerCase();

  if (primary === 'en' || primary?.startsWith('en-')) {
    return 'en';
  }

  return 'ko';
}
