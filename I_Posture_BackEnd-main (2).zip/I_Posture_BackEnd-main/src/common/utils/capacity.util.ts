const KB = 1024n;
const MB = KB * 1024n;
const GB = MB * 1024n;
const TB = GB * 1024n;

function toBigInt(bytes: string | number | bigint): bigint {
  if (typeof bytes === 'bigint') {
    return bytes < 0n ? 0n : bytes;
  }

  if (typeof bytes === 'number') {
    if (!Number.isFinite(bytes) || bytes <= 0) {
      return 0n;
    }

    return BigInt(Math.trunc(bytes));
  }

  if (!bytes || !/^\d+$/.test(bytes)) {
    return 0n;
  }

  return BigInt(bytes);
}

function formatWithOneDecimal(value: number): string {
  return (Math.round(value * 10) / 10).toFixed(1);
}

export function formatBytesDisplay(bytes: string | number | bigint): string {
  const normalized = toBigInt(bytes);

  if (normalized === 0n) {
    return '0B';
  }

  if (normalized >= TB) {
    return `${formatWithOneDecimal(Number(normalized) / Number(TB))}TB`;
  }

  if (normalized >= GB) {
    return `${formatWithOneDecimal(Number(normalized) / Number(GB))}GB`;
  }

  if (normalized >= MB) {
    return `${formatWithOneDecimal(Number(normalized) / Number(MB))}MB`;
  }

  if (normalized >= KB) {
    return `${formatWithOneDecimal(Number(normalized) / Number(KB))}KB`;
  }

  return `${normalized}B`;
}
