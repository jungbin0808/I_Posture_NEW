/** UTC 기준 YYYY-MM-DD (앱 TZ=UTC, next_billing_date 등 날짜 컬럼과 동일 기준) */
export function getUtcDateString(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

/** KST(UTC+9) 기준 YYYY-MM-DD. 서버 TZ가 UTC로 고정되어 있어 KST 날짜 경계 계산엔 별도 변환이 필요함 */
export function getKstDateString(date: Date = new Date()): string {
  const kstMs = date.getTime() + 9 * 60 * 60 * 1000;
  return new Date(kstMs).toISOString().split('T')[0];
}

/** 날짜 문자열(YYYY-MM-DD)에 일수를 더한 날짜 문자열 */
export function addDaysToDateString(dateStr: string, days: number): string {
  const d = new Date(`${dateStr}T00:00:00.000Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().split('T')[0];
}

/** 두 날짜 문자열(YYYY-MM-DD) 사이의 일수 차이 (a - b) */
export function diffDaysBetweenDateStrings(a: string, b: string): number {
  const aMs = new Date(`${a}T00:00:00.000Z`).getTime();
  const bMs = new Date(`${b}T00:00:00.000Z`).getTime();
  return Math.round((aMs - bMs) / (24 * 60 * 60 * 1000));
}

/**
 * 월을 더할 때 말일 처리: 목표 월에 해당 일이 없으면 그 월의 마지막 날로 clamp
 * ex) Jan 31 + 1 month → Feb 28/29
 *     Mar 31 + 1 month → Apr 30
 */
export function addMonthsClamp(date: Date, months: number): Date {
  const day = date.getDate();
  const result = new Date(date);
  result.setDate(1); // 오버플로우 방지를 위해 1일로 먼저 세팅
  result.setMonth(result.getMonth() + months);
  // 목표 월의 마지막 날
  const lastDay = new Date(result.getFullYear(), result.getMonth() + 1, 0).getDate();
  result.setDate(Math.min(day, lastDay));
  return result;
}

export function addYearsClamp(date: Date, years: number): Date {
  return addMonthsClamp(date, years * 12);
}
