import { HttpException, HttpStatus } from '@nestjs/common';
import {
  IPage,
  IPageData,
  IPageResponse,
  ISuccessResponse,
} from './response.interface';

// 1. 오버로드 시그니처: IPageData<T> 타입이 들어올 경우
export function SuccessResponse<T>(
  data: IPageData<T>,
  message?: string,
): IPageResponse<T>;

// 2. 오버로드 시그니처: 그 외 일반 T 타입이 들어올 경우
export function SuccessResponse<T>(
  data: T,
  message?: string,
): ISuccessResponse<T>;

// 3. 실제 함수 구현 (구현부의 시그니처는 모든 경우를 포괄해야 함)
export function SuccessResponse<T>(
  data: T | IPageData<T>,
  message = 'success',
): ISuccessResponse<T> | IPageResponse<T> {
  return {
    status: true,
    message: message,
    data: data as T & IPageData<T>, // 구현부에서는 타입 단언이 필요할 수 있음
  };
}

export function BadRequestResponse(message: string): HttpException {
  throw new HttpException({ message, status: false }, HttpStatus.BAD_REQUEST);
}

export function NotFoundResponse(message: string): HttpException {
  throw new HttpException({ message, status: false }, HttpStatus.NOT_FOUND);
}

export function buildPaging(
  total: number,
  limit: number,
  page: number,
): IPage {
  const totalPage = Math.ceil(total / limit);

  return {
    total,
    limit,
    totalPage,
    page,
  };
}
