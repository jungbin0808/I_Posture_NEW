export interface ISuccessResponse<T> {
  status: true;
  message: string;
  data: T;
}

export interface IArrayResponse {
  message: string;
  data: object[];
}

export interface ResponseInterface {
  message: string;
}

export interface IPage {
  total: number;
  limit: number; // take -> limit 변경
  totalPage: number;
  page: number;
}

export interface IPageData<T> {
  items: T[];
  paging: IPage;
}

export interface IPageResponse<T> {
  status: true;
  message: string;
  data: IPageData<T>;
}
