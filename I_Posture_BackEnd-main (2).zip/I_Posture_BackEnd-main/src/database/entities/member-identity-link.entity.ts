import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum IdentityLinkStatus {
  LINKED = "LINKED",
  UNLINKED = "UNLINKED",
}

@Entity({ name: "member_identity_links", orderBy: { created_at: "DESC", id: "ASC" } })
export class MemberIdentityLinkEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "회원 연동 ID (APP 회원 A ↔ 관리회원 C)" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "연동 생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "app_member_id", comment: "앱 회원 A ID" })
  appMemberId!: string;

  @ManyToOne(() => UserEntity, (user) => user.appIdentityLinks)
  @JoinColumn({ name: "app_member_id" })
  appMember!: UserEntity;

  @Column({ type: "uuid", name: "managed_member_id", comment: "트레이너 관리 회원 C ID" })
  managedMemberId!: string;

  @ManyToOne(() => UserEntity, (user) => user.managedIdentityLinks)
  @JoinColumn({ name: "managed_member_id" })
  managedMember!: UserEntity;

  @Column({
    type: "enum",
    enum: IdentityLinkStatus,
    name: "status",
    default: IdentityLinkStatus.LINKED,
    comment: "연동 상태 (연결/해제)",
  })
  status!: IdentityLinkStatus;

  @Column({
    type: "timestamp",
    name: "unlinked_at",
    precision: 3,
    nullable: true,
    comment: "앱 연동 해제일시",
  })
  unlinkedAt?: Date;
}
