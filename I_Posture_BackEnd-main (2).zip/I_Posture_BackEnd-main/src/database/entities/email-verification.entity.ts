import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum EmailVerificationPurpose {
  REGISTER = 'REGISTER',
  FIND_ID = 'FIND_ID',
  FIND_PASSWORD = 'FIND_PASSWORD',
}

@Entity({ name: 'email_verifications' })
export class EmailVerificationEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id!: string;

  @Index()
  @Column({ type: 'varchar', name: 'email', length: 255, comment: '인증 대상 이메일' })
  email!: string;

  @Column({ type: 'enum', name: 'purpose', enum: EmailVerificationPurpose, comment: '인증 목적' })
  purpose!: EmailVerificationPurpose;

  @Column({ type: 'varchar', name: 'code', length: 6, comment: '6자리 인증 코드' })
  code!: string;

  @Column({ type: 'tinyint', name: 'is_verified', default: false, comment: '인증 완료 여부' })
  isVerified!: boolean;

  @Column({ type: 'int', name: 'attempts', default: 0, comment: '인증 시도 횟수' })
  attempts!: number;

  @Column({ type: 'timestamp', name: 'expires_at', precision: 3, comment: '코드 만료 시각' })
  expiresAt!: Date;

  @Column({ type: 'timestamp', name: 'verified_at', precision: 3, nullable: true, comment: '인증 완료 시각' })
  verifiedAt?: Date;

  @CreateDateColumn({ type: 'timestamp', name: 'created_at', precision: 3, comment: '생성일시', default: () => 'CURRENT_TIMESTAMP(3)' })
  createdAt!: Date;
}
