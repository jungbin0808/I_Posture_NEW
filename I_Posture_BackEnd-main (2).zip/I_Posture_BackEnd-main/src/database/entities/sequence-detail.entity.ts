import { Column, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { SequenceEntity } from "./sequence.entity";
import { ExerciseEntity } from "./exercise.entity";
import { FileEntity } from "./file.entity";

export enum SequenceCategoryType {
  MAIN = "MAIN",
  WARMUP = "WARMUP",
  COOL_DOWN = "COOL_DOWN",
}

@Entity({ name: "sequence_details", orderBy: { step_order: "ASC" } })
export class SequenceDetailEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "시퀀스 상세 ID" })
  id!: string;

  @Column({ type: "uuid", name: "sequence_id", comment: "시퀀스 ID" })
  sequenceId!: string;

  @ManyToOne(() => SequenceEntity, (sequence) => sequence.details)
  @JoinColumn({ name: "sequence_id" })
  sequence!: SequenceEntity;

  @Column({ type: "uuid", name: "exercise_id", nullable: true, comment: "원본 운동 ID (복사 시)" })
  exerciseId?: string;

  @ManyToOne(() => ExerciseEntity)
  @JoinColumn({ name: "exercise_id" })
  exercise?: ExerciseEntity;

  @Column({ type: "boolean", name: "is_custom", default: false, comment: "직접입력 여부 (이미지 업로드 여부 판단)" })
  isCustom!: boolean;

  @Column({ type: "int", name: "step_order", comment: "운동 순서" })
  stepOrder!: number;

  @Column({
    type: "enum",
    enum: SequenceCategoryType,
    name: "category_type",
    default: SequenceCategoryType.MAIN,
    comment: "운동 유형",
  })
  categoryType!: SequenceCategoryType;

  @Column({ type: "varchar", name: "name", length: 100, comment: "동작명" })
  name!: string;

  @Column({ type: "text", name: "description", nullable: true, comment: "설명" })
  description?: string;
}
