import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { MEASUREMENT_TYPE } from "../../common/enums/measurement-type.enum";

@Entity({ name: "precision_reports", orderBy: { createdAt: "DESC" } })
export class PrecisionReportEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "정밀 리포트 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "user_id", comment: "회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.precisionReports)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "trainer_id", nullable: true, comment: "담당 트레이너 ID" })
  trainerId?: string;

  @ManyToOne(() => UserEntity, (user) => user.managedPrecisionReports)
  @JoinColumn({ name: "trainer_id" })
  trainer?: UserEntity;

  @Column({
    type: "enum",
    enum: MEASUREMENT_TYPE,
    name: "type",
    comment: "분석 부위 (NECK, SHOULDERS 등)",
  })
  type!: MEASUREMENT_TYPE;

  @Column({ type: "varchar", name: "key", length: 100, nullable: true, comment: "동작 키 (예: NeckFlexion)" })
  key?: string;

  @Column({ type: "varchar", name: "name", length: 100, nullable: true, comment: "동작명 (예: 목 굽힘)" })
  name?: string;

  @Column({ type: "int", name: "score", default: 0, comment: "가동범위 도달률 (%)" })
  score!: number;

  @Column({ type: "varchar", name: "level", length: 20, nullable: true, comment: "단계 (NORMAL, CAUTION, DANGER)" })
  level?: string;

  @Column({ type: "json", name: "analysis_data", comment: "분석 데이터 (JSON)" })
  analysisData!: any;

  @Column({
    type: "json",
    name: "display_payload_en",
    nullable: true,
    comment: "영문 리포트 전체 payload (Google Translate 스냅샷)",
  })
  displayPayloadEn?: any;

  @Column({ type: "text", name: "comment", nullable: true, comment: "트레이너 코멘트" })
  comment?: string;
}
