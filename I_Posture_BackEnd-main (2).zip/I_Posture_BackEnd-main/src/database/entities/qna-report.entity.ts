import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum QnaReportTarget {
  QUESTION = "QUESTION",
  ANSWER = "ANSWER",
}

@Entity({ name: "qna_reports", orderBy: { created_at: "DESC" } })
export class QnaReportEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "신고 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "신고 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "reporter_id", comment: "신고자 ID" })
  reporterId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "reporter_id" })
  reporter!: UserEntity;

  @Column({
    type: "enum",
    enum: QnaReportTarget,
    name: "target_type",
    comment: "신고 대상 유형 (질문/답변)",
  })
  targetType!: QnaReportTarget;

  @Column({ type: "uuid", name: "target_id", comment: "신고 대상 ID (질문ID 또는 답변ID)" })
  targetId!: string;

  @Column({ type: "text", name: "reason", comment: "신고 사유" })
  reason!: string;
}
