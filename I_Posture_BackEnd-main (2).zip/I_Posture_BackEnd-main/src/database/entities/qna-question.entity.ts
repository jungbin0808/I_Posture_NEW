import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { QnaAnswerEntity } from "./qna-answer.entity";

@Entity({ name: "qna_questions", orderBy: { created_at: "DESC" } })
export class QnaQuestionEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "질문 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "작성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "author_id", comment: "작성자 ID" })
  authorId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "author_id" })
  author!: UserEntity;

  @Column({ type: "varchar", name: "title", length: 255, comment: "질문 제목" })
  title!: string;

  @Column({ type: "text", name: "content", comment: "질문 내용" })
  content!: string;

  @Column({ type: "int", name: "view_count", default: 0, comment: "조회수" })
  viewCount!: number;

  @OneToMany('QnaAnswerEntity', 'question')
  answers!: QnaAnswerEntity[];
}
