import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { RomSensationEntity } from "./rom-sensation.entity";
import { RomMovementPatternEntity } from "./rom-movement-pattern.entity";
import { RomHabitEntity } from "./rom-habit.entity";

@Entity({ name: "rom_standards" })
export class RomStandardEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "PK (UUID)" })
  id!: string;

  @Column({ type: "varchar", name: "joint_ko", length: 50, comment: "관절명 (한글)" })
  jointKo!: string;

  @Column({ type: "varchar", name: "joint_en", length: 50, comment: "관절명 (영문)" })
  jointEn!: string;

  @Column({ type: "varchar", name: "motion_ko", length: 50, comment: "동작명 (한글)" })
  motionKo!: string;

  @Column({ type: "varchar", name: "motion_en", length: 50, comment: "동작명 (영문)" })
  motionEn!: string;

  @Column({ type: "enum", enum: ['L', 'R', 'NONE'], name: "side", default: "NONE", comment: "측정 방향" })
  side!: string;

  @Column({ type: "varchar", name: "report_name_ko", length: 100, comment: "리포트용 (한글)" })
  reportNameKo!: string;

  @Column({ type: "varchar", name: "report_name_en", length: 100, comment: "리포트용 (영문)" })
  reportNameEn!: string;

  @Column({ type: "int", name: "normal_deg", comment: "정상 각도" })
  normalDeg!: number;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @OneToMany(() => RomSensationEntity, (sensation) => sensation.romStandard)
  sensations!: RomSensationEntity[];

  @OneToMany(() => RomMovementPatternEntity, (pattern) => pattern.romStandard)
  movementPatterns!: RomMovementPatternEntity[];

  @OneToMany(() => RomHabitEntity, (habit) => habit.romStandard)
  habits!: RomHabitEntity[];
}
