import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'custom_exercise_body_type' })
export class CustomExerciseBodyTypeEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id!: string;

  @Column({ type: 'varchar', name: 'category', length: 20 })
  category!: string;

  @Column({ type: 'varchar', name: 'main_cat', length: 100 })
  mainCat!: string;

  @Column({ type: 'varchar', name: 'sub_cat', length: 100, nullable: true })
  subCat!: string | null;

  @Column({ type: 'varchar', name: 'detail_cat', length: 100 })
  detailCat!: string;

  @Column({ type: 'varchar', name: 'body_type_name', length: 100 })
  bodyTypeName!: string;
}
