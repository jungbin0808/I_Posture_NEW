import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { RomStandardEntity } from "./rom-standard.entity";

@Entity({ name: "rom_habits" })
export class RomHabitEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "PK (UUID)" })
  id!: string;

  @Column({ type: "uuid", name: "rom_standard_id", comment: "연관된 ROM 기준 ID (FK)" })
  romStandardId!: string;

  @ManyToOne(() => RomStandardEntity, (standard) => standard.habits, { onDelete: "CASCADE" })
  @JoinColumn({ name: "rom_standard_id" })
  romStandard!: RomStandardEntity;

  @Column({ type: "text", name: "habit_content", comment: "영향을 주는 습관/자세 내용" })
  habitContent!: string;

  @Column({ type: "int", name: "image_no", comment: "매핑된 이미지 번호" })
  imageNo!: number;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;
}
