import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

export enum CancellationAction {
  REQUESTED = 'REQUESTED', // 해지 예약 설정 (cancel_at_period_end = true)
  REVOKED = 'REVOKED', // 해지 예약 해제 (cancel_at_period_end = false)
}

export enum CancellationReason {
  USER_REQUEST = 'USER_REQUEST', // 회원이 직접 해지 신청
  DOWNGRADE = 'DOWNGRADE', // 용량 축소(다운그레이드)로 인한 자동 해지 예약
  UPGRADE = 'UPGRADE', // 용량 확대(업그레이드)로 인한 해지 예약 자동 해제
}

@Entity({ name: 'subscription_cancellation_logs', orderBy: { createdAt: 'DESC' } })
export class SubscriptionCancellationLogEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '해지 이력 ID' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '발생 일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @Column({ type: 'uuid', name: 'subscription_id', comment: '구독 ID' })
  subscriptionId!: string;

  @Column({ type: 'uuid', name: 'user_id', comment: '회원 ID' })
  userId!: string;

  @Column({
    type: 'enum',
    enum: CancellationAction,
    name: 'action',
    comment: '해지 예약 설정/해제 여부',
  })
  action!: CancellationAction;

  @Column({
    type: 'enum',
    enum: CancellationReason,
    name: 'reason',
    comment: '변경 사유',
  })
  reason!: CancellationReason;

  @Column({ type: 'date', name: 'next_billing_date', nullable: true, comment: '변경 시점의 다음 결제 예정일' })
  nextBillingDate?: string;
}
