import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { RomStandardEntity } from "./rom-standard.entity";

@Entity({ name: "rom_movement_patterns" })
export class RomMovementPatternEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "PK (UUID)" })
  id!: string;

  @Column({ type: "uuid", name: "rom_standard_id", comment: "연관된 ROM 기준 ID (FK)" })
  romStandardId!: string;

  @ManyToOne(() => RomStandardEntity, (standard) => standard.movementPatterns, { onDelete: "CASCADE" })
  @JoinColumn({ name: "rom_standard_id" })
  romStandard!: RomStandardEntity;

  @Column({ type: "varchar", name: "pattern_content", length: 255, comment: "움직임 패턴 내용" })
  patternContent!: string;

  @Column({ type: "int", name: "image_no", comment: "매핑된 이미지 번호" })
  imageNo!: number;

  @Column({ type: "text", name: "daily_example", comment: "일상 동작 예시" })
  dailyExample!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;
}
