import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "member_storage", orderBy: { created_at: "DESC", id: "ASC" } })
export class MemberStorageEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "회원(A) 스토리지 집계 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "member_id", comment: "users.id (앱 회원 A)" })
  memberId!: string;

  @OneToOne(() => UserEntity, (user) => user.memberStorage)
  @JoinColumn({ name: "member_id" })
  member!: UserEntity;

  @Column({ type: "bigint", name: "allocated_from_center", default: 0, comment: "센터/트레이너로부터 A에게 부여된 활성 할당 용량 합계(Byte)" })
  allocatedFromCenter!: string;

  @Column({ type: "bigint", name: "allocated_from_personal", default: 0, comment: "회원 A 개인이 가진 용량 합계(Byte)" })
  allocatedFromPersonal!: string;

  @Column({ type: "bigint", name: "used_capacity", default: 0, comment: "회원 A 데이터 사용량(Byte)" })
  usedCapacity!: string;
}
