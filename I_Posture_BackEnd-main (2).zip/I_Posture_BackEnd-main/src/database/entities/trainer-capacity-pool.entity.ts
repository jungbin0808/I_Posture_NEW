import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "trainer_capacity_pool", orderBy: { created_at: "DESC", id: "ASC" } })
export class TrainerCapacityPoolEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "개인트레이너 용량 풀 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "트레이너 ID" })
  trainerId!: string;

  @OneToOne(() => UserEntity, (user) => user.capacityPool)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "bigint", name: "total_capacity", default: 0, comment: "트레이너가 구매한 총 용량(Byte)" })
  totalCapacity!: string;

  @Column({ type: "bigint", name: "used_capacity", default: 0, comment: "실제 사용 중인 트레이너 소유 데이터 용량(Byte)" })
  usedCapacity!: string;

  @Column({ type: "bigint", name: "allocated_capacity", default: 0, comment: "현재 앱 회원 A들에게 부여(할당)되어 있는 트레이너 제공 용량 합계(Byte)" })
  allocatedCapacity!: string;
}
