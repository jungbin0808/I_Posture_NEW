import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum StorageOwnerType {
  CENTER = "CENTER",
  TRAINER = "TRAINER",
}

export enum StorageAllocationStatus {
  ACTIVE = "ACTIVE",
  REVOKED = "REVOKED",
  EXPIRED = "EXPIRED",
}

@Entity({ name: "storage_allocations", orderBy: { created_at: "DESC", id: "ASC" } })
export class StorageAllocationEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "회원 용량 할당 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({
    type: "enum",
    enum: StorageOwnerType,
    name: "owner_type",
    default: StorageOwnerType.CENTER,
    comment: "용량 제공 주체 유형 (센터/개인트레이너)",
  })
  ownerType!: StorageOwnerType;

  @Column({ type: "uuid", name: "owner_id", comment: "용량 제공 주체 ID (centers.id 또는 users.id)" })
  ownerId!: string;

  @Column({ type: "uuid", name: "member_id", comment: "용량을 부여받는 앱 회원 A ID" })
  memberId!: string;

  @ManyToOne(() => UserEntity, (user) => user.storageAllocations)
  @JoinColumn({ name: "member_id" })
  member!: UserEntity;

  @Column({ type: "bigint", name: "allocated_capacity", default: 0, comment: "부여된 전체 용량(Byte)" })
  allocatedCapacity!: string;

  @Column({
    type: "enum",
    enum: StorageAllocationStatus,
    name: "status",
    default: StorageAllocationStatus.ACTIVE,
    comment: "할당 상태 (활성/수동회수/기간만료 등)",
  })
  status!: StorageAllocationStatus;
}
