import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
  Unique,
  UpdateDateColumn,
} from 'typeorm';
import { CenterEntity } from './center.entity';
import { UserEntity } from './user.entity';

@Entity({
  name: 'center_trainer_capacity_pools',
  orderBy: { created_at: 'DESC', id: 'ASC' },
})
@Unique('uq_center_trainer_capacity_pools_center_trainer', ['centerId', 'trainerId'])
export class CenterTrainerCapacityPoolEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '센터 트레이너 용량 풀 ID' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'updated_at',
    precision: 3,
    comment: '수정일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
    onUpdate: 'CURRENT_TIMESTAMP(3)',
  })
  updatedAt!: Date;

  @Column({ type: 'uuid', name: 'center_id', comment: '센터 ID' })
  centerId!: string;

  @ManyToOne(() => CenterEntity)
  @JoinColumn({ name: 'center_id' })
  center!: CenterEntity;

  @Column({ type: 'uuid', name: 'trainer_id', comment: '센터 트레이너 ID' })
  trainerId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'trainer_id' })
  trainer!: UserEntity;

  @Column({
    type: 'bigint',
    name: 'used_capacity',
    default: 0,
    comment: '트레이너가 소모한 센터 데이터 용량(bytes)',
  })
  usedCapacity!: string;
}
