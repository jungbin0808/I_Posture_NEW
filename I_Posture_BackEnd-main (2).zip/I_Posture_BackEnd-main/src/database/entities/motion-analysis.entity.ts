import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "motion_analyses", orderBy: { created_at: "DESC", id: "ASC" } })
export class MotionAnalysisEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "모션 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "업로드 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "user_id", comment: "대상 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.motionAnalyses)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "trainer_id", comment: "담당 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.createdMotionAnalyses)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "varchar", name: "title", length: 100, nullable: true, comment: "영상 제목 또는 수기 코멘트" })
  title?: string;

  @Column({ type: "varchar", name: "memo", length: 255, nullable: true, comment: "간단 메모" })
  memo?: string;

  @Column({ type: "text", name: "trainer_comment", nullable: true, comment: "트레이너 코멘트" })
  trainerComment?: string;
}
