import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { ScheduleEntity } from "./schedule.entity";
import { MotionAnalysisEntity } from "./motion-analysis.entity";

export enum AttendanceStatus {
  PRESENT = "PRESENT",
  ABSENT = "ABSENT",
  LATE = "LATE",
}

@Entity({ name: "workout_logs", orderBy: { workout_date: "DESC", created_at: "DESC" } })
export class WorkoutLogEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "일지 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "작성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "작성 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.createdWorkoutLogs)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "uuid", name: "user_id", comment: "대상 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.workoutLogs)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "schedule_id", nullable: true, comment: "연동된 스케줄 ID" })
  scheduleId?: string;

  @ManyToOne(() => ScheduleEntity)
  @JoinColumn({ name: "schedule_id" })
  schedule?: ScheduleEntity;

  @Column({
    type: "enum",
    enum: AttendanceStatus,
    name: "attendance",
    default: AttendanceStatus.PRESENT,
    comment: "출석 상태",
  })
  attendance!: AttendanceStatus;

  @Column({
    type: "timestamp",
    name: "workout_date",
    precision: 3,
    comment: "운동 진행 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  workoutDate!: Date;

  @Column({ type: "varchar", name: "title", length: 255, nullable: true, comment: "운동 주제" })
  title?: string;

  @Column({ type: "json", name: "target_parts", nullable: true, comment: "타겟 부위 코드 목록" })
  targetParts?: any;

  @Column({ type: "json", name: "exercises", nullable: true, comment: "운동 세트 구성 목록" })
  exercises?: any;

  @Column({ type: "uuid", name: "motion_analysis_id", nullable: true, comment: "연동: 모션 분석 ID" })
  motionAnalysisId?: string;

  @ManyToOne(() => MotionAnalysisEntity)
  @JoinColumn({ name: "motion_analysis_id" })
  motionAnalysis?: MotionAnalysisEntity;

  @Column({ type: "text", name: "feedback_improve", nullable: true, comment: "개선사항" })
  feedbackImprove?: string;

  @Column({ type: "text", name: "feedback_caution", nullable: true, comment: "주의사항" })
  feedbackCaution?: string;

  @Column({ type: "json", name: "uncomfortable_parts", nullable: true, comment: "불편한 부위 태그 목록" })
  uncomfortableParts?: any;

  @Column({ type: "varchar", name: "uncomfortable_text", length: 255, nullable: true, comment: "불편한 부위 직접입력" })
  uncomfortableText?: string;

  @Column({ type: "varchar", name: "goal_title", length: 100, nullable: true, comment: "운동 단기 목표명" })
  goalTitle?: string;

  @Column({ type: "int", name: "goal_percent", nullable: true, comment: "달성률 퍼센트 (0~100)" })
  goalPercent?: number;
}
