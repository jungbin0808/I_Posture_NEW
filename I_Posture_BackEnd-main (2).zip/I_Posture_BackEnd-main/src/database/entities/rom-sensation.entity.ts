import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { RomStandardEntity } from "./rom-standard.entity";

@Entity({ name: "rom_sensations" })
export class RomSensationEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "PK (UUID)" })
  id!: string;

  @Column({ type: "uuid", name: "rom_standard_id", comment: "연관된 ROM 기준 ID (FK)" })
  romStandardId!: string;

  @ManyToOne(() => RomStandardEntity, (standard) => standard.sensations, { onDelete: "CASCADE" })
  @JoinColumn({ name: "rom_standard_id" })
  romStandard!: RomStandardEntity;

  @Column({ type: "varchar", name: "sensation_content", length: 255, comment: "체감 변화 내용" })
  sensationContent!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;
}
