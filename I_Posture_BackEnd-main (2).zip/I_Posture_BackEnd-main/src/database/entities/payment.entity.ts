import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { SubscriptionEntity } from "./subscription.entity";

export enum PaymentStatus {
  PENDING = "PENDING",
  SUCCESS = "SUCCESS",
  FAILED = "FAILED",
  REFUNDED = "REFUNDED",
}

export enum PaymentChannel {
  WEB_PG = "WEB_PG",
  INAPP_IOS = "INAPP_IOS",
  INAPP_ANDROID = "INAPP_ANDROID",
  KPN = "KPN",
}

export enum PaymentType {
  SUBSCRIPTION = "SUBSCRIPTION",
  ADDON = "ADDON",
}

@Entity({ name: "payments" })
export class PaymentEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "결제 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "paid_at", // created_at -> paid_at
    precision: 3,
    comment: "결제일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  paidAt!: Date; // createdAt -> paidAt

  @Column({ type: "uuid", name: "user_id", comment: "결제 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.payments)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "subscription_id", nullable: true, comment: "연관 구독 ID" })
  subscriptionId?: string;

  @ManyToOne(() => SubscriptionEntity, (subscription) => subscription.payments)
  @JoinColumn({ name: "subscription_id" })
  subscription?: SubscriptionEntity;

  @Column({ type: "int", name: "amount", comment: "결제 금액" })
  amount!: number;

  @Column({
    type: "enum",
    enum: PaymentStatus,
    name: "status",
    default: PaymentStatus.PENDING,
    comment: "결제 상태",
  })
  status!: PaymentStatus;

  @Column({
    type: "enum",
    enum: PaymentChannel,
    name: "payment_channel",
    nullable: true,
    comment: "결제 채널",
  })
  paymentChannel?: PaymentChannel;

  @Column({
    type: "enum",
    enum: PaymentType,
    name: "payment_type",
    default: PaymentType.SUBSCRIPTION,
    comment: "결제 유형",
  })
  paymentType!: PaymentType;

  @Column({ type: "varchar", name: "pg_provider", length: 50, nullable: true, comment: "PG사" })
  pgProvider?: string;

  @Column({ type: "varchar", name: "pg_imp_uid", length: 100, nullable: true, comment: "PG사 거래 고유 ID" })
  pgImpUid?: string;

  @Column({ type: "uuid", name: "bill_key_id", nullable: true, comment: "사용된 빌키 ID" })
  billKeyId?: string;

  @Column({ type: "varchar", name: "tid", length: 40, nullable: true, comment: "KPN 거래 고유번호" })
  tid?: string;

  @Column({ type: "varchar", name: "auth_no", length: 20, nullable: true, comment: "카드 승인번호" })
  authNo?: string;

  @Column({ type: "varchar", name: "pay_method", length: 10, nullable: true, comment: "결제수단 코드 (CC/IC/VA 등)" })
  payMethod?: string;

  @Column({ type: "varchar", name: "mx_issue_no", length: 32, nullable: true, comment: "상점 주문번호" })
  mxIssueNo?: string;

  @Column({ type: "varchar", name: "mx_issue_date", length: 14, nullable: true, comment: "주문일시 (YYYYMMDDHHMMSS)" })
  mxIssueDate?: string;

  @Column({ type: "varchar", name: "reply_code", length: 10, nullable: true, comment: "KPN 응답코드 (0000=성공)" })
  replyCode?: string;

  @Column({ type: "varchar", name: "reply_message", length: 200, nullable: true, comment: "KPN 응답메시지" })
  replyMessage?: string;
}
