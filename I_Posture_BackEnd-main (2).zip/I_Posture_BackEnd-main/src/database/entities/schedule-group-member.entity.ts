import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { ScheduleGroupEntity } from "./schedule-group.entity";
import { UserEntity } from "./user.entity";

@Entity({ name: "schedule_group_members" })
export class ScheduleGroupMemberEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "group_id", comment: "그룹 ID" })
  groupId!: string;

  @ManyToOne(() => ScheduleGroupEntity, (group) => group.members)
  @JoinColumn({ name: "group_id" })
  group!: ScheduleGroupEntity;

  @Column({ type: "uuid", name: "user_id", comment: "회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.scheduleGroupMemberships)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;
}
