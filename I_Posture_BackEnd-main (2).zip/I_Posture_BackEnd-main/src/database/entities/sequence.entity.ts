import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { SequenceDetailEntity } from "./sequence-detail.entity";
import { ScheduleEntity } from "./schedule.entity";
import { SequenceGroupMappingEntity } from "./sequence-group-mapping.entity";

@Entity({ name: "sequences", orderBy: { created_at: "DESC", id: "ASC" } })
export class SequenceEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "시퀀스 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "담당 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.sequences)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "varchar", name: "title", length: 100, comment: "시퀀스 노트명" })
  title!: string;

  @Column({ type: "text", name: "note", nullable: true, comment: "시퀀스 메모" })
  note?: string;

  @Column({ type: "int", name: "duration", default: 60, comment: "수업 시간 (분)" })
  duration!: number;

  @Column({ type: "boolean", name: "is_active", default: true, comment: "활성 여부" })
  isActive!: boolean;

  @OneToMany(() => SequenceDetailEntity, (detail) => detail.sequence)
  details!: SequenceDetailEntity[];

  @OneToMany(() => ScheduleEntity, (schedule) => schedule.sequence)
  schedules!: ScheduleEntity[];

  @OneToMany(() => SequenceGroupMappingEntity, (mapping) => mapping.sequence)
  sequenceGroupMappings!: SequenceGroupMappingEntity[];
}
