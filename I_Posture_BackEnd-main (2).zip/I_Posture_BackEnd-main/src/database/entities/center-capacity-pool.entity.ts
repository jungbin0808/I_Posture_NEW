import { Column, CreateDateColumn, Entity, JoinColumn, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { CenterEntity } from "./center.entity";

@Entity({ name: "center_capacity_pool", orderBy: { created_at: "DESC", id: "ASC" } })
export class CenterCapacityPoolEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "센터 용량 풀 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "center_id", comment: "센터 ID" })
  centerId!: string;

  @OneToOne(() => CenterEntity, (center) => center.capacityPool)
  @JoinColumn({ name: "center_id" })
  center!: CenterEntity;

  @Column({ type: "bigint", name: "total_capacity", default: 0, comment: "센터가 결제로 확보한 총 용량(bytes)" })
  totalCapacity!: string;

  @Column({ type: "bigint", name: "used_capacity", default: 0, comment: "실제 사용 중인 센터 소유 데이터 용량(bytes)" })
  usedCapacity!: string;

  @Column({ type: "bigint", name: "allocated_capacity", default: 0, comment: "현재 앱 회원 A들에게 부여(할당)되어 있는 센터 제공 용량 합계(bytes)" })
  allocatedCapacity!: string;
}
