import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { CenterEntity } from './center.entity';
import { UserEntity } from './user.entity';

@Entity({ name: 'center_trainer_invitations', orderBy: { invited_at: 'DESC', id: 'DESC' } })
export class CenterTrainerInvitationEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '초대 이력 ID' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @Column({ type: 'uuid', name: 'center_id', comment: '센터 ID' })
  centerId!: string;

  @ManyToOne(() => CenterEntity)
  @JoinColumn({ name: 'center_id' })
  center!: CenterEntity;

  @Column({ type: 'uuid', name: 'trainer_id', comment: '발급된 트레이너 사용자 ID' })
  trainerId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'trainer_id' })
  trainer!: UserEntity;

  @Column({ type: 'varchar', name: 'trainer_name', length: 50, comment: '트레이너명 (발급 시점)' })
  trainerName!: string;

  @Column({ type: 'varchar', name: 'login_user_id', length: 50, comment: '발급 아이디 (발급 시점)' })
  loginUserId!: string;

  @Column({ type: 'varchar', name: 'temp_password', length: 100, comment: '임시 비밀번호 (발급 시점)' })
  tempPassword!: string;

  @Column({ type: 'varchar', name: 'invite_email', length: 255, comment: '초대 메일 수신 주소' })
  inviteEmail!: string;

  @Column({
    type: 'timestamp',
    name: 'invited_at',
    precision: 3,
    comment: '초대 보낸 일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  invitedAt!: Date;
}
