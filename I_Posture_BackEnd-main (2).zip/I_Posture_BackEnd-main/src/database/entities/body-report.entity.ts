import { Entity, Column, ManyToOne, JoinColumn, PrimaryGeneratedColumn, CreateDateColumn, UpdateDateColumn, DeleteDateColumn } from 'typeorm';
import { UserEntity } from './user.entity';

@Entity({ name: 'body_reports' })
export class BodyReportEntity {
  @PrimaryGeneratedColumn('uuid')
  id!: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamp',
    precision: 3,
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamp',
    precision: 3,
    default: () => 'CURRENT_TIMESTAMP(3)',
    onUpdate: 'CURRENT_TIMESTAMP(3)',
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    name: 'deleted_at',
    type: 'timestamp',
    precision: 3,
    nullable: true,
  })
  deletedAt?: Date;

  @Column({ name: 'user_id' })
  userId!: string;

  @Column({ name: 'trainer_id', nullable: true, comment: '측정한 트레이너 ID. null이면 회원 셀프측정' })
  trainerId?: string;

  @Column({ name: 'total_score', type: 'int', default: 0 })
  totalScore!: number;

  @Column({ name: 'analysis_data', type: 'json' })
  analysisData!: any;

  @Column({
    name: 'display_payload_en',
    type: 'json',
    nullable: true,
    comment: '영문 리포트 전체 payload (Google Translate 스냅샷, 트레이너 코멘트 제외)',
  })
  displayPayloadEn?: any;

  @Column({ name: 'comment', type: 'text', nullable: true })
  comment?: string;

  @Column({ name: 'neck_score', type: 'float', default: 0 })
  neckScore!: number;

  @Column({ name: 'pelvis_asymmetry_score', type: 'float', default: 0 })
  pelvisAsymmetryScore!: number;

  @Column({ name: 'shoulder_asymmetry_score', type: 'float', default: 0 })
  shoulderAsymmetryScore!: number;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'trainer_id' })
  trainer?: UserEntity;
}
