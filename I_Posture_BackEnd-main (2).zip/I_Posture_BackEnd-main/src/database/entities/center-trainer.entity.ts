import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { CenterEntity } from "./center.entity";
import { UserEntity } from "./user.entity";

export enum CenterTrainerStatus {
  WORKING = "WORKING",
  RESIGNED = "RESIGNED",
}

@Entity({ name: "center_trainers" }) // orderBy 제거
export class CenterTrainerEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "센터-트레이너 소속 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "등록일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "center_id", comment: "센터 ID" })
  centerId!: string;

  @ManyToOne(() => CenterEntity, (center) => center.trainers)
  @JoinColumn({ name: "center_id" })
  center!: CenterEntity;

  @Column({ type: "uuid", name: "trainer_id", comment: "트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.centerAffiliations)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({
    type: "enum",
    enum: CenterTrainerStatus,
    name: "status",
    default: CenterTrainerStatus.WORKING,
    comment: "근무상태 (재직/퇴사)",
  })
  status!: CenterTrainerStatus;

  @Column({
    type: "timestamp",
    name: "deactivated_at",
    precision: 3,
    nullable: true,
    comment: "계정 비활성화일시",
  })
  deactivatedAt?: Date;

  @Column({ type: "varchar", name: "position", length: 50, nullable: true, comment: "직책 (팀장, 매니저 등)" })
  position?: string;

  @Column({ type: "date", name: "hired_at", comment: "입사일" })
  hiredAt!: string;

  @Column({ type: "date", name: "resigned_at", nullable: true, comment: "퇴사일" })
  resignedAt?: string;
}
