import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum ComparisonReportType {
  BODY = 'BODY',
  ROM = 'ROM',
  MOTION = 'MOTION',
  INBODY = 'INBODY',
  SPINE = 'SPINAL-ALIGNMENT',
  BALANCE = 'BALANCE-TEST',
  FULL_BODY = 'OVERHEAD-SQUAT',
}

@Entity({ name: "report_comparisons" })
export class ReportComparisonEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "PK (UUID)" })
  id!: string;

  @Column({ type: "uuid", name: "user_id", comment: "회원 ID (FK)" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.reportComparisons)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({
    type: "enum",
    enum: ComparisonReportType,
    name: "report_type",
    comment: "리포트 종류",
  })
  reportType!: ComparisonReportType;

  @Column({ type: "uuid", name: "before_report_id", comment: "Before 리포트 ID" })
  beforeReportId!: string;

  @Column({ type: "uuid", name: "after_report_id", comment: "After 리포트 ID" })
  afterReportId!: string;

  @Column({ type: "decimal", name: "before_score", precision: 5, scale: 1, nullable: true, comment: "Before 점수" })
  beforeScore?: number;

  @Column({ type: "decimal", name: "after_score", precision: 5, scale: 1, nullable: true, comment: "After 점수" })
  afterScore?: number;

  @Column({ type: "json", name: "summary_data", nullable: true, comment: "타입별 핵심 요약 데이터" })
  summaryData?: any;

  @Column({ type: "text", name: "trainer_comment", nullable: true, comment: "트레이너 수기 코멘트" })
  trainerComment?: string;

  @Column({ type: "timestamp", name: "after_measured_at", nullable: true, comment: "측정날짜(후) - 정렬 기준" })
  afterMeasuredAt?: Date;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "비교 생성일",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;
}
