import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum Evaluation {
  VERY_GOOD = "VERY_GOOD",
  GOOD = "GOOD",
  NORMAL = "NORMAL",
  POOR = "POOR",
  VERY_POOR = "VERY_POOR",
}

export enum FoodLogVisibility {
  PRIVATE = "PRIVATE",
  SHARED_WITH_TRAINER = "SHARED_WITH_TRAINER",
}

@Entity({ name: "food_logs", orderBy: { log_date: "DESC", created_at: "DESC" } })
export class FoodLogEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "일지 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "작성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "user_id", comment: "작성 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.foodLogs)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "date", name: "log_date", comment: "식단 날짜" })
  logDate!: string;

  @Column({
    type: "enum",
    enum: FoodLogVisibility,
    name: "visibility",
    default: FoodLogVisibility.PRIVATE,
    comment: "공개 범위 - PRIVATE(나의 식단, 트레이너 비공개) / SHARED_WITH_TRAINER(담당 트레이너 식단 연결)",
  })
  visibility!: FoodLogVisibility;

  @Column({ type: "uuid", name: "trainer_id", nullable: true, comment: "visibility가 SHARED_WITH_TRAINER일 때 공유 대상 트레이너 ID. 일지 자체는 회원 소유라 연동 해제와 무관하게 항상 보이고, 그 트레이너와 연동 해제되면 트레이너가 작성한 피드백 필드만 숨김" })
  trainerId?: string;

  @Column({ type: "json", name: "meals", nullable: true, comment: "끼니 타입(BREAKFAST/LUNCH/DINNER/NIGHT_SNACK/SNACK)을 key로 하는 객체. 값: { time, menuName, fileId }" })
  meals?: any;

  @Column({ type: "text", name: "user_memo", nullable: true, comment: "회원 메모 (종합)" })
  userMemo?: string;

  @Column({ type: "tinyint", name: "meal_satisfaction_score", nullable: true, comment: "오늘의 식단 만족도 별점 (1~5)" })
  mealSatisfactionScore?: number;

  @Column({ type: "json", name: "nutrition_feedback", nullable: true, comment: "영양소 균형 피드백" })
  nutritionFeedback?: any;

  @Column({ type: "json", name: "pattern_feedback", nullable: true, comment: "식사 패턴 피드백" })
  patternFeedback?: any;

  @Column({ type: "json", name: "hydration_feedback", nullable: true, comment: "수분 및 음료 섭취 피드백" })
  hydrationFeedback?: any;

  @Column({ type: "json", name: "coaching_feedback", nullable: true, comment: "종합 분석 및 코칭 피드백" })
  coachingFeedback?: any;

  @Column({
    type: "enum",
    enum: Evaluation,
    name: "evaluation",
    default: Evaluation.NORMAL,
    comment: "체중 목표 달성도 종합 평가 (5단계)",
  })
  evaluation!: Evaluation;

  @Column({ type: "text", name: "trainer_comment", nullable: true, comment: "트레이너 한줄 코멘트" })
  trainerComment?: string;
}
