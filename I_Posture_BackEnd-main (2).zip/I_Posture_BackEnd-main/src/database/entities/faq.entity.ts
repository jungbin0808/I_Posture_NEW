import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import type { FaqCategoryEntity } from "./faq-category.entity";

export enum FaqTargetRole {
  ALL = "ALL",
  MEMBER = "MEMBER",
  TRAINER = "TRAINER",
  CENTER = "CENTER",
}

@Entity({ name: "faqs" }) // orderBy 제거
export class FaqEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "FAQ ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시 (Soft Delete)",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "category_id", comment: "카테고리 ID" })
  categoryId!: string;

  @ManyToOne("FaqCategoryEntity", (category: FaqCategoryEntity) => category.faqs)
  @JoinColumn({ name: "category_id" })
  category!: FaqCategoryEntity;

  @Column({
    type: "enum",
    enum: FaqTargetRole,
    name: "target_role",
    default: FaqTargetRole.ALL,
    comment: "노출 대상",
  })
  targetRole!: FaqTargetRole;

  @Column({ type: "varchar", name: "title", length: 255, comment: "질문 제목" })
  title!: string;

  @Column({ type: "text", name: "content", comment: "답변 내용 (HTML 가능)" })
  content!: string;

  @Column({ type: "boolean", name: "is_visible", default: true, comment: "노출 여부" })
  isVisible!: boolean;

  @Column({ type: "int", name: "view_count", default: 0, comment: "조회수" })
  viewCount!: number;
}
