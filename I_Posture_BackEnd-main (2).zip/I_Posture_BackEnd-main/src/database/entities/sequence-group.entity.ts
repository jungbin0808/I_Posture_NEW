import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { SequenceGroupMappingEntity } from "./sequence-group-mapping.entity";

@Entity({ name: "sequence_groups", orderBy: { created_at: "DESC", id: "ASC" } })
export class SequenceGroupEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "시퀀스 그룹 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "담당 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "varchar", name: "name", length: 100, comment: "그룹명" })
  name!: string;

  @OneToMany(() => SequenceGroupMappingEntity, (mapping) => mapping.sequenceGroup)
  sequenceGroupMappings!: SequenceGroupMappingEntity[];
}
