import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { SequenceEntity } from "./sequence.entity";
import { ScheduleGroupEntity } from "./schedule-group.entity";
import { ScheduleBookingEntity } from "./schedule-booking.entity";

export enum LessonStatus {
  RESERVED = "RESERVED",
  COMPLETED = "COMPLETED",
  NOSHOW = "NOSHOW",
}

@Entity({ name: "schedules", orderBy: { start_time: "ASC", created_at: "DESC" } })
export class ScheduleEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "스케줄 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "담당 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.schedules)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "uuid", name: "sequence_id", nullable: true, comment: "수업 내용 (시퀀스)" })
  sequenceId?: string;

  @ManyToOne(() => SequenceEntity, (sequence) => sequence.schedules)
  @JoinColumn({ name: "sequence_id" })
  sequence?: SequenceEntity;

  @Column({ type: "uuid", name: "group_id", nullable: true, comment: "그룹 ID (Null=1:1)" })
  groupId?: string;

  @ManyToOne(() => ScheduleGroupEntity, (group) => group.schedules)
  @JoinColumn({ name: "group_id" })
  group?: ScheduleGroupEntity;

  @Column({ type: "timestamp", name: "start_time", precision: 3, comment: "시작 시간" })
  startTime!: Date;

  @Column({ type: "timestamp", name: "end_time", precision: 3, comment: "종료 시간" })
  endTime!: Date;

  @Column({ type: "text", name: "memo", nullable: true, comment: "특이사항 (메모)" })
  memo?: string;

  @Column({
    type: "enum",
    enum: LessonStatus,
    name: "lesson_status",
    default: LessonStatus.RESERVED,
    comment: "수업 상태 (RESERVED=예약, COMPLETED=완료, NOSHOW=노쇼)",
  })
  lessonStatus!: LessonStatus;

  @OneToMany(() => ScheduleBookingEntity, (booking) => booking.schedule)
  bookings!: ScheduleBookingEntity[];
}
