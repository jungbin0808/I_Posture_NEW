import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "inbody_data", orderBy: { measured_at: "DESC", id: "ASC" } })
export class InbodyDataEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "데이터 ID" })
  id!: string;

  @Column({
    type: "timestamp",
    name: "measured_at",
    precision: 3,
    comment: "측정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  measuredAt!: Date;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "등록일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({ type: "timestamp", name: "deleted_at", precision: 3, nullable: true, comment: "삭제일시" })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "user_id", comment: "대상 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.inbodyData)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "trainer_id", nullable: true, comment: "담당 트레이너 ID. null이면 회원 셀프 등록" })
  trainerId?: string;

  @ManyToOne(() => UserEntity, (user) => user.createdInbodyData)
  @JoinColumn({ name: "trainer_id" })
  trainer?: UserEntity;

  @Column({ type: "json", name: "key_stats", nullable: true, comment: "주요 수치 (체중, 골격근량 등)" })
  keyStats?: any;

  @Column({ type: "json", name: "detail_data", nullable: true, comment: "상세 분석 및 OCR 데이터" })
  detailData?: any;
}
