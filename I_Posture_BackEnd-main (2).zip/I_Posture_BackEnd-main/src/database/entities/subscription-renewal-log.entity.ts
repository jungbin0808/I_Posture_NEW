import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

export enum RenewalStatus {
  SUCCESS = 'SUCCESS',
  FAILED = 'FAILED',
  EXPIRED = 'EXPIRED', // 해지 예약으로 만료 처리
}

@Entity({ name: 'subscription_renewal_logs' })
export class SubscriptionRenewalLogEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'processed_at',
    precision: 3,
    comment: '처리 일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  processedAt!: Date;

  @Column({ type: 'uuid', name: 'subscription_id', comment: '구독 ID' })
  subscriptionId!: string;

  @Column({ type: 'uuid', name: 'user_id', comment: '회원 ID' })
  userId!: string;

  @Column({ type: 'uuid', name: 'plan_id', comment: '플랜 ID' })
  planId!: string;

  @Column({
    type: 'enum',
    enum: RenewalStatus,
    name: 'status',
    comment: '처리 결과',
  })
  status!: RenewalStatus;

  @Column({ type: 'int', name: 'amount', nullable: true, comment: '결제 금액' })
  amount?: number;

  @Column({ type: 'uuid', name: 'bill_key_id', nullable: true, comment: '사용된 빌키 ID' })
  billKeyId?: string;

  @Column({ type: 'varchar', name: 'tid', length: 40, nullable: true, comment: 'KPN 거래 고유번호' })
  tid?: string;

  @Column({ type: 'varchar', name: 'fail_reason', length: 500, nullable: true, comment: '실패 사유' })
  failReason?: string;
}
