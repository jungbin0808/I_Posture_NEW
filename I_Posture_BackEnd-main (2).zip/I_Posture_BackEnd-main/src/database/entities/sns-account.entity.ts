import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum SnsProvider {
  GOOGLE = "GOOGLE",
  APPLE = "APPLE",
}

@Entity({ name: "sns_accounts", orderBy: { created_at: "DESC", id: "ASC" } })
export class SnsAccountEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "SNS 연동 고유 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "등록일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "user_id", comment: "회원 ID (users.id)", nullable: true })
  userId!: string;

  @ManyToOne(() => UserEntity, { onDelete: "CASCADE" })
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({
    type: "enum",
    enum: SnsProvider,
    name: "provider",
    comment: "SNS 제공자",
  })
  provider!: SnsProvider;

  @Column({ type: "varchar", name: "provider_user_id", length: 255, comment: "SNS의 UID" })
  providerUserId!: string;

  @Column({ type: "varchar", name: "sns_email", length: 255, nullable: true, comment: "SNS 이메일" })
  snsEmail?: string;

  @Column({ type: "varchar", name: "access_token", length: 1000, nullable: true, comment: "Access 토큰" })
  accessToken?: string;

  @Column({ type: "varchar", name: "refresh_token", length: 1000, nullable: true, comment: "Refresh 토큰" })
  refreshToken?: string;
}
