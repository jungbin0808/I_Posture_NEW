import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum FileOwnerType {
  MEMBER = "MEMBER",
  TRAINER = "TRAINER",
  CENTER = "CENTER",
  ADMIN = "ADMIN",
}

export enum FileRelatedType {
  PROFILE = "PROFILE",
  BODY = "BODY",
  BODY_FRONT = "BODY_FRONT",
  BODY_SIDE = "BODY_SIDE",
  BODY_BACK = "BODY_BACK",
  PRECISION = "PRECISION",
  MOTION = "MOTION",
  INBODY = "INBODY",
  FOOD_LOG = "FOOD_LOG",
  DIET_LOG = "DIET_LOG",
  WORKOUT_LOG = "WORKOUT_LOG",
  CONSULTATION_LOG = "CONSULTATION_LOG",
  SEQUENCE = "SEQUENCE",
  SEQUENCE_THUMBNAIL = "SEQUENCE_THUMBNAIL",
  EXERCISE = "EXERCISE",
  CENTER_NOTICE = "CENTER_NOTICE",
  CENTER_LOGO = "CENTER_LOGO",
  CENTER_GALLERY = "CENTER_GALLERY",
  QNA_ANSWER = "QNA_ANSWER",
  BANNER = "BANNER",
}

@Entity({ name: "files", orderBy: { created_at: "DESC" } })
export class FileEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "파일 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  // @DeleteDateColumn({
  //   type: "timestamp",
  //   name: "deleted_at",
  //   precision: 3,
  //   nullable: true,
  //   comment: "삭제일시",
  // })
  // deletedAt?: Date;

  @Column({ type: "varchar", name: "file_url", length: 500, comment: "파일 URL (S3)" })
  fileUrl!: string;

  @Column({ type: "varchar", name: "s3_key", length: 500, comment: "S3 Key" })
  s3Key!: string;

  // @Column({ type: "varchar", name: "mime_type", length: 100, nullable: true, comment: "MIME 타입" })
  // mimeType?: string;

  @Column({ type: "bigint", name: "size", comment: "파일 크기 (Byte)" })
  size!: string;

  @Column({
    type: "enum",
    enum: FileOwnerType,
    name: "owner_type",
    comment: "소유자 유형 (누구의 용량을 차감할지)",
  })
  ownerType!: FileOwnerType;

  @Column({ type: "uuid", name: "owner_id", comment: "용량 차감 주체 ID" })
  ownerId!: string;

  @Column({ type: "uuid", name: "uploader_id", comment: "실제 업로드/촬영을 수행한 사용자 ID" })
  uploaderId!: string;

  @ManyToOne(() => UserEntity, (user) => user.uploadedFiles)
  @JoinColumn({ name: "uploader_id" })
  uploader!: UserEntity;

  @Column({ type: "uuid", name: "member_id", nullable: true, comment: "관련 회원 ID (데이터의 주체)" })
  memberId?: string;

  @ManyToOne(() => UserEntity, (user) => user.files)
  @JoinColumn({ name: "member_id" })
  member?: UserEntity;

  @Column({
    type: "enum",
    enum: FileRelatedType,
    name: "related_type",
    nullable: true,
    comment: "관련 데이터 유형",
  })
  relatedType?: FileRelatedType;

  @Column({ type: "uuid", name: "related_id", nullable: true, comment: "관련 데이터 ID" })
  relatedId?: string;

  @Column({ type: "varchar", name: "division", length: 50, nullable: true, comment: "전면/측면 등 구분" })
  division?: string;
}
