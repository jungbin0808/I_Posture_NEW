import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum TrainerUserStatus {
  PENDING = "PENDING",
  ACTIVE = "ACTIVE",
  HOLD = "HOLD",
}

@Entity({ name: "trainer_users", orderBy: { created_at: "DESC", id: "ASC" } })
export class TrainerUserEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "트레이너-관리회원(C) 매핑 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "등록일시 (관리 시작 시각)",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시 (관리 종료)",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.managedMemberships)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "uuid", name: "member_id", comment: "관리되는 회원 C ID" })
  memberId!: string;

  @ManyToOne(() => UserEntity, (user) => user.trainerMemberships)
  @JoinColumn({ name: "member_id" })
  member!: UserEntity;

  @Column({
    type: "enum",
    enum: TrainerUserStatus,
    name: "status",
    default: TrainerUserStatus.ACTIVE,
    comment: "관리 상태",
  })
  status!: TrainerUserStatus;

  @Column({ type: "timestamp", name: "linked_at", precision: 3, nullable: true, comment: "관리 관계 활성화 시각" })
  linkedAt?: Date;

  @Column({ type: "varchar", name: "memo", length: 255, nullable: true, comment: "트레이너용 회원 메모" })
  memo?: string;
}
