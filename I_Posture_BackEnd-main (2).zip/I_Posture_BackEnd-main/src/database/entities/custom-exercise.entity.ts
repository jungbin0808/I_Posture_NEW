import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({ name: 'custom_exercise', orderBy: { sort_order: 'ASC' } })
export class CustomExerciseEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id!: string;

  @Column({
    type: 'varchar',
    name: 'category',
    length: 20,
    comment: 'BODY_BALANCE | INBODY_DIET | LINE_DIET | FACE_CARE',
  })
  category!: string;

  @Column({ type: 'varchar', name: 'main_cat', length: 100 })
  mainCat!: string;

  @Column({ type: 'varchar', name: 'sub_cat', length: 100, nullable: true })
  subCat!: string | null;

  @Column({ type: 'varchar', name: 'detail_cat', length: 100 })
  detailCat!: string;

  @Column({
    type: 'varchar',
    name: 'level',
    length: 5,
    nullable: true,
    comment: 'Lv1 | Lv2 | Lv3 | NULL',
  })
  level!: string | null;

  @Column({ type: 'varchar', name: 'youtube_url', length: 500, nullable: true })
  youtubeUrl!: string | null;

  @Column({ type: 'varchar', name: 'title', length: 200, nullable: true, comment: '영상 제목 (관리자 보완용, mainCat/subCat/detailCat과 별개)' })
  title?: string | null;

  @Column({ type: 'varchar', name: 'thumbnail_url', length: 500, nullable: true, comment: '썸네일 이미지 URL (S3, 관리자 보완용)' })
  thumbnailUrl?: string | null;

  @Column({ type: 'int', unsigned: true, name: 'duration_seconds', nullable: true, comment: '영상 길이(초), 관리자 보완용' })
  durationSeconds?: number | null;

  @Column({ type: 'boolean', name: 'is_new', default: false, comment: 'NEW 뱃지 노출 여부 (관리자 수동 설정)' })
  isNew!: boolean;

  @Column({ type: 'smallint', unsigned: true, name: 'sort_order', default: 0 })
  sortOrder!: number;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'updated_at',
    precision: 3,
    default: () => 'CURRENT_TIMESTAMP(3)',
    onUpdate: 'CURRENT_TIMESTAMP(3)',
  })
  updatedAt!: Date;
}
