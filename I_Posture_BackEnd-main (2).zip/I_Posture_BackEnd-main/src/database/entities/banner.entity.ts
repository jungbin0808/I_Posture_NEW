import { Column, CreateDateColumn, DeleteDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

export enum BannerPosition {
  HOME = 'HOME',
  POINT = 'POINT',
}

@Entity({ name: 'banners', orderBy: { position: 'ASC', sort_order: 'ASC', created_at: 'DESC' } })
export class BannerEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '배너 ID' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'updated_at',
    precision: 3,
    comment: '수정일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
    onUpdate: 'CURRENT_TIMESTAMP(3)',
  })
  updatedAt!: Date;

  @DeleteDateColumn({ type: 'timestamp', name: 'deleted_at', precision: 3, nullable: true, comment: '삭제일시' })
  deletedAt?: Date;

  @Column({ type: 'enum', enum: BannerPosition, name: 'position', comment: '노출 위치 (HOME: 홈 화면, POINT: 포인트 화면)' })
  position!: BannerPosition;

  @Column({ type: 'varchar', name: 'title', length: 100, comment: '관리용 배너 이름 (화면 비노출)' })
  title!: string;

  @Column({ type: 'varchar', name: 'image_url', length: 500, comment: '배너 이미지 URL (S3)' })
  imageUrl!: string;

  @Column({ type: 'varchar', name: 'link_url', length: 500, nullable: true, comment: '탭 시 이동할 링크 URL (딥링크 또는 웹 URL)' })
  linkUrl?: string;

  @Column({ type: 'int', name: 'sort_order', default: 0, comment: '노출 순서 (오름차순)' })
  sortOrder!: number;

  @Column({ type: 'boolean', name: 'is_active', default: true, comment: '노출 여부' })
  isActive!: boolean;
}
