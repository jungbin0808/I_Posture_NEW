import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum LinkRequestBy {
  MEMBER = "MEMBER",
  TRAINER = "TRAINER",
}

export enum LinkRequestStatus {
  PENDING = "PENDING",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED",
  CANCELED = "CANCELED",
}

@Entity({ name: "trainer_link_requests", orderBy: { created_at: "DESC", id: "ASC" } })
export class TrainerLinkRequestEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "회원-트레이너 연결 요청 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "요청 생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "member_id", comment: "앱 회원 A ID" })
  memberId!: string;

  @ManyToOne(() => UserEntity, (user) => user.sentLinkRequestsAsMember)
  @JoinColumn({ name: "member_id" })
  member!: UserEntity;

  @Column({ type: "uuid", name: "trainer_id", comment: "트레이너 B ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.receivedLinkRequestsAsTrainer)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({
    type: "enum",
    enum: LinkRequestBy,
    name: "requested_by",
    comment: "요청 주체 (MEMBER or TRAINER)",
  })
  requestedBy!: LinkRequestBy;

  @Column({
    type: "enum",
    enum: LinkRequestStatus,
    name: "status",
    default: LinkRequestStatus.PENDING,
    comment: "요청 상태",
  })
  status!: LinkRequestStatus;

  @Column({ type: "varchar", name: "request_message", length: 255, nullable: true, comment: "요청 메시지" })
  requestMessage?: string;

  @Column({ type: "varchar", name: "response_message", length: 255, nullable: true, comment: "응답 메시지" })
  responseMessage?: string;

  @Column({ type: "timestamp", name: "processed_at", precision: 3, nullable: true, comment: "요청 처리 일시" })
  processedAt?: Date;
}
