import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { SubscriptionPlanEntity } from "./subscription-plan.entity";
import { CenterEntity } from "./center.entity";
import { PaymentEntity } from "./payment.entity";
import { SubscriptionScope } from "../../common/enums/subscription.enum";

export enum SubscriptionStatus {
  ACTIVE = "ACTIVE",
  PAUSED = "PAUSED",
  CANCELED = "CANCELED",
  EXPIRED = "EXPIRED",
}

export enum BillingCycle {
  MONTHLY = "MONTHLY",
  YEARLY = "YEARLY",
  ONE_TIME = "ONE_TIME",
}

@Entity({ name: "subscriptions" }) // orderBy 제거
export class SubscriptionEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "구독 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "구독 생성일",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "user_id", comment: "결제자(소유자) ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.subscriptions)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "plan_id", comment: "이용 중인 상품 ID" })
  planId!: string;

  @ManyToOne(() => SubscriptionPlanEntity, (plan) => plan.subscriptions)
  @JoinColumn({ name: "plan_id" })
  plan!: SubscriptionPlanEntity;

  @Column({
    type: "enum",
    enum: SubscriptionScope,
    name: "scope",
    default: SubscriptionScope.PERSONAL,
    comment: "구독의 실제 적용 범위",
  })
  scope!: SubscriptionScope;

  @Column({ type: "uuid", name: "center_id", nullable: true, comment: "센터 플랜일 경우 적용 센터 ID" })
  centerId?: string;

  @ManyToOne(() => CenterEntity, (center) => center.subscriptions)
  @JoinColumn({ name: "center_id" })
  center?: CenterEntity;

  @Column({
    type: "enum",
    enum: SubscriptionStatus,
    name: "status",
    default: SubscriptionStatus.ACTIVE,
    comment: "구독 상태",
  })
  status!: SubscriptionStatus;

  @Column({ type: "date", name: "next_billing_date", nullable: true, comment: "다음 결제 예정일" })
  nextBillingDate?: string;

  @Column({ type: "bigint", name: "current_usage", default: 0, comment: "해당 구독으로 제공된 용량 중 사용된 총량 캐시(Byte)" })
  currentUsage!: string;

  @Column({
    type: "enum",
    enum: BillingCycle,
    name: "billing_cycle",
    default: BillingCycle.MONTHLY,
    comment: "결제 주기",
  })
  billingCycle!: BillingCycle;

  @Column({ type: "boolean", name: "cancel_at_period_end", default: false, comment: "현재 주기 종료 시 해지 예약 여부" })
  cancelAtPeriodEnd!: boolean;

  @Column({ type: "boolean", name: "is_trial", default: false, comment: "무료체험 구독 여부" })
  isTrial!: boolean;

  @OneToMany(() => PaymentEntity, (payment) => payment.subscription)
  payments!: PaymentEntity[];
}
