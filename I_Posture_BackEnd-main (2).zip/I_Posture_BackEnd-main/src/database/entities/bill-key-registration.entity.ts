import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { UserEntity } from './user.entity';

/**
 * 빌키 등록/교체 진행 중인 임시 레코드
 * - 카드 등록 UI 진입 시 INSERT
 * - KPN 콜백 성공 시 bill_keys 로 이동 후 DELETE
 * - expiresAt 지난 레코드는 스케줄러가 정리
 */
@Entity({ name: 'bill_key_registrations' })
export class BillKeyRegistrationEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id!: string;

  @Index()
  @Column({ type: 'uuid', name: 'user_id' })
  userId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  /**
   * 교체 시: 교체 대상이 되는 기존 bill_key id
   * 신규 등록 시: null
   */
  @Column({ type: 'uuid', name: 'replacing_bill_key_id', nullable: true })
  replacingBillKeyId?: string | null;

  /** KPN에 전달한 custNo (UUID 하이픈 제거 32자) */
  @Column({ type: 'varchar', name: 'cust_no', length: 32 })
  custNo!: string;

  /** KPN에 전달한 주문자(카드 소유주)명 */
  @Column({ type: 'varchar', name: 'cust_name', length: 50, nullable: true, comment: '카드 소유주명 (주문자명)' })
  custName?: string;

  /** 등록 세션 만료 시각 (기본 30분) */
  @Column({ type: 'timestamp', name: 'expires_at', precision: 3 })
  expiresAt!: Date;

  /** 콜백 성공 후 완료 처리된 시각 (null = 진행 중) */
  @Column({ type: 'timestamp', name: 'completed_at', precision: 3, nullable: true })
  completedAt?: Date | null;

  @CreateDateColumn({ type: 'timestamp', name: 'created_at', precision: 3, default: () => 'CURRENT_TIMESTAMP(3)' })
  createdAt!: Date;
}
