import { CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { TermEntity } from "./term.entity";

@Entity({ name: "user_agreements", orderBy: { agreed_at: "DESC", id: "ASC" } })
export class UserAgreementEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "약관 동의 이력 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "agreed_at",
    precision: 3,
    comment: "동의 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  agreedAt!: Date;

  @ManyToOne(() => UserEntity, (user) => user.agreements)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @ManyToOne(() => TermEntity, (term) => term.userAgreements)
  @JoinColumn({ name: "term_id" })
  term!: TermEntity;
}
