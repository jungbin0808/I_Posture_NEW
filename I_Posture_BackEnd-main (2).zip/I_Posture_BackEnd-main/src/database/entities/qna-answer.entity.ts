import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { QnaQuestionEntity } from "./qna-question.entity";

@Entity({ name: "qna_answers", orderBy: { created_at: "ASC" } })
export class QnaAnswerEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "답변 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "작성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({ type: "uuid", name: "author_id", comment: "답변자 ID" })
  authorId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "author_id" })
  author!: UserEntity;

  @Column({ type: "uuid", name: "question_id", comment: "질문 ID" })
  questionId!: string;

  @ManyToOne('QnaQuestionEntity', 'answers')
  @JoinColumn({ name: "question_id" })
  question!: QnaQuestionEntity;

  @Column({ type: "text", name: "content", comment: "답변 내용" })
  content!: string;

  @Column({ type: "boolean", name: "is_accepted", default: false, comment: "채택 여부" })
  isAccepted!: boolean;

  @Column({ type: "int", name: "rating", nullable: true, comment: "답변 별점 (1~5)" })
  rating?: number;
}
