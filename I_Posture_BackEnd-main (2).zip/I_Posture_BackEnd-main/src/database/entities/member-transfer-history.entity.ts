import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { CenterEntity } from './center.entity';
import { UserEntity } from './user.entity';

@Entity({ name: 'member_transfer_histories', orderBy: { transferred_at: 'DESC', id: 'DESC' } })
export class MemberTransferHistoryEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '이관 이력 ID' })
  id!: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @Column({ type: 'uuid', name: 'center_id', comment: '센터 ID' })
  centerId!: string;

  @ManyToOne(() => CenterEntity)
  @JoinColumn({ name: 'center_id' })
  center!: CenterEntity;

  @Column({ type: 'uuid', name: 'member_id', comment: '회원 ID' })
  memberId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'member_id' })
  member!: UserEntity;

  @Column({ type: 'uuid', name: 'from_trainer_id', comment: '이관 전 담당 트레이너 ID' })
  fromTrainerId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'from_trainer_id' })
  fromTrainer!: UserEntity;

  @Column({ type: 'uuid', name: 'to_trainer_id', comment: '이관 후 담당 트레이너 ID' })
  toTrainerId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'to_trainer_id' })
  toTrainer!: UserEntity;

  @Column({
    type: 'timestamp',
    name: 'app_link_unlinked_at',
    precision: 3,
    nullable: true,
    comment: '이관 시점 이용권 만료(예정)일 (미보유 시 NULL)',
  })
  appLinkUnlinkedAt?: Date;

  @Column({
    type: 'timestamp',
    name: 'transferred_at',
    precision: 3,
    comment: '이관일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  transferredAt!: Date;
}
