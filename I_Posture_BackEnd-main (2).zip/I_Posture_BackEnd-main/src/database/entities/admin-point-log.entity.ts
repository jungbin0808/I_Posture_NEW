import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { PointHistoryEntity } from "./point-history.entity";

export enum AdminPointActionType {
  GIVE = "GIVE",
  DEDUCT = "DEDUCT",
}

@Entity({ name: "admin_point_logs", orderBy: { created_at: "DESC" } })
export class AdminPointLogEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "관리자 포인트 조정 로그 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "지급/차감 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "admin_id", comment: "조작한 관리자 ID" })
  adminId!: string;

  @ManyToOne(() => UserEntity, (user) => user.createdAdminPointLogs)
  @JoinColumn({ name: "admin_id" })
  admin!: UserEntity;

  @Column({ type: "uuid", name: "target_user_id", comment: "포인트를 받은/차감된 회원 ID" })
  targetUserId!: string;

  @ManyToOne(() => UserEntity, (user) => user.receivedAdminPointLogs)
  @JoinColumn({ name: "target_user_id" })
  targetUser!: UserEntity;

  @Column({
    type: "enum",
    enum: AdminPointActionType,
    name: "action_type",
    default: AdminPointActionType.GIVE,
    comment: "관리자 액션 유형",
  })
  actionType!: AdminPointActionType;

  @Column({ type: "int", name: "amount", comment: "변동 포인트 (항상 양수)" })
  amount!: number;

  @Column({ type: "varchar", name: "reason", length: 255, nullable: true, comment: "지급/차감 사유" })
  reason?: string;

  @Column({ type: "uuid", name: "point_history_id", nullable: true, comment: "생성된 포인트 이력 레코드 ID" })
  pointHistoryId?: string;

  @OneToOne(() => PointHistoryEntity)
  @JoinColumn({ name: "point_history_id" })
  pointHistory?: PointHistoryEntity;
}
