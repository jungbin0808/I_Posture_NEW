import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, OneToOne, PrimaryGeneratedColumn } from "typeorm";
import { FileEntity, FileOwnerType } from "./file.entity";
import { UserEntity } from "./user.entity";

@Entity({ name: "storage_usages", orderBy: { created_at: "DESC", id: "ASC" } })
export class StorageUsageEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "스토리지 사용 기록 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "사용 기록 생성일시 (업로드 시점)",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "resource_id", comment: "사용량이 발생한 파일 ID" })
  resourceId!: string;

  @OneToOne(() => FileEntity)
  @JoinColumn({ name: "resource_id" })
  resource!: FileEntity;

  @Column({ type: "uuid", name: "member_id", comment: "데이터 소유 회원 ID (A 또는 C)" })
  memberId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "member_id" })
  member!: UserEntity;

  @Column({
    type: "enum",
    enum: FileOwnerType,
    name: "owner_type",
    default: FileOwnerType.MEMBER,
    comment: "용량 차감 대상 유형 (개인/트레이너/센터)",
  })
  ownerType!: FileOwnerType;

  @Column({ type: "uuid", name: "owner_id", comment: "용량 차감 주체 ID (users.id 또는 centers.id)" })
  ownerId!: string;

  @Column({ type: "bigint", name: "used_bytes", default: 0, comment: "이 파일로 인해 소모된 용량(Byte)" })
  usedBytes!: string;

  @Column({ type: "uuid", name: "uploader_id", comment: "업로드한 사용자 ID (회원 A 또는 트레이너 B)" })
  uploaderId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: "uploader_id" })
  uploader!: UserEntity;
}
