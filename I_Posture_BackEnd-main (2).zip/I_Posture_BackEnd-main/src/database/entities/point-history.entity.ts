import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn } from "typeorm";
import { UserEntity } from "./user.entity";

export enum PointHistoryType {
  EARN = "EARN",
  USE = "USE",
  EXPIRE = "EXPIRE",
}

export enum PointSource {
  ADOPT = "ADOPT",
  CHALLENGE = "CHALLENGE",
  EVENT = "EVENT",
  ADMIN = "ADMIN",
  SYSTEM = "SYSTEM",
}

@Entity({ name: "point_history", orderBy: { created_at: "DESC" } })
export class PointHistoryEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "포인트 이력 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "포인트 변동 발생 일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @Column({ type: "uuid", name: "user_id", comment: "회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.pointHistories)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({
    type: "enum",
    enum: PointHistoryType,
    name: "type",
    default: PointHistoryType.EARN,
    comment: "변동 유형",
  })
  type!: PointHistoryType;

  @Column({
    type: "enum",
    enum: PointSource,
    name: "source",
    default: PointSource.ADOPT,
    comment: "발생 원천",
  })
  source!: PointSource;

  @Column({ type: "int", name: "amount", comment: "변동 포인트" })
  amount!: number;

  @Column({ type: "int", name: "balance_after", comment: "해당 이력 반영 후 회원의 포인트 잔액 스냅샷" })
  balanceAfter!: number;

  @Column({ type: "varchar", name: "description", length: 255, nullable: true, comment: "적요/메모" })
  description?: string;
}
