import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity({ name: 'push_notification_log', orderBy: { created_at: 'DESC' } })
export class PushNotificationLogEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: 'PK (UUID)' })
  id!: string;

  @Column({ type: 'uuid', name: 'user_id', comment: '수신 유저 ID' })
  userId!: string;

  @Column({ type: 'varchar', name: 'title', length: 255, comment: '푸시 제목' })
  title!: string;

  @Column({ type: 'text', name: 'body', comment: '푸시 본문' })
  body!: string;

  @Column({ type: 'json', name: 'data', nullable: true, comment: '추가 데이터 (딥링크 등)' })
  data?: Record<string, string>;

  @Column({ type: 'varchar', name: 'fcm_token', length: 512, comment: '발송 시점 FCM 토큰' })
  fcmToken!: string;

  @Column({ type: 'varchar', name: 'status', length: 20, default: 'SUCCESS', comment: 'SUCCESS | FAILED' })
  status!: 'SUCCESS' | 'FAILED';

  @Column({ type: 'text', name: 'error_msg', nullable: true, comment: '실패 사유' })
  errorMsg?: string;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '발송일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;
}
