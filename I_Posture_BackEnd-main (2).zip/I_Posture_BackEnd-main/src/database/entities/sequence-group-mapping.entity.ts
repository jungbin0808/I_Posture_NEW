import { Entity, JoinColumn, ManyToOne, PrimaryColumn } from "typeorm";
import { SequenceEntity } from "./sequence.entity";
import { SequenceGroupEntity } from "./sequence-group.entity";

@Entity({ name: "sequence_group_mappings" })
export class SequenceGroupMappingEntity {
  @PrimaryColumn({ type: "uuid", name: "sequence_id" })
  sequenceId!: string;

  @PrimaryColumn({ type: "uuid", name: "sequence_group_id" })
  sequenceGroupId!: string;

  @ManyToOne(() => SequenceEntity, (sequence) => sequence.sequenceGroupMappings)
  @JoinColumn({ name: "sequence_id" })
  sequence!: SequenceEntity;

  @ManyToOne(() => SequenceGroupEntity, (group) => group.sequenceGroupMappings)
  @JoinColumn({ name: "sequence_group_id" })
  sequenceGroup!: SequenceGroupEntity;
}
