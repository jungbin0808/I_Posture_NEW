import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn } from 'typeorm';

export enum UserNotificationType {
  NOTICE = 'NOTICE',
  EVENT = 'EVENT',
  APP = 'APP',
}

@Entity({ name: 'user_notifications', orderBy: { created_at: 'DESC', id: 'ASC' } })
@Index('IDX_user_notifications_user_id_created_at', ['userId', 'createdAt'])
export class UserNotificationEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '알림 ID' })
  id!: string;

  @Column({ type: 'uuid', name: 'user_id', comment: '수신 유저 ID' })
  userId!: string;

  @Column({
    type: 'enum',
    enum: UserNotificationType,
    name: 'type',
    comment: '알림 유형 (공지/이벤트/앱 알림)',
  })
  type!: UserNotificationType;

  @Column({ type: 'varchar', name: 'title', length: 255, comment: '알림 제목' })
  title!: string;

  @Column({ type: 'text', name: 'body', comment: '알림 본문' })
  body!: string;

  @Column({ type: 'json', name: 'data', nullable: true, comment: '추가 데이터 (딥링크 등)' })
  data?: Record<string, string>;

  @Column({
    type: 'timestamp',
    name: 'read_at',
    precision: 3,
    nullable: true,
    comment: '읽음 일시 (NULL이면 미읽음)',
  })
  readAt?: Date;

  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;
}
