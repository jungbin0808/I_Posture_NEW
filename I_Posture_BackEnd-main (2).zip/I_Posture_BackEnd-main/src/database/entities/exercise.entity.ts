import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { ExerciseCategoryEntity } from "./exercise-category.entity";

@Entity({ name: "exercises", orderBy: { sortOrder: "ASC", createdAt: "DESC" } })
export class ExerciseEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "운동 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시 (Soft Delete)",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "category_id", comment: "카테고리 ID" })
  categoryId!: string;

  @ManyToOne(() => ExerciseCategoryEntity, (category) => category.exercises)
  @JoinColumn({ name: "category_id" })
  category!: ExerciseCategoryEntity;

  @Column({ type: "varchar", name: "name", length: 100, comment: "운동명" })
  name!: string;

  @Column({ type: "text", name: "description", nullable: true, comment: "설명" })
  description?: string;

  @Column({ type: "int", name: "sort_order", default: 0, comment: "정렬 순서" })
  sortOrder!: number;

  @Column({ type: "boolean", name: "is_active", default: true, comment: "사용 여부" })
  isActive!: boolean;
}
