import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { ScheduleEntity } from "./schedule.entity";
import { UserEntity } from "./user.entity";

export enum BookingStatus {
  APPLIED = "APPLIED",
  CANCELED = "CANCELED",
  NOSHOW = "NOSHOW",
}

@Entity({ name: "schedule_bookings", orderBy: { created_at: "DESC", id: "ASC" } })
export class ScheduleBookingEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "예약 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "schedule_id", comment: "스케줄 ID" })
  scheduleId!: string;

  @ManyToOne(() => ScheduleEntity, (schedule) => schedule.bookings)
  @JoinColumn({ name: "schedule_id" })
  schedule!: ScheduleEntity;

  @Column({ type: "uuid", name: "user_id", comment: "참여 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.bookings)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({
    type: "enum",
    enum: BookingStatus,
    name: "status",
    default: BookingStatus.APPLIED,
    comment: "상태",
  })
  status!: BookingStatus;

  @Column({ type: "varchar", name: "cancel_reason", length: 255, nullable: true, comment: "취소 사유" })
  cancelReason?: string;
}
