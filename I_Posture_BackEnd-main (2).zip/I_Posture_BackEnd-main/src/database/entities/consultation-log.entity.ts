import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { BodyReportEntity } from "./body-report.entity";
import { PrecisionReportEntity } from "./precision-report.entity";
import { MotionAnalysisEntity } from "./motion-analysis.entity";
import { InbodyDataEntity } from "./inbody-data.entity";

export enum ConsultType {
  NEW = "NEW",
  INTERIM = "INTERIM",
  RESET = "RESET",
  FINAL = "FINAL",
}

export enum ConsultResultStatus {
  REG_NEW = "REG_NEW",
  REG_RENEW = "REG_RENEW",
  TRIAL = "TRIAL",
  NO_SALE = "NO_SALE",
}

@Entity({ name: "consultation_logs", orderBy: { consult_at: "DESC", id: "ASC" } })
export class ConsultationLogEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "상담일지 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "trainer_id", comment: "작성 트레이너 ID" })
  trainerId!: string;

  @ManyToOne(() => UserEntity, (user) => user.createdConsultationLogs)
  @JoinColumn({ name: "trainer_id" })
  trainer!: UserEntity;

  @Column({ type: "uuid", name: "user_id", comment: "대상 회원 ID" })
  userId!: string;

  @ManyToOne(() => UserEntity, (user) => user.consultationLogs)
  @JoinColumn({ name: "user_id" })
  user!: UserEntity;

  @Column({
    type: "enum",
    enum: ConsultType,
    name: "consult_type",
    default: ConsultType.NEW,
    comment: "상담 유형",
  })
  consultType!: ConsultType;

  @Column({ type: "datetime", name: "consult_at", comment: "상담 일시" })
  consultAt!: Date;

  @Column({ type: "varchar", name: "short_goal_tags", length: 500, nullable: true, comment: "단기목표 태그 목록" })
  shortGoalTags?: string;

  @Column({ type: "text", name: "short_goal_text", nullable: true, comment: "단기목표 직접입력" })
  shortGoalText?: string;

  @Column({ type: "varchar", name: "long_goal_tags", length: 500, nullable: true, comment: "중장기목표 태그 목록" })
  longGoalTags?: string;

  @Column({ type: "text", name: "long_goal_text", nullable: true, comment: "중장기목표 직접입력" })
  longGoalText?: string;

  @Column({ type: "text", name: "action_plan", nullable: true, comment: "액션 플랜" })
  actionPlan?: string;

  @Column({ type: "text", name: "recommendation", nullable: true, comment: "맞춤 운동 프로그램" })
  recommendation?: string;

  @Column({ type: "uuid", name: "body_report_id", nullable: true })
  bodyReportId?: string;

  @ManyToOne(() => BodyReportEntity)
  @JoinColumn({ name: "body_report_id" })
  bodyReport?: BodyReportEntity;

  @Column({ type: "uuid", name: "precision_report_id", nullable: true })
  precisionReportId?: string;

  @ManyToOne(() => PrecisionReportEntity)
  @JoinColumn({ name: "precision_report_id" })
  precisionReport?: PrecisionReportEntity;

  @Column({ type: "uuid", name: "motion_analysis_id", nullable: true })
  motionAnalysisId?: string;

  @ManyToOne(() => MotionAnalysisEntity)
  @JoinColumn({ name: "motion_analysis_id" })
  motionAnalysis?: MotionAnalysisEntity;

  @Column({ type: "uuid", name: "inbody_data_id", nullable: true })
  inbodyDataId?: string;

  @ManyToOne(() => InbodyDataEntity)
  @JoinColumn({ name: "inbody_data_id" })
  inbodyData?: InbodyDataEntity;

  @Column({
    type: "enum",
    enum: ConsultResultStatus,
    name: "result_status",
    default: ConsultResultStatus.NO_SALE,
    comment: "상담 결과",
  })
  resultStatus!: ConsultResultStatus;
}
