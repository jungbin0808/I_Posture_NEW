import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserEntity } from "./user.entity";
import { CenterNoticeEntity } from "./center-notice.entity";
import { CenterTrainerEntity } from "./center-trainer.entity";
import { SubscriptionEntity } from "./subscription.entity";
import { CenterCapacityPoolEntity } from "./center-capacity-pool.entity";

@Entity({ name: "centers" })
export class CenterEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "센터 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "owner_id", comment: "센터 소유주 회원 ID" })
  ownerId!: string;

  // @OneToOne(() => UserEntity, (user) => user.ownedCenter)
  // @JoinColumn({ name: "owner_id" })
  // owner!: UserEntity;

  @OneToMany(() => CenterNoticeEntity, (notice) => notice.center)
  notices!: CenterNoticeEntity[];

  @OneToMany(() => CenterTrainerEntity, (trainer) => trainer.center)
  trainers!: CenterTrainerEntity[];

  @OneToMany(() => SubscriptionEntity, (subscription) => subscription.center)
  subscriptions!: SubscriptionEntity[];

  @OneToOne(() => CenterCapacityPoolEntity, (pool) => pool.center)
  capacityPool!: CenterCapacityPoolEntity;

  @Column({ type: "varchar", name: "name", length: 100, comment: "센터명" })
  name!: string;

  @Column({ type: "varchar", name: "address", length: 255, nullable: true, comment: "주소" })
  address?: string;

  @Column({ type: "varchar", name: "phone", length: 20, nullable: true, comment: "대표 연락처" })
  phone?: string;

  @Column({ type: "varchar", name: "logo_url", length: 500, nullable: true, comment: "로고 이미지 URL" })
  logoUrl?: string | null;

  @Column({ type: "text", name: "description", nullable: true, comment: "센터 설명" })
  description?: string;
}
