import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { SubscriptionEntity } from "./subscription.entity";
import { SubscriptionScope, SubscriptionTier } from "../../common/enums/subscription.enum";

@Entity({ name: "subscription_plans" })
export class SubscriptionPlanEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "상품 고유 ID" })
  id!: string;

  @Column({ type: "varchar", name: "name", length: 100, comment: "상품명" })
  name!: string;

  @Column({
    type: "enum",
    enum: SubscriptionTier,
    name: "tier",
    default: SubscriptionTier.FREE,
    comment: "구독 등급 (FREE, PRO, PREMIUM, CENTER)",
  })
  tier!: SubscriptionTier;

  @Column({ type: "int", name: "price", comment: "월 가격 (KRW)" })
  price!: number;

  @Column({ type: "bigint", name: "storage_limit", comment: "제공 용량 (bytes 단위)" })
  storageLimit!: string;

  @Column({
    type: "enum",
    enum: SubscriptionScope,
    name: "scope",
    default: SubscriptionScope.PERSONAL,
    comment: "플랜 사용 범위 (개인용/센터용)",
  })
  scope!: SubscriptionScope;

  @Column({ type: "varchar", name: "store_product_id", nullable: true, comment: "인앱 결제용 상품 ID (Store Product ID)" })
  storeProductId?: string;

  @Column({ type: "boolean", name: "is_public", default: true, comment: "판매중 여부" })
  isPublic!: boolean;

  @Column({ type: "varchar", name: "description", length: 255, nullable: true, comment: "상품 설명" })
  description?: string;

  @Column({ type: "int", name: "sale_price", nullable: true, comment: "할인 판매가 (KRW, null이면 할인 없음)" })
  salePrice?: number | null;

  @Column({ type: "boolean", name: "is_trial_available", default: false, comment: "무료체험 가능 여부" })
  isTrialAvailable!: boolean;

  @OneToMany('SubscriptionEntity', 'plan')
  subscriptions!: SubscriptionEntity[];
}
