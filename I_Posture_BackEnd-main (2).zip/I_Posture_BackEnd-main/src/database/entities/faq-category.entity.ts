import { Column, CreateDateColumn, DeleteDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { FaqTargetRole } from "./faq.entity";
import type { FaqEntity } from "./faq.entity";

@Entity({ name: "faq_categories" }) // orderBy 제거
export class FaqCategoryEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "카테고리 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시 (Soft Delete)",
  })
  deletedAt?: Date;

  @Column({ type: "varchar", name: "name", length: 50, comment: "카테고리명" })
  name!: string;

  @Column({ type: "int", name: "sort_order", default: 0, comment: "정렬 순서" })
  sortOrder!: number;

  @Column({ type: "boolean", name: "is_active", default: true, comment: "사용 여부" })
  isActive!: boolean;

  @Column({
    type: "enum",
    enum: FaqTargetRole,
    name: "target_role",
    default: FaqTargetRole.ALL,
    comment: "노출 대상",
  })
  targetRole!: FaqTargetRole;

  @OneToMany("FaqEntity", (faq: FaqEntity) => faq.category)
  faqs!: FaqEntity[];
}
