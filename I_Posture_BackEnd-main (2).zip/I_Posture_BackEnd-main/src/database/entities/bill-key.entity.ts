import { Column, CreateDateColumn, Entity, Index, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { UserEntity } from './user.entity';

export enum BillKeyType {
  CREDIT = 'N',   // 신용카드
  KAKAO = 'K',    // 카카오페이
  NAVER = 'R',    // 네이버페이
}

@Entity({ name: 'bill_keys' })
export class BillKeyEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '빌키 고유 ID' })
  id!: string;

  @Index()
  @Column({ type: 'uuid', name: 'user_id', comment: '사용자 ID' })
  userId!: string;

  @ManyToOne(() => UserEntity)
  @JoinColumn({ name: 'user_id' })
  user!: UserEntity;

  @Column({ type: 'varchar', name: 'bill_key', length: 64, comment: 'KPN 빌키' })
  billKey!: string;

  @Column({ type: 'varchar', name: 'view_card_no', length: 50, nullable: true, comment: '마스킹된 카드번호 (예: 1234-****-****-5678)' })
  viewCardNo?: string;

  @Column({ type: 'varchar', name: 'cust_name', length: 50, nullable: true, comment: '카드 소유주명 (주문자명)' })
  custName?: string;

  @Column({ type: 'varchar', name: 'card_exp', length: 10, nullable: true, comment: '카드 유효기간 (YYMM)' })
  cardExp?: string;

  @Column({ type: 'varchar', name: 'iss_cd', length: 10, nullable: true, comment: '발급사 코드' })
  issCd?: string;

  @Column({ type: 'varchar', name: 'iss_name', length: 50, nullable: true, comment: '발급사명' })
  issName?: string;

  @Column({ type: 'varchar', name: 'check_yn', length: 1, nullable: true, comment: '체크카드 여부 (Y/N/G)' })
  checkYn?: string;

  @Column({ type: 'varchar', name: 'bill_key_type', length: 1, nullable: true, comment: '빌키 타입 (N:신용카드, K:카카오페이, R:네이버페이)' })
  billKeyType?: string;

  @Column({ type: 'tinyint', name: 'is_active', default: true, comment: '사용 가능 여부 (기본 카드 또는 활성 카드)' })
  isActive!: boolean;

  @CreateDateColumn({ type: 'timestamp', name: 'created_at', precision: 3, comment: '등록일시', default: () => 'CURRENT_TIMESTAMP(3)' })
  createdAt!: Date;

  @UpdateDateColumn({ type: 'timestamp', name: 'updated_at', precision: 3, comment: '수정일시', default: () => 'CURRENT_TIMESTAMP(3)', onUpdate: 'CURRENT_TIMESTAMP(3)' })
  updatedAt!: Date;
}
