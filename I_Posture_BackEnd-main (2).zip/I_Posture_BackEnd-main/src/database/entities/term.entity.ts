import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { UserAgreementEntity } from "./user-agreement.entity";

export enum TermType {
  SERVICE = "SERVICE",
  PRIVACY = "PRIVACY",
  MARKETING = "MARKETING",
  THIRD_PARTY = "THIRD_PARTY",
  LOCATION = "LOCATION",
}

@Entity({ name: "terms", orderBy: { created_at: "DESC", id: "ASC" } })
export class TermEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "약관 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @Column({
    type: "enum",
    enum: TermType,
    name: "type",
    comment: "약관 구분 코드",
  })
  type!: TermType;

  @Column({ type: "varchar", name: "title", length: 100, comment: "약관명 (화면 표시용)" })
  title!: string;

  @Column({ type: "text", name: "content", comment: "약관 내용 (HTML)" })
  content!: string;

  @Column({ type: "varchar", name: "version", length: 20, default: "1.0", comment: "약관 버전 문자열" })
  version!: string;

  @Column({ type: "boolean", name: "is_required", default: true, comment: "필수 동의 여부" })
  isRequired!: boolean;

  @Column({ type: "boolean", name: "is_active", default: true, comment: "현재 사용 여부" })
  isActive!: boolean;

  @OneToMany(() => UserAgreementEntity, (agreement) => agreement.term)
  userAgreements!: UserAgreementEntity[];
}
