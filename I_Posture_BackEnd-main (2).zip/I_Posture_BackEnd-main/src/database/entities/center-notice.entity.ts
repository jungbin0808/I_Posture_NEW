import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { CenterEntity } from "./center.entity";
import { UserEntity } from "./user.entity";

export enum CenterNoticeType {
  NOTICE = "NOTICE",
  EVENT = "EVENT",
}

@Entity({ name: "center_notices", orderBy: { created_at: "DESC", id: "ASC" } })
export class CenterNoticeEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "센터 공지사항 ID" })
  id!: string;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: "timestamp",
    name: "deleted_at",
    precision: 3,
    nullable: true,
    comment: "삭제일시",
  })
  deletedAt?: Date;

  @Column({ type: "uuid", name: "center_id", comment: "센터 ID" })
  centerId!: string;

  @ManyToOne(() => CenterEntity, (center) => center.notices)
  @JoinColumn({ name: "center_id" })
  center!: CenterEntity;

  @Column({ type: "uuid", name: "author_id", comment: "작성자 ID" })
  authorId!: string;

  @ManyToOne(() => UserEntity, (user) => user.authoredCenterNotices)
  @JoinColumn({ name: "author_id" })
  author!: UserEntity;

  @Column({ type: "varchar", name: "title", length: 200, comment: "제목" })
  title!: string;

  @Column({ type: "text", name: "content", comment: "내용" })
  content!: string;

  @Column({
    type: "enum",
    enum: CenterNoticeType,
    name: "type",
    default: CenterNoticeType.NOTICE,
    comment: "게시물 유형 (공지/이벤트)",
  })
  type!: CenterNoticeType;

  @Column({ type: "boolean", name: "is_published", default: false, comment: "게시 여부" })
  isPublished!: boolean;

  @Column({ type: "timestamp", name: "published_at", precision: 3, nullable: true, comment: "게시 시작일시" })
  publishedAt?: Date;

  @Column({ type: "int", name: "view_count", default: 0, comment: "조회수" })
  viewCount!: number;
}
