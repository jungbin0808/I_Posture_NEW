import { Column, CreateDateColumn, DeleteDateColumn, Entity, OneToMany, OneToOne, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';
import { SnsAccountEntity } from './sns-account.entity';
import { TrainerUserEntity } from './trainer-user.entity';
import { CenterTrainerEntity } from './center-trainer.entity';
import { CenterNoticeEntity } from './center-notice.entity';
import { TrainerCapacityPoolEntity } from './trainer-capacity-pool.entity';
import { MemberStorageEntity } from './member-storage.entity';
import { StorageAllocationEntity } from './storage-allocation.entity';
import { FileEntity } from './file.entity';
import { MemberIdentityLinkEntity } from './member-identity-link.entity';
import { TrainerLinkRequestEntity } from './trainer-link-request.entity';
import { UserAgreementEntity } from './user-agreement.entity';
import { SequenceEntity } from './sequence.entity';
import { ScheduleGroupEntity } from './schedule-group.entity';
import { ScheduleGroupMemberEntity } from './schedule-group-member.entity';
import { ScheduleEntity } from './schedule.entity';
import { ScheduleBookingEntity } from './schedule-booking.entity';
import { SubscriptionEntity } from './subscription.entity';
import { PaymentEntity } from './payment.entity';
import { BodyReportEntity } from './body-report.entity';
import { PrecisionReportEntity } from './precision-report.entity';
import { MotionAnalysisEntity } from './motion-analysis.entity';
import { InbodyDataEntity } from './inbody-data.entity';
import { ConsultationLogEntity } from './consultation-log.entity';
import { WorkoutLogEntity } from './workout-log.entity';
import { FoodLogEntity } from './food-log.entity';
import { PointHistoryEntity } from './point-history.entity';
import { AdminPointLogEntity } from './admin-point-log.entity';
import { ReportComparisonEntity } from './report-comparison.entity';
import type { CenterEntity } from './center.entity';

export enum Gender {
  MALE = 'MALE',
  FEMALE = 'FEMALE',
  NONE = 'NONE',
}
export enum MemberType {
  APP = 'APP',
  MANAGED = 'MANAGED',
}
export enum UserType {
  ADMIN = 'ADMIN',
  CENTER = 'CENTER',
  C_TRAINER = 'C_TRAINER',
  F_TRAINER = 'F_TRAINER',
  MEMBER = 'MEMBER',
}
export enum AccountStatus {
  ACTIVE = 'ACTIVE',
  BANNED = 'BANNED',
  WITHDRAWAL = 'WITHDRAWAL',
}
export enum PaymentStatus {
  UNPAID = 'UNPAID',
  PAID = 'PAID',
  EXPIRED = 'EXPIRED',
}

@Entity({ name: 'users' })
export class UserEntity {
  @PrimaryGeneratedColumn('uuid', { name: 'id', comment: '회원 고유 ID' })
  id!: string;

  @Column({
    type: 'varchar',
    name: 'user_id',
    length: 100,
    unique: true,
    comment: '로그인 아이디. F_TRAINER/CENTER는 실제 로그인 ID, MANAGED/MEMBER는 unique 제약 충족용 내부 식별값(화면 노출 금지)',
  })
  userId!: string;

  @OneToMany(() => SnsAccountEntity, (snsAccount) => snsAccount.user)
  snsAccounts!: SnsAccountEntity[];

  @OneToMany(() => TrainerUserEntity, (membership) => membership.trainer)
  managedMemberships!: TrainerUserEntity[];

  @OneToMany(() => TrainerUserEntity, (membership) => membership.member)
  trainerMemberships!: TrainerUserEntity[];

  @OneToMany(() => CenterTrainerEntity, (affiliation) => affiliation.trainer)
  centerAffiliations!: CenterTrainerEntity[];

  @OneToMany(() => CenterNoticeEntity, (notice) => notice.author)
  authoredCenterNotices!: CenterNoticeEntity[];

  @OneToOne(() => TrainerCapacityPoolEntity, (pool) => pool.trainer)
  capacityPool!: TrainerCapacityPoolEntity;

  @OneToOne(() => MemberStorageEntity, (storage) => storage.member)
  memberStorage!: MemberStorageEntity;

  @OneToMany(() => StorageAllocationEntity, (allocation) => allocation.member)
  storageAllocations!: StorageAllocationEntity[];

  @OneToMany(() => FileEntity, (file) => file.member)
  files!: FileEntity[];

  @OneToMany(() => FileEntity, (file) => file.uploader)
  uploadedFiles!: FileEntity[];

  @OneToMany(() => MemberIdentityLinkEntity, (link) => link.appMember)
  appIdentityLinks!: MemberIdentityLinkEntity[];

  @OneToMany(() => MemberIdentityLinkEntity, (link) => link.managedMember)
  managedIdentityLinks!: MemberIdentityLinkEntity[];

  @OneToMany(() => TrainerLinkRequestEntity, (request) => request.member)
  sentLinkRequestsAsMember!: TrainerLinkRequestEntity[];

  @OneToMany(() => TrainerLinkRequestEntity, (request) => request.trainer)
  receivedLinkRequestsAsTrainer!: TrainerLinkRequestEntity[];

  @OneToMany(() => UserAgreementEntity, (agreement) => agreement.user)
  agreements!: UserAgreementEntity[];

  @OneToMany(() => SequenceEntity, (sequence) => sequence.trainer)
  sequences!: SequenceEntity[];

  @OneToMany(() => ScheduleGroupEntity, (group) => group.trainer)
  scheduleGroups!: ScheduleGroupEntity[];

  @OneToMany(() => ScheduleGroupMemberEntity, (member) => member.user)
  scheduleGroupMemberships!: ScheduleGroupMemberEntity[];

  @OneToMany(() => ScheduleEntity, (schedule) => schedule.trainer)
  schedules!: ScheduleEntity[];

  @OneToMany(() => ScheduleBookingEntity, (booking) => booking.user)
  bookings!: ScheduleBookingEntity[];

  @OneToMany(() => SubscriptionEntity, (subscription) => subscription.user)
  subscriptions!: SubscriptionEntity[];

  @OneToMany(() => PaymentEntity, (payment) => payment.user)
  payments!: PaymentEntity[];

  @OneToMany(() => BodyReportEntity, (report) => report.user)
  bodyReports!: BodyReportEntity[];

  @OneToMany(() => BodyReportEntity, (report) => report.trainer)
  createdBodyReports!: BodyReportEntity[];

  @OneToMany(() => PrecisionReportEntity, (report) => report.user)
  precisionReports!: PrecisionReportEntity[];

  @OneToMany(() => PrecisionReportEntity, (report) => report.trainer)
  createdPrecisionReports!: PrecisionReportEntity[];

  @OneToMany(() => PrecisionReportEntity, (report) => report.trainer)
  managedPrecisionReports!: PrecisionReportEntity[];

  @OneToMany(() => MotionAnalysisEntity, (analysis) => analysis.user)
  motionAnalyses!: MotionAnalysisEntity[];

  @OneToMany(() => MotionAnalysisEntity, (analysis) => analysis.trainer)
  createdMotionAnalyses!: MotionAnalysisEntity[];

  @OneToMany(() => InbodyDataEntity, (data) => data.user)
  inbodyData!: InbodyDataEntity[];

  @OneToMany(() => InbodyDataEntity, (data) => data.trainer)
  createdInbodyData!: InbodyDataEntity[];

  @OneToMany(() => ConsultationLogEntity, (log) => log.user)
  consultationLogs!: ConsultationLogEntity[];

  @OneToMany(() => ConsultationLogEntity, (log) => log.trainer)
  createdConsultationLogs!: ConsultationLogEntity[];

  @OneToMany(() => WorkoutLogEntity, (log) => log.user)
  workoutLogs!: WorkoutLogEntity[];

  @OneToMany(() => WorkoutLogEntity, (log) => log.trainer)
  createdWorkoutLogs!: WorkoutLogEntity[];

  @OneToMany(() => FoodLogEntity, (log) => log.user)
  foodLogs!: FoodLogEntity[];

  @OneToMany(() => PointHistoryEntity, (history) => history.user)
  pointHistories!: PointHistoryEntity[];

  @OneToMany(() => AdminPointLogEntity, (log) => log.admin)
  createdAdminPointLogs!: AdminPointLogEntity[];

  @OneToMany(() => AdminPointLogEntity, (log) => log.targetUser)
  receivedAdminPointLogs!: AdminPointLogEntity[];

  @OneToMany(() => ReportComparisonEntity, (comparison) => comparison.user)
  reportComparisons!: ReportComparisonEntity[];


  // @OneToOne('CenterEntity', (center: CenterEntity) => center.owner)
  // ownedCenter?: CenterEntity; 
  
  @CreateDateColumn({
    type: 'timestamp',
    name: 'created_at',
    precision: 3,
    comment: '생성일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: 'timestamp',
    name: 'updated_at',
    precision: 3,
    comment: '수정일시',
    default: () => 'CURRENT_TIMESTAMP(3)',
    onUpdate: 'CURRENT_TIMESTAMP(3)',
  })
  updatedAt!: Date;

  @DeleteDateColumn({
    type: 'timestamp',
    name: 'deleted_at',
    precision: 3,
    nullable: true,
    comment: '삭제일시 (Soft Delete)',
  })
  deletedAt?: Date;

  @Column({ type: 'varchar', name: 'email', length: 255, comment: '이메일(로그인 ID)' })
  email!: string;

  @Column({ type: 'varchar', name: 'password', length: 255, nullable: true, comment: '비밀번호(소셜로그인 시 NULL)' })
  password?: string;

  @Column({ type: 'varchar', name: 'name', length: 50, comment: '회원명 (실명)' })
  name!: string;

  @Column({ type: 'varchar', name: 'phone', length: 65, nullable: true, comment: '휴대폰 번호 (APP 회원은 선택)' })
  phone?: string;

  @Column({ type: 'date', name: 'birth_date', nullable: true, comment: '생년월일' })
  birthDate?: string;

  @Column({ type: 'varchar', name: 'address', length: 255, nullable: true, comment: '주소' })
  address?: string;

  @Column({
    type: 'enum',
    enum: Gender,
    name: 'gender',
    default: Gender.NONE,
    comment: '성별',
  })
  gender!: Gender;

  @Column({ type: 'decimal', name: 'height', precision: 5, scale: 1, nullable: true, comment: '신장(cm)' })
  height?: number;

  @Column({ type: 'decimal', name: 'weight', precision: 5, scale: 1, nullable: true, comment: '체중(kg)' })
  weight?: number;

  @Column({
    type: 'enum',
    enum: MemberType,
    name: 'member_type',
    default: MemberType.APP,
    comment: '회원 유형(APP 회원 A / 트레이너 관리용 C)',
  })
  memberType!: MemberType;

  @Column({
    type: 'enum',
    enum: UserType,
    name: 'user_type',
    default: UserType.MEMBER,
    comment: '권한 구분 (관리자/센터계정/센터소속트레이너/개인트레이너/일반회원)',
  })
  userType!: UserType;

  @Column({
    type: 'enum',
    enum: AccountStatus,
    name: 'account_status',
    default: AccountStatus.ACTIVE,
    comment: '계정상태',
  })
  accountStatus!: AccountStatus;

  @Column({
    type: 'enum',
    enum: PaymentStatus,
    name: 'payment_status',
    default: PaymentStatus.UNPAID,
    comment: '결제상태 (개인 Pro 등)',
  })
  paymentStatus!: PaymentStatus;

  @Column({ type: 'boolean', name: 'offline_payment_status', default: false, comment: '오프라인 결제 여부 (센터/트레이너가 회원 결제 확인용)' })
  offlinePaymentStatus!: boolean;

  @Column({ type: 'varchar', name: 'device_id', length: 255, nullable: true, comment: '푸시용 디바이스ID' })
  deviceId?: string;

  @Column({ type: 'varchar', name: 'fcm_token', length: 512, nullable: true, comment: 'Firebase FCM 디바이스 토큰' })
  fcmToken?: string;

  @Column({ type: 'varchar', name: 'affiliation_name', length: 100, nullable: true, comment: '트레이너 개인 소속명(상호, 센터 미소속일 때 노출용)' })
  affiliationName?: string;

  @Column({ type: 'int', name: 'total_points', default: 0, comment: '보유 적립금 총액' })
  totalPoints!: number;

  @Column({ type: 'boolean', name: 'notification_event_marketing', default: true, comment: '이벤트/프로모션 마케팅 푸시알림' })
  notificationEventMarketing!: boolean;

  @Column({ type: 'boolean', name: 'notification_my_question', default: true, comment: '내가 올린 질문 알림' })
  notificationMyQuestion!: boolean;

  @Column({ type: 'boolean', name: 'notification_challenge_result', default: true, comment: '챌린지 신청 결과 알림' })
  notificationChallengeResult!: boolean;

  @Column({ type: 'boolean', name: 'notification_subscription_usage', default: true, comment: '이용권 사용량 완료 알림' })
  notificationSubscriptionUsage!: boolean;

  @Column({ type: 'boolean', name: 'notification_my_answer_accepted', default: true, comment: '내가 올린 답변 채택 알림' })
  notificationMyAnswerAccepted!: boolean;

  @Column({ type: 'boolean', name: 'notification_point_settlement', default: true, comment: '적립금 정산알림' })
  notificationPointSettlement!: boolean;

  @Column({ type: 'boolean', name: 'notification_all', default: true, comment: 'USER APP 전체 알림 받기 마스터 토글' })
  notificationAll!: boolean;

  @Column({ type: 'boolean', name: 'notification_body_measurement_cycle', default: true, comment: 'USER APP 체형·인바디 측정 주기 알림' })
  notificationBodyMeasurementCycle!: boolean;

  @Column({ type: 'boolean', name: 'notification_workout_routine', default: true, comment: 'USER APP 운동 루틴 알림' })
  notificationWorkoutRoutine!: boolean;

  @Column({ type: 'boolean', name: 'notification_challenge_participation', default: true, comment: 'USER APP 챌린지 참여 및 마감 알림' })
  notificationChallengeParticipation!: boolean;

  @Column({ type: 'boolean', name: 'notification_diet_feedback', default: true, comment: 'USER APP 식단 피드백 및 작성 알림' })
  notificationDietFeedback!: boolean;

  @Column({ type: 'boolean', name: 'notification_trainer_report', default: true, comment: 'USER APP 트레이너 분석 리포트 알림' })
  notificationTrainerReport!: boolean;

  @Column({ type: 'boolean', name: 'notification_notice', default: true, comment: 'USER APP 공지사항 알림' })
  notificationNotice!: boolean;
}
