// This file is deprecated. Use food-log.entity.ts instead.
// import { Column, CreateDateColumn, DeleteDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
// import { UserEntity } from "./user.entity";

// export enum DietEvaluation {
//   EXCELLENT = "EXCELLENT",
//   GOOD = "GOOD",
//   FAIR = "FAIR",
//   POOR = "POOR",
// }

// @Entity({ name: "diet_logs", orderBy: { log_date: "DESC", created_at: "DESC" } })
// export class DietLogEntity {
//   @PrimaryGeneratedColumn("uuid", { name: "id", comment: "일지 ID" })
//   id!: string;

//   @CreateDateColumn({
//     type: "timestamp",
//     name: "created_at",
//     precision: 3,
//     comment: "작성일시",
//     default: () => "CURRENT_TIMESTAMP(3)",
//   })
//   createdAt!: Date;

//   @UpdateDateColumn({
//     type: "timestamp",
//     name: "updated_at",
//     precision: 3,
//     comment: "수정일시",
//     default: () => "CURRENT_TIMESTAMP(3)",
//   })
//   updatedAt!: Date;

//   @DeleteDateColumn({
//     type: "timestamp",
//     name: "deleted_at",
//     precision: 3,
//     nullable: true,
//     comment: "삭제일시",
//   })
//   deletedAt?: Date;

//   @Column({ type: "uuid", name: "user_id", comment: "작성 회원 ID" })
//   userId!: string;

//   @ManyToOne(() => UserEntity, (user) => user.dietLogs)
//   @JoinColumn({ name: "user_id" })
//   user!: UserEntity;

//   @Column({ type: "uuid", name: "trainer_id", comment: "담당 트레이너 ID" })
//   trainerId!: string;

//   @ManyToOne(() => UserEntity, (user) => user.createdDietLogs)
//   @JoinColumn({ name: "trainer_id" })
//   trainer!: UserEntity;

//   @Column({ type: "date", name: "log_date", comment: "식단 날짜" })
//   logDate!: string;

//   @Column({ type: "json", name: "meals", nullable: true, comment: "끼니별 메뉴명 데이터" })
//   meals?: any;

//   @Column({ type: "varchar", name: "user_memo", length: 255, nullable: true, comment: "회원 메모 (종합)" })
//   userMemo?: string;

//   @Column({ type: "text", name: "trainer_comment", nullable: true, comment: "트레이너 코멘트" })
//   trainerComment?: string;

//   @Column({
//     type: "enum",
//     enum: DietEvaluation,
//     name: "evaluation",
//     default: DietEvaluation.GOOD,
//     comment: "종합 평가",
//   })
//   evaluation!: DietEvaluation;
// }
