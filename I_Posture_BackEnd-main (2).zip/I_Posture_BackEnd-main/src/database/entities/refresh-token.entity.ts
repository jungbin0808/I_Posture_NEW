import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn, } from "typeorm";
import { UserEntity } from "./user.entity";

@Entity({ name: "refresh_tokens", orderBy: { created_at: "DESC", id: "ASC" } })
export class RefreshTokenEntity {
  @PrimaryGeneratedColumn("uuid", { name: "id", comment: "리프레시 토큰 ID" })
  id!: string;

  @ManyToOne(() => UserEntity, { onDelete: "CASCADE" })
  user!: UserEntity;

  @Column({ type: "uuid", name: "user_id", comment: "사용자 ID" })
  userId!: string;

  @Column({ type: "uuid", name: "jti", comment: "JWT ID" })
  jti!: string;

  @Column({ type: "text", name: "token", comment: "리프레시 토큰(원문 또는 해시)" })
  token!: string;

  @Column({ type: "timestamp", name: "expires_at", precision: 3, comment: "만료 일시", })
  expiresAt!: Date;

  @Column({ type: "boolean", name: "revoked", default: false, comment: "무효화 여부", })
  revoked!: boolean;

  @CreateDateColumn({
    type: "timestamp",
    name: "created_at",
    precision: 3,
    comment: "생성일시",
    default: () => "CURRENT_TIMESTAMP(3)",
  })
  createdAt!: Date;

  @UpdateDateColumn({
    type: "timestamp",
    name: "updated_at",
    precision: 3,
    comment: "수정일시",
    default: () => "CURRENT_TIMESTAMP(3)",
    onUpdate: "CURRENT_TIMESTAMP(3)",
  })
  updatedAt!: Date;
}
