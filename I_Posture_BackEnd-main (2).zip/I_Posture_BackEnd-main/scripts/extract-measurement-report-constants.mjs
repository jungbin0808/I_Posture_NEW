/**
 * Extracts private static/instance readonly data blocks from measurement-report.service.ts
 * and writes measurement-report.static-data.constants.ts (lossless byte copy of values).
 */
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const servicePath = path.join(
  ROOT,
  'src/modules/measurement-report/measurement-report.service.ts',
);
const outPath = path.join(
  ROOT,
  'src/modules/measurement-report/measurement-report.static-data.constants.ts',
);

const src = fs.readFileSync(servicePath, 'utf8');
const lines = src.split('\n');

const BLOCK_START =
  /^\s{2}private (static )?readonly ([A-Z0-9_]+)(?::[^=]+)? =/;

/** @type {{ name: string; start: number; end: number; static: boolean }[]} */
const blocks = [];

for (let i = 0; i < lines.length; i++) {
  const m = lines[i].match(BLOCK_START);
  if (!m) continue;
  const name = m[2];
  const isStatic = !!m[1];
  const start = i;
  let end = i;
  const opener = lines[i].trimEnd().slice(-1);
  const closeChar = opener === '[' ? ']' : '}';
  let depth = 0;
  let started = false;
  for (let j = i; j < lines.length; j++) {
    const line = lines[j];
    for (const ch of line) {
      if (ch === '{' || ch === '[') {
        depth++;
        started = true;
      } else if (ch === '}' || ch === ']') {
        depth--;
      }
    }
    end = j;
    if (started && depth === 0 && j > i) break;
  }
  blocks.push({ name, start, end, static: isStatic });
}

// Skip blocks already in measurement-report.constants.ts
const SKIP = new Set(['TOTAL_SCORE_STAGE_RULES', 'MUSCLE_IMBALANCE_MAP', 'OHT_CASE_DB']);

const extracted = blocks.filter((b) => !SKIP.has(b.name));

let out = `// Auto-extracted from measurement-report.service.ts — do not hand-edit values.\n\n`;

for (const b of extracted) {
  const slice = lines.slice(b.start, b.end + 1);
  const header = slice[0].replace(
    /^\s{2}private (static )?readonly /,
    'export const ',
  );
  slice[0] = header;
  out += slice.join('\n') + '\n\n';
}

fs.writeFileSync(outPath, out);

const manifestPath = path.join(ROOT, 'scripts/measurement-report-constants-manifest.json');
fs.writeFileSync(
  manifestPath,
  JSON.stringify(
    {
      extracted: extracted.map((b) => ({
        name: b.name,
        lines: [b.start + 1, b.end + 1],
        static: b.static,
      })),
      skipped: [...SKIP],
    },
    null,
    2,
  ),
);

console.log(`Wrote ${extracted.length} blocks to ${outPath}`);
console.log(`Manifest: ${manifestPath}`);
