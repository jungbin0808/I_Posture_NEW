#!/bin/bash
set -euo pipefail

# ============================================
# iPosture Backend - Production Deploy Script
# ============================================

APP_DIR="/home/ubuntu/iposture-backend"
CONTAINER_NAME="iposture-backend"
IMAGE_NAME="iposture-backend"
IMAGE_TAG="latest"
PORT=3000
ENV_FILE=".env.production"
FIREBASE_CERT_DIR="$APP_DIR/certs/firebase"
FIREBASE_CERT_FILE="$FIREBASE_CERT_DIR/firebase-certification.json"
FIREBASE_CERT_IN_CONTAINER="/usr/src/app/certs/firebase/firebase-certification.json"
GIT_PULL="${GIT_PULL:-false}"
PRUNE_BUILD_CACHE="${PRUNE_BUILD_CACHE:-true}"
LOG_BACKUP_ROOT="$APP_DIR/logs/container"
LOG_RETENTION_DAYS="${LOG_RETENTION_DAYS:-90}"

FULL_IMAGE="${IMAGE_NAME}:${IMAGE_TAG}"

echo "============================================"
echo " iPosture Backend Deploy"
echo "============================================"

echo "📂 이동: $APP_DIR"
cd "$APP_DIR" || { echo "❌ 디렉토리를 찾을 수 없습니다: $APP_DIR"; exit 1; }

if [ ! -f "$ENV_FILE" ]; then
  echo "❌ 환경 파일이 없습니다: $APP_DIR/$ENV_FILE"
  echo "   서버에 .env.production 파일을 생성해 주세요."
  exit 1
fi

HAS_FIREBASE_JSON_ENV=false
if grep -q '^FIREBASE_SERVICE_ACCOUNT_JSON=' "$ENV_FILE" 2>/dev/null; then
  HAS_FIREBASE_JSON_ENV=true
fi

if [ -f "$FIREBASE_CERT_FILE" ]; then
  echo "✅ Firebase 인증서: $FIREBASE_CERT_FILE"
elif [ "$HAS_FIREBASE_JSON_ENV" = true ]; then
  echo "✅ Firebase 인증서: .env.production (FIREBASE_SERVICE_ACCOUNT_JSON)"
else
  echo "⚠️  Firebase 인증서 없음"
  echo "   기대 경로: $FIREBASE_CERT_FILE"
  echo "   FCM 푸시가 동작하지 않습니다."
fi

if [ "$GIT_PULL" = "true" ]; then
  echo "⬇️  Git Pull..."
  git pull
fi

# 컨테이너 삭제 전 로그 백업 (docker rm 시 stdout 로그 소실 방지)
if docker ps -a --format '{{.Names}}' | grep -qx "$CONTAINER_NAME"; then
  LOG_BACKUP_DIR="$LOG_BACKUP_ROOT/$(date +%Y-%m-%d)"
  mkdir -p "$LOG_BACKUP_DIR"
  BACKUP_FILE="$LOG_BACKUP_DIR/${CONTAINER_NAME}-$(date +%H%M%S).log"

  echo "📦 컨테이너 로그 백업: $BACKUP_FILE"
  docker logs "$CONTAINER_NAME" > "$BACKUP_FILE" 2>&1 || true

  if [ -s "$BACKUP_FILE" ]; then
    gzip -f "$BACKUP_FILE"
    echo "   → $(du -h "${BACKUP_FILE}.gz" | cut -f1) ${BACKUP_FILE}.gz"
  else
    rm -f "$BACKUP_FILE"
    echo "   → 로그 없음 (빈 파일 삭제)"
  fi

  echo "🧹 ${LOG_RETENTION_DAYS}일 지난 로그 백업 삭제..."
  find "$LOG_BACKUP_ROOT" -type f -name '*.log.gz' -mtime +"$LOG_RETENTION_DAYS" -delete 2>/dev/null || true
  find "$LOG_BACKUP_ROOT" -type f -name '*.log' -mtime +"$LOG_RETENTION_DAYS" -delete 2>/dev/null || true
  find "$LOG_BACKUP_ROOT" -type d -empty -delete 2>/dev/null || true
else
  echo "ℹ️  기존 컨테이너 없음 — 로그 백업 스킵"
fi

echo "🛑 기존 컨테이너 중지 및 삭제..."
docker stop "$CONTAINER_NAME" 2>/dev/null || true
docker rm "$CONTAINER_NAME" 2>/dev/null || true

echo "🗑️  이전 앱 이미지 삭제 (재빌드 전)..."
# 컨테이너를 지운 뒤에는 latest 태그 이미지가 dangling 으로 남기 쉬움 → 미리 제거
docker rmi "$FULL_IMAGE" 2>/dev/null || true

echo "🏗️  Docker 이미지 빌드..."
docker build -t "$FULL_IMAGE" .

echo "🚀 새 컨테이너 실행..."
DOCKER_RUN_ARGS=(
  -d
  --name "$CONTAINER_NAME"
  -p "${PORT}:3000"
  --env-file "$ENV_FILE"
  -e NODE_ENV=production
  --restart unless-stopped
)

# certs/ 는 .gitignore — 서버 호스트 경로를 컨테이너에 마운트
if [ -f "$FIREBASE_CERT_FILE" ]; then
  DOCKER_RUN_ARGS+=(-v "$APP_DIR/certs:/usr/src/app/certs:ro")
  DOCKER_RUN_ARGS+=(-e "FIREBASE_SERVICE_ACCOUNT_PATH=$FIREBASE_CERT_IN_CONTAINER")
fi

docker run "${DOCKER_RUN_ARGS[@]}" "$FULL_IMAGE"

echo ""
echo "🧹 배포 후 Docker 찌꺼기 정리..."

# dangling 이미지 — rebuild 시 이전 latest 가 <none> 으로 남는 것
docker image prune -f

# 중지된 컨테이너
docker container prune -f

# 빌드 캐시 (디스크 대부분을 차지하는 경우 많음)
if [ "$PRUNE_BUILD_CACHE" = "true" ]; then
  docker builder prune -f --filter "until=24h"
fi

echo ""
echo "📊 현재 Docker 디스크 사용량:"
docker system df

echo ""
echo "✅ 배포 완료!"
echo "   URL  : http://localhost:${PORT}"
echo "   로그 : docker logs -f ${CONTAINER_NAME}"
echo "   백업 : ${LOG_BACKUP_ROOT}/YYYY-MM-DD/"
echo "   상태 : docker ps --filter name=${CONTAINER_NAME}"
