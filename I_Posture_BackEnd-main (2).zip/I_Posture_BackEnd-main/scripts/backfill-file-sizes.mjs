/**
 * files.size 가 0인 레코드를 S3 HeadObject 또는 file_url HTTP HEAD로 백필합니다.
 *
 * Usage:
 *   node scripts/backfill-file-sizes.mjs
 *   node scripts/backfill-file-sizes.mjs --member-id=<uuid>
 *   node scripts/backfill-file-sizes.mjs --dry-run
 */
import { config as loadEnv } from 'dotenv';
import { existsSync } from 'fs';
import { resolve } from 'path';

if (existsSync(resolve('.env.local'))) {
  loadEnv({ path: '.env.local' });
} else {
  loadEnv();
}
import mysql from 'mysql2/promise';
import { HeadObjectCommand, S3Client } from '@aws-sdk/client-s3';

const args = process.argv.slice(2);
const dryRun = args.includes('--dry-run');
const memberIdArg = args.find((arg) => arg.startsWith('--member-id='));
const memberId = memberIdArg ? memberIdArg.split('=')[1] : null;

const region = process.env.AWS_REGION ?? process.env.AWS_S3_REGION ?? 'ap-northeast-2';
const accessKeyId = process.env.AWS_ACCESS_KEY_ID ?? process.env.AWS_S3_ACCESS_KEY_ID;
const secretAccessKey = process.env.AWS_SECRET_ACCESS_KEY ?? process.env.AWS_S3_SECRET_ACCESS_KEY;
const defaultBucket = process.env.AWS_S3_BUCKET;

const s3 = accessKeyId && secretAccessKey
  ? new S3Client({
    region,
    credentials: { accessKeyId, secretAccessKey },
  })
  : null;

const connection = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

const whereClause = memberId
  ? `WHERE member_id = ?
     AND (size IS NULL OR size = 0)
     AND ((s3_key IS NOT NULL AND s3_key <> '') OR (file_url IS NOT NULL AND file_url <> ''))`
  : `WHERE (size IS NULL OR size = 0)
     AND ((s3_key IS NOT NULL AND s3_key <> '') OR (file_url IS NOT NULL AND file_url <> ''))`;
const params = memberId ? [memberId] : [];

const [rows] = await connection.query(
  `SELECT id, s3_key AS s3Key, file_url AS fileUrl, member_id AS memberId
   FROM files ${whereClause}
   ORDER BY created_at ASC`,
  params,
);

console.log(`Target files: ${rows.length}${dryRun ? ' (dry-run)' : ''}`);
if (!s3) {
  console.log('AWS credentials not set — using HTTP HEAD on file_url fallback.');
}

let updated = 0;
let failed = 0;

function parseS3Location(fileUrl, s3Key) {
  const keyFromDb = s3Key?.trim() ? s3Key.trim() : null;

  if (!fileUrl) {
    return defaultBucket && keyFromDb ? { bucket: defaultBucket, key: keyFromDb } : null;
  }

  try {
    const url = new URL(fileUrl);
    const host = url.hostname;
    const pathname = decodeURIComponent(url.pathname.replace(/^\//, ''));

    if (host.includes('.s3.') || host.includes('.s3-')) {
      const bucket = host.split('.s3')[0];
      return { bucket, key: keyFromDb ?? pathname };
    }

    if (host.startsWith('s3.') || host === 's3.amazonaws.com') {
      const [bucket, ...rest] = pathname.split('/');
      return { bucket, key: keyFromDb ?? rest.join('/') };
    }

    if (defaultBucket && keyFromDb) {
      return { bucket: defaultBucket, key: keyFromDb };
    }
  } catch {
    return defaultBucket && keyFromDb ? { bucket: defaultBucket, key: keyFromDb } : null;
  }

  return defaultBucket && keyFromDb ? { bucket: defaultBucket, key: keyFromDb } : null;
}

async function fetchSizeViaHttp(fileUrl) {
  const response = await fetch(fileUrl, { method: 'HEAD' });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  const contentLength = Number(response.headers.get('content-length') ?? 0);
  return contentLength;
}

async function fetchSizeViaS3(bucket, key) {
  const response = await s3.send(new HeadObjectCommand({ Bucket: bucket, Key: key }));
  return Number(response.ContentLength ?? 0);
}

async function resolveFileSize(row) {
  const location = parseS3Location(row.fileUrl, row.s3Key);

  if (s3 && location?.bucket && location?.key) {
    try {
      const sizeBytes = await fetchSizeViaS3(location.bucket, location.key);
      if (sizeBytes > 0) {
        return sizeBytes;
      }
    } catch (error) {
      if (!row.fileUrl) {
        throw error;
      }
    }
  }

  if (row.fileUrl) {
    return fetchSizeViaHttp(row.fileUrl);
  }

  throw new Error('Unable to resolve file size');
}

for (const row of rows) {
  try {
    const sizeBytes = await resolveFileSize(row);

    if (sizeBytes <= 0) {
      console.warn(`Skip ${row.id}: resolved size is 0`);
      failed += 1;
      continue;
    }

    if (!dryRun) {
      await connection.query('UPDATE files SET size = ? WHERE id = ?', [sizeBytes, row.id]);
    }

    updated += 1;
    console.log(`${dryRun ? '[dry-run] ' : ''}Updated ${row.id} (${row.memberId}) -> ${sizeBytes} bytes`);
  } catch (error) {
    failed += 1;
    console.error(`Failed ${row.id} (${row.s3Key}):`, error.message ?? error);
  }
}

await connection.end();

console.log(`Done. updated=${updated}, failed=${failed}`);
