/**
 * Lossless migration: static data from measurement-report.service.ts → static-data.constants.ts
 * Line detection uses git HEAD structure (private readonly declarations).
 */
import fs from 'fs';
import path from 'path';

const ROOT = path.resolve(import.meta.dirname, '..');
const servicePath = path.join(
  ROOT,
  'src/modules/measurement-report/measurement-report.service.ts',
);
const staticDataPath = path.join(
  ROOT,
  'src/modules/measurement-report/measurement-report.static-data.constants.ts',
);
const barrelPath = path.join(
  ROOT,
  'src/modules/measurement-report/measurement-report.constants.ts',
);

const SKIP = new Set(['TOTAL_SCORE_STAGE_RULES', 'MUSCLE_IMBALANCE_MAP', 'OHT_CASE_DB']);

const lines = fs.readFileSync(servicePath, 'utf8').split('\n');

const DECL_RE = /^\s{2}private (static )?readonly ([A-Z0-9_]+)/;

/** @type {{ name: string; start: number; end: number }[]} */
const blocks = [];

for (let i = 0; i < lines.length; i++) {
  const m = lines[i].match(DECL_RE);
  if (!m) continue;
  const name = m[2];
  if (SKIP.has(name)) {
    blocks.push({ name, start: i, end: findBlockEnd(lines, i), skipExport: true });
    continue;
  }
  blocks.push({ name, start: i, end: findBlockEnd(lines, i), skipExport: false });
}

function findBlockEnd(lines, startIdx) {
  const first = lines[startIdx];
  const trimmed = first.trimEnd();
  // single-line: private readonly X = 'url';
  if (trimmed.endsWith(';') && !trimmed.includes('= {') && !trimmed.includes('= [')) {
    return startIdx;
  }
  // url on next line
  if (
    (trimmed.endsWith('=') || trimmed.endsWith('= ')) &&
    !trimmed.includes('{') &&
    !trimmed.includes('[')
  ) {
    for (let j = startIdx + 1; j < lines.length; j++) {
      if (lines[j].trimEnd().endsWith(';')) return j;
    }
  }
  let depth = 0;
  let started = false;
  for (let j = startIdx; j < lines.length; j++) {
    for (const ch of lines[j]) {
      if (ch === '{' || ch === '[') {
        depth++;
        started = true;
      } else if (ch === '}' || ch === ']') {
        depth--;
      }
    }
    if (started && depth === 0 && j > startIdx) return j;
  }
  throw new Error(`Could not find end for block at line ${startIdx + 1}: ${first}`);
}

let out = '// Static report data extracted from measurement-report.service.ts\n\n';
const exportedNames = [];

for (const b of blocks) {
  if (b.skipExport) continue;
  const slice = lines.slice(b.start, b.end + 1);
  slice[0] = slice[0].replace(/^\s{2}private (static )?readonly /, 'export const ');
  out += slice.join('\n') + '\n\n';
  exportedNames.push(b.name);
}

fs.writeFileSync(staticDataPath, out);

const sorted = [...blocks].sort((a, b) => b.start - a.start);
let newLines = [...lines];
for (const b of sorted) {
  newLines.splice(b.start, b.end - b.start + 1);
}
fs.writeFileSync(servicePath, newLines.join('\n'));

let barrel = fs.readFileSync(barrelPath, 'utf8');
if (!barrel.includes("export * from './measurement-report.static-data.constants'")) {
  barrel = barrel.trimEnd() + "\n\nexport * from './measurement-report.static-data.constants';\n";
  fs.writeFileSync(barrelPath, barrel);
}

const fromConstants = [
  'TOTAL_SCORE_STAGE_RULES',
  'MUSCLE_IMBALANCE_MAP',
  'OHT_CASE_DB',
  ...exportedNames,
];
const uniqueExports = [...new Set(fromConstants)];

let service = fs.readFileSync(servicePath, 'utf8');
const importBlock = `import {\n  ${uniqueExports.join(',\n  ')},\n} from './measurement-report.constants';`;

if (/from '\.\/measurement-report\.constants'/.test(service)) {
  service = service.replace(
    /import \{[^}]+\} from '\.\/measurement-report\.constants';/s,
    importBlock,
  );
} else {
  service = service.replace(
    /(from '\.\.\/consultation-log\/action-plan\.helper';)\n/,
    `$1\n${importBlock}\n`,
  );
}

for (const name of uniqueExports) {
  service = service.replace(
    new RegExp(`MeasurementReportService\\.${name}\\b`, 'g'),
    name,
  );
}

const instanceNames = [
  'MUSCLE_BALANCE_DB',
  'SCENARIO_DB',
  'EXERCISE_CASE_DB',
  'FRONT_PATTERN_DB',
  'REAR_PATTERN_DB',
  'JOINT_ROM_CONTENT_DB',
  'SIDE_PATTERN_DB',
];
for (const name of instanceNames) {
  service = service.replace(new RegExp(`this\\.${name}\\b`, 'g'), name);
}

for (const name of [
  'HEIGHT_LOSS_THRESHOLDS',
  'BALANCE_STATE_RULES',
  'MANAGEMENT_RECOMMENDATION_BY_SCORE',
  'OHT_CASE_DB',
]) {
  service = service.replace(new RegExp(`this\\.${name}\\b`, 'g'), name);
}

fs.writeFileSync(servicePath, service);

console.log(
  JSON.stringify(
    {
      exported: exportedNames.length,
      removedBlocks: blocks.length,
      serviceLinesBefore: lines.length,
      serviceLinesAfter: newLines.length,
      exportedNames,
    },
    null,
    2,
  ),
);
