/**
 * user_notifications 테이블 및 bill_keys cust_name 컬럼 마이그레이션
 *
 * Usage:
 *   node scripts/migrate-user-notifications.mjs
 */
import { config as loadEnv } from 'dotenv';
import { existsSync } from 'fs';
import { resolve } from 'path';
import mysql from 'mysql2/promise';

if (existsSync(resolve('.env.local'))) {
  loadEnv({ path: '.env.local' });
} else {
  loadEnv();
}

const connection = await mysql.createConnection({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  multipleStatements: true,
});

async function columnExists(table, column) {
  const [rows] = await connection.query(
    'SELECT COUNT(*) AS cnt FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
    [process.env.DB_NAME, table, column],
  );
  return Number(rows[0].cnt) > 0;
}

async function tableExists(table) {
  const [rows] = await connection.query(
    'SELECT COUNT(*) AS cnt FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
    [process.env.DB_NAME, table],
  );
  return Number(rows[0].cnt) > 0;
}

const CREATE_USER_NOTIFICATIONS = `
CREATE TABLE user_notifications (
  id char(36) NOT NULL COMMENT '알림 ID',
  user_id char(36) NOT NULL COMMENT '수신 유저 ID',
  type enum('NOTICE','EVENT','APP') NOT NULL COMMENT '알림 유형 (공지/이벤트/앱 알림)',
  title varchar(255) NOT NULL COMMENT '알림 제목',
  body text NOT NULL COMMENT '알림 본문',
  data json NULL COMMENT '추가 데이터 (딥링크 등)',
  read_at timestamp(3) NULL COMMENT '읽음 일시 (NULL이면 미읽음)',
  created_at timestamp(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '생성일시',
  PRIMARY KEY (id),
  KEY IDX_user_notifications_user_id_created_at (user_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
`;

const ALTER_BILL_KEYS = `
ALTER TABLE bill_keys
ADD COLUMN cust_name varchar(50) NULL COMMENT '카드 소유주명 (주문자명)' AFTER view_card_no
`;

const ALTER_BILL_KEY_REGISTRATIONS = `
ALTER TABLE bill_key_registrations
ADD COLUMN cust_name varchar(50) NULL COMMENT '카드 소유주명 (주문자명)' AFTER cust_no
`;

try {
  if (!await tableExists('user_notifications')) {
    console.log('Creating table user_notifications...');
    await connection.query(CREATE_USER_NOTIFICATIONS);
    console.log('user_notifications created.');
  } else {
    console.log('user_notifications already exists — skip.');
  }

  if (!await columnExists('bill_keys', 'cust_name')) {
    console.log('Adding bill_keys.cust_name...');
    await connection.query(ALTER_BILL_KEYS);
    console.log('bill_keys.cust_name added.');
  } else {
    console.log('bill_keys.cust_name already exists — skip.');
  }

  if (!await columnExists('bill_key_registrations', 'cust_name')) {
    console.log('Adding bill_key_registrations.cust_name...');
    await connection.query(ALTER_BILL_KEY_REGISTRATIONS);
    console.log('bill_key_registrations.cust_name added.');
  } else {
    console.log('bill_key_registrations.cust_name already exists — skip.');
  }

  console.log('Migration completed.');
} finally {
  await connection.end();
}
